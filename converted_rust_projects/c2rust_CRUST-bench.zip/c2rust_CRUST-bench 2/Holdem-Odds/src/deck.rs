#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn rand() -> ::core::ffi::c_int;
    fn NewCard(_: Rank, _: Suit) -> Card;
    fn CardEqual(_: *const Card, _: *const Card) -> bool;
    fn CardSwap(_: *mut Card, _: *mut Card);
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type Suit = ::core::ffi::c_uint;
pub const Spade: Suit = 4;
pub const Heart: Suit = 3;
pub const Diamond: Suit = 2;
pub const Club: Suit = 1;
pub const InvalidSuit: Suit = 0;
pub type Rank = ::core::ffi::c_uint;
pub const Ace: Rank = 13;
pub const King: Rank = 12;
pub const Queen: Rank = 11;
pub const Jack: Rank = 10;
pub const Ten: Rank = 9;
pub const Nine: Rank = 8;
pub const Eight: Rank = 7;
pub const Seven: Rank = 6;
pub const Six: Rank = 5;
pub const Five: Rank = 4;
pub const Four: Rank = 3;
pub const Trey: Rank = 2;
pub const Deuce: Rank = 1;
pub const InvalidRank: Rank = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Card {
    pub rank: Rank,
    pub suit: Suit,
}
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn DeckShuffle(
    mut deck: *mut Card,
    mut n: size_t,
    mut deck_size: size_t,
) {
    let mut i: size_t = 0 as size_t;
    while i < n {
        let mut j: size_t = (rand() as size_t).wrapping_rem(deck_size);
        CardSwap(&mut *deck.offset(i as isize), &mut *deck.offset(j as isize));
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn NewDeck(
    mut deck: *mut Card,
    mut rejects: *const Card,
    mut nb_rejects: size_t,
) {
    let mut i: size_t = 0 as size_t;
    let mut r: Rank = Deuce;
    while r as ::core::ffi::c_uint <= Ace as ::core::ffi::c_int as ::core::ffi::c_uint {
        let mut s: Suit = Club;
        while s as ::core::ffi::c_uint
            <= Spade as ::core::ffi::c_int as ::core::ffi::c_uint
        {
            let mut c: Card = NewCard(r, s);
            let mut insert: bool = true_0 != 0;
            let mut j: size_t = 0 as size_t;
            while j < nb_rejects {
                if CardEqual(&mut c, &*rejects.offset(j as isize)) {
                    insert = false_0 != 0;
                    break;
                } else {
                    j = j.wrapping_add(1);
                }
            }
            if insert {
                *deck.offset(i as isize) = c;
                i = i.wrapping_add(1);
            }
            s += 1;
        }
        r += 1;
    }
}
