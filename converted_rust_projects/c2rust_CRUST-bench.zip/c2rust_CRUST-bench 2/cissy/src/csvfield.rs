#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn exit(_: ::core::ffi::c_int) -> !;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strncpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> *mut ::core::ffi::c_char;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct csvfield {
    pub data: *mut ::core::ffi::c_char,
    pub len: size_t,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub static mut STR_MEM_PAD: ::core::ffi::c_int = 10 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn csvfield_printToFile(
    mut pField: *const csvfield,
    mut fp: *mut FILE,
) {
    fprintf(
        fp,
        b"[%s:%d]\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*pField).data,
        (*pField).len as ::core::ffi::c_int,
    );
}
#[no_mangle]
pub unsafe extern "C" fn csvfield_set(
    mut pField: *mut csvfield,
    mut buf: *const ::core::ffi::c_char,
    mut offset: ::core::ffi::c_int,
    mut buflen: ::core::ffi::c_int,
) {
    if (buflen + 1 as ::core::ffi::c_int) as size_t > (*pField).len {
        if !(*pField).data.is_null() {
            free((*pField).data as *mut ::core::ffi::c_void);
        }
        (*pField).len = (buflen + 1 as ::core::ffi::c_int + STR_MEM_PAD) as size_t;
        (*pField).data = malloc((*pField).len) as *mut ::core::ffi::c_char;
        if (*pField).data.is_null() {
            fprintf(
                __stderrp,
                b"csv_setCsvfield: malloc error\n\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
            exit(-(1 as ::core::ffi::c_int));
        }
    }
    strncpy((*pField).data, &*buf.offset(offset as isize), buflen as size_t);
    *(*pField).data.offset(buflen as isize) = '\0' as i32 as ::core::ffi::c_char;
}
#[no_mangle]
pub unsafe extern "C" fn csvfield_append(
    mut pField: *mut csvfield,
    mut buf: *const ::core::ffi::c_char,
    mut offset: ::core::ffi::c_int,
    mut buflen: ::core::ffi::c_int,
) {
    let mut origflen: ::core::ffi::c_int = (if !(*pField).data.is_null() {
        strlen((*pField).data)
    } else {
        0 as size_t
    }) as ::core::ffi::c_int;
    if (origflen + buflen + 1 as ::core::ffi::c_int) as size_t > (*pField).len {
        let mut tmp: *mut ::core::ffi::c_char = (*pField).data;
        (*pField).len = (*pField)
            .len
            .wrapping_add(buflen as size_t)
            .wrapping_add(STR_MEM_PAD as size_t);
        (*pField).data = malloc((*pField).len) as *mut ::core::ffi::c_char;
        if (*pField).data.is_null() {
            fprintf(
                __stderrp,
                b"csv_setCsvfield: malloc error\n\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
            exit(-(1 as ::core::ffi::c_int));
        }
        if !tmp.is_null() {
            strncpy((*pField).data, tmp, strlen(tmp).wrapping_add(1 as size_t));
            free(tmp as *mut ::core::ffi::c_void);
        }
    }
    strncpy(
        &mut *(*pField).data.offset(origflen as isize),
        &*buf.offset(offset as isize),
        buflen as size_t,
    );
    *(*pField).data.offset((origflen + buflen) as isize) = '\0' as i32
        as ::core::ffi::c_char;
}
#[no_mangle]
pub unsafe extern "C" fn csvfield_create() -> *mut csvfield {
    let mut pField: *mut csvfield = malloc(::core::mem::size_of::<csvfield>() as size_t)
        as *mut csvfield;
    if pField.is_null() {
        fprintf(
            __stderrp,
            b"csvfield_create: malloc error\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        exit(-(1 as ::core::ffi::c_int));
    }
    (*pField).len = STR_MEM_PAD as size_t;
    (*pField).data = malloc((*pField).len) as *mut ::core::ffi::c_char;
    if (*pField).data.is_null() {
        fprintf(
            __stderrp,
            b"csvfield_create: malloc error\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        exit(-(1 as ::core::ffi::c_int));
    }
    return pField;
}
#[no_mangle]
pub unsafe extern "C" fn csvfield_reset(mut pField: *mut csvfield) {
    (*pField).data = 0 as *mut ::core::ffi::c_char;
}
