#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn rand() -> ::core::ffi::c_int;
    fn srand(_: ::core::ffi::c_uint);
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn time(_: *mut time_t) -> time_t;
}
pub type __uint128_t = u128;
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_time_t = ::core::ffi::c_long;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type uint8_t = u8;
pub type time_t = __darwin_time_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct MinimizerResult {
    pub minimizer_hash: __uint128_t,
    pub kmer_position: size_t,
    pub smer_position: size_t,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[inline]
unsafe extern "C" fn base_to_bits(mut base: ::core::ffi::c_char) -> uint8_t {
    match base as ::core::ffi::c_int {
        65 | 97 => return 0 as uint8_t,
        67 | 99 => return 1 as uint8_t,
        71 | 103 => return 2 as uint8_t,
        84 | 116 => return 3 as uint8_t,
        _ => return 0 as uint8_t,
    };
}
#[inline]
unsafe extern "C" fn complement_base(mut base: uint8_t) -> uint8_t {
    return (3 as ::core::ffi::c_int - base as ::core::ffi::c_int) as uint8_t;
}
unsafe extern "C" fn add_minimizer(
    mut results: *mut MinimizerResult,
    mut size: *mut ::core::ffi::c_int,
    mut minimizer_hash: __uint128_t,
    mut kmer_position: size_t,
    mut smer_position: size_t,
) {
    (*results.offset(*size as isize)).minimizer_hash = minimizer_hash;
    (*results.offset(*size as isize)).kmer_position = kmer_position;
    (*results.offset(*size as isize)).smer_position = smer_position;
    *size += 1;
}
#[no_mangle]
pub unsafe extern "C" fn compute_closed_syncmers(
    mut sequence_input: *const ::core::ffi::c_char,
    mut len: ::core::ffi::c_int,
    mut K: ::core::ffi::c_int,
    mut S: ::core::ffi::c_int,
    mut results: *mut MinimizerResult,
    mut num_results: *mut ::core::ffi::c_int,
) {
    *num_results = 0 as ::core::ffi::c_int;
    if len < K {
        fprintf(
            __stderrp,
            b"Sequence length is less than K\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return;
    }
    let mut num_s_mers: size_t = (len - S + 1 as ::core::ffi::c_int) as size_t;
    let mut s_mer_hashes: *mut __uint128_t = malloc(
        num_s_mers.wrapping_mul(::core::mem::size_of::<__uint128_t>() as size_t),
    ) as *mut __uint128_t;
    let mut mask: __uint128_t = ((1 as ::core::ffi::c_int as __uint128_t)
        << 2 as ::core::ffi::c_int * S)
        .wrapping_sub(1 as __uint128_t);
    let mut hash_fwd: __uint128_t = 0 as __uint128_t;
    let mut hash_rev: __uint128_t = 0 as __uint128_t;
    let mut rc_shift: __uint128_t = (2 as ::core::ffi::c_int
        * (S - 1 as ::core::ffi::c_int)) as __uint128_t;
    let mut i: size_t = 0 as size_t;
    while i < len as size_t {
        let mut base: uint8_t = base_to_bits(*sequence_input.offset(i as isize));
        hash_fwd = (hash_fwd << 2 as ::core::ffi::c_int | base as __uint128_t) & mask;
        let mut comp_base: uint8_t = complement_base(base);
        hash_rev = (hash_rev >> 2 as ::core::ffi::c_int
            | (comp_base as __uint128_t) << rc_shift) & mask;
        if i >= (S - 1 as ::core::ffi::c_int) as size_t {
            let mut s_mer_pos: size_t = i
                .wrapping_sub(S as size_t)
                .wrapping_add(1 as size_t);
            let mut canonical_hash: __uint128_t = if hash_fwd < hash_rev {
                hash_fwd
            } else {
                hash_rev
            };
            *s_mer_hashes.offset(s_mer_pos as isize) = canonical_hash;
        }
        i = i.wrapping_add(1);
    }
    let mut window_size: size_t = (K - S + 1 as ::core::ffi::c_int) as size_t;
    let mut deque: *mut size_t = malloc(
        num_s_mers.wrapping_mul(::core::mem::size_of::<size_t>() as size_t),
    ) as *mut size_t;
    let mut front: size_t = 0 as size_t;
    let mut back: size_t = 0 as size_t;
    let mut i_0: size_t = 0 as size_t;
    while i_0 < num_s_mers {
        while back > front
            && *s_mer_hashes
                .offset(*deque.offset(back.wrapping_sub(1 as size_t) as isize) as isize)
                > *s_mer_hashes.offset(i_0 as isize)
        {
            back = back.wrapping_sub(1);
        }
        let fresh0 = back;
        back = back.wrapping_add(1);
        *deque.offset(fresh0 as isize) = i_0;
        if i_0 >= window_size
            && *deque.offset(front as isize) <= i_0.wrapping_sub(window_size)
        {
            front = front.wrapping_add(1);
        }
        if i_0 >= window_size.wrapping_sub(1 as size_t) {
            let mut min_pos: size_t = *deque.offset(front as isize);
            let mut kmer_pos: size_t = i_0
                .wrapping_sub(window_size)
                .wrapping_add(1 as size_t);
            if min_pos == kmer_pos
                || min_pos
                    == kmer_pos.wrapping_add(K as size_t).wrapping_sub(S as size_t)
            {
                add_minimizer(
                    results,
                    num_results,
                    *s_mer_hashes.offset(min_pos as isize),
                    kmer_pos,
                    min_pos,
                );
            }
        }
        i_0 = i_0.wrapping_add(1);
    }
    free(s_mer_hashes as *mut ::core::ffi::c_void);
    free(deque as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn compute_closed_syncmers_naive(
    mut sequence: *const ::core::ffi::c_char,
    mut seq_len: size_t,
    mut K: ::core::ffi::c_int,
    mut S: ::core::ffi::c_int,
    mut results: *mut MinimizerResult,
    mut num_results: *mut ::core::ffi::c_int,
) {
    *num_results = 0 as ::core::ffi::c_int;
    let mut mask: __uint128_t = ((1 as ::core::ffi::c_int as __uint128_t)
        << 2 as ::core::ffi::c_int * S)
        .wrapping_sub(1 as __uint128_t);
    let mut i: size_t = 0 as size_t;
    while i <= seq_len.wrapping_sub(K as size_t) {
        let mut min_hash: __uint128_t = !(0 as ::core::ffi::c_int as __uint128_t);
        let mut min_pos_in_kmer: size_t = 0 as size_t;
        let mut j: size_t = 0 as size_t;
        while j <= (K - S) as size_t {
            let mut s_mer_pos: size_t = i.wrapping_add(j);
            let mut hash_fwd: __uint128_t = 0 as __uint128_t;
            let mut hash_rev: __uint128_t = 0 as __uint128_t;
            let mut k: size_t = 0 as size_t;
            while k < S as size_t {
                let mut base: uint8_t = base_to_bits(
                    *sequence.offset(s_mer_pos.wrapping_add(k) as isize),
                );
                hash_fwd = hash_fwd << 2 as ::core::ffi::c_int | base as __uint128_t;
                k = k.wrapping_add(1);
            }
            hash_fwd &= mask;
            let mut k_0: size_t = 0 as size_t;
            while k_0 < S as size_t {
                let mut pos: size_t = s_mer_pos
                    .wrapping_add(S as size_t)
                    .wrapping_sub(1 as size_t)
                    .wrapping_sub(k_0);
                let mut base_0: uint8_t = base_to_bits(*sequence.offset(pos as isize));
                let mut comp_base: uint8_t = complement_base(base_0);
                hash_rev = hash_rev << 2 as ::core::ffi::c_int
                    | comp_base as __uint128_t;
                k_0 = k_0.wrapping_add(1);
            }
            hash_rev &= mask;
            let mut canonical_hash: __uint128_t = if hash_fwd < hash_rev {
                hash_fwd
            } else {
                hash_rev
            };
            if canonical_hash < min_hash {
                min_hash = canonical_hash;
                min_pos_in_kmer = j;
            }
            j = j.wrapping_add(1);
        }
        if min_pos_in_kmer == 0 as size_t || min_pos_in_kmer == (K - S) as size_t {
            (*results.offset(*num_results as isize)).kmer_position = i;
            (*results.offset(*num_results as isize)).smer_position = i
                .wrapping_add(min_pos_in_kmer);
            (*results.offset(*num_results as isize)).minimizer_hash = min_hash;
            *num_results += 1;
        }
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn generate_sequence(
    mut seq: *mut ::core::ffi::c_char,
    mut len: ::core::ffi::c_int,
) {
    let bases: [::core::ffi::c_char; 5] = ::core::mem::transmute::<
        [u8; 5],
        [::core::ffi::c_char; 5],
    >(*b"ACGT\0");
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < len {
        *seq.offset(i as isize) = bases[(rand() % 4 as ::core::ffi::c_int) as usize];
        i += 1;
    }
    *seq.offset(len as isize) = '\0' as i32 as ::core::ffi::c_char;
}
unsafe fn main_0() -> ::core::ffi::c_int {
    srand(time(0 as *mut time_t) as ::core::ffi::c_uint);
    let mut num_tests: ::core::ffi::c_int = 10 as ::core::ffi::c_int;
    let mut sequence_length: ::core::ffi::c_int = 1050 as ::core::ffi::c_int;
    let vla = (sequence_length + 1 as ::core::ffi::c_int) as usize;
    let mut sequence: Vec<::core::ffi::c_char> = ::std::vec::from_elem(0, vla);
    let mut test: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    while test <= num_tests {
        generate_sequence(sequence.as_mut_ptr(), sequence_length);
        let mut a: ::core::ffi::c_int = rand() % 989 as ::core::ffi::c_int
            + 11 as ::core::ffi::c_int;
        let mut b_min: ::core::ffi::c_int = 7 as ::core::ffi::c_int;
        let mut b_max: ::core::ffi::c_int = if (a - 1 as ::core::ffi::c_int)
            < 63 as ::core::ffi::c_int
        {
            a - 1 as ::core::ffi::c_int
        } else {
            63 as ::core::ffi::c_int
        };
        let mut b: ::core::ffi::c_int = if b_max < b_min {
            b_min
        } else {
            rand() % (b_max - b_min + 1 as ::core::ffi::c_int) + b_min
        };
        printf(
            b"Test %d: Sequence Length=%d, K=%d, S=%d\n\0" as *const u8
                as *const ::core::ffi::c_char,
            test,
            sequence_length,
            a,
            b,
        );
        let mut num_results: ::core::ffi::c_int = 0;
        let mut results: [MinimizerResult; 10000] = [MinimizerResult {
            minimizer_hash: 0,
            kmer_position: 0,
            smer_position: 0,
        }; 10000];
        compute_closed_syncmers(
            sequence.as_mut_ptr(),
            strlen(sequence.as_mut_ptr()) as ::core::ffi::c_int,
            a,
            b,
            results.as_mut_ptr(),
            &mut num_results,
        );
        printf(b"Closed Syncmers:\n\0" as *const u8 as *const ::core::ffi::c_char);
        printf(
            b"%-20s %-20s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"Position\0" as *const u8 as *const ::core::ffi::c_char,
            b"Minimizer Hash\0" as *const u8 as *const ::core::ffi::c_char,
        );
        let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while i < num_results {
            printf(
                b"%-20zu %-20llu\n\0" as *const u8 as *const ::core::ffi::c_char,
                results[i as usize].kmer_position,
                results[i as usize].minimizer_hash as ::core::ffi::c_ulonglong,
            );
            i += 1;
        }
        let mut num_naive_results: ::core::ffi::c_int = 0;
        let mut naive_results: [MinimizerResult; 10000] = [MinimizerResult {
            minimizer_hash: 0,
            kmer_position: 0,
            smer_position: 0,
        }; 10000];
        compute_closed_syncmers_naive(
            sequence.as_mut_ptr(),
            strlen(sequence.as_mut_ptr()),
            a,
            b,
            naive_results.as_mut_ptr(),
            &mut num_naive_results,
        );
        printf(
            b"\nClosed Syncmers (Naive):\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        printf(
            b"%-20s %-20s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"Position\0" as *const u8 as *const ::core::ffi::c_char,
            b"Minimizer Hash\0" as *const u8 as *const ::core::ffi::c_char,
        );
        let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while i_0 < num_naive_results {
            printf(
                b"%-20zu %-20llu\n\0" as *const u8 as *const ::core::ffi::c_char,
                naive_results[i_0 as usize].kmer_position,
                naive_results[i_0 as usize].minimizer_hash as ::core::ffi::c_ulonglong,
            );
            i_0 += 1;
        }
        if num_results != num_naive_results {
            printf(
                b"\nMismatch in number of closed syncmers: %d (original) vs %d (naive)\n\0"
                    as *const u8 as *const ::core::ffi::c_char,
                num_results,
                num_naive_results,
            );
            return 1 as ::core::ffi::c_int;
        } else {
            printf(
                b"\nNumber of closed syncmers matches: %d\n\0" as *const u8
                    as *const ::core::ffi::c_char,
                num_results,
            );
        }
        let mut mismatch: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        let mut i_1: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while i_1 < num_results {
            if results[i_1 as usize].kmer_position
                != naive_results[i_1 as usize].kmer_position
                || results[i_1 as usize].minimizer_hash
                    != naive_results[i_1 as usize].minimizer_hash
            {
                printf(
                    b"Mismatch at index %d:\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    i_1,
                );
                printf(
                    b"  Original -> Position: %zu, Hash: %llu\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    results[i_1 as usize].kmer_position,
                    results[i_1 as usize].minimizer_hash as ::core::ffi::c_ulonglong,
                );
                printf(
                    b"  Naive    -> Position: %zu, Hash: %llu\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    naive_results[i_1 as usize].kmer_position,
                    naive_results[i_1 as usize].minimizer_hash
                        as ::core::ffi::c_ulonglong,
                );
                mismatch = 1 as ::core::ffi::c_int;
                break;
            } else {
                i_1 += 1;
            }
        }
        if mismatch != 0 {
            printf(
                b"Test %d failed.\n\0" as *const u8 as *const ::core::ffi::c_char,
                test,
            );
            return 1 as ::core::ffi::c_int;
        }
        printf(
            b"Test %d passed. All closed syncmers match between original and naive method.\n\n\0"
                as *const u8 as *const ::core::ffi::c_char,
            test,
        );
        test += 1;
    }
    printf(b"All tests passed.\n\0" as *const u8 as *const ::core::ffi::c_char);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
