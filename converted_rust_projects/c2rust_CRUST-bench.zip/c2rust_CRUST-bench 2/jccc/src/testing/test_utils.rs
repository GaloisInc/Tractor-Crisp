#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stdoutp: *mut FILE;
    static mut __stderrp: *mut FILE;
    fn fflush(_: *mut FILE) -> ::core::ffi::c_int;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
}
pub type __int64_t = i64;
pub type __darwin_off_t = __int64_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[no_mangle]
pub unsafe extern "C" fn testing_setup_internal(
    mut func_name: *const ::core::ffi::c_char,
) {
    printf(b"Running tests from \0" as *const u8 as *const ::core::ffi::c_char);
    fflush(__stdoutp);
    fprintf(
        __stderrp,
        b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
        32 as ::core::ffi::c_int,
    );
    fprintf(
        __stderrp,
        b"\"%s\"\0" as *const u8 as *const ::core::ffi::c_char,
        func_name,
    );
    fprintf(__stderrp, b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b" ...\n\0" as *const u8 as *const ::core::ffi::c_char);
}
#[no_mangle]
pub unsafe extern "C" fn testing_cleanup_internal(
    mut func_name: *const ::core::ffi::c_char,
) {
    printf(b"Concluded tests from \0" as *const u8 as *const ::core::ffi::c_char);
    fflush(__stdoutp);
    fprintf(
        __stderrp,
        b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
        32 as ::core::ffi::c_int,
    );
    fprintf(
        __stderrp,
        b"\"%s\"\0" as *const u8 as *const ::core::ffi::c_char,
        func_name,
    );
    fprintf(__stderrp, b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
}
#[no_mangle]
pub unsafe extern "C" fn testing_single_test_internal(
    mut func_name: *const ::core::ffi::c_char,
) {
    printf(b"Running \0" as *const u8 as *const ::core::ffi::c_char);
    fflush(__stdoutp);
    fprintf(
        __stderrp,
        b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
        32 as ::core::ffi::c_int,
    );
    fprintf(
        __stderrp,
        b"\"%s\"\0" as *const u8 as *const ::core::ffi::c_char,
        func_name,
    );
    fprintf(__stderrp, b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
}
