#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn memcmp(
        __s1: *const ::core::ffi::c_void,
        __s2: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> ::core::ffi::c_int;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memmove(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn realloc(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type utf8_t = ::core::ffi::c_uchar;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct utf8_string_s {
    pub data: *mut utf8_t,
    pub len: size_t,
    pub c2rust_unnamed: C2RustUnnamed,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed {
    pub cap: size_t,
    pub buf: [utf8_t; 8],
}
pub type utf8_string_t = utf8_string_s;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut e: ::core::ffi::c_int = 0;
    let mut string: utf8_string_t = utf8_string_s {
        data: 0 as *mut utf8_t,
        len: 0,
        c2rust_unnamed: C2RustUnnamed { cap: 0 },
    };
    utf8_string_init(&mut string);
    e = utf8_string_prepend_literal(
        &mut string,
        b" world\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        -(1 as ::core::ffi::c_int) as size_t,
    );
    if !(e == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"string-prepend.c\0" as *const u8 as *const ::core::ffi::c_char,
            15 as ::core::ffi::c_int,
            b"e == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    e = utf8_string_prepend_literal(
        &mut string,
        b"hello\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        -(1 as ::core::ffi::c_int) as size_t,
    );
    if !(e == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"string-prepend.c\0" as *const u8 as *const ::core::ffi::c_char,
            18 as ::core::ffi::c_int,
            b"e == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        string.data as *const ::core::ffi::c_void,
        b"hello world\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        string.len,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"string-prepend.c\0" as *const u8 as *const ::core::ffi::c_char,
            20 as ::core::ffi::c_int,
            b"memcmp(string.data, \"hello world\", string.len) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    utf8_string_destroy(&mut string);
    return 0;
}
#[inline]
unsafe extern "C" fn utf8_string_init(mut string: *mut utf8_string_t) {
    (*string).data = (*string).c2rust_unnamed.buf.as_mut_ptr();
    (*string).len = 0 as size_t;
}
#[inline]
unsafe extern "C" fn utf8_string_destroy(mut string: *mut utf8_string_t) {
    if (*string).data != (*string).c2rust_unnamed.buf.as_mut_ptr() {
        free((*string).data as *mut ::core::ffi::c_void);
    }
}
#[inline]
unsafe extern "C" fn utf8_string_reserve(
    mut string: *mut utf8_string_t,
    mut len: size_t,
) -> ::core::ffi::c_int {
    let mut cap: size_t = if (*string).data == (*string).c2rust_unnamed.buf.as_mut_ptr()
    {
        ::core::mem::size_of::<[utf8_t; 8]>() as size_t
    } else {
        (*string).c2rust_unnamed.cap
    };
    if len <= cap {
        return 0 as ::core::ffi::c_int;
    }
    len = len.wrapping_sub(1);
    len |= len >> 1 as ::core::ffi::c_int;
    len |= len >> 2 as ::core::ffi::c_int;
    len |= len >> 4 as ::core::ffi::c_int;
    len |= len >> 8 as ::core::ffi::c_int;
    len |= len >> 16 as ::core::ffi::c_int;
    if ::core::mem::size_of::<size_t>() as usize == 8 as usize {
        len |= len >> 32 as ::core::ffi::c_int;
    }
    len = len.wrapping_add(1);
    cap = len;
    let mut data: *mut utf8_t = 0 as *mut utf8_t;
    if (*string).data == (*string).c2rust_unnamed.buf.as_mut_ptr() {
        data = malloc(cap) as *mut utf8_t;
        memcpy(
            data as *mut ::core::ffi::c_void,
            (*string).data as *const ::core::ffi::c_void,
            (*string).len,
        );
    } else {
        data = realloc((*string).data as *mut ::core::ffi::c_void, cap) as *mut utf8_t;
    }
    if data.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    (*string).data = data;
    (*string).c2rust_unnamed.cap = cap;
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_prepend_literal(
    mut string: *mut utf8_string_t,
    mut literal: *const utf8_t,
    mut n: size_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    if n == -(1 as ::core::ffi::c_int) as size_t {
        n = strlen(literal as *const ::core::ffi::c_char);
    }
    err = utf8_string_reserve(string, (*string).len.wrapping_add(n));
    if err < 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    memmove(
        &mut *(*string).data.offset(n as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        (*string).data as *const ::core::ffi::c_void,
        (*string).len,
    );
    memcpy(
        (*string).data as *mut ::core::ffi::c_void,
        literal as *const ::core::ffi::c_void,
        n,
    );
    (*string).len = (*string).len.wrapping_add(n);
    return 0 as ::core::ffi::c_int;
}
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
