#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn insert_log(
        log_type: ::core::ffi::c_uint,
        priority: ::core::ffi::c_uint,
        format: *const ::core::ffi::c_char,
        ...
    );
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type hash_t = ::core::ffi::c_uint;
pub type o_key_t = *const ::core::ffi::c_char;
pub type o_data_t = *const ::core::ffi::c_char;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct cuckoo_hash_table {
    pub cur_size: ::core::ffi::c_uint,
    pub cur_marker: ::core::ffi::c_uint,
    pub max_size: ::core::ffi::c_uint,
    pub first_arr: *mut cuckoo_entry,
    pub second_arr: *mut cuckoo_entry,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct cuckoo_entry {
    pub key: o_key_t,
    pub data: o_data_t,
    pub marker: ::core::ffi::c_uint,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
static mut empty_key: o_key_t = 0 as o_key_t;
static mut power: hash_t = 131 as hash_t;
static mut alternative_power: hash_t = 171 as hash_t;
#[inline]
unsafe extern "C" fn hash_by_power(mut p: o_key_t, mut power_0: hash_t) -> hash_t {
    let mut res: hash_t = 0 as hash_t;
    while *p != 0 {
        let fresh0 = p;
        p = p.offset(1);
        res = res.wrapping_mul(power_0).wrapping_add(*fresh0 as hash_t);
    }
    return res;
}
#[inline]
unsafe extern "C" fn hash(mut p: o_key_t) -> hash_t {
    return hash_by_power(p, power);
}
#[inline]
unsafe extern "C" fn compare_keys(
    mut k1: o_key_t,
    mut k2: o_key_t,
) -> ::core::ffi::c_int {
    return strcmp(k1 as *const ::core::ffi::c_char, k2 as *const ::core::ffi::c_char);
}
pub const CUCKOO_HASH_LOG: ::core::ffi::c_int = 3 as ::core::ffi::c_int;
static mut load_factor: ::core::ffi::c_float = 1.0f32;
static mut eps: ::core::ffi::c_float = 1e-3f32;
#[inline]
unsafe extern "C" fn allocate_arr(mut size: ::core::ffi::c_uint) -> *mut cuckoo_entry {
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        1 as ::core::ffi::c_uint,
        b"Allocating new array with size = %u.\0" as *const u8
            as *const ::core::ffi::c_char,
        size,
    );
    let mut arr: *mut cuckoo_entry = 0 as *mut cuckoo_entry;
    let arr_size: ::core::ffi::c_uint = (::core::mem::size_of::<cuckoo_entry>() as usize)
        .wrapping_mul(size as usize) as ::core::ffi::c_uint;
    arr = malloc(arr_size as size_t) as *mut cuckoo_entry;
    memset(arr as *mut ::core::ffi::c_void, 0 as ::core::ffi::c_int, arr_size as size_t);
    return arr;
}
#[inline]
unsafe extern "C" fn initialize_table(
    mut size: ::core::ffi::c_uint,
    mut table: *mut cuckoo_hash_table,
) {
    (*table).cur_size = 0 as ::core::ffi::c_uint;
    (*table).cur_marker = 0 as ::core::ffi::c_uint;
    (*table).max_size = size;
    (*table).first_arr = allocate_arr(size);
    (*table).second_arr = allocate_arr(size);
}
#[no_mangle]
pub unsafe extern "C" fn create_cuckoo_hash_table(
    mut initial_size: ::core::ffi::c_uint,
) -> *mut cuckoo_hash_table {
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        5 as ::core::ffi::c_uint,
        b"Creating a new table with max size = %u.\0" as *const u8
            as *const ::core::ffi::c_char,
        initial_size,
    );
    if !(initial_size >= 2 as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"create_cuckoo_hash_table\0")
                .as_ptr(),
            b"cuckoohash.c\0" as *const u8 as *const ::core::ffi::c_char,
            48 as ::core::ffi::c_int,
            b"initial_size >= 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(initial_size != power && initial_size != alternative_power)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"create_cuckoo_hash_table\0")
                .as_ptr(),
            b"cuckoohash.c\0" as *const u8 as *const ::core::ffi::c_char,
            49 as ::core::ffi::c_int,
            b"initial_size != power && initial_size != alternative_power\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut ret: *mut cuckoo_hash_table = malloc(
        ::core::mem::size_of::<cuckoo_hash_table>() as size_t,
    ) as *mut cuckoo_hash_table;
    initialize_table(initial_size.wrapping_div(2 as ::core::ffi::c_uint), ret);
    return ret;
}
#[inline]
unsafe extern "C" fn recreate(
    mut new_size: ::core::ffi::c_uint,
    mut table: *mut cuckoo_hash_table,
) {
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        4 as ::core::ffi::c_uint,
        b"Recreating the table with new max size = %u.\0" as *const u8
            as *const ::core::ffi::c_char,
        new_size.wrapping_mul(2 as ::core::ffi::c_uint),
    );
    if !(new_size > 0 as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 9], [::core::ffi::c_char; 9]>(*b"recreate\0")
                .as_ptr(),
            b"cuckoohash.c\0" as *const u8 as *const ::core::ffi::c_char,
            60 as ::core::ffi::c_int,
            b"new_size > 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(new_size as ::core::ffi::c_float * load_factor + eps
        > (*table).cur_size as ::core::ffi::c_float) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 9], [::core::ffi::c_char; 9]>(*b"recreate\0")
                .as_ptr(),
            b"cuckoohash.c\0" as *const u8 as *const ::core::ffi::c_char,
            61 as ::core::ffi::c_int,
            b"(float)new_size * load_factor + eps > table->cur_size\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut old_first: *mut cuckoo_entry = (*table).first_arr;
    let mut old_second: *mut cuckoo_entry = (*table).second_arr;
    let mut old_size: ::core::ffi::c_uint = (*table).max_size;
    initialize_table(new_size, table);
    let mut i: ::core::ffi::c_uint = 0 as ::core::ffi::c_uint;
    while i < old_size {
        let mut cur_entry: *mut cuckoo_entry = &mut *old_first.offset(i as isize)
            as *mut cuckoo_entry;
        if (*cur_entry).key != empty_key {
            cuckoo_insert((*cur_entry).key, (*cur_entry).data, table);
        }
        i = i.wrapping_add(1);
    }
    let mut i_0: ::core::ffi::c_uint = 0 as ::core::ffi::c_uint;
    while i_0 < old_size {
        let mut cur_entry_0: *mut cuckoo_entry = &mut *old_second.offset(i_0 as isize)
            as *mut cuckoo_entry;
        if (*cur_entry_0).key != empty_key {
            cuckoo_insert((*cur_entry_0).key, (*cur_entry_0).data, table);
        }
        i_0 = i_0.wrapping_add(1);
    }
    free(old_first as *mut ::core::ffi::c_void);
    free(old_second as *mut ::core::ffi::c_void);
}
#[inline]
unsafe extern "C" fn resize(mut table: *mut cuckoo_hash_table) {
    recreate((*table).max_size.wrapping_mul(2 as ::core::ffi::c_uint), table);
}
#[inline]
unsafe extern "C" fn refill(mut table: *mut cuckoo_hash_table) {
    recreate((*table).max_size.wrapping_add(1 as ::core::ffi::c_uint), table);
}
#[inline]
unsafe extern "C" fn get_first_entry(
    mut key: o_key_t,
    mut table: *mut cuckoo_hash_table,
) -> *mut cuckoo_entry {
    let mut h: hash_t = hash(key);
    let mut hh: hash_t = h.wrapping_rem((*table).max_size as hash_t);
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        1 as ::core::ffi::c_uint,
        b"Looking for key = %s with hash = %u(%u) in the first array.\0" as *const u8
            as *const ::core::ffi::c_char,
        key,
        hh,
        h,
    );
    let mut ret: *mut cuckoo_entry = &mut *(*table).first_arr.offset(hh as isize)
        as *mut cuckoo_entry;
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        1 as ::core::ffi::c_uint,
        b"Found key = %s, data = %s, marker = %u.\0" as *const u8
            as *const ::core::ffi::c_char,
        if !(*ret).key.is_null() {
            (*ret).key as *const ::core::ffi::c_char
        } else {
            b"empty\0" as *const u8 as *const ::core::ffi::c_char
        },
        if !(*ret).data.is_null() {
            (*ret).data as *const ::core::ffi::c_char
        } else {
            b"empty\0" as *const u8 as *const ::core::ffi::c_char
        },
        (*ret).marker,
    );
    return ret;
}
#[inline]
unsafe extern "C" fn get_first_entry_c(
    mut key: o_key_t,
    mut table: *const cuckoo_hash_table,
) -> *const cuckoo_entry {
    let mut h: hash_t = hash(key);
    let mut hh: hash_t = h.wrapping_rem((*table).max_size as hash_t);
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        1 as ::core::ffi::c_uint,
        b"Looking for key = %s with hash = %u(%u) in the first array.\0" as *const u8
            as *const ::core::ffi::c_char,
        key,
        hh,
        h,
    );
    let mut ret: *const cuckoo_entry = &mut *(*table).first_arr.offset(hh as isize)
        as *mut cuckoo_entry;
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        1 as ::core::ffi::c_uint,
        b"Found key = %s, data = %s, marker = %u.\0" as *const u8
            as *const ::core::ffi::c_char,
        if !(*ret).key.is_null() {
            (*ret).key as *const ::core::ffi::c_char
        } else {
            b"empty\0" as *const u8 as *const ::core::ffi::c_char
        },
        if !(*ret).data.is_null() {
            (*ret).data as *const ::core::ffi::c_char
        } else {
            b"empty\0" as *const u8 as *const ::core::ffi::c_char
        },
        (*ret).marker,
    );
    return ret;
}
#[inline]
unsafe extern "C" fn get_second_entry(
    mut key: o_key_t,
    mut table: *mut cuckoo_hash_table,
) -> *mut cuckoo_entry {
    let mut h: hash_t = hash(key);
    let mut hh: hash_t = h.wrapping_rem((*table).max_size as hash_t);
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        1 as ::core::ffi::c_uint,
        b"Looking for key = %s with hash = %u(%u) in the second array.\0" as *const u8
            as *const ::core::ffi::c_char,
        key,
        hh,
        h,
    );
    let mut ret: *mut cuckoo_entry = &mut *(*table).second_arr.offset(hh as isize)
        as *mut cuckoo_entry;
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        1 as ::core::ffi::c_uint,
        b"Found key = %s, data = %s, marker = %u.\0" as *const u8
            as *const ::core::ffi::c_char,
        if !(*ret).key.is_null() {
            (*ret).key as *const ::core::ffi::c_char
        } else {
            b"empty\0" as *const u8 as *const ::core::ffi::c_char
        },
        if !(*ret).data.is_null() {
            (*ret).data as *const ::core::ffi::c_char
        } else {
            b"empty\0" as *const u8 as *const ::core::ffi::c_char
        },
        (*ret).marker,
    );
    return ret;
}
#[inline]
unsafe extern "C" fn get_second_entry_c(
    mut key: o_key_t,
    mut table: *const cuckoo_hash_table,
) -> *const cuckoo_entry {
    let mut h: hash_t = hash(key);
    let mut hh: hash_t = h.wrapping_rem((*table).max_size as hash_t);
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        1 as ::core::ffi::c_uint,
        b"Looking for key = %s with hash = %u(%u) in the second array.\0" as *const u8
            as *const ::core::ffi::c_char,
        key,
        hh,
        h,
    );
    let mut ret: *const cuckoo_entry = &mut *(*table).second_arr.offset(hh as isize)
        as *mut cuckoo_entry;
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        1 as ::core::ffi::c_uint,
        b"Found key = %s, data = %s, marker = %u.\0" as *const u8
            as *const ::core::ffi::c_char,
        if !(*ret).key.is_null() {
            (*ret).key as *const ::core::ffi::c_char
        } else {
            b"empty\0" as *const u8 as *const ::core::ffi::c_char
        },
        if !(*ret).data.is_null() {
            (*ret).data as *const ::core::ffi::c_char
        } else {
            b"empty\0" as *const u8 as *const ::core::ffi::c_char
        },
        (*ret).marker,
    );
    return ret;
}
#[inline]
unsafe extern "C" fn swap_key_data_entry(
    mut key: *mut o_key_t,
    mut data: *mut o_data_t,
    mut entry: *mut cuckoo_entry,
) {
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        2 as ::core::ffi::c_uint,
        b"Swapping key = %s, data = %s with key = %s, data = %s.\0" as *const u8
            as *const ::core::ffi::c_char,
        *key,
        *data,
        (*entry).key,
        (*entry).data,
    );
    if !(!key.is_null() && !data.is_null() && !entry.is_null()) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"swap_key_data_entry\0")
                .as_ptr(),
            b"cuckoohash.c\0" as *const u8 as *const ::core::ffi::c_char,
            141 as ::core::ffi::c_int,
            b"key && data && entry\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut swap_key: o_key_t = (*entry).key;
    let mut swap_data: o_data_t = (*entry).data;
    (*entry).key = *key;
    (*entry).data = *data;
    *key = swap_key;
    *data = swap_data;
}
#[inline]
unsafe extern "C" fn try_to_store(
    mut key: o_key_t,
    mut data: o_data_t,
    mut entry: *mut cuckoo_entry,
) -> ::core::ffi::c_int {
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        0 as ::core::ffi::c_uint,
        b"Trying to store key = %s, data = %s ...\0" as *const u8
            as *const ::core::ffi::c_char,
        key,
        data,
    );
    if (*entry).key == empty_key {
        insert_log(
            CUCKOO_HASH_LOG as ::core::ffi::c_uint,
            0 as ::core::ffi::c_uint,
            b"...success.\0" as *const u8 as *const ::core::ffi::c_char,
        );
        (*entry).key = key;
        (*entry).data = data;
        return 1 as ::core::ffi::c_int;
    } else {
        insert_log(
            CUCKOO_HASH_LOG as ::core::ffi::c_uint,
            0 as ::core::ffi::c_uint,
            b"...failure.\0" as *const u8 as *const ::core::ffi::c_char,
        );
        if !(compare_keys((*entry).key, key) != 0 as ::core::ffi::c_int)
            as ::core::ffi::c_int as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 13],
                    [::core::ffi::c_char; 13],
                >(*b"try_to_store\0")
                    .as_ptr(),
                b"cuckoohash.c\0" as *const u8 as *const ::core::ffi::c_char,
                164 as ::core::ffi::c_int,
                b"compare_keys(entry->key, key) != 0\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        } else {};
        return 0 as ::core::ffi::c_int;
    };
}
#[no_mangle]
pub unsafe extern "C" fn cuckoo_insert(
    mut key: o_key_t,
    mut data: o_data_t,
    mut table: *mut cuckoo_hash_table,
) {
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        4 as ::core::ffi::c_uint,
        b"Inserting key = %s, data = %s.\0" as *const u8 as *const ::core::ffi::c_char,
        key,
        data,
    );
    (*table).cur_marker = (*table).cur_marker.wrapping_add(1);
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        3 as ::core::ffi::c_uint,
        b"Table size = %u, max size = %u and the new marker = %u.\0" as *const u8
            as *const ::core::ffi::c_char,
        (*table).cur_size,
        (*table).max_size,
        (*table).cur_marker,
    );
    if 1.0f64 + (*table).cur_size as ::core::ffi::c_double
        > ((*table).max_size as ::core::ffi::c_float * load_factor)
            as ::core::ffi::c_double
    {
        insert_log(
            CUCKOO_HASH_LOG as ::core::ffi::c_uint,
            4 as ::core::ffi::c_uint,
            b"Table fillness is above the load factor and it needs to be resized.\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
        resize(table);
        insert_log(
            CUCKOO_HASH_LOG as ::core::ffi::c_uint,
            2 as ::core::ffi::c_uint,
            b"Finished with resizing, continuing with key = %s, data = %s.\0"
                as *const u8 as *const ::core::ffi::c_char,
            key,
            data,
        );
    }
    (*table).cur_size = (*table).cur_size.wrapping_add(1);
    let mut first_entry: *mut cuckoo_entry = get_first_entry(key, table);
    if try_to_store(key, data, first_entry) != 0 {
        return;
    }
    let mut second_entry: *mut cuckoo_entry = get_second_entry(key, table);
    if try_to_store(key, data, second_entry) != 0 {
        return;
    }
    loop {
        swap_key_data_entry(&mut key, &mut data, first_entry);
        (*first_entry).marker = (*table).cur_marker;
        second_entry = get_second_entry(key, table);
        if (*second_entry).marker == (*table).cur_marker {
            insert_log(
                CUCKOO_HASH_LOG as ::core::ffi::c_uint,
                5 as ::core::ffi::c_uint,
                b"A cycle has been detected and the table needs to be recreated.\0"
                    as *const u8 as *const ::core::ffi::c_char,
            );
            refill(table);
            cuckoo_insert(key, data, table);
            break;
        } else {
            if try_to_store(key, data, second_entry) != 0 {
                break;
            }
            swap_key_data_entry(&mut key, &mut data, second_entry);
            (*second_entry).marker = (*table).cur_marker;
            first_entry = get_first_entry(key, table);
            if (*first_entry).marker == (*table).cur_marker {
                insert_log(
                    CUCKOO_HASH_LOG as ::core::ffi::c_uint,
                    5 as ::core::ffi::c_uint,
                    b"A cycle has been detected and the table needs to be recreated.\0"
                        as *const u8 as *const ::core::ffi::c_char,
                );
                refill(table);
                cuckoo_insert(key, data, table);
                break;
            } else if try_to_store(key, data, first_entry) != 0 {
                break;
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn cuckoo_find(
    mut key: o_key_t,
    mut table: *const cuckoo_hash_table,
) -> o_data_t {
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        3 as ::core::ffi::c_uint,
        b"Looking for key = %s.\0" as *const u8 as *const ::core::ffi::c_char,
        key,
    );
    let mut entry: *const cuckoo_entry = get_first_entry_c(key, table);
    if (*entry).key != empty_key
        && compare_keys((*entry).key, key) == 0 as ::core::ffi::c_int
    {
        insert_log(
            CUCKOO_HASH_LOG as ::core::ffi::c_uint,
            2 as ::core::ffi::c_uint,
            b"The key is found in the first array. Returning data = %s.\0" as *const u8
                as *const ::core::ffi::c_char,
            (*entry).data,
        );
        return (*entry).data;
    }
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        2 as ::core::ffi::c_uint,
        b"The key is not found in the first array.\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    entry = get_second_entry_c(key, table);
    if !((*entry).key != empty_key
        && compare_keys((*entry).key, key) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"cuckoo_find\0")
                .as_ptr(),
            b"cuckoohash.c\0" as *const u8 as *const ::core::ffi::c_char,
            231 as ::core::ffi::c_int,
            b"entry->key != empty_key && compare_keys(entry->key, key) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        2 as ::core::ffi::c_uint,
        b"The key is found in the second array. Returning data = %s.\0" as *const u8
            as *const ::core::ffi::c_char,
        (*entry).data,
    );
    return (*entry).data;
}
#[no_mangle]
pub unsafe extern "C" fn free_cuckoo_hash_table(mut table: *mut cuckoo_hash_table) {
    insert_log(
        CUCKOO_HASH_LOG as ::core::ffi::c_uint,
        5 as ::core::ffi::c_uint,
        b"Deleting hash table with current size = %u, maximum size = %u.\0" as *const u8
            as *const ::core::ffi::c_char,
        (*table).cur_size,
        (*table).max_size,
    );
    free((*table).first_arr as *mut ::core::ffi::c_void);
    free((*table).second_arr as *mut ::core::ffi::c_void);
    free(table as *mut ::core::ffi::c_void);
}
