#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(c_variadic, extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stdoutp: *mut FILE;
    fn sprintf(
        _: *mut ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn vfprintf(
        _: *mut FILE,
        _: *const ::core::ffi::c_char,
        _: va_list,
    ) -> ::core::ffi::c_int;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
}
pub type __builtin_va_list = *mut ::core::ffi::c_char;
pub type __int64_t = i64;
pub type __darwin_va_list = __builtin_va_list;
pub type __darwin_off_t = __int64_t;
pub type va_list = __darwin_va_list;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct log_info {
    pub priority: ::core::ffi::c_uint,
    pub prefix: [::core::ffi::c_char; 127],
    pub suffix: [::core::ffi::c_char; 127],
}
static mut log_info_table: [log_info; 4] = unsafe {
    [
        {
            let mut init = log_info {
                priority: 0 as ::core::ffi::c_uint,
                prefix: ::core::mem::transmute::<
                    [u8; 127],
                    [::core::ffi::c_char; 127],
                >(
                    *b"log log:\t\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
                suffix: ::core::mem::transmute::<
                    [u8; 127],
                    [::core::ffi::c_char; 127],
                >(
                    *b"\n\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
            };
            init
        },
        {
            let mut init = log_info {
                priority: 0 as ::core::ffi::c_uint,
                prefix: ::core::mem::transmute::<
                    [u8; 127],
                    [::core::ffi::c_char; 127],
                >(
                    *b"unit testing:\t\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
                suffix: ::core::mem::transmute::<
                    [u8; 127],
                    [::core::ffi::c_char; 127],
                >(
                    *b"\n\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
            };
            init
        },
        {
            let mut init = log_info {
                priority: 0 as ::core::ffi::c_uint,
                prefix: ::core::mem::transmute::<
                    [u8; 127],
                    [::core::ffi::c_char; 127],
                >(
                    *b"open hash table:\t\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
                suffix: ::core::mem::transmute::<
                    [u8; 127],
                    [::core::ffi::c_char; 127],
                >(
                    *b"\n\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
            };
            init
        },
        {
            let mut init = log_info {
                priority: 0 as ::core::ffi::c_uint,
                prefix: ::core::mem::transmute::<
                    [u8; 127],
                    [::core::ffi::c_char; 127],
                >(
                    *b"cuckoo hash table:\t\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
                suffix: ::core::mem::transmute::<
                    [u8; 127],
                    [::core::ffi::c_char; 127],
                >(
                    *b"\n\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
                ),
            };
            init
        },
    ]
};
#[inline]
unsafe extern "C" fn print_log(
    mut file: *mut FILE,
    mut format: *const ::core::ffi::c_char,
    mut args: va_list,
) {
    vfprintf(file, format, args as va_list);
}
#[no_mangle]
pub unsafe extern "C" fn change_log_priority(
    mut log_type: ::core::ffi::c_uint,
    mut new_priority: ::core::ffi::c_uint,
) -> ::core::ffi::c_uint {
    let mut old_priority: ::core::ffi::c_uint = log_info_table[log_type as usize]
        .priority;
    log_info_table[log_type as usize].priority = new_priority;
    return old_priority;
}
#[no_mangle]
pub unsafe extern "C" fn insert_log(
    mut log_type: ::core::ffi::c_uint,
    mut priority: ::core::ffi::c_uint,
    mut format: *const ::core::ffi::c_char,
    mut args: ...
) {
    if !(log_type < 4 as ::core::ffi::c_uint && priority <= 10 as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"insert_log\0")
                .as_ptr(),
            b"log.c\0" as *const u8 as *const ::core::ffi::c_char,
            43 as ::core::ffi::c_int,
            b"log_type < 4 && priority <= 10\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut cur_log_info: *mut log_info = &mut *log_info_table
        .as_mut_ptr()
        .offset(log_type as isize) as *mut log_info;
    if (*cur_log_info).priority <= priority {
        let mut message: [::core::ffi::c_char; 255] = [0; 255];
        sprintf(
            message.as_mut_ptr(),
            b"%s%s%s\0" as *const u8 as *const ::core::ffi::c_char,
            (*cur_log_info).prefix.as_mut_ptr(),
            format,
            (*cur_log_info).suffix.as_mut_ptr(),
        );
        let mut args_0: va_list = 0 as *mut ::core::ffi::c_char;
        args_0 = args.clone();
        print_log(__stdoutp, message.as_mut_ptr(), args_0);
    }
}
