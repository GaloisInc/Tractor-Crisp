#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn insert_log(
        log_type: ::core::ffi::c_uint,
        priority: ::core::ffi::c_uint,
        format: *const ::core::ffi::c_char,
        ...
    );
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type hash_t = ::core::ffi::c_uint;
pub type o_key_t = *const ::core::ffi::c_char;
pub type o_data_t = *const ::core::ffi::c_char;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct open_hash_table {
    pub cur_size: ::core::ffi::c_uint,
    pub max_size: ::core::ffi::c_uint,
    pub arr: *mut open_entry,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct open_entry {
    pub key: o_key_t,
    pub data: o_data_t,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
static mut empty_key: o_key_t = 0 as o_key_t;
static mut power: hash_t = 131 as hash_t;
static mut rehasher: hash_t = 718841 as hash_t;
#[inline]
unsafe extern "C" fn hash_by_power(mut p: o_key_t, mut power_0: hash_t) -> hash_t {
    let mut res: hash_t = 0 as hash_t;
    while *p != 0 {
        let fresh0 = p;
        p = p.offset(1);
        res = res.wrapping_mul(power_0).wrapping_add(*fresh0 as hash_t);
    }
    return res;
}
#[inline]
unsafe extern "C" fn hash(mut p: o_key_t) -> hash_t {
    return hash_by_power(p, power);
}
#[inline]
unsafe extern "C" fn compare_keys(
    mut k1: o_key_t,
    mut k2: o_key_t,
) -> ::core::ffi::c_int {
    return strcmp(k1 as *const ::core::ffi::c_char, k2 as *const ::core::ffi::c_char);
}
#[inline]
unsafe extern "C" fn rehash(mut h: hash_t) -> hash_t {
    return h.wrapping_add(rehasher);
}
pub const OPEN_HASH_LOG: ::core::ffi::c_int = 2 as ::core::ffi::c_int;
static mut load_factor: ::core::ffi::c_float = 0.6f32;
static mut eps: ::core::ffi::c_float = 1e-3f32;
#[inline]
unsafe extern "C" fn allocate_arr(mut size: ::core::ffi::c_uint) -> *mut open_entry {
    insert_log(
        OPEN_HASH_LOG as ::core::ffi::c_uint,
        1 as ::core::ffi::c_uint,
        b"Allocating new array for a table with size = %u.\0" as *const u8
            as *const ::core::ffi::c_char,
        size,
    );
    let mut arr: *mut open_entry = 0 as *mut open_entry;
    let arr_size: ::core::ffi::c_uint = (::core::mem::size_of::<open_entry>() as usize)
        .wrapping_mul(size as usize) as ::core::ffi::c_uint;
    arr = malloc(arr_size as size_t) as *mut open_entry;
    memset(arr as *mut ::core::ffi::c_void, 0 as ::core::ffi::c_int, arr_size as size_t);
    return arr;
}
#[no_mangle]
pub unsafe extern "C" fn create_open_hash_table(
    mut initial_size: ::core::ffi::c_uint,
) -> *mut open_hash_table {
    insert_log(
        OPEN_HASH_LOG as ::core::ffi::c_uint,
        5 as ::core::ffi::c_uint,
        b"Creating a new table with max size = %u.\0" as *const u8
            as *const ::core::ffi::c_char,
        initial_size,
    );
    if !(initial_size != 0 as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"create_open_hash_table\0")
                .as_ptr(),
            b"openhash.c\0" as *const u8 as *const ::core::ffi::c_char,
            37 as ::core::ffi::c_int,
            b"initial_size != 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(initial_size != power && initial_size != rehasher) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"create_open_hash_table\0")
                .as_ptr(),
            b"openhash.c\0" as *const u8 as *const ::core::ffi::c_char,
            38 as ::core::ffi::c_int,
            b"initial_size != power && initial_size != rehasher\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut ret: *mut open_hash_table = malloc(
        ::core::mem::size_of::<open_hash_table>() as size_t,
    ) as *mut open_hash_table;
    (*ret).cur_size = 0 as ::core::ffi::c_uint;
    (*ret).max_size = initial_size;
    (*ret).arr = allocate_arr(initial_size);
    return ret;
}
#[inline]
unsafe extern "C" fn query(
    mut key: o_key_t,
    mut table: *const open_hash_table,
) -> *mut open_entry {
    insert_log(
        OPEN_HASH_LOG as ::core::ffi::c_uint,
        1 as ::core::ffi::c_uint,
        b"Query in an with key = %s.\0" as *const u8 as *const ::core::ffi::c_char,
        key,
    );
    if !(key != empty_key) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 6], [::core::ffi::c_char; 6]>(*b"query\0")
                .as_ptr(),
            b"openhash.c\0" as *const u8 as *const ::core::ffi::c_char,
            51 as ::core::ffi::c_int,
            b"key != empty_key\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut h: hash_t = 0;
    h = hash(key);
    loop {
        insert_log(
            OPEN_HASH_LOG as ::core::ffi::c_uint,
            0 as ::core::ffi::c_uint,
            b"Trying a cell with hash = %u(%u).\0" as *const u8
                as *const ::core::ffi::c_char,
            (h as ::core::ffi::c_uint).wrapping_rem((*table).max_size),
            h,
        );
        let mut entry: *mut open_entry = &mut *(*table)
            .arr
            .offset((h as ::core::ffi::c_uint).wrapping_rem((*table).max_size) as isize)
            as *mut open_entry;
        let cur_key: o_key_t = (*entry).key;
        if cur_key == empty_key || compare_keys(cur_key, key) == 0 as ::core::ffi::c_int
        {
            insert_log(
                OPEN_HASH_LOG as ::core::ffi::c_uint,
                0 as ::core::ffi::c_uint,
                b"The cell is empty!\0" as *const u8 as *const ::core::ffi::c_char,
            );
            return entry;
        }
        insert_log(
            OPEN_HASH_LOG as ::core::ffi::c_uint,
            0 as ::core::ffi::c_uint,
            b"Collision! Cell: key = %s, data = %s.\0" as *const u8
                as *const ::core::ffi::c_char,
            (*entry).key,
            (*entry).data,
        );
        h = rehash(h);
    };
}
#[no_mangle]
pub unsafe extern "C" fn open_insert(
    mut key: o_key_t,
    mut data: o_data_t,
    mut table: *mut open_hash_table,
) {
    insert_log(
        OPEN_HASH_LOG as ::core::ffi::c_uint,
        4 as ::core::ffi::c_uint,
        b"Trying to insert a key = %s and data = %s.\0" as *const u8
            as *const ::core::ffi::c_char,
        key,
        data,
    );
    insert_log(
        OPEN_HASH_LOG as ::core::ffi::c_uint,
        4 as ::core::ffi::c_uint,
        b"Current size = %u, maximum size = %u.\0" as *const u8
            as *const ::core::ffi::c_char,
        (*table).cur_size,
        (*table).max_size,
    );
    if !(((*table).cur_size as ::core::ffi::c_float
        / (*table).max_size as ::core::ffi::c_float) < load_factor + eps)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"open_insert\0")
                .as_ptr(),
            b"openhash.c\0" as *const u8 as *const ::core::ffi::c_char,
            73 as ::core::ffi::c_int,
            b"((float)table->cur_size / table->max_size) < load_factor + eps\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    (*table).cur_size = (*table).cur_size.wrapping_add(1);
    if (*table).cur_size as ::core::ffi::c_float
        / (*table).max_size as ::core::ffi::c_float > load_factor
    {
        (*table).max_size = (*table).max_size.wrapping_mul(2 as ::core::ffi::c_uint);
        insert_log(
            OPEN_HASH_LOG as ::core::ffi::c_uint,
            4 as ::core::ffi::c_uint,
            b"Table's density in above the load factor. New max size is %u.\0"
                as *const u8 as *const ::core::ffi::c_char,
            (*table).max_size,
        );
        let mut old_arr: *mut open_entry = (*table).arr;
        (*table).arr = allocate_arr((*table).max_size);
        let mut h: hash_t = 0 as hash_t;
        while h < (*table).max_size.wrapping_div(2 as ::core::ffi::c_uint) {
            let cur_key: o_key_t = (*old_arr.offset(h as isize)).key;
            if cur_key != empty_key {
                *query(cur_key, table) = *old_arr.offset(h as isize);
            }
            h = h.wrapping_add(1);
        }
        free(old_arr as *mut ::core::ffi::c_void);
    }
    let mut cell: *mut open_entry = query(key, table);
    if !((*cell).key == empty_key) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"open_insert\0")
                .as_ptr(),
            b"openhash.c\0" as *const u8 as *const ::core::ffi::c_char,
            95 as ::core::ffi::c_int,
            b"cell->key == empty_key\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    insert_log(
        OPEN_HASH_LOG as ::core::ffi::c_uint,
        4 as ::core::ffi::c_uint,
        b"Inserting key = %s, data = %s. Current size = %u, maximum size = %u.\0"
            as *const u8 as *const ::core::ffi::c_char,
        key,
        data,
        (*table).cur_size,
        (*table).max_size,
    );
    (*cell).key = key;
    (*cell).data = data;
}
#[no_mangle]
pub unsafe extern "C" fn open_find(
    mut key: o_key_t,
    mut table: *const open_hash_table,
) -> o_data_t {
    insert_log(
        OPEN_HASH_LOG as ::core::ffi::c_uint,
        2 as ::core::ffi::c_uint,
        b"Looking for a key = %s.\0" as *const u8 as *const ::core::ffi::c_char,
        key,
    );
    let mut cell: *mut open_entry = query(key, table);
    if !((*cell).key != empty_key) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"open_find\0")
                .as_ptr(),
            b"openhash.c\0" as *const u8 as *const ::core::ffi::c_char,
            107 as ::core::ffi::c_int,
            b"cell->key != empty_key\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    insert_log(
        OPEN_HASH_LOG as ::core::ffi::c_uint,
        2 as ::core::ffi::c_uint,
        b"Returning data = %s.\0" as *const u8 as *const ::core::ffi::c_char,
        (*cell).data,
    );
    return (*cell).data;
}
#[no_mangle]
pub unsafe extern "C" fn free_open_hash_table(mut table: *mut open_hash_table) {
    insert_log(
        OPEN_HASH_LOG as ::core::ffi::c_uint,
        3 as ::core::ffi::c_uint,
        b"Deleting a table with current size = %u, maximum size = %u.\0" as *const u8
            as *const ::core::ffi::c_char,
        (*table).cur_size,
        (*table).max_size,
    );
    free((*table).arr as *mut ::core::ffi::c_void);
    free(table as *mut ::core::ffi::c_void);
}
