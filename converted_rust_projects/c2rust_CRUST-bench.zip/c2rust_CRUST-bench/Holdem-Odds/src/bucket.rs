#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type Suit = ::core::ffi::c_uint;
pub const Spade: Suit = 4;
pub const Heart: Suit = 3;
pub const Diamond: Suit = 2;
pub const Club: Suit = 1;
pub const InvalidSuit: Suit = 0;
pub type Rank = ::core::ffi::c_uint;
pub const Ace: Rank = 13;
pub const King: Rank = 12;
pub const Queen: Rank = 11;
pub const Jack: Rank = 10;
pub const Ten: Rank = 9;
pub const Nine: Rank = 8;
pub const Eight: Rank = 7;
pub const Seven: Rank = 6;
pub const Six: Rank = 5;
pub const Five: Rank = 4;
pub const Four: Rank = 3;
pub const Trey: Rank = 2;
pub const Deuce: Rank = 1;
pub const InvalidRank: Rank = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Card {
    pub rank: Rank,
    pub suit: Suit,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Bucket {
    pub cards: [Card; 4],
    pub count: size_t,
}
#[no_mangle]
pub unsafe extern "C" fn BucketAdd(mut bucket: *mut Bucket, mut card: *const Card) {
    if (*bucket).count < 4 as size_t {
        (*bucket).cards[(*bucket).count as usize] = *card;
        (*bucket).count = (*bucket).count.wrapping_add(1);
    }
}
