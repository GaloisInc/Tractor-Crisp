#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type Suit = ::core::ffi::c_uint;
pub const Spade: Suit = 4;
pub const Heart: Suit = 3;
pub const Diamond: Suit = 2;
pub const Club: Suit = 1;
pub const InvalidSuit: Suit = 0;
pub type Rank = ::core::ffi::c_uint;
pub const Ace: Rank = 13;
pub const King: Rank = 12;
pub const Queen: Rank = 11;
pub const Jack: Rank = 10;
pub const Ten: Rank = 9;
pub const Nine: Rank = 8;
pub const Eight: Rank = 7;
pub const Seven: Rank = 6;
pub const Six: Rank = 5;
pub const Five: Rank = 4;
pub const Four: Rank = 3;
pub const Trey: Rank = 2;
pub const Deuce: Rank = 1;
pub const InvalidRank: Rank = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Card {
    pub rank: Rank,
    pub suit: Suit,
}
pub const RANKS_PER_DECK: ::core::ffi::c_int = 13 as ::core::ffi::c_int;
pub const SUITS_PER_DECK: ::core::ffi::c_int = 4 as ::core::ffi::c_int;
pub const RANK_CHARS: [::core::ffi::c_char; 14] = unsafe {
    ::core::mem::transmute::<[u8; 14], [::core::ffi::c_char; 14]>(*b"23456789TJQKA\0")
};
pub const SUIT_CHARS: [::core::ffi::c_char; 5] = unsafe {
    ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"cdhs\0")
};
#[no_mangle]
pub static mut INVALID_CARD: Card = {
    let mut init = Card {
        rank: InvalidRank,
        suit: InvalidSuit,
    };
    init
};
#[no_mangle]
pub unsafe extern "C" fn indexOf(
    mut c: ::core::ffi::c_char,
    mut chars: *const ::core::ffi::c_char,
    mut N: size_t,
) -> size_t {
    let mut i: size_t = 0 as size_t;
    while i < N {
        if *chars.offset(i as isize) as ::core::ffi::c_int == c as ::core::ffi::c_int {
            return i.wrapping_add(1 as size_t);
        }
        i = i.wrapping_add(1);
    }
    return 0 as size_t;
}
#[no_mangle]
pub unsafe extern "C" fn CharToRank(mut r: ::core::ffi::c_char) -> Rank {
    return indexOf(r, RANK_CHARS.as_ptr(), RANKS_PER_DECK as size_t) as Rank;
}
#[no_mangle]
pub unsafe extern "C" fn CharToSuit(mut s: ::core::ffi::c_char) -> Suit {
    return indexOf(s, SUIT_CHARS.as_ptr(), SUITS_PER_DECK as size_t) as Suit;
}
#[no_mangle]
pub unsafe extern "C" fn NewCard(mut rank: Rank, mut suit: Suit) -> Card {
    let mut card: Card = {
        let mut init = Card { rank: rank, suit: suit };
        init
    };
    if CardIsValid(&mut card) { return card } else { return INVALID_CARD };
}
#[no_mangle]
pub unsafe extern "C" fn NewCardFromChars(
    mut r: ::core::ffi::c_char,
    mut s: ::core::ffi::c_char,
) -> Card {
    let mut rank: Rank = CharToRank(r);
    let mut suit: Suit = CharToSuit(s);
    return NewCard(rank, suit);
}
#[no_mangle]
pub unsafe extern "C" fn NewCardFromString(mut s: *mut ::core::ffi::c_char) -> Card {
    if strlen(s) != 2 as size_t {
        return INVALID_CARD
    } else {
        return NewCardFromChars(
            *s.offset(0 as ::core::ffi::c_int as isize),
            *s.offset(1 as ::core::ffi::c_int as isize),
        )
    };
}
#[no_mangle]
pub unsafe extern "C" fn CardCompare(
    mut a: *const Card,
    mut b: *const Card,
) -> ::core::ffi::c_int {
    return ((*a).rank as ::core::ffi::c_uint)
        .wrapping_sub((*b).rank as ::core::ffi::c_uint) as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn CardEqual(mut a: *const Card, mut b: *const Card) -> bool {
    return (*a).rank as ::core::ffi::c_uint == (*b).rank as ::core::ffi::c_uint
        && (*a).suit as ::core::ffi::c_uint == (*b).suit as ::core::ffi::c_uint;
}
#[no_mangle]
pub unsafe extern "C" fn CardToString(
    mut out: *mut ::core::ffi::c_char,
    mut c: *const Card,
) {
    if !CardIsValid(c) {
        *out.offset(0 as ::core::ffi::c_int as isize) = '-' as i32
            as ::core::ffi::c_char;
        *out.offset(1 as ::core::ffi::c_int as isize) = '-' as i32
            as ::core::ffi::c_char;
    } else {
        *out.offset(0 as ::core::ffi::c_int as isize) = RANK_CHARS[((*c).rank
            as ::core::ffi::c_int - 1 as ::core::ffi::c_int) as usize];
        *out.offset(1 as ::core::ffi::c_int as isize) = SUIT_CHARS[((*c).suit
            as ::core::ffi::c_int - 1 as ::core::ffi::c_int) as usize];
    }
    *out.offset(2 as ::core::ffi::c_int as isize) = '\0' as i32 as ::core::ffi::c_char;
}
#[no_mangle]
pub unsafe extern "C" fn CardIsValid(mut c: *const Card) -> bool {
    return (*c).rank as ::core::ffi::c_uint
        >= Deuce as ::core::ffi::c_int as ::core::ffi::c_uint
        && (*c).rank as ::core::ffi::c_uint
            <= Ace as ::core::ffi::c_int as ::core::ffi::c_uint
        && (*c).suit as ::core::ffi::c_uint
            >= Club as ::core::ffi::c_int as ::core::ffi::c_uint
        && (*c).suit as ::core::ffi::c_uint
            <= Spade as ::core::ffi::c_int as ::core::ffi::c_uint;
}
#[no_mangle]
pub unsafe extern "C" fn CardSwap(mut a: *mut Card, mut b: *mut Card) {
    let mut t: Card = *a;
    *a = *b;
    *b = t;
}
