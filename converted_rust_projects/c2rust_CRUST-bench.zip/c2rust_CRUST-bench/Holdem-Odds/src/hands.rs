#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn CardIsValid(_: *const Card) -> bool;
    fn CardCompare(_: *const Card, _: *const Card) -> ::core::ffi::c_int;
    fn BucketAdd(_: *mut Bucket, _: *const Card);
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type Suit = ::core::ffi::c_uint;
pub const Spade: Suit = 4;
pub const Heart: Suit = 3;
pub const Diamond: Suit = 2;
pub const Club: Suit = 1;
pub const InvalidSuit: Suit = 0;
pub type Rank = ::core::ffi::c_uint;
pub const Ace: Rank = 13;
pub const King: Rank = 12;
pub const Queen: Rank = 11;
pub const Jack: Rank = 10;
pub const Ten: Rank = 9;
pub const Nine: Rank = 8;
pub const Eight: Rank = 7;
pub const Seven: Rank = 6;
pub const Six: Rank = 5;
pub const Five: Rank = 4;
pub const Four: Rank = 3;
pub const Trey: Rank = 2;
pub const Deuce: Rank = 1;
pub const InvalidRank: Rank = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Card {
    pub rank: Rank,
    pub suit: Suit,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Bucket {
    pub cards: [Card; 4],
    pub count: size_t,
}
pub type HandType = ::core::ffi::c_uint;
pub const StraightFlush: HandType = 11;
pub const WheelFlush: HandType = 10;
pub const FourOfAKind: HandType = 9;
pub const FullHouse: HandType = 8;
pub const Flush: HandType = 7;
pub const Straight: HandType = 6;
pub const Wheel: HandType = 5;
pub const ThreeOfAKind: HandType = 4;
pub const TwoPair: HandType = 3;
pub const Pair: HandType = 2;
pub const HighCard: HandType = 1;
pub const InvalidHand: HandType = 0;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const RANKS_PER_DECK: ::core::ffi::c_int = 13 as ::core::ffi::c_int;
pub const HAND_LENGTH: ::core::ffi::c_int = 5 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn HandCompare(
    mut hand1: *mut Card,
    mut hand2: *mut Card,
) -> ::core::ffi::c_int {
    let mut hand1_type: HandType = HandClassify(hand1);
    let mut hand2_type: HandType = HandClassify(hand2);
    let mut diff: ::core::ffi::c_int = (hand1_type as ::core::ffi::c_uint)
        .wrapping_sub(hand2_type as ::core::ffi::c_uint) as ::core::ffi::c_int;
    if diff != 0 as ::core::ffi::c_int {
        return diff;
    }
    let mut i: size_t = 0 as size_t;
    while i < HAND_LENGTH as size_t {
        let mut cmp: ::core::ffi::c_int = CardCompare(
            &mut *hand1.offset(i as isize),
            &mut *hand2.offset(i as isize),
        );
        if cmp != 0 as ::core::ffi::c_int {
            return cmp;
        }
        i = i.wrapping_add(1);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn HandSort(mut hand: *mut Card) {
    let mut buckets: [Bucket; 13] = [
        {
            let mut init = Bucket {
                cards: [
                    {
                        let mut init = Card {
                            rank: InvalidRank,
                            suit: InvalidSuit,
                        };
                        init
                    },
                    Card {
                        rank: InvalidRank,
                        suit: InvalidSuit,
                    },
                    Card {
                        rank: InvalidRank,
                        suit: InvalidSuit,
                    },
                    Card {
                        rank: InvalidRank,
                        suit: InvalidSuit,
                    },
                ],
                count: 0 as size_t,
            };
            init
        },
        Bucket {
            cards: [Card {
                rank: InvalidRank,
                suit: InvalidSuit,
            }; 4],
            count: 0,
        },
        Bucket {
            cards: [Card {
                rank: InvalidRank,
                suit: InvalidSuit,
            }; 4],
            count: 0,
        },
        Bucket {
            cards: [Card {
                rank: InvalidRank,
                suit: InvalidSuit,
            }; 4],
            count: 0,
        },
        Bucket {
            cards: [Card {
                rank: InvalidRank,
                suit: InvalidSuit,
            }; 4],
            count: 0,
        },
        Bucket {
            cards: [Card {
                rank: InvalidRank,
                suit: InvalidSuit,
            }; 4],
            count: 0,
        },
        Bucket {
            cards: [Card {
                rank: InvalidRank,
                suit: InvalidSuit,
            }; 4],
            count: 0,
        },
        Bucket {
            cards: [Card {
                rank: InvalidRank,
                suit: InvalidSuit,
            }; 4],
            count: 0,
        },
        Bucket {
            cards: [Card {
                rank: InvalidRank,
                suit: InvalidSuit,
            }; 4],
            count: 0,
        },
        Bucket {
            cards: [Card {
                rank: InvalidRank,
                suit: InvalidSuit,
            }; 4],
            count: 0,
        },
        Bucket {
            cards: [Card {
                rank: InvalidRank,
                suit: InvalidSuit,
            }; 4],
            count: 0,
        },
        Bucket {
            cards: [Card {
                rank: InvalidRank,
                suit: InvalidSuit,
            }; 4],
            count: 0,
        },
        Bucket {
            cards: [Card {
                rank: InvalidRank,
                suit: InvalidSuit,
            }; 4],
            count: 0,
        },
    ];
    let mut i: size_t = 0 as size_t;
    while i < HAND_LENGTH as size_t {
        let mut bucket_index: size_t = ((*hand.offset(i as isize)).rank
            as ::core::ffi::c_uint)
            .wrapping_sub(1 as ::core::ffi::c_uint) as size_t;
        BucketAdd(
            &mut *buckets.as_mut_ptr().offset(bucket_index as isize),
            &mut *hand.offset(i as isize),
        );
        i = i.wrapping_add(1);
    }
    let mut index: size_t = 0 as size_t;
    let mut count: size_t = 4 as size_t;
    while count > 0 as size_t {
        let mut j: size_t = (RANKS_PER_DECK - 1 as ::core::ffi::c_int) as size_t;
        while j != -(1 as ::core::ffi::c_int) as size_t {
            if buckets[j as usize].count == count {
                memcpy(
                    &mut *hand.offset(index as isize) as *mut Card
                        as *mut ::core::ffi::c_void,
                    &mut (*buckets.as_mut_ptr().offset(j as isize)).cards
                        as *mut [Card; 4] as *const ::core::ffi::c_void,
                    (::core::mem::size_of::<Card>() as size_t).wrapping_mul(count),
                );
                index = index.wrapping_add(count);
            }
            j = j.wrapping_sub(1);
        }
        count = count.wrapping_sub(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn HandClassify(mut cards: *mut Card) -> HandType {
    if HandIsFlush(cards) {
        if HandIsStraight(cards) {
            return StraightFlush;
        }
        if HandIsWheel(cards) {
            return WheelFlush;
        }
        return Flush;
    } else {
        if HandIsFourOfAKind(cards) {
            return FourOfAKind;
        }
        if HandIsFullHouse(cards) {
            return FullHouse;
        }
        if HandIsStraight(cards) {
            return Straight;
        }
        if HandIsWheel(cards) {
            return Wheel;
        }
        if HandIsThreeOfAKind(cards) {
            return ThreeOfAKind;
        }
        if HandIsTwoPair(cards) {
            return TwoPair;
        }
        if HandIsPair(cards) {
            return Pair;
        }
        return HighCard;
    };
}
#[no_mangle]
pub unsafe extern "C" fn HandIsValid(mut cards: *const Card) -> bool {
    let mut i: size_t = 0 as size_t;
    while i < HAND_LENGTH as size_t {
        if !CardIsValid(&*cards.offset(i as isize)) {
            return false_0 != 0;
        }
        i = i.wrapping_add(1);
    }
    return true_0 != 0;
}
unsafe extern "C" fn HandIsFourOfAKind(mut cards: *const Card) -> bool {
    return (*cards.offset(0 as ::core::ffi::c_int as isize)).rank as ::core::ffi::c_uint
        == (*cards.offset(3 as ::core::ffi::c_int as isize)).rank as ::core::ffi::c_uint;
}
unsafe extern "C" fn HandIsFullHouse(mut cards: *const Card) -> bool {
    return (*cards.offset(0 as ::core::ffi::c_int as isize)).rank as ::core::ffi::c_uint
        == (*cards.offset(2 as ::core::ffi::c_int as isize)).rank as ::core::ffi::c_uint
        && (*cards.offset(3 as ::core::ffi::c_int as isize)).rank as ::core::ffi::c_uint
            == (*cards.offset(4 as ::core::ffi::c_int as isize)).rank
                as ::core::ffi::c_uint;
}
unsafe extern "C" fn HandIsFlush(mut cards: *const Card) -> bool {
    let mut i: size_t = 1 as size_t;
    while i < HAND_LENGTH as size_t {
        if (*cards.offset(i as isize)).suit as ::core::ffi::c_uint
            != (*cards.offset(0 as ::core::ffi::c_int as isize)).suit
                as ::core::ffi::c_uint
        {
            return false_0 != 0;
        }
        i = i.wrapping_add(1);
    }
    return true_0 != 0;
}
unsafe extern "C" fn HandIsStraight(mut cards: *const Card) -> bool {
    return (*cards.offset(0 as ::core::ffi::c_int as isize)).rank as ::core::ffi::c_uint
        == ((*cards.offset(1 as ::core::ffi::c_int as isize)).rank
            as ::core::ffi::c_uint)
            .wrapping_add(1 as ::core::ffi::c_uint)
        && (*cards.offset(0 as ::core::ffi::c_int as isize)).rank as ::core::ffi::c_uint
            == ((*cards.offset(4 as ::core::ffi::c_int as isize)).rank
                as ::core::ffi::c_uint)
                .wrapping_add(4 as ::core::ffi::c_uint);
}
unsafe extern "C" fn HandIsWheel(mut cards: *const Card) -> bool {
    return (*cards.offset(0 as ::core::ffi::c_int as isize)).rank as ::core::ffi::c_uint
        == Ace as ::core::ffi::c_int as ::core::ffi::c_uint
        && (*cards.offset(1 as ::core::ffi::c_int as isize)).rank as ::core::ffi::c_uint
            == Five as ::core::ffi::c_int as ::core::ffi::c_uint;
}
unsafe extern "C" fn HandIsThreeOfAKind(mut cards: *const Card) -> bool {
    return (*cards.offset(0 as ::core::ffi::c_int as isize)).rank as ::core::ffi::c_uint
        == (*cards.offset(2 as ::core::ffi::c_int as isize)).rank as ::core::ffi::c_uint;
}
unsafe extern "C" fn HandIsTwoPair(mut cards: *const Card) -> bool {
    return (*cards.offset(2 as ::core::ffi::c_int as isize)).rank as ::core::ffi::c_uint
        == (*cards.offset(3 as ::core::ffi::c_int as isize)).rank as ::core::ffi::c_uint;
}
unsafe extern "C" fn HandIsPair(mut cards: *const Card) -> bool {
    return (*cards.offset(0 as ::core::ffi::c_int as isize)).rank as ::core::ffi::c_uint
        == (*cards.offset(1 as ::core::ffi::c_int as isize)).rank as ::core::ffi::c_uint;
}
