#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn exit(_: ::core::ffi::c_int) -> !;
    fn srand(_: ::core::ffi::c_uint);
    fn time(_: *mut time_t) -> time_t;
    fn NewCardFromString(_: *mut ::core::ffi::c_char) -> Card;
    fn DeckShuffle(_: *mut Card, _: size_t, _: size_t);
    fn NewDeck(_: *mut Card, _: *const Card, _: size_t);
    fn HandCompare(_: *mut Card, _: *mut Card) -> ::core::ffi::c_int;
    fn HandSort(_: *mut Card);
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_time_t = ::core::ffi::c_long;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type time_t = __darwin_time_t;
pub type Suit = ::core::ffi::c_uint;
pub const Spade: Suit = 4;
pub const Heart: Suit = 3;
pub const Diamond: Suit = 2;
pub const Club: Suit = 1;
pub const InvalidSuit: Suit = 0;
pub type Rank = ::core::ffi::c_uint;
pub const Ace: Rank = 13;
pub const King: Rank = 12;
pub const Queen: Rank = 11;
pub const Jack: Rank = 10;
pub const Ten: Rank = 9;
pub const Nine: Rank = 8;
pub const Eight: Rank = 7;
pub const Seven: Rank = 6;
pub const Six: Rank = 5;
pub const Five: Rank = 4;
pub const Four: Rank = 3;
pub const Trey: Rank = 2;
pub const Deuce: Rank = 1;
pub const InvalidRank: Rank = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Card {
    pub rank: Rank,
    pub suit: Suit,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const ITERATIONS: ::core::ffi::c_int = 2000000 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn usage(mut name: *const ::core::ffi::c_char) {
    fprintf(
        __stderrp,
        b"Usage: %s <c1> <c2> <c3> <c4>\n\0" as *const u8 as *const ::core::ffi::c_char,
        name,
    );
    exit(1 as ::core::ffi::c_int);
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    if argc != 5 as ::core::ffi::c_int {
        usage(*argv.offset(0 as ::core::ffi::c_int as isize));
    }
    srand(time(0 as *mut time_t) as ::core::ffi::c_uint);
    let mut deck: [Card; 48] = [Card {
        rank: InvalidRank,
        suit: InvalidSuit,
    }; 48];
    let mut cards: [Card; 4] = [Card {
        rank: InvalidRank,
        suit: InvalidSuit,
    }; 4];
    let mut hand1: [Card; 5] = [Card {
        rank: InvalidRank,
        suit: InvalidSuit,
    }; 5];
    let mut hand2: [Card; 5] = [Card {
        rank: InvalidRank,
        suit: InvalidSuit,
    }; 5];
    let mut results: [size_t; 3] = [
        0 as ::core::ffi::c_int as size_t,
        0 as ::core::ffi::c_int as size_t,
        0 as ::core::ffi::c_int as size_t,
    ];
    let mut i: size_t = 0 as size_t;
    while i < 4 as size_t {
        cards[i as usize] = NewCardFromString(
            *argv.offset(i.wrapping_add(1 as size_t) as isize),
        );
        i = i.wrapping_add(1);
    }
    NewDeck(deck.as_mut_ptr(), cards.as_mut_ptr(), 4 as size_t);
    let mut i_0: size_t = 0 as size_t;
    while i_0 < ITERATIONS as size_t {
        DeckShuffle(deck.as_mut_ptr(), 3 as size_t, 48 as size_t);
        hand1[0 as ::core::ffi::c_int as usize] = cards[0 as ::core::ffi::c_int
            as usize];
        hand1[1 as ::core::ffi::c_int as usize] = cards[1 as ::core::ffi::c_int
            as usize];
        hand2[0 as ::core::ffi::c_int as usize] = cards[2 as ::core::ffi::c_int
            as usize];
        hand2[1 as ::core::ffi::c_int as usize] = cards[3 as ::core::ffi::c_int
            as usize];
        let mut j: size_t = 0 as size_t;
        while j < 3 as size_t {
            hand1[(2 as size_t).wrapping_add(j) as usize] = deck[j as usize];
            hand2[(2 as size_t).wrapping_add(j) as usize] = deck[j as usize];
            j = j.wrapping_add(1);
        }
        HandSort(hand1.as_mut_ptr());
        HandSort(hand2.as_mut_ptr());
        let mut c: ::core::ffi::c_int = HandCompare(
            hand1.as_mut_ptr(),
            hand2.as_mut_ptr(),
        );
        if c > 0 as ::core::ffi::c_int {
            results[0 as ::core::ffi::c_int as usize] = results[0 as ::core::ffi::c_int
                    as usize]
                .wrapping_add(1);
        } else if c == 0 as ::core::ffi::c_int {
            results[1 as ::core::ffi::c_int as usize] = results[1 as ::core::ffi::c_int
                    as usize]
                .wrapping_add(1);
        } else if c < 0 as ::core::ffi::c_int {
            results[2 as ::core::ffi::c_int as usize] = results[2 as ::core::ffi::c_int
                    as usize]
                .wrapping_add(1);
        }
        i_0 = i_0.wrapping_add(1);
    }
    printf(
        b"WIN: %.2f\tTIE: %.2f\tLOSS: %.2f\n\0" as *const u8
            as *const ::core::ffi::c_char,
        results[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_double
            / ITERATIONS as ::core::ffi::c_double,
        results[1 as ::core::ffi::c_int as usize] as ::core::ffi::c_double
            / ITERATIONS as ::core::ffi::c_double,
        results[2 as ::core::ffi::c_int as usize] as ::core::ffi::c_double
            / ITERATIONS as ::core::ffi::c_double,
    );
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
