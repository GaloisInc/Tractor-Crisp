#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(linkage)]
extern "C" {
    static mut _DefaultRuneLocale: _RuneLocale;
    fn __maskrune(_: __darwin_ct_rune_t, _: ::core::ffi::c_ulong) -> ::core::ffi::c_int;
    fn __toupper(_: __darwin_ct_rune_t) -> __darwin_ct_rune_t;
    fn __tolower(_: __darwin_ct_rune_t) -> __darwin_ct_rune_t;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn sprintf(
        _: *mut ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn realloc(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn abort() -> !;
    fn memcmp(
        __s1: *const ::core::ffi::c_void,
        __s2: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> ::core::ffi::c_int;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strchr(
        __s: *const ::core::ffi::c_char,
        __c: ::core::ffi::c_int,
    ) -> *mut ::core::ffi::c_char;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strcpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strncmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> ::core::ffi::c_int;
}
pub type __uint32_t = u32;
pub type __darwin_ct_rune_t = ::core::ffi::c_int;
pub type __darwin_ptrdiff_t = isize;
pub type __darwin_size_t = usize;
pub type __darwin_wchar_t = ::libc::wchar_t;
pub type __darwin_rune_t = __darwin_wchar_t;
pub type ptrdiff_t = __darwin_ptrdiff_t;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct dstate {
    pub transitions: [*mut dstate; 256],
    pub accepting: bool,
    pub terminating: bool,
    pub id: ::core::ffi::c_int,
    pub next: *mut dstate,
    pub bitset: [uint8_t; 0],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct nfa {
    pub initial: *mut nstate,
    pub final_0: *mut nstate,
    pub complemented: bool,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct nstate {
    pub label: symset_t,
    pub target: *mut nstate,
    pub epsilon0: *mut nstate,
    pub epsilon1: *mut nstate,
    pub next: *mut nstate,
    pub id: ::core::ffi::c_int,
}
pub type symset_t = [uint8_t; 32];
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneLocale {
    pub __magic: [::core::ffi::c_char; 8],
    pub __encoding: [::core::ffi::c_char; 32],
    pub __sgetrune: Option<
        unsafe extern "C" fn(
            *const ::core::ffi::c_char,
            __darwin_size_t,
            *mut *const ::core::ffi::c_char,
        ) -> __darwin_rune_t,
    >,
    pub __sputrune: Option<
        unsafe extern "C" fn(
            __darwin_rune_t,
            *mut ::core::ffi::c_char,
            __darwin_size_t,
            *mut *mut ::core::ffi::c_char,
        ) -> ::core::ffi::c_int,
    >,
    pub __invalid_rune: __darwin_rune_t,
    pub __runetype: [__uint32_t; 256],
    pub __maplower: [__darwin_rune_t; 256],
    pub __mapupper: [__darwin_rune_t; 256],
    pub __runetype_ext: _RuneRange,
    pub __maplower_ext: _RuneRange,
    pub __mapupper_ext: _RuneRange,
    pub __variable: *mut ::core::ffi::c_void,
    pub __variable_len: ::core::ffi::c_int,
    pub __ncharclasses: ::core::ffi::c_int,
    pub __charclasses: *mut _RuneCharClass,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneCharClass {
    pub __name: [::core::ffi::c_char; 14],
    pub __mask: __uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneRange {
    pub __nranges: ::core::ffi::c_int,
    pub __ranges: *mut _RuneEntry,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneEntry {
    pub __min: __darwin_rune_t,
    pub __max: __darwin_rune_t,
    pub __map: __darwin_rune_t,
    pub __types: *mut __uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct arrow {
    pub label: *mut ::core::ffi::c_char,
    pub prec: prec,
}
pub type prec = ::core::ffi::c_uint;
pub const SYMSET: prec = 3;
pub const QUANT: prec = 2;
pub const CONCAT: prec = 1;
pub const ALT: prec = 0;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const _CACHED_RUNES: ::core::ffi::c_int = (1 as ::core::ffi::c_int)
    << 8 as ::core::ffi::c_int;
pub const _CTYPE_A: ::core::ffi::c_long = 0x100 as ::core::ffi::c_long;
pub const _CTYPE_D: ::core::ffi::c_long = 0x400 as ::core::ffi::c_long;
pub const _CTYPE_S: ::core::ffi::c_long = 0x4000 as ::core::ffi::c_long;
pub const _CTYPE_X: ::core::ffi::c_long = 0x10000 as ::core::ffi::c_long;
pub const _CTYPE_R: ::core::ffi::c_long = 0x40000 as ::core::ffi::c_long;
#[inline]
unsafe extern "C" fn isascii(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return (_c & !(0x7f as ::core::ffi::c_int) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn __istype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> ::core::ffi::c_int {
    return if isascii(_c as ::core::ffi::c_int) != 0 {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    } else {
        (__maskrune(_c, _f) != 0) as ::core::ffi::c_int
    };
}
#[inline]
unsafe extern "C" fn __isctype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> __darwin_ct_rune_t {
    return if _c < 0 as ::core::ffi::c_int || _c >= _CACHED_RUNES {
        0 as __darwin_ct_rune_t
    } else {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    };
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isalnum(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(
        _c as __darwin_ct_rune_t,
        (_CTYPE_A | _CTYPE_D) as ::core::ffi::c_ulong,
    );
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isdigit(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __isctype(_c as __darwin_ct_rune_t, _CTYPE_D as ::core::ffi::c_ulong)
        as ::core::ffi::c_int;
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isprint(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_R as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isspace(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_S as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isxdigit(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __isctype(_c as __darwin_ct_rune_t, _CTYPE_X as ::core::ffi::c_ulong)
        as ::core::ffi::c_int;
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn tolower(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __tolower(_c as __darwin_ct_rune_t) as ::core::ffi::c_int;
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn toupper(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __toupper(_c as __darwin_ct_rune_t) as ::core::ffi::c_int;
}
pub const UINT_MAX: ::core::ffi::c_uint = 0xffffffff as ::core::ffi::c_uint;
pub const INT_MAX: ::core::ffi::c_int = 2147483647 as ::core::ffi::c_int;
pub const METACHARS: [::core::ffi::c_char; 20] = unsafe {
    ::core::mem::transmute::<
        [u8; 20],
        [::core::ffi::c_char; 20],
    >(*b"\\.-^$*+?{}[]<>()|&~\0")
};
unsafe extern "C" fn bitset_get(
    mut bitset: *mut uint8_t,
    mut id: ::core::ffi::c_uint,
) -> bool {
    return *bitset.offset(id.wrapping_div(8 as ::core::ffi::c_uint) as isize)
        as ::core::ffi::c_int
        & (1 as ::core::ffi::c_int) << id.wrapping_rem(8 as ::core::ffi::c_uint) != 0;
}
unsafe extern "C" fn bitset_set(mut bitset: *mut uint8_t, mut id: ::core::ffi::c_uint) {
    let ref mut fresh23 = *bitset
        .offset(id.wrapping_div(8 as ::core::ffi::c_uint) as isize);
    *fresh23 = (*fresh23 as ::core::ffi::c_int
        | (1 as ::core::ffi::c_int) << id.wrapping_rem(8 as ::core::ffi::c_uint))
        as uint8_t;
}
unsafe extern "C" fn symset_fmt(mut symset: *mut uint8_t) -> *mut ::core::ffi::c_char {
    static mut buf: [::core::ffi::c_char; 1024] = [0; 1024];
    static mut nbuf: [::core::ffi::c_char; 1024] = [0; 1024];
    let mut bufp: *mut ::core::ffi::c_char = buf.as_mut_ptr();
    let mut nbufp: *mut ::core::ffi::c_char = nbuf.as_mut_ptr();
    let mut nsym: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut nnsym: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let fresh72 = nbufp;
    nbufp = nbufp.offset(1);
    *fresh72 = '^' as i32 as ::core::ffi::c_char;
    let fresh73 = nbufp;
    nbufp = nbufp.offset(1);
    *fresh73 = '[' as i32 as ::core::ffi::c_char;
    let fresh74 = bufp;
    bufp = bufp.offset(1);
    *fresh74 = *fresh73;
    let mut chr: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while chr < 256 as ::core::ffi::c_int {
        loop {
            if bitset_get(symset as *mut uint8_t, chr as ::core::ffi::c_uint)
                as ::core::ffi::c_int != 0
            {
                nsym += 1;
            } else {
                nnsym += 1;
            };
            let mut p: *mut *mut ::core::ffi::c_char = if bitset_get(
                symset as *mut uint8_t,
                chr as ::core::ffi::c_uint,
            ) as ::core::ffi::c_int != 0
            {
                &mut bufp
            } else {
                &mut nbufp
            };
            let mut is_metachar: bool = chr != 0
                && !strchr(METACHARS.as_ptr(), chr).is_null();
            if isprint(chr) == 0 && !is_metachar {
                *p = (*p)
                    .offset(
                        sprintf(
                            *p,
                            b"\\x%02hhx\0" as *const u8 as *const ::core::ffi::c_char,
                            chr,
                        ) as isize,
                    );
            } else {
                if is_metachar {
                    let fresh75 = *p;
                    *p = (*p).offset(1);
                    *fresh75 = '\\' as i32 as ::core::ffi::c_char;
                }
                let fresh76 = *p;
                *p = (*p).offset(1);
                *fresh76 = chr as ::core::ffi::c_char;
            }
            let mut start: ::core::ffi::c_int = chr;
            while chr < 255 as ::core::ffi::c_int
                && bitset_get(symset as *mut uint8_t, chr as ::core::ffi::c_uint)
                    as ::core::ffi::c_int
                    == bitset_get(
                        symset as *mut uint8_t,
                        (chr + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint,
                    ) as ::core::ffi::c_int
            {
                chr += 1;
            }
            if chr - start >= 2 as ::core::ffi::c_int {
                let fresh77 = *p;
                *p = (*p).offset(1);
                *fresh77 = '-' as i32 as ::core::ffi::c_char;
                if bitset_get(symset as *mut uint8_t, chr as ::core::ffi::c_uint)
                    as ::core::ffi::c_int != 0
                {
                    nsym -= 1;
                } else {
                    nnsym -= 1;
                };
            }
            if !(chr - start >= 1 as ::core::ffi::c_int) {
                break;
            }
        }
        chr += 1;
    }
    let fresh78 = nbufp;
    nbufp = nbufp.offset(1);
    *fresh78 = ']' as i32 as ::core::ffi::c_char;
    let fresh79 = bufp;
    bufp = bufp.offset(1);
    *fresh79 = *fresh78;
    let fresh80 = nbufp;
    nbufp = nbufp.offset(1);
    *fresh80 = '\0' as i32 as ::core::ffi::c_char;
    let fresh81 = bufp;
    bufp = bufp.offset(1);
    *fresh81 = *fresh80;
    if nnsym == 0 as ::core::ffi::c_int {
        return b"<>\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_char
    } else if nsym == 1 as ::core::ffi::c_int {
        *bufp.offset(-(2 as ::core::ffi::c_int) as isize) = '\0' as i32
            as ::core::ffi::c_char;
        return buf.as_mut_ptr().offset(1 as ::core::ffi::c_int as isize);
    } else if nnsym == 1 as ::core::ffi::c_int {
        *nbufp.offset(-(2 as ::core::ffi::c_int) as isize) = '\0' as i32
            as ::core::ffi::c_char;
        nbuf[1 as ::core::ffi::c_int as usize] = '^' as i32 as ::core::ffi::c_char;
        return nbuf.as_mut_ptr().offset(1 as ::core::ffi::c_int as isize);
    }
    return if (bufp.offset_from(buf.as_mut_ptr()) as ::core::ffi::c_long)
        < nbufp.offset_from(nbuf.as_mut_ptr()) as ::core::ffi::c_long
    {
        buf.as_mut_ptr()
    } else {
        nbuf.as_mut_ptr()
    };
}
unsafe extern "C" fn nstate_alloc() -> *mut nstate {
    let mut nstate: *mut nstate = malloc(::core::mem::size_of::<nstate>() as size_t)
        as *mut nstate;
    *nstate = {
        let mut init = nstate {
            label: [0; 32],
            target: 0 as *mut nstate,
            epsilon0: 0 as *mut nstate,
            epsilon1: 0 as *mut nstate,
            next: 0 as *mut nstate,
            id: -(1 as ::core::ffi::c_int),
        };
        init
    };
    return nstate;
}
#[no_mangle]
pub unsafe extern "C" fn nfa_free(mut nfa: nfa) {
    let mut next: *mut nstate = 0 as *mut nstate;
    let mut nstate: *mut nstate = nfa.initial as *mut nstate;
    while !nstate.is_null() {
        next = (*nstate).next;
        free(nstate as *mut ::core::ffi::c_void);
        nstate = next;
    }
}
unsafe extern "C" fn nfa_get_size(mut nfa: nfa) -> ::core::ffi::c_int {
    let mut nfa_size: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut nstate: *mut nstate = nfa.initial as *mut nstate;
    while !nstate.is_null() {
        let fresh30 = nfa_size;
        nfa_size = nfa_size + 1;
        (*nstate).id = fresh30;
        if (*nstate).id == INT_MAX {
            abort();
        }
        nstate = (*nstate).next;
    }
    return nfa_size;
}
unsafe extern "C" fn nfa_clone(mut nfa: nfa) -> nfa {
    let mut nfa_size: ::core::ffi::c_int = nfa_get_size(nfa);
    let vla = nfa_size as usize;
    let mut nstates: Vec<*mut nstate> = ::std::vec::from_elem(0 as *mut nstate, vla);
    let mut id: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while id < nfa_size {
        let ref mut fresh25 = *nstates.as_mut_ptr().offset(id as isize);
        *fresh25 = nstate_alloc();
        id += 1;
    }
    let mut nstate: *mut nstate = nfa.initial as *mut nstate;
    while !nstate.is_null() {
        memcpy(
            (**nstates.as_mut_ptr().offset((*nstate).id as isize)).label.as_mut_ptr()
                as *mut ::core::ffi::c_void,
            (*nstate).label.as_mut_ptr() as *const ::core::ffi::c_void,
            ::core::mem::size_of::<symset_t>() as size_t,
        );
        if !(*nstate).target.is_null() {
            let ref mut fresh26 = (**nstates.as_mut_ptr().offset((*nstate).id as isize))
                .target;
            *fresh26 = *nstates.as_mut_ptr().offset((*(*nstate).target).id as isize);
        }
        if !(*nstate).epsilon0.is_null() {
            let ref mut fresh27 = (**nstates.as_mut_ptr().offset((*nstate).id as isize))
                .epsilon0;
            *fresh27 = *nstates.as_mut_ptr().offset((*(*nstate).epsilon0).id as isize);
        }
        if !(*nstate).epsilon1.is_null() {
            let ref mut fresh28 = (**nstates.as_mut_ptr().offset((*nstate).id as isize))
                .epsilon1;
            *fresh28 = *nstates.as_mut_ptr().offset((*(*nstate).epsilon1).id as isize);
        }
        if !(*nstate).next.is_null() {
            let ref mut fresh29 = (**nstates.as_mut_ptr().offset((*nstate).id as isize))
                .next;
            *fresh29 = *nstates.as_mut_ptr().offset((*(*nstate).next).id as isize);
        }
        nstate = (*nstate).next;
    }
    return {
        let mut init = nfa {
            initial: *nstates.as_mut_ptr().offset((*nfa.initial).id as isize),
            final_0: *nstates.as_mut_ptr().offset((*nfa.final_0).id as isize),
            complemented: nfa.complemented,
        };
        init
    };
}
unsafe extern "C" fn nfa_concat(mut nfap: *mut nfa, mut nfa: nfa) {
    if (*nfap).initial == (*nfap).final_0 {
        nfa_free(*nfap);
        *nfap = nfa;
    } else if nfa.initial != nfa.final_0 {
        memcpy(
            (*nfap).final_0 as *mut ::core::ffi::c_void,
            nfa.initial as *const ::core::ffi::c_void,
            ::core::mem::size_of::<nstate>() as size_t,
        );
        (*nfap).final_0 = nfa.final_0;
        free(nfa.initial as *mut ::core::ffi::c_void);
    }
}
unsafe extern "C" fn nfa_pad_initial(mut nfa: *mut nfa) {
    let mut initial: *mut nstate = nstate_alloc();
    (*initial).epsilon0 = (*nfa).initial as *mut nstate;
    (*initial).next = (*nfa).initial as *mut nstate;
    (*nfa).initial = initial as *mut nstate;
}
unsafe extern "C" fn nfa_pad_final(mut nfa: *mut nfa) {
    let mut final_0: *mut nstate = nstate_alloc();
    (*(*nfa).final_0).epsilon0 = final_0;
    (*(*nfa).final_0).next = final_0;
    (*nfa).final_0 = final_0;
}
unsafe extern "C" fn nfa_uncomplement(mut nfa: *mut nfa) {
    if !(*nfa).complemented {
        return;
    }
    let mut dfa: *mut dstate = ltre_compile(*nfa);
    let mut uncomplemented: nfa = ltre_uncompile(dfa);
    dfa_free(dfa);
    nfa_free(*nfa);
    memcpy(
        nfa as *mut ::core::ffi::c_void,
        &mut uncomplemented as *mut nfa as *const ::core::ffi::c_void,
        ::core::mem::size_of::<nfa>() as size_t,
    );
}
#[no_mangle]
pub unsafe extern "C" fn nfa_dump(mut nfa: nfa) {
    nfa_get_size(nfa);
    printf(b"graph LR\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(
        b"  I( ) --> %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*nfa.initial).id,
    );
    printf(
        b"  %d --> F( )\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*nfa.final_0).id,
    );
    let mut nstate: *mut nstate = nfa.initial as *mut nstate;
    while !nstate.is_null() {
        if !(*nstate).epsilon0.is_null() {
            printf(
                b"  %d --> %d\n\0" as *const u8 as *const ::core::ffi::c_char,
                (*nstate).id,
                (*(*nstate).epsilon0).id,
            );
        }
        if !(*nstate).epsilon1.is_null() {
            printf(
                b"  %d --> %d\n\0" as *const u8 as *const ::core::ffi::c_char,
                (*nstate).id,
                (*(*nstate).epsilon1).id,
            );
        }
        let mut empty: bool = true_0 != 0;
        let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while (i as usize) < ::core::mem::size_of::<symset_t>() as usize {
            empty = (empty as ::core::ffi::c_int
                & ((*nstate).label[i as usize] == 0) as ::core::ffi::c_int) as bool;
            i += 1;
        }
        if !empty {
            printf(
                b"  %d --\0" as *const u8 as *const ::core::ffi::c_char,
                (*nstate).id,
            );
            let mut fmt: *mut ::core::ffi::c_char = symset_fmt(
                (*nstate).label.as_mut_ptr(),
            );
            while *fmt != 0 {
                printf(
                    if !strchr(
                            b"\\\"#&{}()xo=- \0" as *const u8
                                as *const ::core::ffi::c_char,
                            *fmt as ::core::ffi::c_int,
                        )
                        .is_null()
                    {
                        b"#%hhu;\0" as *const u8 as *const ::core::ffi::c_char
                    } else {
                        b"%c\0" as *const u8 as *const ::core::ffi::c_char
                    },
                    *fmt as ::core::ffi::c_int,
                );
                fmt = fmt.offset(1);
            }
            printf(
                b"--> %d\n\0" as *const u8 as *const ::core::ffi::c_char,
                (*(*nstate).target).id,
            );
        }
        nstate = (*nstate).next;
    }
}
unsafe extern "C" fn dstate_alloc(mut bitset_size: ::core::ffi::c_int) -> *mut dstate {
    let mut dstate: *mut dstate = malloc(
        (::core::mem::size_of::<dstate>() as size_t).wrapping_add(bitset_size as size_t),
    ) as *mut dstate;
    *dstate = {
        let mut init = dstate {
            transitions: [0 as *mut dstate; 256],
            accepting: false,
            terminating: false,
            id: -(1 as ::core::ffi::c_int),
            next: 0 as *mut dstate,
            bitset: [],
        };
        init
    };
    memset(
        (*dstate).bitset.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        bitset_size as size_t,
    );
    return dstate;
}
#[no_mangle]
pub unsafe extern "C" fn dfa_free(mut dstate: *mut dstate) {
    let mut next: *mut dstate = 0 as *mut dstate;
    while !dstate.is_null() {
        next = (*dstate).next;
        free(dstate as *mut ::core::ffi::c_void);
        dstate = next;
    }
}
unsafe extern "C" fn dfa_get_size(mut dfa: *mut dstate) -> ::core::ffi::c_int {
    let mut dfa_size: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut dstate: *mut dstate = dfa;
    while !dstate.is_null() {
        let fresh5 = dfa_size;
        dfa_size = dfa_size + 1;
        (*dstate).id = fresh5;
        if (*dstate).id == INT_MAX {
            abort();
        }
        dstate = (*dstate).next;
    }
    return dfa_size;
}
unsafe extern "C" fn leb128_put(mut p: *mut *mut uint8_t, mut n: ::core::ffi::c_int) {
    while n >> 7 as ::core::ffi::c_int != 0 {
        let fresh3 = *p;
        *p = (*p).offset(1);
        *fresh3 = (n & 0x7f as ::core::ffi::c_int | 0x80 as ::core::ffi::c_int)
            as uint8_t;
        n >>= 7 as ::core::ffi::c_int;
    }
    let fresh4 = *p;
    *p = (*p).offset(1);
    *fresh4 = n as uint8_t;
}
unsafe extern "C" fn leb128_get(mut p: *mut *mut uint8_t) -> ::core::ffi::c_int {
    let mut n: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut c: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    loop {
        let fresh14 = c;
        c = c + 1;
        n
            |= (**p as ::core::ffi::c_int & 0x7f as ::core::ffi::c_int)
                << fresh14 * 7 as ::core::ffi::c_int;
        let fresh15 = *p;
        *p = (*p).offset(1);
        if !(*fresh15 as ::core::ffi::c_int & 0x80 as ::core::ffi::c_int != 0) {
            break;
        }
    }
    return n;
}
#[no_mangle]
pub unsafe extern "C" fn dfa_serialize(
    mut dfa: *mut dstate,
    mut size: *mut size_t,
) -> *mut uint8_t {
    let mut dfa_size: ::core::ffi::c_int = dfa_get_size(dfa);
    let mut ceil_log128: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut s: ::core::ffi::c_int = dfa_size;
    loop {
        s >>= 7 as ::core::ffi::c_int;
        if !(s != 0) {
            break;
        }
        ceil_log128 += 1;
    }
    ceil_log128 += 1;
    let mut buf: *mut uint8_t = malloc(ceil_log128 as size_t) as *mut uint8_t;
    let mut p: *mut uint8_t = buf;
    leb128_put(&mut p, dfa_size);
    let mut dstate: *mut dstate = dfa;
    while !dstate.is_null() {
        let mut len: ptrdiff_t = p.offset_from(buf) as ptrdiff_t;
        let mut new: *mut uint8_t = realloc(
            buf as *mut ::core::ffi::c_void,
            (len + 1 as ptrdiff_t
                + (256 as ::core::ffi::c_int * (1 as ::core::ffi::c_int + ceil_log128))
                    as ptrdiff_t) as size_t,
        ) as *mut uint8_t;
        buf = new;
        p = new.offset(len as isize);
        let fresh0 = p;
        p = p.offset(1);
        *fresh0 = (((*dstate).accepting as ::core::ffi::c_int) << 1 as ::core::ffi::c_int
            | (*dstate).terminating as ::core::ffi::c_int) as uint8_t;
        let mut chr: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while chr < 256 as ::core::ffi::c_int {
            let mut start: ::core::ffi::c_int = chr;
            while chr < 255 as ::core::ffi::c_int
                && (*dstate).transitions[chr as usize]
                    == (*dstate).transitions[(chr + 1 as ::core::ffi::c_int) as usize]
            {
                chr += 1;
            }
            let fresh1 = p;
            p = p.offset(1);
            *fresh1 = (chr - start) as uint8_t;
            let fresh2 = chr;
            chr = chr + 1;
            leb128_put(&mut p, (*(*dstate).transitions[fresh2 as usize]).id);
        }
        dstate = (*dstate).next;
    }
    *size = p.offset_from(buf) as ::core::ffi::c_long as size_t;
    return realloc(
        buf as *mut ::core::ffi::c_void,
        p.offset_from(buf) as ::core::ffi::c_long as size_t,
    ) as *mut uint8_t;
}
#[no_mangle]
pub unsafe extern "C" fn dfa_deserialize(
    mut buf: *mut uint8_t,
    mut size: *mut size_t,
) -> *mut dstate {
    let mut p: *mut uint8_t = buf;
    let mut dfa_size: ::core::ffi::c_int = leb128_get(&mut p);
    let vla = dfa_size as usize;
    let mut dstates: Vec<*mut dstate> = ::std::vec::from_elem(0 as *mut dstate, vla);
    let mut id: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while id < dfa_size {
        let ref mut fresh6 = *dstates.as_mut_ptr().offset(id as isize);
        *fresh6 = dstate_alloc(0 as ::core::ffi::c_int);
        id += 1;
    }
    let mut id_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while id_0 < dfa_size {
        (**dstates.as_mut_ptr().offset(id_0 as isize)).accepting = *p
            as ::core::ffi::c_int >> 1 as ::core::ffi::c_int & 1 as ::core::ffi::c_int
            != 0;
        let fresh8 = p;
        p = p.offset(1);
        (**dstates.as_mut_ptr().offset(id_0 as isize)).terminating = *fresh8
            as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0;
        let mut chr: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while chr < 256 as ::core::ffi::c_int {
            let fresh9 = p;
            p = p.offset(1);
            let mut len: ::core::ffi::c_int = *fresh9 as ::core::ffi::c_int;
            let mut target: *mut dstate = *dstates
                .as_mut_ptr()
                .offset(leb128_get(&mut p) as isize);
            loop {
                let fresh10 = chr;
                chr = chr + 1;
                let ref mut fresh11 = (**dstates.as_mut_ptr().offset(id_0 as isize))
                    .transitions[fresh10 as usize];
                *fresh11 = target;
                let fresh12 = len;
                len = len - 1;
                if !(fresh12 != 0) {
                    break;
                }
            }
        }
        if id_0 != 0 as ::core::ffi::c_int {
            let ref mut fresh13 = (**dstates
                .as_mut_ptr()
                .offset((id_0 - 1 as ::core::ffi::c_int) as isize))
                .next;
            *fresh13 = *dstates.as_mut_ptr().offset(id_0 as isize);
        }
        id_0 += 1;
    }
    *size = p.offset_from(buf) as ::core::ffi::c_long as size_t;
    return *dstates.as_mut_ptr();
}
#[no_mangle]
pub unsafe extern "C" fn dfa_dump(mut dfa: *mut dstate) {
    dfa_get_size(dfa);
    printf(b"graph LR\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"  I( ) --> %d\n\0" as *const u8 as *const ::core::ffi::c_char, (*dfa).id);
    let mut ds1: *mut dstate = dfa;
    while !ds1.is_null() {
        if (*ds1).accepting {
            printf(
                b"  %d --> F( )\n\0" as *const u8 as *const ::core::ffi::c_char,
                (*ds1).id,
            );
        }
        let mut ds2: *mut dstate = dfa;
        while !ds2.is_null() {
            let mut empty: bool = true_0 != 0;
            let mut transitions: symset_t = [
                0 as ::core::ffi::c_int as uint8_t,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
            ];
            let mut chr: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
            while chr < 256 as ::core::ffi::c_int {
                if (*ds1).transitions[chr as usize] == ds2 {
                    bitset_set(transitions.as_mut_ptr(), chr as ::core::ffi::c_uint);
                    empty = false_0 != 0;
                }
                chr += 1;
            }
            if !empty {
                printf(
                    b"  %d --\0" as *const u8 as *const ::core::ffi::c_char,
                    (*ds1).id,
                );
                let mut fmt: *mut ::core::ffi::c_char = symset_fmt(
                    transitions.as_mut_ptr(),
                );
                while *fmt != 0 {
                    printf(
                        if !strchr(
                                b"\\\"#&{}()xo=- \0" as *const u8
                                    as *const ::core::ffi::c_char,
                                *fmt as ::core::ffi::c_int,
                            )
                            .is_null()
                        {
                            b"#%hhu;\0" as *const u8 as *const ::core::ffi::c_char
                        } else {
                            b"%c\0" as *const u8 as *const ::core::ffi::c_char
                        },
                        *fmt as ::core::ffi::c_int,
                    );
                    fmt = fmt.offset(1);
                }
                printf(
                    b"--> %d\n\0" as *const u8 as *const ::core::ffi::c_char,
                    (*ds2).id,
                );
            }
            ds2 = (*ds2).next;
        }
        ds1 = (*ds1).next;
    }
}
unsafe extern "C" fn parse_natural(
    mut regex: *mut *mut ::core::ffi::c_char,
    mut error: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_uint {
    if isdigit(**regex as ::core::ffi::c_int) == 0 {
        *error = b"expected natural number\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_char;
        return 0 as ::core::ffi::c_uint;
    }
    let mut natural: ::core::ffi::c_uint = 0 as ::core::ffi::c_uint;
    while isdigit(**regex as ::core::ffi::c_int) != 0 {
        let mut digit: ::core::ffi::c_int = **regex as ::core::ffi::c_int - '0' as i32;
        if natural > UINT_MAX.wrapping_div(10 as ::core::ffi::c_uint)
            || natural.wrapping_mul(10 as ::core::ffi::c_uint)
                > UINT_MAX.wrapping_sub(digit as ::core::ffi::c_uint)
        {
            *error = b"natural number overflow\0" as *const u8
                as *const ::core::ffi::c_char as *mut ::core::ffi::c_char;
            return UINT_MAX;
        }
        natural = natural.wrapping_mul(10 as ::core::ffi::c_uint);
        natural = natural.wrapping_add(digit as ::core::ffi::c_uint);
        *regex = (*regex).offset(1);
    }
    return natural;
}
unsafe extern "C" fn parse_hexbyte(
    mut regex: *mut *mut ::core::ffi::c_char,
    mut error: *mut *mut ::core::ffi::c_char,
) -> uint8_t {
    let mut byte: uint8_t = 0 as uint8_t;
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < 2 as ::core::ffi::c_int {
        byte = ((byte as ::core::ffi::c_int) << 4 as ::core::ffi::c_int) as uint8_t;
        let mut chr: ::core::ffi::c_char = **regex;
        if isdigit(chr as ::core::ffi::c_int) != 0 {
            byte = (byte as ::core::ffi::c_int | chr as ::core::ffi::c_int - '0' as i32)
                as uint8_t;
        } else if isxdigit(chr as ::core::ffi::c_int) != 0 {
            byte = (byte as ::core::ffi::c_int
                | tolower(chr as ::core::ffi::c_int) - 'a' as i32
                    + 10 as ::core::ffi::c_int) as uint8_t;
        } else {
            *error = b"expected hex digit\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
            return 0 as uint8_t;
        }
        *regex = (*regex).offset(1);
        i += 1;
    }
    return byte;
}
unsafe extern "C" fn parse_escape(
    mut regex: *mut *mut ::core::ffi::c_char,
    mut error: *mut *mut ::core::ffi::c_char,
) -> uint8_t {
    if !strchr(METACHARS.as_ptr(), **regex as ::core::ffi::c_int).is_null() {
        let fresh21 = *regex;
        *regex = (*regex).offset(1);
        return *fresh21 as uint8_t;
    }
    let fresh22 = *regex;
    *regex = (*regex).offset(1);
    match *fresh22 as ::core::ffi::c_int {
        97 => return '\u{7}' as i32 as uint8_t,
        98 => return '\u{8}' as i32 as uint8_t,
        102 => return '\u{c}' as i32 as uint8_t,
        110 => return '\n' as i32 as uint8_t,
        114 => return '\r' as i32 as uint8_t,
        116 => return '\t' as i32 as uint8_t,
        118 => return '\u{b}' as i32 as uint8_t,
        120 => {
            let mut chr: uint8_t = parse_hexbyte(regex, error);
            if !(*error).is_null() {
                return 0 as uint8_t;
            }
            return chr;
        }
        _ => {}
    }
    *regex = (*regex).offset(-1);
    *error = b"unknown escape\0" as *const u8 as *const ::core::ffi::c_char
        as *mut ::core::ffi::c_char;
    return 0 as uint8_t;
}
unsafe extern "C" fn parse_symbol(
    mut regex: *mut *mut ::core::ffi::c_char,
    mut error: *mut *mut ::core::ffi::c_char,
) -> uint8_t {
    if **regex as ::core::ffi::c_int == '\\' as i32 {
        *regex = (*regex).offset(1);
        let mut escape: uint8_t = parse_escape(regex, error);
        if !(*error).is_null() {
            return 0 as uint8_t;
        }
        return escape;
    }
    if **regex as ::core::ffi::c_int == '\0' as i32 {
        *error = b"expected symbol\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_char;
        return 0 as uint8_t;
    }
    if !strchr(METACHARS.as_ptr(), **regex as ::core::ffi::c_int).is_null() {
        *error = b"unexpected metacharacter\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_char;
        return 0 as uint8_t;
    }
    if isprint(**regex as ::core::ffi::c_int) == 0 {
        *error = b"unexpected nonprintable character\0" as *const u8
            as *const ::core::ffi::c_char as *mut ::core::ffi::c_char;
        return 0 as uint8_t;
    }
    let fresh20 = *regex;
    *regex = (*regex).offset(1);
    return *fresh20 as uint8_t;
}
unsafe extern "C" fn parse_shorthand(
    mut symset: *mut uint8_t,
    mut regex: *mut *mut ::core::ffi::c_char,
    mut error: *mut *mut ::core::ffi::c_char,
) {
    memset(
        symset as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<symset_t>() as size_t,
    );
    if **regex as ::core::ffi::c_int == '\\' as i32 {
        *regex = (*regex).offset(1);
        let fresh24 = *regex;
        *regex = (*regex).offset(1);
        match *fresh24 as ::core::ffi::c_int {
            100 => {
                let mut chr: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                while chr < 256 as ::core::ffi::c_int {
                    if isdigit(chr) != 0 {
                        bitset_set(symset as *mut uint8_t, chr as ::core::ffi::c_uint);
                    }
                    chr += 1;
                }
                return;
            }
            68 => {
                let mut chr_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                while chr_0 < 256 as ::core::ffi::c_int {
                    if isdigit(chr_0) == 0 {
                        bitset_set(symset as *mut uint8_t, chr_0 as ::core::ffi::c_uint);
                    }
                    chr_0 += 1;
                }
                return;
            }
            115 => {
                let mut chr_1: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                while chr_1 < 256 as ::core::ffi::c_int {
                    if isspace(chr_1) != 0 {
                        bitset_set(symset as *mut uint8_t, chr_1 as ::core::ffi::c_uint);
                    }
                    chr_1 += 1;
                }
                return;
            }
            83 => {
                let mut chr_2: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                while chr_2 < 256 as ::core::ffi::c_int {
                    if isspace(chr_2) == 0 {
                        bitset_set(symset as *mut uint8_t, chr_2 as ::core::ffi::c_uint);
                    }
                    chr_2 += 1;
                }
                return;
            }
            119 => {
                let mut chr_3: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                while chr_3 < 256 as ::core::ffi::c_int {
                    if chr_3 == '_' as i32 || isalnum(chr_3) != 0 {
                        bitset_set(symset as *mut uint8_t, chr_3 as ::core::ffi::c_uint);
                    }
                    chr_3 += 1;
                }
                return;
            }
            87 => {
                let mut chr_4: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                while chr_4 < 256 as ::core::ffi::c_int {
                    if chr_4 != '_' as i32 && isalnum(chr_4) == 0 {
                        bitset_set(symset as *mut uint8_t, chr_4 as ::core::ffi::c_uint);
                    }
                    chr_4 += 1;
                }
                return;
            }
            _ => {}
        }
        *regex = (*regex).offset(-1);
        *regex = (*regex).offset(-1);
    }
    if **regex as ::core::ffi::c_int == '.' as i32 {
        *regex = (*regex).offset(1);
        let mut chr_5: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while chr_5 < 256 as ::core::ffi::c_int {
            if chr_5 != '\n' as i32 {
                bitset_set(symset as *mut uint8_t, chr_5 as ::core::ffi::c_uint);
            }
            chr_5 += 1;
        }
        return;
    }
    *error = b"expected shorthand class\0" as *const u8 as *const ::core::ffi::c_char
        as *mut ::core::ffi::c_char;
}
unsafe extern "C" fn parse_symset(
    mut symset: *mut uint8_t,
    mut regex: *mut *mut ::core::ffi::c_char,
    mut error: *mut *mut ::core::ffi::c_char,
) {
    let mut begin: uint8_t = 0;
    let mut complement: bool = false_0 != 0;
    if **regex as ::core::ffi::c_int == '^' as i32 {
        *regex = (*regex).offset(1);
        complement = true_0 != 0;
    }
    let mut last_regex: *mut ::core::ffi::c_char = *regex;
    parse_shorthand(symset, regex, error);
    if !(*error).is_null() {
        *error = 0 as *mut ::core::ffi::c_char;
        *regex = last_regex;
        if **regex as ::core::ffi::c_int == '[' as i32 {
            *regex = (*regex).offset(1);
            memset(
                symset as *mut ::core::ffi::c_void,
                0 as ::core::ffi::c_int,
                ::core::mem::size_of::<symset_t>() as size_t,
            );
            while strchr(
                    b"]\0" as *const u8 as *const ::core::ffi::c_char,
                    **regex as ::core::ffi::c_int,
                )
                .is_null()
            {
                let mut sub: symset_t = [0; 32];
                parse_symset(sub.as_mut_ptr(), regex, error);
                if !(*error).is_null() {
                    return;
                }
                let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                while (i as usize) < ::core::mem::size_of::<symset_t>() as usize {
                    let ref mut fresh18 = *symset.offset(i as isize);
                    *fresh18 = (*fresh18 as ::core::ffi::c_int
                        | sub[i as usize] as ::core::ffi::c_int) as uint8_t;
                    i += 1;
                }
            }
            if **regex as ::core::ffi::c_int != ']' as i32 {
                *error = b"expected ']'\0" as *const u8 as *const ::core::ffi::c_char
                    as *mut ::core::ffi::c_char;
                return;
            }
            *regex = (*regex).offset(1);
        } else {
            *regex = last_regex;
            if **regex as ::core::ffi::c_int == '<' as i32 {
                *regex = (*regex).offset(1);
                memset(
                    symset as *mut ::core::ffi::c_void,
                    0xff as ::core::ffi::c_int,
                    ::core::mem::size_of::<symset_t>() as size_t,
                );
                while strchr(
                        b">\0" as *const u8 as *const ::core::ffi::c_char,
                        **regex as ::core::ffi::c_int,
                    )
                    .is_null()
                {
                    let mut sub_0: symset_t = [0; 32];
                    parse_symset(sub_0.as_mut_ptr(), regex, error);
                    if !(*error).is_null() {
                        return;
                    }
                    let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                    while (i_0 as usize) < ::core::mem::size_of::<symset_t>() as usize {
                        let ref mut fresh19 = *symset.offset(i_0 as isize);
                        *fresh19 = (*fresh19 as ::core::ffi::c_int
                            & sub_0[i_0 as usize] as ::core::ffi::c_int) as uint8_t;
                        i_0 += 1;
                    }
                }
                if **regex as ::core::ffi::c_int != '>' as i32 {
                    *error = b"expected '>'\0" as *const u8 as *const ::core::ffi::c_char
                        as *mut ::core::ffi::c_char;
                    return;
                }
                *regex = (*regex).offset(1);
            } else {
                *regex = last_regex;
                begin = parse_symbol(regex, error);
                if (*error).is_null() {
                    let mut end: uint8_t = begin;
                    if **regex as ::core::ffi::c_int == '-' as i32 {
                        *regex = (*regex).offset(1);
                        end = parse_symbol(regex, error);
                        if !(*error).is_null() {
                            return;
                        }
                    }
                    end = end.wrapping_add(1);
                    memset(
                        symset as *mut ::core::ffi::c_void,
                        0 as ::core::ffi::c_int,
                        ::core::mem::size_of::<symset_t>() as size_t,
                    );
                    let mut chr: uint8_t = begin;
                    loop {
                        bitset_set(symset as *mut uint8_t, chr as ::core::ffi::c_uint);
                        chr = chr.wrapping_add(1);
                        if !(chr as ::core::ffi::c_int != end as ::core::ffi::c_int) {
                            break;
                        }
                    }
                } else {
                    return
                }
            }
        }
    }
    if complement {
        let mut i_1: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while (i_1 as usize) < ::core::mem::size_of::<symset_t>() as usize {
            *symset.offset(i_1 as isize) = !(*symset.offset(i_1 as isize)
                as ::core::ffi::c_int) as uint8_t;
            i_1 += 1;
        }
    }
}
unsafe extern "C" fn parse_atom(
    mut regex: *mut *mut ::core::ffi::c_char,
    mut error: *mut *mut ::core::ffi::c_char,
) -> nfa {
    if **regex as ::core::ffi::c_int == '(' as i32 {
        *regex = (*regex).offset(1);
        let mut sub: nfa = parse_regex(regex, error);
        if !(*error).is_null() {
            return {
                let mut init = nfa {
                    initial: 0 as *mut nstate,
                    final_0: 0 as *mut nstate,
                    complemented: false,
                };
                init
            };
        }
        if **regex as ::core::ffi::c_int != ')' as i32 {
            *error = b"expected ')'\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
            nfa_free(sub);
            return {
                let mut init = nfa {
                    initial: 0 as *mut nstate,
                    final_0: 0 as *mut nstate,
                    complemented: false,
                };
                init
            };
        }
        *regex = (*regex).offset(1);
        return sub;
    }
    let mut chars: nfa = {
        let mut init = nfa {
            initial: nstate_alloc() as *mut nstate,
            final_0: nstate_alloc(),
            complemented: false_0 != 0,
        };
        init
    };
    (*chars.initial).next = chars.final_0;
    (*chars.initial).target = chars.final_0;
    parse_symset((*chars.initial).label.as_mut_ptr(), regex, error);
    if !(*error).is_null() {
        nfa_free(chars);
        return {
            let mut init = nfa {
                initial: 0 as *mut nstate,
                final_0: 0 as *mut nstate,
                complemented: false,
            };
            init
        };
    }
    return chars;
}
unsafe extern "C" fn parse_factor(
    mut regex: *mut *mut ::core::ffi::c_char,
    mut error: *mut *mut ::core::ffi::c_char,
) -> nfa {
    let mut atom: nfa = parse_atom(regex, error);
    if !(*error).is_null() {
        return {
            let mut init = nfa {
                initial: 0 as *mut nstate,
                final_0: 0 as *mut nstate,
                complemented: false,
            };
            init
        };
    }
    if **regex as ::core::ffi::c_int == '*' as i32 {
        *regex = (*regex).offset(1);
        nfa_uncomplement(&mut atom);
        (*atom.final_0).epsilon1 = atom.initial as *mut nstate;
        nfa_pad_initial(&mut atom);
        nfa_pad_final(&mut atom);
        (*atom.initial).epsilon1 = atom.final_0;
        return atom;
    }
    if **regex as ::core::ffi::c_int == '+' as i32 {
        *regex = (*regex).offset(1);
        nfa_uncomplement(&mut atom);
        (*atom.final_0).epsilon1 = atom.initial as *mut nstate;
        nfa_pad_initial(&mut atom);
        nfa_pad_final(&mut atom);
        return atom;
    }
    if **regex as ::core::ffi::c_int == '?' as i32 {
        *regex = (*regex).offset(1);
        nfa_uncomplement(&mut atom);
        if !(*atom.initial).epsilon1.is_null() {
            nfa_pad_initial(&mut atom);
        }
        (*atom.initial).epsilon1 = atom.final_0;
        return atom;
    }
    let mut last_regex: *mut ::core::ffi::c_char = *regex;
    if **regex as ::core::ffi::c_int == '{' as i32 {
        *regex = (*regex).offset(1);
        nfa_uncomplement(&mut atom);
        let mut min: ::core::ffi::c_uint = parse_natural(regex, error);
        if !(*error).is_null() && min == UINT_MAX {
            nfa_free(atom);
            return {
                let mut init = nfa {
                    initial: 0 as *mut nstate,
                    final_0: 0 as *mut nstate,
                    complemented: false,
                };
                init
            };
        } else if !(*error).is_null() {
            min = 0 as ::core::ffi::c_uint;
            *error = 0 as *mut ::core::ffi::c_char;
        }
        let mut max: ::core::ffi::c_uint = min;
        let mut max_unbounded: bool = false_0 != 0;
        if **regex as ::core::ffi::c_int == ',' as i32 {
            *regex = (*regex).offset(1);
            max = parse_natural(regex, error);
            if !(*error).is_null() && max == UINT_MAX {
                nfa_free(atom);
                return {
                    let mut init = nfa {
                        initial: 0 as *mut nstate,
                        final_0: 0 as *mut nstate,
                        complemented: false,
                    };
                    init
                };
            } else if !(*error).is_null() {
                max_unbounded = true_0 != 0;
                *error = 0 as *mut ::core::ffi::c_char;
            }
        }
        if **regex as ::core::ffi::c_int != '}' as i32 {
            *error = b"expected '}'\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
            nfa_free(atom);
            return {
                let mut init = nfa {
                    initial: 0 as *mut nstate,
                    final_0: 0 as *mut nstate,
                    complemented: false,
                };
                init
            };
        }
        *regex = (*regex).offset(1);
        if min > max && !max_unbounded {
            *regex = last_regex;
            *error = b"misbounded quantifier\0" as *const u8
                as *const ::core::ffi::c_char as *mut ::core::ffi::c_char;
            nfa_free(atom);
            return {
                let mut init = nfa {
                    initial: 0 as *mut nstate,
                    final_0: 0 as *mut nstate,
                    complemented: false,
                };
                init
            };
        }
        let mut atoms: nfa = {
            let mut init = nfa {
                initial: 0 as *mut nstate,
                final_0: 0 as *mut nstate,
                complemented: false_0 != 0,
            };
            init
        };
        atoms.final_0 = nstate_alloc();
        atoms.initial = atoms.final_0 as *mut nstate;
        let mut i: ::core::ffi::c_uint = 0 as ::core::ffi::c_uint;
        while if max_unbounded as ::core::ffi::c_int != 0 {
            (i <= min) as ::core::ffi::c_int
        } else {
            (i < max) as ::core::ffi::c_int
        } != 0
        {
            let mut clone: nfa = nfa_clone(atom);
            if i >= min {
                if max_unbounded {
                    (*clone.final_0).epsilon1 = clone.initial as *mut nstate;
                    nfa_pad_initial(&mut clone);
                    nfa_pad_final(&mut clone);
                }
                (*clone.initial).epsilon1 = clone.final_0;
            }
            nfa_concat(&mut atoms, clone);
            if i == UINT_MAX {
                break;
            }
            i = i.wrapping_add(1);
        }
        nfa_free(atom);
        return atoms;
    }
    return atom;
}
unsafe extern "C" fn parse_term(
    mut regex: *mut *mut ::core::ffi::c_char,
    mut error: *mut *mut ::core::ffi::c_char,
) -> nfa {
    let mut complement: bool = false_0 != 0;
    if **regex as ::core::ffi::c_int == '~' as i32 {
        *regex = (*regex).offset(1);
        complement = true_0 != 0;
    }
    let mut term: nfa = {
        let mut init = nfa {
            initial: 0 as *mut nstate,
            final_0: 0 as *mut nstate,
            complemented: false_0 != 0,
        };
        init
    };
    term.final_0 = nstate_alloc();
    term.initial = term.final_0 as *mut nstate;
    while strchr(
            b")|&\0" as *const u8 as *const ::core::ffi::c_char,
            **regex as ::core::ffi::c_int,
        )
        .is_null()
    {
        let mut factor: nfa = parse_factor(regex, error);
        if !(*error).is_null() {
            nfa_free(term);
            return {
                let mut init = nfa {
                    initial: 0 as *mut nstate,
                    final_0: 0 as *mut nstate,
                    complemented: false,
                };
                init
            };
        }
        nfa_uncomplement(&mut factor);
        nfa_concat(&mut term, factor);
    }
    if complement {
        term.complemented = true_0 != 0;
    }
    return term;
}
unsafe extern "C" fn parse_regex(
    mut regex: *mut *mut ::core::ffi::c_char,
    mut error: *mut *mut ::core::ffi::c_char,
) -> nfa {
    let mut re: nfa = parse_term(regex, error);
    if !(*error).is_null() {
        return {
            let mut init = nfa {
                initial: 0 as *mut nstate,
                final_0: 0 as *mut nstate,
                complemented: false,
            };
            init
        };
    }
    while **regex as ::core::ffi::c_int == '|' as i32
        || **regex as ::core::ffi::c_int == '&' as i32
    {
        let fresh17 = *regex;
        *regex = (*regex).offset(1);
        let mut intersect: bool = *fresh17 as ::core::ffi::c_int == '&' as i32;
        let mut alt: nfa = parse_term(regex, error);
        if !(*error).is_null() {
            nfa_free(re);
            return {
                let mut init = nfa {
                    initial: 0 as *mut nstate,
                    final_0: 0 as *mut nstate,
                    complemented: false,
                };
                init
            };
        }
        re.complemented = (re.complemented as ::core::ffi::c_int
            ^ intersect as ::core::ffi::c_int) as bool;
        alt.complemented = (alt.complemented as ::core::ffi::c_int
            ^ intersect as ::core::ffi::c_int) as bool;
        nfa_uncomplement(&mut re);
        nfa_uncomplement(&mut alt);
        nfa_pad_initial(&mut re);
        nfa_pad_final(&mut alt);
        (*re.initial).epsilon1 = alt.initial as *mut nstate;
        (*re.final_0).epsilon0 = alt.final_0;
        (*re.final_0).next = alt.initial as *mut nstate;
        re.final_0 = alt.final_0;
        re.complemented = (re.complemented as ::core::ffi::c_int
            ^ intersect as ::core::ffi::c_int) as bool;
    }
    return re;
}
#[no_mangle]
pub unsafe extern "C" fn ltre_parse(
    mut regex: *mut *mut ::core::ffi::c_char,
    mut error: *mut *mut ::core::ffi::c_char,
) -> nfa {
    let mut e: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut r: *mut ::core::ffi::c_char = *regex;
    if error.is_null() {
        error = &mut e;
        regex = &mut r;
    }
    *error = 0 as *mut ::core::ffi::c_char;
    let mut nfa: nfa = parse_regex(regex, error);
    if !(*error).is_null() {
        return {
            let mut init = nfa {
                initial: 0 as *mut nstate,
                final_0: 0 as *mut nstate,
                complemented: false,
            };
            init
        };
    }
    if **regex as ::core::ffi::c_int != '\0' as i32 {
        *error = b"expected end of input\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_char;
        nfa_free(nfa);
        return {
            let mut init = nfa {
                initial: 0 as *mut nstate,
                final_0: 0 as *mut nstate,
                complemented: false,
            };
            init
        };
    }
    return nfa;
}
#[no_mangle]
pub unsafe extern "C" fn ltre_fixed_string(mut string: *mut ::core::ffi::c_char) -> nfa {
    let mut nfa: nfa = {
        let mut init = nfa {
            initial: 0 as *mut nstate,
            final_0: 0 as *mut nstate,
            complemented: false_0 != 0,
        };
        init
    };
    nfa.final_0 = nstate_alloc();
    nfa.initial = nfa.final_0 as *mut nstate;
    while *string != 0 {
        let mut initial: *mut nstate = nfa.final_0;
        nfa.final_0 = nstate_alloc();
        (*initial).next = nfa.final_0;
        (*initial).target = nfa.final_0;
        bitset_set(
            (*initial).label.as_mut_ptr(),
            *string as uint8_t as ::core::ffi::c_uint,
        );
        string = string.offset(1);
    }
    return nfa;
}
#[no_mangle]
pub unsafe extern "C" fn ltre_partial(mut nfa: *mut nfa) {
    nfa_uncomplement(nfa);
    nfa_pad_initial(nfa);
    nfa_pad_final(nfa);
    (*(*nfa).initial).target = (*nfa).initial as *mut nstate;
    (*(*nfa).final_0).target = (*nfa).final_0;
    memset(
        (*(*nfa).initial).label.as_mut_ptr() as *mut ::core::ffi::c_void,
        0xff as ::core::ffi::c_int,
        ::core::mem::size_of::<symset_t>() as size_t,
    );
    memset(
        (*(*nfa).final_0).label.as_mut_ptr() as *mut ::core::ffi::c_void,
        0xff as ::core::ffi::c_int,
        ::core::mem::size_of::<symset_t>() as size_t,
    );
}
#[no_mangle]
pub unsafe extern "C" fn ltre_ignorecase(mut nfa: *mut nfa) {
    nfa_uncomplement(nfa);
    let mut nstate: *mut nstate = (*nfa).initial as *mut nstate;
    while !nstate.is_null() {
        let mut chr: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while chr < 256 as ::core::ffi::c_int {
            if bitset_get((*nstate).label.as_mut_ptr(), chr as ::core::ffi::c_uint) {
                bitset_set(
                    (*nstate).label.as_mut_ptr(),
                    tolower(chr) as ::core::ffi::c_uint,
                );
                bitset_set(
                    (*nstate).label.as_mut_ptr(),
                    toupper(chr) as ::core::ffi::c_uint,
                );
            }
            chr += 1;
        }
        nstate = (*nstate).next;
    }
}
#[no_mangle]
pub unsafe extern "C" fn ltre_complement(mut nfa: *mut nfa) {
    (*nfa).complemented = !(*nfa).complemented;
}
unsafe extern "C" fn epsilon_closure(mut nstate: *mut nstate, mut bitset: *mut uint8_t) {
    if nstate.is_null() {
        return;
    }
    if bitset_get(bitset, (*nstate).id as ::core::ffi::c_uint) {
        return;
    }
    bitset_set(bitset, (*nstate).id as ::core::ffi::c_uint);
    epsilon_closure((*nstate).epsilon0, bitset);
    epsilon_closure((*nstate).epsilon1, bitset);
}
unsafe extern "C" fn dfa_step(
    mut dfap: *mut *mut dstate,
    mut dstate: *mut dstate,
    mut chr: uint8_t,
    mut nfa: nfa,
    mut nfa_size: ::core::ffi::c_int,
    mut nstates: *mut *mut nstate,
) {
    let mut bitset_size: ::core::ffi::c_int = (nfa_size + 7 as ::core::ffi::c_int)
        / 8 as ::core::ffi::c_int;
    let vla = bitset_size as usize;
    let mut bitset_union: Vec<uint8_t> = ::std::vec::from_elem(0, vla);
    memset(
        bitset_union.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        bitset_size as size_t,
    );
    if !dstate.is_null() {
        let mut id: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while id < nfa_size {
            if bitset_get((*dstate).bitset.as_mut_ptr(), id as ::core::ffi::c_uint)
                as ::core::ffi::c_int != 0
                && bitset_get(
                    (**nstates.offset(id as isize)).label.as_mut_ptr(),
                    chr as ::core::ffi::c_uint,
                ) as ::core::ffi::c_int != 0
            {
                epsilon_closure(
                    (**nstates.offset(id as isize)).target,
                    bitset_union.as_mut_ptr(),
                );
            }
            id += 1;
        }
    } else {
        epsilon_closure(nfa.initial as *mut nstate, bitset_union.as_mut_ptr());
    }
    let mut dstatep: *mut *mut dstate = dfap;
    while !(*dstatep).is_null()
        && memcmp(
            (**dstatep).bitset.as_mut_ptr() as *const ::core::ffi::c_void,
            bitset_union.as_mut_ptr() as *const ::core::ffi::c_void,
            bitset_size as size_t,
        ) != 0
    {
        dstatep = &mut (**dstatep).next;
    }
    if (*dstatep).is_null() {
        *dstatep = dstate_alloc(bitset_size);
        memcpy(
            (**dstatep).bitset.as_mut_ptr() as *mut ::core::ffi::c_void,
            bitset_union.as_mut_ptr() as *const ::core::ffi::c_void,
            bitset_size as size_t,
        );
        (**dstatep).accepting = bitset_get(
            bitset_union.as_mut_ptr(),
            (*nfa.final_0).id as ::core::ffi::c_uint,
        );
        (**dstatep).accepting = ((**dstatep).accepting as ::core::ffi::c_int
            ^ nfa.complemented as ::core::ffi::c_int) as bool;
    }
    if !dstate.is_null() {
        (*dstate).transitions[chr as usize] = *dstatep;
    }
}
#[no_mangle]
pub unsafe extern "C" fn ltre_compile(mut nfa: nfa) -> *mut dstate {
    let mut nfa_size: ::core::ffi::c_int = nfa_get_size(nfa);
    let vla = nfa_size as usize;
    let mut nstates: Vec<*mut nstate> = ::std::vec::from_elem(0 as *mut nstate, vla);
    let mut nstate: *mut nstate = nfa.initial as *mut nstate;
    while !nstate.is_null() {
        let ref mut fresh31 = *nstates.as_mut_ptr().offset((*nstate).id as isize);
        *fresh31 = nstate;
        nstate = (*nstate).next;
    }
    let mut dfa: *mut dstate = 0 as *mut dstate;
    dfa_step(
        &mut dfa,
        0 as *mut dstate,
        0 as uint8_t,
        nfa,
        nfa_size,
        nstates.as_mut_ptr(),
    );
    let mut dstate: *mut dstate = dfa;
    while !dstate.is_null() {
        let mut chr: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while chr < 256 as ::core::ffi::c_int {
            dfa_step(
                &mut dfa,
                dstate,
                chr as uint8_t,
                nfa,
                nfa_size,
                nstates.as_mut_ptr(),
            );
            chr += 1;
        }
        dstate = (*dstate).next;
    }
    let mut dfa_size: ::core::ffi::c_int = dfa_get_size(dfa);
    let vla_0 = dfa_size as usize;
    let mut dstates: Vec<*mut dstate> = ::std::vec::from_elem(0 as *mut dstate, vla_0);
    let mut dstate_0: *mut dstate = dfa;
    while !dstate_0.is_null() {
        let ref mut fresh32 = *dstates.as_mut_ptr().offset((*dstate_0).id as isize);
        *fresh32 = dstate_0;
        dstate_0 = (*dstate_0).next;
    }
    let vla_1 = dfa_size as usize;
    let vla_2 = ((dfa_size + 7 as ::core::ffi::c_int) / 8 as ::core::ffi::c_int)
        as usize;
    let mut dis: Vec<uint8_t> = ::std::vec::from_elem(0, vla_1 * vla_2);
    memset(
        dis.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        vla_1 * vla_2 * ::core::mem::size_of::<uint8_t>() as size_t,
    );
    let mut ds1: *mut dstate = dfa;
    while !ds1.is_null() {
        let mut ds2: *mut dstate = (*ds1).next;
        while !ds2.is_null() {
            if (*ds1).accepting as ::core::ffi::c_int
                != (*ds2).accepting as ::core::ffi::c_int
            {
                bitset_set(
                    dis.as_mut_ptr().offset((*ds1).id as isize * vla_2 as isize),
                    (*ds2).id as ::core::ffi::c_uint,
                );
                bitset_set(
                    dis.as_mut_ptr().offset((*ds2).id as isize * vla_2 as isize),
                    (*ds1).id as ::core::ffi::c_uint,
                );
            }
            ds2 = (*ds2).next;
        }
        ds1 = (*ds1).next;
    }
    let mut done: bool = false_0 != 0;
    loop {
        done = !done;
        if !done {
            break;
        }
        let mut id1: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while id1 < dfa_size {
            let mut id2: ::core::ffi::c_int = id1 + 1 as ::core::ffi::c_int;
            while id2 < dfa_size {
                if !bitset_get(
                    dis.as_mut_ptr().offset(id1 as isize * vla_2 as isize),
                    id2 as ::core::ffi::c_uint,
                ) {
                    let mut chr_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                    while chr_0 < 256 as ::core::ffi::c_int {
                        if (**dstates.as_mut_ptr().offset(id1 as isize))
                            .transitions[chr_0 as usize]
                            != (**dstates.as_mut_ptr().offset(id2 as isize))
                                .transitions[chr_0 as usize]
                        {
                            if bitset_get(
                                dis
                                    .as_mut_ptr()
                                    .offset(
                                        (**(**dstates.as_mut_ptr().offset(id1 as isize))
                                            .transitions
                                            .as_mut_ptr()
                                            .offset(chr_0 as isize))
                                            .id as isize * vla_2 as isize,
                                    ),
                                (*(**dstates.as_mut_ptr().offset(id2 as isize))
                                    .transitions[chr_0 as usize])
                                    .id as ::core::ffi::c_uint,
                            ) {
                                bitset_set(
                                    dis.as_mut_ptr().offset(id1 as isize * vla_2 as isize),
                                    id2 as ::core::ffi::c_uint,
                                );
                                bitset_set(
                                    dis.as_mut_ptr().offset(id2 as isize * vla_2 as isize),
                                    id1 as ::core::ffi::c_uint,
                                );
                                done = false_0 != 0;
                                break;
                            }
                        }
                        chr_0 += 1;
                    }
                }
                id2 += 1;
            }
            id1 += 1;
        }
    }
    let mut ds1_0: *mut dstate = dfa;
    while !ds1_0.is_null() {
        let mut prev: *mut dstate = ds1_0;
        while !prev.is_null() {
            let mut ds2_0: *mut dstate = 0 as *mut dstate;
            loop {
                ds2_0 = (*prev).next;
                if ds2_0.is_null() {
                    break;
                }
                if bitset_get(
                    dis.as_mut_ptr().offset((*ds1_0).id as isize * vla_2 as isize),
                    (*ds2_0).id as ::core::ffi::c_uint,
                ) {
                    break;
                }
                let mut dstate_1: *mut dstate = dfa;
                while !dstate_1.is_null() {
                    let mut chr_1: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                    while chr_1 < 256 as ::core::ffi::c_int {
                        if (*dstate_1).transitions[chr_1 as usize] == ds2_0 {
                            (*dstate_1).transitions[chr_1 as usize] = ds1_0;
                        }
                        chr_1 += 1;
                    }
                    dstate_1 = (*dstate_1).next;
                }
                (*prev).next = (*ds2_0).next;
                free(ds2_0 as *mut ::core::ffi::c_void);
            }
            prev = (*prev).next;
        }
        (*ds1_0).terminating = true_0 != 0;
        let mut chr_2: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while chr_2 < 256 as ::core::ffi::c_int {
            if (*ds1_0).transitions[chr_2 as usize] != ds1_0 {
                (*ds1_0).terminating = false_0 != 0;
            }
            chr_2 += 1;
        }
        ds1_0 = (*ds1_0).next;
    }
    return dfa;
}
#[no_mangle]
pub unsafe extern "C" fn ltre_matches(
    mut dfa: *mut dstate,
    mut input: *mut uint8_t,
) -> bool {
    while !(*dfa).terminating && *input as ::core::ffi::c_int != 0 {
        dfa = (*dfa).transitions[*input as usize];
        input = input.offset(1);
    }
    return (*dfa).accepting;
}
#[no_mangle]
pub unsafe extern "C" fn ltre_matches_lazy(
    mut dfap: *mut *mut dstate,
    mut nfa: nfa,
    mut input: *mut uint8_t,
) -> bool {
    let mut nfa_size: ::core::ffi::c_int = nfa_get_size(nfa);
    let vla = nfa_size as usize;
    let mut nstates: Vec<*mut nstate> = ::std::vec::from_elem(0 as *mut nstate, vla);
    let mut nstate: *mut nstate = nfa.initial as *mut nstate;
    while !nstate.is_null() {
        let ref mut fresh82 = *nstates.as_mut_ptr().offset((*nstate).id as isize);
        *fresh82 = nstate;
        nstate = (*nstate).next;
    }
    dfa_step(dfap, 0 as *mut dstate, 0 as uint8_t, nfa, nfa_size, nstates.as_mut_ptr());
    let mut dstate: *mut dstate = *dfap;
    while *input != 0 {
        if (*dstate).transitions[*input as usize].is_null() {
            dfa_step(dfap, dstate, *input, nfa, nfa_size, nstates.as_mut_ptr());
        }
        let fresh83 = input;
        input = input.offset(1);
        dstate = (*dstate).transitions[*fresh83 as usize];
    }
    return (*dstate).accepting;
}
#[no_mangle]
pub unsafe extern "C" fn ltre_uncompile(mut dfa: *mut dstate) -> nfa {
    let mut dfa_size: ::core::ffi::c_int = dfa_get_size(dfa);
    let mut nfa: nfa = {
        let mut init = nfa {
            initial: nstate_alloc() as *mut nstate,
            final_0: nstate_alloc(),
            complemented: false_0 != 0,
        };
        init
    };
    let mut tail: *mut nstate = nfa.initial as *mut nstate;
    let vla = dfa_size as usize;
    let mut nstates: Vec<*mut nstate> = ::std::vec::from_elem(0 as *mut nstate, vla);
    let mut id: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while id < dfa_size {
        (*tail).next = nstate_alloc();
        let ref mut fresh33 = *nstates.as_mut_ptr().offset(id as isize);
        *fresh33 = (*tail).next;
        tail = (*tail).next;
        id += 1;
    }
    (*nfa.initial).epsilon1 = *nstates.as_mut_ptr().offset((*dfa).id as isize);
    let mut dstate: *mut dstate = dfa;
    while !dstate.is_null() {
        if (*dstate).accepting {
            let ref mut fresh34 = (**nstates.as_mut_ptr().offset((*dstate).id as isize))
                .epsilon1;
            *fresh34 = nfa.final_0;
        }
        dstate = (*dstate).next;
    }
    let mut ds1: *mut dstate = dfa;
    while !ds1.is_null() {
        let mut free_0: *mut nstate = 0 as *mut nstate;
        let mut ds2: *mut dstate = dfa;
        while !ds2.is_null() {
            let mut empty: bool = true_0 != 0;
            let mut transitions: symset_t = [
                0 as ::core::ffi::c_int as uint8_t,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
            ];
            let mut chr: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
            while chr < 256 as ::core::ffi::c_int {
                if (*ds1).transitions[chr as usize] == ds2 {
                    bitset_set(transitions.as_mut_ptr(), chr as ::core::ffi::c_uint);
                    empty = false_0 != 0;
                }
                chr += 1;
            }
            if !empty {
                let mut src: *mut nstate = 0 as *mut nstate;
                if free_0.is_null() {
                    free_0 = *nstates.as_mut_ptr().offset((*ds1).id as isize);
                    src = free_0;
                } else {
                    (*tail).next = nstate_alloc();
                    src = (*tail).next;
                    tail = (*tail).next;
                    if (*free_0).epsilon1.is_null() {
                        (*free_0).epsilon1 = tail;
                    } else {
                        (*free_0).epsilon0 = tail;
                        free_0 = tail;
                    }
                }
                (*src).target = *nstates.as_mut_ptr().offset((*ds2).id as isize);
                memcpy(
                    (*src).label.as_mut_ptr() as *mut ::core::ffi::c_void,
                    transitions.as_mut_ptr() as *const ::core::ffi::c_void,
                    ::core::mem::size_of::<symset_t>() as size_t,
                );
            }
            ds2 = (*ds2).next;
        }
        ds1 = (*ds1).next;
    }
    (*tail).next = nfa.final_0;
    return nfa;
}
#[no_mangle]
pub unsafe extern "C" fn ltre_decompile(
    mut dfa: *mut dstate,
) -> *mut ::core::ffi::c_char {
    let mut current_block: u64;
    let mut dfa_size: ::core::ffi::c_int = dfa_get_size(dfa);
    let vla = (dfa_size + 1 as ::core::ffi::c_int) as usize;
    let vla_0 = (dfa_size + 1 as ::core::ffi::c_int) as usize;
    let mut arrows: Vec<arrow> = ::std::vec::from_elem(
        arrow {
            label: 0 as *mut ::core::ffi::c_char,
            prec: ALT,
        },
        vla * vla_0,
    );
    let mut id: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while id <= dfa_size {
        let ref mut fresh35 = (*arrows
            .as_mut_ptr()
            .offset(id as isize * vla_0 as isize)
            .offset(dfa_size as isize))
            .label;
        *fresh35 = 0 as *mut ::core::ffi::c_char;
        let ref mut fresh36 = (*arrows
            .as_mut_ptr()
            .offset(dfa_size as isize * vla_0 as isize)
            .offset(id as isize))
            .label;
        *fresh36 = *fresh35;
        id += 1;
    }
    let ref mut fresh37 = (*arrows
        .as_mut_ptr()
        .offset(dfa_size as isize * vla_0 as isize)
        .offset((*dfa).id as isize))
        .label;
    *fresh37 = malloc(1 as size_t) as *mut ::core::ffi::c_char;
    *(*arrows
        .as_mut_ptr()
        .offset(dfa_size as isize * vla_0 as isize)
        .offset((*dfa).id as isize))
        .label = '\0' as i32 as ::core::ffi::c_char;
    (*arrows
        .as_mut_ptr()
        .offset(dfa_size as isize * vla_0 as isize)
        .offset((*dfa).id as isize))
        .prec = SYMSET;
    let mut ds1: *mut dstate = dfa;
    while !ds1.is_null() {
        if (*ds1).accepting {
            let ref mut fresh38 = (*arrows
                .as_mut_ptr()
                .offset((*ds1).id as isize * vla_0 as isize)
                .offset(dfa_size as isize))
                .label;
            *fresh38 = malloc(1 as size_t) as *mut ::core::ffi::c_char;
            *(*arrows
                .as_mut_ptr()
                .offset((*ds1).id as isize * vla_0 as isize)
                .offset(dfa_size as isize))
                .label = '\0' as i32 as ::core::ffi::c_char;
            (*arrows
                .as_mut_ptr()
                .offset((*ds1).id as isize * vla_0 as isize)
                .offset(dfa_size as isize))
                .prec = SYMSET;
        }
        let mut ds2: *mut dstate = dfa;
        while !ds2.is_null() {
            let mut empty: bool = true_0 != 0;
            let mut transitions: symset_t = [
                0 as ::core::ffi::c_int as uint8_t,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
            ];
            let mut chr: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
            while chr < 256 as ::core::ffi::c_int {
                if (*ds1).transitions[chr as usize] == ds2 {
                    bitset_set(transitions.as_mut_ptr(), chr as ::core::ffi::c_uint);
                    empty = false_0 != 0;
                }
                chr += 1;
            }
            let ref mut fresh39 = (*arrows
                .as_mut_ptr()
                .offset((*ds1).id as isize * vla_0 as isize)
                .offset((*ds2).id as isize))
                .label;
            *fresh39 = 0 as *mut ::core::ffi::c_char;
            if !empty {
                let mut fmt: *mut ::core::ffi::c_char = symset_fmt(
                    transitions.as_mut_ptr(),
                );
                let ref mut fresh40 = (*arrows
                    .as_mut_ptr()
                    .offset((*ds1).id as isize * vla_0 as isize)
                    .offset((*ds2).id as isize))
                    .label;
                *fresh40 = malloc(strlen(fmt).wrapping_add(1 as size_t))
                    as *mut ::core::ffi::c_char;
                strcpy(
                    (*arrows
                        .as_mut_ptr()
                        .offset((*ds1).id as isize * vla_0 as isize)
                        .offset((*ds2).id as isize))
                        .label,
                    fmt,
                );
                (*arrows
                    .as_mut_ptr()
                    .offset((*ds1).id as isize * vla_0 as isize)
                    .offset((*ds2).id as isize))
                    .prec = SYMSET;
            }
            ds2 = (*ds2).next;
        }
        ds1 = (*ds1).next;
    }
    loop {
        let mut best_fit: ::core::ffi::c_int = 0;
        let mut min_degree: ::core::ffi::c_int = INT_MAX;
        let mut id1: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while id1 < dfa_size {
            let mut degree: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
            let mut id2: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
            while id2 < dfa_size {
                degree
                    += ((*arrows
                        .as_mut_ptr()
                        .offset(id1 as isize * vla_0 as isize)
                        .offset(id2 as isize))
                        .label != NULL as *mut ::core::ffi::c_char) as ::core::ffi::c_int
                        + ((*arrows
                            .as_mut_ptr()
                            .offset(id2 as isize * vla_0 as isize)
                            .offset(id1 as isize))
                            .label != NULL as *mut ::core::ffi::c_char)
                            as ::core::ffi::c_int;
                id2 += 1;
            }
            if !(degree == 0 as ::core::ffi::c_int) {
                if degree < min_degree {
                    min_degree = degree;
                    best_fit = id1;
                }
            }
            id1 += 1;
        }
        if min_degree == INT_MAX {
            break;
        }
        let mut id1_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while id1_0 <= dfa_size {
            if !(id1_0 == best_fit) {
                let mut id2_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                while id2_0 <= dfa_size {
                    if !(id2_0 == best_fit) {
                        let mut in_0: arrow = *arrows
                            .as_mut_ptr()
                            .offset(id1_0 as isize * vla_0 as isize)
                            .offset(best_fit as isize);
                        let mut out: arrow = *arrows
                            .as_mut_ptr()
                            .offset(best_fit as isize * vla_0 as isize)
                            .offset(id2_0 as isize);
                        let mut self_0: arrow = *arrows
                            .as_mut_ptr()
                            .offset(best_fit as isize * vla_0 as isize)
                            .offset(best_fit as isize);
                        let mut existing: arrow = *arrows
                            .as_mut_ptr()
                            .offset(id1_0 as isize * vla_0 as isize)
                            .offset(id2_0 as isize);
                        if !(in_0.label.is_null() || out.label.is_null()) {
                            let mut first: arrow = arrow {
                                label: 0 as *mut ::core::ffi::c_char,
                                prec: ALT,
                            };
                            let mut second: arrow = arrow {
                                label: 0 as *mut ::core::ffi::c_char,
                                prec: ALT,
                            };
                            let mut diff: ptrdiff_t = 0;
                            if self_0.label.is_null() || *self_0.label == 0 {
                                first = in_0;
                                second = out;
                            } else {
                                if in_0.prec as ::core::ffi::c_uint
                                    >= CONCAT as ::core::ffi::c_int as ::core::ffi::c_uint
                                    && self_0.prec as ::core::ffi::c_uint
                                        >= CONCAT as ::core::ffi::c_int as ::core::ffi::c_uint
                                    && {
                                        diff = strlen(in_0.label).wrapping_sub(strlen(self_0.label))
                                            as ptrdiff_t;
                                        diff >= 0 as ptrdiff_t
                                    }
                                    && strcmp(in_0.label.offset(diff as isize), self_0.label)
                                        == 0 as ::core::ffi::c_int
                                {
                                    if diff >= 1 as ptrdiff_t
                                        && !strchr(
                                                b"^-\\\0" as *const u8 as *const ::core::ffi::c_char,
                                                *in_0.label.offset((diff - 1 as ptrdiff_t) as isize)
                                                    as ::core::ffi::c_int,
                                            )
                                            .is_null()
                                        && (diff == 1 as ptrdiff_t
                                            || *in_0.label.offset((diff - 2 as ptrdiff_t) as isize)
                                                as ::core::ffi::c_int != '\\' as i32)
                                    {
                                        current_block = 18199910057808559459;
                                    } else if diff >= 2 as ptrdiff_t
                                        && strncmp(
                                            &mut *in_0.label.offset((diff - 2 as ptrdiff_t) as isize),
                                            b"\\x\0" as *const u8 as *const ::core::ffi::c_char,
                                            2 as size_t,
                                        ) == 0 as ::core::ffi::c_int
                                        && (diff == 2 as ptrdiff_t
                                            || *in_0.label.offset((diff - 3 as ptrdiff_t) as isize)
                                                as ::core::ffi::c_int != '\\' as i32)
                                    {
                                        current_block = 18199910057808559459;
                                    } else if diff >= 3 as ptrdiff_t
                                        && strncmp(
                                            &mut *in_0.label.offset((diff - 3 as ptrdiff_t) as isize),
                                            b"\\x\0" as *const u8 as *const ::core::ffi::c_char,
                                            2 as size_t,
                                        ) == 0 as ::core::ffi::c_int
                                        && (diff == 3 as ptrdiff_t
                                            || *in_0.label.offset((diff - 4 as ptrdiff_t) as isize)
                                                as ::core::ffi::c_int != '\\' as i32)
                                    {
                                        current_block = 18199910057808559459;
                                    } else {
                                        first.label = malloc(
                                            strlen(in_0.label)
                                                .wrapping_add(5 as size_t)
                                                .wrapping_add(1 as size_t),
                                        ) as *mut ::core::ffi::c_char;
                                        let mut p: *mut ::core::ffi::c_char = first.label;
                                        if diff != 0 as ptrdiff_t
                                            && (in_0.prec as ::core::ffi::c_uint)
                                                < CONCAT as ::core::ffi::c_int as ::core::ffi::c_uint
                                        {
                                            let fresh41 = p;
                                            p = p.offset(1);
                                            *fresh41 = '(' as i32 as ::core::ffi::c_char;
                                        }
                                        memcpy(
                                            p as *mut ::core::ffi::c_void,
                                            in_0.label as *const ::core::ffi::c_void,
                                            diff as size_t,
                                        );
                                        p = p.offset(diff as isize);
                                        if diff != 0 as ptrdiff_t
                                            && (in_0.prec as ::core::ffi::c_uint)
                                                < CONCAT as ::core::ffi::c_int as ::core::ffi::c_uint
                                        {
                                            let fresh42 = p;
                                            p = p.offset(1);
                                            *fresh42 = ')' as i32 as ::core::ffi::c_char;
                                        }
                                        if self_0.prec as ::core::ffi::c_uint
                                            <= QUANT as ::core::ffi::c_int as ::core::ffi::c_uint
                                        {
                                            let fresh43 = p;
                                            p = p.offset(1);
                                            *fresh43 = '(' as i32 as ::core::ffi::c_char;
                                        }
                                        strcpy(p, self_0.label);
                                        p = p.offset(strlen(self_0.label) as isize);
                                        if self_0.prec as ::core::ffi::c_uint
                                            <= QUANT as ::core::ffi::c_int as ::core::ffi::c_uint
                                        {
                                            let fresh44 = p;
                                            p = p.offset(1);
                                            *fresh44 = ')' as i32 as ::core::ffi::c_char;
                                        }
                                        let fresh45 = p;
                                        p = p.offset(1);
                                        *fresh45 = '+' as i32 as ::core::ffi::c_char;
                                        let fresh46 = p;
                                        p = p.offset(1);
                                        *fresh46 = '\0' as i32 as ::core::ffi::c_char;
                                        first.prec = CONCAT;
                                        second = out;
                                        current_block = 15587532755333643506;
                                    }
                                } else {
                                    current_block = 18199910057808559459;
                                }
                                match current_block {
                                    15587532755333643506 => {}
                                    _ => {
                                        if out.prec as ::core::ffi::c_uint
                                            >= CONCAT as ::core::ffi::c_int as ::core::ffi::c_uint
                                            && self_0.prec as ::core::ffi::c_uint
                                                >= CONCAT as ::core::ffi::c_int as ::core::ffi::c_uint
                                            && {
                                                diff = strlen(out.label).wrapping_sub(strlen(self_0.label))
                                                    as ptrdiff_t;
                                                diff >= 0 as ptrdiff_t
                                            }
                                            && strncmp(out.label, self_0.label, strlen(self_0.label))
                                                == 0 as ::core::ffi::c_int
                                        {
                                            second.label = malloc(
                                                strlen(out.label)
                                                    .wrapping_add(5 as size_t)
                                                    .wrapping_add(1 as size_t),
                                            ) as *mut ::core::ffi::c_char;
                                            let mut p_0: *mut ::core::ffi::c_char = second.label;
                                            if self_0.prec as ::core::ffi::c_uint
                                                <= QUANT as ::core::ffi::c_int as ::core::ffi::c_uint
                                            {
                                                let fresh47 = p_0;
                                                p_0 = p_0.offset(1);
                                                *fresh47 = '(' as i32 as ::core::ffi::c_char;
                                            }
                                            strcpy(p_0, self_0.label);
                                            p_0 = p_0.offset(strlen(self_0.label) as isize);
                                            if self_0.prec as ::core::ffi::c_uint
                                                <= QUANT as ::core::ffi::c_int as ::core::ffi::c_uint
                                            {
                                                let fresh48 = p_0;
                                                p_0 = p_0.offset(1);
                                                *fresh48 = ')' as i32 as ::core::ffi::c_char;
                                            }
                                            let fresh49 = p_0;
                                            p_0 = p_0.offset(1);
                                            *fresh49 = '+' as i32 as ::core::ffi::c_char;
                                            if diff != 0 as ptrdiff_t
                                                && (out.prec as ::core::ffi::c_uint)
                                                    < CONCAT as ::core::ffi::c_int as ::core::ffi::c_uint
                                            {
                                                let fresh50 = p_0;
                                                p_0 = p_0.offset(1);
                                                *fresh50 = '(' as i32 as ::core::ffi::c_char;
                                            }
                                            memcpy(
                                                p_0 as *mut ::core::ffi::c_void,
                                                out.label.offset(diff as isize)
                                                    as *const ::core::ffi::c_void,
                                                diff as size_t,
                                            );
                                            p_0 = p_0.offset(diff as isize);
                                            if diff != 0 as ptrdiff_t
                                                && (out.prec as ::core::ffi::c_uint)
                                                    < CONCAT as ::core::ffi::c_int as ::core::ffi::c_uint
                                            {
                                                let fresh51 = p_0;
                                                p_0 = p_0.offset(1);
                                                *fresh51 = ')' as i32 as ::core::ffi::c_char;
                                            }
                                            let fresh52 = p_0;
                                            p_0 = p_0.offset(1);
                                            *fresh52 = '\0' as i32 as ::core::ffi::c_char;
                                            second.prec = CONCAT;
                                            first = in_0;
                                        } else {
                                            second.label = malloc(
                                                strlen(self_0.label)
                                                    .wrapping_add(strlen(out.label))
                                                    .wrapping_add(5 as size_t)
                                                    .wrapping_add(1 as size_t),
                                            ) as *mut ::core::ffi::c_char;
                                            let mut p_1: *mut ::core::ffi::c_char = second.label;
                                            if self_0.prec as ::core::ffi::c_uint
                                                <= QUANT as ::core::ffi::c_int as ::core::ffi::c_uint
                                            {
                                                let fresh53 = p_1;
                                                p_1 = p_1.offset(1);
                                                *fresh53 = '(' as i32 as ::core::ffi::c_char;
                                            }
                                            strcpy(p_1, self_0.label);
                                            p_1 = p_1.offset(strlen(self_0.label) as isize);
                                            if self_0.prec as ::core::ffi::c_uint
                                                <= QUANT as ::core::ffi::c_int as ::core::ffi::c_uint
                                            {
                                                let fresh54 = p_1;
                                                p_1 = p_1.offset(1);
                                                *fresh54 = ')' as i32 as ::core::ffi::c_char;
                                            }
                                            let fresh55 = p_1;
                                            p_1 = p_1.offset(1);
                                            *fresh55 = '*' as i32 as ::core::ffi::c_char;
                                            if (out.prec as ::core::ffi::c_uint)
                                                < CONCAT as ::core::ffi::c_int as ::core::ffi::c_uint
                                            {
                                                let fresh56 = p_1;
                                                p_1 = p_1.offset(1);
                                                *fresh56 = '(' as i32 as ::core::ffi::c_char;
                                            }
                                            strcpy(p_1, out.label);
                                            p_1 = p_1.offset(strlen(out.label) as isize);
                                            if (out.prec as ::core::ffi::c_uint)
                                                < CONCAT as ::core::ffi::c_int as ::core::ffi::c_uint
                                            {
                                                let fresh57 = p_1;
                                                p_1 = p_1.offset(1);
                                                *fresh57 = ')' as i32 as ::core::ffi::c_char;
                                            }
                                            let fresh58 = p_1;
                                            p_1 = p_1.offset(1);
                                            *fresh58 = '\0' as i32 as ::core::ffi::c_char;
                                            second.prec = CONCAT;
                                            first = in_0;
                                        }
                                    }
                                }
                            }
                            let mut bypass: arrow = arrow {
                                label: 0 as *mut ::core::ffi::c_char,
                                prec: ALT,
                            };
                            if *first.label == 0 {
                                bypass = second;
                            } else if *second.label == 0 {
                                bypass = first;
                            } else {
                                bypass.label = malloc(
                                    strlen(first.label)
                                        .wrapping_add(strlen(second.label))
                                        .wrapping_add(4 as size_t)
                                        .wrapping_add(1 as size_t),
                                ) as *mut ::core::ffi::c_char;
                                let mut p_2: *mut ::core::ffi::c_char = bypass.label;
                                if (first.prec as ::core::ffi::c_uint)
                                    < CONCAT as ::core::ffi::c_int as ::core::ffi::c_uint
                                {
                                    let fresh59 = p_2;
                                    p_2 = p_2.offset(1);
                                    *fresh59 = '(' as i32 as ::core::ffi::c_char;
                                }
                                strcpy(p_2, first.label);
                                p_2 = p_2.offset(strlen(first.label) as isize);
                                if (first.prec as ::core::ffi::c_uint)
                                    < CONCAT as ::core::ffi::c_int as ::core::ffi::c_uint
                                {
                                    let fresh60 = p_2;
                                    p_2 = p_2.offset(1);
                                    *fresh60 = ')' as i32 as ::core::ffi::c_char;
                                }
                                if (second.prec as ::core::ffi::c_uint)
                                    < CONCAT as ::core::ffi::c_int as ::core::ffi::c_uint
                                {
                                    let fresh61 = p_2;
                                    p_2 = p_2.offset(1);
                                    *fresh61 = '(' as i32 as ::core::ffi::c_char;
                                }
                                strcpy(p_2, second.label);
                                p_2 = p_2.offset(strlen(second.label) as isize);
                                if (second.prec as ::core::ffi::c_uint)
                                    < CONCAT as ::core::ffi::c_int as ::core::ffi::c_uint
                                {
                                    let fresh62 = p_2;
                                    p_2 = p_2.offset(1);
                                    *fresh62 = ')' as i32 as ::core::ffi::c_char;
                                }
                                let fresh63 = p_2;
                                p_2 = p_2.offset(1);
                                *fresh63 = '\0' as i32 as ::core::ffi::c_char;
                                bypass.prec = CONCAT;
                            }
                            let mut merged: arrow = arrow {
                                label: 0 as *mut ::core::ffi::c_char,
                                prec: ALT,
                            };
                            if bypass.label.is_null() {
                                merged = existing;
                            } else if existing.label.is_null() {
                                if bypass.label == first.label
                                    || bypass.label == second.label
                                {
                                    merged.label = malloc(
                                        strlen(bypass.label).wrapping_add(1 as size_t),
                                    ) as *mut ::core::ffi::c_char;
                                    strcpy(merged.label, bypass.label);
                                    merged.prec = bypass.prec;
                                } else {
                                    merged = bypass;
                                }
                            } else if *existing.label == 0 {
                                merged.label = malloc(
                                    strlen(bypass.label)
                                        .wrapping_add(3 as size_t)
                                        .wrapping_add(1 as size_t),
                                ) as *mut ::core::ffi::c_char;
                                let mut p_3: *mut ::core::ffi::c_char = merged.label;
                                if bypass.prec as ::core::ffi::c_uint
                                    <= QUANT as ::core::ffi::c_int as ::core::ffi::c_uint
                                {
                                    let fresh64 = p_3;
                                    p_3 = p_3.offset(1);
                                    *fresh64 = '(' as i32 as ::core::ffi::c_char;
                                }
                                strcpy(p_3, bypass.label);
                                p_3 = p_3.offset(strlen(bypass.label) as isize);
                                if bypass.prec as ::core::ffi::c_uint
                                    <= QUANT as ::core::ffi::c_int as ::core::ffi::c_uint
                                {
                                    let fresh65 = p_3;
                                    p_3 = p_3.offset(1);
                                    *fresh65 = ')' as i32 as ::core::ffi::c_char;
                                }
                                let fresh66 = p_3;
                                p_3 = p_3.offset(1);
                                *fresh66 = '?' as i32 as ::core::ffi::c_char;
                                let fresh67 = p_3;
                                p_3 = p_3.offset(1);
                                *fresh67 = '\0' as i32 as ::core::ffi::c_char;
                                merged.prec = QUANT;
                            } else {
                                merged.label = malloc(
                                    strlen(existing.label)
                                        .wrapping_add(strlen(bypass.label))
                                        .wrapping_add(1 as size_t)
                                        .wrapping_add(1 as size_t),
                                ) as *mut ::core::ffi::c_char;
                                let mut p_4: *mut ::core::ffi::c_char = merged.label;
                                strcpy(p_4, existing.label);
                                p_4 = p_4.offset(strlen(existing.label) as isize);
                                let fresh68 = p_4;
                                p_4 = p_4.offset(1);
                                *fresh68 = '|' as i32 as ::core::ffi::c_char;
                                strcpy(p_4, bypass.label);
                                p_4 = p_4.offset(strlen(bypass.label) as isize);
                                let fresh69 = p_4;
                                p_4 = p_4.offset(1);
                                *fresh69 = '\0' as i32 as ::core::ffi::c_char;
                                merged.prec = ALT;
                            }
                            if first.label != in_0.label {
                                free(first.label as *mut ::core::ffi::c_void);
                            }
                            if second.label != out.label {
                                free(second.label as *mut ::core::ffi::c_void);
                            }
                            if bypass.label != first.label
                                && bypass.label != second.label
                                && bypass.label != merged.label
                            {
                                free(bypass.label as *mut ::core::ffi::c_void);
                            }
                            if existing.label != merged.label {
                                free(existing.label as *mut ::core::ffi::c_void);
                            }
                            *arrows
                                .as_mut_ptr()
                                .offset(id1_0 as isize * vla_0 as isize)
                                .offset(id2_0 as isize) = merged;
                        }
                    }
                    id2_0 += 1;
                }
            }
            id1_0 += 1;
        }
        let mut id_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while id_0 <= dfa_size {
            free(
                (*arrows
                    .as_mut_ptr()
                    .offset(id_0 as isize * vla_0 as isize)
                    .offset(best_fit as isize))
                    .label as *mut ::core::ffi::c_void,
            );
            let ref mut fresh70 = (*arrows
                .as_mut_ptr()
                .offset(id_0 as isize * vla_0 as isize)
                .offset(best_fit as isize))
                .label;
            *fresh70 = 0 as *mut ::core::ffi::c_char;
            free(
                (*arrows
                    .as_mut_ptr()
                    .offset(best_fit as isize * vla_0 as isize)
                    .offset(id_0 as isize))
                    .label as *mut ::core::ffi::c_void,
            );
            let ref mut fresh71 = (*arrows
                .as_mut_ptr()
                .offset(best_fit as isize * vla_0 as isize)
                .offset(id_0 as isize))
                .label;
            *fresh71 = 0 as *mut ::core::ffi::c_char;
            id_0 += 1;
        }
    }
    let mut regex: *mut ::core::ffi::c_char = (*arrows
        .as_mut_ptr()
        .offset(dfa_size as isize * vla_0 as isize)
        .offset(dfa_size as isize))
        .label;
    if regex.is_null() {
        regex = malloc(3 as size_t) as *mut ::core::ffi::c_char;
        strcpy(regex, b"[]\0" as *const u8 as *const ::core::ffi::c_char);
    }
    return regex;
}
