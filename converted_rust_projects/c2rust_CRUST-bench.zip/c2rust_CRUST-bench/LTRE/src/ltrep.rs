#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types, linkage)]
extern "C" {
    pub type nstate;
    pub type __sFILEX;
    fn nfa_free(nfa: nfa);
    fn dfa_free(dfa: *mut dstate);
    fn ltre_parse(
        regex: *mut *mut ::core::ffi::c_char,
        error: *mut *mut ::core::ffi::c_char,
    ) -> nfa;
    fn ltre_fixed_string(string: *mut ::core::ffi::c_char) -> nfa;
    fn ltre_partial(nfa: *mut nfa);
    fn ltre_ignorecase(nfa: *mut nfa);
    fn ltre_complement(nfa: *mut nfa);
    fn ltre_compile(nfa: nfa) -> *mut dstate;
    fn ltre_matches(dfa: *mut dstate, input: *mut uint8_t) -> bool;
    static mut _DefaultRuneLocale: _RuneLocale;
    fn __maskrune(_: __darwin_ct_rune_t, _: ::core::ffi::c_ulong) -> ::core::ffi::c_int;
    fn open(
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        ...
    ) -> ::core::ffi::c_int;
    static mut __stdinp: *mut FILE;
    static mut __stdoutp: *mut FILE;
    static mut __stderrp: *mut FILE;
    fn clearerr(_: *mut FILE);
    fn feof(_: *mut FILE) -> ::core::ffi::c_int;
    fn fgets(
        _: *mut ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *mut FILE,
    ) -> *mut ::core::ffi::c_char;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn fputc(_: ::core::ffi::c_int, _: *mut FILE) -> ::core::ffi::c_int;
    fn fputs(_: *const ::core::ffi::c_char, _: *mut FILE) -> ::core::ffi::c_int;
    fn fwrite(
        __ptr: *const ::core::ffi::c_void,
        __size: size_t,
        __nitems: size_t,
        __stream: *mut FILE,
    ) -> ::core::ffi::c_ulong;
    fn perror(_: *const ::core::ffi::c_char);
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn realloc(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn exit(_: ::core::ffi::c_int) -> !;
    fn memchr(
        __s: *const ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strchr(
        __s: *const ::core::ffi::c_char,
        __c: ::core::ffi::c_int,
    ) -> *mut ::core::ffi::c_char;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn mmap(
        _: *mut ::core::ffi::c_void,
        _: size_t,
        _: ::core::ffi::c_int,
        _: ::core::ffi::c_int,
        _: ::core::ffi::c_int,
        _: off_t,
    ) -> *mut ::core::ffi::c_void;
    fn close(_: ::core::ffi::c_int) -> ::core::ffi::c_int;
    fn lseek(_: ::core::ffi::c_int, _: off_t, _: ::core::ffi::c_int) -> off_t;
}
pub type __uint32_t = u32;
pub type __int64_t = i64;
pub type __darwin_ct_rune_t = ::core::ffi::c_int;
pub type __darwin_size_t = usize;
pub type __darwin_wchar_t = ::libc::wchar_t;
pub type __darwin_rune_t = __darwin_wchar_t;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct dstate {
    pub transitions: [*mut dstate; 256],
    pub accepting: bool,
    pub terminating: bool,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct nfa {
    pub initial: *mut nstate,
    pub final_0: *mut nstate,
    pub complemented: bool,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneEntry {
    pub __min: __darwin_rune_t,
    pub __max: __darwin_rune_t,
    pub __map: __darwin_rune_t,
    pub __types: *mut __uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneRange {
    pub __nranges: ::core::ffi::c_int,
    pub __ranges: *mut _RuneEntry,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneCharClass {
    pub __name: [::core::ffi::c_char; 14],
    pub __mask: __uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneLocale {
    pub __magic: [::core::ffi::c_char; 8],
    pub __encoding: [::core::ffi::c_char; 32],
    pub __sgetrune: Option<
        unsafe extern "C" fn(
            *const ::core::ffi::c_char,
            __darwin_size_t,
            *mut *const ::core::ffi::c_char,
        ) -> __darwin_rune_t,
    >,
    pub __sputrune: Option<
        unsafe extern "C" fn(
            __darwin_rune_t,
            *mut ::core::ffi::c_char,
            __darwin_size_t,
            *mut *mut ::core::ffi::c_char,
        ) -> ::core::ffi::c_int,
    >,
    pub __invalid_rune: __darwin_rune_t,
    pub __runetype: [__uint32_t; 256],
    pub __maplower: [__darwin_rune_t; 256],
    pub __mapupper: [__darwin_rune_t; 256],
    pub __runetype_ext: _RuneRange,
    pub __maplower_ext: _RuneRange,
    pub __mapupper_ext: _RuneRange,
    pub __variable: *mut ::core::ffi::c_void,
    pub __variable_len: ::core::ffi::c_int,
    pub __ncharclasses: ::core::ffi::c_int,
    pub __charclasses: *mut _RuneCharClass,
}
pub type off_t = __darwin_off_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct args {
    pub opts: C2RustUnnamed,
    pub regex: *mut ::core::ffi::c_char,
    pub files: *mut *mut ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct C2RustUnnamed {
    pub invert: bool,
    pub full: bool,
    pub ignore: bool,
    pub fixed: bool,
    pub lineno: bool,
    pub file: bool,
    pub count: bool,
    pub help: bool,
}
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const _CTYPE_U: ::core::ffi::c_long = 0x8000 as ::core::ffi::c_long;
#[inline]
unsafe extern "C" fn isascii(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return (_c & !(0x7f as ::core::ffi::c_int) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn __istype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> ::core::ffi::c_int {
    return if isascii(_c as ::core::ffi::c_int) != 0 {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    } else {
        (__maskrune(_c, _f) != 0) as ::core::ffi::c_int
    };
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isupper(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_U as ::core::ffi::c_ulong);
}
pub const O_RDONLY: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const SEEK_END: ::core::ffi::c_int = 2 as ::core::ffi::c_int;
pub const EXIT_FAILURE: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const EXIT_SUCCESS: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const PROT_READ: ::core::ffi::c_int = 0x1 as ::core::ffi::c_int;
pub const MAP_PRIVATE: ::core::ffi::c_int = 0x2 as ::core::ffi::c_int;
#[no_mangle]
pub static mut opts: *const ::core::ffi::c_char = b"v xpisF nNHIc h \0" as *const u8
    as *const ::core::ffi::c_char;
#[no_mangle]
pub unsafe extern "C" fn parse_args(mut argv: *mut *mut ::core::ffi::c_char) -> args {
    let mut args: args = {
        let mut init = args {
            opts: {
                let mut init = C2RustUnnamed {
                    invert: 0 as ::core::ffi::c_int != 0,
                    full: false,
                    ignore: false,
                    fixed: false,
                    lineno: false,
                    file: false,
                    count: false,
                    help: false,
                };
                init
            },
            regex: 0 as *mut ::core::ffi::c_char,
            files: 0 as *mut *mut ::core::ffi::c_char,
        };
        init
    };
    let mut smartcase: bool = false_0 != 0;
    argv = argv.offset(1);
    if (*argv).is_null() {
        fputs(
            b"LTREP - print lines matching a regex\nTry 'ltrep -h' for more information.\n\0"
                as *const u8 as *const ::core::ffi::c_char,
            __stdoutp,
        );
        exit(EXIT_FAILURE);
    }
    while !(*argv).is_null() && **argv as ::core::ffi::c_int == '-' as i32 {
        if strcmp(*argv, b"--\0" as *const u8 as *const ::core::ffi::c_char)
            == 0 as ::core::ffi::c_int
            && {
                let fresh0 = argv;
                argv = argv.offset(1);
                !fresh0.is_null()
            }
        {
            break;
        }
        let mut p: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
        let mut opt: *mut ::core::ffi::c_char = (*argv)
            .offset(1 as ::core::ffi::c_int as isize);
        while *opt != 0 {
            if *opt as ::core::ffi::c_int == 'S' as i32 {
                smartcase = true_0 != 0;
            } else {
                p = strchr(opts, *opt as ::core::ffi::c_int);
                if !p.is_null() && *opt as ::core::ffi::c_int != ' ' as i32 {
                    *(&mut args.opts as *mut C2RustUnnamed as *mut bool)
                        .offset(
                            (p.offset_from(opts) as ::core::ffi::c_long
                                >> 1 as ::core::ffi::c_int) as isize,
                        ) = p.offset_from(opts) as ::core::ffi::c_long
                        & 1 as ::core::ffi::c_long == 0;
                } else {
                    printf(
                        b"Unrecognized option '-%.*s'\nTry 'ltrep -h' for more information.\n\0"
                            as *const u8 as *const ::core::ffi::c_char,
                        (if *opt as ::core::ffi::c_int == '-' as i32 {
                            -(1 as ::core::ffi::c_int)
                        } else {
                            1 as ::core::ffi::c_int
                        }),
                        opt,
                    );
                    exit(EXIT_FAILURE);
                }
            }
            smartcase = (smartcase as ::core::ffi::c_int
                & (*opt as ::core::ffi::c_int != 'i' as i32
                    && *opt as ::core::ffi::c_int != 's' as i32) as ::core::ffi::c_int)
                as bool;
            opt = opt.offset(1);
        }
        argv = argv.offset(1);
    }
    if args.opts.help {
        fputs(
            b"LTREP - print lines matching a regex\nUsage:\n  ltrep [options...] [--] <regex> [files...]\nOptions:\n  -v     invert match; print non-matching lines\n  -x/-p  full match; match against whole lines\n  -i/-s  ignore case; match case-insensitively\n  -S     smart case; set '-i' if regex lowercase\n  -F     interpret the regex as a fixed string\n  -n/-N  prefix matching lines with line numbers\n  -H/-I  prefix matching lines with file names\n  -c     only print a count of matching lines\n  -h     display this help message and exit\nOptions '-i/-s' and '-S' override eachother.\nA '--' is needed when <regex> begins in '-'.\nA file of '-' denotes standard input. If no\nfiles are provided, read from standard input.\n\0"
                as *const u8 as *const ::core::ffi::c_char,
            __stdoutp,
        );
        exit(EXIT_SUCCESS);
    }
    if (*argv).is_null() {
        fputs(
            b"Usage:\n  ltrep [options...] [--] <regex> [files...]\nTry 'ltrep -h' for more information.\n\0"
                as *const u8 as *const ::core::ffi::c_char,
            __stdoutp,
        );
        exit(EXIT_FAILURE);
    }
    args.regex = *argv;
    argv = argv.offset(1);
    args.files = argv;
    if smartcase {
        args.opts.ignore = true_0 != 0;
        let mut c: *mut ::core::ffi::c_char = args.regex;
        while *c != 0 {
            args.opts.ignore = (args.opts.ignore as ::core::ffi::c_int
                & (isupper(*c as ::core::ffi::c_int) == 0) as ::core::ffi::c_int)
                as bool;
            c = c.offset(1);
        }
    }
    return args;
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut current_block: u64;
    let mut args: args = parse_args(argv);
    let mut error: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut loc: *mut ::core::ffi::c_char = args.regex;
    let mut nfa: nfa = if args.opts.fixed as ::core::ffi::c_int != 0 {
        ltre_fixed_string(loc)
    } else {
        ltre_parse(&mut loc, &mut error)
    };
    if !error.is_null() {
        fprintf(
            __stderrp,
            b"parse error: %s near '%.16s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            error,
            loc,
        );
        exit(EXIT_FAILURE);
    }
    if !args.opts.full {
        ltre_partial(&mut nfa);
    }
    if args.opts.ignore {
        ltre_ignorecase(&mut nfa);
    }
    if args.opts.invert {
        ltre_complement(&mut nfa);
    }
    let mut dfa: *mut dstate = ltre_compile(nfa);
    let mut count: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    if (*args.files).is_null() {
        current_block = 3640593987805443782;
    } else {
        current_block = 11636175345244025579;
    }
    's_50: loop {
        match current_block {
            3640593987805443782 => {
                let mut lineno: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                let mut len: size_t = 0 as size_t;
                let mut cap: size_t = 256 as size_t;
                let mut nl: *mut uint8_t = 0 as *mut uint8_t;
                let mut line: *mut uint8_t = malloc(cap) as *mut uint8_t;
                while !fgets(
                        (line as *mut ::core::ffi::c_char).offset(len as isize),
                        cap.wrapping_sub(len) as ::core::ffi::c_int,
                        __stdinp,
                    )
                    .is_null()
                {
                    nl = memchr(
                        line.offset(len as isize) as *const ::core::ffi::c_void,
                        '\n' as i32,
                        cap.wrapping_sub(len),
                    ) as *mut uint8_t;
                    if nl.is_null() {
                        if feof(__stdinp) == 0 {
                            len = cap.wrapping_sub(1 as size_t);
                            cap = cap.wrapping_mul(2 as size_t);
                            line = realloc(line as *mut ::core::ffi::c_void, cap)
                                as *mut uint8_t;
                            continue;
                        } else {
                            nl = memchr(
                                line.offset(len as isize) as *const ::core::ffi::c_void,
                                '\0' as i32,
                                cap.wrapping_sub(len),
                            ) as *mut uint8_t;
                        }
                    }
                    *nl = '\0' as i32 as uint8_t;
                    len = 0 as size_t;
                    let mut fresh1: *mut ::core::ffi::c_char = b"<stdin>\0" as *const u8
                        as *const ::core::ffi::c_char as *mut ::core::ffi::c_char;
                    let mut file: *mut *mut ::core::ffi::c_char = &mut fresh1
                        as *mut *mut ::core::ffi::c_char;
                    lineno += 1;
                    if ltre_matches(dfa, line) {
                        count += 1;
                        if !args.opts.count {
                            if args.opts.file {
                                printf(
                                    b"%s:\0" as *const u8 as *const ::core::ffi::c_char,
                                    *file,
                                );
                            }
                            if args.opts.lineno {
                                printf(
                                    b"%d:\0" as *const u8 as *const ::core::ffi::c_char,
                                    lineno,
                                );
                            }
                            fwrite(
                                line as *const ::core::ffi::c_void,
                                ::core::mem::size_of::<uint8_t>() as size_t,
                                nl.offset_from(line) as ::core::ffi::c_long as size_t,
                                __stdoutp,
                            );
                            fputc('\n' as i32, __stdoutp);
                        }
                    }
                }
                if feof(__stdinp) == 0 {
                    perror(b"fgets\0" as *const u8 as *const ::core::ffi::c_char);
                    exit(EXIT_FAILURE);
                }
                free(line as *mut ::core::ffi::c_void);
                clearerr(__stdinp);
                current_block = 11636175345244025579;
            }
            _ => {
                let mut file_0: *mut *mut ::core::ffi::c_char = 0
                    as *mut *mut ::core::ffi::c_char;
                loop {
                    let fresh2 = args.files;
                    args.files = args.files.offset(1);
                    file_0 = fresh2;
                    if (*file_0).is_null() {
                        break 's_50;
                    }
                    if strcmp(*file_0, b"-\0" as *const u8 as *const ::core::ffi::c_char)
                        == 0 as ::core::ffi::c_int
                    {
                        current_block = 3640593987805443782;
                        break;
                    }
                    let mut fd: ::core::ffi::c_int = open(*file_0, O_RDONLY);
                    if fd == -(1 as ::core::ffi::c_int) {
                        perror(b"open\0" as *const u8 as *const ::core::ffi::c_char);
                        exit(EXIT_FAILURE);
                    }
                    let mut len_0: size_t = lseek(fd, 0 as off_t, SEEK_END) as size_t;
                    let mut data: *mut uint8_t = mmap(
                        0 as *mut ::core::ffi::c_void,
                        len_0,
                        PROT_READ,
                        MAP_PRIVATE,
                        fd,
                        0 as off_t,
                    ) as *mut uint8_t;
                    let mut lineno_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                    let mut dstate: *mut dstate = dfa;
                    let mut nl_0: *mut uint8_t = data;
                    let mut line_0: *mut uint8_t = data;
                    while nl_0 < data.offset(len_0 as isize) {
                        dstate = dfa;
                        while !(*dstate).terminating
                            && *nl_0 as ::core::ffi::c_int != '\n' as i32
                            && nl_0 < data.offset(len_0 as isize)
                        {
                            dstate = (*dstate).transitions[*nl_0 as usize];
                            nl_0 = nl_0.offset(1);
                        }
                        if *nl_0 as ::core::ffi::c_int != '\n' as i32 {
                            nl_0 = memchr(
                                nl_0 as *const ::core::ffi::c_void,
                                '\n' as i32,
                                data.offset(len_0 as isize).offset_from(nl_0)
                                    as ::core::ffi::c_long as size_t,
                            ) as *mut uint8_t;
                            nl_0 = if !nl_0.is_null() {
                                nl_0
                            } else {
                                data.offset(len_0 as isize)
                            };
                        }
                        lineno_0 += 1;
                        if (*dstate).accepting {
                            count += 1;
                            if !args.opts.count {
                                if args.opts.file {
                                    printf(
                                        b"%s:\0" as *const u8 as *const ::core::ffi::c_char,
                                        *file_0,
                                    );
                                }
                                if args.opts.lineno {
                                    printf(
                                        b"%d:\0" as *const u8 as *const ::core::ffi::c_char,
                                        lineno_0,
                                    );
                                }
                                fwrite(
                                    line_0 as *const ::core::ffi::c_void,
                                    ::core::mem::size_of::<uint8_t>() as size_t,
                                    nl_0.offset_from(line_0) as ::core::ffi::c_long as size_t,
                                    __stdoutp,
                                );
                                fputc('\n' as i32, __stdoutp);
                            }
                        }
                        nl_0 = nl_0.offset(1);
                        line_0 = nl_0;
                    }
                    if close(fd) == -(1 as ::core::ffi::c_int) {
                        perror(b"close\0" as *const u8 as *const ::core::ffi::c_char);
                        exit(EXIT_FAILURE);
                    }
                }
            }
        }
    }
    if args.opts.count {
        printf(b"%d\n\0" as *const u8 as *const ::core::ffi::c_char, count);
    }
    nfa_free(nfa);
    dfa_free(dfa);
    return 0;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
