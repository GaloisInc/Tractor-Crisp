#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
use ::num_traits::ToPrimitive;
pub const LLONG_MAX: ::core::ffi::c_longlong = 0x7fffffffffffffff
    as ::core::ffi::c_longlong;
pub const LLONG_MIN: ::core::ffi::c_longlong = -(0x7fffffffffffffff
    as ::core::ffi::c_longlong) - 1 as ::core::ffi::c_longlong;
pub const S21_M_PI: ::core::ffi::c_double = 3.14159265358979323846264338327950288f64;
pub const S21_M_E: ::core::ffi::c_double = 2.71828182845904523536028747135266250f64;
pub const EPS_10: ::core::ffi::c_double = 1e-10f64;
pub const S21_NAN: ::core::ffi::c_double = 0.0f64 / 0.0f64;
pub const S21_INFINITY: ::core::ffi::c_double = 1.0f64 / 0.0f64;
#[no_mangle]
pub unsafe extern "C" fn castom_abs(mut x: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return if x > 0 as ::core::ffi::c_int { x } else { -x };
}
#[no_mangle]
pub unsafe extern "C" fn castom_acos(mut x: ::core::ffi::c_double) -> ::f128::f128 {
    return ::f128::f128::new(S21_M_PI / 2 as ::core::ffi::c_int as ::core::ffi::c_double)
        - castom_asin(x);
}
#[no_mangle]
pub unsafe extern "C" fn castom_asin(mut x: ::core::ffi::c_double) -> ::f128::f128 {
    let mut term: ::f128::f128 = ::f128::f128::new(x);
    let mut sum: ::f128::f128 = ::f128::f128::new(S21_NAN);
    if -1.0f64 < x && x < 1.0f64 {
        sum = term;
        x *= x;
        let mut k: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
        while castom_fabs(term.to_f64().unwrap()) > ::f128::f128::new(EPS_10) {
            term
                *= ::f128::f128::new(
                    x * k as ::core::ffi::c_double
                        / (k + 1 as ::core::ffi::c_int) as ::core::ffi::c_double,
                );
            sum += term / ::f128::f128::new(k + 2 as ::core::ffi::c_int);
            k += 2 as ::core::ffi::c_int;
        }
    } else if x == 1.0f64 {
        sum = ::f128::f128::new(S21_M_PI / 2.0f64);
    } else if x == -1.0f64 {
        sum = ::f128::f128::new(-S21_M_PI / 2.0f64);
    }
    return sum;
}
#[no_mangle]
pub unsafe extern "C" fn castom_atan(mut x: ::core::ffi::c_double) -> ::f128::f128 {
    return castom_asin(
        (::f128::f128::new(x) / castom_sqrt(1.0f64 + x * x)).to_f64().unwrap(),
    );
}
#[no_mangle]
pub unsafe extern "C" fn castom_ceil(mut x: ::core::ffi::c_double) -> ::f128::f128 {
    if x >= LLONG_MAX as ::core::ffi::c_double || x <= LLONG_MIN as ::core::ffi::c_double
        || x != x
    {
        return ::f128::f128::new(x);
    }
    let mut truncation: ::f128::f128 = ::f128::f128::new(x as ::core::ffi::c_longlong);
    return truncation
        + ::f128::f128::new((truncation < ::f128::f128::new(x)) as ::core::ffi::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn castom_cos(mut x: ::core::ffi::c_double) -> ::f128::f128 {
    x = castom_fmod(x, 2.0f64 * S21_M_PI).to_f64().unwrap();
    let mut t_s: ::f128::f128 = ::f128::f128::new(0 as ::core::ffi::c_int);
    let mut last: ::f128::f128 = ::f128::f128::new(1 as ::core::ffi::c_int);
    let mut k: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    while castom_fabs(last.to_f64().unwrap()) > ::f128::f128::new(EPS_10) {
        t_s += last;
        last
            *= ::f128::f128::new(
                -x * x / (2.0f64 * k as ::core::ffi::c_double - 1.0f64)
                    / (2.0f64 * k as ::core::ffi::c_double),
            );
        k += 1;
    }
    return t_s;
}
#[no_mangle]
pub unsafe extern "C" fn castom_exp(mut x: ::core::ffi::c_double) -> ::f128::f128 {
    let mut sum: ::f128::f128 = ::f128::f128::new(1.0);
    let mut cur: ::f128::f128 = ::f128::f128::new(1.0);
    let mut n: ::core::ffi::c_uint = 1 as ::core::ffi::c_uint;
    while castom_fabs(cur.to_f64().unwrap()) > ::f128::f128::new(EPS_10) {
        let fresh0 = n;
        n = n.wrapping_add(1);
        cur *= ::f128::f128::new(x) / ::f128::f128::new(fresh0);
        sum += cur;
    }
    return sum;
}
#[no_mangle]
pub unsafe extern "C" fn castom_fabs(mut x: ::core::ffi::c_double) -> ::f128::f128 {
    return if x > 0.0f64 { ::f128::f128::new(x) } else { -::f128::f128::new(x) };
}
#[no_mangle]
pub unsafe extern "C" fn castom_floor(mut x: ::core::ffi::c_double) -> ::f128::f128 {
    if x >= LLONG_MAX as ::core::ffi::c_double || x <= LLONG_MIN as ::core::ffi::c_double
        || x != x
    {
        return ::f128::f128::new(x);
    }
    let mut truncation: ::f128::f128 = ::f128::f128::new(x as ::core::ffi::c_longlong);
    return truncation
        - ::f128::f128::new((truncation > ::f128::f128::new(x)) as ::core::ffi::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn castom_fmod(
    mut x: ::core::ffi::c_double,
    mut y: ::core::ffi::c_double,
) -> ::f128::f128 {
    return ::f128::f128::new(x) - castom_trunc(x / y) * ::f128::f128::new(y);
}
#[no_mangle]
pub unsafe extern "C" fn castom_log(mut x: ::core::ffi::c_double) -> ::f128::f128 {
    let mut a: ::core::ffi::c_uint = 0 as ::core::ffi::c_uint;
    let mut b: ::core::ffi::c_double = 0 as ::core::ffi::c_int as ::core::ffi::c_double;
    if x > 0 as ::core::ffi::c_int as ::core::ffi::c_double {
        let mut d: ::core::ffi::c_uint = 0;
        let mut e: ::core::ffi::c_double = 0 as ::core::ffi::c_int
            as ::core::ffi::c_double;
        let mut c: ::core::ffi::c_double = 0 as ::core::ffi::c_int
            as ::core::ffi::c_double;
        let mut f: ::core::ffi::c_double = 0 as ::core::ffi::c_int
            as ::core::ffi::c_double;
        c = if x < 1.0f64 {
            1 as ::core::ffi::c_int as ::core::ffi::c_double / x
        } else {
            x
        };
        loop {
            c /= S21_M_E;
            if !(c > 1 as ::core::ffi::c_int as ::core::ffi::c_double) {
                break;
            }
            a = a.wrapping_add(1);
        }
        c = 1 as ::core::ffi::c_int as ::core::ffi::c_double
            / (c * S21_M_E - 1 as ::core::ffi::c_int as ::core::ffi::c_double);
        c = c + c + 1 as ::core::ffi::c_int as ::core::ffi::c_double;
        f = c * c;
        b = 0 as ::core::ffi::c_int as ::core::ffi::c_double;
        d = 1 as ::core::ffi::c_uint;
        c /= 2 as ::core::ffi::c_int as ::core::ffi::c_double;
        loop {
            e = b;
            b
                += 1 as ::core::ffi::c_int as ::core::ffi::c_double
                    / (d as ::core::ffi::c_double * c);
            if !(b - e != 0.) {
                break;
            }
            d = d.wrapping_add(2 as ::core::ffi::c_uint);
            c *= f;
        }
    } else {
        b = (x == 0 as ::core::ffi::c_int as ::core::ffi::c_double) as ::core::ffi::c_int
            as ::core::ffi::c_double / 0.0f64;
    }
    return ::f128::f128::new(
        if x < 1 as ::core::ffi::c_int as ::core::ffi::c_double {
            -(a as ::core::ffi::c_double + b)
        } else {
            a as ::core::ffi::c_double + b
        },
    );
}
#[no_mangle]
pub unsafe extern "C" fn castom_pow(
    mut base: ::core::ffi::c_double,
    mut exp: ::core::ffi::c_double,
) -> ::f128::f128 {
    let mut result: ::f128::f128 = ::f128::f128::ZERO;
    if base == 0.0f64 && exp != 0.0f64 {
        result = ::f128::f128::new(0.0);
    } else if exp < 0 as ::core::ffi::c_int as ::core::ffi::c_double {
        result = castom_pow(
            1 as ::core::ffi::c_int as ::core::ffi::c_double / base,
            -exp,
        );
    } else if base < 0.0f64 && exp != exp as ::core::ffi::c_long as ::core::ffi::c_double
    {
        result = ::f128::f128::new(-0.0f64 / 0.0f64);
    } else if exp == 0.0f64 {
        result = ::f128::f128::new(1.0);
    } else {
        let mut flag: ::f128::f128 = ::f128::f128::new(1.0);
        if base < 0 as ::core::ffi::c_int as ::core::ffi::c_double
            && exp as ::core::ffi::c_long % 2 as ::core::ffi::c_long != 0
        {
            flag = ::f128::f128::new(-1.0f64);
        }
        if base < 0 as ::core::ffi::c_int as ::core::ffi::c_double {
            base = -base;
        }
        let mut div: ::core::ffi::c_long = exp as ::core::ffi::c_long;
        let mut integerPart: ::f128::f128 = ::f128::f128::new(1 as ::core::ffi::c_int);
        let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while (i as ::core::ffi::c_long) < div {
            integerPart *= ::f128::f128::new(base);
            i += 1;
        }
        result = integerPart
            * castom_exp(
                (::f128::f128::new(exp - div as ::core::ffi::c_double)
                    * castom_log(base))
                    .to_f64()
                    .unwrap(),
            ) * flag;
    }
    return result;
}
#[no_mangle]
pub unsafe extern "C" fn castom_sin(mut x: ::core::ffi::c_double) -> ::f128::f128 {
    x = castom_fmod(x, 2.0f64 * S21_M_PI).to_f64().unwrap();
    let mut sum: ::f128::f128 = ::f128::f128::new(0.0);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i <= 20 as ::core::ffi::c_int {
        let mut fa: ::core::ffi::c_double = 1.0f64;
        let mut pow: ::core::ffi::c_double = 1.0f64;
        let mut j: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
        while j <= 2 as ::core::ffi::c_int * i + 1 as ::core::ffi::c_int {
            fa *= j as ::core::ffi::c_double;
            pow *= x;
            j += 1;
        }
        sum
            += ::f128::f128::new(
                (if i % 2 as ::core::ffi::c_int != 0 { -1.0f64 } else { 1.0f64 }) / fa
                    * pow,
            );
        i += 1;
    }
    return sum;
}
#[no_mangle]
pub unsafe extern "C" fn castom_sqrt(mut x: ::core::ffi::c_double) -> ::f128::f128 {
    if x != x || x < 0 as ::core::ffi::c_int as ::core::ffi::c_double {
        return ::f128::f128::new(S21_NAN);
    }
    let mut sqrt: ::core::ffi::c_double = 0.;
    let mut temp: ::core::ffi::c_double = 0.;
    sqrt = x / 2 as ::core::ffi::c_int as ::core::ffi::c_double;
    temp = 0 as ::core::ffi::c_int as ::core::ffi::c_double;
    while sqrt != temp {
        temp = sqrt;
        sqrt = (x / temp + temp) / 2 as ::core::ffi::c_int as ::core::ffi::c_double;
    }
    return ::f128::f128::new(sqrt);
}
#[no_mangle]
pub unsafe extern "C" fn castom_tan(mut x: ::core::ffi::c_double) -> ::f128::f128 {
    let mut result: ::f128::f128 = ::f128::f128::new(0.0);
    if x == 0.0f64 {
        result = ::f128::f128::new(0.0);
    } else if S21_M_PI / 6 as ::core::ffi::c_int as ::core::ffi::c_double == x {
        result = ::f128::f128::new(1 as ::core::ffi::c_int)
            / castom_sqrt(3 as ::core::ffi::c_int as ::core::ffi::c_double);
    } else if S21_M_PI / 4 as ::core::ffi::c_int as ::core::ffi::c_double == x {
        result = ::f128::f128::new(1.0);
    } else if S21_M_PI / 3 as ::core::ffi::c_int as ::core::ffi::c_double == x {
        result = castom_sqrt(3 as ::core::ffi::c_int as ::core::ffi::c_double);
    } else if S21_M_PI / 2 as ::core::ffi::c_int as ::core::ffi::c_double == x {
        result = ::f128::f128::new(S21_INFINITY);
    } else if S21_M_PI == x {
        result = ::f128::f128::new(0.0);
    } else if 3.0f64 * S21_M_PI / 2 as ::core::ffi::c_int as ::core::ffi::c_double == x {
        result = ::f128::f128::new(S21_INFINITY);
    } else if 2.0f64 * S21_M_PI == x {
        result = ::f128::f128::new(0.0);
    } else {
        result = castom_sin(x) / castom_cos(x);
    }
    return result;
}
#[no_mangle]
pub unsafe extern "C" fn castom_trunc(mut x: ::core::ffi::c_double) -> ::f128::f128 {
    return if x > 0.0f64 { castom_floor(x) } else { castom_ceil(x) };
}
