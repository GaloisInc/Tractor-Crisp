#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
}
pub type __int64_t = i64;
pub type __darwin_off_t = __int64_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type uint8_t = u8;
pub type u4 = uint8_t;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
unsafe extern "C" fn nand(mut a: bool, mut b: bool) -> bool {
    return !(a as ::core::ffi::c_int != 0 && b as ::core::ffi::c_int != 0);
}
unsafe extern "C" fn not(mut a: bool) -> bool {
    return nand(a, true_0 != 0);
}
unsafe extern "C" fn or(mut a: bool, mut b: bool) -> bool {
    return nand(not(a), not(b));
}
unsafe extern "C" fn and(mut a: bool, mut b: bool) -> bool {
    return not(nand(a, b));
}
unsafe extern "C" fn xor(mut a: bool, mut b: bool) -> bool {
    return or(and(a, not(b)), and(not(a), b));
}
unsafe extern "C" fn add_bit(
    mut a: bool,
    mut b: bool,
    mut carry: bool,
    mut carry_result: *mut bool,
) -> bool {
    *carry_result = and(or(a, b), or(and(a, b), carry));
    return xor(xor(a, b), carry);
}
unsafe extern "C" fn half_sub(
    mut a: bool,
    mut b: bool,
    mut carry_result: *mut bool,
) -> bool {
    *carry_result = and(not(a), b);
    return xor(a, b);
}
unsafe extern "C" fn sub_bit(
    mut a: bool,
    mut b: bool,
    mut carry: bool,
    mut carry_result: *mut bool,
) -> bool {
    let mut b1: bool = false;
    let mut b2: bool = false;
    let mut result: bool = half_sub(half_sub(a, b, &mut b1), carry, &mut b2);
    *carry_result = or(b1, b2);
    return result;
}
#[no_mangle]
pub unsafe extern "C" fn bll(mut x: bool) -> *const ::core::ffi::c_char {
    return if x as ::core::ffi::c_int != 0 {
        b"true\0" as *const u8 as *const ::core::ffi::c_char
    } else {
        b"false\0" as *const u8 as *const ::core::ffi::c_char
    };
}
#[no_mangle]
pub unsafe extern "C" fn print_add_bit(mut a: bool, mut b: bool, mut carry: bool) {
    printf(b"a      : %s\n\0" as *const u8 as *const ::core::ffi::c_char, bll(a));
    printf(b"b      : %s\n\0" as *const u8 as *const ::core::ffi::c_char, bll(b));
    printf(b"carry  : %s\n\0" as *const u8 as *const ::core::ffi::c_char, bll(carry));
    let mut res_carry: bool = false;
    printf(b"result :\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(
        b"  bit  : %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        bll(add_bit(a, b, carry, &mut res_carry)),
    );
    printf(
        b"  carry: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        bll(res_carry),
    );
}
pub const U4_MAX: ::core::ffi::c_int = 0o17 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn add_u4(mut a: u4, mut b: u4) -> u4 {
    let mut carry: bool = false_0 != 0;
    let mut result: u4 = 0 as u4;
    result = (result as ::core::ffi::c_int
        | (add_bit(
            a as ::core::ffi::c_int >> 0 as ::core::ffi::c_int
                & 0o1 as ::core::ffi::c_int != 0,
            b as ::core::ffi::c_int >> 0 as ::core::ffi::c_int
                & 0o1 as ::core::ffi::c_int != 0,
            carry,
            &mut carry,
        ) as u4 as ::core::ffi::c_int) << 0 as ::core::ffi::c_int) as u4;
    result = (result as ::core::ffi::c_int
        | (add_bit(
            a as ::core::ffi::c_int >> 1 as ::core::ffi::c_int
                & 0o1 as ::core::ffi::c_int != 0,
            b as ::core::ffi::c_int >> 1 as ::core::ffi::c_int
                & 0o1 as ::core::ffi::c_int != 0,
            carry,
            &mut carry,
        ) as u4 as ::core::ffi::c_int) << 1 as ::core::ffi::c_int) as u4;
    result = (result as ::core::ffi::c_int
        | (add_bit(
            a as ::core::ffi::c_int >> 2 as ::core::ffi::c_int
                & 0o1 as ::core::ffi::c_int != 0,
            b as ::core::ffi::c_int >> 2 as ::core::ffi::c_int
                & 0o1 as ::core::ffi::c_int != 0,
            carry,
            &mut carry,
        ) as u4 as ::core::ffi::c_int) << 2 as ::core::ffi::c_int) as u4;
    result = (result as ::core::ffi::c_int
        | (add_bit(
            a as ::core::ffi::c_int >> 3 as ::core::ffi::c_int
                & 0o1 as ::core::ffi::c_int != 0,
            b as ::core::ffi::c_int >> 3 as ::core::ffi::c_int
                & 0o1 as ::core::ffi::c_int != 0,
            carry,
            &mut carry,
        ) as u4 as ::core::ffi::c_int) << 3 as ::core::ffi::c_int) as u4;
    return result;
}
#[no_mangle]
pub unsafe extern "C" fn sub_u4(mut a: u4, mut b: u4) -> u4 {
    let mut carry: bool = false_0 != 0;
    let mut result: u4 = 0 as u4;
    result = (result as ::core::ffi::c_int
        | (sub_bit(
            a as ::core::ffi::c_int >> 0 as ::core::ffi::c_int
                & 0o1 as ::core::ffi::c_int != 0,
            b as ::core::ffi::c_int >> 0 as ::core::ffi::c_int
                & 0o1 as ::core::ffi::c_int != 0,
            carry,
            &mut carry,
        ) as u4 as ::core::ffi::c_int) << 0 as ::core::ffi::c_int) as u4;
    result = (result as ::core::ffi::c_int
        | (sub_bit(
            a as ::core::ffi::c_int >> 1 as ::core::ffi::c_int
                & 0o1 as ::core::ffi::c_int != 0,
            b as ::core::ffi::c_int >> 1 as ::core::ffi::c_int
                & 0o1 as ::core::ffi::c_int != 0,
            carry,
            &mut carry,
        ) as u4 as ::core::ffi::c_int) << 1 as ::core::ffi::c_int) as u4;
    result = (result as ::core::ffi::c_int
        | (sub_bit(
            a as ::core::ffi::c_int >> 2 as ::core::ffi::c_int
                & 0o1 as ::core::ffi::c_int != 0,
            b as ::core::ffi::c_int >> 2 as ::core::ffi::c_int
                & 0o1 as ::core::ffi::c_int != 0,
            carry,
            &mut carry,
        ) as u4 as ::core::ffi::c_int) << 2 as ::core::ffi::c_int) as u4;
    result = (result as ::core::ffi::c_int
        | (sub_bit(
            a as ::core::ffi::c_int >> 3 as ::core::ffi::c_int
                & 0o1 as ::core::ffi::c_int != 0,
            b as ::core::ffi::c_int >> 3 as ::core::ffi::c_int
                & 0o1 as ::core::ffi::c_int != 0,
            carry,
            &mut carry,
        ) as u4 as ::core::ffi::c_int) << 3 as ::core::ffi::c_int) as u4;
    return result;
}
#[no_mangle]
pub unsafe extern "C" fn check_add() -> bool {
    let mut a: u4 = 0 as u4;
    while (a as ::core::ffi::c_int) < U4_MAX {
        let mut b: u4 = 0 as u4;
        while (b as ::core::ffi::c_int) < U4_MAX {
            let mut my: u4 = add_u4(a, b);
            let mut h: u4 = (a as ::core::ffi::c_int + b as ::core::ffi::c_int
                & 0o17 as ::core::ffi::c_int) as u4;
            if my as ::core::ffi::c_int != h as ::core::ffi::c_int {
                fprintf(
                    __stderrp,
                    b"ERROR: Add failed with %d+%d:\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    a as ::core::ffi::c_int,
                    b as ::core::ffi::c_int,
                );
                fprintf(
                    __stderrp,
                    b"  My  : %d\n\0" as *const u8 as *const ::core::ffi::c_char,
                    my as ::core::ffi::c_int,
                );
                fprintf(
                    __stderrp,
                    b"  Real: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
                    my as ::core::ffi::c_int,
                );
                return false_0 != 0;
            }
            b = b.wrapping_add(1);
        }
        a = a.wrapping_add(1);
    }
    fprintf(
        __stderrp,
        b"Add works correctly\n\0" as *const u8 as *const ::core::ffi::c_char,
    );
    return true_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn check_sub() -> bool {
    let mut a: u4 = 0 as u4;
    while (a as ::core::ffi::c_int) < U4_MAX {
        let mut b: u4 = 0 as u4;
        while (b as ::core::ffi::c_int) < U4_MAX {
            let mut my: u4 = sub_u4(a, b);
            let mut h: u4 = (a as ::core::ffi::c_int - b as ::core::ffi::c_int
                & 0o17 as ::core::ffi::c_int) as u4;
            if my as ::core::ffi::c_int != h as ::core::ffi::c_int {
                fprintf(
                    __stderrp,
                    b"ERROR: Sub failed with %d-%d:\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    a as ::core::ffi::c_int,
                    b as ::core::ffi::c_int,
                );
                fprintf(
                    __stderrp,
                    b"  My  : %d\n\0" as *const u8 as *const ::core::ffi::c_char,
                    my as ::core::ffi::c_int,
                );
                fprintf(
                    __stderrp,
                    b"  Real: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
                    h as ::core::ffi::c_int,
                );
                return false_0 != 0;
            }
            b = b.wrapping_add(1);
        }
        a = a.wrapping_add(1);
    }
    fprintf(
        __stderrp,
        b"Sub works correctly\n\0" as *const u8 as *const ::core::ffi::c_char,
    );
    return true_0 != 0;
}
unsafe fn main_0() -> ::core::ffi::c_int {
    if !check_add() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            39 as ::core::ffi::c_int,
            b"check_add()\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !check_sub() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            40 as ::core::ffi::c_int,
            b"check_sub()\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
