#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(c_variadic, extern_types, linkage)]
extern "C" {
    pub type __sFILEX;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    static mut _DefaultRuneLocale: _RuneLocale;
    fn __maskrune(_: __darwin_ct_rune_t, _: ::core::ffi::c_ulong) -> ::core::ffi::c_int;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn fread(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
        __nitems: size_t,
        __stream: *mut FILE,
    ) -> ::core::ffi::c_ulong;
    fn fseek(
        _: *mut FILE,
        _: ::core::ffi::c_long,
        _: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn ftell(_: *mut FILE) -> ::core::ffi::c_long;
    fn rewind(_: *mut FILE);
    fn snprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn vsnprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        _: va_list,
    ) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strncmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> ::core::ffi::c_int;
}
pub type __builtin_va_list = *mut ::core::ffi::c_char;
pub type __uint32_t = u32;
pub type __int64_t = i64;
pub type __darwin_ct_rune_t = ::core::ffi::c_int;
pub type __darwin_size_t = usize;
pub type __darwin_wchar_t = ::libc::wchar_t;
pub type __darwin_rune_t = __darwin_wchar_t;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneEntry {
    pub __min: __darwin_rune_t,
    pub __max: __darwin_rune_t,
    pub __map: __darwin_rune_t,
    pub __types: *mut __uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneRange {
    pub __nranges: ::core::ffi::c_int,
    pub __ranges: *mut _RuneEntry,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneCharClass {
    pub __name: [::core::ffi::c_char; 14],
    pub __mask: __uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneLocale {
    pub __magic: [::core::ffi::c_char; 8],
    pub __encoding: [::core::ffi::c_char; 32],
    pub __sgetrune: Option<
        unsafe extern "C" fn(
            *const ::core::ffi::c_char,
            __darwin_size_t,
            *mut *const ::core::ffi::c_char,
        ) -> __darwin_rune_t,
    >,
    pub __sputrune: Option<
        unsafe extern "C" fn(
            __darwin_rune_t,
            *mut ::core::ffi::c_char,
            __darwin_size_t,
            *mut *mut ::core::ffi::c_char,
        ) -> ::core::ffi::c_int,
    >,
    pub __invalid_rune: __darwin_rune_t,
    pub __runetype: [__uint32_t; 256],
    pub __maplower: [__darwin_rune_t; 256],
    pub __mapupper: [__darwin_rune_t; 256],
    pub __runetype_ext: _RuneRange,
    pub __maplower_ext: _RuneRange,
    pub __mapupper_ext: _RuneRange,
    pub __variable: *mut ::core::ffi::c_void,
    pub __variable_len: ::core::ffi::c_int,
    pub __ncharclasses: ::core::ffi::c_int,
    pub __charclasses: *mut _RuneCharClass,
}
pub type va_list = __builtin_va_list;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type uint8_t = u8;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct CfgError {
    pub off: ::core::ffi::c_int,
    pub col: ::core::ffi::c_int,
    pub row: ::core::ffi::c_int,
    pub msg: [::core::ffi::c_char; 64],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct CfgColor {
    pub r: uint8_t,
    pub g: uint8_t,
    pub b: uint8_t,
    pub a: uint8_t,
}
pub type CfgValType = ::core::ffi::c_uint;
pub const CFG_TYPE_COLOR: CfgValType = 4;
pub const CFG_TYPE_FLOAT: CfgValType = 3;
pub const CFG_TYPE_INT: CfgValType = 2;
pub const CFG_TYPE_BOOL: CfgValType = 1;
pub const CFG_TYPE_STRING: CfgValType = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub union CfgVal {
    pub string: [::core::ffi::c_char; 65],
    pub boolean: bool,
    pub integer: ::core::ffi::c_int,
    pub floating: ::core::ffi::c_float,
    pub color: CfgColor,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct CfgEntry {
    pub type_0: CfgValType,
    pub key: [::core::ffi::c_char; 33],
    pub val: CfgVal,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Cfg {
    pub entries: *mut CfgEntry,
    pub count: ::core::ffi::c_int,
    pub capacity: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Scanner {
    pub src: *const ::core::ffi::c_char,
    pub len: ::core::ffi::c_int,
    pub cur: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const _CACHED_RUNES: ::core::ffi::c_int = (1 as ::core::ffi::c_int)
    << 8 as ::core::ffi::c_int;
pub const _CTYPE_A: ::core::ffi::c_long = 0x100 as ::core::ffi::c_long;
pub const _CTYPE_D: ::core::ffi::c_long = 0x400 as ::core::ffi::c_long;
pub const _CTYPE_P: ::core::ffi::c_long = 0x2000 as ::core::ffi::c_long;
pub const _CTYPE_S: ::core::ffi::c_long = 0x4000 as ::core::ffi::c_long;
pub const _CTYPE_B: ::core::ffi::c_long = 0x20000 as ::core::ffi::c_long;
#[inline]
unsafe extern "C" fn isascii(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return (_c & !(0x7f as ::core::ffi::c_int) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn __istype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> ::core::ffi::c_int {
    return if isascii(_c as ::core::ffi::c_int) != 0 {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    } else {
        (__maskrune(_c, _f) != 0) as ::core::ffi::c_int
    };
}
#[inline]
unsafe extern "C" fn __isctype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> __darwin_ct_rune_t {
    return if _c < 0 as ::core::ffi::c_int || _c >= _CACHED_RUNES {
        0 as __darwin_ct_rune_t
    } else {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    };
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isalnum(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(
        _c as __darwin_ct_rune_t,
        (_CTYPE_A | _CTYPE_D) as ::core::ffi::c_ulong,
    );
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isalpha(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_A as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isblank(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_B as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isdigit(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __isctype(_c as __darwin_ct_rune_t, _CTYPE_D as ::core::ffi::c_ulong)
        as ::core::ffi::c_int;
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn ispunct(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_P as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isspace(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_S as ::core::ffi::c_ulong);
}
pub const INT_MAX: ::core::ffi::c_int = 2147483647 as ::core::ffi::c_int;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const SEEK_END: ::core::ffi::c_int = 2 as ::core::ffi::c_int;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const CFG_FILE_EXT: [::core::ffi::c_char; 5] = unsafe {
    ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b".cfg\0")
};
pub const CFG_MAX_KEY: ::core::ffi::c_int = 32 as ::core::ffi::c_int;
pub const CFG_MAX_VAL: ::core::ffi::c_int = 64 as ::core::ffi::c_int;
pub const CFG_MAX_ERR: ::core::ffi::c_int = 64 as ::core::ffi::c_int;
unsafe extern "C" fn init_scanner(
    mut s: *mut Scanner,
    mut src: *const ::core::ffi::c_char,
    mut src_len: ::core::ffi::c_int,
) {
    (*s).src = src;
    (*s).len = src_len;
    (*s).cur = 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn is_at_end(mut s: *mut Scanner) -> bool {
    return (*s).cur >= (*s).len;
}
unsafe extern "C" fn cur(mut s: *mut Scanner) -> ::core::ffi::c_int {
    return (*s).cur;
}
unsafe extern "C" fn set_cur(mut s: *mut Scanner, mut n: ::core::ffi::c_int) {
    (*s).cur = n;
}
unsafe extern "C" fn peek(mut s: *mut Scanner) -> ::core::ffi::c_char {
    return *(*s).src.offset((*s).cur as isize);
}
unsafe extern "C" fn peek_next(mut s: *mut Scanner) -> ::core::ffi::c_char {
    if (*s).cur >= (*s).len - 1 as ::core::ffi::c_int {
        return '\0' as i32 as ::core::ffi::c_char;
    }
    return *(*s).src.offset(((*s).cur + 1 as ::core::ffi::c_int) as isize);
}
unsafe extern "C" fn advance(mut s: *mut Scanner) -> ::core::ffi::c_char {
    let fresh0 = (*s).cur;
    (*s).cur = (*s).cur + 1;
    return *(*s).src.offset(fresh0 as isize);
}
unsafe extern "C" fn advance2(
    mut s: *mut Scanner,
    mut n: ::core::ffi::c_int,
) -> ::core::ffi::c_char {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < n - 1 as ::core::ffi::c_int {
        (*s).cur += 1;
        i += 1;
    }
    let fresh1 = (*s).cur;
    (*s).cur = (*s).cur + 1;
    return *(*s).src.offset(fresh1 as isize);
}
unsafe extern "C" fn skip_whitespace(mut s: *mut Scanner) {
    while !is_at_end(s) && isspace(peek(s) as ::core::ffi::c_int) != 0 {
        advance(s);
    }
}
unsafe extern "C" fn skip_blank(mut s: *mut Scanner) {
    while !is_at_end(s) && isspace(peek(s) as ::core::ffi::c_int) != 0
        && peek(s) as ::core::ffi::c_int != '\n' as i32
    {
        advance(s);
    }
}
unsafe extern "C" fn skip_comment(mut s: *mut Scanner) {
    while !is_at_end(s) && peek(s) as ::core::ffi::c_int == '#' as i32 {
        loop {
            advance(s);
            if !(!is_at_end(s) && peek(s) as ::core::ffi::c_int != '\n' as i32) {
                break;
            }
        }
    }
}
#[no_mangle]
pub unsafe extern "C" fn skip_whitespace_and_comments(mut s: *mut Scanner) {
    while !is_at_end(s)
        && (isspace(peek(s) as ::core::ffi::c_int) != 0
            || peek(s) as ::core::ffi::c_int == '#' as i32)
    {
        skip_whitespace(s);
        skip_comment(s);
    }
}
unsafe extern "C" fn copy_slice_into(
    mut s: *mut Scanner,
    mut src_off: ::core::ffi::c_int,
    mut src_len: ::core::ffi::c_int,
    mut dst: *mut ::core::ffi::c_char,
    mut max: ::core::ffi::c_int,
) {
    if !(src_len < max) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"copy_slice_into\0")
                .as_ptr(),
            b"config.c\0" as *const u8 as *const ::core::ffi::c_char,
            107 as ::core::ffi::c_int,
            b"src_len < max\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    memcpy(
        dst as *mut ::core::ffi::c_void,
        (*s).src.offset(src_off as isize) as *const ::core::ffi::c_void,
        src_len as size_t,
    );
    *dst.offset(src_len as isize) = '\0' as i32 as ::core::ffi::c_char;
}
unsafe extern "C" fn match_literal(
    mut s: *mut Scanner,
    mut offset: ::core::ffi::c_int,
    mut literal: *const ::core::ffi::c_char,
    mut len: ::core::ffi::c_int,
) -> bool {
    if offset + len > (*s).len {
        return false_0 != 0;
    }
    return strncmp((*s).src.offset(offset as isize), literal, len as size_t) == 0;
}
unsafe extern "C" fn consume_literal(
    mut s: *mut Scanner,
    mut offset: ::core::ffi::c_int,
    mut literal: *const ::core::ffi::c_char,
    mut len: ::core::ffi::c_int,
) -> bool {
    if match_literal(s, offset, literal, len) {
        advance2(s, len);
        return true_0 != 0;
    }
    return false_0 != 0;
}
unsafe extern "C" fn is_key(mut ch: ::core::ffi::c_char) -> bool {
    return isalpha(ch as ::core::ffi::c_int) != 0
        || ch as ::core::ffi::c_int == '.' as i32
        || ch as ::core::ffi::c_int == '_' as i32;
}
unsafe extern "C" fn is_string(mut ch: ::core::ffi::c_char) -> bool {
    return isalnum(ch as ::core::ffi::c_int) != 0
        || isblank(ch as ::core::ffi::c_int) != 0
        || ispunct(ch as ::core::ffi::c_int) != 0
            && ch as ::core::ffi::c_int != '"' as i32;
}
unsafe extern "C" fn init_error(mut err: *mut CfgError) {
    (*err).off = -(1 as ::core::ffi::c_int);
    (*err).col = -(1 as ::core::ffi::c_int);
    (*err).row = -(1 as ::core::ffi::c_int);
    (*err).msg[0 as ::core::ffi::c_int as usize] = '\0' as i32 as ::core::ffi::c_char;
}
unsafe extern "C" fn error(
    mut s: *mut Scanner,
    mut err: *mut CfgError,
    mut fmt: *const ::core::ffi::c_char,
    mut args: ...
) -> ::core::ffi::c_int {
    let prefix: [::core::ffi::c_char; 1] = ::core::mem::transmute::<
        [u8; 1],
        [::core::ffi::c_char; 1],
    >(*b"\0");
    let prefix_len: ::core::ffi::c_int = (::core::mem::size_of::<
        [::core::ffi::c_char; 1],
    >() as usize)
        .wrapping_sub(1 as usize) as ::core::ffi::c_int;
    (*err).off = cur(s);
    (*err).row = 1 as ::core::ffi::c_int;
    (*err).col = 1 as ::core::ffi::c_int;
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < cur(s) {
        (*err).col += 1;
        if *(*s).src.offset(i as isize) as ::core::ffi::c_int == '\n' as i32 {
            (*err).row += 1;
            (*err).col = 1 as ::core::ffi::c_int;
        }
        i += 1;
    }
    let mut vargs: va_list = 0 as *mut ::core::ffi::c_char;
    vargs = args.clone();
    snprintf((*err).msg.as_mut_ptr(), CFG_MAX_ERR as size_t, prefix.as_ptr());
    vsnprintf(
        (*err).msg.as_mut_ptr().offset(prefix_len as isize),
        (CFG_MAX_ERR - prefix_len) as size_t,
        fmt,
        vargs,
    );
    return -(1 as ::core::ffi::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn cfg_fprint_error(
    mut stream: *mut FILE,
    mut err: *mut CfgError,
) {
    if (*err).row == -(1 as ::core::ffi::c_int)
        && (*err).col == -(1 as ::core::ffi::c_int)
    {
        fprintf(
            stream,
            b"Error: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            (*err).msg.as_mut_ptr(),
        );
    } else {
        fprintf(
            stream,
            b"Error at %d:%d :: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            (*err).row,
            (*err).col,
            (*err).msg.as_mut_ptr(),
        );
    };
}
unsafe extern "C" fn parse_string(
    mut s: *mut Scanner,
    mut entry: *mut CfgEntry,
    mut err: *mut CfgError,
) -> ::core::ffi::c_int {
    advance(s);
    let mut val_offset: ::core::ffi::c_int = cur(s);
    while !is_at_end(s) && is_string(peek(s)) as ::core::ffi::c_int != 0 {
        advance(s);
    }
    if is_at_end(s) as ::core::ffi::c_int != 0
        || peek(s) as ::core::ffi::c_int != '"' as i32
    {
        return error(
            s,
            err,
            b"closing '\"' expected\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    let mut val_len: ::core::ffi::c_int = cur(s) - val_offset;
    if val_len > CFG_MAX_VAL {
        return error(
            s,
            err,
            b"value too long\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    advance(s);
    copy_slice_into(
        s,
        val_offset,
        val_len,
        (*entry).val.string.as_mut_ptr(),
        ::core::mem::size_of::<[::core::ffi::c_char; 65]>() as ::core::ffi::c_int,
    );
    (*entry).type_0 = CFG_TYPE_STRING;
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn consume_int(
    mut s: *mut Scanner,
    mut number: *mut ::core::ffi::c_int,
    mut err: *mut CfgError,
) -> ::core::ffi::c_int {
    let mut sign: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    let mut num: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    if !is_at_end(s) && peek(s) as ::core::ffi::c_int == '-' as i32
        && isdigit(peek_next(s) as ::core::ffi::c_int) != 0
    {
        advance(s);
        sign = -(1 as ::core::ffi::c_int);
    }
    if !is_at_end(s) && isdigit(peek(s) as ::core::ffi::c_int) == 0 {
        return error(
            s,
            err,
            b"number expected\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    while !is_at_end(s) && isdigit(peek(s) as ::core::ffi::c_int) != 0 {
        let mut digit: ::core::ffi::c_int = advance(s) as ::core::ffi::c_int
            - '0' as i32;
        if num > (INT_MAX - digit) / 10 as ::core::ffi::c_int {
            return error(
                s,
                err,
                b"number too large\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        num = num * 10 as ::core::ffi::c_int + digit;
    }
    *number = sign * num;
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn consume_float(
    mut s: *mut Scanner,
    mut number: *mut ::core::ffi::c_float,
    mut err: *mut CfgError,
) -> ::core::ffi::c_int {
    let mut sign: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    let mut int_part: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut fract_part: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    if !is_at_end(s) && peek(s) as ::core::ffi::c_int == '-' as i32
        && isdigit(peek_next(s) as ::core::ffi::c_int) != 0
    {
        advance(s);
        sign = -(1 as ::core::ffi::c_int);
    }
    if !is_at_end(s) && isdigit(peek(s) as ::core::ffi::c_int) == 0 {
        return error(
            s,
            err,
            b"number expected\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    while !is_at_end(s) && isdigit(peek(s) as ::core::ffi::c_int) != 0 {
        let mut digit: ::core::ffi::c_int = advance(s) as ::core::ffi::c_int
            - '0' as i32;
        if int_part > (INT_MAX - digit) / 10 as ::core::ffi::c_int {
            return error(
                s,
                err,
                b"number too large\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        int_part = int_part * 10 as ::core::ffi::c_int + digit;
    }
    if !is_at_end(s) && peek(s) as ::core::ffi::c_int != '.' as i32 {
        return error(
            s,
            err,
            b"float expected\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    advance(s);
    let mut div: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    while !is_at_end(s) && isdigit(peek(s) as ::core::ffi::c_int) != 0 {
        let mut digit_0: ::core::ffi::c_int = advance(s) as ::core::ffi::c_int
            - '0' as i32;
        if fract_part > (INT_MAX - digit_0) / 10 as ::core::ffi::c_int {
            return error(
                s,
                err,
                b"number too large\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        fract_part = fract_part * 10 as ::core::ffi::c_int + digit_0;
        if div > INT_MAX / 10 as ::core::ffi::c_int {
            return error(
                s,
                err,
                b"number too large\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        div *= 10 as ::core::ffi::c_int;
    }
    let mut floating: ::core::ffi::c_float = int_part as ::core::ffi::c_float
        + fract_part as ::core::ffi::c_float / div as ::core::ffi::c_float;
    *number = sign as ::core::ffi::c_float * floating;
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn match_float(mut s: *mut Scanner) -> bool {
    let mut restore: ::core::ffi::c_int = cur(s);
    let mut is_float: bool = false_0 != 0;
    if !is_at_end(s) && peek(s) as ::core::ffi::c_int == '-' as i32
        && isdigit(peek_next(s) as ::core::ffi::c_int) != 0
    {
        advance(s);
    }
    while !is_at_end(s) && isdigit(peek(s) as ::core::ffi::c_int) != 0 {
        advance(s);
    }
    if !is_at_end(s) && peek(s) as ::core::ffi::c_int == '.' as i32 {
        is_float = true_0 != 0;
    }
    set_cur(s, restore);
    return is_float;
}
unsafe extern "C" fn parse_number(
    mut s: *mut Scanner,
    mut entry: *mut CfgEntry,
    mut err: *mut CfgError,
) -> ::core::ffi::c_int {
    if match_float(s) {
        let mut number: ::core::ffi::c_float = 0.;
        if consume_float(s, &mut number, err) != 0 as ::core::ffi::c_int {
            return -(1 as ::core::ffi::c_int);
        }
        (*entry).val.floating = number;
        (*entry).type_0 = CFG_TYPE_FLOAT;
    } else {
        let mut number_0: ::core::ffi::c_int = 0;
        if consume_int(s, &mut number_0, err) != 0 as ::core::ffi::c_int {
            return -(1 as ::core::ffi::c_int);
        }
        (*entry).val.integer = number_0;
        (*entry).type_0 = CFG_TYPE_INT;
    }
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn parse_rgba(
    mut s: *mut Scanner,
    mut entry: *mut CfgEntry,
    mut err: *mut CfgError,
) -> ::core::ffi::c_int {
    if !consume_literal(
        s,
        cur(s),
        b"rgba\0" as *const u8 as *const ::core::ffi::c_char,
        4 as ::core::ffi::c_int,
    ) {
        return error(
            s,
            err,
            b"invalid literal\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    skip_blank(s);
    if is_at_end(s) as ::core::ffi::c_int != 0
        || peek(s) as ::core::ffi::c_int != '(' as i32
    {
        return error(
            s,
            err,
            b"'(' expected\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    advance(s);
    let mut rgb: [uint8_t; 3] = [0; 3];
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < 3 as ::core::ffi::c_int {
        skip_blank(s);
        if match_float(s) {
            return error(
                s,
                err,
                b"red, blue and green must be integers in range [0, 255]\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        }
        let mut number: ::core::ffi::c_int = 0;
        if consume_int(s, &mut number, err) != 0 as ::core::ffi::c_int {
            return -(1 as ::core::ffi::c_int);
        }
        if number < 0 as ::core::ffi::c_int || number > 255 as ::core::ffi::c_int {
            return error(
                s,
                err,
                b"red, blue and green must be integers in range [0, 255]\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        }
        rgb[i as usize] = number as uint8_t;
        skip_blank(s);
        if is_at_end(s) as ::core::ffi::c_int != 0
            || peek(s) as ::core::ffi::c_int != ',' as i32
        {
            return error(
                s,
                err,
                b"',' expected\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        advance(s);
        i += 1;
    }
    skip_blank(s);
    let mut alpha: uint8_t = 0;
    if match_float(s) {
        let mut number_0: ::core::ffi::c_float = 0.;
        if consume_float(s, &mut number_0, err) != 0 as ::core::ffi::c_int {
            return -(1 as ::core::ffi::c_int);
        }
        if number_0 < 0 as ::core::ffi::c_int as ::core::ffi::c_float
            || number_0 > 1 as ::core::ffi::c_int as ::core::ffi::c_float
        {
            return error(
                s,
                err,
                b"alpha must be in range [0, 1]\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        }
        alpha = (number_0 * 255 as ::core::ffi::c_int as ::core::ffi::c_float)
            as uint8_t;
    } else {
        let mut number_1: ::core::ffi::c_int = 0;
        if consume_int(s, &mut number_1, err) != 0 as ::core::ffi::c_int {
            return -(1 as ::core::ffi::c_int);
        }
        if number_1 < 0 as ::core::ffi::c_int || number_1 > 1 as ::core::ffi::c_int {
            return error(
                s,
                err,
                b"alpha must be in range [0, 1]\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        }
        alpha = (number_1 * 255 as ::core::ffi::c_int) as uint8_t;
    }
    skip_blank(s);
    if is_at_end(s) as ::core::ffi::c_int != 0
        || peek(s) as ::core::ffi::c_int != ')' as i32
    {
        return error(
            s,
            err,
            b"')' expected\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    advance(s);
    (*entry).val.color = {
        let mut init = CfgColor {
            r: rgb[0 as ::core::ffi::c_int as usize],
            g: rgb[1 as ::core::ffi::c_int as usize],
            b: rgb[2 as ::core::ffi::c_int as usize],
            a: alpha,
        };
        init
    };
    (*entry).type_0 = CFG_TYPE_COLOR;
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn parse_true(
    mut s: *mut Scanner,
    mut entry: *mut CfgEntry,
    mut err: *mut CfgError,
) -> ::core::ffi::c_int {
    if !consume_literal(
        s,
        cur(s),
        b"true\0" as *const u8 as *const ::core::ffi::c_char,
        4 as ::core::ffi::c_int,
    ) {
        return error(
            s,
            err,
            b"invalid literal\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    (*entry).val.boolean = true_0 != 0;
    (*entry).type_0 = CFG_TYPE_BOOL;
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn parse_false(
    mut s: *mut Scanner,
    mut entry: *mut CfgEntry,
    mut err: *mut CfgError,
) -> ::core::ffi::c_int {
    if !consume_literal(
        s,
        cur(s),
        b"false\0" as *const u8 as *const ::core::ffi::c_char,
        5 as ::core::ffi::c_int,
    ) {
        return error(
            s,
            err,
            b"invalid literal\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    (*entry).val.boolean = false_0 != 0;
    (*entry).type_0 = CFG_TYPE_BOOL;
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn parse_literal(
    mut s: *mut Scanner,
    mut entry: *mut CfgEntry,
    mut err: *mut CfgError,
) -> ::core::ffi::c_int {
    match peek(s) as ::core::ffi::c_int {
        116 => return parse_true(s, entry, err),
        102 => return parse_false(s, entry, err),
        114 => return parse_rgba(s, entry, err),
        _ => {
            return error(
                s,
                err,
                b"invalid literal\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
    };
}
unsafe extern "C" fn parse_value(
    mut s: *mut Scanner,
    mut entry: *mut CfgEntry,
    mut err: *mut CfgError,
) -> ::core::ffi::c_int {
    skip_blank(s);
    if is_at_end(s) as ::core::ffi::c_int != 0
        || peek(s) as ::core::ffi::c_int == '\n' as i32
    {
        return error(
            s,
            err,
            b"missing value\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    let mut c: ::core::ffi::c_char = peek(s);
    if c as ::core::ffi::c_int == '"' as i32 {
        return parse_string(s, entry, err)
    } else if isalpha(c as ::core::ffi::c_int) != 0 {
        return parse_literal(s, entry, err)
    } else if isdigit(c as ::core::ffi::c_int) != 0
        || c as ::core::ffi::c_int == '-' as i32
            && isdigit(peek_next(s) as ::core::ffi::c_int) != 0
    {
        return parse_number(s, entry, err)
    } else {
        return error(
            s,
            err,
            b"invalid value\0" as *const u8 as *const ::core::ffi::c_char,
        )
    };
}
unsafe extern "C" fn parse_key(
    mut s: *mut Scanner,
    mut entry: *mut CfgEntry,
    mut err: *mut CfgError,
) -> ::core::ffi::c_int {
    if is_at_end(s) as ::core::ffi::c_int != 0 || !is_key(peek(s)) {
        return error(
            s,
            err,
            b"missing key\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    let mut key_offset: ::core::ffi::c_int = cur(s);
    loop {
        advance(s);
        if !(!is_at_end(s) && is_key(peek(s)) as ::core::ffi::c_int != 0) {
            break;
        }
    }
    let mut key_len: ::core::ffi::c_int = cur(s) - key_offset;
    if key_len > CFG_MAX_KEY {
        return error(
            s,
            err,
            b"key too long\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    copy_slice_into(
        s,
        key_offset,
        key_len,
        (*entry).key.as_mut_ptr(),
        ::core::mem::size_of::<[::core::ffi::c_char; 33]>() as ::core::ffi::c_int,
    );
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn consume_colon(
    mut s: *mut Scanner,
    mut err: *mut CfgError,
) -> ::core::ffi::c_int {
    skip_blank(s);
    if is_at_end(s) as ::core::ffi::c_int != 0
        || peek(s) as ::core::ffi::c_int != ':' as i32
    {
        return error(
            s,
            err,
            b"':' expected\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    advance(s);
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn parse_entry(
    mut s: *mut Scanner,
    mut entry: *mut CfgEntry,
    mut err: *mut CfgError,
) -> ::core::ffi::c_int {
    if parse_key(s, entry, err) != 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    if consume_colon(s, err) != 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    if parse_value(s, entry, err) != 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    skip_blank(s);
    if !is_at_end(s) && peek(s) as ::core::ffi::c_int == '#' as i32 {
        skip_comment(s);
    }
    if !is_at_end(s) && peek(s) as ::core::ffi::c_int != '\n' as i32 {
        return error(
            s,
            err,
            b"unexpected character '%c'\0" as *const u8 as *const ::core::ffi::c_char,
            peek(s) as ::core::ffi::c_int,
        );
    }
    if !is_at_end(s) {
        advance(s);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn cfg_parse(
    mut src: *const ::core::ffi::c_char,
    mut src_len: ::core::ffi::c_int,
    mut cfg: *mut Cfg,
    mut err: *mut CfgError,
) -> ::core::ffi::c_int {
    let mut s: Scanner = Scanner {
        src: 0 as *const ::core::ffi::c_char,
        len: 0,
        cur: 0,
    };
    init_scanner(&mut s, src, src_len);
    init_error(err);
    (*cfg).count = 0 as ::core::ffi::c_int;
    skip_whitespace_and_comments(&mut s);
    while !is_at_end(&mut s) && (*cfg).count < (*cfg).capacity {
        let mut entry: *mut CfgEntry = &mut *(*cfg).entries.offset((*cfg).count as isize)
            as *mut CfgEntry;
        if parse_entry(&mut s, entry, err) != 0 as ::core::ffi::c_int {
            return -(1 as ::core::ffi::c_int);
        }
        (*cfg).count += 1;
        skip_whitespace_and_comments(&mut s);
    }
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn read_file(
    mut filename: *const ::core::ffi::c_char,
    mut count: *mut ::core::ffi::c_int,
    mut err: *mut ::core::ffi::c_char,
) -> *mut ::core::ffi::c_char {
    let mut file: *mut FILE = fopen(
        filename,
        b"rb\0" as *const u8 as *const ::core::ffi::c_char,
    ) as *mut FILE;
    if file.is_null() {
        snprintf(
            err,
            CFG_MAX_ERR as size_t,
            b"failed to open file\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 0 as *mut ::core::ffi::c_char;
    }
    fseek(file, 0 as ::core::ffi::c_long, SEEK_END);
    let mut file_size: size_t = ftell(file) as size_t;
    rewind(file);
    let mut src: *mut ::core::ffi::c_char = malloc(file_size.wrapping_add(1 as size_t))
        as *mut ::core::ffi::c_char;
    if src.is_null() {
        snprintf(
            err,
            CFG_MAX_ERR as size_t,
            b"memory allocation failed\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 0 as *mut ::core::ffi::c_char;
    }
    let mut bytes_read: size_t = fread(
        src as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_char>() as size_t,
        file_size,
        file,
    ) as size_t;
    fclose(file);
    if bytes_read != file_size {
        free(src as *mut ::core::ffi::c_void);
        snprintf(
            err,
            CFG_MAX_ERR as size_t,
            b"failed to read file\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 0 as *mut ::core::ffi::c_char;
    }
    *count = file_size as ::core::ffi::c_int;
    return src;
}
#[no_mangle]
pub unsafe extern "C" fn cfg_parse_file(
    mut filename: *const ::core::ffi::c_char,
    mut cfg: *mut Cfg,
    mut err: *mut CfgError,
) -> ::core::ffi::c_int {
    init_error(err);
    let mut len: size_t = strlen(filename);
    if len < 5 as size_t {
        snprintf(
            (*err).msg.as_mut_ptr(),
            CFG_MAX_ERR as size_t,
            b"invalid filename\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return -(1 as ::core::ffi::c_int);
    }
    let mut ext: *const ::core::ffi::c_char = filename
        .offset(
            len
                .wrapping_sub(
                    (::core::mem::size_of::<[::core::ffi::c_char; 5]>() as size_t)
                        .wrapping_sub(1 as size_t),
                ) as isize,
        );
    if strcmp(ext, CFG_FILE_EXT.as_ptr()) != 0 as ::core::ffi::c_int {
        snprintf(
            (*err).msg.as_mut_ptr(),
            CFG_MAX_ERR as size_t,
            b"invalid file extension\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return -(1 as ::core::ffi::c_int);
    }
    let mut src_len: ::core::ffi::c_int = 0;
    let mut src: *mut ::core::ffi::c_char = read_file(
        filename,
        &mut src_len,
        (*err).msg.as_mut_ptr(),
    );
    if src.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    let mut res: ::core::ffi::c_int = cfg_parse(src, src_len, cfg, err);
    free(src as *mut ::core::ffi::c_void);
    return res;
}
unsafe extern "C" fn get_val(
    mut cfg: *mut Cfg,
    mut key: *const ::core::ffi::c_char,
    mut fallback: *mut ::core::ffi::c_void,
    mut type_0: CfgValType,
) -> *mut ::core::ffi::c_void {
    let mut i: ::core::ffi::c_int = (*cfg).count - 1 as ::core::ffi::c_int;
    while i >= 0 as ::core::ffi::c_int {
        if (*(*cfg).entries.offset(i as isize)).type_0 as ::core::ffi::c_uint
            == type_0 as ::core::ffi::c_uint
            && strcmp(key, (*(*cfg).entries.offset(i as isize)).key.as_mut_ptr()) == 0
        {
            return &mut (*(*cfg).entries.offset(i as isize)).val as *mut CfgVal
                as *mut ::core::ffi::c_void;
        }
        i -= 1;
    }
    return fallback;
}
#[no_mangle]
pub unsafe extern "C" fn cfg_get_string(
    mut cfg: *mut Cfg,
    mut key: *const ::core::ffi::c_char,
    mut fallback: *mut ::core::ffi::c_char,
) -> *mut ::core::ffi::c_char {
    return get_val(cfg, key, fallback as *mut ::core::ffi::c_void, CFG_TYPE_STRING)
        as *mut ::core::ffi::c_char;
}
#[no_mangle]
pub unsafe extern "C" fn cfg_get_bool(
    mut cfg: *mut Cfg,
    mut key: *const ::core::ffi::c_char,
    mut fallback: bool,
) -> bool {
    return *(get_val(
        cfg,
        key,
        &mut fallback as *mut bool as *mut ::core::ffi::c_void,
        CFG_TYPE_BOOL,
    ) as *mut bool);
}
#[no_mangle]
pub unsafe extern "C" fn cfg_get_int(
    mut cfg: *mut Cfg,
    mut key: *const ::core::ffi::c_char,
    mut fallback: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    return *(get_val(
        cfg,
        key,
        &mut fallback as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
        CFG_TYPE_INT,
    ) as *mut ::core::ffi::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn cfg_get_int_min(
    mut cfg: *mut Cfg,
    mut key: *const ::core::ffi::c_char,
    mut fallback: ::core::ffi::c_int,
    mut min: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut value: ::core::ffi::c_int = cfg_get_int(cfg, key, fallback);
    if value < min {
        value = fallback;
    }
    return value;
}
#[no_mangle]
pub unsafe extern "C" fn cfg_get_int_max(
    mut cfg: *mut Cfg,
    mut key: *const ::core::ffi::c_char,
    mut fallback: ::core::ffi::c_int,
    mut max: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut value: ::core::ffi::c_int = cfg_get_int(cfg, key, fallback);
    if value > max {
        value = fallback;
    }
    return value;
}
#[no_mangle]
pub unsafe extern "C" fn cfg_get_int_range(
    mut cfg: *mut Cfg,
    mut key: *const ::core::ffi::c_char,
    mut fallback: ::core::ffi::c_int,
    mut min: ::core::ffi::c_int,
    mut max: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut value: ::core::ffi::c_int = cfg_get_int(cfg, key, fallback);
    if value < min || value > max {
        value = fallback;
    }
    return value;
}
#[no_mangle]
pub unsafe extern "C" fn cfg_get_float(
    mut cfg: *mut Cfg,
    mut key: *const ::core::ffi::c_char,
    mut fallback: ::core::ffi::c_float,
) -> ::core::ffi::c_float {
    return *(get_val(
        cfg,
        key,
        &mut fallback as *mut ::core::ffi::c_float as *mut ::core::ffi::c_void,
        CFG_TYPE_FLOAT,
    ) as *mut ::core::ffi::c_float);
}
#[no_mangle]
pub unsafe extern "C" fn cfg_get_float_min(
    mut cfg: *mut Cfg,
    mut key: *const ::core::ffi::c_char,
    mut fallback: ::core::ffi::c_float,
    mut min: ::core::ffi::c_float,
) -> ::core::ffi::c_float {
    let mut value: ::core::ffi::c_float = cfg_get_float(cfg, key, fallback);
    if value < min {
        value = fallback;
    }
    return value;
}
#[no_mangle]
pub unsafe extern "C" fn cfg_get_float_max(
    mut cfg: *mut Cfg,
    mut key: *const ::core::ffi::c_char,
    mut fallback: ::core::ffi::c_float,
    mut max: ::core::ffi::c_float,
) -> ::core::ffi::c_float {
    let mut value: ::core::ffi::c_float = cfg_get_float(cfg, key, fallback);
    if value > max {
        value = fallback;
    }
    return value;
}
#[no_mangle]
pub unsafe extern "C" fn cfg_get_float_range(
    mut cfg: *mut Cfg,
    mut key: *const ::core::ffi::c_char,
    mut fallback: ::core::ffi::c_float,
    mut min: ::core::ffi::c_float,
    mut max: ::core::ffi::c_float,
) -> ::core::ffi::c_float {
    let mut value: ::core::ffi::c_float = cfg_get_float(cfg, key, fallback);
    if value < min || value > max {
        value = fallback;
    }
    return value;
}
#[no_mangle]
pub unsafe extern "C" fn cfg_get_color(
    mut cfg: *mut Cfg,
    mut key: *const ::core::ffi::c_char,
    mut fallback: CfgColor,
) -> CfgColor {
    return *(get_val(
        cfg,
        key,
        &mut fallback as *mut CfgColor as *mut ::core::ffi::c_void,
        CFG_TYPE_COLOR,
    ) as *mut CfgColor);
}
#[no_mangle]
pub unsafe extern "C" fn cfg_fprint(mut stream: *mut FILE, mut cfg: *mut Cfg) {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*cfg).count {
        fprintf(
            stream,
            b"%s: \0" as *const u8 as *const ::core::ffi::c_char,
            (*(*cfg).entries.offset(i as isize)).key.as_mut_ptr(),
        );
        match (*(*cfg).entries.offset(i as isize)).type_0 as ::core::ffi::c_uint {
            0 => {
                fprintf(
                    stream,
                    b"\"%s\"\n\0" as *const u8 as *const ::core::ffi::c_char,
                    (*(*cfg).entries.offset(i as isize)).val.string.as_mut_ptr(),
                );
            }
            1 => {
                fprintf(
                    stream,
                    b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    if (*(*cfg).entries.offset(i as isize)).val.boolean
                        as ::core::ffi::c_int != 0
                    {
                        b"true\0" as *const u8 as *const ::core::ffi::c_char
                    } else {
                        b"false\0" as *const u8 as *const ::core::ffi::c_char
                    },
                );
            }
            2 => {
                fprintf(
                    stream,
                    b"%d\n\0" as *const u8 as *const ::core::ffi::c_char,
                    (*(*cfg).entries.offset(i as isize)).val.integer,
                );
            }
            3 => {
                fprintf(
                    stream,
                    b"%f\n\0" as *const u8 as *const ::core::ffi::c_char,
                    (*(*cfg).entries.offset(i as isize)).val.floating
                        as ::core::ffi::c_double,
                );
            }
            4 => {
                let mut c: CfgColor = (*(*cfg).entries.offset(i as isize)).val.color;
                fprintf(
                    stream,
                    b"rgba(%d, %d, %d, %d)\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    c.r as ::core::ffi::c_int,
                    c.g as ::core::ffi::c_int,
                    c.b as ::core::ffi::c_int,
                    c.a as ::core::ffi::c_int,
                );
            }
            _ => {}
        }
        i += 1;
    }
}
