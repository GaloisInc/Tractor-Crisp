#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stdoutp: *mut FILE;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn cfg_parse_file(
        filename: *const ::core::ffi::c_char,
        cfg: *mut Cfg,
        err: *mut CfgError,
    ) -> ::core::ffi::c_int;
    fn cfg_get_string(
        cfg: *mut Cfg,
        key: *const ::core::ffi::c_char,
        fallback: *mut ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
    fn cfg_get_bool(
        cfg: *mut Cfg,
        key: *const ::core::ffi::c_char,
        fallback: bool,
    ) -> bool;
    fn cfg_get_int(
        cfg: *mut Cfg,
        key: *const ::core::ffi::c_char,
        fallback: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn cfg_get_float(
        cfg: *mut Cfg,
        key: *const ::core::ffi::c_char,
        fallback: ::core::ffi::c_float,
    ) -> ::core::ffi::c_float;
    fn cfg_get_color(
        cfg: *mut Cfg,
        key: *const ::core::ffi::c_char,
        fallback: CfgColor,
    ) -> CfgColor;
    fn cfg_fprint_error(stream: *mut FILE, err: *mut CfgError);
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type uint8_t = u8;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct CfgError {
    pub off: ::core::ffi::c_int,
    pub col: ::core::ffi::c_int,
    pub row: ::core::ffi::c_int,
    pub msg: [::core::ffi::c_char; 64],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct CfgColor {
    pub r: uint8_t,
    pub g: uint8_t,
    pub b: uint8_t,
    pub a: uint8_t,
}
pub type CfgValType = ::core::ffi::c_uint;
pub const CFG_TYPE_COLOR: CfgValType = 4;
pub const CFG_TYPE_FLOAT: CfgValType = 3;
pub const CFG_TYPE_INT: CfgValType = 2;
pub const CFG_TYPE_BOOL: CfgValType = 1;
pub const CFG_TYPE_STRING: CfgValType = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub union CfgVal {
    pub string: [::core::ffi::c_char; 65],
    pub boolean: bool,
    pub integer: ::core::ffi::c_int,
    pub floating: ::core::ffi::c_float,
    pub color: CfgColor,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct CfgEntry {
    pub type_0: CfgValType,
    pub key: [::core::ffi::c_char; 33],
    pub val: CfgVal,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Cfg {
    pub entries: *mut CfgEntry,
    pub count: ::core::ffi::c_int,
    pub capacity: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    if argc != 2 as ::core::ffi::c_int {
        fprintf(
            __stderrp,
            b"Error: missing config file\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    let mut capacity: ::core::ffi::c_int = 64 as ::core::ffi::c_int;
    let mut entries: *mut CfgEntry = malloc(
        (capacity as size_t).wrapping_mul(::core::mem::size_of::<CfgEntry>() as size_t),
    ) as *mut CfgEntry;
    if entries.is_null() {
        fprintf(
            __stderrp,
            b"Error: memory allocation failed\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    let mut err: CfgError = CfgError {
        off: 0,
        col: 0,
        row: 0,
        msg: [0; 64],
    };
    let mut cfg: Cfg = {
        let mut init = Cfg {
            entries: entries,
            count: 0,
            capacity: capacity,
        };
        init
    };
    let mut res: ::core::ffi::c_int = cfg_parse_file(
        *argv.offset(1 as ::core::ffi::c_int as isize),
        &mut cfg,
        &mut err,
    );
    if res != 0 as ::core::ffi::c_int {
        cfg_fprint_error(__stderrp, &mut err);
        free(entries as *mut ::core::ffi::c_void);
        return 1 as ::core::ffi::c_int;
    }
    let mut font: *mut ::core::ffi::c_char = cfg_get_string(
        &mut cfg,
        b"font\0" as *const u8 as *const ::core::ffi::c_char,
        b"Noto Sans Mono\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_char,
    );
    let mut font_size: ::core::ffi::c_int = cfg_get_int(
        &mut cfg,
        b"font.size\0" as *const u8 as *const ::core::ffi::c_char,
        12 as ::core::ffi::c_int,
    );
    let mut zoom: ::core::ffi::c_float = cfg_get_float(
        &mut cfg,
        b"zoom\0" as *const u8 as *const ::core::ffi::c_char,
        1.0f32,
    );
    let mut line_num: bool = cfg_get_bool(
        &mut cfg,
        b"lineNumbers\0" as *const u8 as *const ::core::ffi::c_char,
        true_0 != 0,
    );
    let mut bg: CfgColor = cfg_get_color(
        &mut cfg,
        b"bg.color\0" as *const u8 as *const ::core::ffi::c_char,
        {
            let mut init = CfgColor {
                r: 255 as uint8_t,
                g: 255 as uint8_t,
                b: 255 as uint8_t,
                a: 1 as uint8_t,
            };
            init
        },
    );
    fprintf(__stdoutp, b"font: %s\n\0" as *const u8 as *const ::core::ffi::c_char, font);
    fprintf(
        __stdoutp,
        b"font.size: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        font_size,
    );
    fprintf(
        __stdoutp,
        b"zoom: %f\n\0" as *const u8 as *const ::core::ffi::c_char,
        zoom as ::core::ffi::c_double,
    );
    fprintf(
        __stdoutp,
        b"lineNumbers: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        if line_num as ::core::ffi::c_int != 0 {
            b"true\0" as *const u8 as *const ::core::ffi::c_char
        } else {
            b"false\0" as *const u8 as *const ::core::ffi::c_char
        },
    );
    fprintf(
        __stdoutp,
        b"bg.color: rgba(%d, %d, %d, %d)\n\0" as *const u8 as *const ::core::ffi::c_char,
        bg.r as ::core::ffi::c_int,
        bg.g as ::core::ffi::c_int,
        bg.b as ::core::ffi::c_int,
        bg.a as ::core::ffi::c_int,
    );
    free(entries as *mut ::core::ffi::c_void);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
