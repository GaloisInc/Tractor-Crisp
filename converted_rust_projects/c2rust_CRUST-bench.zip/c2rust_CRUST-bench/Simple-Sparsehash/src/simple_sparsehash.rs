#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn calloc(__count: size_t, __size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn realloc(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memmove(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strncmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> ::core::ffi::c_int;
    fn strncpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> *mut ::core::ffi::c_char;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
pub type uint32_t = u32;
pub type uint64_t = u64;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct sparse_bucket {
    pub key: *mut ::core::ffi::c_char,
    pub klen: size_t,
    pub val: *mut ::core::ffi::c_void,
    pub vlen: size_t,
    pub hash: uint64_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct sparse_array_group {
    pub count: uint32_t,
    pub elem_size: size_t,
    pub group: *mut ::core::ffi::c_void,
    pub bitmap: [uint32_t; 2],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct sparse_array {
    pub maximum: size_t,
    pub groups: *mut sparse_array_group,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct sparse_dict {
    pub bucket_max: size_t,
    pub bucket_count: size_t,
    pub buckets: *mut sparse_array,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const GROUP_SIZE: ::core::ffi::c_int = 48 as ::core::ffi::c_int;
pub const STARTING_SIZE: ::core::ffi::c_int = 32 as ::core::ffi::c_int;
pub const RESIZE_PERCENT: ::core::ffi::c_int = 80 as ::core::ffi::c_int;
pub const BITCHUNK_SIZE: usize = (::core::mem::size_of::<uint32_t>() as usize)
    .wrapping_mul(8 as usize);
unsafe extern "C" fn hash_fnv1a(
    mut key: *const ::core::ffi::c_char,
    klen: size_t,
) -> uint64_t {
    static mut fnv_prime: uint64_t = 1099511628211 as uint64_t;
    static mut fnv_offset_bias: uint64_t = 14695981039346656037 as uint64_t;
    let iterations: ::core::ffi::c_int = klen as ::core::ffi::c_int;
    let mut i: uint8_t = 0;
    let mut hash: uint64_t = fnv_offset_bias;
    i = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < iterations {
        hash = hash ^ *key.offset(i as isize) as uint64_t;
        hash = hash.wrapping_mul(fnv_prime);
        i = i.wrapping_add(1);
    }
    return hash;
}
unsafe extern "C" fn charbit(position: uint32_t) -> uint32_t {
    return position >> 5 as ::core::ffi::c_int;
}
unsafe extern "C" fn modbit(position: uint32_t) -> uint32_t {
    return ((1 as ::core::ffi::c_int) << (position & 31 as uint32_t)) as uint32_t;
}
#[inline]
unsafe extern "C" fn popcount_32(mut x: uint32_t) -> uint32_t {
    let m1: uint32_t = 0x55555555 as uint32_t;
    let m2: uint32_t = 0x33333333 as uint32_t;
    let m4: uint32_t = 0xf0f0f0f as uint32_t;
    x = x.wrapping_sub(x >> 1 as ::core::ffi::c_int & m1);
    x = (x & m2).wrapping_add(x >> 2 as ::core::ffi::c_int & m2);
    x = x.wrapping_add(x >> 4 as ::core::ffi::c_int) & m4;
    x = x.wrapping_add(x >> 8 as ::core::ffi::c_int);
    return x.wrapping_add(x >> 16 as ::core::ffi::c_int) & 0x3f as uint32_t;
}
unsafe extern "C" fn position_to_offset(
    mut bitmap: *const uint32_t,
    position: uint32_t,
) -> uint32_t {
    let mut retval: uint32_t = 0 as uint32_t;
    let mut pos: uint32_t = position;
    let mut bitmap_iter: uint32_t = 0 as uint32_t;
    while pos as usize >= BITCHUNK_SIZE {
        let fresh0 = bitmap_iter;
        bitmap_iter = bitmap_iter.wrapping_add(1);
        retval = retval.wrapping_add(popcount_32(*bitmap.offset(fresh0 as isize)));
        pos = (pos as ::core::ffi::c_ulong)
            .wrapping_sub(BITCHUNK_SIZE as ::core::ffi::c_ulong) as uint32_t as uint32_t;
    }
    return retval
        .wrapping_add(
            popcount_32(
                *bitmap.offset(bitmap_iter as isize)
                    & ((1 as ::core::ffi::c_int as uint32_t) << pos)
                        .wrapping_sub(1 as uint32_t),
            ) as uint32_t,
        );
}
unsafe extern "C" fn is_position_occupied(
    mut bitmap: *const uint32_t,
    position: uint32_t,
) -> ::core::ffi::c_int {
    return (*bitmap.offset(charbit(position) as isize) & modbit(position))
        as ::core::ffi::c_int;
}
unsafe extern "C" fn set_position(mut bitmap: *mut uint32_t, position: uint32_t) {
    *bitmap.offset(charbit(position) as isize) |= modbit(position);
}
unsafe extern "C" fn _sparse_array_group_set(
    mut arr: *mut sparse_array_group,
    i: uint32_t,
    mut val: *const ::core::ffi::c_void,
    vlen: size_t,
) -> ::core::ffi::c_int {
    let mut offset: uint32_t = 0 as uint32_t;
    let mut destination: *mut ::core::ffi::c_void = NULL;
    if vlen > (*arr).elem_size {
        return 0 as ::core::ffi::c_int;
    }
    offset = position_to_offset((*arr).bitmap.as_mut_ptr(), i);
    if is_position_occupied((*arr).bitmap.as_mut_ptr(), i) == 0 {
        let to_move_siz: size_t = ((*arr).count.wrapping_sub(offset) as size_t)
            .wrapping_mul(
                (*arr).elem_size.wrapping_add(::core::mem::size_of::<size_t>() as size_t),
            );
        let mut new_group: *mut ::core::ffi::c_void = realloc(
            (*arr).group,
            ((*arr).count.wrapping_add(1 as uint32_t) as size_t)
                .wrapping_mul(
                    (*arr)
                        .elem_size
                        .wrapping_add(::core::mem::size_of::<size_t>() as size_t),
                ),
        );
        if new_group.is_null() {
            return 0 as ::core::ffi::c_int;
        }
        if to_move_siz > 0 as size_t {
            memmove(
                (new_group as *mut ::core::ffi::c_uchar)
                    .offset(
                        (offset.wrapping_add(1 as uint32_t) as size_t)
                            .wrapping_mul(
                                (*arr)
                                    .elem_size
                                    .wrapping_add(::core::mem::size_of::<size_t>() as size_t),
                            ) as isize,
                    ) as *mut ::core::ffi::c_void,
                (new_group as *mut ::core::ffi::c_uchar)
                    .offset(
                        (offset as size_t)
                            .wrapping_mul(
                                (*arr)
                                    .elem_size
                                    .wrapping_add(::core::mem::size_of::<size_t>() as size_t),
                            ) as isize,
                    ) as *const ::core::ffi::c_void,
                to_move_siz,
            );
        }
        (*arr).count = (*arr).count.wrapping_add(1);
        (*arr).group = new_group;
        set_position((*arr).bitmap.as_mut_ptr(), i);
    }
    destination = ((*arr).group as *mut ::core::ffi::c_uchar)
        .offset(
            (offset as size_t)
                .wrapping_mul(
                    (*arr)
                        .elem_size
                        .wrapping_add(::core::mem::size_of::<size_t>() as size_t),
                ) as isize,
        ) as *mut ::core::ffi::c_void;
    memcpy(
        destination,
        &vlen as *const size_t as *const ::core::ffi::c_void,
        ::core::mem::size_of::<size_t>() as size_t,
    );
    destination = (destination as *mut ::core::ffi::c_uchar)
        .offset(::core::mem::size_of::<size_t>() as usize as isize)
        as *mut ::core::ffi::c_void;
    memcpy(destination, val, vlen);
    return 1 as ::core::ffi::c_int;
}
unsafe extern "C" fn _sparse_array_group_get(
    mut arr: *mut sparse_array_group,
    i: uint32_t,
    mut outsize: *mut size_t,
) -> *const ::core::ffi::c_void {
    let offset: uint32_t = position_to_offset((*arr).bitmap.as_mut_ptr(), i) as uint32_t;
    let mut item_siz: *const ::core::ffi::c_uchar = ((*arr).group
        as *mut ::core::ffi::c_uchar)
        .offset(
            (offset as size_t)
                .wrapping_mul(
                    (*arr)
                        .elem_size
                        .wrapping_add(::core::mem::size_of::<size_t>() as size_t),
                ) as isize,
        );
    let mut item: *const ::core::ffi::c_void = item_siz
        .offset(::core::mem::size_of::<size_t>() as usize as isize)
        as *const ::core::ffi::c_void;
    if is_position_occupied((*arr).bitmap.as_mut_ptr(), i) == 0 {
        return 0 as *const ::core::ffi::c_void;
    }
    if *(item_siz as *mut size_t) == 0 as size_t {
        return 0 as *const ::core::ffi::c_void;
    }
    if !outsize.is_null() {
        memcpy(
            outsize as *mut ::core::ffi::c_void,
            item_siz as *const ::core::ffi::c_void,
            ::core::mem::size_of::<size_t>() as size_t,
        );
    }
    return item;
}
unsafe extern "C" fn _sparse_array_group_free(
    mut arr: *mut sparse_array_group,
) -> ::core::ffi::c_int {
    free((*arr).group);
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn sparse_array_init(
    element_size: size_t,
    maximum: uint32_t,
) -> *mut sparse_array {
    let mut i: ::core::ffi::c_uint = 0 as ::core::ffi::c_uint;
    let mut arr: *mut sparse_array = 0 as *mut sparse_array;
    arr = calloc(1 as size_t, ::core::mem::size_of::<sparse_array>() as size_t)
        as *mut sparse_array;
    if arr.is_null() {
        return 0 as *mut sparse_array;
    }
    let mut stack_array: sparse_array = {
        let mut init = sparse_array {
            maximum: maximum as size_t,
            groups: 0 as *mut sparse_array_group,
        };
        init
    };
    memcpy(
        arr as *mut ::core::ffi::c_void,
        &mut stack_array as *mut sparse_array as *const ::core::ffi::c_void,
        ::core::mem::size_of::<sparse_array>() as size_t,
    );
    (*arr).groups = calloc(
        (*arr)
            .maximum
            .wrapping_sub(1 as size_t)
            .wrapping_div(GROUP_SIZE as size_t)
            .wrapping_add(1 as size_t),
        ::core::mem::size_of::<sparse_array_group>() as size_t,
    ) as *mut sparse_array_group;
    if (*arr).groups.is_null() {
        free(arr as *mut ::core::ffi::c_void);
        return 0 as *mut sparse_array;
    }
    i = 0 as ::core::ffi::c_uint;
    while (i as size_t)
        < (*arr)
            .maximum
            .wrapping_sub(1 as size_t)
            .wrapping_div(GROUP_SIZE as size_t)
            .wrapping_add(1 as size_t)
    {
        let mut sag: *mut sparse_array_group = &mut *(*arr).groups.offset(i as isize)
            as *mut sparse_array_group;
        (*sag).elem_size = element_size;
        i = i.wrapping_add(1);
    }
    return arr;
}
#[no_mangle]
pub unsafe extern "C" fn sparse_array_set(
    mut arr: *mut sparse_array,
    i: uint32_t,
    mut val: *const ::core::ffi::c_void,
    vlen: size_t,
) -> ::core::ffi::c_int {
    if i as size_t > (*arr).maximum {
        return 0 as ::core::ffi::c_int;
    }
    let mut operating_group: *mut sparse_array_group = &mut *(*arr)
        .groups
        .offset(i.wrapping_div(GROUP_SIZE as uint32_t) as isize)
        as *mut sparse_array_group;
    let position: ::core::ffi::c_int = i.wrapping_rem(GROUP_SIZE as uint32_t)
        as ::core::ffi::c_int;
    return _sparse_array_group_set(operating_group, position as uint32_t, val, vlen)
        as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn sparse_array_get(
    mut arr: *mut sparse_array,
    i: uint32_t,
    mut outsize: *mut size_t,
) -> *const ::core::ffi::c_void {
    if i as size_t > (*arr).maximum {
        return 0 as *const ::core::ffi::c_void;
    }
    let mut operating_group: *mut sparse_array_group = &mut *(*arr)
        .groups
        .offset(i.wrapping_div(GROUP_SIZE as uint32_t) as isize)
        as *mut sparse_array_group;
    let position: ::core::ffi::c_int = i.wrapping_rem(GROUP_SIZE as uint32_t)
        as ::core::ffi::c_int;
    return _sparse_array_group_get(operating_group, position as uint32_t, outsize);
}
#[no_mangle]
pub unsafe extern "C" fn sparse_array_free(
    mut arr: *mut sparse_array,
) -> ::core::ffi::c_int {
    let mut i: ::core::ffi::c_uint = 0 as ::core::ffi::c_uint;
    while (i as size_t)
        < (*arr)
            .maximum
            .wrapping_sub(1 as size_t)
            .wrapping_div(GROUP_SIZE as size_t)
            .wrapping_add(1 as size_t)
    {
        let mut sag: *mut sparse_array_group = &mut *(*arr).groups.offset(i as isize)
            as *mut sparse_array_group;
        _sparse_array_group_free(sag);
        i = i.wrapping_add(1);
    }
    free((*arr).groups as *mut ::core::ffi::c_void);
    free(arr as *mut ::core::ffi::c_void);
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn sparse_dict_init() -> *mut sparse_dict {
    let mut new: *mut sparse_dict = 0 as *mut sparse_dict;
    new = calloc(1 as size_t, ::core::mem::size_of::<sparse_dict>() as size_t)
        as *mut sparse_dict;
    if new.is_null() {
        return 0 as *mut sparse_dict;
    }
    (*new).bucket_max = STARTING_SIZE as size_t;
    (*new).bucket_count = 0 as size_t;
    (*new).buckets = sparse_array_init(
        ::core::mem::size_of::<sparse_bucket>() as size_t,
        STARTING_SIZE as uint32_t,
    );
    if (*new).buckets.is_null() {
        free(new as *mut ::core::ffi::c_void);
        return 0 as *mut sparse_dict;
    } else {
        return new
    };
}
unsafe extern "C" fn _create_and_insert_new_bucket(
    mut array: *mut sparse_array,
    i: ::core::ffi::c_uint,
    mut key: *const ::core::ffi::c_char,
    klen: size_t,
    mut value: *const ::core::ffi::c_void,
    vlen: size_t,
    key_hash: uint64_t,
) -> ::core::ffi::c_int {
    let mut bct: sparse_bucket = sparse_bucket {
        key: 0 as *mut ::core::ffi::c_char,
        klen: 0,
        val: 0 as *mut ::core::ffi::c_void,
        vlen: 0,
        hash: 0,
    };
    let mut copied_value: *mut ::core::ffi::c_void = NULL;
    let mut copied_key: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    copied_value = malloc(vlen.wrapping_add(klen));
    if !copied_value.is_null() {
        memcpy(copied_value, value, vlen);
        copied_key = copied_value.offset(vlen as isize) as *mut ::core::ffi::c_char;
        strncpy(copied_key, key, klen);
        bct = {
            let mut init = sparse_bucket {
                key: copied_key,
                klen: klen,
                val: copied_value,
                vlen: vlen,
                hash: key_hash,
            };
            init
        };
        if !(sparse_array_set(
            array,
            i as uint32_t,
            &mut bct as *mut sparse_bucket as *const ::core::ffi::c_void,
            ::core::mem::size_of::<sparse_bucket>() as size_t,
        ) == 0)
        {
            return 1 as ::core::ffi::c_int;
        }
    }
    free(copied_value);
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn _rehash_and_grow_table(
    mut dict: *mut sparse_dict,
) -> ::core::ffi::c_int {
    let mut current_block: u64;
    let mut i: ::core::ffi::c_uint = 0 as ::core::ffi::c_uint;
    let mut buckets_rehashed: ::core::ffi::c_uint = 0 as ::core::ffi::c_uint;
    let new_bucket_max: size_t = (*dict).bucket_max.wrapping_mul(2 as size_t);
    let mut new_buckets: *mut sparse_array = 0 as *mut sparse_array;
    new_buckets = sparse_array_init(
        ::core::mem::size_of::<sparse_bucket>() as size_t,
        new_bucket_max as uint32_t,
    );
    if !new_buckets.is_null() {
        i = 0 as ::core::ffi::c_uint;
        's_16: loop {
            if !((i as size_t) < (*dict).bucket_max) {
                current_block = 12039483399334584727;
                break;
            }
            let mut bucket_siz: size_t = 0 as size_t;
            let mut bucket: *const sparse_bucket = sparse_array_get(
                (*dict).buckets,
                i as uint32_t,
                &mut bucket_siz,
            ) as *const sparse_bucket;
            if bucket_siz != 0 as size_t && !bucket.is_null() {
                let mut probed_val: ::core::ffi::c_uint = 0 as ::core::ffi::c_uint;
                let mut num_probes: ::core::ffi::c_uint = 0 as ::core::ffi::c_uint;
                let mut key_hash: uint64_t = (*bucket).hash;
                loop {
                    probed_val = (key_hash
                        .wrapping_add(num_probes.wrapping_mul(num_probes) as uint64_t)
                        & new_bucket_max.wrapping_sub(1 as size_t) as uint64_t)
                        as ::core::ffi::c_uint;
                    let mut current_value_siz: size_t = 0 as size_t;
                    let mut current_value: *const ::core::ffi::c_void = sparse_array_get(
                        new_buckets,
                        probed_val as uint32_t,
                        &mut current_value_siz,
                    );
                    if current_value_siz == 0 as size_t && current_value.is_null() {
                        break;
                    }
                    if num_probes as size_t > (*dict).bucket_count {
                        current_block = 9323137552179165462;
                        break 's_16;
                    }
                    num_probes = num_probes.wrapping_add(1);
                }
                if sparse_array_set(
                    new_buckets,
                    probed_val as uint32_t,
                    bucket as *const ::core::ffi::c_void,
                    ::core::mem::size_of::<sparse_bucket>() as size_t,
                ) == 0
                {
                    current_block = 9323137552179165462;
                    break;
                }
                buckets_rehashed = buckets_rehashed.wrapping_add(1);
            }
            if buckets_rehashed as size_t == (*dict).bucket_count {
                current_block = 12039483399334584727;
                break;
            }
            i = i.wrapping_add(1);
        }
        match current_block {
            9323137552179165462 => {}
            _ => {
                sparse_array_free((*dict).buckets);
                (*dict).buckets = new_buckets;
                (*dict).bucket_max = new_bucket_max;
                return 1 as ::core::ffi::c_int;
            }
        }
    }
    if !new_buckets.is_null() {
        sparse_array_free(new_buckets);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn sparse_dict_set(
    mut dict: *mut sparse_dict,
    mut key: *const ::core::ffi::c_char,
    klen: size_t,
    mut value: *const ::core::ffi::c_void,
    vlen: size_t,
) -> ::core::ffi::c_int {
    let mut current_block: u64;
    let key_hash: uint64_t = hash_fnv1a(key, klen) as uint64_t;
    let mut num_probes: ::core::ffi::c_uint = 0 as ::core::ffi::c_uint;
    loop {
        let mut current_value_siz: size_t = 0 as size_t;
        let probed_val: ::core::ffi::c_uint = (key_hash
            .wrapping_add(num_probes.wrapping_mul(num_probes) as uint64_t)
            & (*dict).bucket_max.wrapping_sub(1 as size_t) as uint64_t)
            as ::core::ffi::c_uint;
        let mut current_value: *const ::core::ffi::c_void = sparse_array_get(
            (*dict).buckets,
            probed_val as uint32_t,
            &mut current_value_siz,
        );
        if current_value_siz == 0 as size_t && current_value.is_null() {
            if _create_and_insert_new_bucket(
                (*dict).buckets,
                probed_val,
                key,
                klen,
                value,
                vlen,
                key_hash,
            ) != 0
            {
                current_block = 1054647088692577877;
                break;
            } else {
                current_block = 14317338483548463801;
                break;
            }
        } else {
            let mut existing_bucket: *mut sparse_bucket = current_value
                as *mut sparse_bucket;
            if (*existing_bucket).hash == key_hash && (*existing_bucket).klen == klen
                && strncmp((*existing_bucket).key, key, klen) == 0 as ::core::ffi::c_int
            {
                let mut existing_key: *mut ::core::ffi::c_char = (*existing_bucket).key;
                let mut existing_val: *mut ::core::ffi::c_void = (*existing_bucket).val;
                if !(_create_and_insert_new_bucket(
                    (*dict).buckets,
                    probed_val,
                    key,
                    klen,
                    value,
                    vlen,
                    key_hash,
                ) != 0)
                {
                    current_block = 14317338483548463801;
                    break;
                }
                free(existing_key as *mut ::core::ffi::c_void);
                free(existing_val);
                return 1 as ::core::ffi::c_int;
            } else {
                num_probes = num_probes.wrapping_add(1);
                if !(num_probes as size_t > (*dict).bucket_count) {
                    continue;
                }
                printf(
                    b"Could not find an open slot in the table.\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                );
                current_block = 14317338483548463801;
                break;
            }
        }
    }
    match current_block {
        14317338483548463801 => return 0 as ::core::ffi::c_int,
        _ => {
            (*dict).bucket_count = (*dict).bucket_count.wrapping_add(1);
            if (*dict).bucket_count as ::core::ffi::c_float
                / (*dict).bucket_max as ::core::ffi::c_float
                >= RESIZE_PERCENT as ::core::ffi::c_float / 100.0f32
            {
                return _rehash_and_grow_table(dict) as ::core::ffi::c_int;
            }
            return 1 as ::core::ffi::c_int;
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sparse_dict_get(
    mut dict: *mut sparse_dict,
    mut key: *const ::core::ffi::c_char,
    klen: size_t,
    mut outsize: *mut size_t,
) -> *const ::core::ffi::c_void {
    let key_hash: uint64_t = hash_fnv1a(key, klen) as uint64_t;
    let mut num_probes: ::core::ffi::c_uint = 0 as ::core::ffi::c_uint;
    loop {
        let mut current_value_siz: size_t = 0 as size_t;
        let probed_val: ::core::ffi::c_uint = (key_hash
            .wrapping_add(num_probes.wrapping_mul(num_probes) as uint64_t)
            & (*dict).bucket_max.wrapping_sub(1 as size_t) as uint64_t)
            as ::core::ffi::c_uint;
        let mut current_value: *const ::core::ffi::c_void = sparse_array_get(
            (*dict).buckets,
            probed_val as uint32_t,
            &mut current_value_siz,
        );
        if current_value_siz != 0 as size_t && !current_value.is_null() {
            let mut existing_bucket: *mut sparse_bucket = current_value
                as *mut sparse_bucket;
            if (*existing_bucket).hash == key_hash && (*existing_bucket).klen == klen
                && strncmp((*existing_bucket).key, key, klen) == 0 as ::core::ffi::c_int
            {
                if !outsize.is_null() {
                    memcpy(
                        outsize as *mut ::core::ffi::c_void,
                        &(*existing_bucket).vlen as *const size_t
                            as *const ::core::ffi::c_void,
                        ::core::mem::size_of::<size_t>() as size_t,
                    );
                }
                return (*existing_bucket).val;
            }
        } else {
            return 0 as *const ::core::ffi::c_void
        }
        num_probes = num_probes.wrapping_add(1);
        if num_probes as size_t > (*dict).bucket_count {
            return 0 as *const ::core::ffi::c_void;
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sparse_dict_free(
    mut dict: *mut sparse_dict,
) -> ::core::ffi::c_int {
    let mut i: ::core::ffi::c_uint = 0 as ::core::ffi::c_uint;
    i = 0 as ::core::ffi::c_uint;
    while (i as size_t) < (*dict).bucket_max {
        let mut current_value_siz: size_t = 0 as size_t;
        let mut current_value: *const ::core::ffi::c_void = sparse_array_get(
            (*dict).buckets,
            i as uint32_t,
            &mut current_value_siz,
        );
        if current_value_siz != 0 as size_t && !current_value.is_null() {
            let mut existing_bucket: *mut sparse_bucket = current_value
                as *mut sparse_bucket;
            free((*existing_bucket).val);
        }
        i = i.wrapping_add(1);
    }
    sparse_array_free((*dict).buckets);
    free(dict as *mut ::core::ffi::c_void);
    return 1 as ::core::ffi::c_int;
}
