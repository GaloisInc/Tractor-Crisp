#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn snprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strncmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> ::core::ffi::c_int;
    fn sparse_array_init(element_size: size_t, maximum: uint32_t) -> *mut sparse_array;
    fn sparse_array_set(
        arr: *mut sparse_array,
        i: uint32_t,
        val: *const ::core::ffi::c_void,
        vlen: size_t,
    ) -> ::core::ffi::c_int;
    fn sparse_array_get(
        arr: *mut sparse_array,
        i: uint32_t,
        outsize: *mut size_t,
    ) -> *const ::core::ffi::c_void;
    fn sparse_array_free(arr: *mut sparse_array) -> ::core::ffi::c_int;
    fn sparse_dict_init() -> *mut sparse_dict;
    fn sparse_dict_set(
        dict: *mut sparse_dict,
        key: *const ::core::ffi::c_char,
        klen: size_t,
        value: *const ::core::ffi::c_void,
        vlen: size_t,
    ) -> ::core::ffi::c_int;
    fn sparse_dict_get(
        dict: *mut sparse_dict,
        key: *const ::core::ffi::c_char,
        klen: size_t,
        outsize: *mut size_t,
    ) -> *const ::core::ffi::c_void;
    fn sparse_dict_free(dict: *mut sparse_dict) -> ::core::ffi::c_int;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint32_t = u32;
pub type uint64_t = u64;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct sparse_array_group {
    pub count: uint32_t,
    pub elem_size: size_t,
    pub group: *mut ::core::ffi::c_void,
    pub bitmap: [uint32_t; 2],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct sparse_array {
    pub maximum: size_t,
    pub groups: *mut sparse_array_group,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct sparse_dict {
    pub bucket_max: size_t,
    pub bucket_count: size_t,
    pub buckets: *mut sparse_array,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const GROUP_SIZE: ::core::ffi::c_int = 48 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn test_empty_array_does_not_blow_up() -> ::core::ffi::c_int {
    let mut arr: *mut sparse_array = 0 as *mut sparse_array;
    arr = sparse_array_init(
        ::core::mem::size_of::<uint64_t>() as size_t,
        32 as uint32_t,
    );
    if arr.is_null() {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            29 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if !sparse_array_get(arr, 0 as uint32_t, 0 as *mut size_t).is_null() {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            31 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if sparse_array_free(arr) == 0 {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            33 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_cannot_set_outside_bounds() -> ::core::ffi::c_int {
    let mut arr: *mut sparse_array = 0 as *mut sparse_array;
    let test_num: uint64_t = 666 as uint64_t;
    arr = sparse_array_init(
        ::core::mem::size_of::<uint64_t>() as size_t,
        32 as uint32_t,
    );
    if arr.is_null() {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            41 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if !(sparse_array_set(
        arr,
        35 as uint32_t,
        &test_num as *const uint64_t as *const ::core::ffi::c_void,
        ::core::mem::size_of::<uint64_t>() as size_t,
    ) == 0 as ::core::ffi::c_int)
    {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            43 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if sparse_array_free(arr) == 0 {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            45 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_cannot_get_outside_bounds() -> ::core::ffi::c_int {
    let mut arr: *mut sparse_array = 0 as *mut sparse_array;
    arr = sparse_array_init(
        ::core::mem::size_of::<uint64_t>() as size_t,
        32 as uint32_t,
    );
    if arr.is_null() {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            52 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if !sparse_array_get(arr, 35 as uint32_t, 0 as *mut size_t).is_null() {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            54 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if sparse_array_free(arr) == 0 {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            56 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_cannot_set_bigger_elements() -> ::core::ffi::c_int {
    let mut arr: *mut sparse_array = 0 as *mut sparse_array;
    let test_num: uint64_t = 666 as uint64_t;
    arr = sparse_array_init(
        ::core::mem::size_of::<::core::ffi::c_char>() as size_t,
        100 as uint32_t,
    );
    if arr.is_null() {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            64 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if !(sparse_array_set(
        arr,
        0 as uint32_t,
        &test_num as *const uint64_t as *const ::core::ffi::c_void,
        ::core::mem::size_of::<uint64_t>() as size_t,
    ) == 0 as ::core::ffi::c_int)
    {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            66 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if sparse_array_free(arr) == 0 {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            68 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_array_set_backwards() -> ::core::ffi::c_int {
    let mut i: ::core::ffi::c_int = 0;
    let array_size: ::core::ffi::c_int = 120 as ::core::ffi::c_int;
    let mut arr: *mut sparse_array = 0 as *mut sparse_array;
    arr = sparse_array_init(
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        array_size as uint32_t,
    );
    if arr.is_null() {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            78 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    i = array_size - 1 as ::core::ffi::c_int;
    while i >= 0 as ::core::ffi::c_int {
        let mut returned: *mut ::core::ffi::c_int = 0 as *mut ::core::ffi::c_int;
        let mut siz: size_t = 0 as size_t;
        if sparse_array_set(
            arr,
            i as uint32_t,
            &mut i as *mut ::core::ffi::c_int as *const ::core::ffi::c_void,
            ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        ) == 0
        {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                83 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        returned = sparse_array_get(arr, i as uint32_t, &mut siz)
            as *mut ::core::ffi::c_int;
        if returned.is_null() {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                85 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        if !(*returned == i) {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                86 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        if !(siz == ::core::mem::size_of::<::core::ffi::c_int>() as usize) {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                87 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        i -= 1;
    }
    i = array_size - 1 as ::core::ffi::c_int;
    while i >= 0 as ::core::ffi::c_int {
        let mut returned_0: *mut ::core::ffi::c_int = 0 as *mut ::core::ffi::c_int;
        let mut siz_0: size_t = 0 as size_t;
        returned_0 = sparse_array_get(arr, i as uint32_t, &mut siz_0)
            as *mut ::core::ffi::c_int;
        if !(*returned_0 == i) {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                94 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        if !(siz_0 == ::core::mem::size_of::<::core::ffi::c_int>() as usize) {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                95 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        i -= 1;
    }
    if sparse_array_free(arr) == 0 {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            98 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_array_set() -> ::core::ffi::c_int {
    let mut i: ::core::ffi::c_int = 0;
    let array_size: ::core::ffi::c_int = 130 as ::core::ffi::c_int;
    let mut arr: *mut sparse_array = 0 as *mut sparse_array;
    arr = sparse_array_init(
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        array_size as uint32_t,
    );
    if arr.is_null() {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            107 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    i = 0 as ::core::ffi::c_int;
    while i < array_size {
        let mut returned: *mut ::core::ffi::c_int = 0 as *mut ::core::ffi::c_int;
        let mut siz: size_t = 0 as size_t;
        if sparse_array_set(
            arr,
            i as uint32_t,
            &mut i as *mut ::core::ffi::c_int as *const ::core::ffi::c_void,
            ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        ) == 0
        {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                112 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        returned = sparse_array_get(arr, i as uint32_t, &mut siz)
            as *mut ::core::ffi::c_int;
        if !(*returned == i) {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                114 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        if !(siz == ::core::mem::size_of::<::core::ffi::c_int>() as usize) {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                115 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        i += 1;
    }
    i = 0 as ::core::ffi::c_int;
    while i < array_size {
        let mut returned_0: *mut ::core::ffi::c_int = 0 as *mut ::core::ffi::c_int;
        let mut siz_0: size_t = 0 as size_t;
        returned_0 = sparse_array_get(arr, i as uint32_t, &mut siz_0)
            as *mut ::core::ffi::c_int;
        if !(*returned_0 == i) {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                123 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        if !(siz_0 == ::core::mem::size_of::<::core::ffi::c_int>() as usize) {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                124 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        i += 1;
    }
    if sparse_array_free(arr) == 0 {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            127 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_array_set_high_num() -> ::core::ffi::c_int {
    let test_num: ::core::ffi::c_int = 65555555 as ::core::ffi::c_int;
    let index: ::core::ffi::c_int = GROUP_SIZE - 1 as ::core::ffi::c_int;
    let mut returned: *mut ::core::ffi::c_int = 0 as *mut ::core::ffi::c_int;
    let mut siz: size_t = 0 as size_t;
    let mut arr: *mut sparse_array = 0 as *mut sparse_array;
    arr = sparse_array_init(
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        140 as uint32_t,
    );
    if arr.is_null() {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            139 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if sparse_array_set(
        arr,
        index as uint32_t,
        &test_num as *const ::core::ffi::c_int as *const ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
    ) == 0
    {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            141 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    returned = sparse_array_get(arr, index as uint32_t, &mut siz)
        as *mut ::core::ffi::c_int;
    if returned.is_null() {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            143 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if !(*returned == test_num) {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            144 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if !(siz == ::core::mem::size_of::<::core::ffi::c_int>() as usize) {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            145 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if sparse_array_free(arr) == 0 {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            147 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_array_set_overwrites_old_values() -> ::core::ffi::c_int {
    let mut arr: *mut sparse_array = 0 as *mut sparse_array;
    let test_num: ::core::ffi::c_int = 666 as ::core::ffi::c_int;
    let test_num2: ::core::ffi::c_int = 1024 as ::core::ffi::c_int;
    arr = sparse_array_init(
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        150 as uint32_t,
    );
    if arr.is_null() {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            156 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if sparse_array_set(
        arr,
        0 as uint32_t,
        &test_num as *const ::core::ffi::c_int as *const ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
    ) == 0
    {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            158 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if sparse_array_set(
        arr,
        0 as uint32_t,
        &test_num2 as *const ::core::ffi::c_int as *const ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
    ) == 0
    {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            159 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if !(*(sparse_array_get(arr, 0 as uint32_t, 0 as *mut size_t)
        as *const ::core::ffi::c_int) == 1024 as ::core::ffi::c_int)
    {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            161 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if sparse_array_free(arr) == 0 {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            163 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_array_get() -> ::core::ffi::c_int {
    let mut arr: *mut sparse_array = 0 as *mut sparse_array;
    let test_num: ::core::ffi::c_int = 666 as ::core::ffi::c_int;
    let mut item_size: size_t = 0 as size_t;
    arr = sparse_array_init(
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        200 as uint32_t,
    );
    if arr.is_null() {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            172 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if sparse_array_set(
        arr,
        0 as uint32_t,
        &test_num as *const ::core::ffi::c_int as *const ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
    ) == 0
    {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            174 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if !(*(sparse_array_get(arr, 0 as uint32_t, &mut item_size)
        as *const ::core::ffi::c_int) == 666 as ::core::ffi::c_int)
    {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            175 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if !(item_size == ::core::mem::size_of::<::core::ffi::c_int>() as usize) {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            176 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if sparse_array_free(arr) == 0 {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            178 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_dict_set() -> ::core::ffi::c_int {
    let mut dict: *mut sparse_dict = 0 as *mut sparse_dict;
    dict = sparse_dict_init();
    if dict.is_null() {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            185 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if sparse_dict_set(
        dict,
        b"key\0" as *const u8 as *const ::core::ffi::c_char,
        strlen(b"key\0" as *const u8 as *const ::core::ffi::c_char),
        b"value\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        strlen(b"value\0" as *const u8 as *const ::core::ffi::c_char),
    ) == 0
    {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            187 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if sparse_dict_free(dict) == 0 {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            189 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_dict_get() -> ::core::ffi::c_int {
    let mut dict: *mut sparse_dict = 0 as *mut sparse_dict;
    let mut outsize: size_t = 0 as size_t;
    let mut value: *const ::core::ffi::c_char = 0 as *const ::core::ffi::c_char;
    dict = sparse_dict_init();
    if dict.is_null() {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            199 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if sparse_dict_set(
        dict,
        b"key\0" as *const u8 as *const ::core::ffi::c_char,
        strlen(b"key\0" as *const u8 as *const ::core::ffi::c_char),
        b"value\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        strlen(b"value\0" as *const u8 as *const ::core::ffi::c_char),
    ) == 0
    {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            201 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    value = sparse_dict_get(
        dict,
        b"key\0" as *const u8 as *const ::core::ffi::c_char,
        strlen(b"key\0" as *const u8 as *const ::core::ffi::c_char),
        &mut outsize,
    ) as *const ::core::ffi::c_char;
    if value.is_null() {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            205 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if !(outsize == strlen(b"value\0" as *const u8 as *const ::core::ffi::c_char)) {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            206 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if !(strncmp(value, b"value\0" as *const u8 as *const ::core::ffi::c_char, outsize)
        == 0 as ::core::ffi::c_int)
    {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            207 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    if sparse_dict_free(dict) == 0 {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            209 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_dict_lots_of_set() -> ::core::ffi::c_int {
    let mut dict: *mut sparse_dict = 0 as *mut sparse_dict;
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    dict = sparse_dict_init();
    if dict.is_null() {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            218 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    let iterations: ::core::ffi::c_int = 1000000 as ::core::ffi::c_int;
    i = 0 as ::core::ffi::c_int;
    while i < iterations {
        let mut key: [::core::ffi::c_char; 64] = [
            0 as ::core::ffi::c_int as ::core::ffi::c_char,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
        ];
        snprintf(
            key.as_mut_ptr(),
            ::core::mem::size_of::<[::core::ffi::c_char; 64]>() as size_t,
            b"crazy hash%i\0" as *const u8 as *const ::core::ffi::c_char,
            i,
        );
        let mut val: [::core::ffi::c_char; 64] = [
            0 as ::core::ffi::c_int as ::core::ffi::c_char,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
        ];
        snprintf(
            val.as_mut_ptr(),
            ::core::mem::size_of::<[::core::ffi::c_char; 64]>() as size_t,
            b"value%i\0" as *const u8 as *const ::core::ffi::c_char,
            i,
        );
        if sparse_dict_set(
            dict,
            key.as_mut_ptr(),
            strlen(key.as_mut_ptr()),
            val.as_mut_ptr() as *const ::core::ffi::c_void,
            strlen(val.as_mut_ptr()),
        ) == 0
        {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                228 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        if !((*dict).bucket_count
            == (i + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint as size_t)
        {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                229 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        let mut outsize: size_t = 0 as size_t;
        let mut retrieved_value: *const ::core::ffi::c_char = sparse_dict_get(
            dict,
            key.as_mut_ptr(),
            strlen(key.as_mut_ptr()),
            &mut outsize,
        ) as *const ::core::ffi::c_char;
        if retrieved_value.is_null() {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                233 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        if !(outsize == strlen(val.as_mut_ptr())) {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                234 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        if !(strncmp(retrieved_value, val.as_mut_ptr(), outsize)
            == 0 as ::core::ffi::c_int)
        {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                235 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        i += 1;
    }
    i = iterations - 1 as ::core::ffi::c_int;
    while i >= 0 as ::core::ffi::c_int {
        let mut key_0: [::core::ffi::c_char; 64] = [
            0 as ::core::ffi::c_int as ::core::ffi::c_char,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
        ];
        snprintf(
            key_0.as_mut_ptr(),
            ::core::mem::size_of::<[::core::ffi::c_char; 64]>() as size_t,
            b"crazy hash%i\0" as *const u8 as *const ::core::ffi::c_char,
            i,
        );
        let mut val_0: [::core::ffi::c_char; 64] = [
            0 as ::core::ffi::c_int as ::core::ffi::c_char,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
        ];
        snprintf(
            val_0.as_mut_ptr(),
            ::core::mem::size_of::<[::core::ffi::c_char; 64]>() as size_t,
            b"value%i\0" as *const u8 as *const ::core::ffi::c_char,
            i,
        );
        let mut outsize_0: size_t = 0 as size_t;
        let mut retrieved_value_0: *const ::core::ffi::c_char = sparse_dict_get(
            dict,
            key_0.as_mut_ptr(),
            strlen(key_0.as_mut_ptr()),
            &mut outsize_0,
        ) as *const ::core::ffi::c_char;
        if retrieved_value_0.is_null() {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                248 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        if !(outsize_0 == strlen(val_0.as_mut_ptr())) {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                249 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        if !(strncmp(retrieved_value_0, val_0.as_mut_ptr(), outsize_0)
            == 0 as ::core::ffi::c_int)
        {
            printf(
                b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
                250 as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        i -= 1;
    }
    if sparse_dict_free(dict) == 0 {
        printf(
            b"%i: \0" as *const u8 as *const ::core::ffi::c_char,
            253 as ::core::ffi::c_int,
        );
        return 0 as ::core::ffi::c_int;
    }
    return 1 as ::core::ffi::c_int;
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut test_return_val: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut tests_failed: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut tests_run: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    test_return_val = test_cannot_set_bigger_elements();
    if test_return_val == 0 {
        tests_failed += 1;
        printf(
            b"%c[%dmFailed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            31 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_cannot_set_bigger_elements\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {
        tests_run += 1;
        printf(
            b"%c[%dmPassed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            32 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_cannot_set_bigger_elements\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    test_return_val = test_cannot_set_outside_bounds();
    if test_return_val == 0 {
        tests_failed += 1;
        printf(
            b"%c[%dmFailed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            31 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_cannot_set_outside_bounds\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {
        tests_run += 1;
        printf(
            b"%c[%dmPassed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            32 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_cannot_set_outside_bounds\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    test_return_val = test_cannot_get_outside_bounds();
    if test_return_val == 0 {
        tests_failed += 1;
        printf(
            b"%c[%dmFailed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            31 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_cannot_get_outside_bounds\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {
        tests_run += 1;
        printf(
            b"%c[%dmPassed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            32 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_cannot_get_outside_bounds\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    test_return_val = test_empty_array_does_not_blow_up();
    if test_return_val == 0 {
        tests_failed += 1;
        printf(
            b"%c[%dmFailed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            31 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_empty_array_does_not_blow_up\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {
        tests_run += 1;
        printf(
            b"%c[%dmPassed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            32 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_empty_array_does_not_blow_up\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    test_return_val = test_array_set();
    if test_return_val == 0 {
        tests_failed += 1;
        printf(
            b"%c[%dmFailed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            31 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_array_set\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {
        tests_run += 1;
        printf(
            b"%c[%dmPassed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            32 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_array_set\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    test_return_val = test_array_set_backwards();
    if test_return_val == 0 {
        tests_failed += 1;
        printf(
            b"%c[%dmFailed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            31 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_array_set_backwards\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {
        tests_run += 1;
        printf(
            b"%c[%dmPassed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            32 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_array_set_backwards\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    test_return_val = test_array_set_overwrites_old_values();
    if test_return_val == 0 {
        tests_failed += 1;
        printf(
            b"%c[%dmFailed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            31 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_array_set_overwrites_old_values\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {
        tests_run += 1;
        printf(
            b"%c[%dmPassed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            32 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_array_set_overwrites_old_values\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    test_return_val = test_array_set_high_num();
    if test_return_val == 0 {
        tests_failed += 1;
        printf(
            b"%c[%dmFailed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            31 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_array_set_high_num\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {
        tests_run += 1;
        printf(
            b"%c[%dmPassed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            32 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_array_set_high_num\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    test_return_val = test_array_get();
    if test_return_val == 0 {
        tests_failed += 1;
        printf(
            b"%c[%dmFailed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            31 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_array_get\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {
        tests_run += 1;
        printf(
            b"%c[%dmPassed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            32 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_array_get\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    test_return_val = test_dict_set();
    if test_return_val == 0 {
        tests_failed += 1;
        printf(
            b"%c[%dmFailed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            31 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_dict_set\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {
        tests_run += 1;
        printf(
            b"%c[%dmPassed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            32 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_dict_set\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    test_return_val = test_dict_get();
    if test_return_val == 0 {
        tests_failed += 1;
        printf(
            b"%c[%dmFailed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            31 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_dict_get\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {
        tests_run += 1;
        printf(
            b"%c[%dmPassed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            32 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_dict_get\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    test_return_val = test_dict_lots_of_set();
    if test_return_val == 0 {
        tests_failed += 1;
        printf(
            b"%c[%dmFailed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            31 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_dict_lots_of_set\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {
        tests_run += 1;
        printf(
            b"%c[%dmPassed%c[%dm: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            0x1b as ::core::ffi::c_int,
            32 as ::core::ffi::c_int,
            0x1b as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"test_dict_lots_of_set\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    printf(
        b"\n-----\nTests passed: (%i/%i)\n\0" as *const u8 as *const ::core::ffi::c_char,
        tests_run,
        tests_run + tests_failed,
    );
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
