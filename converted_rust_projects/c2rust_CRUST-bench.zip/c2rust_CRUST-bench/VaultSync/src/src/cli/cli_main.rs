#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn init_repository();
    fn track_changes(n: ::core::ffi::c_int, files: *mut *const ::core::ffi::c_char);
    fn commit_changes();
    fn rollback_changes(hash: *const ::core::ffi::c_char);
    fn logger(tag: LOGGING_TAG, message: *const ::core::ffi::c_char);
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
}
pub type LOGGING_TAG = ::core::ffi::c_uint;
pub const WARNING_TAG: LOGGING_TAG = 3;
pub const ERROR_TAG: LOGGING_TAG = 2;
pub const INFO_TAG: LOGGING_TAG = 1;
pub const ARG_INIT: [::core::ffi::c_char; 5] = unsafe {
    ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"init\0")
};
pub const ARG_HELP: [::core::ffi::c_char; 7] = unsafe {
    ::core::mem::transmute::<[u8; 7], [::core::ffi::c_char; 7]>(*b"--help\0")
};
pub const ARG_HELP_SC: [::core::ffi::c_char; 3] = unsafe {
    ::core::mem::transmute::<[u8; 3], [::core::ffi::c_char; 3]>(*b"-h\0")
};
pub const ARG_ADD_CHANGES: [::core::ffi::c_char; 4] = unsafe {
    ::core::mem::transmute::<[u8; 4], [::core::ffi::c_char; 4]>(*b"add\0")
};
pub const ARG_COMMIT: [::core::ffi::c_char; 7] = unsafe {
    ::core::mem::transmute::<[u8; 7], [::core::ffi::c_char; 7]>(*b"commit\0")
};
pub const ARG_ROLLBACK: [::core::ffi::c_char; 9] = unsafe {
    ::core::mem::transmute::<[u8; 9], [::core::ffi::c_char; 9]>(*b"rollback\0")
};
#[no_mangle]
pub unsafe extern "C" fn run_cli(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *const ::core::ffi::c_char,
) {
    if argc < 2 as ::core::ffi::c_int {
        invalid_args();
        return;
    } else if argc < 3 as ::core::ffi::c_int {
        let mut init_action: ::core::ffi::c_int = (strcmp(
            *argv.offset(1 as ::core::ffi::c_int as isize),
            ARG_INIT.as_ptr(),
        ) == 0) as ::core::ffi::c_int;
        let mut commit_action: ::core::ffi::c_int = (strcmp(
            *argv.offset(1 as ::core::ffi::c_int as isize),
            ARG_COMMIT.as_ptr(),
        ) == 0) as ::core::ffi::c_int;
        let mut help_action: ::core::ffi::c_int = (strcmp(
            *argv.offset(1 as ::core::ffi::c_int as isize),
            ARG_HELP.as_ptr(),
        ) == 0
            || strcmp(
                *argv.offset(1 as ::core::ffi::c_int as isize),
                ARG_HELP_SC.as_ptr(),
            ) == 0) as ::core::ffi::c_int;
        if init_action != 0 {
            init_repository();
        } else if commit_action != 0 {
            commit_changes();
        } else if help_action != 0 {
            getting_help();
        } else {
            invalid_args();
        }
        return;
    } else if argc < 4 as ::core::ffi::c_int
        && strcmp(*argv.offset(1 as ::core::ffi::c_int as isize), ARG_ROLLBACK.as_ptr())
            == 0 as ::core::ffi::c_int
    {
        rollback_changes(*argv.offset(2 as ::core::ffi::c_int as isize));
        return;
    }
    if strcmp(*argv.offset(1 as ::core::ffi::c_int as isize), ARG_ADD_CHANGES.as_ptr())
        == 0 as ::core::ffi::c_int
    {
        track_changes(argc, argv);
        return;
    }
    invalid_args();
}
#[no_mangle]
pub unsafe extern "C" fn getting_help() {
    printf(
        b"Usage: vaultsync [OPTIONS] COMMAND\n\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    printf(b"Options:\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(
        b"  -h, --help     Show help message and exit\n\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    printf(b"Commands:\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(
        b"  init           Initialize a repository\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    printf(
        b"  commit         Make a commit\n\0" as *const u8 as *const ::core::ffi::c_char,
    );
    printf(
        b"  add [files]    Add files to be tracked in the next commit\n\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    printf(
        b"For more information, see 'man vaultsync'\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
}
#[no_mangle]
pub unsafe extern "C" fn invalid_args() {
    logger(
        INFO_TAG,
        b"Invalid arguments, check --help\0" as *const u8 as *const ::core::ffi::c_char,
    );
}
