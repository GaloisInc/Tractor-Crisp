#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn logger(tag: LOGGING_TAG, message: *const ::core::ffi::c_char);
    fn addFile(head: *mut file_node, path: *const ::core::ffi::c_char) -> *mut file_node;
    fn init_repo(repo: *mut repository, author: *mut author) -> ::core::ffi::c_int;
    fn load_repository() -> *mut repository;
    fn load_author() -> *mut author;
    fn add_changes(repo: *mut repository, files: *mut file_node) -> ::core::ffi::c_int;
    fn make_commit(
        repo: *mut repository,
        author: *mut author,
        commit: *mut commit,
    ) -> ::core::ffi::c_int;
    fn rollback(
        repo: *mut repository,
        commit_hash: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
}
pub type LOGGING_TAG = ::core::ffi::c_uint;
pub const WARNING_TAG: LOGGING_TAG = 3;
pub const ERROR_TAG: LOGGING_TAG = 2;
pub const INFO_TAG: LOGGING_TAG = 1;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct author {
    pub username: [::core::ffi::c_char; 50],
    pub mail: [::core::ffi::c_char; 100],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct repository {
    pub name: [::core::ffi::c_char; 80],
    pub author: *mut author,
    pub dir: [::core::ffi::c_char; 1024],
    pub last_commit: *mut commit,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct commit {
    pub hash: [::core::ffi::c_char; 65],
    pub author: *mut author,
    pub parent_hash: [::core::ffi::c_char; 65],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct file_node {
    pub path: [::core::ffi::c_char; 1024],
    pub next: *mut file_node,
}
pub type size_t = __darwin_size_t;
pub type __darwin_size_t = usize;
pub const SUCCESS: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn init_repository() {
    let mut author: *mut author = 0 as *mut author;
    author = load_author();
    if author.is_null() {
        logger(
            ERROR_TAG,
            b"Can not getting the author, check the default config at ~/.vsync_rc\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
        return;
    }
    let mut repo: *mut repository = 0 as *mut repository;
    if init_repo(repo, author) == SUCCESS {
        logger(
            INFO_TAG,
            b"Initialization done\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
}
#[no_mangle]
pub unsafe extern "C" fn track_changes(
    mut n: ::core::ffi::c_int,
    mut paths: *mut *const ::core::ffi::c_char,
) {
    let mut i: ::core::ffi::c_int = 2 as ::core::ffi::c_int;
    let mut files: *mut file_node = 0 as *mut file_node;
    while i < n {
        let fresh0 = i;
        i = i + 1;
        files = addFile(files, *paths.offset(fresh0 as isize));
    }
    let mut repo: *mut repository = 0 as *mut repository;
    repo = load_repository();
    if repo.is_null() {
        logger(
            ERROR_TAG,
            b"Can not getting the repo info\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return;
    }
    if add_changes(repo, files) == SUCCESS {
        logger(
            INFO_TAG,
            b"Files has been tracked successfully\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
}
#[no_mangle]
pub unsafe extern "C" fn commit_changes() {
    let mut new_commit: *mut commit = malloc(::core::mem::size_of::<commit>() as size_t)
        as *mut commit;
    let mut repo: *mut repository = 0 as *mut repository;
    let mut author: *mut author = 0 as *mut author;
    author = load_author();
    if author.is_null() {
        logger(
            ERROR_TAG,
            b"Can not getting the author, check the default config at ~/.vsync_rc\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
        return;
    }
    repo = load_repository();
    if repo.is_null() {
        logger(
            ERROR_TAG,
            b"Can not getting the repo info\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return;
    }
    if make_commit(repo, author, new_commit) == SUCCESS {
        logger(
            INFO_TAG,
            b"The commit has been done successfully\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
}
#[no_mangle]
pub unsafe extern "C" fn rollback_changes(mut hash: *const ::core::ffi::c_char) {
    let mut repo: *mut repository = 0 as *mut repository;
    repo = load_repository();
    if repo.is_null() {
        logger(
            ERROR_TAG,
            b"Can not getting the repo info\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return;
    }
    if rollback(repo, hash) == SUCCESS {
        logger(
            INFO_TAG,
            b"The rollback has been successfully done\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
}
