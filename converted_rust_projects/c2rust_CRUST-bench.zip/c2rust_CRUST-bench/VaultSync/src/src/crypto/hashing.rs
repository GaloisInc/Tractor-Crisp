#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn SHA256_Init(c: *mut SHA256_CTX) -> ::core::ffi::c_int;
    fn SHA256_Update(
        c: *mut SHA256_CTX,
        data: *const ::core::ffi::c_void,
        len: size_t,
    ) -> ::core::ffi::c_int;
    fn SHA256_Final(
        md: *mut ::core::ffi::c_uchar,
        c: *mut SHA256_CTX,
    ) -> ::core::ffi::c_int;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn exit(_: ::core::ffi::c_int) -> !;
    fn RAND_bytes(
        buf: *mut ::core::ffi::c_uchar,
        num: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
}
pub type size_t = __darwin_size_t;
pub type __darwin_size_t = usize;
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type fpos_t = __darwin_off_t;
pub type __darwin_off_t = __int64_t;
pub type __int64_t = i64;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
pub type SHA256_CTX = SHA256state_st;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct SHA256state_st {
    pub h: [::core::ffi::c_uint; 8],
    pub Nl: ::core::ffi::c_uint,
    pub Nh: ::core::ffi::c_uint,
    pub data: [::core::ffi::c_uint; 16],
    pub num: ::core::ffi::c_uint,
    pub md_len: ::core::ffi::c_uint,
}
pub const EXIT_FAILURE: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn generate_random_data(
    mut word: *mut ::core::ffi::c_char,
    mut length: ::core::ffi::c_int,
) {
    let charset: [::core::ffi::c_char; 63] = ::core::mem::transmute::<
        [u8; 63],
        [::core::ffi::c_char; 63],
    >(*b"0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ\0");
    let charset_size: size_t = (::core::mem::size_of::<[::core::ffi::c_char; 63]>()
        as size_t)
        .wrapping_sub(1 as size_t);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < length {
        if RAND_bytes(
            &mut *word.offset(i as isize) as *mut ::core::ffi::c_char
                as *mut ::core::ffi::c_uchar,
            1 as ::core::ffi::c_int,
        ) != 1 as ::core::ffi::c_int
        {
            fprintf(
                __stderrp,
                b"Error generating random byte.\n\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
            exit(EXIT_FAILURE);
        }
        *word.offset(i as isize) = charset[(*word.offset(i as isize) as size_t)
            .wrapping_rem(charset_size) as usize];
        i += 1;
    }
    *word.offset(length as isize) = '\0' as i32 as ::core::ffi::c_char;
}
#[no_mangle]
pub unsafe extern "C" fn generate_hash(
    mut data: *const ::core::ffi::c_char,
    mut length: ::core::ffi::c_int,
    mut hash: *mut ::core::ffi::c_uchar,
) {
    let mut sha256: SHA256_CTX = SHA256state_st {
        h: [0; 8],
        Nl: 0,
        Nh: 0,
        data: [0; 16],
        num: 0,
        md_len: 0,
    };
    SHA256_Init(&mut sha256);
    SHA256_Update(&mut sha256, data as *const ::core::ffi::c_void, length as size_t);
    SHA256_Final(hash, &mut sha256);
}
