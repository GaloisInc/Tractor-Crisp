#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn ctime(_: *const time_t) -> *mut ::core::ffi::c_char;
    fn time(_: *mut time_t) -> time_t;
    fn strerror(__errnum: ::core::ffi::c_int) -> *mut ::core::ffi::c_char;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn __error() -> *mut ::core::ffi::c_int;
}
pub type LOGGING_TAG = ::core::ffi::c_uint;
pub const WARNING_TAG: LOGGING_TAG = 3;
pub const ERROR_TAG: LOGGING_TAG = 2;
pub const INFO_TAG: LOGGING_TAG = 1;
pub type time_t = __darwin_time_t;
pub type __darwin_time_t = ::core::ffi::c_long;
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type fpos_t = __darwin_off_t;
pub type __darwin_off_t = __int64_t;
pub type __int64_t = i64;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
pub type size_t = __darwin_size_t;
pub type __darwin_size_t = usize;
#[no_mangle]
pub unsafe extern "C" fn logger(
    mut tag: LOGGING_TAG,
    mut message: *const ::core::ffi::c_char,
) {
    let mut now: time_t = 0;
    time(&mut now);
    let mut time_now: *mut ::core::ffi::c_char = ctime(&mut now);
    *time_now.offset(strlen(time_now).wrapping_sub(1 as size_t) as isize) = 0
        as ::core::ffi::c_char;
    match tag as ::core::ffi::c_uint {
        1 => {
            printf(
                b"%s \x1B[1m[%s]\x1B[m: %s\n\0" as *const u8
                    as *const ::core::ffi::c_char,
                time_now,
                b"INFO\0" as *const u8 as *const ::core::ffi::c_char,
                message,
            );
        }
        2 => {
            fprintf(
                __stderrp,
                b"%s \x1B[31m\x1B[1m[%s]\x1B[m\x1B[0m: %s (%s)\n\0" as *const u8
                    as *const ::core::ffi::c_char,
                time_now,
                b"ERROR\0" as *const u8 as *const ::core::ffi::c_char,
                message,
                strerror(*__error()),
            );
        }
        3 => {
            printf(
                b"%s \x1B[1m[%s]\x1B[m: %s\n\0" as *const u8
                    as *const ::core::ffi::c_char,
                time_now,
                b"WARNING\0" as *const u8 as *const ::core::ffi::c_char,
                message,
            );
        }
        _ => {}
    };
}
