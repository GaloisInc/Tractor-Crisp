#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint32_t = u32;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct amp_t {
    pub version: ::core::ffi::c_short,
    pub argc: ::core::ffi::c_short,
    pub buf: *mut ::core::ffi::c_char,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const AMP_VERSION: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
unsafe extern "C" fn read_u32_be(mut buf: *mut ::core::ffi::c_char) -> uint32_t {
    let mut n: uint32_t = 0 as uint32_t;
    n
        |= ((*buf.offset(0 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
            << 24 as ::core::ffi::c_int) as uint32_t;
    n
        |= ((*buf.offset(1 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
            << 16 as ::core::ffi::c_int) as uint32_t;
    n
        |= ((*buf.offset(2 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
            << 8 as ::core::ffi::c_int) as uint32_t;
    n |= *buf.offset(3 as ::core::ffi::c_int as isize) as uint32_t;
    return n;
}
unsafe extern "C" fn write_u32_be(mut buf: *mut ::core::ffi::c_char, mut n: uint32_t) {
    *buf.offset(0 as ::core::ffi::c_int as isize) = (n >> 24 as ::core::ffi::c_int
        & 0xff as uint32_t) as ::core::ffi::c_char;
    *buf.offset(1 as ::core::ffi::c_int as isize) = (n >> 16 as ::core::ffi::c_int
        & 0xff as uint32_t) as ::core::ffi::c_char;
    *buf.offset(2 as ::core::ffi::c_int as isize) = (n >> 8 as ::core::ffi::c_int
        & 0xff as uint32_t) as ::core::ffi::c_char;
    *buf.offset(3 as ::core::ffi::c_int as isize) = (n & 0xff as uint32_t)
        as ::core::ffi::c_char;
}
#[no_mangle]
pub unsafe extern "C" fn amp_decode(
    mut msg: *mut amp_t,
    mut buf: *mut ::core::ffi::c_char,
) {
    (*msg).version = (*buf.offset(0 as ::core::ffi::c_int as isize) as ::core::ffi::c_int
        >> 4 as ::core::ffi::c_int) as ::core::ffi::c_short;
    (*msg).argc = (*buf.offset(0 as ::core::ffi::c_int as isize) as ::core::ffi::c_int
        & 0xf as ::core::ffi::c_int) as ::core::ffi::c_short;
    (*msg).buf = buf.offset(1 as ::core::ffi::c_int as isize);
}
#[no_mangle]
pub unsafe extern "C" fn amp_decode_arg(
    mut msg: *mut amp_t,
) -> *mut ::core::ffi::c_char {
    let mut len: uint32_t = read_u32_be((*msg).buf);
    (*msg).buf = (*msg).buf.offset(4 as ::core::ffi::c_int as isize);
    let mut buf: *mut ::core::ffi::c_char = malloc(len as size_t)
        as *mut ::core::ffi::c_char;
    if buf.is_null() {
        return 0 as *mut ::core::ffi::c_char;
    }
    memcpy(
        buf as *mut ::core::ffi::c_void,
        (*msg).buf as *const ::core::ffi::c_void,
        len as size_t,
    );
    (*msg).buf = (*msg).buf.offset(len as isize);
    return buf;
}
#[no_mangle]
pub unsafe extern "C" fn amp_encode(
    mut argv: *mut *mut ::core::ffi::c_char,
    mut argc: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_char {
    let mut len: size_t = 1 as size_t;
    let vla = argc as usize;
    let mut lens: Vec<size_t> = ::std::vec::from_elem(0, vla);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < argc {
        len = len.wrapping_add(4 as size_t);
        *lens.as_mut_ptr().offset(i as isize) = strlen(*argv.offset(i as isize));
        len = len.wrapping_add(*lens.as_mut_ptr().offset(i as isize));
        i += 1;
    }
    let mut buf: *mut ::core::ffi::c_char = malloc(len) as *mut ::core::ffi::c_char;
    let mut ret: *mut ::core::ffi::c_char = buf;
    if buf.is_null() {
        return 0 as *mut ::core::ffi::c_char;
    }
    let fresh0 = buf;
    buf = buf.offset(1);
    *fresh0 = (AMP_VERSION << 4 as ::core::ffi::c_int | argc) as ::core::ffi::c_char;
    let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_0 < argc {
        let mut len_0: size_t = *lens.as_mut_ptr().offset(i_0 as isize);
        write_u32_be(buf, len_0 as uint32_t);
        buf = buf.offset(4 as ::core::ffi::c_int as isize);
        memcpy(
            buf as *mut ::core::ffi::c_void,
            *argv.offset(i_0 as isize) as *const ::core::ffi::c_void,
            len_0,
        );
        buf = buf.offset(len_0 as isize);
        i_0 += 1;
    }
    return ret;
}
