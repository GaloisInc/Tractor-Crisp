#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn amp_encode(
        argv: *mut *mut ::core::ffi::c_char,
        argc: ::core::ffi::c_int,
    ) -> *mut ::core::ffi::c_char;
    fn amp_decode(msg: *mut amp_t, buf: *mut ::core::ffi::c_char);
    fn amp_decode_arg(msg: *mut amp_t) -> *mut ::core::ffi::c_char;
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct amp_t {
    pub version: ::core::ffi::c_short,
    pub argc: ::core::ffi::c_short,
    pub buf: *mut ::core::ffi::c_char,
}
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut args: [*mut ::core::ffi::c_char; 3] = [
        b"some\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
        b"stuff\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_char,
        b"here\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    ];
    let mut buf: *mut ::core::ffi::c_char = amp_encode(
        args.as_mut_ptr(),
        3 as ::core::ffi::c_int,
    );
    let mut msg: amp_t = {
        let mut init = amp_t {
            version: 0 as ::core::ffi::c_short,
            argc: 0,
            buf: 0 as *mut ::core::ffi::c_char,
        };
        init
    };
    amp_decode(&mut msg, buf);
    if !(1 as ::core::ffi::c_int == msg.version as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            17 as ::core::ffi::c_int,
            b"1 == msg.version\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(3 as ::core::ffi::c_int == msg.argc as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            18 as ::core::ffi::c_int,
            b"3 == msg.argc\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < msg.argc as ::core::ffi::c_int {
        let mut arg: *mut ::core::ffi::c_char = amp_decode_arg(&mut msg);
        match i {
            0 => {
                if !(0 as ::core::ffi::c_int
                    == strcmp(b"some\0" as *const u8 as *const ::core::ffi::c_char, arg))
                    as ::core::ffi::c_int as ::core::ffi::c_long != 0
                {
                    __assert_rtn(
                        ::core::mem::transmute::<
                            [u8; 5],
                            [::core::ffi::c_char; 5],
                        >(*b"main\0")
                            .as_ptr(),
                        b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
                        25 as ::core::ffi::c_int,
                        b"0 == strcmp(\"some\", arg)\0" as *const u8
                            as *const ::core::ffi::c_char,
                    );
                } else {};
            }
            1 => {
                if !(0 as ::core::ffi::c_int
                    == strcmp(
                        b"stuff\0" as *const u8 as *const ::core::ffi::c_char,
                        arg,
                    )) as ::core::ffi::c_int as ::core::ffi::c_long != 0
                {
                    __assert_rtn(
                        ::core::mem::transmute::<
                            [u8; 5],
                            [::core::ffi::c_char; 5],
                        >(*b"main\0")
                            .as_ptr(),
                        b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
                        28 as ::core::ffi::c_int,
                        b"0 == strcmp(\"stuff\", arg)\0" as *const u8
                            as *const ::core::ffi::c_char,
                    );
                } else {};
            }
            2 => {
                if !(0 as ::core::ffi::c_int
                    == strcmp(b"here\0" as *const u8 as *const ::core::ffi::c_char, arg))
                    as ::core::ffi::c_int as ::core::ffi::c_long != 0
                {
                    __assert_rtn(
                        ::core::mem::transmute::<
                            [u8; 5],
                            [::core::ffi::c_char; 5],
                        >(*b"main\0")
                            .as_ptr(),
                        b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
                        31 as ::core::ffi::c_int,
                        b"0 == strcmp(\"here\", arg)\0" as *const u8
                            as *const ::core::ffi::c_char,
                    );
                } else {};
            }
            _ => {}
        }
        i += 1;
    }
    printf(b"ok\n\0" as *const u8 as *const ::core::ffi::c_char);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
