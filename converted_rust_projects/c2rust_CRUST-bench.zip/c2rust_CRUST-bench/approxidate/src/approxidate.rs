#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn gettimeofday(_: *mut timeval, _: *mut ::core::ffi::c_void) -> ::core::ffi::c_int;
    fn pow(_: ::core::ffi::c_double, _: ::core::ffi::c_double) -> ::core::ffi::c_double;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn mktime(_: *mut tm) -> time_t;
    fn time(_: *mut time_t) -> time_t;
    fn gmtime_r(_: *const time_t, _: *mut tm) -> *mut tm;
    fn localtime_r(_: *const time_t, _: *mut tm) -> *mut tm;
    fn strtol(
        __str: *const ::core::ffi::c_char,
        __endptr: *mut *mut ::core::ffi::c_char,
        __base: ::core::ffi::c_int,
    ) -> ::core::ffi::c_long;
    fn strtoul(
        __str: *const ::core::ffi::c_char,
        __endptr: *mut *mut ::core::ffi::c_char,
        __base: ::core::ffi::c_int,
    ) -> ::core::ffi::c_ulong;
}
pub type __int32_t = i32;
pub type __darwin_size_t = usize;
pub type __darwin_time_t = ::core::ffi::c_long;
pub type __darwin_suseconds_t = __int32_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct timeval {
    pub tv_sec: __darwin_time_t,
    pub tv_usec: __darwin_suseconds_t,
}
pub type time_t = __darwin_time_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct atm {
    pub tm_sec: ::core::ffi::c_int,
    pub tm_min: ::core::ffi::c_int,
    pub tm_hour: ::core::ffi::c_int,
    pub tm_mday: ::core::ffi::c_int,
    pub tm_mon: ::core::ffi::c_int,
    pub tm_year: ::core::ffi::c_int,
    pub tm_wday: ::core::ffi::c_int,
    pub tm_yday: ::core::ffi::c_int,
    pub tm_isdst: ::core::ffi::c_int,
    pub tm_usec: ::core::ffi::c_long,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tm {
    pub tm_sec: ::core::ffi::c_int,
    pub tm_min: ::core::ffi::c_int,
    pub tm_hour: ::core::ffi::c_int,
    pub tm_mday: ::core::ffi::c_int,
    pub tm_mon: ::core::ffi::c_int,
    pub tm_year: ::core::ffi::c_int,
    pub tm_wday: ::core::ffi::c_int,
    pub tm_yday: ::core::ffi::c_int,
    pub tm_isdst: ::core::ffi::c_int,
    pub tm_gmtoff: ::core::ffi::c_long,
    pub tm_zone: *mut ::core::ffi::c_char,
}
pub const X: C2RustUnnamed_0 = 64;
pub const P: C2RustUnnamed_0 = 32;
pub const U: C2RustUnnamed_0 = 128;
pub const R: C2RustUnnamed_0 = 16;
pub const A: C2RustUnnamed_0 = 4;
pub const G: C2RustUnnamed_0 = 8;
pub const D: C2RustUnnamed_0 = 2;
pub const S: C2RustUnnamed_0 = 1;
pub const Z: C2RustUnnamed_0 = 65;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct typelen {
    pub type_0: *const ::core::ffi::c_char,
    pub length: ::core::ffi::c_int,
}
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct special {
    pub name: *const ::core::ffi::c_char,
    pub fn_0: Option<
        unsafe extern "C" fn(*mut atm, *mut atm, *mut ::core::ffi::c_int) -> (),
    >,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct C2RustUnnamed {
    pub name: *const ::core::ffi::c_char,
    pub offset: ::core::ffi::c_int,
    pub dst: ::core::ffi::c_int,
}
pub type C2RustUnnamed_0 = ::core::ffi::c_uint;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const ULONG_MAX: ::core::ffi::c_ulong = 0xffffffffffffffff as ::core::ffi::c_ulong;
#[no_mangle]
pub static mut sane_ctype: [::core::ffi::c_uchar; 256] = [
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    Z as ::core::ffi::c_int as ::core::ffi::c_uchar,
    Z as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    Z as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    S as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    R as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    R as ::core::ffi::c_int as ::core::ffi::c_uchar,
    R as ::core::ffi::c_int as ::core::ffi::c_uchar,
    G as ::core::ffi::c_int as ::core::ffi::c_uchar,
    R as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    R as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    D as ::core::ffi::c_int as ::core::ffi::c_uchar,
    D as ::core::ffi::c_int as ::core::ffi::c_uchar,
    D as ::core::ffi::c_int as ::core::ffi::c_uchar,
    D as ::core::ffi::c_int as ::core::ffi::c_uchar,
    D as ::core::ffi::c_int as ::core::ffi::c_uchar,
    D as ::core::ffi::c_int as ::core::ffi::c_uchar,
    D as ::core::ffi::c_int as ::core::ffi::c_uchar,
    D as ::core::ffi::c_int as ::core::ffi::c_uchar,
    D as ::core::ffi::c_int as ::core::ffi::c_uchar,
    D as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    G as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    G as ::core::ffi::c_int as ::core::ffi::c_uchar,
    G as ::core::ffi::c_int as ::core::ffi::c_uchar,
    U as ::core::ffi::c_int as ::core::ffi::c_uchar,
    R as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    A as ::core::ffi::c_int as ::core::ffi::c_uchar,
    R as ::core::ffi::c_int as ::core::ffi::c_uchar,
    R as ::core::ffi::c_int as ::core::ffi::c_uchar,
    U as ::core::ffi::c_int as ::core::ffi::c_uchar,
    P as ::core::ffi::c_int as ::core::ffi::c_uchar,
    X as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
];
#[inline]
unsafe extern "C" fn sane_case(
    mut x: ::core::ffi::c_int,
    mut high: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    if sane_ctype[x as ::core::ffi::c_uchar as usize] as ::core::ffi::c_int
        & 0x4 as ::core::ffi::c_int != 0 as ::core::ffi::c_int
    {
        x = x & !(0x20 as ::core::ffi::c_int) | high;
    }
    return x;
}
unsafe extern "C" fn tm_to_time_t(mut tm: *const atm) -> time_t {
    static mut mdays: [::core::ffi::c_int; 12] = [
        0 as ::core::ffi::c_int,
        31 as ::core::ffi::c_int,
        59 as ::core::ffi::c_int,
        90 as ::core::ffi::c_int,
        120 as ::core::ffi::c_int,
        151 as ::core::ffi::c_int,
        181 as ::core::ffi::c_int,
        212 as ::core::ffi::c_int,
        243 as ::core::ffi::c_int,
        273 as ::core::ffi::c_int,
        304 as ::core::ffi::c_int,
        334 as ::core::ffi::c_int,
    ];
    let mut year: ::core::ffi::c_int = (*tm).tm_year - 70 as ::core::ffi::c_int;
    let mut month: ::core::ffi::c_int = (*tm).tm_mon;
    let mut day: ::core::ffi::c_int = (*tm).tm_mday;
    if year < 0 as ::core::ffi::c_int || year > 129 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int) as time_t;
    }
    if month < 0 as ::core::ffi::c_int || month > 11 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int) as time_t;
    }
    if month < 2 as ::core::ffi::c_int
        || (year + 2 as ::core::ffi::c_int) % 4 as ::core::ffi::c_int != 0
    {
        day -= 1;
    }
    if (*tm).tm_hour < 0 as ::core::ffi::c_int || (*tm).tm_min < 0 as ::core::ffi::c_int
        || (*tm).tm_sec < 0 as ::core::ffi::c_int
    {
        return -(1 as ::core::ffi::c_int) as time_t;
    }
    return (((year * 365 as ::core::ffi::c_int
        + (year + 1 as ::core::ffi::c_int) / 4 as ::core::ffi::c_int
        + mdays[month as usize] + day) * 24 as ::core::ffi::c_int
        * 60 as ::core::ffi::c_int) as ::core::ffi::c_ulong)
        .wrapping_mul(60 as ::core::ffi::c_ulong)
        .wrapping_add(
            ((*tm).tm_hour * 60 as ::core::ffi::c_int * 60 as ::core::ffi::c_int)
                as ::core::ffi::c_ulong,
        )
        .wrapping_add(((*tm).tm_min * 60 as ::core::ffi::c_int) as ::core::ffi::c_ulong)
        .wrapping_add((*tm).tm_sec as ::core::ffi::c_ulong) as time_t;
}
static mut month_names: [*const ::core::ffi::c_char; 12] = [
    b"January\0" as *const u8 as *const ::core::ffi::c_char,
    b"February\0" as *const u8 as *const ::core::ffi::c_char,
    b"March\0" as *const u8 as *const ::core::ffi::c_char,
    b"April\0" as *const u8 as *const ::core::ffi::c_char,
    b"May\0" as *const u8 as *const ::core::ffi::c_char,
    b"June\0" as *const u8 as *const ::core::ffi::c_char,
    b"July\0" as *const u8 as *const ::core::ffi::c_char,
    b"August\0" as *const u8 as *const ::core::ffi::c_char,
    b"September\0" as *const u8 as *const ::core::ffi::c_char,
    b"October\0" as *const u8 as *const ::core::ffi::c_char,
    b"November\0" as *const u8 as *const ::core::ffi::c_char,
    b"December\0" as *const u8 as *const ::core::ffi::c_char,
];
static mut weekday_names: [*const ::core::ffi::c_char; 7] = [
    b"Sundays\0" as *const u8 as *const ::core::ffi::c_char,
    b"Mondays\0" as *const u8 as *const ::core::ffi::c_char,
    b"Tuesdays\0" as *const u8 as *const ::core::ffi::c_char,
    b"Wednesdays\0" as *const u8 as *const ::core::ffi::c_char,
    b"Thursdays\0" as *const u8 as *const ::core::ffi::c_char,
    b"Fridays\0" as *const u8 as *const ::core::ffi::c_char,
    b"Saturdays\0" as *const u8 as *const ::core::ffi::c_char,
];
static mut timezone_names: [C2RustUnnamed; 44] = [
    {
        let mut init = C2RustUnnamed {
            name: b"IDLW\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(12 as ::core::ffi::c_int),
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"NT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(11 as ::core::ffi::c_int),
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"CAT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(10 as ::core::ffi::c_int),
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"HST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(10 as ::core::ffi::c_int),
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"HDT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(10 as ::core::ffi::c_int),
            dst: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"YST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(9 as ::core::ffi::c_int),
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"YDT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(9 as ::core::ffi::c_int),
            dst: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"PST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(8 as ::core::ffi::c_int),
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"PDT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(8 as ::core::ffi::c_int),
            dst: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"MST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(7 as ::core::ffi::c_int),
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"MDT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(7 as ::core::ffi::c_int),
            dst: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"CST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(6 as ::core::ffi::c_int),
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"CDT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(6 as ::core::ffi::c_int),
            dst: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"EST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(5 as ::core::ffi::c_int),
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"EDT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(5 as ::core::ffi::c_int),
            dst: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"AST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(3 as ::core::ffi::c_int),
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"ADT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(3 as ::core::ffi::c_int),
            dst: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"WAT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: -(1 as ::core::ffi::c_int),
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"GMT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 0 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"UTC\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 0 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"Z\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 0 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"WET\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 0 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"BST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 0 as ::core::ffi::c_int,
            dst: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"CET\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 1 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"MET\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 1 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"MEWT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 1 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"MEST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 1 as ::core::ffi::c_int,
            dst: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"CEST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 1 as ::core::ffi::c_int,
            dst: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"MESZ\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 1 as ::core::ffi::c_int,
            dst: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"FWT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 1 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"FST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 1 as ::core::ffi::c_int,
            dst: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"EET\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 2 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"EEST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 2 as ::core::ffi::c_int,
            dst: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"WAST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 7 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"WADT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 7 as ::core::ffi::c_int,
            dst: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"CCT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 8 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"JST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 9 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"EAST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 10 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"EADT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 10 as ::core::ffi::c_int,
            dst: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"GST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 10 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"NZT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 12 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"NZST\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 12 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"NZDT\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 12 as ::core::ffi::c_int,
            dst: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = C2RustUnnamed {
            name: b"IDLE\0" as *const u8 as *const ::core::ffi::c_char,
            offset: 12 as ::core::ffi::c_int,
            dst: 0 as ::core::ffi::c_int,
        };
        init
    },
];
unsafe extern "C" fn match_string(
    mut date: *const ::core::ffi::c_char,
    mut str: *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    i = 0 as ::core::ffi::c_int;
    while *date != 0 {
        if !(*date as ::core::ffi::c_int == *str as ::core::ffi::c_int) {
            if !(sane_case(
                *date as ::core::ffi::c_uchar as ::core::ffi::c_int,
                0 as ::core::ffi::c_int,
            )
                == sane_case(
                    *str as ::core::ffi::c_uchar as ::core::ffi::c_int,
                    0 as ::core::ffi::c_int,
                ))
            {
                if !(sane_ctype[*date as ::core::ffi::c_uchar as usize]
                    as ::core::ffi::c_int
                    & (0x4 as ::core::ffi::c_int | 0x2 as ::core::ffi::c_int)
                    != 0 as ::core::ffi::c_int)
                {
                    break;
                }
                return 0 as ::core::ffi::c_int;
            }
        }
        date = date.offset(1);
        str = str.offset(1);
        i += 1;
    }
    return i;
}
unsafe extern "C" fn skip_alpha(
    mut date: *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    loop {
        i += 1;
        if !(sane_ctype[*date.offset(i as isize) as ::core::ffi::c_uchar as usize]
            as ::core::ffi::c_int & 0x4 as ::core::ffi::c_int != 0 as ::core::ffi::c_int)
        {
            break;
        }
    }
    return i;
}
unsafe extern "C" fn match_alpha(
    mut date: *const ::core::ffi::c_char,
    mut tm: *mut atm,
    mut offset: *mut ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut i: ::core::ffi::c_int = 0;
    i = 0 as ::core::ffi::c_int;
    while i < 12 as ::core::ffi::c_int {
        let mut match_0: ::core::ffi::c_int = match_string(
            date,
            month_names[i as usize],
        );
        if match_0 >= 3 as ::core::ffi::c_int {
            (*tm).tm_mon = i;
            return match_0;
        }
        i += 1;
    }
    i = 0 as ::core::ffi::c_int;
    while i < 7 as ::core::ffi::c_int {
        let mut match_1: ::core::ffi::c_int = match_string(
            date,
            weekday_names[i as usize],
        );
        if match_1 >= 3 as ::core::ffi::c_int {
            (*tm).tm_wday = i;
            return match_1;
        }
        i += 1;
    }
    i = 0 as ::core::ffi::c_int;
    while (i as usize)
        < (::core::mem::size_of::<[C2RustUnnamed; 44]>() as usize)
            .wrapping_div(::core::mem::size_of::<C2RustUnnamed>() as usize)
    {
        let mut match_2: ::core::ffi::c_int = match_string(
            date,
            timezone_names[i as usize].name,
        );
        if match_2 >= 3 as ::core::ffi::c_int
            || match_2 as size_t == strlen(timezone_names[i as usize].name)
        {
            let mut off: ::core::ffi::c_int = timezone_names[i as usize].offset;
            off += timezone_names[i as usize].dst;
            if *offset == -(1 as ::core::ffi::c_int) {
                *offset = 60 as ::core::ffi::c_int * off;
            }
            return match_2;
        }
        i += 1;
    }
    if match_string(date, b"PM\0" as *const u8 as *const ::core::ffi::c_char)
        == 2 as ::core::ffi::c_int
    {
        (*tm).tm_hour = (*tm).tm_hour % 12 as ::core::ffi::c_int
            + 12 as ::core::ffi::c_int;
        return 2 as ::core::ffi::c_int;
    }
    if match_string(date, b"AM\0" as *const u8 as *const ::core::ffi::c_char)
        == 2 as ::core::ffi::c_int
    {
        (*tm).tm_hour = (*tm).tm_hour % 12 as ::core::ffi::c_int
            + 0 as ::core::ffi::c_int;
        return 2 as ::core::ffi::c_int;
    }
    return skip_alpha(date);
}
unsafe extern "C" fn is_date(
    mut year: ::core::ffi::c_int,
    mut month: ::core::ffi::c_int,
    mut day: ::core::ffi::c_int,
    mut now_tm: *mut atm,
    mut now: time_t,
    mut tm: *mut atm,
) -> ::core::ffi::c_int {
    if month > 0 as ::core::ffi::c_int && month < 13 as ::core::ffi::c_int
        && day > 0 as ::core::ffi::c_int && day < 32 as ::core::ffi::c_int
    {
        let mut check: atm = *tm;
        let mut r: *mut atm = if !now_tm.is_null() { &mut check } else { tm };
        (*r).tm_mon = month - 1 as ::core::ffi::c_int;
        (*r).tm_mday = day;
        if year == -(1 as ::core::ffi::c_int) {
            if now_tm.is_null() {
                return 1 as ::core::ffi::c_int;
            }
            (*r).tm_year = (*now_tm).tm_year;
        } else if year >= 1970 as ::core::ffi::c_int && year < 2100 as ::core::ffi::c_int
        {
            (*r).tm_year = year - 1900 as ::core::ffi::c_int;
        } else if year > 70 as ::core::ffi::c_int && year < 100 as ::core::ffi::c_int {
            (*r).tm_year = year;
        } else if year < 38 as ::core::ffi::c_int {
            (*r).tm_year = year + 100 as ::core::ffi::c_int;
        } else {
            return 0 as ::core::ffi::c_int
        }
        if now_tm.is_null() {
            return 1 as ::core::ffi::c_int;
        }
        (*tm).tm_mon = (*r).tm_mon;
        (*tm).tm_mday = (*r).tm_mday;
        if year != -(1 as ::core::ffi::c_int) {
            (*tm).tm_year = (*r).tm_year;
        }
        return 1 as ::core::ffi::c_int;
    }
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn match_multi_number(
    mut num: ::core::ffi::c_ulong,
    mut c: ::core::ffi::c_char,
    mut date: *const ::core::ffi::c_char,
    mut end: *mut ::core::ffi::c_char,
    mut tm: *mut atm,
    mut now: time_t,
) -> ::core::ffi::c_int {
    let mut num2: ::core::ffi::c_long = 0;
    let mut num3: ::core::ffi::c_long = 0;
    let mut num4: ::core::ffi::c_long = 0;
    num2 = strtol(
        end.offset(1 as ::core::ffi::c_int as isize),
        &mut end,
        10 as ::core::ffi::c_int,
    );
    num3 = -(1 as ::core::ffi::c_int) as ::core::ffi::c_long;
    num4 = 0 as ::core::ffi::c_long;
    if *end as ::core::ffi::c_int == c as ::core::ffi::c_int
        && sane_ctype[*end.offset(1 as ::core::ffi::c_int as isize)
            as ::core::ffi::c_uchar as usize] as ::core::ffi::c_int
            & 0x2 as ::core::ffi::c_int != 0 as ::core::ffi::c_int
    {
        num3 = strtol(
            end.offset(1 as ::core::ffi::c_int as isize),
            &mut end,
            10 as ::core::ffi::c_int,
        );
        if *end as ::core::ffi::c_int == '.' as i32 {
            let mut start: *mut ::core::ffi::c_char = end
                .offset(1 as ::core::ffi::c_int as isize);
            num4 = strtol(
                end.offset(1 as ::core::ffi::c_int as isize),
                &mut end,
                10 as ::core::ffi::c_int,
            );
            if (end.offset_from(start) as ::core::ffi::c_long) < 6 as ::core::ffi::c_long
            {
                num4
                    *= pow(
                        10 as ::core::ffi::c_int as ::core::ffi::c_double,
                        (6 as ::core::ffi::c_long
                            - end.offset_from(start) as ::core::ffi::c_long)
                            as ::core::ffi::c_double,
                    ) as ::core::ffi::c_long;
            }
        }
    }
    let mut current_block_21: u64;
    match c as ::core::ffi::c_int {
        58 => {
            if num3 < 0 as ::core::ffi::c_long {
                num3 = 0 as ::core::ffi::c_long;
            }
            if num < 25 as ::core::ffi::c_ulong && num2 >= 0 as ::core::ffi::c_long
                && num2 < 60 as ::core::ffi::c_long && num3 >= 0 as ::core::ffi::c_long
                && num3 <= 60 as ::core::ffi::c_long
            {
                (*tm).tm_hour = num as ::core::ffi::c_int;
                (*tm).tm_min = num2 as ::core::ffi::c_int;
                (*tm).tm_sec = num3 as ::core::ffi::c_int;
                (*tm).tm_usec = num4;
            } else {
                return 0 as ::core::ffi::c_int
            }
        }
        45 | 47 | 46 => {
            if now == 0 {
                now = time(0 as *mut time_t);
            }
            if num > 70 as ::core::ffi::c_ulong {
                if is_date(
                    num as ::core::ffi::c_int,
                    num2 as ::core::ffi::c_int,
                    num3 as ::core::ffi::c_int,
                    0 as *mut atm,
                    now,
                    tm,
                ) != 0
                {
                    current_block_21 = 7056779235015430508;
                } else if is_date(
                    num as ::core::ffi::c_int,
                    num3 as ::core::ffi::c_int,
                    num2 as ::core::ffi::c_int,
                    0 as *mut atm,
                    now,
                    tm,
                ) != 0
                {
                    current_block_21 = 7056779235015430508;
                } else {
                    current_block_21 = 1109700713171191020;
                }
            } else {
                current_block_21 = 1109700713171191020;
            }
            match current_block_21 {
                7056779235015430508 => {}
                _ => {
                    if !(c as ::core::ffi::c_int != '.' as i32
                        && is_date(
                            num3 as ::core::ffi::c_int,
                            num as ::core::ffi::c_int,
                            num2 as ::core::ffi::c_int,
                            0 as *mut atm,
                            now,
                            tm,
                        ) != 0)
                    {
                        if !(is_date(
                            num3 as ::core::ffi::c_int,
                            num2 as ::core::ffi::c_int,
                            num as ::core::ffi::c_int,
                            0 as *mut atm,
                            now,
                            tm,
                        ) != 0)
                        {
                            if !(c as ::core::ffi::c_int == '.' as i32
                                && is_date(
                                    num3 as ::core::ffi::c_int,
                                    num as ::core::ffi::c_int,
                                    num2 as ::core::ffi::c_int,
                                    0 as *mut atm,
                                    now,
                                    tm,
                                ) != 0)
                            {
                                return 0 as ::core::ffi::c_int;
                            }
                        }
                    }
                }
            }
        }
        _ => {}
    }
    return end.offset_from(date) as ::core::ffi::c_long as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn nodate(mut tm: *mut tm) -> ::core::ffi::c_int {
    return ((*tm).tm_year & (*tm).tm_mon & (*tm).tm_mday & (*tm).tm_hour & (*tm).tm_min
        & (*tm).tm_sec < 0 as ::core::ffi::c_int) as ::core::ffi::c_int;
}
unsafe extern "C" fn match_digit(
    mut date: *const ::core::ffi::c_char,
    mut tm: *mut atm,
    mut offset: *mut ::core::ffi::c_int,
    mut tm_gmt: *mut ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut n: ::core::ffi::c_int = 0;
    let mut end: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut num: ::core::ffi::c_ulong = 0;
    num = strtoul(date, &mut end, 10 as ::core::ffi::c_int);
    if num >= 100000000 as ::core::ffi::c_ulong && nodate(tm as *mut tm) != 0 {
        let mut time_0: time_t = num as time_t;
        if !gmtime_r(&mut time_0, tm as *mut tm).is_null() {
            *tm_gmt = 1 as ::core::ffi::c_int;
            return end.offset_from(date) as ::core::ffi::c_long as ::core::ffi::c_int;
        }
    }
    match *end as ::core::ffi::c_int {
        58 | 46 | 47 | 45 => {
            if sane_ctype[*end.offset(1 as ::core::ffi::c_int as isize)
                as ::core::ffi::c_uchar as usize] as ::core::ffi::c_int
                & 0x2 as ::core::ffi::c_int != 0 as ::core::ffi::c_int
            {
                let mut match_0: ::core::ffi::c_int = match_multi_number(
                    num,
                    *end,
                    date,
                    end,
                    tm,
                    0 as time_t,
                );
                if match_0 != 0 {
                    return match_0;
                }
            }
        }
        _ => {}
    }
    n = 0 as ::core::ffi::c_int;
    loop {
        n += 1;
        if !(sane_ctype[*date.offset(n as isize) as ::core::ffi::c_uchar as usize]
            as ::core::ffi::c_int & 0x2 as ::core::ffi::c_int != 0 as ::core::ffi::c_int)
        {
            break;
        }
    }
    if n == 4 as ::core::ffi::c_int {
        if num <= 1400 as ::core::ffi::c_ulong && *offset == -(1 as ::core::ffi::c_int) {
            let mut minutes: ::core::ffi::c_uint = num
                .wrapping_rem(100 as ::core::ffi::c_ulong) as ::core::ffi::c_uint;
            let mut hours: ::core::ffi::c_uint = num
                .wrapping_div(100 as ::core::ffi::c_ulong) as ::core::ffi::c_uint;
            *offset = hours.wrapping_mul(60 as ::core::ffi::c_uint).wrapping_add(minutes)
                as ::core::ffi::c_int;
        } else if num > 1900 as ::core::ffi::c_ulong
            && num < 2100 as ::core::ffi::c_ulong
        {
            (*tm).tm_year = num.wrapping_sub(1900 as ::core::ffi::c_ulong)
                as ::core::ffi::c_int;
        }
        return n;
    }
    if n > 2 as ::core::ffi::c_int {
        return n;
    }
    if num > 0 as ::core::ffi::c_ulong && num < 32 as ::core::ffi::c_ulong
        && (*tm).tm_mday < 0 as ::core::ffi::c_int
    {
        (*tm).tm_mday = num as ::core::ffi::c_int;
        return n;
    }
    if n == 2 as ::core::ffi::c_int && (*tm).tm_year < 0 as ::core::ffi::c_int {
        if num < 10 as ::core::ffi::c_ulong && (*tm).tm_mday >= 0 as ::core::ffi::c_int {
            (*tm).tm_year = num.wrapping_add(100 as ::core::ffi::c_ulong)
                as ::core::ffi::c_int;
            return n;
        }
        if num >= 70 as ::core::ffi::c_ulong {
            (*tm).tm_year = num as ::core::ffi::c_int;
            return n;
        }
    }
    if num > 0 as ::core::ffi::c_ulong && num < 13 as ::core::ffi::c_ulong
        && (*tm).tm_mon < 0 as ::core::ffi::c_int
    {
        (*tm).tm_mon = num.wrapping_sub(1 as ::core::ffi::c_ulong) as ::core::ffi::c_int;
    }
    return n;
}
unsafe extern "C" fn match_tz(
    mut date: *const ::core::ffi::c_char,
    mut offp: *mut ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut end: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut hour: ::core::ffi::c_int = strtoul(
        date.offset(1 as ::core::ffi::c_int as isize),
        &mut end,
        10 as ::core::ffi::c_int,
    ) as ::core::ffi::c_int;
    let mut n: ::core::ffi::c_int = end
        .offset_from(date.offset(1 as ::core::ffi::c_int as isize))
        as ::core::ffi::c_long as ::core::ffi::c_int;
    let mut min: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    if n == 4 as ::core::ffi::c_int {
        min = hour % 100 as ::core::ffi::c_int;
        hour = hour / 100 as ::core::ffi::c_int;
    } else if n != 2 as ::core::ffi::c_int {
        min = 99 as ::core::ffi::c_int;
    } else if *end as ::core::ffi::c_int == ':' as i32 {
        min = strtoul(
            end.offset(1 as ::core::ffi::c_int as isize),
            &mut end,
            10 as ::core::ffi::c_int,
        ) as ::core::ffi::c_int;
        if end.offset_from(date.offset(1 as ::core::ffi::c_int as isize))
            as ::core::ffi::c_long != 5 as ::core::ffi::c_long
        {
            min = 99 as ::core::ffi::c_int;
        }
    }
    if min < 60 as ::core::ffi::c_int && hour < 24 as ::core::ffi::c_int {
        let mut offset: ::core::ffi::c_int = hour * 60 as ::core::ffi::c_int + min;
        if *date as ::core::ffi::c_int == '-' as i32 {
            offset = -offset;
        }
        *offp = offset;
    }
    return end.offset_from(date) as ::core::ffi::c_long as ::core::ffi::c_int;
}
unsafe extern "C" fn match_object_header_date(
    mut date: *const ::core::ffi::c_char,
    mut tv: *mut timeval,
    mut offset: *mut ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut end: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut stamp: ::core::ffi::c_ulong = 0;
    let mut ofs: ::core::ffi::c_int = 0;
    if (*date as ::core::ffi::c_int) < '0' as i32
        || ('9' as i32) < *date as ::core::ffi::c_int
    {
        return -(1 as ::core::ffi::c_int);
    }
    stamp = strtoul(date, &mut end, 10 as ::core::ffi::c_int);
    if *end as ::core::ffi::c_int != ' ' as i32 || stamp == ULONG_MAX
        || *end.offset(1 as ::core::ffi::c_int as isize) as ::core::ffi::c_int
            != '+' as i32
            && *end.offset(1 as ::core::ffi::c_int as isize) as ::core::ffi::c_int
                != '-' as i32
    {
        return -(1 as ::core::ffi::c_int);
    }
    date = end.offset(2 as ::core::ffi::c_int as isize);
    ofs = strtol(date, &mut end, 10 as ::core::ffi::c_int) as ::core::ffi::c_int;
    if *end as ::core::ffi::c_int != '\0' as i32
        && *end as ::core::ffi::c_int != '\n' as i32
        || end
            != date.offset(4 as ::core::ffi::c_int as isize) as *mut ::core::ffi::c_char
    {
        return -(1 as ::core::ffi::c_int);
    }
    ofs = ofs / 100 as ::core::ffi::c_int * 60 as ::core::ffi::c_int
        + ofs % 100 as ::core::ffi::c_int;
    if *date.offset(-(1 as ::core::ffi::c_int) as isize) as ::core::ffi::c_int
        == '-' as i32
    {
        ofs = -ofs;
    }
    (*tv).tv_sec = stamp as __darwin_time_t;
    *offset = ofs;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn parse_date_basic(
    mut date: *const ::core::ffi::c_char,
    mut tv: *mut timeval,
    mut offset: *mut ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut tm: atm = atm {
        tm_sec: 0,
        tm_min: 0,
        tm_hour: 0,
        tm_mday: 0,
        tm_mon: 0,
        tm_year: 0,
        tm_wday: 0,
        tm_yday: 0,
        tm_isdst: 0,
        tm_usec: 0,
    };
    let mut tm_gmt: ::core::ffi::c_int = 0;
    let mut dummy_offset: ::core::ffi::c_int = 0;
    if offset.is_null() {
        offset = &mut dummy_offset;
    }
    memset(
        &mut tm as *mut atm as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<atm>() as size_t,
    );
    tm.tm_year = -(1 as ::core::ffi::c_int);
    tm.tm_mon = -(1 as ::core::ffi::c_int);
    tm.tm_mday = -(1 as ::core::ffi::c_int);
    tm.tm_isdst = -(1 as ::core::ffi::c_int);
    tm.tm_hour = -(1 as ::core::ffi::c_int);
    tm.tm_min = -(1 as ::core::ffi::c_int);
    tm.tm_sec = -(1 as ::core::ffi::c_int);
    tm.tm_usec = 0 as ::core::ffi::c_long;
    *offset = -(1 as ::core::ffi::c_int);
    tm_gmt = 0 as ::core::ffi::c_int;
    if *date as ::core::ffi::c_int == '@' as i32
        && match_object_header_date(
            date.offset(1 as ::core::ffi::c_int as isize),
            tv,
            offset,
        ) == 0
    {
        return 0 as ::core::ffi::c_int;
    }
    loop {
        let mut match_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        let mut c: ::core::ffi::c_uchar = *date as ::core::ffi::c_uchar;
        if c == 0 || c as ::core::ffi::c_int == '\n' as i32 {
            break;
        }
        if sane_ctype[c as usize] as ::core::ffi::c_int & 0x4 as ::core::ffi::c_int
            != 0 as ::core::ffi::c_int
        {
            match_0 = match_alpha(date, &mut tm, offset);
        } else if sane_ctype[c as usize] as ::core::ffi::c_int
            & 0x2 as ::core::ffi::c_int != 0 as ::core::ffi::c_int
        {
            match_0 = match_digit(date, &mut tm, offset, &mut tm_gmt);
        } else if (c as ::core::ffi::c_int == '-' as i32
            || c as ::core::ffi::c_int == '+' as i32)
            && sane_ctype[*date.offset(1 as ::core::ffi::c_int as isize)
                as ::core::ffi::c_uchar as usize] as ::core::ffi::c_int
                & 0x2 as ::core::ffi::c_int != 0 as ::core::ffi::c_int
        {
            match_0 = match_tz(date, offset);
        }
        if match_0 == 0 {
            match_0 = 1 as ::core::ffi::c_int;
        }
        date = date.offset(match_0 as isize);
    }
    (*tv).tv_usec = tm.tm_usec as __darwin_suseconds_t;
    (*tv).tv_sec = tm_to_time_t(&mut tm) as __darwin_time_t;
    if *offset == -(1 as ::core::ffi::c_int) {
        let mut temp_time: time_t = mktime(&mut tm as *mut atm as *mut tm);
        if (*tv).tv_sec > temp_time {
            *offset = (((*tv).tv_sec - temp_time as __darwin_time_t)
                / 60 as __darwin_time_t) as ::core::ffi::c_int;
        } else {
            *offset = -(((temp_time as __darwin_time_t - (*tv).tv_sec)
                / 60 as __darwin_time_t) as ::core::ffi::c_int);
        }
    }
    if *offset == -(1 as ::core::ffi::c_int) {
        *offset = (((*tv).tv_sec - mktime(&mut tm as *mut atm as *mut tm))
            / 60 as time_t) as ::core::ffi::c_int;
    }
    if (*tv).tv_sec == -(1 as ::core::ffi::c_int) as __darwin_time_t {
        return -(1 as ::core::ffi::c_int);
    }
    if tm_gmt == 0 {
        (*tv).tv_sec -= (*offset * 60 as ::core::ffi::c_int) as __darwin_time_t;
    }
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn update_tm(
    mut tm: *mut atm,
    mut now: *mut atm,
    mut sec: ::core::ffi::c_ulong,
) -> ::core::ffi::c_ulong {
    let mut n: time_t = 0;
    if (*tm).tm_mday < 0 as ::core::ffi::c_int {
        (*tm).tm_mday = (*now).tm_mday;
    }
    if (*tm).tm_mon < 0 as ::core::ffi::c_int {
        (*tm).tm_mon = (*now).tm_mon;
    }
    if (*tm).tm_year < 0 as ::core::ffi::c_int {
        (*tm).tm_year = (*now).tm_year;
        if (*tm).tm_mon > (*now).tm_mon {
            (*tm).tm_year -= 1;
        }
    }
    n = (mktime(tm as *mut tm) as ::core::ffi::c_ulong).wrapping_sub(sec) as time_t;
    localtime_r(&mut n, tm as *mut tm);
    return n as ::core::ffi::c_ulong;
}
unsafe extern "C" fn date_now(
    mut tm: *mut atm,
    mut now: *mut atm,
    mut num: *mut ::core::ffi::c_int,
) {
    update_tm(tm, now, 0 as ::core::ffi::c_ulong);
}
unsafe extern "C" fn date_yesterday(
    mut tm: *mut atm,
    mut now: *mut atm,
    mut num: *mut ::core::ffi::c_int,
) {
    update_tm(
        tm,
        now,
        (24 as ::core::ffi::c_int * 60 as ::core::ffi::c_int * 60 as ::core::ffi::c_int)
            as ::core::ffi::c_ulong,
    );
}
unsafe extern "C" fn date_time(
    mut tm: *mut atm,
    mut now: *mut atm,
    mut hour: ::core::ffi::c_int,
) {
    if (*tm).tm_hour < hour {
        date_yesterday(tm, now, 0 as *mut ::core::ffi::c_int);
    }
    (*tm).tm_hour = hour;
    (*tm).tm_min = 0 as ::core::ffi::c_int;
    (*tm).tm_sec = 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn date_midnight(
    mut tm: *mut atm,
    mut now: *mut atm,
    mut num: *mut ::core::ffi::c_int,
) {
    date_time(tm, now, 0 as ::core::ffi::c_int);
}
unsafe extern "C" fn date_noon(
    mut tm: *mut atm,
    mut now: *mut atm,
    mut num: *mut ::core::ffi::c_int,
) {
    date_time(tm, now, 12 as ::core::ffi::c_int);
}
unsafe extern "C" fn date_tea(
    mut tm: *mut atm,
    mut now: *mut atm,
    mut num: *mut ::core::ffi::c_int,
) {
    date_time(tm, now, 17 as ::core::ffi::c_int);
}
unsafe extern "C" fn date_pm(
    mut tm: *mut atm,
    mut now: *mut atm,
    mut num: *mut ::core::ffi::c_int,
) {
    let mut hour: ::core::ffi::c_int = 0;
    let mut n: ::core::ffi::c_int = *num;
    *num = 0 as ::core::ffi::c_int;
    hour = (*tm).tm_hour;
    if n != 0 {
        hour = n;
        (*tm).tm_min = 0 as ::core::ffi::c_int;
        (*tm).tm_sec = 0 as ::core::ffi::c_int;
    }
    (*tm).tm_hour = hour % 12 as ::core::ffi::c_int + 12 as ::core::ffi::c_int;
}
unsafe extern "C" fn date_am(
    mut tm: *mut atm,
    mut now: *mut atm,
    mut num: *mut ::core::ffi::c_int,
) {
    let mut hour: ::core::ffi::c_int = 0;
    let mut n: ::core::ffi::c_int = *num;
    *num = 0 as ::core::ffi::c_int;
    hour = (*tm).tm_hour;
    if n != 0 {
        hour = n;
        (*tm).tm_min = 0 as ::core::ffi::c_int;
        (*tm).tm_sec = 0 as ::core::ffi::c_int;
    }
    (*tm).tm_hour = hour % 12 as ::core::ffi::c_int;
}
unsafe extern "C" fn date_never(
    mut tm: *mut atm,
    mut now: *mut atm,
    mut num: *mut ::core::ffi::c_int,
) {
    let mut n: time_t = 0 as time_t;
    localtime_r(&mut n, tm as *mut tm);
}
static mut special: [special; 9] = unsafe {
    [
        {
            let mut init = special {
                name: b"yesterday\0" as *const u8 as *const ::core::ffi::c_char,
                fn_0: Some(
                    date_yesterday
                        as unsafe extern "C" fn(
                            *mut atm,
                            *mut atm,
                            *mut ::core::ffi::c_int,
                        ) -> (),
                ),
            };
            init
        },
        {
            let mut init = special {
                name: b"noon\0" as *const u8 as *const ::core::ffi::c_char,
                fn_0: Some(
                    date_noon
                        as unsafe extern "C" fn(
                            *mut atm,
                            *mut atm,
                            *mut ::core::ffi::c_int,
                        ) -> (),
                ),
            };
            init
        },
        {
            let mut init = special {
                name: b"midnight\0" as *const u8 as *const ::core::ffi::c_char,
                fn_0: Some(
                    date_midnight
                        as unsafe extern "C" fn(
                            *mut atm,
                            *mut atm,
                            *mut ::core::ffi::c_int,
                        ) -> (),
                ),
            };
            init
        },
        {
            let mut init = special {
                name: b"tea\0" as *const u8 as *const ::core::ffi::c_char,
                fn_0: Some(
                    date_tea
                        as unsafe extern "C" fn(
                            *mut atm,
                            *mut atm,
                            *mut ::core::ffi::c_int,
                        ) -> (),
                ),
            };
            init
        },
        {
            let mut init = special {
                name: b"PM\0" as *const u8 as *const ::core::ffi::c_char,
                fn_0: Some(
                    date_pm
                        as unsafe extern "C" fn(
                            *mut atm,
                            *mut atm,
                            *mut ::core::ffi::c_int,
                        ) -> (),
                ),
            };
            init
        },
        {
            let mut init = special {
                name: b"AM\0" as *const u8 as *const ::core::ffi::c_char,
                fn_0: Some(
                    date_am
                        as unsafe extern "C" fn(
                            *mut atm,
                            *mut atm,
                            *mut ::core::ffi::c_int,
                        ) -> (),
                ),
            };
            init
        },
        {
            let mut init = special {
                name: b"never\0" as *const u8 as *const ::core::ffi::c_char,
                fn_0: Some(
                    date_never
                        as unsafe extern "C" fn(
                            *mut atm,
                            *mut atm,
                            *mut ::core::ffi::c_int,
                        ) -> (),
                ),
            };
            init
        },
        {
            let mut init = special {
                name: b"now\0" as *const u8 as *const ::core::ffi::c_char,
                fn_0: Some(
                    date_now
                        as unsafe extern "C" fn(
                            *mut atm,
                            *mut atm,
                            *mut ::core::ffi::c_int,
                        ) -> (),
                ),
            };
            init
        },
        {
            let mut init = special {
                name: 0 as *const ::core::ffi::c_char,
                fn_0: None,
            };
            init
        },
    ]
};
static mut number_name: [*const ::core::ffi::c_char; 11] = [
    b"zero\0" as *const u8 as *const ::core::ffi::c_char,
    b"one\0" as *const u8 as *const ::core::ffi::c_char,
    b"two\0" as *const u8 as *const ::core::ffi::c_char,
    b"three\0" as *const u8 as *const ::core::ffi::c_char,
    b"four\0" as *const u8 as *const ::core::ffi::c_char,
    b"five\0" as *const u8 as *const ::core::ffi::c_char,
    b"six\0" as *const u8 as *const ::core::ffi::c_char,
    b"seven\0" as *const u8 as *const ::core::ffi::c_char,
    b"eight\0" as *const u8 as *const ::core::ffi::c_char,
    b"nine\0" as *const u8 as *const ::core::ffi::c_char,
    b"ten\0" as *const u8 as *const ::core::ffi::c_char,
];
static mut typelen: [typelen; 6] = [
    {
        let mut init = typelen {
            type_0: b"seconds\0" as *const u8 as *const ::core::ffi::c_char,
            length: 1 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = typelen {
            type_0: b"minutes\0" as *const u8 as *const ::core::ffi::c_char,
            length: 60 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = typelen {
            type_0: b"hours\0" as *const u8 as *const ::core::ffi::c_char,
            length: 60 as ::core::ffi::c_int * 60 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = typelen {
            type_0: b"days\0" as *const u8 as *const ::core::ffi::c_char,
            length: 24 as ::core::ffi::c_int * 60 as ::core::ffi::c_int
                * 60 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = typelen {
            type_0: b"weeks\0" as *const u8 as *const ::core::ffi::c_char,
            length: 7 as ::core::ffi::c_int * 24 as ::core::ffi::c_int
                * 60 as ::core::ffi::c_int * 60 as ::core::ffi::c_int,
        };
        init
    },
    {
        let mut init = typelen {
            type_0: 0 as *const ::core::ffi::c_char,
            length: 0,
        };
        init
    },
];
unsafe extern "C" fn approxidate_alpha(
    mut date: *const ::core::ffi::c_char,
    mut tm: *mut atm,
    mut now: *mut atm,
    mut num: *mut ::core::ffi::c_int,
    mut touched: *mut ::core::ffi::c_int,
) -> *const ::core::ffi::c_char {
    let mut tl: *const typelen = 0 as *const typelen;
    let mut s: *const special = 0 as *const special;
    let mut end: *const ::core::ffi::c_char = date;
    let mut i: ::core::ffi::c_int = 0;
    loop {
        end = end.offset(1);
        if !(sane_ctype[*end as ::core::ffi::c_uchar as usize] as ::core::ffi::c_int
            & 0x4 as ::core::ffi::c_int != 0 as ::core::ffi::c_int)
        {
            break;
        }
    }
    i = 0 as ::core::ffi::c_int;
    while i < 12 as ::core::ffi::c_int {
        let mut match_0: ::core::ffi::c_int = match_string(
            date,
            month_names[i as usize],
        );
        if match_0 >= 3 as ::core::ffi::c_int {
            (*tm).tm_mon = i;
            *touched = 1 as ::core::ffi::c_int;
            return end;
        }
        i += 1;
    }
    s = special.as_ptr() as *const special;
    while !(*s).name.is_null() {
        let mut len: ::core::ffi::c_int = strlen((*s).name) as ::core::ffi::c_int;
        if match_string(date, (*s).name) == len {
            (*s).fn_0.expect("non-null function pointer")(tm, now, num);
            *touched = 1 as ::core::ffi::c_int;
            return end;
        }
        s = s.offset(1);
    }
    if *num == 0 {
        i = 1 as ::core::ffi::c_int;
        while i < 11 as ::core::ffi::c_int {
            let mut len_0: ::core::ffi::c_int = strlen(number_name[i as usize])
                as ::core::ffi::c_int;
            if match_string(date, number_name[i as usize]) == len_0 {
                *num = i;
                *touched = 1 as ::core::ffi::c_int;
                return end;
            }
            i += 1;
        }
        if match_string(date, b"last\0" as *const u8 as *const ::core::ffi::c_char)
            == 4 as ::core::ffi::c_int
        {
            *num = 1 as ::core::ffi::c_int;
            *touched = 1 as ::core::ffi::c_int;
        }
        return end;
    }
    tl = typelen.as_ptr() as *const typelen;
    while !(*tl).type_0.is_null() {
        let mut len_1: ::core::ffi::c_int = strlen((*tl).type_0) as ::core::ffi::c_int;
        if match_string(date, (*tl).type_0) >= len_1 - 1 as ::core::ffi::c_int {
            update_tm(tm, now, ((*tl).length * *num) as ::core::ffi::c_ulong);
            *num = 0 as ::core::ffi::c_int;
            *touched = 1 as ::core::ffi::c_int;
            return end;
        }
        tl = tl.offset(1);
    }
    i = 0 as ::core::ffi::c_int;
    while i < 7 as ::core::ffi::c_int {
        let mut match_1: ::core::ffi::c_int = match_string(
            date,
            weekday_names[i as usize],
        );
        if match_1 >= 3 as ::core::ffi::c_int {
            let mut diff: ::core::ffi::c_int = 0;
            let mut n: ::core::ffi::c_int = *num - 1 as ::core::ffi::c_int;
            *num = 0 as ::core::ffi::c_int;
            diff = (*tm).tm_wday - i;
            if diff <= 0 as ::core::ffi::c_int {
                n += 1;
            }
            diff += 7 as ::core::ffi::c_int * n;
            update_tm(
                tm,
                now,
                (diff * 24 as ::core::ffi::c_int * 60 as ::core::ffi::c_int
                    * 60 as ::core::ffi::c_int) as ::core::ffi::c_ulong,
            );
            *touched = 1 as ::core::ffi::c_int;
            return end;
        }
        i += 1;
    }
    if match_string(date, b"months\0" as *const u8 as *const ::core::ffi::c_char)
        >= 5 as ::core::ffi::c_int
    {
        let mut n_0: ::core::ffi::c_int = 0;
        update_tm(tm, now, 0 as ::core::ffi::c_ulong);
        n_0 = (*tm).tm_mon - *num;
        *num = 0 as ::core::ffi::c_int;
        while n_0 < 0 as ::core::ffi::c_int {
            n_0 += 12 as ::core::ffi::c_int;
            (*tm).tm_year -= 1;
        }
        (*tm).tm_mon = n_0;
        *touched = 1 as ::core::ffi::c_int;
        return end;
    }
    if match_string(date, b"years\0" as *const u8 as *const ::core::ffi::c_char)
        >= 4 as ::core::ffi::c_int
    {
        update_tm(tm, now, 0 as ::core::ffi::c_ulong);
        (*tm).tm_year -= *num;
        *num = 0 as ::core::ffi::c_int;
        *touched = 1 as ::core::ffi::c_int;
        return end;
    }
    return end;
}
unsafe extern "C" fn approxidate_digit(
    mut date: *const ::core::ffi::c_char,
    mut tm: *mut atm,
    mut num: *mut ::core::ffi::c_int,
    mut now: time_t,
) -> *const ::core::ffi::c_char {
    let mut end: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut number: ::core::ffi::c_ulong = strtoul(
        date,
        &mut end,
        10 as ::core::ffi::c_int,
    );
    match *end as ::core::ffi::c_int {
        58 | 46 | 47 | 45 => {
            if sane_ctype[*end.offset(1 as ::core::ffi::c_int as isize)
                as ::core::ffi::c_uchar as usize] as ::core::ffi::c_int
                & 0x2 as ::core::ffi::c_int != 0 as ::core::ffi::c_int
            {
                let mut match_0: ::core::ffi::c_int = match_multi_number(
                    number,
                    *end,
                    date,
                    end,
                    tm,
                    now,
                );
                if match_0 != 0 {
                    return date.offset(match_0 as isize);
                }
            }
        }
        _ => {}
    }
    if *date.offset(0 as ::core::ffi::c_int as isize) as ::core::ffi::c_int != '0' as i32
        || end.offset_from(date) as ::core::ffi::c_long <= 2 as ::core::ffi::c_long
    {
        *num = number as ::core::ffi::c_int;
    }
    return end;
}
unsafe extern "C" fn pending_number(mut tm: *mut atm, mut num: *mut ::core::ffi::c_int) {
    let mut number: ::core::ffi::c_int = *num;
    if number != 0 {
        *num = 0 as ::core::ffi::c_int;
        if (*tm).tm_mday < 0 as ::core::ffi::c_int && number < 32 as ::core::ffi::c_int {
            (*tm).tm_mday = number;
        } else if (*tm).tm_mon < 0 as ::core::ffi::c_int
            && number < 13 as ::core::ffi::c_int
        {
            (*tm).tm_mon = number - 1 as ::core::ffi::c_int;
        } else if (*tm).tm_year < 0 as ::core::ffi::c_int {
            if number > 1969 as ::core::ffi::c_int && number < 2100 as ::core::ffi::c_int
            {
                (*tm).tm_year = number - 1900 as ::core::ffi::c_int;
            } else if number > 69 as ::core::ffi::c_int
                && number < 100 as ::core::ffi::c_int
            {
                (*tm).tm_year = number;
            } else if number < 38 as ::core::ffi::c_int {
                (*tm).tm_year = 100 as ::core::ffi::c_int + number;
            }
        }
    }
}
unsafe extern "C" fn approxidate_str(
    mut date: *const ::core::ffi::c_char,
    mut tv: *mut timeval,
) -> ::core::ffi::c_int {
    let mut number: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut touched: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut tm: atm = atm {
        tm_sec: 0,
        tm_min: 0,
        tm_hour: 0,
        tm_mday: 0,
        tm_mon: 0,
        tm_year: 0,
        tm_wday: 0,
        tm_yday: 0,
        tm_isdst: 0,
        tm_usec: 0,
    };
    let mut now: atm = atm {
        tm_sec: 0,
        tm_min: 0,
        tm_hour: 0,
        tm_mday: 0,
        tm_mon: 0,
        tm_year: 0,
        tm_wday: 0,
        tm_yday: 0,
        tm_isdst: 0,
        tm_usec: 0,
    };
    let mut time_sec: time_t = 0;
    time_sec = (*tv).tv_sec as time_t;
    localtime_r(&mut time_sec, &mut tm as *mut atm as *mut tm);
    now = tm;
    tm.tm_year = -(1 as ::core::ffi::c_int);
    tm.tm_mon = -(1 as ::core::ffi::c_int);
    tm.tm_mday = -(1 as ::core::ffi::c_int);
    tm.tm_usec = (*tv).tv_usec as ::core::ffi::c_long;
    loop {
        let mut c: ::core::ffi::c_uchar = *date as ::core::ffi::c_uchar;
        if c == 0 {
            break;
        }
        date = date.offset(1);
        if sane_ctype[c as usize] as ::core::ffi::c_int & 0x2 as ::core::ffi::c_int
            != 0 as ::core::ffi::c_int
        {
            pending_number(&mut tm, &mut number);
            date = approxidate_digit(
                date.offset(-(1 as ::core::ffi::c_int as isize)),
                &mut tm,
                &mut number,
                time_sec,
            );
            touched = 1 as ::core::ffi::c_int;
        } else if sane_ctype[c as usize] as ::core::ffi::c_int
            & 0x4 as ::core::ffi::c_int != 0 as ::core::ffi::c_int
        {
            date = approxidate_alpha(
                date.offset(-(1 as ::core::ffi::c_int as isize)),
                &mut tm,
                &mut now,
                &mut number,
                &mut touched,
            );
        }
    }
    pending_number(&mut tm, &mut number);
    if touched == 0 {
        return -(1 as ::core::ffi::c_int);
    }
    (*tv).tv_usec = tm.tm_usec as __darwin_suseconds_t;
    (*tv).tv_sec = update_tm(&mut tm, &mut now, 0 as ::core::ffi::c_ulong)
        as __darwin_time_t;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn approxidate(
    mut date: *const ::core::ffi::c_char,
    mut tv: *mut timeval,
) -> ::core::ffi::c_int {
    return approxidate_relative(date, tv, 0 as *const timeval);
}
#[no_mangle]
pub unsafe extern "C" fn approxidate_relative(
    mut date: *const ::core::ffi::c_char,
    mut tv: *mut timeval,
    mut relative_to: *const timeval,
) -> ::core::ffi::c_int {
    let mut offset: ::core::ffi::c_int = 0;
    if parse_date_basic(date, tv, &mut offset) == 0 {
        return 0 as ::core::ffi::c_int;
    }
    if relative_to.is_null() {
        gettimeofday(tv, NULL);
    } else {
        *tv = *relative_to;
    }
    if approxidate_str(date, tv) == 0 {
        return 0 as ::core::ffi::c_int;
    }
    return -(1 as ::core::ffi::c_int);
}
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
