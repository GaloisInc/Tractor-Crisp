#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn gettimeofday(_: *mut timeval, _: *mut ::core::ffi::c_void) -> ::core::ffi::c_int;
    fn approxidate(
        date: *const ::core::ffi::c_char,
        tv: *mut timeval,
    ) -> ::core::ffi::c_int;
    fn approxidate_relative(
        date: *const ::core::ffi::c_char,
        tv: *mut timeval,
        relative_to: *const timeval,
    ) -> ::core::ffi::c_int;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn gmtime(_: *const time_t) -> *mut tm;
    fn strftime(
        _: *mut ::core::ffi::c_char,
        _: size_t,
        _: *const ::core::ffi::c_char,
        _: *const tm,
    ) -> size_t;
    fn strptime(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: *mut tm,
    ) -> *mut ::core::ffi::c_char;
    fn time(_: *mut time_t) -> time_t;
    fn clock_gettime(__clock_id: clockid_t, __tp: *mut timespec) -> ::core::ffi::c_int;
}
pub type __int32_t = i32;
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_time_t = ::core::ffi::c_long;
pub type __darwin_off_t = __int64_t;
pub type __darwin_suseconds_t = __int32_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct timespec {
    pub tv_sec: __darwin_time_t,
    pub tv_nsec: ::core::ffi::c_long,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct timeval {
    pub tv_sec: __darwin_time_t,
    pub tv_usec: __darwin_suseconds_t,
}
pub type time_t = __darwin_time_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tm {
    pub tm_sec: ::core::ffi::c_int,
    pub tm_min: ::core::ffi::c_int,
    pub tm_hour: ::core::ffi::c_int,
    pub tm_mday: ::core::ffi::c_int,
    pub tm_mon: ::core::ffi::c_int,
    pub tm_year: ::core::ffi::c_int,
    pub tm_wday: ::core::ffi::c_int,
    pub tm_yday: ::core::ffi::c_int,
    pub tm_isdst: ::core::ffi::c_int,
    pub tm_gmtoff: ::core::ffi::c_long,
    pub tm_zone: *mut ::core::ffi::c_char,
}
pub type clockid_t = ::core::ffi::c_uint;
pub const _CLOCK_THREAD_CPUTIME_ID: clockid_t = 16;
pub const _CLOCK_PROCESS_CPUTIME_ID: clockid_t = 12;
pub const _CLOCK_MONOTONIC: clockid_t = 6;
pub const _CLOCK_REALTIME: clockid_t = 0;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const EXIT_FAILURE: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const EXIT_SUCCESS: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
unsafe extern "C" fn _start_of_day(mut sec: time_t) -> time_t {
    return sec - sec % 86400 as time_t;
}
unsafe extern "C" fn monotonic_now() -> ::core::ffi::c_double {
    let mut ts: timespec = timespec { tv_sec: 0, tv_nsec: 0 };
    clock_gettime(_CLOCK_MONOTONIC, &mut ts);
    return ts.tv_sec as ::core::ffi::c_double
        + ts.tv_nsec as ::core::ffi::c_double / 1000000000.0f64;
}
unsafe extern "C" fn approxidate_test() -> bool {
    let mut usec: ::core::ffi::c_long = 0;
    let mut ts: time_t = 0;
    let mut tm: *mut tm = 0 as *mut tm;
    let mut buff: [::core::ffi::c_char; 128] = [0; 128];
    let mut tv: timeval = timeval { tv_sec: 0, tv_usec: 0 };
    let mut tv_rel: timeval = timeval { tv_sec: 0, tv_usec: 0 };
    let mut errors: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    approxidate(
        b"10/Mar/2013:00:00:02.003 UTC\0" as *const u8 as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_sec != 1362873602 as __darwin_time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            46 as ::core::ffi::c_int,
            tv.tv_sec,
            1362873602 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    if tv.tv_usec != 3000 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            47 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            3000 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(
        b"10/Mar/2013:00:00:02 UTC\0" as *const u8 as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_sec != 1362873602 as __darwin_time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            50 as ::core::ffi::c_int,
            tv.tv_sec,
            1362873602 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    if tv.tv_usec != 0 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            51 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            0 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(
        b"10/Mar/2013:00:00:07 UTC\0" as *const u8 as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_sec != 1362873607 as __darwin_time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            54 as ::core::ffi::c_int,
            tv.tv_sec,
            1362873607 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    if tv.tv_usec != 0 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            55 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            0 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(
        b"10/Mar/2012:00:00:07 UTC\0" as *const u8 as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_sec != 1331337607 as __darwin_time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            58 as ::core::ffi::c_int,
            tv.tv_sec,
            1331337607 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    if tv.tv_usec != 0 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            59 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            0 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(
        b"10/Mar/2012:00:00:07 +0500\0" as *const u8 as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_sec != 1331319607 as __darwin_time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            62 as ::core::ffi::c_int,
            tv.tv_sec,
            1331319607 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    if tv.tv_usec != 0 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            63 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            0 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(
        b"10/Mar/2012:00:00:07.657891 +0500\0" as *const u8
            as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_sec != 1331319607 as __darwin_time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            66 as ::core::ffi::c_int,
            tv.tv_sec,
            1331319607 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    if tv.tv_usec != 657891 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            67 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            657891 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(
        b"10/Mar/2012:00:00:07.657891 +1400\0" as *const u8
            as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_sec != 1331287207 as __darwin_time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            70 as ::core::ffi::c_int,
            tv.tv_sec,
            1331287207 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    if tv.tv_usec != 657891 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            71 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            657891 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(
        b"10/Mar/2012:00:00:07.657891 -0110\0" as *const u8
            as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_sec != 1331341807 as __darwin_time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            74 as ::core::ffi::c_int,
            tv.tv_sec,
            1331341807 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    if tv.tv_usec != 657891 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            75 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            657891 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(
        b"mar 10 2013 00:00:07 UTC\0" as *const u8 as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_sec != 1362873607 as __darwin_time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            78 as ::core::ffi::c_int,
            tv.tv_sec,
            1362873607 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    if tv.tv_usec != 0 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            79 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            0 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(
        b"mar 10 2013 04:00:07 -0500\0" as *const u8 as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_sec != 1362906007 as __darwin_time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            82 as ::core::ffi::c_int,
            tv.tv_sec,
            1362906007 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    if tv.tv_usec != 0 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            83 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            0 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(
        b"march 10 2013 04:00:07 -0500\0" as *const u8 as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_sec != 1362906007 as __darwin_time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            86 as ::core::ffi::c_int,
            tv.tv_sec,
            1362906007 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    if tv.tv_usec != 0 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            87 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            0 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(
        b"march 10 2013 04:00:07 -0500\0" as *const u8 as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_sec != 1362906007 as __darwin_time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            90 as ::core::ffi::c_int,
            tv.tv_sec,
            1362906007 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    if tv.tv_usec != 0 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            91 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            0 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(
        b"10 march 2013 04:00:07 -0500\0" as *const u8 as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_sec != 1362906007 as __darwin_time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            94 as ::core::ffi::c_int,
            tv.tv_sec,
            1362906007 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    if tv.tv_usec != 0 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            95 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            0 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(
        b"2013 10 march 04:00:07 -0500\0" as *const u8 as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_sec != 1362906007 as __darwin_time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            98 as ::core::ffi::c_int,
            tv.tv_sec,
            1362906007 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    if tv.tv_usec != 0 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            99 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            0 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(
        b"2013 march 10 04:00:07 -0500\0" as *const u8 as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_sec != 1362906007 as __darwin_time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            102 as ::core::ffi::c_int,
            tv.tv_sec,
            1362906007 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    if tv.tv_usec != 0 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            103 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            0 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(
        b"00:00:07.657891\0" as *const u8 as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_usec != 657891 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            106 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            657891 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(
        b"23:11:07.9876 +1400\0" as *const u8 as *const ::core::ffi::c_char,
        &mut tv,
    );
    if tv.tv_usec != 987600 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            109 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            987600 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(b"23:11:07.9876\0" as *const u8 as *const ::core::ffi::c_char, &mut tv);
    if tv.tv_usec != 987600 as __darwin_suseconds_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            112 as ::core::ffi::c_int,
            tv.tv_usec as ::core::ffi::c_long,
            987600 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(b"1/1/2014\0" as *const u8 as *const ::core::ffi::c_char, &mut tv);
    if _start_of_day(tv.tv_sec as time_t) != 1388534400 as time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            115 as ::core::ffi::c_int,
            _start_of_day(tv.tv_sec as time_t),
            1388534400 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    approxidate(b"1/1/2014 UTC\0" as *const u8 as *const ::core::ffi::c_char, &mut tv);
    if _start_of_day(tv.tv_sec as time_t) != 1388534400 as time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            118 as ::core::ffi::c_int,
            _start_of_day(tv.tv_sec as time_t),
            1388534400 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    tv_rel.tv_sec = 1577910617 as __darwin_time_t;
    tv_rel.tv_usec = 0 as ::core::ffi::c_int as __darwin_suseconds_t;
    approxidate_relative(
        b"1/1/2014\0" as *const u8 as *const ::core::ffi::c_char,
        &mut tv,
        &mut tv_rel,
    );
    if tv.tv_sec != 1388608217 as __darwin_time_t {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            124 as ::core::ffi::c_int,
            tv.tv_sec,
            1388608217 as ::core::ffi::c_int as ::core::ffi::c_long,
        );
        errors += 1;
    }
    ts = time(0 as *mut time_t);
    ts
        += (86400 as ::core::ffi::c_int * 31 as ::core::ffi::c_int
            * 5 as ::core::ffi::c_int) as time_t;
    tm = gmtime(&mut ts);
    strftime(
        buff.as_mut_ptr(),
        ::core::mem::size_of::<[::core::ffi::c_char; 128]>() as size_t,
        b"%m/%d/%Y\0" as *const u8 as *const ::core::ffi::c_char,
        tm,
    );
    approxidate(buff.as_mut_ptr(), &mut tv);
    if _start_of_day(tv.tv_sec as time_t) != _start_of_day(ts) {
        fprintf(
            __stderrp,
            b"Test failure at line %d: %ld != %ld\n\0" as *const u8
                as *const ::core::ffi::c_char,
            137 as ::core::ffi::c_int,
            _start_of_day(tv.tv_sec as time_t),
            _start_of_day(ts),
        );
        errors += 1;
    }
    gettimeofday(&mut tv, NULL);
    usec = tv.tv_usec as ::core::ffi::c_long;
    approxidate(b"10/Mar/2012\0" as *const u8 as *const ::core::ffi::c_char, &mut tv);
    if !((usec - 10000 as ::core::ffi::c_long) < tv.tv_usec as ::core::ffi::c_long
        && usec + 10000 as ::core::ffi::c_long > tv.tv_usec as ::core::ffi::c_long)
    {
        fprintf(
            __stderrp,
            b"Error: usec calculation for anonymous time is off\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        errors += 1;
    }
    if errors > 0 as ::core::ffi::c_int {
        fprintf(
            __stderrp,
            b"%d tests failed\n\0" as *const u8 as *const ::core::ffi::c_char,
            errors,
        );
        return false_0 != 0;
    } else {
        fprintf(
            __stderrp,
            b"All tests passed\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    return true_0 != 0;
}
unsafe extern "C" fn approxidate_benchmark() {
    let ROUNDS: ::core::ffi::c_int = 1000000 as ::core::ffi::c_int;
    let mut start: ::core::ffi::c_double = monotonic_now();
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < ROUNDS {
        let mut t: timeval = timeval { tv_sec: 0, tv_usec: 0 };
        if !(approxidate(
            b"10/Mar/2013:00:00:02.003 -0500\0" as *const u8
                as *const ::core::ffi::c_char,
            &mut t,
        ) >= 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 22],
                    [::core::ffi::c_char; 22],
                >(*b"approxidate_benchmark\0")
                    .as_ptr(),
                b"approxidate-test.c\0" as *const u8 as *const ::core::ffi::c_char,
                165 as ::core::ffi::c_int,
                b"approxidate(\"10/Mar/2013:00:00:02.003 -0500\", &t) >= 0\0"
                    as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        i += 1;
    }
    printf(
        b"approxidate time: %lf\n\0" as *const u8 as *const ::core::ffi::c_char,
        monotonic_now() - start,
    );
    start = monotonic_now();
    let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_0 < ROUNDS {
        let mut m: tm = tm {
            tm_sec: 0,
            tm_min: 0,
            tm_hour: 0,
            tm_mday: 0,
            tm_mon: 0,
            tm_year: 0,
            tm_wday: 0,
            tm_yday: 0,
            tm_isdst: 0,
            tm_gmtoff: 0,
            tm_zone: 0 as *mut ::core::ffi::c_char,
        };
        if strptime(
                b"10/Mar/2013:00:00:02\0" as *const u8 as *const ::core::ffi::c_char,
                b"%d/%b/%Y:%T\0" as *const u8 as *const ::core::ffi::c_char,
                &mut m,
            )
            .is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 22],
                    [::core::ffi::c_char; 22],
                >(*b"approxidate_benchmark\0")
                    .as_ptr(),
                b"approxidate-test.c\0" as *const u8 as *const ::core::ffi::c_char,
                173 as ::core::ffi::c_int,
                b"strptime(\"10/Mar/2013:00:00:02\", \"%d/%b/%Y:%T\", &m) != NULL\0"
                    as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        i_0 += 1;
    }
    printf(
        b"strptime time: %lf\n\0" as *const u8 as *const ::core::ffi::c_char,
        monotonic_now() - start,
    );
}
unsafe fn main_0() -> ::core::ffi::c_int {
    if !approxidate_test() {
        return EXIT_FAILURE;
    }
    approxidate_benchmark();
    return EXIT_SUCCESS;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
