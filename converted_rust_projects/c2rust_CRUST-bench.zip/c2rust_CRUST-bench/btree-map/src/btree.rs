#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn memcmp(
        __s1: *const ::core::ffi::c_void,
        __s2: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> ::core::ffi::c_int;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type uint8_t = u8;
pub type uint32_t = u32;
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct value {
    pub value: *mut uint8_t,
    pub len: size_t,
}
pub type value_t = value;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct btree_key {
    pub key: *mut uint8_t,
    pub len: size_t,
}
pub type btree_key_t = btree_key;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct entry {
    pub key: btree_key_t,
    pub value: value_t,
}
pub type entry_t = entry;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct entry_list {
    pub entries: *mut entry_t,
    pub len: size_t,
    pub cap: size_t,
}
pub type entry_list_t = entry_list;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct node {
    pub key_hash: uint32_t,
    pub p_key: [uint8_t; 10],
    pub key_len: size_t,
    pub value: value_t,
    pub child_left: *mut node_t,
    pub child_right: *mut node_t,
}
pub type node_t = node;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct btree {
    pub node: *mut node_t,
}
pub type btree_t = btree;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const UINT32_MAX: ::core::ffi::c_uint = 4294967295 as ::core::ffi::c_uint;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const BTREE_KEY_SIZE: ::core::ffi::c_int = 10 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn btree_malloc(mut size: size_t) -> *mut ::core::ffi::c_void {
    let mut ptr: *mut ::core::ffi::c_void = malloc(size);
    memset(ptr, 0 as ::core::ffi::c_int, size);
    return ptr;
}
#[no_mangle]
pub unsafe extern "C" fn btree_free(mut ptr: *mut ::core::ffi::c_void) {
    free(ptr);
    ptr = NULL;
}
#[no_mangle]
pub unsafe extern "C" fn min_size(mut a: size_t, mut b: size_t) -> size_t {
    if a < b {
        return a;
    }
    return b;
}
#[no_mangle]
pub unsafe extern "C" fn calc_key_hash(
    mut key: *mut ::core::ffi::c_void,
    mut key_len: size_t,
) -> uint32_t {
    let mut key_sum: uint32_t = 0 as uint32_t;
    let mut byte_key: *mut uint8_t = key as *mut uint8_t;
    let mut i: size_t = 0 as size_t;
    while i < key_len {
        key_sum = key_sum.wrapping_rem(UINT32_MAX as uint32_t);
        key_sum = (key_sum as size_t)
            .wrapping_add(
                (*byte_key.offset(i as isize) as size_t)
                    .wrapping_mul(i.wrapping_add(1 as size_t))
                    .wrapping_rem(UINT32_MAX as size_t),
            ) as uint32_t as uint32_t;
        i = i.wrapping_add(1);
    }
    return key_sum;
}
#[no_mangle]
pub unsafe extern "C" fn new_btree() -> *mut btree_t {
    let mut bt: *mut btree_t = btree_malloc(::core::mem::size_of::<btree_t>() as size_t)
        as *mut btree_t;
    (*bt).node = 0 as *mut node_t;
    return bt;
}
#[no_mangle]
pub unsafe extern "C" fn new_node(
    mut key: *mut ::core::ffi::c_void,
    mut key_len: size_t,
    mut value: *mut ::core::ffi::c_void,
    mut value_len: size_t,
) -> *mut node_t {
    let mut node: *mut node_t = btree_malloc(::core::mem::size_of::<node_t>() as size_t)
        as *mut node_t;
    (*node).key_len = min_size(BTREE_KEY_SIZE as size_t, key_len);
    memcpy((*node).p_key.as_mut_ptr() as *mut ::core::ffi::c_void, key, (*node).key_len);
    (*node).value.value = btree_malloc(value_len) as *mut uint8_t;
    (*node).value.len = value_len;
    memcpy((*node).value.value as *mut ::core::ffi::c_void, value, (*node).value.len);
    (*node).key_hash = calc_key_hash(
        (*node).p_key.as_mut_ptr() as *mut ::core::ffi::c_void,
        (*node).key_len,
    );
    return node;
}
#[no_mangle]
pub unsafe extern "C" fn free_node(mut self_0: *mut node_t) {
    if self_0.is_null() {
        return;
    }
    btree_free((*self_0).value.value as *mut ::core::ffi::c_void);
    free_node((*self_0).child_left);
    free_node((*self_0).child_right);
    btree_free(self_0 as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn add_node(mut self_0: *mut node_t, mut n_node: *mut node_t) {
    if (*n_node).key_hash > (*self_0).key_hash {
        if (*self_0).child_right.is_null() {
            (*self_0).child_right = n_node;
            return;
        }
        add_node((*self_0).child_right, n_node);
        return;
    }
    if (*n_node).key_hash == (*self_0).key_hash {
        if memcmp(
            (*self_0).p_key.as_mut_ptr() as *const ::core::ffi::c_void,
            (*n_node).p_key.as_mut_ptr() as *const ::core::ffi::c_void,
            (*n_node).key_len,
        ) == 0 as ::core::ffi::c_int
        {
            (*self_0).value.len = (*n_node).value.len;
            memcpy(
                (*self_0).value.value as *mut ::core::ffi::c_void,
                (*n_node).value.value as *const ::core::ffi::c_void,
                (*n_node).value.len,
            );
            free_node(n_node);
            return;
        }
    }
    if (*self_0).child_left.is_null() {
        (*self_0).child_left = n_node;
        return;
    }
    add_node((*self_0).child_left, n_node);
}
#[no_mangle]
pub unsafe extern "C" fn find_value(
    mut self_0: *mut node_t,
    mut key_hash: uint32_t,
    mut key: *mut ::core::ffi::c_void,
    mut key_len: size_t,
) -> *mut value_t {
    key_len = min_size(BTREE_KEY_SIZE as size_t, key_len);
    if (*self_0).key_hash == key_hash {
        if memcmp(
            (*self_0).p_key.as_mut_ptr() as *const ::core::ffi::c_void,
            key,
            key_len,
        ) == 0 as ::core::ffi::c_int
        {
            return &mut (*self_0).value;
        }
    }
    if key_hash > (*self_0).key_hash {
        if (*self_0).child_right.is_null() {
            return 0 as *mut value_t;
        }
        return find_value((*self_0).child_right, key_hash, key, key_len);
    }
    if (*self_0).child_left.is_null() {
        return 0 as *mut value_t;
    }
    return find_value((*self_0).child_left, key_hash, key, key_len);
}
#[no_mangle]
pub unsafe extern "C" fn list_node_entries(
    mut self_0: *mut node_t,
    mut list: *mut entry_list_t,
) {
    if self_0.is_null() {
        return;
    }
    list_node_entries((*self_0).child_left, list);
    if (*list).len >= (*list).cap {
        return;
    }
    let mut entry: *mut entry_t = btree_malloc(
        ::core::mem::size_of::<entry_t>() as size_t,
    ) as *mut entry_t;
    (*entry).key.key = btree_malloc((*self_0).key_len) as *mut uint8_t;
    (*entry).key.len = (*self_0).key_len;
    memcpy(
        (*entry).key.key as *mut ::core::ffi::c_void,
        (*self_0).p_key.as_mut_ptr() as *const ::core::ffi::c_void,
        (*self_0).key_len,
    );
    (*entry).value.value = btree_malloc((*self_0).value.len) as *mut uint8_t;
    (*entry).value.len = (*self_0).value.len;
    memcpy(
        (*entry).value.value as *mut ::core::ffi::c_void,
        (*self_0).value.value as *const ::core::ffi::c_void,
        (*self_0).value.len,
    );
    *(*list).entries.offset((*list).len as isize) = *entry;
    (*list).len = (*list).len.wrapping_add(1 as size_t);
    list_node_entries((*self_0).child_right, list);
}
#[no_mangle]
pub unsafe extern "C" fn get_node_count(mut self_0: *mut node_t) -> size_t {
    if self_0.is_null() {
        return 0 as size_t;
    }
    return (1 as size_t)
        .wrapping_add(get_node_count((*self_0).child_left))
        .wrapping_add(get_node_count((*self_0).child_right));
}
#[no_mangle]
pub unsafe extern "C" fn add_entry(
    mut self_0: *mut btree_t,
    mut key: *mut ::core::ffi::c_void,
    mut key_len: size_t,
    mut value: *mut ::core::ffi::c_void,
    mut value_len: size_t,
) {
    let mut n_node: *mut node_t = new_node(key, key_len, value, value_len);
    if (*self_0).node.is_null() {
        (*self_0).node = n_node;
        return;
    }
    add_node((*self_0).node, n_node);
}
#[no_mangle]
pub unsafe extern "C" fn find_entry(
    mut self_0: *mut btree_t,
    mut key: *mut ::core::ffi::c_void,
    mut key_len: size_t,
) -> *mut value_t {
    if (*self_0).node.is_null() {
        return 0 as *mut value_t;
    }
    key_len = min_size(BTREE_KEY_SIZE as size_t, key_len);
    let mut key_hash: uint32_t = calc_key_hash(key, key_len);
    return find_value((*self_0).node, key_hash, key, key_len);
}
#[no_mangle]
pub unsafe extern "C" fn delete_node(
    mut root: *mut node_t,
    mut key_hash: uint32_t,
    mut key: *mut ::core::ffi::c_void,
    mut key_len: size_t,
) -> *mut node_t {
    if root.is_null() {
        return 0 as *mut node_t;
    }
    key_len = min_size(BTREE_KEY_SIZE as size_t, key_len);
    if key_hash < (*root).key_hash {
        (*root).child_left = delete_node((*root).child_left, key_hash, key, key_len);
    } else if key_hash > (*root).key_hash {
        (*root).child_right = delete_node((*root).child_right, key_hash, key, key_len);
    } else if memcmp(
        (*root).p_key.as_mut_ptr() as *const ::core::ffi::c_void,
        key,
        key_len,
    ) == 0 as ::core::ffi::c_int
    {
        if (*root).child_left.is_null() {
            let mut temp: *mut node_t = (*root).child_right;
            btree_free(root as *mut ::core::ffi::c_void);
            return temp;
        } else if (*root).child_right.is_null() {
            let mut temp_0: *mut node_t = (*root).child_left;
            btree_free(root as *mut ::core::ffi::c_void);
            return temp_0;
        }
        let mut temp_1: *mut node_t = (*root).child_right;
        while !temp_1.is_null() && !(*temp_1).child_left.is_null() {
            temp_1 = (*temp_1).child_left;
        }
        (*root).key_hash = (*temp_1).key_hash;
        memcpy(
            (*root).p_key.as_mut_ptr() as *mut ::core::ffi::c_void,
            (*temp_1).p_key.as_mut_ptr() as *const ::core::ffi::c_void,
            (*temp_1).key_len,
        );
        (*root).key_len = (*temp_1).key_len;
        memcpy(
            (*root).value.value as *mut ::core::ffi::c_void,
            (*temp_1).value.value as *const ::core::ffi::c_void,
            (*temp_1).value.len,
        );
        (*root).value.len = (*temp_1).value.len;
        (*root).child_right = delete_node(
            (*root).child_right,
            (*temp_1).key_hash,
            (*temp_1).p_key.as_mut_ptr() as *mut ::core::ffi::c_void,
            (*temp_1).key_len,
        );
    }
    return root;
}
#[no_mangle]
pub unsafe extern "C" fn remove_entry(
    mut self_0: *mut btree_t,
    mut key: *mut ::core::ffi::c_void,
    mut key_len: size_t,
) {
    if self_0.is_null() {
        return;
    }
    key_len = min_size(BTREE_KEY_SIZE as size_t, key_len);
    let mut key_hash: uint32_t = calc_key_hash(key, key_len);
    (*self_0).node = delete_node((*self_0).node, key_hash, key, key_len);
}
#[no_mangle]
pub unsafe extern "C" fn list_entries(mut self_0: *mut btree_t) -> *mut entry_list_t {
    if self_0.is_null() {
        return 0 as *mut entry_list_t;
    }
    let mut list: *mut entry_list_t = btree_malloc(
        ::core::mem::size_of::<entry_list_t>() as size_t,
    ) as *mut entry_list_t;
    (*list).len = 0 as size_t;
    (*list).cap = get_entry_count(self_0);
    (*list).entries = btree_malloc(
        (::core::mem::size_of::<entry_t>() as size_t).wrapping_mul((*list).cap),
    ) as *mut entry_t;
    list_node_entries((*self_0).node, list);
    return list;
}
#[no_mangle]
pub unsafe extern "C" fn get_entry_count(mut self_0: *mut btree_t) -> size_t {
    if self_0.is_null() {
        return 0 as size_t;
    }
    return get_node_count((*self_0).node);
}
#[no_mangle]
pub unsafe extern "C" fn free_tree(mut self_0: *mut *mut btree_t) {
    free_node((**self_0).node);
    btree_free(*self_0 as *mut ::core::ffi::c_void);
    *self_0 = 0 as *mut btree_t;
}
#[no_mangle]
pub unsafe extern "C" fn free_entry_list(mut list: *mut *mut entry_list_t) {
    let mut i: size_t = 0 as size_t;
    while i < (**list).len {
        btree_free(
            (*(**list).entries.offset(i as isize)).key.key as *mut ::core::ffi::c_void,
        );
        btree_free(
            (*(**list).entries.offset(i as isize)).value.value
                as *mut ::core::ffi::c_void,
        );
        i = i.wrapping_add(1);
    }
    btree_free((**list).entries as *mut ::core::ffi::c_void);
    btree_free(*list as *mut ::core::ffi::c_void);
    *list = 0 as *mut entry_list_t;
}
