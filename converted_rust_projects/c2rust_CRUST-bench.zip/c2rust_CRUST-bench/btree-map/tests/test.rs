#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type btree;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn new_btree() -> *mut btree_t;
    fn find_entry(
        self_0: *mut btree_t,
        key: *mut ::core::ffi::c_void,
        key_len: size_t,
    ) -> *mut value_t;
    fn add_entry(
        self_0: *mut btree_t,
        key: *mut ::core::ffi::c_void,
        key_len: size_t,
        value: *mut ::core::ffi::c_void,
        value_len: size_t,
    );
    fn free_tree(self_0: *mut *mut btree_t);
    fn remove_entry(
        self_0: *mut btree_t,
        key: *mut ::core::ffi::c_void,
        key_len: size_t,
    );
    fn list_entries(self_0: *mut btree_t) -> *mut entry_list_t;
    fn free_entry_list(list: *mut *mut entry_list_t);
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn memcmp(
        __s1: *const ::core::ffi::c_void,
        __s2: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> ::core::ffi::c_int;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
pub type uint32_t = u32;
pub type uint64_t = u64;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct value {
    pub value: *mut uint8_t,
    pub len: size_t,
}
pub type value_t = value;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct btree_key {
    pub key: *mut uint8_t,
    pub len: size_t,
}
pub type btree_key_t = btree_key;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct entry {
    pub key: btree_key_t,
    pub value: value_t,
}
pub type entry_t = entry;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct entry_list {
    pub entries: *mut entry_t,
    pub len: size_t,
    pub cap: size_t,
}
pub type entry_list_t = entry_list;
pub type btree_t = btree;
pub type custom_key_t = custom_key;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct custom_key {
    pub key: uint32_t,
    pub key2: uint32_t,
}
pub type custom_value_t = custom_value;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct custom_value {
    pub value: uint32_t,
    pub value2: uint32_t,
}
#[no_mangle]
pub unsafe extern "C" fn test_add_entry() {
    let mut btree: *mut btree_t = new_btree();
    add_entry(
        btree,
        b"entry_1\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
        b"value_1\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    let mut value: *mut value_t = find_entry(
        btree,
        b"entry_1\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    if value.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 15],
                [::core::ffi::c_char; 15],
            >(*b"test_add_entry\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            12 as ::core::ffi::c_int,
            b"value != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*value).value as *const ::core::ffi::c_void,
        b"value_1\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 15],
                [::core::ffi::c_char; 15],
            >(*b"test_add_entry\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            13 as ::core::ffi::c_int,
            b"memcmp(value->value, \"value_1\", sizeof(\"value_1\")) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    free_tree(&mut btree);
}
#[no_mangle]
pub unsafe extern "C" fn test_entry_list() {
    let mut btree: *mut btree_t = new_btree();
    add_entry(
        btree,
        b"entry_1\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
        b"value_1\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    add_entry(
        btree,
        b"entry_2\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
        b"value_2\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    add_entry(
        btree,
        b"entry_3\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
        b"value_3\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    add_entry(
        btree,
        b"entry_4\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
        b"value_4\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    add_entry(
        btree,
        b"entry_5\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
        b"value_5\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    let mut list: *mut entry_list_t = list_entries(btree);
    if !((*list).len == 5 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_entry_list\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            25 as ::core::ffi::c_int,
            b"list->len == 5\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(0 as ::core::ffi::c_int as isize)).key.key
            as *const ::core::ffi::c_void,
        b"entry_1\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_entry_list\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            26 as ::core::ffi::c_int,
            b"memcmp(list->entries[0].key.key, \"entry_1\", sizeof(\"entry_1\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(0 as ::core::ffi::c_int as isize)).value.value
            as *const ::core::ffi::c_void,
        b"value_1\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_entry_list\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            27 as ::core::ffi::c_int,
            b"memcmp(list->entries[0].value.value, \"value_1\", sizeof(\"value_1\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(1 as ::core::ffi::c_int as isize)).key.key
            as *const ::core::ffi::c_void,
        b"entry_2\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_entry_list\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            28 as ::core::ffi::c_int,
            b"memcmp(list->entries[1].key.key, \"entry_2\", sizeof(\"entry_2\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(1 as ::core::ffi::c_int as isize)).value.value
            as *const ::core::ffi::c_void,
        b"value_2\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_entry_list\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            29 as ::core::ffi::c_int,
            b"memcmp(list->entries[1].value.value, \"value_2\", sizeof(\"value_2\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(2 as ::core::ffi::c_int as isize)).key.key
            as *const ::core::ffi::c_void,
        b"entry_3\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_entry_list\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            30 as ::core::ffi::c_int,
            b"memcmp(list->entries[2].key.key, \"entry_3\", sizeof(\"entry_3\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(2 as ::core::ffi::c_int as isize)).value.value
            as *const ::core::ffi::c_void,
        b"value_3\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_entry_list\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            31 as ::core::ffi::c_int,
            b"memcmp(list->entries[2].value.value, \"value_3\", sizeof(\"value_3\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(3 as ::core::ffi::c_int as isize)).key.key
            as *const ::core::ffi::c_void,
        b"entry_4\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_entry_list\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            32 as ::core::ffi::c_int,
            b"memcmp(list->entries[3].key.key, \"entry_4\", sizeof(\"entry_4\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(3 as ::core::ffi::c_int as isize)).value.value
            as *const ::core::ffi::c_void,
        b"value_4\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_entry_list\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            33 as ::core::ffi::c_int,
            b"memcmp(list->entries[3].value.value, \"value_4\", sizeof(\"value_4\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(4 as ::core::ffi::c_int as isize)).key.key
            as *const ::core::ffi::c_void,
        b"entry_5\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_entry_list\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            34 as ::core::ffi::c_int,
            b"memcmp(list->entries[4].key.key, \"entry_5\", sizeof(\"entry_5\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(4 as ::core::ffi::c_int as isize)).value.value
            as *const ::core::ffi::c_void,
        b"value_5\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_entry_list\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            35 as ::core::ffi::c_int,
            b"memcmp(list->entries[4].value.value, \"value_5\", sizeof(\"value_5\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    free_tree(&mut btree);
    free_entry_list(&mut list);
}
#[no_mangle]
pub unsafe extern "C" fn test_remove_entry() {
    let mut btree: *mut btree_t = new_btree();
    add_entry(
        btree,
        b"entry_1\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
        b"value_1\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    add_entry(
        btree,
        b"entry_2\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
        b"value_2\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    add_entry(
        btree,
        b"entry_3\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
        b"value_3\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    add_entry(
        btree,
        b"entry_4\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
        b"value_4\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    add_entry(
        btree,
        b"entry_5\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
        b"value_5\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    remove_entry(
        btree,
        b"entry_3\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    let mut list: *mut entry_list_t = list_entries(btree);
    if !((*list).len == 4 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 18],
                [::core::ffi::c_char; 18],
            >(*b"test_remove_entry\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            49 as ::core::ffi::c_int,
            b"list->len == 4\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(0 as ::core::ffi::c_int as isize)).key.key
            as *const ::core::ffi::c_void,
        b"entry_1\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 18],
                [::core::ffi::c_char; 18],
            >(*b"test_remove_entry\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            50 as ::core::ffi::c_int,
            b"memcmp(list->entries[0].key.key, \"entry_1\", sizeof(\"entry_1\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(0 as ::core::ffi::c_int as isize)).value.value
            as *const ::core::ffi::c_void,
        b"value_1\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 18],
                [::core::ffi::c_char; 18],
            >(*b"test_remove_entry\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            51 as ::core::ffi::c_int,
            b"memcmp(list->entries[0].value.value, \"value_1\", sizeof(\"value_1\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(1 as ::core::ffi::c_int as isize)).key.key
            as *const ::core::ffi::c_void,
        b"entry_2\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 18],
                [::core::ffi::c_char; 18],
            >(*b"test_remove_entry\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            52 as ::core::ffi::c_int,
            b"memcmp(list->entries[1].key.key, \"entry_2\", sizeof(\"entry_2\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(1 as ::core::ffi::c_int as isize)).value.value
            as *const ::core::ffi::c_void,
        b"value_2\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 18],
                [::core::ffi::c_char; 18],
            >(*b"test_remove_entry\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            53 as ::core::ffi::c_int,
            b"memcmp(list->entries[1].value.value, \"value_2\", sizeof(\"value_2\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(2 as ::core::ffi::c_int as isize)).key.key
            as *const ::core::ffi::c_void,
        b"entry_4\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 18],
                [::core::ffi::c_char; 18],
            >(*b"test_remove_entry\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            54 as ::core::ffi::c_int,
            b"memcmp(list->entries[2].key.key, \"entry_4\", sizeof(\"entry_4\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(2 as ::core::ffi::c_int as isize)).value.value
            as *const ::core::ffi::c_void,
        b"value_4\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 18],
                [::core::ffi::c_char; 18],
            >(*b"test_remove_entry\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            55 as ::core::ffi::c_int,
            b"memcmp(list->entries[2].value.value, \"value_4\", sizeof(\"value_4\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(3 as ::core::ffi::c_int as isize)).key.key
            as *const ::core::ffi::c_void,
        b"entry_5\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 18],
                [::core::ffi::c_char; 18],
            >(*b"test_remove_entry\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            56 as ::core::ffi::c_int,
            b"memcmp(list->entries[3].key.key, \"entry_5\", sizeof(\"entry_5\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*(*list).entries.offset(3 as ::core::ffi::c_int as isize)).value.value
            as *const ::core::ffi::c_void,
        b"value_5\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 18],
                [::core::ffi::c_char; 18],
            >(*b"test_remove_entry\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            57 as ::core::ffi::c_int,
            b"memcmp(list->entries[3].value.value, \"value_5\", sizeof(\"value_5\")) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    free_tree(&mut btree);
    free_entry_list(&mut list);
}
#[no_mangle]
pub unsafe extern "C" fn test_multiple_key_types() {
    let mut btree: *mut btree_t = new_btree();
    add_entry(
        btree,
        b"entry_1\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
        b"value_1\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    let mut int_key: uint32_t = 1 as uint32_t;
    add_entry(
        btree,
        &mut int_key as *mut uint32_t as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<uint32_t>() as size_t,
        b"value_2\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    let mut long_key: uint64_t = 10 as uint64_t;
    add_entry(
        btree,
        &mut long_key as *mut uint64_t as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<uint64_t>() as size_t,
        b"value_3\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    let mut byte_key: uint8_t = 9 as uint8_t;
    add_entry(
        btree,
        &mut byte_key as *mut uint8_t as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<uint8_t>() as size_t,
        b"value_4\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    let mut value: *mut value_t = find_entry(
        btree,
        b"entry_1\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    if value.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"test_multiple_key_types\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            73 as ::core::ffi::c_int,
            b"value != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*value).value as *const ::core::ffi::c_void,
        b"value_1\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"test_multiple_key_types\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            74 as ::core::ffi::c_int,
            b"memcmp(value->value, \"value_1\", sizeof(\"value_1\")) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    value = find_entry(
        btree,
        &mut int_key as *mut uint32_t as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<uint32_t>() as size_t,
    );
    if value.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"test_multiple_key_types\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            77 as ::core::ffi::c_int,
            b"value != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*value).value as *const ::core::ffi::c_void,
        b"value_2\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"test_multiple_key_types\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            78 as ::core::ffi::c_int,
            b"memcmp(value->value, \"value_2\", sizeof(\"value_2\")) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    value = find_entry(
        btree,
        &mut long_key as *mut uint64_t as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<uint64_t>() as size_t,
    );
    if value.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"test_multiple_key_types\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            81 as ::core::ffi::c_int,
            b"value != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*value).value as *const ::core::ffi::c_void,
        b"value_3\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"test_multiple_key_types\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            82 as ::core::ffi::c_int,
            b"memcmp(value->value, \"value_3\", sizeof(\"value_3\")) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    value = find_entry(
        btree,
        &mut byte_key as *mut uint8_t as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<uint8_t>() as size_t,
    );
    if value.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"test_multiple_key_types\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            85 as ::core::ffi::c_int,
            b"value != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*value).value as *const ::core::ffi::c_void,
        b"value_4\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"test_multiple_key_types\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            86 as ::core::ffi::c_int,
            b"memcmp(value->value, \"value_4\", sizeof(\"value_4\")) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    free_tree(&mut btree);
}
#[no_mangle]
pub unsafe extern "C" fn test_add_custom_struct() {
    let mut btree: *mut btree_t = new_btree();
    let mut key: custom_key_t = {
        let mut init = custom_key {
            key: 1 as uint32_t,
            key2: 2 as uint32_t,
        };
        init
    };
    add_entry(
        btree,
        &mut key as *mut custom_key_t as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<custom_key_t>() as size_t,
        b"value_1\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    );
    let mut value: *mut value_t = find_entry(
        btree,
        &mut key as *mut custom_key_t as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<custom_key_t>() as size_t,
    );
    if value.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_add_custom_struct\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            101 as ::core::ffi::c_int,
            b"value != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*value).value as *const ::core::ffi::c_void,
        b"value_1\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 8]>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_add_custom_struct\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            102 as ::core::ffi::c_int,
            b"memcmp(value->value, \"value_1\", sizeof(\"value_1\")) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    free_tree(&mut btree);
}
#[no_mangle]
pub unsafe extern "C" fn test_add_custom_struct_to_value() {
    let mut btree: *mut btree_t = new_btree();
    let mut c_value: custom_value_t = {
        let mut init = custom_value {
            value: 1 as uint32_t,
            value2: 2 as uint32_t,
        };
        init
    };
    add_entry(
        btree,
        b"key_1\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 6]>() as size_t,
        &mut c_value as *mut custom_value_t as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<custom_value_t>() as size_t,
    );
    let mut value: *mut value_t = find_entry(
        btree,
        b"key_1\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_char; 6]>() as size_t,
    );
    if value.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 32],
                [::core::ffi::c_char; 32],
            >(*b"test_add_custom_struct_to_value\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            116 as ::core::ffi::c_int,
            b"value != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        (*value).value as *const ::core::ffi::c_void,
        &mut c_value as *mut custom_value_t as *const ::core::ffi::c_void,
        ::core::mem::size_of::<custom_value_t>() as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 32],
                [::core::ffi::c_char; 32],
            >(*b"test_add_custom_struct_to_value\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            117 as ::core::ffi::c_int,
            b"memcmp(value->value, &c_value, sizeof(c_value)) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    free_tree(&mut btree);
}
unsafe fn main_0() -> ::core::ffi::c_int {
    test_add_entry();
    test_entry_list();
    test_remove_entry();
    test_multiple_key_types();
    test_add_custom_struct();
    test_add_custom_struct_to_value();
    printf(b"All tests passed!\n\0" as *const u8 as *const ::core::ffi::c_char);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
