#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn init_channel(
        _: *mut Channel,
        p: uint64_t,
        q: uint64_t,
        w: uint64_t,
    ) -> ::core::ffi::c_int;
    fn set_polynomial(
        p: *mut Polynomial,
        coeffs: *mut Coeff,
        size: size_t,
    ) -> ::core::ffi::c_int;
    fn set_zero(p: *const Polynomial) -> ::core::ffi::c_int;
    fn coef_sum(poly: *const Polynomial) -> int64_t;
    fn poly_fit(poly: *mut Polynomial, mod_0: uint64_t) -> ::core::ffi::c_int;
    fn poly_mul(
        poly1: *const Polynomial,
        poly2: *const Polynomial,
        result: *mut Polynomial,
        mod_0: uint64_t,
    ) -> ::core::ffi::c_int;
    fn poly_add(
        poly1: *const Polynomial,
        poly2: *const Polynomial,
        result: *mut Polynomial,
        mod_0: uint64_t,
    ) -> ::core::ffi::c_int;
    fn poly_sub(
        poly1: *const Polynomial,
        poly2: *const Polynomial,
        result: *mut Polynomial,
        mod_0: uint64_t,
    ) -> ::core::ffi::c_int;
    fn poly_mod(
        poly1: *mut Polynomial,
        poly2: *const Polynomial,
        mod_0: uint64_t,
    ) -> ::core::ffi::c_int;
    fn poly_sub_scaler(
        poly: *const Polynomial,
        scaler: uint64_t,
        result: *mut Polynomial,
        mod_0: uint64_t,
    ) -> ::core::ffi::c_int;
    fn generate_error(
        q: uint64_t,
        message: uint64_t,
        rm: *mut Polynomial,
    ) -> ::core::ffi::c_int;
    fn generate_vanisher(p: uint64_t, q: uint64_t, e: *mut Polynomial) -> uint64_t;
    fn generate_linear(p: uint64_t, q: uint64_t, b: *mut Polynomial) -> uint64_t;
    fn generate_u(
        channel: *const Channel,
        param: *const Parameters,
        u: *mut Polynomial,
    ) -> ::core::ffi::c_int;
    fn generate_secret(
        channel: *const Channel,
        param: *const Parameters,
        u: *const Polynomial,
        secret: *mut PolyArray,
        lambda: *mut Matrix3D,
    ) -> ::core::ffi::c_int;
    fn generate_f0(
        channel: *const Channel,
        param: *const Parameters,
        f0: *mut PolyArray,
    ) -> ::core::ffi::c_int;
    fn generate_f1(
        channel: *const Channel,
        param: *const Parameters,
        f0: *const PolyArray,
        x: *const PolyArray,
        u: *const Polynomial,
        f1: *mut Polynomial,
    ) -> ::core::ffi::c_int;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type int64_t = i64;
pub type uint8_t = u8;
pub type uint64_t = u64;
pub type __darwin_size_t = usize;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Parameters {
    pub dim: uint64_t,
    pub N: uint64_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Channel {
    pub p: uint64_t,
    pub q: uint64_t,
    pub w: uint64_t,
}
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Matrix2D {
    pub dim: size_t,
    pub data: *mut uint64_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Matrix3D {
    pub data: *mut Matrix2D,
    pub size: size_t,
}
pub type Coeff = int64_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Polynomial {
    pub coeffs: *mut Coeff,
    pub size: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct PolyArray {
    pub polies: *mut Polynomial,
    pub size: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct PublicKey {
    pub u: Polynomial,
    pub lambda: Matrix3D,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct PrivateKey {
    pub x: PolyArray,
    pub f0: PolyArray,
    pub f1: Polynomial,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct SharedInfo {
    pub channel: Channel,
    pub param: Parameters,
    pub pk: PublicKey,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Aces {
    pub shared_info: SharedInfo,
    pub private_key: PrivateKey,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct CipherMessage {
    pub c1: PolyArray,
    pub c2: Polynomial,
    pub level: uint64_t,
}
#[no_mangle]
pub unsafe extern "C" fn set_aces(
    mut aces: *mut Aces,
    mut dim: size_t,
    mut memory: *mut ::core::ffi::c_void,
    mut size: size_t,
) -> ::core::ffi::c_int {
    let mut required: size_t = (::core::mem::size_of::<Coeff>() as size_t)
        .wrapping_mul(
            (2 as size_t)
                .wrapping_mul(dim)
                .wrapping_add(1 as size_t)
                .wrapping_add((2 as size_t).wrapping_mul(dim).wrapping_mul(dim)),
        )
        .wrapping_add((::core::mem::size_of::<Matrix2D>() as size_t).wrapping_mul(dim))
        .wrapping_add(
            (::core::mem::size_of::<Polynomial>() as size_t)
                .wrapping_mul(2 as size_t)
                .wrapping_mul(dim),
        )
        .wrapping_add(
            (::core::mem::size_of::<uint64_t>() as size_t)
                .wrapping_mul(dim)
                .wrapping_mul(dim)
                .wrapping_mul(dim),
        );
    if size < required {
        return -(1 as ::core::ffi::c_int);
    }
    let mut mem: *mut uint8_t = memory as *mut uint8_t;
    let mut u_mem: *mut Coeff = mem as *mut Coeff;
    mem = mem
        .offset(
            dim
                .wrapping_add(1 as size_t)
                .wrapping_mul(::core::mem::size_of::<Coeff>() as size_t) as isize,
        );
    set_polynomial(&mut (*aces).shared_info.pk.u, u_mem, dim.wrapping_add(1 as size_t));
    let mut lambda_mat: *mut Matrix2D = mem as *mut Matrix2D;
    mem = mem
        .offset(dim.wrapping_mul(::core::mem::size_of::<Matrix2D>() as size_t) as isize);
    let mut lambda_mem: *mut uint64_t = mem as *mut uint64_t;
    mem = mem
        .offset(
            dim
                .wrapping_mul(dim)
                .wrapping_mul(dim)
                .wrapping_mul(::core::mem::size_of::<uint64_t>() as size_t) as isize,
        );
    let mut i: size_t = 0 as size_t;
    while i < dim {
        (*lambda_mat.offset(i as isize)).dim = dim;
        let ref mut fresh0 = (*lambda_mat.offset(i as isize)).data;
        *fresh0 = lambda_mem.offset(i.wrapping_mul(dim).wrapping_mul(dim) as isize);
        i = i.wrapping_add(1);
    }
    (*aces).shared_info.pk.lambda.size = dim;
    (*aces).shared_info.pk.lambda.data = lambda_mat;
    let mut x_polies: *mut Polynomial = mem as *mut Polynomial;
    mem = mem
        .offset(
            dim.wrapping_mul(::core::mem::size_of::<Polynomial>() as size_t) as isize,
        );
    let mut x_mem: *mut Coeff = mem as *mut Coeff;
    mem = mem
        .offset(
            dim.wrapping_mul(dim).wrapping_mul(::core::mem::size_of::<Coeff>() as size_t)
                as isize,
        );
    let mut i_0: size_t = 0 as size_t;
    while i_0 < dim {
        set_polynomial(
            &mut *x_polies.offset(i_0 as isize),
            x_mem.offset(i_0.wrapping_mul(dim) as isize),
            dim,
        );
        i_0 = i_0.wrapping_add(1);
    }
    (*aces).private_key.x.size = dim;
    (*aces).private_key.x.polies = x_polies;
    let mut f0_polies: *mut Polynomial = mem as *mut Polynomial;
    mem = mem
        .offset(
            dim.wrapping_mul(::core::mem::size_of::<Polynomial>() as size_t) as isize,
        );
    let mut f0_mem: *mut Coeff = mem as *mut Coeff;
    mem = mem
        .offset(
            dim.wrapping_mul(dim).wrapping_mul(::core::mem::size_of::<Coeff>() as size_t)
                as isize,
        );
    let mut i_1: size_t = 0 as size_t;
    while i_1 < dim {
        set_polynomial(
            &mut *f0_polies.offset(i_1 as isize),
            f0_mem.offset(i_1.wrapping_mul(dim) as isize),
            dim,
        );
        i_1 = i_1.wrapping_add(1);
    }
    (*aces).private_key.f0.size = dim;
    (*aces).private_key.f0.polies = f0_polies;
    let mut f1_mem: *mut Coeff = mem as *mut Coeff;
    mem = mem
        .offset(dim.wrapping_mul(::core::mem::size_of::<Coeff>() as size_t) as isize);
    set_polynomial(&mut (*aces).private_key.f1, f1_mem, dim);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn init_aces(
    mut p: uint64_t,
    mut q: uint64_t,
    mut dim: uint64_t,
    mut aces: *mut Aces,
) -> ::core::ffi::c_int {
    (*aces).shared_info.param.dim = dim;
    (*aces).shared_info.param.N = 1 as uint64_t;
    init_channel(&mut (*aces).shared_info.channel, p, q, 1 as uint64_t);
    generate_u(
        &mut (*aces).shared_info.channel,
        &mut (*aces).shared_info.param,
        &mut (*aces).shared_info.pk.u,
    );
    generate_secret(
        &mut (*aces).shared_info.channel,
        &mut (*aces).shared_info.param,
        &mut (*aces).shared_info.pk.u,
        &mut (*aces).private_key.x,
        &mut (*aces).shared_info.pk.lambda,
    );
    generate_f0(
        &mut (*aces).shared_info.channel,
        &mut (*aces).shared_info.param,
        &mut (*aces).private_key.f0,
    );
    generate_f1(
        &mut (*aces).shared_info.channel,
        &mut (*aces).shared_info.param,
        &mut (*aces).private_key.f0,
        &mut (*aces).private_key.x,
        &mut (*aces).shared_info.pk.u,
        &mut (*aces).private_key.f1,
    );
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn aces_encrypt(
    mut aces: *const Aces,
    mut message: *const uint64_t,
    mut size: size_t,
    mut result: *mut CipherMessage,
) -> ::core::ffi::c_int {
    if size > 1 as size_t {
        return -(1 as ::core::ffi::c_int);
    }
    let dim: size_t = (*aces).shared_info.param.dim as size_t;
    let vla = (3 as size_t).wrapping_mul(dim) as usize;
    let mut mem: Vec<Coeff> = ::std::vec::from_elem(0, vla);
    let mut r_m: Polynomial = Polynomial {
        coeffs: 0 as *mut Coeff,
        size: 0,
    };
    let mut e: Polynomial = Polynomial {
        coeffs: 0 as *mut Coeff,
        size: 0,
    };
    let mut b: Polynomial = Polynomial {
        coeffs: 0 as *mut Coeff,
        size: 0,
    };
    set_polynomial(&mut r_m, mem.as_mut_ptr(), dim);
    set_polynomial(&mut e, mem.as_mut_ptr().offset(dim as isize), dim);
    set_polynomial(
        &mut b,
        mem.as_mut_ptr().offset((2 as size_t).wrapping_mul(dim) as isize),
        dim,
    );
    generate_error((*aces).shared_info.channel.q, *message, &mut r_m);
    generate_vanisher(
        (*aces).shared_info.channel.p,
        (*aces).shared_info.channel.q,
        &mut e,
    );
    generate_linear(
        (*aces).shared_info.channel.p,
        (*aces).shared_info.channel.q,
        &mut b,
    );
    let vla_0 = (2 as size_t).wrapping_mul(dim) as usize;
    let mut tmp_mem: Vec<Coeff> = ::std::vec::from_elem(0, vla_0);
    let mut tmp: Polynomial = Polynomial {
        coeffs: 0 as *mut Coeff,
        size: 0,
    };
    let mut i: size_t = 0 as size_t;
    while i < dim {
        set_polynomial(&mut tmp, tmp_mem.as_mut_ptr(), (2 as size_t).wrapping_mul(dim));
        poly_mul(
            &mut b,
            &mut *(*aces).private_key.f0.polies.offset(i as isize),
            &mut tmp,
            (*aces).shared_info.channel.q,
        );
        poly_mod(&mut tmp, &(*aces).shared_info.pk.u, (*aces).shared_info.channel.q);
        memcpy(
            (*(*result).c1.polies.offset(i as isize)).coeffs as *mut ::core::ffi::c_void,
            tmp.coeffs as *const ::core::ffi::c_void,
            tmp.size.wrapping_mul(::core::mem::size_of::<Coeff>() as size_t),
        );
        i = i.wrapping_add(1);
    }
    set_polynomial(&mut tmp, tmp_mem.as_mut_ptr(), (2 as size_t).wrapping_mul(dim));
    poly_add(
        &(*aces).private_key.f1,
        &mut e,
        &mut (*result).c2,
        (*aces).shared_info.channel.q,
    );
    poly_mul(&mut (*result).c2, &mut b, &mut tmp, (*aces).shared_info.channel.q);
    poly_add(&mut tmp, &mut r_m, &mut tmp, (*aces).shared_info.channel.q);
    poly_mod(&mut tmp, &(*aces).shared_info.pk.u, (*aces).shared_info.channel.q);
    memcpy(
        (*result).c2.coeffs as *mut ::core::ffi::c_void,
        tmp.coeffs as *const ::core::ffi::c_void,
        tmp.size.wrapping_mul(::core::mem::size_of::<Coeff>() as size_t),
    );
    (*result).level = (*aces).shared_info.channel.p;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn aces_decrypt(
    mut aces: *const Aces,
    mut message: *const CipherMessage,
    mut size: size_t,
    mut result: *mut uint64_t,
) -> ::core::ffi::c_int {
    if size > 1 as size_t {
        return -(1 as ::core::ffi::c_int);
    }
    let dim: size_t = (*aces).shared_info.param.dim as size_t;
    let vla = (2 as size_t).wrapping_mul(dim) as usize;
    let mut c0Tx_mem: Vec<Coeff> = ::std::vec::from_elem(0, vla);
    let mut c0Tx: Polynomial = Polynomial {
        coeffs: 0 as *mut Coeff,
        size: 0,
    };
    set_polynomial(&mut c0Tx, c0Tx_mem.as_mut_ptr(), (2 as size_t).wrapping_mul(dim));
    set_zero(&mut c0Tx);
    let vla_0 = (2 as size_t).wrapping_mul(dim) as usize;
    let mut tmp_mem: Vec<Coeff> = ::std::vec::from_elem(0, vla_0);
    let mut tmp: Polynomial = Polynomial {
        coeffs: 0 as *mut Coeff,
        size: 0,
    };
    let mut i: size_t = 0 as size_t;
    while i < dim {
        set_polynomial(&mut tmp, tmp_mem.as_mut_ptr(), (2 as size_t).wrapping_mul(dim));
        poly_mul(
            &mut *(*message).c1.polies.offset(i as isize),
            &mut *(*aces).private_key.x.polies.offset(i as isize),
            &mut tmp,
            (*aces).shared_info.channel.q,
        );
        poly_add(&mut tmp, &mut c0Tx, &mut c0Tx, (*aces).shared_info.channel.q);
        i = i.wrapping_add(1);
    }
    poly_fit(&mut c0Tx, (*aces).shared_info.channel.q);
    poly_sub(&(*message).c2, &mut c0Tx, &mut c0Tx, (*aces).shared_info.channel.q);
    *result = (coef_sum(&mut c0Tx) as uint64_t)
        .wrapping_rem((*aces).shared_info.channel.q)
        .wrapping_rem((*aces).shared_info.channel.p);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn aces_add(
    mut a: *const CipherMessage,
    mut b: *const CipherMessage,
    mut info: *const SharedInfo,
    mut result: *mut CipherMessage,
) -> ::core::ffi::c_int {
    let mut i: size_t = 0 as size_t;
    while (i as uint64_t) < (*info).param.dim {
        poly_add(
            &mut *(*a).c1.polies.offset(i as isize),
            &mut *(*b).c1.polies.offset(i as isize),
            &mut *(*result).c1.polies.offset(i as isize),
            (*info).channel.q,
        );
        poly_mod(
            &mut *(*result).c1.polies.offset(i as isize),
            &(*info).pk.u,
            (*info).channel.q,
        );
        i = i.wrapping_add(1);
    }
    poly_add(&(*a).c2, &(*b).c2, &mut (*result).c2, (*info).channel.q);
    poly_mod(&mut (*result).c2, &(*info).pk.u, (*info).channel.q);
    (*result).level = (*a).level.wrapping_add((*b).level);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn aces_mul(
    mut a: *const CipherMessage,
    mut b: *const CipherMessage,
    mut info: *const SharedInfo,
    mut result: *mut CipherMessage,
) -> ::core::ffi::c_int {
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn aces_refresh(
    mut info: *const SharedInfo,
    mut a: *mut CipherMessage,
    mut k: uint64_t,
) -> ::core::ffi::c_int {
    poly_sub_scaler(
        &mut (*a).c2,
        k.wrapping_mul((*info).channel.p),
        &mut (*a).c2,
        (*info).channel.q,
    );
    (*a).level = (*a).level.wrapping_sub(k);
    return 0 as ::core::ffi::c_int;
}
