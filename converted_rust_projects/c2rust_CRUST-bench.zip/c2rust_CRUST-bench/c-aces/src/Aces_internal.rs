#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn matrix3d_get(lambda: *mut Matrix3D, idx: size_t) -> *mut Matrix2D;
    fn matrix2d_multiply(
        m: *mut Matrix2D,
        invm: *mut Matrix2D,
        result: *mut Matrix2D,
        mod_0: uint64_t,
    ) -> ::core::ffi::c_int;
    fn fill_random_invertible_pairs(
        m: *mut Matrix2D,
        invm: *mut Matrix2D,
        mod_0: uint64_t,
        iterations: size_t,
    ) -> ::core::ffi::c_int;
    fn set_polynomial(
        p: *mut Polynomial,
        coeffs: *mut Coeff,
        size: size_t,
    ) -> ::core::ffi::c_int;
    fn set_zero(p: *const Polynomial) -> ::core::ffi::c_int;
    fn coef_sum(poly: *const Polynomial) -> int64_t;
    fn poly_mul(
        poly1: *const Polynomial,
        poly2: *const Polynomial,
        result: *mut Polynomial,
        mod_0: uint64_t,
    ) -> ::core::ffi::c_int;
    fn poly_add(
        poly1: *const Polynomial,
        poly2: *const Polynomial,
        result: *mut Polynomial,
        mod_0: uint64_t,
    ) -> ::core::ffi::c_int;
    fn poly_mod(
        poly1: *mut Polynomial,
        poly2: *const Polynomial,
        mod_0: uint64_t,
    ) -> ::core::ffi::c_int;
    fn randrange(lower: uint64_t, upper: uint64_t) -> uint64_t;
    fn normal_rand(
        mean: ::core::ffi::c_double,
        stddev: ::core::ffi::c_double,
    ) -> ::core::ffi::c_double;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type int64_t = i64;
pub type uint64_t = u64;
pub type __darwin_size_t = usize;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Parameters {
    pub dim: uint64_t,
    pub N: uint64_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Channel {
    pub p: uint64_t,
    pub q: uint64_t,
    pub w: uint64_t,
}
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Matrix2D {
    pub dim: size_t,
    pub data: *mut uint64_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Matrix3D {
    pub data: *mut Matrix2D,
    pub size: size_t,
}
pub type Coeff = int64_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Polynomial {
    pub coeffs: *mut Coeff,
    pub size: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct PolyArray {
    pub polies: *mut Polynomial,
    pub size: size_t,
}
#[inline]
unsafe extern "C" fn matrix2d_get(
    mut matrix: *mut Matrix2D,
    mut row: size_t,
    mut col: size_t,
) -> uint64_t {
    let mut dim: size_t = (*matrix).dim;
    return *(*matrix).data.offset(row.wrapping_mul(dim).wrapping_add(col) as isize);
}
#[inline]
unsafe extern "C" fn matrix2d_set(
    mut matrix: *mut Matrix2D,
    mut row: size_t,
    mut col: size_t,
    mut value: uint64_t,
) {
    let mut dim: size_t = (*matrix).dim;
    *(*matrix).data.offset(row.wrapping_mul(dim).wrapping_add(col) as isize) = value;
}
pub const EPROB: ::core::ffi::c_double = 0.5f64;
#[inline]
unsafe extern "C" fn max(mut a: uint64_t, mut b: uint64_t) -> uint64_t {
    return if a > b { a } else { b };
}
#[inline]
unsafe extern "C" fn min(mut a: uint64_t, mut b: uint64_t) -> uint64_t {
    return if a < b { a } else { b };
}
#[inline]
unsafe extern "C" fn clamp(
    mut min_value: uint64_t,
    mut max_value: uint64_t,
    mut value: uint64_t,
) -> uint64_t {
    return max(min_value, min(max_value, value));
}
#[no_mangle]
pub unsafe extern "C" fn generate_error(
    mut q: uint64_t,
    mut message: uint64_t,
    mut rm: *mut Polynomial,
) -> ::core::ffi::c_int {
    let mut i: size_t = 0 as size_t;
    while i < (*rm).size {
        *(*rm).coeffs.offset(i as isize) = randrange(0 as uint64_t, q) as Coeff;
        i = i.wrapping_add(1);
    }
    let mut shift: Coeff = (*(*rm)
        .coeffs
        .offset((*rm).size.wrapping_sub(1 as size_t) as isize)
        + (message as Coeff - coef_sum(rm))) % q as Coeff;
    *(*rm).coeffs.offset((*rm).size.wrapping_sub(1 as size_t) as isize) = if shift
        > 0 as Coeff
    {
        shift
    } else {
        shift + q as Coeff
    };
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn generate_vanisher(
    mut p: uint64_t,
    mut q: uint64_t,
    mut e: *mut Polynomial,
) -> uint64_t {
    let mut k: int64_t = (if (randrange(0 as uint64_t, 1 as uint64_t)
        as ::core::ffi::c_double) < EPROB
    {
        0 as ::core::ffi::c_int
    } else {
        1 as ::core::ffi::c_int
    }) as int64_t;
    let mut i: size_t = 0 as size_t;
    while i < (*e).size {
        *(*e).coeffs.offset(i as isize) = randrange(0 as uint64_t, q) as Coeff;
        i = i.wrapping_add(1);
    }
    let mut shift: Coeff = (*(*e)
        .coeffs
        .offset((*e).size.wrapping_sub(1 as size_t) as isize) + p as Coeff * k as Coeff
        - coef_sum(e) as Coeff) % q as Coeff;
    *(*e).coeffs.offset((*e).size.wrapping_sub(1 as size_t) as isize) = if shift
        > 0 as Coeff
    {
        shift
    } else {
        shift + q as Coeff
    };
    return k as uint64_t;
}
#[no_mangle]
pub unsafe extern "C" fn generate_linear(
    mut p: uint64_t,
    mut q: uint64_t,
    mut b: *mut Polynomial,
) -> uint64_t {
    let mut k: int64_t = randrange(0 as uint64_t, p) as int64_t;
    let mut i: size_t = 0 as size_t;
    while i < (*b).size {
        *(*b).coeffs.offset(i as isize) = randrange(0 as uint64_t, q) as Coeff;
        i = i.wrapping_add(1);
    }
    let mut shift: Coeff = (*(*b)
        .coeffs
        .offset((*b).size.wrapping_sub(1 as size_t) as isize) + k as Coeff
        - coef_sum(b) as Coeff) % q as Coeff;
    *(*b).coeffs.offset((*b).size.wrapping_sub(1 as size_t) as isize) = if shift
        > 0 as Coeff
    {
        shift
    } else {
        shift + q as Coeff
    };
    return k as uint64_t;
}
#[no_mangle]
pub unsafe extern "C" fn generate_u(
    mut channel: *const Channel,
    mut param: *const Parameters,
    mut u: *mut Polynomial,
) -> ::core::ffi::c_int {
    let mut nonzeros: uint64_t = randrange(
        (*param).dim.wrapping_div(2 as uint64_t),
        (*param).dim.wrapping_sub(1 as uint64_t),
    );
    let mut zeroes: uint64_t = (*param).dim.wrapping_sub(nonzeros);
    *(*u).coeffs.offset(0 as ::core::ffi::c_int as isize) = 1 as Coeff;
    let mut i: size_t = 1 as size_t;
    while (i as uint64_t) < (*param).dim {
        if !(nonzeros > 1 as uint64_t) {
            break;
        }
        let fresh0 = i;
        i = i.wrapping_add(1);
        *(*u).coeffs.offset(fresh0 as isize) = randrange(0 as uint64_t, (*channel).q)
            as Coeff;
        nonzeros = nonzeros.wrapping_sub(1);
        if zeroes > 0 as uint64_t {
            let mut samp: uint64_t = clamp(
                0 as uint64_t,
                zeroes,
                normal_rand(
                    zeroes.wrapping_div(2 as uint64_t) as ::core::ffi::c_double,
                    zeroes.wrapping_div(2 as uint64_t) as ::core::ffi::c_double,
                ) as uint64_t,
            );
            let mut zero: uint64_t = randrange(0 as uint64_t, samp);
            let mut j: size_t = 0 as size_t;
            while (j as uint64_t) < zero {
                let fresh1 = i;
                i = i.wrapping_add(1);
                *(*u).coeffs.offset(fresh1 as isize) = 0 as Coeff;
                j = j.wrapping_add(1);
            }
            zeroes = zeroes.wrapping_sub(zero);
        }
    }
    *(*u).coeffs.offset((*param).dim as isize) = 0 as Coeff;
    *(*u).coeffs.offset((*param).dim as isize) = ((*channel).q as int64_t - coef_sum(u))
        as Coeff;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn generate_secret(
    mut channel: *const Channel,
    mut param: *const Parameters,
    mut u: *const Polynomial,
    mut secret: *mut PolyArray,
    mut lambda: *mut Matrix3D,
) -> ::core::ffi::c_int {
    let mut m: Matrix2D = Matrix2D {
        dim: 0,
        data: 0 as *mut uint64_t,
    };
    let mut invm: Matrix2D = Matrix2D {
        dim: 0,
        data: 0 as *mut uint64_t,
    };
    m.dim = (*param).dim as size_t;
    invm.dim = (*param).dim as size_t;
    let mut required_mem: size_t = m.dim.wrapping_mul(m.dim);
    let vla = (2 as size_t).wrapping_mul(required_mem) as usize;
    let mut mem: Vec<uint64_t> = ::std::vec::from_elem(0, vla);
    m.data = mem.as_mut_ptr();
    invm.data = mem.as_mut_ptr().offset(required_mem as isize);
    fill_random_invertible_pairs(&mut m, &mut invm, (*channel).q, 600 as size_t);
    (*secret).size = m.dim;
    let mut i: size_t = 0 as size_t;
    while i < m.dim {
        let mut j: size_t = 0 as size_t;
        while j < m.dim {
            *(*(*secret).polies.offset(i as isize)).coeffs.offset(j as isize) = matrix2d_get(
                &mut m,
                j,
                i,
            ) as Coeff;
            j = j.wrapping_add(1);
        }
        i = i.wrapping_add(1);
    }
    let mut arr: *mut Matrix2D = &mut m;
    let mut a_ij_poly: Polynomial = Polynomial {
        coeffs: 0 as *mut Coeff,
        size: 0,
    };
    let vla_0 = (2 as size_t).wrapping_mul((*secret).size) as usize;
    let mut miim: Vec<Coeff> = ::std::vec::from_elem(0, vla_0);
    let mut i_0: size_t = 0 as size_t;
    while i_0 < (*secret).size {
        let mut j_0: size_t = 0 as size_t;
        while j_0 < (*secret).size {
            set_polynomial(
                &mut a_ij_poly,
                miim.as_mut_ptr(),
                (2 as size_t).wrapping_mul((*secret).size),
            );
            poly_mul(
                &mut *(*secret).polies.offset(i_0 as isize),
                &mut *(*secret).polies.offset(j_0 as isize),
                &mut a_ij_poly,
                (*channel).q,
            );
            poly_mod(&mut a_ij_poly, u, (*channel).q);
            let mut row: size_t = 0 as size_t;
            while row < (*arr).dim {
                matrix2d_set(
                    arr,
                    row,
                    j_0,
                    *a_ij_poly
                        .coeffs
                        .offset(
                            (*arr).dim.wrapping_sub(row).wrapping_sub(1 as size_t)
                                as isize,
                        ) as uint64_t,
                );
                row = row.wrapping_add(1);
            }
            j_0 = j_0.wrapping_add(1);
        }
        matrix2d_multiply(&mut invm, arr, matrix3d_get(lambda, i_0), (*channel).q);
        i_0 = i_0.wrapping_add(1);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn generate_f0(
    mut channel: *const Channel,
    mut param: *const Parameters,
    mut f0: *mut PolyArray,
) -> ::core::ffi::c_int {
    let mut i: size_t = 0 as size_t;
    while i < (*f0).size {
        let mut j: size_t = 0 as size_t;
        while j < (*(*f0).polies.offset(i as isize)).size {
            *(*(*f0).polies.offset(i as isize)).coeffs.offset(j as isize) = randrange(
                0 as uint64_t,
                (*channel).q.wrapping_sub(1 as uint64_t),
            ) as Coeff;
            j = j.wrapping_add(1);
        }
        i = i.wrapping_add(1);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn generate_f1(
    mut channel: *const Channel,
    mut param: *const Parameters,
    mut f0: *const PolyArray,
    mut x: *const PolyArray,
    mut u: *const Polynomial,
    mut f1: *mut Polynomial,
) -> ::core::ffi::c_int {
    let mut tmp: Polynomial = Polynomial {
        coeffs: 0 as *mut Coeff,
        size: 0,
    };
    let vla = (*param).dim.wrapping_mul(2 as uint64_t) as usize;
    let mut mem: Vec<Coeff> = ::std::vec::from_elem(0, vla);
    let mut f_pre: Polynomial = Polynomial {
        coeffs: 0 as *mut Coeff,
        size: 0,
    };
    let vla_0 = (*param).dim.wrapping_mul(2 as uint64_t) as usize;
    let mut f_pre_mem: Vec<Coeff> = ::std::vec::from_elem(0, vla_0);
    set_polynomial(
        &mut f_pre,
        f_pre_mem.as_mut_ptr(),
        (*param).dim.wrapping_mul(2 as uint64_t) as size_t,
    );
    set_zero(&mut f_pre);
    let mut i: size_t = 0 as size_t;
    while (i as uint64_t) < (*param).dim {
        set_polynomial(
            &mut tmp,
            mem.as_mut_ptr(),
            (*param).dim.wrapping_mul(2 as uint64_t) as size_t,
        );
        poly_mul(
            &mut *(*f0).polies.offset(i as isize),
            &mut *(*x).polies.offset(i as isize),
            &mut tmp,
            (*channel).q,
        );
        poly_add(&mut f_pre, &mut tmp, &mut f_pre, (*channel).q);
        i = i.wrapping_add(1);
    }
    poly_mod(&mut f_pre, u, (*channel).q);
    let mut diff: size_t = (*f1).size.wrapping_sub(f_pre.size);
    (*f1).coeffs = (*f1).coeffs.offset(diff as isize);
    (*f1).size = (*f1).size.wrapping_sub(diff);
    memcpy(
        (*f1).coeffs as *mut ::core::ffi::c_void,
        f_pre.coeffs as *const ::core::ffi::c_void,
        f_pre.size.wrapping_mul(::core::mem::size_of::<Coeff>() as size_t),
    );
    return 0 as ::core::ffi::c_int;
}
