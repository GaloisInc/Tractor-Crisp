#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn are_coprime(x: uint64_t, y: uint64_t) -> ::core::ffi::c_int;
    fn pow(_: ::core::ffi::c_double, _: ::core::ffi::c_double) -> ::core::ffi::c_double;
}
pub type uint64_t = u64;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Channel {
    pub p: uint64_t,
    pub q: uint64_t,
    pub w: uint64_t,
}
#[no_mangle]
pub unsafe extern "C" fn init_channel(
    mut channel: *mut Channel,
    mut p: uint64_t,
    mut q: uint64_t,
    mut w: uint64_t,
) -> ::core::ffi::c_int {
    (*channel).w = w;
    (*channel).p = p;
    (*channel).q = q;
    if !(pow(
        p as ::core::ffi::c_double,
        2 as ::core::ffi::c_int as ::core::ffi::c_double,
    ) < q as ::core::ffi::c_double && are_coprime(p, q) != 0)
    {
        (*channel).q = pow(
            p.wrapping_add(1 as uint64_t) as ::core::ffi::c_double,
            2 as ::core::ffi::c_int as ::core::ffi::c_double,
        ) as uint64_t;
    }
    return 0 as ::core::ffi::c_int;
}
