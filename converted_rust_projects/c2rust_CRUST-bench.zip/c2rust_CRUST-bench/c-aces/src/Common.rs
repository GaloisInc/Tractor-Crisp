#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn cos(_: ::core::ffi::c_double) -> ::core::ffi::c_double;
    fn log(_: ::core::ffi::c_double) -> ::core::ffi::c_double;
    fn sqrt(_: ::core::ffi::c_double) -> ::core::ffi::c_double;
    fn rand() -> ::core::ffi::c_int;
}
pub type int64_t = i64;
pub type uint64_t = u64;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Xgcd {
    pub gcd: uint64_t,
    pub a: int64_t,
    pub b: int64_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Pair {
    pub first: uint64_t,
    pub second: uint64_t,
}
pub const RAND_MAX: ::core::ffi::c_int = 0x7fffffff as ::core::ffi::c_int;
pub const PI: ::core::ffi::c_double = 3.14159265f64;
unsafe extern "C" fn rand_val() -> ::core::ffi::c_double {
    return rand() as ::core::ffi::c_double / RAND_MAX as ::core::ffi::c_double;
}
#[no_mangle]
pub unsafe extern "C" fn normal_rand(
    mut mean: ::core::ffi::c_double,
    mut stddev: ::core::ffi::c_double,
) -> ::core::ffi::c_double {
    let mut u: ::core::ffi::c_double = 0.;
    let mut r: ::core::ffi::c_double = 0.;
    let mut theta: ::core::ffi::c_double = 0.;
    let mut x: ::core::ffi::c_double = 0.;
    let mut norm_rv: ::core::ffi::c_double = 0.;
    u = 0.0f64;
    while u == 0.0f64 {
        u = rand_val();
    }
    r = sqrt(-2.0f64 * log(u));
    theta = 0.0f64;
    while theta == 0.0f64 {
        theta = 2.0f64 * PI * rand_val();
    }
    x = r * cos(theta);
    norm_rv = x * stddev + mean;
    return norm_rv;
}
#[no_mangle]
pub unsafe extern "C" fn gcd(mut x: uint64_t, mut y: uint64_t) -> uint64_t {
    while x != y {
        if x > y {
            x = x.wrapping_sub(y);
        } else {
            y = y.wrapping_sub(x);
        }
    }
    return x;
}
#[no_mangle]
pub unsafe extern "C" fn xgcd(mut x: uint64_t, mut y: uint64_t) -> Xgcd {
    let mut prev_a: int64_t = 1 as int64_t;
    let mut a: int64_t = 0 as int64_t;
    let mut prev_b: int64_t = 0 as int64_t;
    let mut b: int64_t = 1 as int64_t;
    while y != 0 as uint64_t {
        let mut q: int64_t = x.wrapping_div(y) as int64_t;
        let mut temp: int64_t = x.wrapping_rem(y) as int64_t;
        x = y;
        y = temp as uint64_t;
        temp = a;
        a = prev_a - q * a;
        prev_a = temp;
        temp = b;
        b = prev_b - q * b;
        prev_b = temp;
    }
    let mut result: Xgcd = {
        let mut init = Xgcd {
            gcd: x,
            a: prev_a,
            b: prev_b,
        };
        init
    };
    return result;
}
#[no_mangle]
pub unsafe extern "C" fn are_coprime(
    mut x: uint64_t,
    mut y: uint64_t,
) -> ::core::ffi::c_int {
    return !(gcd(x, y) > 1 as uint64_t) as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn randrange(
    mut lower: uint64_t,
    mut upper: uint64_t,
) -> uint64_t {
    return (rand() as uint64_t)
        .wrapping_rem(upper.wrapping_sub(lower).wrapping_add(1 as uint64_t))
        .wrapping_add(lower);
}
#[no_mangle]
pub unsafe extern "C" fn randinverse(mut value: uint64_t) -> Pair {
    let mut a: uint64_t = randrange(2 as uint64_t, value.wrapping_sub(1 as uint64_t));
    while are_coprime(a, value) == 0 {
        a = randrange(2 as uint64_t, value.wrapping_sub(1 as uint64_t));
    }
    let mut result: Xgcd = xgcd(a, value);
    let mut p: Pair = {
        let mut init = Pair {
            first: a,
            second: if result.a > 0 as int64_t {
                result.a as uint64_t
            } else {
                (result.a + value as int64_t) as uint64_t
            },
        };
        init
    };
    return p;
}
