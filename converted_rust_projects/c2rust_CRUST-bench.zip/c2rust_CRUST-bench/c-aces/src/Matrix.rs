#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn randinverse(value: uint64_t) -> Pair;
    fn randrange(lower: uint64_t, upper: uint64_t) -> uint64_t;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint64_t = u64;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Matrix2D {
    pub dim: size_t,
    pub data: *mut uint64_t,
}
pub type Transformer = Option<
    unsafe extern "C" fn(*mut Matrix2D, *mut Matrix2D, uint64_t) -> ::core::ffi::c_int,
>;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Matrix3D {
    pub data: *mut Matrix2D,
    pub size: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Pair {
    pub first: uint64_t,
    pub second: uint64_t,
}
pub const TRANSFORM_COUNT: ::core::ffi::c_int = 3 as ::core::ffi::c_int;
#[inline]
unsafe extern "C" fn matrix2d_row(
    mut matrix: *mut Matrix2D,
    mut row: size_t,
) -> *mut uint64_t {
    return (*matrix).data.offset(row.wrapping_mul((*matrix).dim) as isize);
}
#[inline]
unsafe extern "C" fn matrix2d_get(
    mut matrix: *mut Matrix2D,
    mut row: size_t,
    mut col: size_t,
) -> uint64_t {
    let mut dim: size_t = (*matrix).dim;
    return *(*matrix).data.offset(row.wrapping_mul(dim).wrapping_add(col) as isize);
}
#[inline]
unsafe extern "C" fn matrix2d_set(
    mut matrix: *mut Matrix2D,
    mut row: size_t,
    mut col: size_t,
    mut value: uint64_t,
) {
    let mut dim: size_t = (*matrix).dim;
    *(*matrix).data.offset(row.wrapping_mul(dim).wrapping_add(col) as isize) = value;
}
#[no_mangle]
pub unsafe extern "C" fn matrix3d_get(
    mut lambda: *mut Matrix3D,
    mut idx: size_t,
) -> *mut Matrix2D {
    return &mut *(*lambda).data.offset(idx as isize) as *mut Matrix2D;
}
#[no_mangle]
pub unsafe extern "C" fn matrix2d_multiply(
    mut m: *mut Matrix2D,
    mut invm: *mut Matrix2D,
    mut result: *mut Matrix2D,
    mut mod_0: uint64_t,
) -> ::core::ffi::c_int {
    let mut dim: size_t = (*m).dim;
    let mut i: size_t = 0 as size_t;
    while i < dim {
        let mut j: size_t = 0 as size_t;
        while j < dim {
            matrix2d_set(result, i, j, 0 as uint64_t);
            let mut k: size_t = 0 as size_t;
            while k < dim {
                matrix2d_set(
                    result,
                    i,
                    j,
                    matrix2d_get(result, i, j)
                        .wrapping_add(
                            matrix2d_get(m, i, k).wrapping_mul(matrix2d_get(invm, k, j)),
                        ),
                );
                k = k.wrapping_add(1);
            }
            matrix2d_set(result, i, j, matrix2d_get(result, i, j).wrapping_rem(mod_0));
            j = j.wrapping_add(1);
        }
        i = i.wrapping_add(1);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn swap_transform(
    mut m: *mut Matrix2D,
    mut invm: *mut Matrix2D,
    mut mod_0: uint64_t,
) -> ::core::ffi::c_int {
    let mut dim: size_t = (*m).dim;
    let mut tmp: uint64_t = 0;
    let vla = dim as usize;
    let mut tmp_row: Vec<uint64_t> = ::std::vec::from_elem(0, vla);
    let mut source: size_t = randrange(
        1 as uint64_t,
        dim.wrapping_sub(1 as size_t) as uint64_t,
    ) as size_t;
    let mut target: size_t = randrange(
        0 as uint64_t,
        source.wrapping_sub(1 as size_t) as uint64_t,
    ) as size_t;
    let mut row: size_t = 0 as size_t;
    while row < dim {
        tmp = matrix2d_get(m, row, source);
        matrix2d_set(m, row, source, matrix2d_get(m, row, target));
        matrix2d_set(m, row, target, tmp);
        row = row.wrapping_add(1);
    }
    memcpy(
        tmp_row.as_mut_ptr() as *mut ::core::ffi::c_void,
        matrix2d_row(invm, source) as *const ::core::ffi::c_void,
        (::core::mem::size_of::<uint64_t>() as size_t).wrapping_mul(dim),
    );
    memcpy(
        matrix2d_row(invm, source) as *mut ::core::ffi::c_void,
        matrix2d_row(invm, target) as *const ::core::ffi::c_void,
        (::core::mem::size_of::<uint64_t>() as size_t).wrapping_mul(dim),
    );
    memcpy(
        matrix2d_row(invm, target) as *mut ::core::ffi::c_void,
        tmp_row.as_mut_ptr() as *const ::core::ffi::c_void,
        (::core::mem::size_of::<uint64_t>() as size_t).wrapping_mul(dim),
    );
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn linear_mix_transform(
    mut m: *mut Matrix2D,
    mut invm: *mut Matrix2D,
    mut mod_0: uint64_t,
) -> ::core::ffi::c_int {
    let mut dim: size_t = (*m).dim;
    let mut scale: size_t = randrange(1 as uint64_t, mod_0.wrapping_sub(1 as uint64_t))
        as size_t;
    let mut source: size_t = randrange(
        1 as uint64_t,
        dim.wrapping_sub(1 as size_t) as uint64_t,
    ) as size_t;
    let mut target: size_t = randrange(
        0 as uint64_t,
        source.wrapping_sub(1 as size_t) as uint64_t,
    ) as size_t;
    let mut row: size_t = 0 as size_t;
    while row < dim {
        matrix2d_set(
            m,
            row,
            target,
            matrix2d_get(m, row, target)
                .wrapping_add(
                    matrix2d_get(m, row, source).wrapping_mul(scale as uint64_t),
                )
                .wrapping_rem(mod_0),
        );
        matrix2d_set(
            invm,
            source,
            row,
            matrix2d_get(invm, source, row)
                .wrapping_add(
                    matrix2d_get(invm, target, row)
                        .wrapping_mul(mod_0.wrapping_sub(scale as uint64_t)),
                )
                .wrapping_rem(mod_0),
        );
        row = row.wrapping_add(1);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn scale_transform(
    mut m: *mut Matrix2D,
    mut invm: *mut Matrix2D,
    mut mod_0: uint64_t,
) -> ::core::ffi::c_int {
    let mut dim: size_t = (*m).dim;
    let mut scale: Pair = randinverse(mod_0);
    let mut idx: size_t = 0 as size_t;
    while idx < dim.wrapping_mul(dim) {
        *(*m).data.offset(idx as isize) = (*(*m).data.offset(idx as isize))
            .wrapping_mul(scale.first)
            .wrapping_rem(mod_0);
        *(*invm).data.offset(idx as isize) = (*(*invm).data.offset(idx as isize))
            .wrapping_mul(scale.second)
            .wrapping_rem(mod_0);
        idx = idx.wrapping_add(1);
    }
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn matrix2d_eye(mut m: *mut Matrix2D) -> ::core::ffi::c_int {
    let mut dim: size_t = (*m).dim;
    memset(
        (*m).data as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        dim.wrapping_mul(dim).wrapping_mul(::core::mem::size_of::<uint64_t>() as size_t),
    );
    let mut row: size_t = 0 as size_t;
    while row < dim {
        matrix2d_set(m, row, row, 1 as uint64_t);
        row = row.wrapping_add(1);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn fill_random_invertible_pairs(
    mut m: *mut Matrix2D,
    mut invm: *mut Matrix2D,
    mut mod_0: uint64_t,
    mut iterations: size_t,
) -> ::core::ffi::c_int {
    let transformers: [Transformer; 3] = [
        Some(
            swap_transform
                as unsafe extern "C" fn(
                    *mut Matrix2D,
                    *mut Matrix2D,
                    uint64_t,
                ) -> ::core::ffi::c_int,
        ),
        Some(
            scale_transform
                as unsafe extern "C" fn(
                    *mut Matrix2D,
                    *mut Matrix2D,
                    uint64_t,
                ) -> ::core::ffi::c_int,
        ),
        Some(
            linear_mix_transform
                as unsafe extern "C" fn(
                    *mut Matrix2D,
                    *mut Matrix2D,
                    uint64_t,
                ) -> ::core::ffi::c_int,
        ),
    ];
    matrix2d_eye(m);
    matrix2d_eye(invm);
    let mut i: size_t = 0 as size_t;
    while i < iterations {
        let mut select: size_t = randrange(
            0 as uint64_t,
            (TRANSFORM_COUNT - 1 as ::core::ffi::c_int) as uint64_t,
        ) as size_t;
        transformers[select as usize]
            .expect("non-null function pointer")(m, invm, mod_0);
        i = i.wrapping_add(1);
    }
    return 0 as ::core::ffi::c_int;
}
