#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn memcmp(
        __s1: *const ::core::ffi::c_void,
        __s2: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> ::core::ffi::c_int;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type __darwin_size_t = usize;
pub type int64_t = i64;
pub type size_t = __darwin_size_t;
pub type uint64_t = u64;
pub type Coeff = int64_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Polynomial {
    pub coeffs: *mut Coeff,
    pub size: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct PolyArray {
    pub polies: *mut Polynomial,
    pub size: size_t,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn poly_free(mut poly: *mut Polynomial) {
    free((*poly).coeffs as *mut ::core::ffi::c_void);
    (*poly).coeffs = 0 as *mut Coeff;
    (*poly).size = 0 as size_t;
}
#[no_mangle]
pub unsafe extern "C" fn get_polynomial(
    mut p: *mut Polynomial,
    mut size: size_t,
) -> ::core::ffi::c_int {
    (*p).size = size;
    (*p).coeffs = malloc(
        (*p).size.wrapping_mul(::core::mem::size_of::<Coeff>() as size_t),
    ) as *mut Coeff;
    if (*p).coeffs.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn get_polyarray(
    mut p: *mut PolyArray,
    mut size: size_t,
) -> ::core::ffi::c_int {
    (*p).size = size;
    (*p).polies = malloc(
        (*p).size.wrapping_mul(::core::mem::size_of::<Polynomial>() as size_t),
    ) as *mut Polynomial;
    if (*p).polies.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn set_polynomial(
    mut p: *mut Polynomial,
    mut coeffs: *mut Coeff,
    mut size: size_t,
) -> ::core::ffi::c_int {
    (*p).size = size;
    (*p).coeffs = coeffs;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn set_zero(mut p: *const Polynomial) -> ::core::ffi::c_int {
    memset(
        (*p).coeffs as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        (*p).size.wrapping_mul(::core::mem::size_of::<Coeff>() as size_t),
    );
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn coef_sum(mut poly: *const Polynomial) -> int64_t {
    if poly.is_null() || (*poly).size == 0 as size_t {
        return 0 as int64_t;
    }
    let mut sum: int64_t = 0 as int64_t;
    let mut i: size_t = 0 as size_t;
    while i < (*poly).size {
        sum += *(*poly).coeffs.offset(i as isize) as int64_t;
        i = i.wrapping_add(1);
    }
    return sum;
}
#[no_mangle]
pub unsafe extern "C" fn poly_degree(mut poly: *const Polynomial) -> uint64_t {
    if (*poly).size == 0 as size_t {
        return 0 as uint64_t;
    }
    let mut i: size_t = 0 as size_t;
    while i < (*poly).size {
        if *(*poly).coeffs.offset(i as isize) != 0 as Coeff {
            return (*poly).size.wrapping_sub(i).wrapping_sub(1 as size_t) as uint64_t;
        }
        i = i.wrapping_add(1);
    }
    return 0 as uint64_t;
}
#[no_mangle]
pub unsafe extern "C" fn poly_fit(
    mut poly: *mut Polynomial,
    mut mod_0: uint64_t,
) -> ::core::ffi::c_int {
    if poly.is_null() || (*poly).size == 0 as size_t {
        return -(1 as ::core::ffi::c_int);
    }
    let mut degree: uint64_t = poly_degree(poly);
    let mut idx: uint64_t = ((*poly).size.wrapping_sub(1 as size_t) as uint64_t)
        .wrapping_sub(degree);
    let mut i: size_t = 0 as size_t;
    while (i as uint64_t).wrapping_add(idx) < (*poly).size as uint64_t {
        *(*poly).coeffs.offset(i as isize) = (*(*poly)
            .coeffs
            .offset((i as uint64_t).wrapping_add(idx) as isize) as uint64_t)
            .wrapping_rem(mod_0) as Coeff;
        i = i.wrapping_add(1);
    }
    (*poly).size = ((*poly).size as uint64_t).wrapping_sub(idx) as size_t as size_t;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn poly_mul(
    mut poly1: *const Polynomial,
    mut poly2: *const Polynomial,
    mut result: *mut Polynomial,
    mut mod_0: uint64_t,
) -> ::core::ffi::c_int {
    set_zero(result);
    let mut deg1: uint64_t = (*poly1).size.wrapping_sub(1 as size_t) as uint64_t;
    let mut deg2: uint64_t = (*poly2).size.wrapping_sub(1 as size_t) as uint64_t;
    let mut res_deg: uint64_t = ((*result).size as uint64_t)
        .wrapping_sub(deg2)
        .wrapping_sub(deg1)
        .wrapping_sub(1 as uint64_t);
    let mut i: size_t = 0 as size_t;
    while i < (*poly1).size {
        let mut j: size_t = 0 as size_t;
        while j < (*poly2).size {
            let ref mut fresh0 = *(*result)
                .coeffs
                .offset(
                    res_deg.wrapping_add(i as uint64_t).wrapping_add(j as uint64_t)
                        as isize,
                );
            *fresh0 = (*fresh0 as uint64_t)
                .wrapping_add(
                    ((*(*poly1).coeffs.offset(i as isize)
                        * *(*poly2).coeffs.offset(j as isize)) as uint64_t)
                        .wrapping_rem(mod_0),
                ) as Coeff as Coeff;
            j = j.wrapping_add(1);
        }
        i = i.wrapping_add(1);
    }
    poly_fit(result, mod_0);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn poly_equal(
    mut poly1: *const Polynomial,
    mut poly2: *const Polynomial,
) -> ::core::ffi::c_int {
    if (*poly1).size != (*poly2).size {
        return 0 as ::core::ffi::c_int;
    }
    return (0 as ::core::ffi::c_int
        == memcmp(
            (*poly1).coeffs as *const ::core::ffi::c_void,
            (*poly2).coeffs as *const ::core::ffi::c_void,
            (*poly1).size.wrapping_mul(::core::mem::size_of::<Coeff>() as size_t),
        )) as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn poly_add(
    mut poly1: *const Polynomial,
    mut poly2: *const Polynomial,
    mut result: *mut Polynomial,
    mut mod_0: uint64_t,
) -> ::core::ffi::c_int {
    if (*poly1).size > (*result).size || (*poly2).size > (*result).size
        || mod_0 == 0 as uint64_t
    {
        return -(1 as ::core::ffi::c_int);
    }
    if (*poly1).size != (*poly2).size {
        let mut size: size_t = (*result).size;
        let mut diff1: size_t = size.wrapping_sub((*poly1).size);
        let mut diff2: size_t = size.wrapping_sub((*poly2).size);
        let mut i: size_t = 0 as size_t;
        while i < size {
            *(*result).coeffs.offset(i as isize) = (((if i >= diff1 {
                *(*poly1).coeffs.offset(i.wrapping_sub(diff1) as isize)
            } else {
                0 as Coeff
            })
                + (if i >= diff2 {
                    *(*poly2).coeffs.offset(i.wrapping_sub(diff2) as isize)
                } else {
                    0 as Coeff
                })) as uint64_t)
                .wrapping_rem(mod_0) as Coeff;
            i = i.wrapping_add(1);
        }
        return 0 as ::core::ffi::c_int;
    }
    let mut i_0: size_t = 0 as size_t;
    while i_0 < (*poly1).size {
        *(*result).coeffs.offset(i_0 as isize) = ((*(*poly1).coeffs.offset(i_0 as isize)
            + *(*poly2).coeffs.offset(i_0 as isize)) as uint64_t)
            .wrapping_rem(mod_0) as Coeff;
        i_0 = i_0.wrapping_add(1);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn poly_sub(
    mut poly1: *const Polynomial,
    mut poly2: *const Polynomial,
    mut result: *mut Polynomial,
    mut mod_0: uint64_t,
) -> ::core::ffi::c_int {
    if (*poly1).size > (*result).size || (*poly2).size > (*result).size
        || mod_0 == 0 as uint64_t
    {
        return -(1 as ::core::ffi::c_int);
    }
    if (*poly1).size != (*poly2).size {
        let mut size: size_t = (*result).size;
        let mut diff1: size_t = size.wrapping_sub((*poly1).size);
        let mut diff2: size_t = size.wrapping_sub((*poly2).size);
        let mut i: size_t = 0 as size_t;
        while i < size {
            *(*result).coeffs.offset(i as isize) = (((if i >= diff1 {
                *(*poly1).coeffs.offset(i.wrapping_sub(diff1) as isize)
            } else {
                0 as Coeff
            })
                - (if i >= diff2 {
                    *(*poly2).coeffs.offset(i.wrapping_sub(diff2) as isize)
                } else {
                    0 as Coeff
                })) as uint64_t)
                .wrapping_rem(mod_0) as Coeff;
            i = i.wrapping_add(1);
        }
        return 0 as ::core::ffi::c_int;
    }
    let mut i_0: size_t = 0 as size_t;
    while i_0 < (*poly1).size {
        *(*result).coeffs.offset(i_0 as isize) = ((*(*poly1).coeffs.offset(i_0 as isize)
            - *(*poly2).coeffs.offset(i_0 as isize)) as uint64_t)
            .wrapping_rem(mod_0) as Coeff;
        i_0 = i_0.wrapping_add(1);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn poly_lshift(
    mut poly1: *const Polynomial,
    mut poly2: *const Polynomial,
    mut result: *mut Polynomial,
    mut mod_0: uint64_t,
) -> ::core::ffi::c_int {
    if *(*poly2).coeffs.offset(0 as ::core::ffi::c_int as isize) != 1 as Coeff {
        return -(1 as ::core::ffi::c_int);
    }
    let mut degree1: uint64_t = poly_degree(poly1);
    let mut degree2: uint64_t = poly_degree(poly2);
    if degree1 < degree2 {
        return -(1 as ::core::ffi::c_int);
    }
    let mut a_d: Coeff = *(*poly1).coeffs.offset(0 as ::core::ffi::c_int as isize);
    let mut i: size_t = 0 as size_t;
    while i < (*poly1).size {
        if i < (*poly2).size {
            let mut res: int64_t = (*(*poly1).coeffs.offset(i as isize)
                - *(*poly2).coeffs.offset(i as isize) * a_d) % mod_0 as int64_t;
            *(*result).coeffs.offset(i as isize) = if res < 0 as int64_t {
                res + mod_0 as int64_t
            } else {
                res
            };
        } else {
            *(*result).coeffs.offset(i as isize) = *(*poly1).coeffs.offset(i as isize);
        }
        i = i.wrapping_add(1);
    }
    poly_fit(result, mod_0);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn poly_mod(
    mut poly1: *mut Polynomial,
    mut poly2: *const Polynomial,
    mut mod_0: uint64_t,
) -> ::core::ffi::c_int {
    while poly_lshift(poly1, poly2, poly1, mod_0) == 0 as ::core::ffi::c_int {}
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn poly_sub_scaler(
    mut poly: *const Polynomial,
    mut scaler: uint64_t,
    mut result: *mut Polynomial,
    mut mod_0: uint64_t,
) -> ::core::ffi::c_int {
    let mut i: size_t = 0 as size_t;
    while i < (*poly).size {
        *(*result).coeffs.offset(i as isize) = (*(*poly).coeffs.offset(i as isize)
            as uint64_t)
            .wrapping_sub(scaler)
            .wrapping_rem(mod_0) as Coeff;
        i = i.wrapping_add(1);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn poly_add_scaler(
    mut poly: *const Polynomial,
    mut scaler: uint64_t,
    mut result: *mut Polynomial,
    mut mod_0: uint64_t,
) -> ::core::ffi::c_int {
    let mut i: size_t = 0 as size_t;
    while i < (*poly).size {
        *(*result).coeffs.offset(i as isize) = (*(*poly).coeffs.offset(i as isize)
            as uint64_t)
            .wrapping_add(scaler)
            .wrapping_rem(mod_0) as Coeff;
        i = i.wrapping_add(1);
    }
    return 0 as ::core::ffi::c_int;
}
