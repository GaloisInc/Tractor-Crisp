#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type ASN1_VALUE_st;
    pub type asn1_object_st;
    pub type ASN1_ITEM_st;
    pub type bignum_st;
    pub type bignum_ctx;
    pub type bn_mont_ctx_st;
    pub type bn_gencb_st;
    pub type evp_md_st;
    pub type evp_md_ctx_st;
    pub type evp_pkey_st;
    pub type rsa_st;
    fn memcmp(
        __s1: *const ::core::ffi::c_void,
        __s2: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> ::core::ffi::c_int;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn CRYPTO_malloc(
        num: size_t,
        file: *const ::core::ffi::c_char,
        line: ::core::ffi::c_int,
    ) -> *mut ::core::ffi::c_void;
    fn CRYPTO_free(
        ptr: *mut ::core::ffi::c_void,
        file: *const ::core::ffi::c_char,
        line: ::core::ffi::c_int,
    );
    fn CRYPTO_clear_free(
        ptr: *mut ::core::ffi::c_void,
        num: size_t,
        file: *const ::core::ffi::c_char,
        line: ::core::ffi::c_int,
    );
    fn OPENSSL_cleanse(ptr: *mut ::core::ffi::c_void, len: size_t);
    fn BN_is_one(a: *const BIGNUM) -> ::core::ffi::c_int;
    fn BN_CTX_new() -> *mut BN_CTX;
    fn BN_CTX_free(c: *mut BN_CTX);
    fn BN_CTX_start(ctx: *mut BN_CTX);
    fn BN_CTX_get(ctx: *mut BN_CTX) -> *mut BIGNUM;
    fn BN_CTX_end(ctx: *mut BN_CTX);
    fn BN_rand_range(rnd: *mut BIGNUM, range: *const BIGNUM) -> ::core::ffi::c_int;
    fn BN_new() -> *mut BIGNUM;
    fn BN_bin2bn(
        s: *const ::core::ffi::c_uchar,
        len: ::core::ffi::c_int,
        ret: *mut BIGNUM,
    ) -> *mut BIGNUM;
    fn BN_bn2binpad(
        a: *const BIGNUM,
        to: *mut ::core::ffi::c_uchar,
        tolen: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn BN_mod_mul(
        r: *mut BIGNUM,
        a: *const BIGNUM,
        b: *const BIGNUM,
        m: *const BIGNUM,
        ctx: *mut BN_CTX,
    ) -> ::core::ffi::c_int;
    fn BN_set_word(a: *mut BIGNUM, w: ::core::ffi::c_ulong) -> ::core::ffi::c_int;
    fn BN_cmp(a: *const BIGNUM, b: *const BIGNUM) -> ::core::ffi::c_int;
    fn BN_free(a: *mut BIGNUM);
    fn BN_mod_exp_mont(
        r: *mut BIGNUM,
        a: *const BIGNUM,
        p: *const BIGNUM,
        m: *const BIGNUM,
        ctx: *mut BN_CTX,
        m_ctx: *mut BN_MONT_CTX,
    ) -> ::core::ffi::c_int;
    fn BN_clear(a: *mut BIGNUM);
    fn BN_gcd(
        r: *mut BIGNUM,
        a: *const BIGNUM,
        b: *const BIGNUM,
        ctx: *mut BN_CTX,
    ) -> ::core::ffi::c_int;
    fn BN_mod_inverse(
        ret: *mut BIGNUM,
        a: *const BIGNUM,
        n: *const BIGNUM,
        ctx: *mut BN_CTX,
    ) -> *mut BIGNUM;
    fn BN_MONT_CTX_new() -> *mut BN_MONT_CTX;
    fn BN_MONT_CTX_free(mont: *mut BN_MONT_CTX);
    fn BN_MONT_CTX_set(
        mont: *mut BN_MONT_CTX,
        mod_0: *const BIGNUM,
        ctx: *mut BN_CTX,
    ) -> ::core::ffi::c_int;
    fn ERR_new();
    fn ERR_set_debug(
        file: *const ::core::ffi::c_char,
        line: ::core::ffi::c_int,
        func: *const ::core::ffi::c_char,
    );
    fn ERR_set_error(
        lib: ::core::ffi::c_int,
        reason: ::core::ffi::c_int,
        fmt: *const ::core::ffi::c_char,
        ...
    );
    fn ASN1_STRING_new() -> *mut ASN1_STRING;
    fn ASN1_STRING_free(a: *mut ASN1_STRING);
    fn ASN1_STRING_length(x: *const ASN1_STRING) -> ::core::ffi::c_int;
    fn ASN1_STRING_get0_data(x: *const ASN1_STRING) -> *const ::core::ffi::c_uchar;
    fn ASN1_item_pack(
        obj: *mut ::core::ffi::c_void,
        it: *const ASN1_ITEM,
        oct: *mut *mut ASN1_OCTET_STRING,
    ) -> *mut ASN1_STRING;
    fn EVP_MD_get_size(md: *const EVP_MD) -> ::core::ffi::c_int;
    fn EVP_MD_CTX_new() -> *mut EVP_MD_CTX;
    fn EVP_MD_CTX_free(ctx: *mut EVP_MD_CTX);
    fn EVP_DigestUpdate(
        ctx: *mut EVP_MD_CTX,
        d: *const ::core::ffi::c_void,
        cnt: size_t,
    ) -> ::core::ffi::c_int;
    fn EVP_DigestFinal_ex(
        ctx: *mut EVP_MD_CTX,
        md: *mut ::core::ffi::c_uchar,
        s: *mut ::core::ffi::c_uint,
    ) -> ::core::ffi::c_int;
    fn EVP_DigestInit(ctx: *mut EVP_MD_CTX, type_0: *const EVP_MD) -> ::core::ffi::c_int;
    fn EVP_sha256() -> *const EVP_MD;
    fn EVP_sha384() -> *const EVP_MD;
    fn EVP_sha512() -> *const EVP_MD;
    fn EVP_PKEY_get_bits(pkey: *const EVP_PKEY) -> ::core::ffi::c_int;
    fn EVP_PKEY_get_size(pkey: *const EVP_PKEY) -> ::core::ffi::c_int;
    fn EVP_PKEY_assign(
        pkey: *mut EVP_PKEY,
        type_0: ::core::ffi::c_int,
        key: *mut ::core::ffi::c_void,
    ) -> ::core::ffi::c_int;
    fn EVP_PKEY_get0_RSA(pkey: *const EVP_PKEY) -> *const rsa_st;
    fn EVP_PKEY_new() -> *mut EVP_PKEY;
    fn EVP_PKEY_free(pkey: *mut EVP_PKEY);
    fn d2i_PublicKey(
        type_0: ::core::ffi::c_int,
        a: *mut *mut EVP_PKEY,
        pp: *mut *const ::core::ffi::c_uchar,
        length: ::core::ffi::c_long,
    ) -> *mut EVP_PKEY;
    fn i2d_PublicKey(
        a: *const EVP_PKEY,
        pp: *mut *mut ::core::ffi::c_uchar,
    ) -> ::core::ffi::c_int;
    fn d2i_PrivateKey(
        type_0: ::core::ffi::c_int,
        a: *mut *mut EVP_PKEY,
        pp: *mut *const ::core::ffi::c_uchar,
        length: ::core::ffi::c_long,
    ) -> *mut EVP_PKEY;
    fn i2d_PrivateKey(
        a: *const EVP_PKEY,
        pp: *mut *mut ::core::ffi::c_uchar,
    ) -> ::core::ffi::c_int;
    fn EVP_PKEY_get_bn_param(
        pkey: *const EVP_PKEY,
        key_name: *const ::core::ffi::c_char,
        bn: *mut *mut BIGNUM,
    ) -> ::core::ffi::c_int;
    fn RAND_bytes(
        buf: *mut ::core::ffi::c_uchar,
        num: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn RSA_new() -> *mut RSA;
    fn RSA_generate_key_ex(
        rsa: *mut RSA,
        bits: ::core::ffi::c_int,
        e: *mut BIGNUM,
        cb: *mut BN_GENCB,
    ) -> ::core::ffi::c_int;
    fn RSA_private_encrypt(
        flen: ::core::ffi::c_int,
        from: *const ::core::ffi::c_uchar,
        to: *mut ::core::ffi::c_uchar,
        rsa: *mut RSA,
        padding: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn RSA_public_decrypt(
        flen: ::core::ffi::c_int,
        from: *const ::core::ffi::c_uchar,
        to: *mut ::core::ffi::c_uchar,
        rsa: *mut RSA,
        padding: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn RSA_free(r: *mut RSA);
    fn RSA_verify_PKCS1_PSS_mgf1(
        rsa: *mut RSA,
        mHash: *const ::core::ffi::c_uchar,
        Hash: *const EVP_MD,
        mgf1Hash: *const EVP_MD,
        EM: *const ::core::ffi::c_uchar,
        sLen: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn RSA_padding_add_PKCS1_PSS_mgf1(
        rsa: *mut RSA,
        EM: *mut ::core::ffi::c_uchar,
        mHash: *const ::core::ffi::c_uchar,
        Hash: *const EVP_MD,
        mgf1Hash: *const EVP_MD,
        sLen: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn SHA256_Init(c: *mut SHA256_CTX) -> ::core::ffi::c_int;
    fn SHA256_Update(
        c: *mut SHA256_CTX,
        data: *const ::core::ffi::c_void,
        len: size_t,
    ) -> ::core::ffi::c_int;
    fn SHA256_Final(
        md: *mut ::core::ffi::c_uchar,
        c: *mut SHA256_CTX,
    ) -> ::core::ffi::c_int;
    fn X509_ALGOR_set_md(alg: *mut X509_ALGOR, md: *const EVP_MD);
    fn X509_ALGOR_free(a: *mut X509_ALGOR);
    fn X509_ALGOR_it() -> *const ASN1_ITEM;
    fn X509_ALGOR_new() -> *mut X509_ALGOR;
}
pub type uint8_t = u8;
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct asn1_string_st {
    pub length: ::core::ffi::c_int,
    pub type_0: ::core::ffi::c_int,
    pub data: *mut ::core::ffi::c_uchar,
    pub flags: ::core::ffi::c_long,
}
pub type ASN1_INTEGER = asn1_string_st;
pub type ASN1_ENUMERATED = asn1_string_st;
pub type ASN1_BIT_STRING = asn1_string_st;
pub type ASN1_OCTET_STRING = asn1_string_st;
pub type ASN1_PRINTABLESTRING = asn1_string_st;
pub type ASN1_T61STRING = asn1_string_st;
pub type ASN1_IA5STRING = asn1_string_st;
pub type ASN1_GENERALSTRING = asn1_string_st;
pub type ASN1_UNIVERSALSTRING = asn1_string_st;
pub type ASN1_BMPSTRING = asn1_string_st;
pub type ASN1_UTCTIME = asn1_string_st;
pub type ASN1_GENERALIZEDTIME = asn1_string_st;
pub type ASN1_VISIBLESTRING = asn1_string_st;
pub type ASN1_UTF8STRING = asn1_string_st;
pub type ASN1_STRING = asn1_string_st;
pub type ASN1_BOOLEAN = ::core::ffi::c_int;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct asn1_type_st {
    pub type_0: ::core::ffi::c_int,
    pub value: C2RustUnnamed,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed {
    pub ptr: *mut ::core::ffi::c_char,
    pub boolean: ASN1_BOOLEAN,
    pub asn1_string: *mut ASN1_STRING,
    pub object: *mut ASN1_OBJECT,
    pub integer: *mut ASN1_INTEGER,
    pub enumerated: *mut ASN1_ENUMERATED,
    pub bit_string: *mut ASN1_BIT_STRING,
    pub octet_string: *mut ASN1_OCTET_STRING,
    pub printablestring: *mut ASN1_PRINTABLESTRING,
    pub t61string: *mut ASN1_T61STRING,
    pub ia5string: *mut ASN1_IA5STRING,
    pub generalstring: *mut ASN1_GENERALSTRING,
    pub bmpstring: *mut ASN1_BMPSTRING,
    pub universalstring: *mut ASN1_UNIVERSALSTRING,
    pub utctime: *mut ASN1_UTCTIME,
    pub generalizedtime: *mut ASN1_GENERALIZEDTIME,
    pub visiblestring: *mut ASN1_VISIBLESTRING,
    pub utf8string: *mut ASN1_UTF8STRING,
    pub set: *mut ASN1_STRING,
    pub sequence: *mut ASN1_STRING,
    pub asn1_value: *mut ASN1_VALUE,
}
pub type ASN1_VALUE = ASN1_VALUE_st;
pub type ASN1_OBJECT = asn1_object_st;
pub type ASN1_TYPE = asn1_type_st;
pub type ASN1_ITEM = ASN1_ITEM_st;
pub type BIGNUM = bignum_st;
pub type BN_CTX = bignum_ctx;
pub type BN_MONT_CTX = bn_mont_ctx_st;
pub type BN_GENCB = bn_gencb_st;
pub type EVP_MD = evp_md_st;
pub type EVP_MD_CTX = evp_md_ctx_st;
pub type EVP_PKEY = evp_pkey_st;
pub type RSA = rsa_st;
pub type X509_ALGOR = X509_algor_st;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct X509_algor_st {
    pub algorithm: *mut ASN1_OBJECT,
    pub parameter: *mut ASN1_TYPE,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct SHA256state_st {
    pub h: [::core::ffi::c_uint; 8],
    pub Nl: ::core::ffi::c_uint,
    pub Nh: ::core::ffi::c_uint,
    pub data: [::core::ffi::c_uint; 16],
    pub num: ::core::ffi::c_uint,
    pub md_len: ::core::ffi::c_uint,
}
pub type SHA256_CTX = SHA256state_st;
pub type BRSAHashFunction = ::core::ffi::c_uint;
pub const BRSA_SHA512: BRSAHashFunction = 2;
pub const BRSA_SHA384: BRSAHashFunction = 1;
pub const BRSA_SHA256: BRSAHashFunction = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSAContext {
    pub evp_md: *const EVP_MD,
    pub salt_len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSABlindMessage {
    pub blind_message: *mut uint8_t,
    pub blind_message_len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSABlindingSecret {
    pub secret: *mut uint8_t,
    pub secret_len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSABlindSignature {
    pub blind_sig: *mut uint8_t,
    pub blind_sig_len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSASignature {
    pub sig: *mut uint8_t,
    pub sig_len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSAPublicKey {
    pub evp_pkey: *mut EVP_PKEY,
    pub mont_ctx: *mut BN_MONT_CTX,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSASecretKey {
    pub evp_pkey: *mut EVP_PKEY,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSASerializedKey {
    pub bytes: *mut uint8_t,
    pub bytes_len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSAMessageRandomizer {
    pub noise: [uint8_t; 32],
}
pub const LONG_MAX: ::core::ffi::c_long = 0x7fffffffffffffff as ::core::ffi::c_long;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const ERR_LIB_NONE: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const NID_rsaEncryption: ::core::ffi::c_int = 6 as ::core::ffi::c_int;
pub const EVP_PKEY_RSA: ::core::ffi::c_int = NID_rsaEncryption;
pub const RSA_3: ::core::ffi::c_long = 0x3 as ::core::ffi::c_long;
pub const RSA_F4: ::core::ffi::c_long = 0x10001 as ::core::ffi::c_long;
pub const RSA_NO_PADDING: ::core::ffi::c_int = 3 as ::core::ffi::c_int;
pub const BRSA_DEFAULT_SALT_LENGTH: size_t = -(1 as ::core::ffi::c_int) as size_t;
pub const MIN_MODULUS_BITS: ::core::ffi::c_int = 2048 as ::core::ffi::c_int;
pub const MAX_MODULUS_BITS: ::core::ffi::c_int = 4096 as ::core::ffi::c_int;
pub const MAX_SERIALIZED_PK_LEN: ::core::ffi::c_int = 1000 as ::core::ffi::c_int;
unsafe extern "C" fn _rsa_bits(mut evp_pkey: *const EVP_PKEY) -> ::core::ffi::c_int {
    return EVP_PKEY_get_bits(evp_pkey);
}
unsafe extern "C" fn _rsa_size(mut evp_pkey: *const EVP_PKEY) -> size_t {
    return EVP_PKEY_get_size(evp_pkey) as size_t;
}
unsafe extern "C" fn _rsa_n(mut evp_pkey: *const EVP_PKEY) -> *mut BIGNUM {
    let mut bn: *mut BIGNUM = 0 as *mut BIGNUM;
    EVP_PKEY_get_bn_param(
        evp_pkey,
        b"n\0" as *const u8 as *const ::core::ffi::c_char,
        &mut bn,
    );
    return bn;
}
unsafe extern "C" fn _rsa_e(mut evp_pkey: *const EVP_PKEY) -> *mut BIGNUM {
    let mut bn: *mut BIGNUM = 0 as *mut BIGNUM;
    EVP_PKEY_get_bn_param(
        evp_pkey,
        b"e\0" as *const u8 as *const ::core::ffi::c_char,
        &mut bn,
    );
    return bn;
}
unsafe extern "C" fn new_mont_domain(mut n: *const BIGNUM) -> *mut BN_MONT_CTX {
    let mut mont_ctx: *mut BN_MONT_CTX = BN_MONT_CTX_new();
    if mont_ctx.is_null() {
        return 0 as *mut BN_MONT_CTX;
    }
    let mut bn_ctx: *mut BN_CTX = BN_CTX_new();
    if bn_ctx.is_null() {
        return 0 as *mut BN_MONT_CTX;
    }
    BN_CTX_start(bn_ctx);
    let ret: ::core::ffi::c_int = BN_MONT_CTX_set(mont_ctx, n, bn_ctx)
        as ::core::ffi::c_int;
    if ret != ERR_LIB_NONE {
        mont_ctx = 0 as *mut BN_MONT_CTX;
    }
    BN_CTX_end(bn_ctx);
    BN_CTX_free(bn_ctx);
    return mont_ctx;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_context_init_default(mut context: *mut BRSAContext) {
    brsa_context_init_custom(context, BRSA_SHA384, BRSA_DEFAULT_SALT_LENGTH);
}
#[no_mangle]
pub unsafe extern "C" fn brsa_context_init_deterministic(mut context: *mut BRSAContext) {
    brsa_context_init_custom(context, BRSA_SHA384, 0 as size_t);
}
#[no_mangle]
pub unsafe extern "C" fn brsa_context_init_custom(
    mut context: *mut BRSAContext,
    mut hash_function: BRSAHashFunction,
    mut salt_len: size_t,
) -> ::core::ffi::c_int {
    let mut evp_md: *const EVP_MD = 0 as *const EVP_MD;
    match hash_function as ::core::ffi::c_uint {
        0 => {
            evp_md = EVP_sha256();
        }
        1 => {
            evp_md = EVP_sha384();
        }
        2 => {
            evp_md = EVP_sha512();
        }
        _ => return -(1 as ::core::ffi::c_int),
    }
    (*context).evp_md = evp_md;
    if salt_len == BRSA_DEFAULT_SALT_LENGTH {
        (*context).salt_len = EVP_MD_get_size(evp_md) as size_t;
    } else {
        (*context).salt_len = salt_len;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_publickey_recover(
    mut pk: *mut BRSAPublicKey,
    mut sk: *const BRSASecretKey,
) -> ::core::ffi::c_int {
    let mut serialized: BRSASerializedKey = {
        let mut init = BRSASerializedKey {
            bytes: 0 as *mut uint8_t,
            bytes_len: 0 as size_t,
        };
        init
    };
    let mut ret: ::core::ffi::c_int = i2d_PublicKey(
        (*sk).evp_pkey,
        &mut serialized.bytes,
    );
    if ret <= 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    serialized.bytes_len = ret as size_t;
    ret = brsa_publickey_import(pk, serialized.bytes, serialized.bytes_len);
    brsa_serializedkey_deinit(&mut serialized);
    return ret;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_keypair_generate(
    mut sk: *mut BRSASecretKey,
    mut pk: *mut BRSAPublicKey,
    mut modulus_bits: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    (*sk).evp_pkey = 0 as *mut EVP_PKEY;
    if !pk.is_null() {
        (*pk).evp_pkey = 0 as *mut EVP_PKEY;
        (*pk).mont_ctx = 0 as *mut BN_MONT_CTX;
    }
    let mut rsa: *mut RSA = RSA_new();
    if rsa.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    let mut e: *mut BIGNUM = BN_new();
    if e.is_null() {
        RSA_free(rsa);
        return -(1 as ::core::ffi::c_int);
    }
    BN_set_word(e, RSA_F4 as ::core::ffi::c_ulong);
    if RSA_generate_key_ex(rsa, modulus_bits, e, 0 as *mut BN_GENCB) != ERR_LIB_NONE {
        RSA_free(rsa);
        BN_free(e);
        return -(1 as ::core::ffi::c_int);
    }
    BN_free(e);
    (*sk).evp_pkey = EVP_PKEY_new();
    if (*sk).evp_pkey.is_null() {
        RSA_free(rsa);
        return -(1 as ::core::ffi::c_int);
    }
    EVP_PKEY_assign((*sk).evp_pkey, EVP_PKEY_RSA, rsa as *mut ::core::ffi::c_void);
    if !pk.is_null() {
        return brsa_publickey_recover(pk, sk);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_secretkey_import(
    mut sk: *mut BRSASecretKey,
    mut der: *const uint8_t,
    der_len: size_t,
) -> ::core::ffi::c_int {
    let mut der_: *const uint8_t = der;
    (*sk).evp_pkey = 0 as *mut EVP_PKEY;
    if der_len > LONG_MAX as size_t {
        return -(1 as ::core::ffi::c_int);
    }
    if d2i_PrivateKey(
            EVP_PKEY_RSA,
            &mut (*sk).evp_pkey,
            &mut der_,
            der_len as ::core::ffi::c_long,
        )
        .is_null()
    {
        return -(1 as ::core::ffi::c_int);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_secretkey_export(
    mut serialized: *mut BRSASerializedKey,
    mut sk: *const BRSASecretKey,
) -> ::core::ffi::c_int {
    (*serialized).bytes = 0 as *mut uint8_t;
    let ret: ::core::ffi::c_int = i2d_PrivateKey(
        (*sk).evp_pkey,
        &mut (*serialized).bytes,
    ) as ::core::ffi::c_int;
    if ret <= 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    (*serialized).bytes_len = ret as size_t;
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn _rsa_parameters_check(
    mut evp_pkey: *const EVP_PKEY,
) -> ::core::ffi::c_int {
    let modulus_bits: ::core::ffi::c_int = _rsa_bits(evp_pkey) as ::core::ffi::c_int;
    if modulus_bits < MIN_MODULUS_BITS {
        ERR_new();
        ERR_set_debug(
            b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            228 as ::core::ffi::c_int,
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"_rsa_parameters_check\0")
                .as_ptr(),
        );
        ERR_set_error(
            4 as ::core::ffi::c_int,
            112 as ::core::ffi::c_int,
            0 as *const ::core::ffi::c_char,
        );
        return -(1 as ::core::ffi::c_int);
    }
    if modulus_bits > MAX_MODULUS_BITS {
        ERR_new();
        ERR_set_debug(
            b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            232 as ::core::ffi::c_int,
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"_rsa_parameters_check\0")
                .as_ptr(),
        );
        ERR_set_error(
            4 as ::core::ffi::c_int,
            105 as ::core::ffi::c_int,
            0 as *const ::core::ffi::c_char,
        );
        return -(1 as ::core::ffi::c_int);
    }
    let mut e3: *mut BIGNUM = BN_new();
    if e3.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    let mut ef4: *mut BIGNUM = BN_new();
    if ef4.is_null() {
        BN_free(e3);
        return -(1 as ::core::ffi::c_int);
    }
    BN_set_word(e3, RSA_3 as ::core::ffi::c_ulong);
    BN_set_word(ef4, RSA_F4 as ::core::ffi::c_ulong);
    let mut ret: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
    let mut e: *mut BIGNUM = _rsa_e(evp_pkey);
    if !e.is_null()
        && (BN_cmp(e, e3) == 0 as ::core::ffi::c_int
            || BN_cmp(e, ef4) == 0 as ::core::ffi::c_int)
    {
        ret = 0 as ::core::ffi::c_int;
    }
    BN_free(e);
    BN_free(ef4);
    BN_free(e3);
    return ret;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_publickey_import(
    mut pk: *mut BRSAPublicKey,
    mut der: *const uint8_t,
    der_len: size_t,
) -> ::core::ffi::c_int {
    let mut der_: *const uint8_t = der;
    (*pk).evp_pkey = 0 as *mut EVP_PKEY;
    (*pk).mont_ctx = 0 as *mut BN_MONT_CTX;
    if der_len > MAX_SERIALIZED_PK_LEN as size_t {
        return -(1 as ::core::ffi::c_int);
    }
    if d2i_PublicKey(
            EVP_PKEY_RSA,
            &mut (*pk).evp_pkey,
            &mut der_,
            der_len as ::core::ffi::c_long,
        )
        .is_null()
    {
        return -(1 as ::core::ffi::c_int);
    }
    (*pk).mont_ctx = 0 as *mut BN_MONT_CTX;
    if (*pk).evp_pkey.is_null() {
        brsa_publickey_deinit(pk);
        return -(1 as ::core::ffi::c_int);
    }
    if _rsa_parameters_check((*pk).evp_pkey) != 0 as ::core::ffi::c_int {
        brsa_publickey_deinit(pk);
        return -(1 as ::core::ffi::c_int);
    }
    let mut n: *mut BIGNUM = _rsa_n((*pk).evp_pkey);
    if n.is_null() {
        brsa_publickey_deinit(pk);
        return -(1 as ::core::ffi::c_int);
    }
    (*pk).mont_ctx = new_mont_domain(n);
    BN_free(n);
    if (*pk).mont_ctx.is_null() {
        brsa_publickey_deinit(pk);
        return -(1 as ::core::ffi::c_int);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_publickey_export(
    mut serialized: *mut BRSASerializedKey,
    mut pk: *const BRSAPublicKey,
) -> ::core::ffi::c_int {
    (*serialized).bytes = 0 as *mut uint8_t;
    (*serialized).bytes_len = 0 as size_t;
    let ret: ::core::ffi::c_int = i2d_PublicKey((*pk).evp_pkey, &mut (*serialized).bytes)
        as ::core::ffi::c_int;
    if ret <= 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    (*serialized).bytes_len = ret as size_t;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_secretkey_deinit(mut sk: *mut BRSASecretKey) {
    EVP_PKEY_free((*sk).evp_pkey);
    (*sk).evp_pkey = 0 as *mut EVP_PKEY;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_publickey_deinit(mut pk: *mut BRSAPublicKey) {
    EVP_PKEY_free((*pk).evp_pkey);
    (*pk).evp_pkey = 0 as *mut EVP_PKEY;
    BN_MONT_CTX_free((*pk).mont_ctx);
    (*pk).mont_ctx = 0 as *mut BN_MONT_CTX;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_serializedkey_deinit(
    mut serialized: *mut BRSASerializedKey,
) {
    CRYPTO_clear_free(
        (*serialized).bytes as *mut ::core::ffi::c_void,
        (*serialized).bytes_len,
        b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
        330 as ::core::ffi::c_int,
    );
    (*serialized).bytes = 0 as *mut uint8_t;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_blind_message_deinit(
    mut blind_message: *mut BRSABlindMessage,
) {
    CRYPTO_clear_free(
        (*blind_message).blind_message as *mut ::core::ffi::c_void,
        (*blind_message).blind_message_len,
        b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
        337 as ::core::ffi::c_int,
    );
    (*blind_message).blind_message = 0 as *mut uint8_t;
}
unsafe extern "C" fn brsa_blind_message_init(
    mut blind_message: *mut BRSABlindMessage,
    mut modulus_bytes: size_t,
) -> ::core::ffi::c_int {
    (*blind_message).blind_message_len = modulus_bytes;
    (*blind_message).blind_message = CRYPTO_malloc(
        (*blind_message).blind_message_len,
        b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
        345 as ::core::ffi::c_int,
    ) as *mut uint8_t;
    if (*blind_message).blind_message.is_null() {
        brsa_blind_message_deinit(blind_message);
        return -(1 as ::core::ffi::c_int);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_blinding_secret_deinit(
    mut secret: *mut BRSABlindingSecret,
) {
    CRYPTO_clear_free(
        (*secret).secret as *mut ::core::ffi::c_void,
        (*secret).secret_len,
        b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
        355 as ::core::ffi::c_int,
    );
    (*secret).secret = 0 as *mut uint8_t;
}
unsafe extern "C" fn brsa_blinding_secret_init(
    mut secret: *mut BRSABlindingSecret,
    mut modulus_bytes: size_t,
) -> ::core::ffi::c_int {
    (*secret).secret_len = modulus_bytes;
    (*secret).secret = CRYPTO_malloc(
        (*secret).secret_len,
        b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
        363 as ::core::ffi::c_int,
    ) as *mut uint8_t;
    if (*secret).secret.is_null() {
        brsa_blinding_secret_deinit(secret);
        return -(1 as ::core::ffi::c_int);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_blind_signature_deinit(
    mut blind_sig: *mut BRSABlindSignature,
) {
    CRYPTO_free(
        (*blind_sig).blind_sig as *mut ::core::ffi::c_void,
        b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
        373 as ::core::ffi::c_int,
    );
    (*blind_sig).blind_sig = 0 as *mut uint8_t;
}
unsafe extern "C" fn brsa_blind_signature_init(
    mut blind_sig: *mut BRSABlindSignature,
    mut blind_sig_len: size_t,
) -> ::core::ffi::c_int {
    (*blind_sig).blind_sig_len = blind_sig_len;
    (*blind_sig).blind_sig = CRYPTO_malloc(
        (*blind_sig).blind_sig_len,
        b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
        381 as ::core::ffi::c_int,
    ) as *mut uint8_t;
    if (*blind_sig).blind_sig.is_null() {
        brsa_blind_signature_deinit(blind_sig);
        return -(1 as ::core::ffi::c_int);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_signature_deinit(mut sig: *mut BRSASignature) {
    CRYPTO_free(
        (*sig).sig as *mut ::core::ffi::c_void,
        b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
        391 as ::core::ffi::c_int,
    );
    (*sig).sig = 0 as *mut uint8_t;
}
unsafe extern "C" fn brsa_signature_init(
    mut sig: *mut BRSASignature,
    mut sig_len: size_t,
) -> ::core::ffi::c_int {
    (*sig).sig_len = sig_len;
    (*sig).sig = CRYPTO_malloc(
        (*sig).sig_len,
        b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
        399 as ::core::ffi::c_int,
    ) as *mut uint8_t;
    if (*sig).sig.is_null() {
        brsa_signature_deinit(sig);
        return -(1 as ::core::ffi::c_int);
    }
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn _hash(
    mut evp_md: *const EVP_MD,
    mut prefix: *const BRSAMessageRandomizer,
    mut msg_hash: *mut uint8_t,
    msg_hash_len: size_t,
    mut msg: *const uint8_t,
    msg_len: size_t,
) -> ::core::ffi::c_int {
    let mut hash_ctx: *mut EVP_MD_CTX = 0 as *mut EVP_MD_CTX;
    if msg_hash_len < EVP_MD_get_size(evp_md) as size_t {
        return -(1 as ::core::ffi::c_int);
    }
    hash_ctx = EVP_MD_CTX_new();
    if hash_ctx.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    let mut ret: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
    if !(EVP_DigestInit(hash_ctx, evp_md) != ERR_LIB_NONE) {
        if !(!prefix.is_null()
            && EVP_DigestUpdate(hash_ctx, msg as *const ::core::ffi::c_void, msg_len)
                != ERR_LIB_NONE)
        {
            if !(EVP_DigestUpdate(hash_ctx, msg as *const ::core::ffi::c_void, msg_len)
                != ERR_LIB_NONE
                || EVP_DigestFinal_ex(
                    hash_ctx,
                    msg_hash as *mut ::core::ffi::c_uchar,
                    0 as *mut ::core::ffi::c_uint,
                ) != ERR_LIB_NONE)
            {
                ret = 0 as ::core::ffi::c_int;
            }
        }
    }
    EVP_MD_CTX_free(hash_ctx);
    return ret;
}
unsafe extern "C" fn _blind(
    mut blind_message: *mut BRSABlindMessage,
    mut secret_: *mut BRSABlindingSecret,
    mut pk: *mut BRSAPublicKey,
    mut bn_ctx: *mut BN_CTX,
    mut padded: *const uint8_t,
    mut padded_len: size_t,
) -> ::core::ffi::c_int {
    let mut m: *mut BIGNUM = BN_CTX_get(bn_ctx);
    if BN_bin2bn(
            padded as *const ::core::ffi::c_uchar,
            padded_len as ::core::ffi::c_int,
            m,
        )
        .is_null()
    {
        return -(1 as ::core::ffi::c_int);
    }
    let mut n: *mut BIGNUM = _rsa_n((*pk).evp_pkey);
    if n.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    let mut gcd: *mut BIGNUM = BN_CTX_get(bn_ctx);
    if gcd.is_null() {
        BN_free(n);
        return -(1 as ::core::ffi::c_int);
    }
    BN_gcd(gcd, m, n, bn_ctx);
    if BN_is_one(gcd) == 0 as ::core::ffi::c_int {
        BN_free(n);
        return -(1 as ::core::ffi::c_int);
    }
    let mut secret_inv: *mut BIGNUM = BN_CTX_get(bn_ctx);
    let mut secret: *mut BIGNUM = BN_CTX_get(bn_ctx);
    if secret_inv.is_null() || secret.is_null() {
        BN_free(n);
        return -(1 as ::core::ffi::c_int);
    }
    loop {
        if BN_rand_range(secret_inv, n) != ERR_LIB_NONE {
            BN_free(n);
            return -(1 as ::core::ffi::c_int);
        }
        if !(BN_is_one(secret_inv) != 0
            || BN_mod_inverse(secret, secret_inv, n, bn_ctx).is_null())
        {
            break;
        }
    }
    let mut x: *mut BIGNUM = BN_CTX_get(bn_ctx);
    let mut blind_m: *mut BIGNUM = BN_CTX_get(bn_ctx);
    if x.is_null() || blind_m.is_null() {
        BN_free(n);
        return -(1 as ::core::ffi::c_int);
    }
    let mut e: *mut BIGNUM = _rsa_e((*pk).evp_pkey);
    if e.is_null() {
        BN_free(n);
        return -(1 as ::core::ffi::c_int);
    }
    if BN_mod_exp_mont(x, secret_inv, e, n, bn_ctx, (*pk).mont_ctx) != ERR_LIB_NONE {
        BN_free(e);
        BN_free(n);
        return -(1 as ::core::ffi::c_int);
    }
    BN_free(e);
    BN_clear(secret_inv);
    if BN_mod_mul(blind_m, m, x, n, bn_ctx) != ERR_LIB_NONE {
        BN_free(n);
        return -(1 as ::core::ffi::c_int);
    }
    BN_free(n);
    let modulus_bytes: size_t = _rsa_size((*pk).evp_pkey) as size_t;
    if brsa_blind_message_init(blind_message, modulus_bytes) != 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    if brsa_blinding_secret_init(secret_, modulus_bytes) != 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    if (BN_bn2binpad(
        blind_m,
        (*blind_message).blind_message as *mut ::core::ffi::c_uchar,
        (*blind_message).blind_message_len as ::core::ffi::c_int,
    ) as size_t == (*blind_message).blind_message_len as ::core::ffi::c_int as size_t)
        as ::core::ffi::c_int != ERR_LIB_NONE
    {
        return -(1 as ::core::ffi::c_int);
    }
    if (BN_bn2binpad(
        secret,
        (*secret_).secret as *mut ::core::ffi::c_uchar,
        (*secret_).secret_len as ::core::ffi::c_int,
    ) as size_t == (*secret_).secret_len as ::core::ffi::c_int as size_t)
        as ::core::ffi::c_int != ERR_LIB_NONE
    {
        return -(1 as ::core::ffi::c_int);
    }
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn _check_canonical(
    mut sk: *const BRSASecretKey,
    mut blind_message: *const BRSABlindMessage,
) -> ::core::ffi::c_int {
    let mut evp_pkey: *const EVP_PKEY = (*sk).evp_pkey;
    let modulus_bytes: size_t = _rsa_size(evp_pkey) as size_t;
    if (*blind_message).blind_message_len != modulus_bytes {
        ERR_new();
        ERR_set_debug(
            b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            528 as ::core::ffi::c_int,
            ::core::mem::transmute::<
                [u8; 17],
                [::core::ffi::c_char; 17],
            >(*b"_check_canonical\0")
                .as_ptr(),
        );
        ERR_set_error(
            4 as ::core::ffi::c_int,
            132 as ::core::ffi::c_int,
            0 as *const ::core::ffi::c_char,
        );
        return -(1 as ::core::ffi::c_int);
    }
    let mut n: *mut BIGNUM = 0 as *mut BIGNUM;
    let mut n_s: *mut ::core::ffi::c_uchar = 0 as *mut ::core::ffi::c_uchar;
    n = _rsa_n(evp_pkey);
    if n.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    n_s = CRYPTO_malloc(
        modulus_bytes,
        b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
        537 as ::core::ffi::c_int,
    ) as *mut ::core::ffi::c_uchar;
    if n_s.is_null() {
        BN_free(n);
        return -(1 as ::core::ffi::c_int);
    }
    if (BN_bn2binpad(n, n_s, modulus_bytes as ::core::ffi::c_int) as size_t
        == modulus_bytes as ::core::ffi::c_int as size_t) as ::core::ffi::c_int
        != ERR_LIB_NONE
    {
        CRYPTO_free(
            n_s as *mut ::core::ffi::c_void,
            b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            542 as ::core::ffi::c_int,
        );
        BN_free(n);
        return -(1 as ::core::ffi::c_int);
    }
    BN_free(n);
    let mut i: size_t = 0;
    i = 0 as size_t;
    while i < modulus_bytes {
        let a: uint8_t = *(*blind_message).blind_message.offset(i as isize);
        let b: uint8_t = *n_s.offset(i as isize);
        if (a as ::core::ffi::c_int) < b as ::core::ffi::c_int {
            break;
        }
        if a as ::core::ffi::c_int > b as ::core::ffi::c_int
            || i.wrapping_add(1 as size_t) == modulus_bytes
        {
            CRYPTO_free(
                n_s as *mut ::core::ffi::c_void,
                b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
                555 as ::core::ffi::c_int,
            );
            ERR_new();
            ERR_set_debug(
                b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
                556 as ::core::ffi::c_int,
                ::core::mem::transmute::<
                    [u8; 17],
                    [::core::ffi::c_char; 17],
                >(*b"_check_canonical\0")
                    .as_ptr(),
            );
            ERR_set_error(
                4 as ::core::ffi::c_int,
                132 as ::core::ffi::c_int,
                0 as *const ::core::ffi::c_char,
            );
            return -(1 as ::core::ffi::c_int);
        }
        i = i.wrapping_add(1);
    }
    CRYPTO_free(
        n_s as *mut ::core::ffi::c_void,
        b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
        560 as ::core::ffi::c_int,
    );
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_blind(
    mut context: *const BRSAContext,
    mut blind_message: *mut BRSABlindMessage,
    mut secret: *mut BRSABlindingSecret,
    mut msg_randomizer: *mut BRSAMessageRandomizer,
    mut pk: *mut BRSAPublicKey,
    mut msg: *const uint8_t,
    mut msg_len: size_t,
) -> ::core::ffi::c_int {
    if _rsa_parameters_check((*pk).evp_pkey) != 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    let modulus_bytes: size_t = _rsa_size((*pk).evp_pkey) as size_t;
    if !msg_randomizer.is_null() {
        if RAND_bytes(
            (*msg_randomizer).noise.as_mut_ptr() as *mut ::core::ffi::c_uchar,
            ::core::mem::size_of::<[uint8_t; 32]>() as ::core::ffi::c_int,
        ) != ERR_LIB_NONE
        {
            return -(1 as ::core::ffi::c_int);
        }
    }
    let mut msg_hash: [uint8_t; 64] = [0; 64];
    if _hash(
        (*context).evp_md,
        msg_randomizer,
        msg_hash.as_mut_ptr(),
        ::core::mem::size_of::<[uint8_t; 64]>() as size_t,
        msg,
        msg_len,
    ) != 0 as ::core::ffi::c_int
    {
        return -(1 as ::core::ffi::c_int);
    }
    let padded_len: size_t = modulus_bytes;
    let mut padded: *mut uint8_t = CRYPTO_malloc(
        padded_len,
        b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
        590 as ::core::ffi::c_int,
    ) as *mut uint8_t;
    if padded.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    let mut evp_md: *const EVP_MD = (*context).evp_md;
    if RSA_padding_add_PKCS1_PSS_mgf1(
        EVP_PKEY_get0_RSA((*pk).evp_pkey) as *mut RSA,
        padded as *mut ::core::ffi::c_uchar,
        msg_hash.as_mut_ptr(),
        evp_md,
        evp_md,
        (*context).salt_len as ::core::ffi::c_int,
    ) != ERR_LIB_NONE
    {
        return -(1 as ::core::ffi::c_int);
    }
    OPENSSL_cleanse(
        msg_hash.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[uint8_t; 64]>() as size_t,
    );
    let mut bn_ctx: *mut BN_CTX = BN_CTX_new();
    if bn_ctx.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    BN_CTX_start(bn_ctx);
    let ret: ::core::ffi::c_int = _blind(
        blind_message,
        secret,
        pk,
        bn_ctx,
        padded,
        padded_len,
    ) as ::core::ffi::c_int;
    BN_CTX_end(bn_ctx);
    BN_CTX_free(bn_ctx);
    CRYPTO_clear_free(
        padded as *mut ::core::ffi::c_void,
        padded_len,
        b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
        614 as ::core::ffi::c_int,
    );
    return ret;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_blind_message_generate(
    mut context: *const BRSAContext,
    mut blind_message: *mut BRSABlindMessage,
    mut msg: *mut uint8_t,
    mut msg_len: size_t,
    mut secret: *mut BRSABlindingSecret,
    mut pk: *mut BRSAPublicKey,
) -> ::core::ffi::c_int {
    if RAND_bytes(msg as *mut ::core::ffi::c_uchar, msg_len as ::core::ffi::c_int)
        != ERR_LIB_NONE
    {
        return -(1 as ::core::ffi::c_int);
    }
    return brsa_blind(
        context,
        blind_message,
        secret,
        0 as *mut BRSAMessageRandomizer,
        pk,
        msg,
        msg_len,
    );
}
#[no_mangle]
pub unsafe extern "C" fn brsa_blind_sign(
    mut context: *const BRSAContext,
    mut blind_sig: *mut BRSABlindSignature,
    mut sk: *mut BRSASecretKey,
    mut blind_message: *const BRSABlindMessage,
) -> ::core::ffi::c_int {
    if _rsa_parameters_check((*sk).evp_pkey) != 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    if _check_canonical(sk, blind_message) != 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    if brsa_blind_signature_init(blind_sig, _rsa_size((*sk).evp_pkey))
        != 0 as ::core::ffi::c_int
    {
        return -(1 as ::core::ffi::c_int);
    }
    if RSA_private_encrypt(
        (*blind_sig).blind_sig_len as ::core::ffi::c_int,
        (*blind_message).blind_message,
        (*blind_sig).blind_sig as *mut ::core::ffi::c_uchar,
        EVP_PKEY_get0_RSA((*sk).evp_pkey) as *mut RSA,
        RSA_NO_PADDING,
    ) < 0 as ::core::ffi::c_int
    {
        brsa_blind_signature_deinit(blind_sig);
        return -(1 as ::core::ffi::c_int);
    }
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn rsassa_pss_verify(
    mut context: *const BRSAContext,
    mut sig: *const BRSASignature,
    mut pk: *mut BRSAPublicKey,
    mut msg_randomizer: *const BRSAMessageRandomizer,
    mut msg: *const uint8_t,
    msg_len: size_t,
) -> ::core::ffi::c_int {
    let modulus_bytes: size_t = _rsa_size((*pk).evp_pkey) as size_t;
    if (*sig).sig_len != modulus_bytes {
        ERR_new();
        ERR_set_debug(
            b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            662 as ::core::ffi::c_int,
            ::core::mem::transmute::<
                [u8; 18],
                [::core::ffi::c_char; 18],
            >(*b"rsassa_pss_verify\0")
                .as_ptr(),
        );
        ERR_set_error(
            4 as ::core::ffi::c_int,
            132 as ::core::ffi::c_int,
            0 as *const ::core::ffi::c_char,
        );
        return -(1 as ::core::ffi::c_int);
    }
    let mut msg_hash: [uint8_t; 64] = [0; 64];
    if _hash(
        (*context).evp_md,
        msg_randomizer,
        msg_hash.as_mut_ptr(),
        ::core::mem::size_of::<[uint8_t; 64]>() as size_t,
        msg,
        msg_len,
    ) != 0 as ::core::ffi::c_int
    {
        return -(1 as ::core::ffi::c_int);
    }
    let em_len: size_t = (*sig).sig_len;
    let mut em: *mut uint8_t = CRYPTO_malloc(
        em_len,
        b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
        672 as ::core::ffi::c_int,
    ) as *mut uint8_t;
    if em.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    if RSA_public_decrypt(
        (*sig).sig_len as ::core::ffi::c_int,
        (*sig).sig,
        em as *mut ::core::ffi::c_uchar,
        EVP_PKEY_get0_RSA((*pk).evp_pkey) as *mut RSA,
        RSA_NO_PADDING,
    ) < 0 as ::core::ffi::c_int
    {
        CRYPTO_free(
            em as *mut ::core::ffi::c_void,
            b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            679 as ::core::ffi::c_int,
        );
        return -(1 as ::core::ffi::c_int);
    }
    let mut evp_md: *const EVP_MD = (*context).evp_md;
    if RSA_verify_PKCS1_PSS_mgf1(
        EVP_PKEY_get0_RSA((*pk).evp_pkey) as *mut RSA,
        msg_hash.as_mut_ptr(),
        evp_md,
        evp_md,
        em,
        (*context).salt_len as ::core::ffi::c_int,
    ) != ERR_LIB_NONE
    {
        CRYPTO_free(
            em as *mut ::core::ffi::c_void,
            b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            686 as ::core::ffi::c_int,
        );
        return -(1 as ::core::ffi::c_int);
    }
    CRYPTO_free(
        em as *mut ::core::ffi::c_void,
        b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
        689 as ::core::ffi::c_int,
    );
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn _finalize(
    mut context: *const BRSAContext,
    mut sig: *mut BRSASignature,
    mut blind_sig: *const BRSABlindSignature,
    mut secret_: *const BRSABlindingSecret,
    mut msg_randomizer: *const BRSAMessageRandomizer,
    mut pk: *mut BRSAPublicKey,
    mut bn_ctx: *mut BN_CTX,
    mut msg: *const uint8_t,
    mut msg_len: size_t,
) -> ::core::ffi::c_int {
    let mut secret: *mut BIGNUM = BN_CTX_get(bn_ctx);
    let mut blind_z: *mut BIGNUM = BN_CTX_get(bn_ctx);
    let mut z: *mut BIGNUM = BN_CTX_get(bn_ctx);
    if secret.is_null() || blind_z.is_null() || z.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    if BN_bin2bn((*secret_).secret, (*secret_).secret_len as ::core::ffi::c_int, secret)
        .is_null()
    {
        return -(1 as ::core::ffi::c_int);
    }
    if BN_bin2bn(
            (*blind_sig).blind_sig,
            (*blind_sig).blind_sig_len as ::core::ffi::c_int,
            blind_z,
        )
        .is_null()
    {
        return -(1 as ::core::ffi::c_int);
    }
    let mut n: *mut BIGNUM = _rsa_n((*pk).evp_pkey);
    if n.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    if BN_mod_mul(z, blind_z, secret, n, bn_ctx) != ERR_LIB_NONE {
        BN_free(n);
        return -(1 as ::core::ffi::c_int);
    }
    BN_free(n);
    if brsa_signature_init(sig, _rsa_size((*pk).evp_pkey)) != 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    if (BN_bn2binpad(
        z,
        (*sig).sig as *mut ::core::ffi::c_uchar,
        (*sig).sig_len as ::core::ffi::c_int,
    ) as size_t == (*sig).sig_len as ::core::ffi::c_int as size_t) as ::core::ffi::c_int
        != ERR_LIB_NONE
    {
        brsa_signature_deinit(sig);
        return -(1 as ::core::ffi::c_int);
    }
    if rsassa_pss_verify(context, sig, pk, msg_randomizer, msg, msg_len)
        != 0 as ::core::ffi::c_int
    {
        brsa_signature_deinit(sig);
        return -(1 as ::core::ffi::c_int);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_finalize(
    mut context: *const BRSAContext,
    mut sig: *mut BRSASignature,
    mut blind_sig: *const BRSABlindSignature,
    mut secret: *const BRSABlindingSecret,
    mut msg_randomizer: *const BRSAMessageRandomizer,
    mut pk: *mut BRSAPublicKey,
    mut msg: *const uint8_t,
    mut msg_len: size_t,
) -> ::core::ffi::c_int {
    if _rsa_parameters_check((*pk).evp_pkey) != 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    let modulus_bytes: size_t = _rsa_size((*pk).evp_pkey) as size_t;
    if (*blind_sig).blind_sig_len != modulus_bytes
        || (*secret).secret_len != modulus_bytes
    {
        ERR_new();
        ERR_set_debug(
            b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            745 as ::core::ffi::c_int,
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"brsa_finalize\0")
                .as_ptr(),
        );
        ERR_set_error(
            4 as ::core::ffi::c_int,
            132 as ::core::ffi::c_int,
            0 as *const ::core::ffi::c_char,
        );
        return -(1 as ::core::ffi::c_int);
    }
    let mut bn_ctx: *mut BN_CTX = BN_CTX_new();
    if bn_ctx.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    BN_CTX_start(bn_ctx);
    let ret: ::core::ffi::c_int = _finalize(
        context,
        sig,
        blind_sig,
        secret,
        msg_randomizer,
        pk,
        bn_ctx,
        msg,
        msg_len,
    ) as ::core::ffi::c_int;
    BN_CTX_end(bn_ctx);
    BN_CTX_free(bn_ctx);
    return ret;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_verify(
    mut context: *const BRSAContext,
    mut sig: *const BRSASignature,
    mut pk: *mut BRSAPublicKey,
    mut msg_randomizer: *const BRSAMessageRandomizer,
    mut msg: *const uint8_t,
    mut msg_len: size_t,
) -> ::core::ffi::c_int {
    return rsassa_pss_verify(context, sig, pk, msg_randomizer, msg, msg_len);
}
static mut rsassa_pss_s_template: [::core::ffi::c_uchar; 72] = [
    SEQ as ::core::ffi::c_uchar,
    (EXT | 2 as ::core::ffi::c_int) as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    SEQ as ::core::ffi::c_uchar,
    61 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    OBJ as ::core::ffi::c_uchar,
    9 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0x2a as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0x86 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0x48 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0x86 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0xf7 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0xd as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0x1 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0x1 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0xa as ::core::ffi::c_int as ::core::ffi::c_uchar,
    SEQ as ::core::ffi::c_uchar,
    48 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    (CON | 0 as ::core::ffi::c_int) as ::core::ffi::c_uchar,
    (2 as ::core::ffi::c_int + 2 as ::core::ffi::c_int + 9 as ::core::ffi::c_int)
        as ::core::ffi::c_uchar,
    SEQ as ::core::ffi::c_uchar,
    (2 as ::core::ffi::c_int + 9 as ::core::ffi::c_int) as ::core::ffi::c_uchar,
    OBJ as ::core::ffi::c_uchar,
    9 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    (CON | 1 as ::core::ffi::c_int) as ::core::ffi::c_uchar,
    (2 as ::core::ffi::c_int + 24 as ::core::ffi::c_int) as ::core::ffi::c_uchar,
    SEQ as ::core::ffi::c_uchar,
    24 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    OBJ as ::core::ffi::c_uchar,
    9 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0x2a as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0x86 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0x48 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0x86 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0xf7 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0xd as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0x1 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0x1 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0x8 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    SEQ as ::core::ffi::c_uchar,
    (2 as ::core::ffi::c_int + 9 as ::core::ffi::c_int) as ::core::ffi::c_uchar,
    OBJ as ::core::ffi::c_uchar,
    9 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    (CON | 2 as ::core::ffi::c_int) as ::core::ffi::c_uchar,
    (2 as ::core::ffi::c_int + 1 as ::core::ffi::c_int) as ::core::ffi::c_uchar,
    INT as ::core::ffi::c_uchar,
    1 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    BIT as ::core::ffi::c_uchar,
    (EXT | 2 as ::core::ffi::c_int) as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
    0 as ::core::ffi::c_int as ::core::ffi::c_uchar,
];
pub const SEQ: ::core::ffi::c_int = 0x30 as ::core::ffi::c_int;
pub const EXT: ::core::ffi::c_int = 0x80 as ::core::ffi::c_int;
pub const CON: ::core::ffi::c_int = 0xa0 as ::core::ffi::c_int;
pub const INT: ::core::ffi::c_int = 0x2 as ::core::ffi::c_int;
pub const BIT: ::core::ffi::c_int = 0x3 as ::core::ffi::c_int;
pub const OBJ: ::core::ffi::c_int = 0x6 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn brsa_publickey_export_spki(
    mut context: *const BRSAContext,
    mut spki: *mut BRSASerializedKey,
    mut pk: *const BRSAPublicKey,
) -> ::core::ffi::c_int {
    (*spki).bytes = 0 as *mut uint8_t;
    (*spki).bytes_len = 0 as size_t;
    let mut spki_raw: BRSASerializedKey = {
        let mut init = BRSASerializedKey {
            bytes: 0 as *mut uint8_t,
            bytes_len: 0 as size_t,
        };
        init
    };
    let mut ret: ::core::ffi::c_int = i2d_PublicKey((*pk).evp_pkey, &mut spki_raw.bytes);
    if ret <= 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    spki_raw.bytes_len = ret as size_t;
    let template_len: size_t = ::core::mem::size_of::<[::core::ffi::c_uchar; 72]>()
        as size_t;
    let container_len: size_t = template_len
        .wrapping_sub(4 as size_t)
        .wrapping_add(spki_raw.bytes_len);
    let mut spki_bytes: *mut ::core::ffi::c_uchar = CRYPTO_malloc(
        template_len.wrapping_add(spki_raw.bytes_len),
        b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
        815 as ::core::ffi::c_int,
    ) as *mut ::core::ffi::c_uchar;
    if spki_bytes.is_null() {
        brsa_serializedkey_deinit(&mut spki_raw);
        return -(1 as ::core::ffi::c_int);
    }
    memcpy(
        spki_bytes as *mut ::core::ffi::c_void,
        rsassa_pss_s_template.as_ptr() as *const ::core::ffi::c_void,
        template_len,
    );
    memcpy(
        &mut *spki_bytes.offset(template_len as isize) as *mut ::core::ffi::c_uchar
            as *mut ::core::ffi::c_void,
        spki_raw.bytes as *const ::core::ffi::c_void,
        spki_raw.bytes_len,
    );
    *spki_bytes.offset(2 as ::core::ffi::c_int as isize) = (container_len
        >> 8 as ::core::ffi::c_int) as ::core::ffi::c_uchar;
    *spki_bytes.offset(3 as ::core::ffi::c_int as isize) = (container_len
        & 0xff as size_t) as ::core::ffi::c_uchar;
    *spki_bytes.offset(66 as ::core::ffi::c_int as isize) = ((*context).salt_len
        & 0xff as size_t) as ::core::ffi::c_uchar;
    *spki_bytes.offset(69 as ::core::ffi::c_int as isize) = ((1 as size_t)
        .wrapping_add(spki_raw.bytes_len) >> 8 as ::core::ffi::c_int)
        as ::core::ffi::c_uchar;
    *spki_bytes.offset(70 as ::core::ffi::c_int as isize) = ((1 as size_t)
        .wrapping_add(spki_raw.bytes_len) & 0xff as size_t) as ::core::ffi::c_uchar;
    brsa_serializedkey_deinit(&mut spki_raw);
    let mut algor_mgf1: *mut X509_ALGOR = X509_ALGOR_new();
    if algor_mgf1.is_null() {
        CRYPTO_free(
            spki_bytes as *mut ::core::ffi::c_void,
            b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            831 as ::core::ffi::c_int,
        );
        return -(1 as ::core::ffi::c_int);
    }
    X509_ALGOR_set_md(algor_mgf1, (*context).evp_md);
    let mut algor_mgf1_s: *mut ASN1_STRING = ASN1_STRING_new();
    if algor_mgf1_s.is_null() {
        CRYPTO_free(
            spki_bytes as *mut ::core::ffi::c_void,
            b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            837 as ::core::ffi::c_int,
        );
        X509_ALGOR_free(algor_mgf1);
        return -(1 as ::core::ffi::c_int);
    }
    ASN1_item_pack(
        algor_mgf1 as *mut ::core::ffi::c_void,
        X509_ALGOR_it(),
        &mut algor_mgf1_s,
    );
    X509_ALGOR_free(algor_mgf1);
    let mut mgf1_s_data: [::core::ffi::c_uchar; 13] = [0; 13];
    let mut alg_data: *const ::core::ffi::c_uchar = ASN1_STRING_get0_data(algor_mgf1_s);
    if ASN1_STRING_length(algor_mgf1_s) as usize
        == ::core::mem::size_of::<[::core::ffi::c_uchar; 13]>() as usize
    {
        memcpy(
            mgf1_s_data.as_mut_ptr() as *mut ::core::ffi::c_void,
            alg_data as *const ::core::ffi::c_void,
            ::core::mem::size_of::<[::core::ffi::c_uchar; 13]>() as size_t,
        );
    } else if ASN1_STRING_length(algor_mgf1_s) as usize
        == (::core::mem::size_of::<[::core::ffi::c_uchar; 13]>() as usize)
            .wrapping_add(2 as usize)
    {
        if *alg_data.offset(1 as ::core::ffi::c_int as isize) as usize
            != ::core::mem::size_of::<[::core::ffi::c_uchar; 13]>() as usize
            || *alg_data.offset(3 as ::core::ffi::c_int as isize) as ::core::ffi::c_int
                != 9 as ::core::ffi::c_int
            || *alg_data
                .offset(::core::mem::size_of::<[::core::ffi::c_uchar; 13]>() as isize)
                as ::core::ffi::c_int != 5 as ::core::ffi::c_int
            || *alg_data
                .offset(
                    (1 as usize)
                        .wrapping_add(
                            ::core::mem::size_of::<[::core::ffi::c_uchar; 13]>() as usize,
                        ) as isize,
                ) as ::core::ffi::c_int != 0 as ::core::ffi::c_int
        {
            CRYPTO_free(
                spki_bytes as *mut ::core::ffi::c_void,
                b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
                851 as ::core::ffi::c_int,
            );
            ASN1_STRING_free(algor_mgf1_s);
            return -(1 as ::core::ffi::c_int);
        }
        memcpy(
            mgf1_s_data.as_mut_ptr() as *mut ::core::ffi::c_void,
            alg_data as *const ::core::ffi::c_void,
            ::core::mem::size_of::<[::core::ffi::c_uchar; 13]>() as size_t,
        );
        mgf1_s_data[1 as ::core::ffi::c_int as usize] = (mgf1_s_data[1
            as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            - 2 as ::core::ffi::c_int) as ::core::ffi::c_uchar;
    } else {
        CRYPTO_free(
            spki_bytes as *mut ::core::ffi::c_void,
            b"src/blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            858 as ::core::ffi::c_int,
        );
        ASN1_STRING_free(algor_mgf1_s);
        return -(1 as ::core::ffi::c_int);
    }
    memcpy(
        &mut *spki_bytes.offset(21 as ::core::ffi::c_int as isize)
            as *mut ::core::ffi::c_uchar as *mut ::core::ffi::c_void,
        mgf1_s_data.as_mut_ptr() as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_uchar; 13]>() as size_t,
    );
    memcpy(
        &mut *spki_bytes.offset(49 as ::core::ffi::c_int as isize)
            as *mut ::core::ffi::c_uchar as *mut ::core::ffi::c_void,
        mgf1_s_data.as_mut_ptr() as *const ::core::ffi::c_void,
        ::core::mem::size_of::<[::core::ffi::c_uchar; 13]>() as size_t,
    );
    ASN1_STRING_free(algor_mgf1_s);
    (*spki).bytes = spki_bytes as *mut uint8_t;
    (*spki).bytes_len = template_len.wrapping_add(spki_raw.bytes_len);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn brsa_publickey_import_spki(
    mut context: *const BRSAContext,
    mut pk: *mut BRSAPublicKey,
    mut spki: *const uint8_t,
    spki_len: size_t,
) -> ::core::ffi::c_int {
    let template_len: size_t = ::core::mem::size_of::<[::core::ffi::c_uchar; 72]>()
        as size_t;
    if spki_len > MAX_SERIALIZED_PK_LEN as size_t || spki_len <= template_len {
        return -(1 as ::core::ffi::c_int);
    }
    if memcmp(
        &*rsassa_pss_s_template.as_ptr().offset(6 as ::core::ffi::c_int as isize)
            as *const ::core::ffi::c_uchar as *const ::core::ffi::c_void,
        &*spki.offset(6 as ::core::ffi::c_int as isize) as *const uint8_t
            as *const ::core::ffi::c_void,
        (18 as ::core::ffi::c_int - 6 as ::core::ffi::c_int) as size_t,
    ) != 0 as ::core::ffi::c_int
    {
        return -(1 as ::core::ffi::c_int);
    }
    let alg_len: size_t = *spki.offset(5 as ::core::ffi::c_int as isize) as size_t;
    if spki_len <= alg_len.wrapping_add(11 as size_t) {
        return -(1 as ::core::ffi::c_int);
    }
    return brsa_publickey_import(
        pk,
        &*spki.offset(alg_len.wrapping_add(11 as size_t) as isize),
        spki_len.wrapping_sub(alg_len).wrapping_sub(11 as size_t),
    );
}
#[no_mangle]
pub unsafe extern "C" fn brsa_publickey_id(
    mut context: *const BRSAContext,
    mut id: *mut uint8_t,
    mut id_len: size_t,
    mut pk: *const BRSAPublicKey,
) -> ::core::ffi::c_int {
    let mut spki: BRSASerializedKey = BRSASerializedKey {
        bytes: 0 as *mut uint8_t,
        bytes_len: 0,
    };
    if brsa_publickey_export_spki(context, &mut spki, pk) != 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    let mut h: [uint8_t; 32] = [0; 32];
    let mut hash_ctx: SHA256_CTX = SHA256state_st {
        h: [0; 8],
        Nl: 0,
        Nh: 0,
        data: [0; 16],
        num: 0,
        md_len: 0,
    };
    if SHA256_Init(&mut hash_ctx) != ERR_LIB_NONE
        || SHA256_Update(
            &mut hash_ctx,
            spki.bytes as *const ::core::ffi::c_void,
            spki.bytes_len,
        ) != ERR_LIB_NONE
        || SHA256_Final(h.as_mut_ptr() as *mut ::core::ffi::c_uchar, &mut hash_ctx)
            != ERR_LIB_NONE
    {
        return -(1 as ::core::ffi::c_int);
    }
    brsa_serializedkey_deinit(&mut spki);
    let mut out_len: size_t = id_len;
    if out_len > ::core::mem::size_of::<[uint8_t; 32]>() as usize {
        out_len = ::core::mem::size_of::<[uint8_t; 32]>() as usize as size_t;
        memset(
            id.offset(out_len as isize) as *mut ::core::ffi::c_void,
            0 as ::core::ffi::c_int,
            id_len.wrapping_sub(out_len),
        );
    }
    memcpy(
        id as *mut ::core::ffi::c_void,
        h.as_mut_ptr() as *const ::core::ffi::c_void,
        out_len,
    );
    return 0 as ::core::ffi::c_int;
}
