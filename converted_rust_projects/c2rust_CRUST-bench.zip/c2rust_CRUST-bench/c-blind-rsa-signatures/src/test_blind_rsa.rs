#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type bn_mont_ctx_st;
    pub type evp_md_st;
    pub type evp_pkey_st;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn memcmp(
        __s1: *const ::core::ffi::c_void,
        __s2: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> ::core::ffi::c_int;
    fn brsa_context_init_default(context: *mut BRSAContext);
    fn brsa_context_init_deterministic(context: *mut BRSAContext);
    fn brsa_context_init_custom(
        context: *mut BRSAContext,
        hash_function: BRSAHashFunction,
        salt_len: size_t,
    ) -> ::core::ffi::c_int;
    fn brsa_keypair_generate(
        sk: *mut BRSASecretKey,
        pk: *mut BRSAPublicKey,
        modulus_bits: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn brsa_secretkey_import(
        sk: *mut BRSASecretKey,
        der: *const uint8_t,
        der_len: size_t,
    ) -> ::core::ffi::c_int;
    fn brsa_secretkey_export(
        serialized: *mut BRSASerializedKey,
        sk: *const BRSASecretKey,
    ) -> ::core::ffi::c_int;
    fn brsa_publickey_import(
        pk: *mut BRSAPublicKey,
        der: *const uint8_t,
        der_len: size_t,
    ) -> ::core::ffi::c_int;
    fn brsa_publickey_export(
        serialized: *mut BRSASerializedKey,
        pk: *const BRSAPublicKey,
    ) -> ::core::ffi::c_int;
    fn brsa_publickey_id(
        context: *const BRSAContext,
        id: *mut uint8_t,
        id_len: size_t,
        pk: *const BRSAPublicKey,
    ) -> ::core::ffi::c_int;
    fn brsa_secretkey_deinit(sk: *mut BRSASecretKey);
    fn brsa_publickey_deinit(pk: *mut BRSAPublicKey);
    fn brsa_serializedkey_deinit(serialized: *mut BRSASerializedKey);
    fn brsa_blind_message_deinit(blind_message: *mut BRSABlindMessage);
    fn brsa_blinding_secret_deinit(secret: *mut BRSABlindingSecret);
    fn brsa_blind_signature_deinit(blind_sig: *mut BRSABlindSignature);
    fn brsa_signature_deinit(blind_sig: *mut BRSASignature);
    fn brsa_blind_message_generate(
        context: *const BRSAContext,
        blind_message: *mut BRSABlindMessage,
        msg: *mut uint8_t,
        msg_len: size_t,
        secret: *mut BRSABlindingSecret,
        pk: *mut BRSAPublicKey,
    ) -> ::core::ffi::c_int;
    fn brsa_blind_sign(
        context: *const BRSAContext,
        blind_sig: *mut BRSABlindSignature,
        sk: *mut BRSASecretKey,
        blind_message: *const BRSABlindMessage,
    ) -> ::core::ffi::c_int;
    fn brsa_finalize(
        context: *const BRSAContext,
        sig: *mut BRSASignature,
        blind_sig: *const BRSABlindSignature,
        secret_: *const BRSABlindingSecret,
        msg_randomizer: *const BRSAMessageRandomizer,
        pk: *mut BRSAPublicKey,
        msg: *const uint8_t,
        msg_len: size_t,
    ) -> ::core::ffi::c_int;
    fn brsa_verify(
        context: *const BRSAContext,
        sig: *const BRSASignature,
        pk: *mut BRSAPublicKey,
        msg_randomizer: *const BRSAMessageRandomizer,
        msg: *const uint8_t,
        msg_len: size_t,
    ) -> ::core::ffi::c_int;
}
pub type uint8_t = u8;
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type BN_MONT_CTX = bn_mont_ctx_st;
pub type EVP_MD = evp_md_st;
pub type EVP_PKEY = evp_pkey_st;
pub type BRSAHashFunction = ::core::ffi::c_uint;
pub const BRSA_SHA512: BRSAHashFunction = 2;
pub const BRSA_SHA384: BRSAHashFunction = 1;
pub const BRSA_SHA256: BRSAHashFunction = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSAContext {
    pub evp_md: *const EVP_MD,
    pub salt_len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSABlindMessage {
    pub blind_message: *mut uint8_t,
    pub blind_message_len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSABlindingSecret {
    pub secret: *mut uint8_t,
    pub secret_len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSABlindSignature {
    pub blind_sig: *mut uint8_t,
    pub blind_sig_len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSASignature {
    pub sig: *mut uint8_t,
    pub sig_len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSAPublicKey {
    pub evp_pkey: *mut EVP_PKEY,
    pub mont_ctx: *mut BN_MONT_CTX,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSASecretKey {
    pub evp_pkey: *mut EVP_PKEY,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSASerializedKey {
    pub bytes: *mut uint8_t,
    pub bytes_len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BRSAMessageRandomizer {
    pub noise: [uint8_t; 32],
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
unsafe extern "C" fn test_default() {
    let mut context: BRSAContext = BRSAContext {
        evp_md: 0 as *const EVP_MD,
        salt_len: 0,
    };
    brsa_context_init_default(&mut context);
    let mut sk: BRSASecretKey = BRSASecretKey {
        evp_pkey: 0 as *mut EVP_PKEY,
    };
    let mut pk: BRSAPublicKey = BRSAPublicKey {
        evp_pkey: 0 as *mut EVP_PKEY,
        mont_ctx: 0 as *mut BN_MONT_CTX,
    };
    if !(brsa_keypair_generate(&mut sk, &mut pk, 2048 as ::core::ffi::c_int)
        == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 13],
                [::core::ffi::c_char; 13],
            >(*b"test_default\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            23 as ::core::ffi::c_int,
            b"brsa_keypair_generate(&sk, &pk, 2048) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut msg_randomizer: *mut BRSAMessageRandomizer = 0 as *mut BRSAMessageRandomizer;
    let mut msg: [uint8_t; 32] = [0; 32];
    let msg_len: size_t = ::core::mem::size_of::<[uint8_t; 32]>() as size_t;
    let mut blind_msg: BRSABlindMessage = BRSABlindMessage {
        blind_message: 0 as *mut uint8_t,
        blind_message_len: 0,
    };
    let mut client_secret: BRSABlindingSecret = BRSABlindingSecret {
        secret: 0 as *mut uint8_t,
        secret_len: 0,
    };
    if !(brsa_blind_message_generate(
        &mut context,
        &mut blind_msg,
        msg.as_mut_ptr(),
        msg_len,
        &mut client_secret,
        &mut pk,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 13],
                [::core::ffi::c_char; 13],
            >(*b"test_default\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            36 as ::core::ffi::c_int,
            b"brsa_blind_message_generate(&context, &blind_msg, msg, msg_len, &client_secret, &pk) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut blind_sig: BRSABlindSignature = BRSABlindSignature {
        blind_sig: 0 as *mut uint8_t,
        blind_sig_len: 0,
    };
    if !(brsa_blind_sign(&mut context, &mut blind_sig, &mut sk, &mut blind_msg)
        == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 13],
                [::core::ffi::c_char; 13],
            >(*b"test_default\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            41 as ::core::ffi::c_int,
            b"brsa_blind_sign(&context, &blind_sig, &sk, &blind_msg) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    brsa_blind_message_deinit(&mut blind_msg);
    let mut sig: BRSASignature = BRSASignature {
        sig: 0 as *mut uint8_t,
        sig_len: 0,
    };
    if !(brsa_finalize(
        &mut context,
        &mut sig,
        &mut blind_sig,
        &mut client_secret,
        msg_randomizer,
        &mut pk,
        msg.as_mut_ptr(),
        msg_len,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 13],
                [::core::ffi::c_char; 13],
            >(*b"test_default\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            53 as ::core::ffi::c_int,
            b"brsa_finalize( &context, &sig, &blind_sig, &client_secret, msg_randomizer, &pk, msg, msg_len) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    brsa_blind_signature_deinit(&mut blind_sig);
    brsa_blinding_secret_deinit(&mut client_secret);
    if !(brsa_verify(
        &mut context,
        &mut sig,
        &mut pk,
        msg_randomizer,
        msg.as_mut_ptr(),
        msg_len,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 13],
                [::core::ffi::c_char; 13],
            >(*b"test_default\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            58 as ::core::ffi::c_int,
            b"brsa_verify(&context, &sig, &pk, msg_randomizer, msg, msg_len) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    brsa_signature_deinit(&mut sig);
    let mut key_id: [uint8_t; 4] = [0; 4];
    if !(brsa_publickey_id(
        &mut context,
        key_id.as_mut_ptr(),
        ::core::mem::size_of::<[uint8_t; 4]>() as size_t,
        &mut pk,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 13],
                [::core::ffi::c_char; 13],
            >(*b"test_default\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            63 as ::core::ffi::c_int,
            b"brsa_publickey_id(&context, key_id, sizeof key_id, &pk) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut sk_der: BRSASerializedKey = BRSASerializedKey {
        bytes: 0 as *mut uint8_t,
        bytes_len: 0,
    };
    let mut pk_der: BRSASerializedKey = BRSASerializedKey {
        bytes: 0 as *mut uint8_t,
        bytes_len: 0,
    };
    if !(brsa_secretkey_export(&mut sk_der, &mut sk) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 13],
                [::core::ffi::c_char; 13],
            >(*b"test_default\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            67 as ::core::ffi::c_int,
            b"brsa_secretkey_export(&sk_der, &sk) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(brsa_publickey_export(&mut pk_der, &mut pk) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 13],
                [::core::ffi::c_char; 13],
            >(*b"test_default\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            68 as ::core::ffi::c_int,
            b"brsa_publickey_export(&pk_der, &pk) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    brsa_secretkey_deinit(&mut sk);
    brsa_publickey_deinit(&mut pk);
    if !(brsa_secretkey_import(&mut sk, sk_der.bytes, sk_der.bytes_len)
        == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 13],
                [::core::ffi::c_char; 13],
            >(*b"test_default\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            75 as ::core::ffi::c_int,
            b"brsa_secretkey_import(&sk, sk_der.bytes, sk_der.bytes_len) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(brsa_publickey_import(&mut pk, pk_der.bytes, pk_der.bytes_len)
        == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 13],
                [::core::ffi::c_char; 13],
            >(*b"test_default\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            76 as ::core::ffi::c_int,
            b"brsa_publickey_import(&pk, pk_der.bytes, pk_der.bytes_len) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    brsa_serializedkey_deinit(&mut sk_der);
    brsa_serializedkey_deinit(&mut pk_der);
    brsa_secretkey_deinit(&mut sk);
    brsa_publickey_deinit(&mut pk);
}
unsafe extern "C" fn test_deterministic() {
    let mut context: BRSAContext = BRSAContext {
        evp_md: 0 as *const EVP_MD,
        salt_len: 0,
    };
    brsa_context_init_deterministic(&mut context);
    let mut sk: BRSASecretKey = BRSASecretKey {
        evp_pkey: 0 as *mut EVP_PKEY,
    };
    let mut pk: BRSAPublicKey = BRSAPublicKey {
        evp_pkey: 0 as *mut EVP_PKEY,
        mont_ctx: 0 as *mut BN_MONT_CTX,
    };
    if !(brsa_keypair_generate(&mut sk, &mut pk, 2048 as ::core::ffi::c_int)
        == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_deterministic\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            94 as ::core::ffi::c_int,
            b"brsa_keypair_generate(&sk, &pk, 2048) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut msg_randomizer: *mut BRSAMessageRandomizer = 0 as *mut BRSAMessageRandomizer;
    let mut msg: [uint8_t; 32] = [0; 32];
    let msg_len: size_t = ::core::mem::size_of::<[uint8_t; 32]>() as size_t;
    let mut blind_msg: BRSABlindMessage = BRSABlindMessage {
        blind_message: 0 as *mut uint8_t,
        blind_message_len: 0,
    };
    let mut client_secret: BRSABlindingSecret = BRSABlindingSecret {
        secret: 0 as *mut uint8_t,
        secret_len: 0,
    };
    if !(brsa_blind_message_generate(
        &mut context,
        &mut blind_msg,
        msg.as_mut_ptr(),
        msg_len,
        &mut client_secret,
        &mut pk,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_deterministic\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            106 as ::core::ffi::c_int,
            b"brsa_blind_message_generate(&context, &blind_msg, msg, msg_len, &client_secret, &pk) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut blind_sig: BRSABlindSignature = BRSABlindSignature {
        blind_sig: 0 as *mut uint8_t,
        blind_sig_len: 0,
    };
    if !(brsa_blind_sign(&mut context, &mut blind_sig, &mut sk, &mut blind_msg)
        == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_deterministic\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            111 as ::core::ffi::c_int,
            b"brsa_blind_sign(&context, &blind_sig, &sk, &blind_msg) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut sig: BRSASignature = BRSASignature {
        sig: 0 as *mut uint8_t,
        sig_len: 0,
    };
    if !(brsa_finalize(
        &mut context,
        &mut sig,
        &mut blind_sig,
        &mut client_secret,
        msg_randomizer,
        &mut pk,
        msg.as_mut_ptr(),
        msg_len,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_deterministic\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            122 as ::core::ffi::c_int,
            b"brsa_finalize( &context, &sig, &blind_sig, &client_secret, msg_randomizer, &pk, msg, msg_len) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    brsa_blinding_secret_deinit(&mut client_secret);
    if !(brsa_verify(
        &mut context,
        &mut sig,
        &mut pk,
        msg_randomizer,
        msg.as_mut_ptr(),
        msg_len,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_deterministic\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            126 as ::core::ffi::c_int,
            b"brsa_verify(&context, &sig, &pk, msg_randomizer, msg, msg_len) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    brsa_signature_deinit(&mut sig);
    let mut blind_sig2: BRSABlindSignature = BRSABlindSignature {
        blind_sig: 0 as *mut uint8_t,
        blind_sig_len: 0,
    };
    if !(brsa_blind_sign(&mut context, &mut blind_sig2, &mut sk, &mut blind_msg)
        == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_deterministic\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            131 as ::core::ffi::c_int,
            b"brsa_blind_sign(&context, &blind_sig2, &sk, &blind_msg) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    brsa_blind_message_deinit(&mut blind_msg);
    brsa_secretkey_deinit(&mut sk);
    brsa_publickey_deinit(&mut pk);
    if !(memcmp(
        blind_sig.blind_sig as *const ::core::ffi::c_void,
        blind_sig2.blind_sig as *const ::core::ffi::c_void,
        blind_sig.blind_sig_len,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_deterministic\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            137 as ::core::ffi::c_int,
            b"memcmp(blind_sig.blind_sig, blind_sig2.blind_sig, blind_sig.blind_sig_len) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    brsa_blind_signature_deinit(&mut blind_sig);
    brsa_blind_signature_deinit(&mut blind_sig2);
}
unsafe extern "C" fn test_custom_parameters() {
    let mut context: BRSAContext = BRSAContext {
        evp_md: 0 as *const EVP_MD,
        salt_len: 0,
    };
    brsa_context_init_custom(&mut context, BRSA_SHA256, 48 as size_t);
    let mut sk: BRSASecretKey = BRSASecretKey {
        evp_pkey: 0 as *mut EVP_PKEY,
    };
    let mut pk: BRSAPublicKey = BRSAPublicKey {
        evp_pkey: 0 as *mut EVP_PKEY,
        mont_ctx: 0 as *mut BN_MONT_CTX,
    };
    if !(brsa_keypair_generate(&mut sk, &mut pk, 2048 as ::core::ffi::c_int)
        == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_custom_parameters\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            151 as ::core::ffi::c_int,
            b"brsa_keypair_generate(&sk, &pk, 2048) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut msg_randomizer: *mut BRSAMessageRandomizer = 0 as *mut BRSAMessageRandomizer;
    let mut msg: [uint8_t; 32] = [0; 32];
    let msg_len: size_t = ::core::mem::size_of::<[uint8_t; 32]>() as size_t;
    let mut blind_msg: BRSABlindMessage = BRSABlindMessage {
        blind_message: 0 as *mut uint8_t,
        blind_message_len: 0,
    };
    let mut client_secret: BRSABlindingSecret = BRSABlindingSecret {
        secret: 0 as *mut uint8_t,
        secret_len: 0,
    };
    if !(brsa_blind_message_generate(
        &mut context,
        &mut blind_msg,
        msg.as_mut_ptr(),
        msg_len,
        &mut client_secret,
        &mut pk,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_custom_parameters\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            161 as ::core::ffi::c_int,
            b"brsa_blind_message_generate(&context, &blind_msg, msg, msg_len, &client_secret, &pk) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut blind_sig: BRSABlindSignature = BRSABlindSignature {
        blind_sig: 0 as *mut uint8_t,
        blind_sig_len: 0,
    };
    if !(brsa_blind_sign(&mut context, &mut blind_sig, &mut sk, &mut blind_msg)
        == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_custom_parameters\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            164 as ::core::ffi::c_int,
            b"brsa_blind_sign(&context, &blind_sig, &sk, &blind_msg) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    brsa_blind_message_deinit(&mut blind_msg);
    let mut sig: BRSASignature = BRSASignature {
        sig: 0 as *mut uint8_t,
        sig_len: 0,
    };
    if !(brsa_finalize(
        &mut context,
        &mut sig,
        &mut blind_sig,
        &mut client_secret,
        msg_randomizer,
        &mut pk,
        msg.as_mut_ptr(),
        msg_len,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_custom_parameters\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            169 as ::core::ffi::c_int,
            b"brsa_finalize( &context, &sig, &blind_sig, &client_secret, msg_randomizer, &pk, msg, msg_len) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    brsa_blind_signature_deinit(&mut blind_sig);
    brsa_blinding_secret_deinit(&mut client_secret);
    if !(brsa_verify(
        &mut context,
        &mut sig,
        &mut pk,
        msg_randomizer,
        msg.as_mut_ptr(),
        msg_len,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_custom_parameters\0")
                .as_ptr(),
            b"test_blind_rsa.c\0" as *const u8 as *const ::core::ffi::c_char,
            173 as ::core::ffi::c_int,
            b"brsa_verify(&context, &sig, &pk, msg_randomizer, msg, msg_len) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    brsa_signature_deinit(&mut sig);
    brsa_secretkey_deinit(&mut sk);
    brsa_publickey_deinit(&mut pk);
}
unsafe fn main_0() -> ::core::ffi::c_int {
    test_default();
    test_deterministic();
    test_custom_parameters();
    printf(b"All tests passed.\n\0" as *const u8 as *const ::core::ffi::c_char);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
