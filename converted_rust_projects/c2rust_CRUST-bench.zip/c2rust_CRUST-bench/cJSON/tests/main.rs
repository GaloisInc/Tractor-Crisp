#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn fread(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
        __nitems: size_t,
        __stream: *mut FILE,
    ) -> ::core::ffi::c_ulong;
    fn fseek(
        _: *mut FILE,
        _: ::core::ffi::c_long,
        _: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn ftell(_: *mut FILE) -> ::core::ffi::c_long;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn cJSON_Parse(value: *const ::core::ffi::c_char) -> *mut cJSON;
    fn cJSON_Print(item: *mut cJSON) -> *mut ::core::ffi::c_char;
    fn cJSON_Delete(c: *mut cJSON);
    fn cJSON_GetErrorPtr() -> *const ::core::ffi::c_char;
    fn cJSON_CreateFalse() -> *mut cJSON;
    fn cJSON_CreateNumber(num: ::core::ffi::c_double) -> *mut cJSON;
    fn cJSON_CreateString(string: *const ::core::ffi::c_char) -> *mut cJSON;
    fn cJSON_CreateArray() -> *mut cJSON;
    fn cJSON_CreateObject() -> *mut cJSON;
    fn cJSON_CreateIntArray(
        numbers: *const ::core::ffi::c_int,
        count: ::core::ffi::c_int,
    ) -> *mut cJSON;
    fn cJSON_CreateStringArray(
        strings: *mut *const ::core::ffi::c_char,
        count: ::core::ffi::c_int,
    ) -> *mut cJSON;
    fn cJSON_AddItemToArray(array: *mut cJSON, item: *mut cJSON);
    fn cJSON_AddItemToObject(
        object: *mut cJSON,
        string: *const ::core::ffi::c_char,
        item: *mut cJSON,
    );
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct cJSON {
    pub next: *mut cJSON,
    pub prev: *mut cJSON,
    pub child: *mut cJSON,
    pub type_0: ::core::ffi::c_int,
    pub valuestring: *mut ::core::ffi::c_char,
    pub valueint: ::core::ffi::c_int,
    pub valuedouble: ::core::ffi::c_double,
    pub string: *mut ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct record {
    pub precision: *const ::core::ffi::c_char,
    pub lat: ::core::ffi::c_double,
    pub lon: ::core::ffi::c_double,
    pub address: *const ::core::ffi::c_char,
    pub city: *const ::core::ffi::c_char,
    pub state: *const ::core::ffi::c_char,
    pub zip: *const ::core::ffi::c_char,
    pub country: *const ::core::ffi::c_char,
}
pub const SEEK_SET: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const SEEK_END: ::core::ffi::c_int = 2 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn doit(mut text: *mut ::core::ffi::c_char) {
    let mut out: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut json: *mut cJSON = 0 as *mut cJSON;
    json = cJSON_Parse(text);
    if json.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"doit\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            34 as ::core::ffi::c_int,
            b"json != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if json.is_null() {
        printf(
            b"Error before: [%s]\n\0" as *const u8 as *const ::core::ffi::c_char,
            cJSON_GetErrorPtr(),
        );
    } else {
        out = cJSON_Print(json);
        cJSON_Delete(json);
        printf(b"%s\n\0" as *const u8 as *const ::core::ffi::c_char, out);
        free(out as *mut ::core::ffi::c_void);
    };
}
#[no_mangle]
pub unsafe extern "C" fn dofile(mut filename: *mut ::core::ffi::c_char) {
    let mut f: *mut FILE = 0 as *mut FILE;
    let mut len: ::core::ffi::c_long = 0;
    let mut data: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    f = fopen(filename, b"rb\0" as *const u8 as *const ::core::ffi::c_char) as *mut FILE;
    fseek(f, 0 as ::core::ffi::c_long, SEEK_END);
    len = ftell(f);
    fseek(f, 0 as ::core::ffi::c_long, SEEK_SET);
    data = malloc((len + 1 as ::core::ffi::c_long) as size_t)
        as *mut ::core::ffi::c_char;
    fread(data as *mut ::core::ffi::c_void, 1 as size_t, len as size_t, f);
    fclose(f);
    doit(data);
    free(data as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn create_objects() {
    let mut root: *mut cJSON = 0 as *mut cJSON;
    let mut fmt: *mut cJSON = 0 as *mut cJSON;
    let mut img: *mut cJSON = 0 as *mut cJSON;
    let mut thm: *mut cJSON = 0 as *mut cJSON;
    let mut fld: *mut cJSON = 0 as *mut cJSON;
    let mut out: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut i: ::core::ffi::c_int = 0;
    let mut strings: [*const ::core::ffi::c_char; 7] = [
        b"Sunday\0" as *const u8 as *const ::core::ffi::c_char,
        b"Monday\0" as *const u8 as *const ::core::ffi::c_char,
        b"Tuesday\0" as *const u8 as *const ::core::ffi::c_char,
        b"Wednesday\0" as *const u8 as *const ::core::ffi::c_char,
        b"Thursday\0" as *const u8 as *const ::core::ffi::c_char,
        b"Friday\0" as *const u8 as *const ::core::ffi::c_char,
        b"Saturday\0" as *const u8 as *const ::core::ffi::c_char,
    ];
    let mut numbers: [[::core::ffi::c_int; 3]; 3] = [
        [0 as ::core::ffi::c_int, -(1 as ::core::ffi::c_int), 0 as ::core::ffi::c_int],
        [1 as ::core::ffi::c_int, 0 as ::core::ffi::c_int, 0 as ::core::ffi::c_int],
        [0 as ::core::ffi::c_int, 0 as ::core::ffi::c_int, 1 as ::core::ffi::c_int],
    ];
    let mut ids: [::core::ffi::c_int; 4] = [
        116 as ::core::ffi::c_int,
        943 as ::core::ffi::c_int,
        234 as ::core::ffi::c_int,
        38793 as ::core::ffi::c_int,
    ];
    let mut fields: [record; 2] = [
        {
            let mut init = record {
                precision: b"zip\0" as *const u8 as *const ::core::ffi::c_char,
                lat: 37.7668f64,
                lon: -1.223959e+2f64,
                address: b"\0" as *const u8 as *const ::core::ffi::c_char,
                city: b"SAN FRANCISCO\0" as *const u8 as *const ::core::ffi::c_char,
                state: b"CA\0" as *const u8 as *const ::core::ffi::c_char,
                zip: b"94107\0" as *const u8 as *const ::core::ffi::c_char,
                country: b"US\0" as *const u8 as *const ::core::ffi::c_char,
            };
            init
        },
        {
            let mut init = record {
                precision: b"zip\0" as *const u8 as *const ::core::ffi::c_char,
                lat: 37.371991f64,
                lon: -1.22026e+2f64,
                address: b"\0" as *const u8 as *const ::core::ffi::c_char,
                city: b"SUNNYVALE\0" as *const u8 as *const ::core::ffi::c_char,
                state: b"CA\0" as *const u8 as *const ::core::ffi::c_char,
                zip: b"94085\0" as *const u8 as *const ::core::ffi::c_char,
                country: b"US\0" as *const u8 as *const ::core::ffi::c_char,
            };
            init
        },
    ];
    root = cJSON_CreateObject();
    cJSON_AddItemToObject(
        root,
        b"name\0" as *const u8 as *const ::core::ffi::c_char,
        cJSON_CreateString(
            b"Jack (\"Bee\") Nimble\0" as *const u8 as *const ::core::ffi::c_char,
        ),
    );
    fmt = cJSON_CreateObject();
    cJSON_AddItemToObject(
        root,
        b"format\0" as *const u8 as *const ::core::ffi::c_char,
        fmt,
    );
    cJSON_AddItemToObject(
        fmt,
        b"type\0" as *const u8 as *const ::core::ffi::c_char,
        cJSON_CreateString(b"rect\0" as *const u8 as *const ::core::ffi::c_char),
    );
    cJSON_AddItemToObject(
        fmt,
        b"width\0" as *const u8 as *const ::core::ffi::c_char,
        cJSON_CreateNumber(1920 as ::core::ffi::c_int as ::core::ffi::c_double),
    );
    cJSON_AddItemToObject(
        fmt,
        b"height\0" as *const u8 as *const ::core::ffi::c_char,
        cJSON_CreateNumber(1080 as ::core::ffi::c_int as ::core::ffi::c_double),
    );
    cJSON_AddItemToObject(
        fmt,
        b"interlace\0" as *const u8 as *const ::core::ffi::c_char,
        cJSON_CreateFalse(),
    );
    cJSON_AddItemToObject(
        fmt,
        b"frame rate\0" as *const u8 as *const ::core::ffi::c_char,
        cJSON_CreateNumber(24 as ::core::ffi::c_int as ::core::ffi::c_double),
    );
    out = cJSON_Print(root);
    cJSON_Delete(root);
    printf(b"%s\n\0" as *const u8 as *const ::core::ffi::c_char, out);
    free(out as *mut ::core::ffi::c_void);
    root = cJSON_CreateStringArray(strings.as_mut_ptr(), 7 as ::core::ffi::c_int);
    out = cJSON_Print(root);
    cJSON_Delete(root);
    printf(b"%s\n\0" as *const u8 as *const ::core::ffi::c_char, out);
    free(out as *mut ::core::ffi::c_void);
    root = cJSON_CreateArray();
    i = 0 as ::core::ffi::c_int;
    while i < 3 as ::core::ffi::c_int {
        cJSON_AddItemToArray(
            root,
            cJSON_CreateIntArray(
                (*numbers.as_mut_ptr().offset(i as isize)).as_mut_ptr(),
                3 as ::core::ffi::c_int,
            ),
        );
        i += 1;
    }
    out = cJSON_Print(root);
    cJSON_Delete(root);
    printf(b"%s\n\0" as *const u8 as *const ::core::ffi::c_char, out);
    free(out as *mut ::core::ffi::c_void);
    root = cJSON_CreateObject();
    img = cJSON_CreateObject();
    cJSON_AddItemToObject(
        root,
        b"Image\0" as *const u8 as *const ::core::ffi::c_char,
        img,
    );
    cJSON_AddItemToObject(
        img,
        b"Width\0" as *const u8 as *const ::core::ffi::c_char,
        cJSON_CreateNumber(800 as ::core::ffi::c_int as ::core::ffi::c_double),
    );
    cJSON_AddItemToObject(
        img,
        b"Height\0" as *const u8 as *const ::core::ffi::c_char,
        cJSON_CreateNumber(600 as ::core::ffi::c_int as ::core::ffi::c_double),
    );
    cJSON_AddItemToObject(
        img,
        b"Title\0" as *const u8 as *const ::core::ffi::c_char,
        cJSON_CreateString(
            b"View from 15th Floor\0" as *const u8 as *const ::core::ffi::c_char,
        ),
    );
    thm = cJSON_CreateObject();
    cJSON_AddItemToObject(
        img,
        b"Thumbnail\0" as *const u8 as *const ::core::ffi::c_char,
        thm,
    );
    cJSON_AddItemToObject(
        thm,
        b"Url\0" as *const u8 as *const ::core::ffi::c_char,
        cJSON_CreateString(
            b"http:/*www.example.com/image/481989943\0" as *const u8
                as *const ::core::ffi::c_char,
        ),
    );
    cJSON_AddItemToObject(
        thm,
        b"Height\0" as *const u8 as *const ::core::ffi::c_char,
        cJSON_CreateNumber(125 as ::core::ffi::c_int as ::core::ffi::c_double),
    );
    cJSON_AddItemToObject(
        thm,
        b"Width\0" as *const u8 as *const ::core::ffi::c_char,
        cJSON_CreateString(b"100\0" as *const u8 as *const ::core::ffi::c_char),
    );
    cJSON_AddItemToObject(
        img,
        b"IDs\0" as *const u8 as *const ::core::ffi::c_char,
        cJSON_CreateIntArray(ids.as_mut_ptr(), 4 as ::core::ffi::c_int),
    );
    out = cJSON_Print(root);
    cJSON_Delete(root);
    printf(b"%s\n\0" as *const u8 as *const ::core::ffi::c_char, out);
    free(out as *mut ::core::ffi::c_void);
    root = cJSON_CreateArray();
    i = 0 as ::core::ffi::c_int;
    while i < 2 as ::core::ffi::c_int {
        fld = cJSON_CreateObject();
        cJSON_AddItemToArray(root, fld);
        cJSON_AddItemToObject(
            fld,
            b"precision\0" as *const u8 as *const ::core::ffi::c_char,
            cJSON_CreateString(fields[i as usize].precision),
        );
        cJSON_AddItemToObject(
            fld,
            b"Latitude\0" as *const u8 as *const ::core::ffi::c_char,
            cJSON_CreateNumber(fields[i as usize].lat),
        );
        cJSON_AddItemToObject(
            fld,
            b"Longitude\0" as *const u8 as *const ::core::ffi::c_char,
            cJSON_CreateNumber(fields[i as usize].lon),
        );
        cJSON_AddItemToObject(
            fld,
            b"Address\0" as *const u8 as *const ::core::ffi::c_char,
            cJSON_CreateString(fields[i as usize].address),
        );
        cJSON_AddItemToObject(
            fld,
            b"City\0" as *const u8 as *const ::core::ffi::c_char,
            cJSON_CreateString(fields[i as usize].city),
        );
        cJSON_AddItemToObject(
            fld,
            b"State\0" as *const u8 as *const ::core::ffi::c_char,
            cJSON_CreateString(fields[i as usize].state),
        );
        cJSON_AddItemToObject(
            fld,
            b"Zip\0" as *const u8 as *const ::core::ffi::c_char,
            cJSON_CreateString(fields[i as usize].zip),
        );
        cJSON_AddItemToObject(
            fld,
            b"Country\0" as *const u8 as *const ::core::ffi::c_char,
            cJSON_CreateString(fields[i as usize].country),
        );
        i += 1;
    }
    out = cJSON_Print(root);
    cJSON_Delete(root);
    printf(b"%s\n\0" as *const u8 as *const ::core::ffi::c_char, out);
    free(out as *mut ::core::ffi::c_void);
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut text1: [::core::ffi::c_char; 153] = ::core::mem::transmute::<
        [u8; 153],
        [::core::ffi::c_char; 153],
    >(
        *b"{\n\"name\": \"Jack (\\\"Bee\\\") Nimble\", \n\"format\": {\"type\":       \"rect\", \n\"width\":      1920, \n\"height\":     1080, \n\"interlace\":  false,\"frame rate\": 24\n}\n}\0",
    );
    let mut text2: [::core::ffi::c_char; 79] = ::core::mem::transmute::<
        [u8; 79],
        [::core::ffi::c_char; 79],
    >(
        *b"[\"Sunday\", \"Monday\", \"Tuesday\", \"Wednesday\", \"Thursday\", \"Friday\", \"Saturday\"]\0",
    );
    let mut text3: [::core::ffi::c_char; 51] = ::core::mem::transmute::<
        [u8; 51],
        [::core::ffi::c_char; 51],
    >(*b"[\n    [0, -1, 0],\n    [1, 0, 0],\n    [0, 0, 1]\n\t]\n\0");
    let mut text4: [::core::ffi::c_char; 247] = ::core::mem::transmute::<
        [u8; 247],
        [::core::ffi::c_char; 247],
    >(
        *b"{\n\t\t\"Image\": {\n\t\t\t\"Width\":  800,\n\t\t\t\"Height\": 600,\n\t\t\t\"Title\":  \"View from 15th Floor\",\n\t\t\t\"Thumbnail\": {\n\t\t\t\t\"Url\":    \"http:/*www.example.com/image/481989943\",\n\t\t\t\t\"Height\": 125,\n\t\t\t\t\"Width\":  \"100\"\n\t\t\t},\n\t\t\t\"IDs\": [116, 943, 234, 38793]\n\t\t}\n\t}\0",
    );
    let mut text5: [::core::ffi::c_char; 399] = ::core::mem::transmute::<
        [u8; 399],
        [::core::ffi::c_char; 399],
    >(
        *b"[\n\t {\n\t \"precision\": \"zip\",\n\t \"Latitude\":  37.7668,\n\t \"Longitude\": -122.3959,\n\t \"Address\":   \"\",\n\t \"City\":      \"SAN FRANCISCO\",\n\t \"State\":     \"CA\",\n\t \"Zip\":       \"94107\",\n\t \"Country\":   \"US\"\n\t },\n\t {\n\t \"precision\": \"zip\",\n\t \"Latitude\":  37.371991,\n\t \"Longitude\": -122.026020,\n\t \"Address\":   \"\",\n\t \"City\":      \"SUNNYVALE\",\n\t \"State\":     \"CA\",\n\t \"Zip\":       \"94085\",\n\t \"Country\":   \"US\"\n\t }\n\t ]\0",
    );
    doit(text1.as_mut_ptr());
    doit(text2.as_mut_ptr());
    doit(text3.as_mut_ptr());
    doit(text4.as_mut_ptr());
    doit(text5.as_mut_ptr());
    create_objects();
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *const ::core::ffi::c_char,
            ) as i32,
        )
    }
}
