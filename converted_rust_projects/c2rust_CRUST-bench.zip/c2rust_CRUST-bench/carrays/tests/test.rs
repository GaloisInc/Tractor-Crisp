#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stdoutp: *mut FILE;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn free(_: *mut ::core::ffi::c_void);
    fn rand() -> ::core::ffi::c_int;
    fn srand(_: ::core::ffi::c_uint);
    fn srand48(_: ::core::ffi::c_long);
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn gca_calc_GCD(a: uint32_t, b: uint32_t) -> uint32_t;
    fn gca_cycle_left(
        _ptr: *mut ::core::ffi::c_void,
        n: size_t,
        es: size_t,
        shift: size_t,
    );
    fn gca_cycle_right(
        _ptr: *mut ::core::ffi::c_void,
        n: size_t,
        es: size_t,
        shift: size_t,
    );
    fn gca_reverse(_ptr: *mut ::core::ffi::c_void, n: size_t, es: size_t);
    fn gca_shuffle(_ptr: *mut ::core::ffi::c_void, n: size_t, es: size_t);
    fn gca_itr_reset(p: *mut size_t, n: size_t) -> *mut size_t;
    fn gca_itr_next(pp: *mut *mut size_t, n: size_t, init: *mut size_t) -> *mut size_t;
    fn gca_bsearch(
        _ptr: *mut ::core::ffi::c_void,
        n: size_t,
        es: size_t,
        searchf: Option<
            unsafe extern "C" fn(
                *const ::core::ffi::c_void,
                *mut ::core::ffi::c_void,
            ) -> ::core::ffi::c_int,
        >,
        arg: *mut ::core::ffi::c_void,
    ) -> *mut ::core::ffi::c_void;
    fn gca_lsearch(
        _ptr: *mut ::core::ffi::c_void,
        n: size_t,
        es: size_t,
        searchf: Option<
            unsafe extern "C" fn(
                *const ::core::ffi::c_void,
                *mut ::core::ffi::c_void,
            ) -> ::core::ffi::c_int,
        >,
        arg: *mut ::core::ffi::c_void,
    ) -> *mut ::core::ffi::c_void;
    fn gca_qpart(
        base: *mut ::core::ffi::c_void,
        nel: size_t,
        es: size_t,
        compar: Option<
            unsafe extern "C" fn(
                *const ::core::ffi::c_void,
                *const ::core::ffi::c_void,
                *mut ::core::ffi::c_void,
            ) -> ::core::ffi::c_int,
        >,
        arg: *mut ::core::ffi::c_void,
    ) -> size_t;
    fn gca_qsort(
        base: *mut ::core::ffi::c_void,
        nel: size_t,
        es: size_t,
        compar: Option<
            unsafe extern "C" fn(
                *const ::core::ffi::c_void,
                *const ::core::ffi::c_void,
                *mut ::core::ffi::c_void,
            ) -> ::core::ffi::c_int,
        >,
        arg: *mut ::core::ffi::c_void,
    );
    fn gca_qselect(
        base: *mut ::core::ffi::c_void,
        nel: size_t,
        es: size_t,
        kidx: size_t,
        compar: Option<
            unsafe extern "C" fn(
                *const ::core::ffi::c_void,
                *const ::core::ffi::c_void,
                *mut ::core::ffi::c_void,
            ) -> ::core::ffi::c_int,
        >,
        arg: *mut ::core::ffi::c_void,
    ) -> *mut ::core::ffi::c_void;
    fn gca_heap_make(
        base: *mut ::core::ffi::c_void,
        nel: size_t,
        es: size_t,
        compar: Option<
            unsafe extern "C" fn(
                *const ::core::ffi::c_void,
                *const ::core::ffi::c_void,
                *mut ::core::ffi::c_void,
            ) -> ::core::ffi::c_int,
        >,
        arg: *mut ::core::ffi::c_void,
    );
    fn gca_heap_sort(
        heap: *mut ::core::ffi::c_void,
        nel: size_t,
        es: size_t,
        compar: Option<
            unsafe extern "C" fn(
                *const ::core::ffi::c_void,
                *const ::core::ffi::c_void,
                *mut ::core::ffi::c_void,
            ) -> ::core::ffi::c_int,
        >,
        arg: *mut ::core::ffi::c_void,
    );
    fn gca_median5(
        p0: *mut ::core::ffi::c_void,
        p1: *mut ::core::ffi::c_void,
        p2: *mut ::core::ffi::c_void,
        p3: *mut ::core::ffi::c_void,
        p4: *mut ::core::ffi::c_void,
        compar: Option<
            unsafe extern "C" fn(
                *const ::core::ffi::c_void,
                *const ::core::ffi::c_void,
                *mut ::core::ffi::c_void,
            ) -> ::core::ffi::c_int,
        >,
        arg: *mut ::core::ffi::c_void,
    ) -> *mut ::core::ffi::c_void;
    fn gettimeofday(_: *mut timeval, _: *mut ::core::ffi::c_void) -> ::core::ffi::c_int;
    fn getpid() -> pid_t;
}
pub type __int32_t = i32;
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_time_t = ::core::ffi::c_long;
pub type __darwin_off_t = __int64_t;
pub type __darwin_pid_t = __int32_t;
pub type __darwin_suseconds_t = __int32_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type pid_t = __darwin_pid_t;
pub type uint32_t = u32;
pub type uint64_t = u64;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct timeval {
    pub tv_sec: __darwin_time_t,
    pub tv_usec: __darwin_suseconds_t,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
#[inline]
unsafe extern "C" fn gca_roundup32(mut x: uint32_t) -> uint32_t {
    x = x.wrapping_sub(1);
    x |= x >> 1 as ::core::ffi::c_int;
    x |= x >> 2 as ::core::ffi::c_int;
    x |= x >> 4 as ::core::ffi::c_int;
    x |= x >> 8 as ::core::ffi::c_int;
    x |= x >> 16 as ::core::ffi::c_int;
    x = x.wrapping_add(1);
    return x;
}
#[inline]
unsafe extern "C" fn gca_roundup64(mut x: uint64_t) -> uint64_t {
    x = x.wrapping_sub(1);
    x |= x >> 1 as ::core::ffi::c_int;
    x |= x >> 2 as ::core::ffi::c_int;
    x |= x >> 4 as ::core::ffi::c_int;
    x |= x >> 8 as ::core::ffi::c_int;
    x |= x >> 16 as ::core::ffi::c_int;
    x |= x >> 32 as ::core::ffi::c_int;
    x = x.wrapping_add(1);
    return x;
}
#[inline]
unsafe extern "C" fn gca_cmp2_int(
    mut aa: *const ::core::ffi::c_void,
    mut bb: *const ::core::ffi::c_void,
    mut p: *mut ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    let a: ::core::ffi::c_int = *(aa as *const ::core::ffi::c_int);
    let b: ::core::ffi::c_int = *(bb as *const ::core::ffi::c_int);
    return (a > b) as ::core::ffi::c_int - (b > a) as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn gca_cmp2_size(
    mut aa: *const ::core::ffi::c_void,
    mut bb: *const ::core::ffi::c_void,
    mut p: *mut ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    let a: size_t = *(aa as *const size_t);
    let b: size_t = *(bb as *const size_t);
    return (a > b) as ::core::ffi::c_int - (b > a) as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn gca_search_int(
    mut aa: *const ::core::ffi::c_void,
    mut bb: *mut ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    let a: ::core::ffi::c_int = *(aa as *const ::core::ffi::c_int);
    let b: ::core::ffi::c_int = *(bb as *mut ::core::ffi::c_int);
    return (a > b) as ::core::ffi::c_int - (b > a) as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn gca_swapm(
    mut aa: *mut ::core::ffi::c_void,
    mut bb: *mut ::core::ffi::c_void,
    mut es: size_t,
) {
    let mut end: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut a: *mut ::core::ffi::c_char = aa as *mut ::core::ffi::c_char;
    let mut b: *mut ::core::ffi::c_char = bb as *mut ::core::ffi::c_char;
    let mut tmp: ::core::ffi::c_char = 0;
    end = a.offset(es as isize);
    while a < end {
        tmp = *a;
        *a = *b;
        *b = tmp;
        a = a.offset(1);
        b = b.offset(1);
    }
}
#[inline]
unsafe extern "C" fn gca_is_sorted(
    mut base: *mut ::core::ffi::c_void,
    mut nel: size_t,
    mut es: size_t,
    mut compar: Option<
        unsafe extern "C" fn(
            *const ::core::ffi::c_void,
            *const ::core::ffi::c_void,
            *mut ::core::ffi::c_void,
        ) -> ::core::ffi::c_int,
    >,
    mut arg: *mut ::core::ffi::c_void,
) -> bool {
    let mut b: *mut ::core::ffi::c_char = base as *mut ::core::ffi::c_char;
    let mut end: *mut ::core::ffi::c_char = b.offset(es.wrapping_mul(nel) as isize);
    let mut ptr: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    ptr = b;
    while ptr.offset(es as isize) < end {
        if compar
            .expect(
                "non-null function pointer",
            )(
            ptr as *const ::core::ffi::c_void,
            ptr.offset(es as isize) as *const ::core::ffi::c_void,
            arg,
        ) > 0 as ::core::ffi::c_int
        {
            return false_0 != 0;
        }
        ptr = ptr.offset(es as isize);
    }
    return true_0 != 0;
}
#[inline]
unsafe extern "C" fn gca_max(
    mut base: *mut ::core::ffi::c_void,
    mut nel: size_t,
    mut es: size_t,
    mut compar: Option<
        unsafe extern "C" fn(
            *const ::core::ffi::c_void,
            *const ::core::ffi::c_void,
            *mut ::core::ffi::c_void,
        ) -> ::core::ffi::c_int,
    >,
    mut arg: *mut ::core::ffi::c_void,
) -> *mut ::core::ffi::c_void {
    let mut b: *mut ::core::ffi::c_char = base as *mut ::core::ffi::c_char;
    let mut end: *mut ::core::ffi::c_char = b.offset(es.wrapping_mul(nel) as isize);
    let mut ptr: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut max: *mut ::core::ffi::c_char = base as *mut ::core::ffi::c_char;
    ptr = b.offset(es as isize);
    while ptr < end {
        if compar
            .expect(
                "non-null function pointer",
            )(max as *const ::core::ffi::c_void, ptr as *const ::core::ffi::c_void, arg)
            < 0 as ::core::ffi::c_int
        {
            max = ptr;
        }
        ptr = ptr.offset(es as isize);
    }
    return max as *mut ::core::ffi::c_void;
}
#[no_mangle]
pub static mut num_tests_run: size_t = 0 as size_t;
#[no_mangle]
pub static mut num_tests_failed: size_t = 0 as size_t;
#[no_mangle]
pub unsafe extern "C" fn test_round() {
    fprintf(
        __stdoutp,
        b"[%s:%i] Testing roundup32() / roundup64()\n\0" as *const u8
            as *const ::core::ffi::c_char,
        b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
        43 as ::core::ffi::c_int,
    );
    let mut i: uint64_t = 0;
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_roundup32(0 as uint32_t) == 0 as uint32_t
        && gca_roundup64(0 as uint64_t) == 0 as uint64_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            47 as ::core::ffi::c_int,
            b"gca_roundup32(0) == 0 && gca_roundup64(0) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_roundup32(1 as uint32_t) == 1 as uint32_t
        && gca_roundup64(1 as uint64_t) == 1 as uint64_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            48 as ::core::ffi::c_int,
            b"gca_roundup32(1) == 1 && gca_roundup64(1) == 1\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_roundup32(2 as uint32_t) == 2 as uint32_t
        && gca_roundup64(2 as uint64_t) == 2 as uint64_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            49 as ::core::ffi::c_int,
            b"gca_roundup32(2) == 2 && gca_roundup64(2) == 2\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_roundup32(3 as uint32_t) == 4 as uint32_t
        && gca_roundup64(3 as uint64_t) == 4 as uint64_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            50 as ::core::ffi::c_int,
            b"gca_roundup32(3) == 4 && gca_roundup64(3) == 4\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_roundup32(4 as uint32_t) == 4 as uint32_t
        && gca_roundup64(4 as uint64_t) == 4 as uint64_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            51 as ::core::ffi::c_int,
            b"gca_roundup32(4) == 4 && gca_roundup64(4) == 4\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_roundup32(5 as uint32_t) == 8 as uint32_t
        && gca_roundup64(5 as uint64_t) == 8 as uint64_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            52 as ::core::ffi::c_int,
            b"gca_roundup32(5) == 8 && gca_roundup64(5) == 8\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_roundup32(6 as uint32_t) == 8 as uint32_t
        && gca_roundup64(6 as uint64_t) == 8 as uint64_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            53 as ::core::ffi::c_int,
            b"gca_roundup32(6) == 8 && gca_roundup64(6) == 8\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_roundup32(7 as uint32_t) == 8 as uint32_t
        && gca_roundup64(7 as uint64_t) == 8 as uint64_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            54 as ::core::ffi::c_int,
            b"gca_roundup32(7) == 8 && gca_roundup64(7) == 8\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_roundup32(8 as uint32_t) == 8 as uint32_t
        && gca_roundup64(8 as uint64_t) == 8 as uint64_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            55 as ::core::ffi::c_int,
            b"gca_roundup32(8) == 8 && gca_roundup64(8) == 8\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_roundup32(100 as uint32_t) == 128 as uint32_t
        && gca_roundup64(100 as uint64_t) == 128 as uint64_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            56 as ::core::ffi::c_int,
            b"gca_roundup32(100) == 128 && gca_roundup64(100) == 128\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    i = 2 as uint64_t;
    while i < 32 as uint64_t {
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(gca_roundup32(((1 as uint32_t) << i).wrapping_sub(1 as uint32_t))
            == (1 as uint32_t) << i)
        {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                59 as ::core::ffi::c_int,
                b"gca_roundup32((1U<<i)-1) == (1U<<i)\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        }
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(gca_roundup32((1 as uint32_t) << i) == (1 as uint32_t) << i) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                60 as ::core::ffi::c_int,
                b"gca_roundup32(1U<<i) == (1U<<i)\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        }
        i = i.wrapping_add(1);
    }
    i = 2 as uint64_t;
    while i < 64 as uint64_t {
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(gca_roundup64(
            ((1 as ::core::ffi::c_ulong) << i).wrapping_sub(1 as ::core::ffi::c_ulong)
                as uint64_t,
        ) == ((1 as ::core::ffi::c_ulong) << i) as uint64_t)
        {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                64 as ::core::ffi::c_int,
                b"gca_roundup64((1UL<<i)-1) == (1UL<<i)\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        }
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(gca_roundup64(((1 as ::core::ffi::c_ulong) << i) as uint64_t)
            == ((1 as ::core::ffi::c_ulong) << i) as uint64_t)
        {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                65 as ::core::ffi::c_int,
                b"gca_roundup64(1UL<<i) == (1UL<<i)\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        }
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn test_GCD() {
    fprintf(
        __stdoutp,
        b"[%s:%i] Testing calculating GCD...\n\0" as *const u8
            as *const ::core::ffi::c_char,
        b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
        71 as ::core::ffi::c_int,
    );
    let mut i: size_t = 0;
    i = 0 as size_t;
    while i < 100 as size_t {
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(gca_calc_GCD(i as uint32_t, i as uint32_t) as size_t == i) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                75 as ::core::ffi::c_int,
                b"gca_calc_GCD(i,i) == i\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(gca_calc_GCD(i as uint32_t, 0 as uint32_t) as size_t == i) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                76 as ::core::ffi::c_int,
                b"gca_calc_GCD(i,0) == i\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(gca_calc_GCD(0 as uint32_t, i as uint32_t) as size_t == i) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                77 as ::core::ffi::c_int,
                b"gca_calc_GCD(0,i) == i\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(gca_calc_GCD(i as uint32_t, 1 as uint32_t) == 1 as uint32_t) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                78 as ::core::ffi::c_int,
                b"gca_calc_GCD(i,1) == 1\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(gca_calc_GCD(1 as uint32_t, i as uint32_t) == 1 as uint32_t) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                79 as ::core::ffi::c_int,
                b"gca_calc_GCD(1,i) == 1\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = i.wrapping_add(1);
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(2 as uint32_t, 4 as uint32_t) == 2 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            82 as ::core::ffi::c_int,
            b"gca_calc_GCD(2,4) == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(4 as uint32_t, 2 as uint32_t) == 2 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            83 as ::core::ffi::c_int,
            b"gca_calc_GCD(4,2) == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(6 as uint32_t, 9 as uint32_t) == 3 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            84 as ::core::ffi::c_int,
            b"gca_calc_GCD(6,9) == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(9 as uint32_t, 6 as uint32_t) == 3 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            85 as ::core::ffi::c_int,
            b"gca_calc_GCD(9,6) == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(0 as uint32_t, 0 as uint32_t) == 0 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            86 as ::core::ffi::c_int,
            b"gca_calc_GCD(0,0) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(10 as uint32_t, 0 as uint32_t) == 10 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            87 as ::core::ffi::c_int,
            b"gca_calc_GCD(10,0) == 10\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(0 as uint32_t, 10 as uint32_t) == 10 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            88 as ::core::ffi::c_int,
            b"gca_calc_GCD(0,10) == 10\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(2 as uint32_t, 2 as uint32_t) == 2 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            89 as ::core::ffi::c_int,
            b"gca_calc_GCD(2,2) == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(1 as uint32_t, 1 as uint32_t) == 1 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            90 as ::core::ffi::c_int,
            b"gca_calc_GCD(1,1) == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(1 as uint32_t, 2 as uint32_t) == 1 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            91 as ::core::ffi::c_int,
            b"gca_calc_GCD(1,2) == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(1 as uint32_t, 100 as uint32_t) == 1 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            92 as ::core::ffi::c_int,
            b"gca_calc_GCD(1,100) == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(2 as uint32_t, 4 as uint32_t) == 2 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            93 as ::core::ffi::c_int,
            b"gca_calc_GCD(2,4) == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(7 as uint32_t, 5 as uint32_t) == 1 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            94 as ::core::ffi::c_int,
            b"gca_calc_GCD(7,5) == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(18 as uint32_t, 6 as uint32_t) == 6 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            95 as ::core::ffi::c_int,
            b"gca_calc_GCD(18,6) == 6\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(3 as uint32_t, 6 as uint32_t) == 3 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            96 as ::core::ffi::c_int,
            b"gca_calc_GCD(3,6) == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(100 as uint32_t, 120 as uint32_t) == 20 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            97 as ::core::ffi::c_int,
            b"gca_calc_GCD(100,120) == 20\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_calc_GCD(100 as uint32_t, 125 as uint32_t) == 25 as uint32_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            98 as ::core::ffi::c_int,
            b"gca_calc_GCD(100,125) == 25\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
}
#[no_mangle]
pub unsafe extern "C" fn _test_cycle(mut arr: *mut size_t, mut n: size_t) {
    let mut shift: size_t = 0;
    let mut i: size_t = 0;
    i = 0 as size_t;
    while i < n {
        *arr.offset(i as isize) = i;
        i = i.wrapping_add(1);
    }
    gca_cycle_left(
        arr as *mut ::core::ffi::c_void,
        n,
        ::core::mem::size_of::<size_t>() as size_t,
        0 as size_t,
    );
    i = 0 as size_t;
    while i < n {
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(*arr.offset(i as isize) == i) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                110 as ::core::ffi::c_int,
                b"arr[i] == i\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = i.wrapping_add(1);
    }
    gca_cycle_left(
        arr as *mut ::core::ffi::c_void,
        n,
        ::core::mem::size_of::<size_t>() as size_t,
        n,
    );
    i = 0 as size_t;
    while i < n {
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(*arr.offset(i as isize) == i) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                112 as ::core::ffi::c_int,
                b"arr[i] == i\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = i.wrapping_add(1);
    }
    gca_cycle_left(
        arr as *mut ::core::ffi::c_void,
        n,
        ::core::mem::size_of::<size_t>() as size_t,
        (2 as size_t).wrapping_mul(n),
    );
    i = 0 as size_t;
    while i < n {
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(*arr.offset(i as isize) == i) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                114 as ::core::ffi::c_int,
                b"arr[i] == i\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = i.wrapping_add(1);
    }
    gca_cycle_left(
        arr as *mut ::core::ffi::c_void,
        n,
        ::core::mem::size_of::<size_t>() as size_t,
        (3 as size_t).wrapping_mul(n),
    );
    i = 0 as size_t;
    while i < n {
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(*arr.offset(i as isize) == i) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                116 as ::core::ffi::c_int,
                b"arr[i] == i\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = i.wrapping_add(1);
    }
    gca_cycle_right(
        arr as *mut ::core::ffi::c_void,
        n,
        ::core::mem::size_of::<size_t>() as size_t,
        0 as size_t,
    );
    i = 0 as size_t;
    while i < n {
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(*arr.offset(i as isize) == i) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                120 as ::core::ffi::c_int,
                b"arr[i] == i\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = i.wrapping_add(1);
    }
    gca_cycle_right(
        arr as *mut ::core::ffi::c_void,
        n,
        ::core::mem::size_of::<size_t>() as size_t,
        n,
    );
    i = 0 as size_t;
    while i < n {
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(*arr.offset(i as isize) == i) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                122 as ::core::ffi::c_int,
                b"arr[i] == i\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = i.wrapping_add(1);
    }
    gca_cycle_right(
        arr as *mut ::core::ffi::c_void,
        n,
        ::core::mem::size_of::<size_t>() as size_t,
        (2 as size_t).wrapping_mul(n),
    );
    i = 0 as size_t;
    while i < n {
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(*arr.offset(i as isize) == i) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                124 as ::core::ffi::c_int,
                b"arr[i] == i\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = i.wrapping_add(1);
    }
    gca_cycle_right(
        arr as *mut ::core::ffi::c_void,
        n,
        ::core::mem::size_of::<size_t>() as size_t,
        (3 as size_t).wrapping_mul(n),
    );
    i = 0 as size_t;
    while i < n {
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(*arr.offset(i as isize) == i) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                126 as ::core::ffi::c_int,
                b"arr[i] == i\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = i.wrapping_add(1);
    }
    shift = 0 as size_t;
    while shift < n {
        i = 0 as size_t;
        while i < n {
            *arr.offset(i as isize) = i;
            i = i.wrapping_add(1);
        }
        gca_cycle_left(
            arr as *mut ::core::ffi::c_void,
            n,
            ::core::mem::size_of::<size_t>() as size_t,
            shift,
        );
        i = 0 as size_t;
        while i < n {
            num_tests_run = num_tests_run.wrapping_add(1);
            if !(*arr.offset(i as isize) == i.wrapping_add(shift).wrapping_rem(n)) {
                num_tests_failed = num_tests_failed.wrapping_add(1);
                fprintf(
                    __stderrp,
                    b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                    131 as ::core::ffi::c_int,
                    b"arr[i] == ((i+shift) % n)\0" as *const u8
                        as *const ::core::ffi::c_char,
                );
            }
            i = i.wrapping_add(1);
        }
        gca_cycle_right(
            arr as *mut ::core::ffi::c_void,
            n,
            ::core::mem::size_of::<size_t>() as size_t,
            shift,
        );
        i = 0 as size_t;
        while i < n {
            num_tests_run = num_tests_run.wrapping_add(1);
            if !(*arr.offset(i as isize) == i) {
                num_tests_failed = num_tests_failed.wrapping_add(1);
                fprintf(
                    __stderrp,
                    b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                    134 as ::core::ffi::c_int,
                    b"arr[i] == i\0" as *const u8 as *const ::core::ffi::c_char,
                );
            }
            i = i.wrapping_add(1);
        }
        shift = shift.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn test_cycle() {
    fprintf(
        __stdoutp,
        b"[%s:%i] Testing array cycle left/right...\n\0" as *const u8
            as *const ::core::ffi::c_char,
        b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
        140 as ::core::ffi::c_int,
    );
    let mut n: size_t = 0;
    let mut arr: [size_t; 100] = [0; 100];
    n = 0 as size_t;
    while n < 100 as size_t {
        _test_cycle(arr.as_mut_ptr(), n);
        n = n.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn test_reverse() {
    fprintf(
        __stdoutp,
        b"[%s:%i] Testing array reverse...\n\0" as *const u8
            as *const ::core::ffi::c_char,
        b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
        150 as ::core::ffi::c_int,
    );
    let mut i: size_t = 0;
    let mut n: size_t = 0;
    let mut tmp: [size_t; 100] = [0; 100];
    n = 0 as size_t;
    while n <= N as size_t {
        i = 0 as size_t;
        while i < n {
            tmp[i as usize] = i;
            i = i.wrapping_add(1);
        }
        gca_reverse(
            tmp.as_mut_ptr() as *mut ::core::ffi::c_void,
            n,
            ::core::mem::size_of::<size_t>() as size_t,
        );
        i = 0 as size_t;
        while i < n && tmp[i as usize] == n.wrapping_sub(i).wrapping_sub(1 as size_t) {
            i = i.wrapping_add(1);
        }
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(i == n) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                158 as ::core::ffi::c_int,
                b"i == n\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        n = n.wrapping_add(1);
    }
}
pub const N: ::core::ffi::c_int = 100 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn test_bsearch() {
    fprintf(
        __stdoutp,
        b"[%s:%i] Testing binary search...\n\0" as *const u8
            as *const ::core::ffi::c_char,
        b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
        165 as ::core::ffi::c_int,
    );
    let mut idx: size_t = 0;
    let mut i: ::core::ffi::c_int = 0;
    let mut n: ::core::ffi::c_int = 0;
    let mut find: ::core::ffi::c_int = 0;
    let mut arr: [::core::ffi::c_int; 100] = [0; 100];
    let mut foundb: *mut ::core::ffi::c_int = 0 as *mut ::core::ffi::c_int;
    let mut foundl: *mut ::core::ffi::c_int = 0 as *mut ::core::ffi::c_int;
    i = 0 as ::core::ffi::c_int;
    while i < N_0 {
        arr[i as usize] = i;
        i += 1;
    }
    find = 20 as ::core::ffi::c_int;
    foundb = gca_bsearch(
        arr.as_mut_ptr() as *mut ::core::ffi::c_void,
        N_0 as size_t,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        Some(
            gca_search_int
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                    *mut ::core::ffi::c_void,
                ) -> ::core::ffi::c_int,
        ),
        &mut find as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
    ) as *mut ::core::ffi::c_int;
    foundl = gca_lsearch(
        arr.as_mut_ptr() as *mut ::core::ffi::c_void,
        N_0 as size_t,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        Some(
            gca_search_int
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                    *mut ::core::ffi::c_void,
                ) -> ::core::ffi::c_int,
        ),
        &mut find as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
    ) as *mut ::core::ffi::c_int;
    idx = foundb.offset_from(arr.as_mut_ptr()) as ::core::ffi::c_long as size_t;
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(foundb
        == &mut *arr.as_mut_ptr().offset(find as isize) as *mut ::core::ffi::c_int)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            177 as ::core::ffi::c_int,
            b"foundb == &arr[find]\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(idx == find as size_t) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            178 as ::core::ffi::c_int,
            b"idx == (size_t)find\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    n = 0 as ::core::ffi::c_int;
    while n <= N_0 {
        find = -(2 as ::core::ffi::c_int);
        while find <= n + 2 as ::core::ffi::c_int {
            foundb = gca_bsearch(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                n as size_t,
                ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
                Some(
                    gca_search_int
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                &mut find as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
            ) as *mut ::core::ffi::c_int;
            num_tests_run = num_tests_run.wrapping_add(1);
            if !(foundb
                == (if find < 0 as ::core::ffi::c_int || find >= n {
                    0 as *mut ::core::ffi::c_int
                } else {
                    &mut *arr.as_mut_ptr().offset(find as isize)
                        as *mut ::core::ffi::c_int
                }))
            {
                num_tests_failed = num_tests_failed.wrapping_add(1);
                fprintf(
                    __stderrp,
                    b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                    183 as ::core::ffi::c_int,
                    b"foundb == (find < 0 || find >= n ? ((void *)0) : &arr[find])\0"
                        as *const u8 as *const ::core::ffi::c_char,
                );
            }
            foundl = gca_lsearch(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                n as size_t,
                ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
                Some(
                    gca_search_int
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                &mut find as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
            ) as *mut ::core::ffi::c_int;
            num_tests_run = num_tests_run.wrapping_add(1);
            if !(foundb == foundl) {
                num_tests_failed = num_tests_failed.wrapping_add(1);
                fprintf(
                    __stderrp,
                    b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                    185 as ::core::ffi::c_int,
                    b"foundb == foundl\0" as *const u8 as *const ::core::ffi::c_char,
                );
            }
            find += 1;
        }
        n += 1;
    }
}
pub const N_0: ::core::ffi::c_int = 100 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn test_quicksort() {
    fprintf(
        __stdoutp,
        b"[%s:%i] Testing quicksort...\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
        193 as ::core::ffi::c_int,
    );
    let mut i: size_t = 0;
    let mut j: size_t = 0;
    let mut n: size_t = 0;
    let mut arr: [size_t; 100] = [0; 100];
    n = 0 as size_t;
    while n <= N_1 as size_t {
        i = 0 as size_t;
        while i < n {
            arr[i as usize] = n.wrapping_sub(1 as size_t).wrapping_sub(i);
            i = i.wrapping_add(1);
        }
        gca_qsort(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            n,
            ::core::mem::size_of::<size_t>() as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            NULL,
        );
        num_tests_run = num_tests_run.wrapping_add(1);
        if !gca_is_sorted(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            n,
            ::core::mem::size_of::<size_t>() as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        ) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                204 as ::core::ffi::c_int,
                b"gca_is_sorted(arr, n, sizeof(arr[0]), gca_cmp2_size, ((void *)0))\0"
                    as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = 0 as size_t;
        while i < n {
            arr[i as usize] = i;
            i = i.wrapping_add(1);
        }
        gca_qsort(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            n,
            ::core::mem::size_of::<size_t>() as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            NULL,
        );
        num_tests_run = num_tests_run.wrapping_add(1);
        if !gca_is_sorted(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            n,
            ::core::mem::size_of::<size_t>() as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        ) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                209 as ::core::ffi::c_int,
                b"gca_is_sorted(arr, n, sizeof(arr[0]), gca_cmp2_size, ((void *)0))\0"
                    as *const u8 as *const ::core::ffi::c_char,
            );
        }
        j = 0 as size_t;
        while j < 100 as size_t {
            gca_shuffle(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                n,
                ::core::mem::size_of::<size_t>() as size_t,
            );
            gca_qsort(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                n,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                NULL,
            );
            num_tests_run = num_tests_run.wrapping_add(1);
            if !gca_is_sorted(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                n,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) {
                num_tests_failed = num_tests_failed.wrapping_add(1);
                fprintf(
                    __stderrp,
                    b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                    215 as ::core::ffi::c_int,
                    b"gca_is_sorted(arr, n, sizeof(arr[0]), gca_cmp2_size, ((void *)0))\0"
                        as *const u8 as *const ::core::ffi::c_char,
                );
            }
            j = j.wrapping_add(1);
        }
        n = n.wrapping_add(1);
    }
}
pub const N_1: ::core::ffi::c_int = 100 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn check_qpart(
    mut arr: *mut size_t,
    mut n: size_t,
    mut pidx: size_t,
) -> bool {
    let mut i: size_t = 0 as size_t;
    i = 0 as size_t;
    while i < pidx {
        if *arr.offset(i as isize) > *arr.offset(pidx as isize) {
            return false_0 != 0;
        }
        i = i.wrapping_add(1);
    }
    i = pidx.wrapping_add(1 as size_t);
    while i < n {
        if *arr.offset(i as isize) < *arr.offset(pidx as isize) {
            return false_0 != 0;
        }
        i = i.wrapping_add(1);
    }
    return true_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn test_quickpartition() {
    fprintf(
        __stdoutp,
        b"[%s:%i] Testing quickpartition...\n\0" as *const u8
            as *const ::core::ffi::c_char,
        b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
        235 as ::core::ffi::c_int,
    );
    let mut i: size_t = 0;
    let mut n: size_t = 0;
    let mut arr: [size_t; 100] = [0; 100];
    let mut p: size_t = 0;
    i = 0 as size_t;
    while i < N_2 as size_t {
        arr[i as usize] = i;
        i = i.wrapping_add(1);
    }
    n = 0 as size_t;
    while n <= N_2 as size_t {
        gca_shuffle(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            n,
            ::core::mem::size_of::<size_t>() as size_t,
        );
        i = 0 as size_t;
        while i < n {
            p = arr[i as usize];
            gca_swapm(
                &mut *arr.as_mut_ptr().offset(0 as ::core::ffi::c_int as isize)
                    as *mut size_t as *mut ::core::ffi::c_void,
                &mut *arr.as_mut_ptr().offset(i as isize) as *mut size_t
                    as *mut ::core::ffi::c_void,
                ::core::mem::size_of::<size_t>() as size_t,
            );
            gca_qpart(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                n,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                NULL,
            );
            num_tests_run = num_tests_run.wrapping_add(1);
            if !(arr[p as usize] == p) {
                num_tests_failed = num_tests_failed.wrapping_add(1);
                fprintf(
                    __stderrp,
                    b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                    247 as ::core::ffi::c_int,
                    b"arr[p] == p\0" as *const u8 as *const ::core::ffi::c_char,
                );
            }
            num_tests_run = num_tests_run.wrapping_add(1);
            if !check_qpart(arr.as_mut_ptr(), n, p) {
                num_tests_failed = num_tests_failed.wrapping_add(1);
                fprintf(
                    __stderrp,
                    b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                    248 as ::core::ffi::c_int,
                    b"check_qpart(arr, n, p)\0" as *const u8
                        as *const ::core::ffi::c_char,
                );
            }
            i = i.wrapping_add(1);
        }
        n = n.wrapping_add(1);
    }
}
pub const N_2: ::core::ffi::c_int = 100 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn test_quickselect() {
    fprintf(
        __stdoutp,
        b"[%s:%i] Testing quickselect...\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
        256 as ::core::ffi::c_int,
    );
    let mut i: size_t = 0;
    let mut n: size_t = 0;
    let mut arr: [size_t; 10] = [0; 10];
    let mut pos: [size_t; 10] = [0; 10];
    i = 0 as size_t;
    while i < N_3 as size_t {
        pos[i as usize] = i;
        i = i.wrapping_add(1);
    }
    n = 0 as size_t;
    while n <= N_3 as size_t {
        gca_shuffle(
            pos.as_mut_ptr() as *mut ::core::ffi::c_void,
            n,
            ::core::mem::size_of::<size_t>() as size_t,
        );
        i = 0 as size_t;
        while i < n && pos[i as usize] < n {
            i = i.wrapping_add(1);
        }
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(i == n) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                268 as ::core::ffi::c_int,
                b"i == n\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = 0 as size_t;
        while i < n {
            arr[i as usize] = i;
            i = i.wrapping_add(1);
        }
        i = 0 as size_t;
        while i < n {
            gca_qselect(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                n,
                ::core::mem::size_of::<size_t>() as size_t,
                i,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                NULL,
            );
            num_tests_run = num_tests_run.wrapping_add(1);
            if !gca_is_sorted(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                n,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) {
                num_tests_failed = num_tests_failed.wrapping_add(1);
                fprintf(
                    __stderrp,
                    b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                    276 as ::core::ffi::c_int,
                    b"gca_is_sorted(arr, n, sizeof(arr[0]), gca_cmp2_size, ((void *)0))\0"
                        as *const u8 as *const ::core::ffi::c_char,
                );
            }
            i = i.wrapping_add(1);
        }
        i = 0 as size_t;
        while i < n {
            gca_qselect(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                n,
                ::core::mem::size_of::<size_t>() as size_t,
                pos[i as usize],
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                NULL,
            );
            num_tests_run = num_tests_run.wrapping_add(1);
            if !check_qpart(arr.as_mut_ptr(), n, pos[i as usize]) {
                num_tests_failed = num_tests_failed.wrapping_add(1);
                fprintf(
                    __stderrp,
                    b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                    282 as ::core::ffi::c_int,
                    b"check_qpart(arr, n, pos[i])\0" as *const u8
                        as *const ::core::ffi::c_char,
                );
            }
            i = i.wrapping_add(1);
        }
        num_tests_run = num_tests_run.wrapping_add(1);
        if !gca_is_sorted(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            n,
            ::core::mem::size_of::<size_t>() as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        ) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                285 as ::core::ffi::c_int,
                b"gca_is_sorted(arr, n, sizeof(arr[0]), gca_cmp2_size, ((void *)0))\0"
                    as *const u8 as *const ::core::ffi::c_char,
            );
        }
        n = n.wrapping_add(1);
    }
}
pub const N_3: ::core::ffi::c_int = 10 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn test_heapsort() {
    fprintf(
        __stdoutp,
        b"[%s:%i] Testing heapsort...\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
        293 as ::core::ffi::c_int,
    );
    let mut i: ::core::ffi::c_int = 0;
    let mut j: ::core::ffi::c_int = 0;
    let mut n: ::core::ffi::c_int = 0;
    let mut arr: [::core::ffi::c_int; 200] = [0; 200];
    n = 0 as ::core::ffi::c_int;
    while n <= N_4 {
        j = 0 as ::core::ffi::c_int;
        while j < n {
            arr[j as usize] = j;
            j += 1;
        }
        gca_heap_make(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            n as size_t,
            ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
            Some(
                gca_cmp2_int
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            NULL,
        );
        gca_heap_sort(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            n as size_t,
            ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
            Some(
                gca_cmp2_int
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            NULL,
        );
        num_tests_run = num_tests_run.wrapping_add(1);
        if !gca_is_sorted(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            n as size_t,
            ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
            Some(
                gca_cmp2_int
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        ) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                305 as ::core::ffi::c_int,
                b"gca_is_sorted(arr, n, sizeof(arr[0]), gca_cmp2_int, ((void *)0))\0"
                    as *const u8 as *const ::core::ffi::c_char,
            );
        }
        j = 0 as ::core::ffi::c_int;
        while j < n {
            arr[j as usize] = n - 1 as ::core::ffi::c_int - j;
            j += 1;
        }
        gca_heap_make(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            n as size_t,
            ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
            Some(
                gca_cmp2_int
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            NULL,
        );
        gca_heap_sort(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            n as size_t,
            ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
            Some(
                gca_cmp2_int
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            NULL,
        );
        num_tests_run = num_tests_run.wrapping_add(1);
        if !gca_is_sorted(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            n as size_t,
            ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
            Some(
                gca_cmp2_int
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        ) {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                311 as ::core::ffi::c_int,
                b"gca_is_sorted(arr, n, sizeof(arr[0]), gca_cmp2_int, ((void *)0))\0"
                    as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = 0 as ::core::ffi::c_int;
        while i < 10 as ::core::ffi::c_int {
            gca_shuffle(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                n as size_t,
                ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
            );
            gca_heap_make(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                n as size_t,
                ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
                Some(
                    gca_cmp2_int
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                NULL,
            );
            gca_heap_sort(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                n as size_t,
                ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
                Some(
                    gca_cmp2_int
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                NULL,
            );
            num_tests_run = num_tests_run.wrapping_add(1);
            if !gca_is_sorted(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                n as size_t,
                ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
                Some(
                    gca_cmp2_int
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) {
                num_tests_failed = num_tests_failed.wrapping_add(1);
                fprintf(
                    __stderrp,
                    b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                    318 as ::core::ffi::c_int,
                    b"gca_is_sorted(arr, n, sizeof(arr[0]), gca_cmp2_int, ((void *)0))\0"
                        as *const u8 as *const ::core::ffi::c_char,
                );
            }
            i += 1;
        }
        n += 1;
    }
}
pub const N_4: ::core::ffi::c_int = 200 as ::core::ffi::c_int;
#[inline]
unsafe extern "C" fn check_median5(mut arr: *mut size_t, mut ans: size_t) {
    let mut i: size_t = 0;
    let mut tmp: size_t = 0;
    let mut ptr: *mut ::core::ffi::c_char = gca_median5(
        &mut *arr.offset(0 as ::core::ffi::c_int as isize) as *mut size_t
            as *mut ::core::ffi::c_void,
        &mut *arr.offset(1 as ::core::ffi::c_int as isize) as *mut size_t
            as *mut ::core::ffi::c_void,
        &mut *arr.offset(2 as ::core::ffi::c_int as isize) as *mut size_t
            as *mut ::core::ffi::c_void,
        &mut *arr.offset(3 as ::core::ffi::c_int as isize) as *mut size_t
            as *mut ::core::ffi::c_void,
        &mut *arr.offset(4 as ::core::ffi::c_int as isize) as *mut size_t
            as *mut ::core::ffi::c_void,
        Some(
            gca_cmp2_size
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                    *const ::core::ffi::c_void,
                    *mut ::core::ffi::c_void,
                ) -> ::core::ffi::c_int,
        ),
        NULL,
    ) as *mut ::core::ffi::c_char;
    memcpy(
        &mut tmp as *mut size_t as *mut ::core::ffi::c_void,
        ptr as *const ::core::ffi::c_void,
        ::core::mem::size_of::<size_t>() as size_t,
    );
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(tmp == ans) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            333 as ::core::ffi::c_int,
            b"tmp == ans\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    if tmp != ans {
        i = 0 as size_t;
        while i < 5 as size_t {
            printf(
                b" %zu\0" as *const u8 as *const ::core::ffi::c_char,
                *arr.offset(i as isize),
            );
            i = i.wrapping_add(1);
        }
        printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
    }
}
#[no_mangle]
pub unsafe extern "C" fn test_median5() {
    let mut arr: [size_t; 5] = [0; 5];
    let mut i: size_t = 0;
    let mut m: size_t = 2 as size_t;
    let mut itr: *mut size_t = 0 as *mut size_t;
    i = 0 as size_t;
    while !gca_itr_next(&mut itr, 5 as size_t, 0 as *mut size_t).is_null() {
        check_median5(itr, m);
        i = i.wrapping_add(1);
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(i
        == (5 as ::core::ffi::c_int * 4 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
            * 2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int) as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            350 as ::core::ffi::c_int,
            b"i == 5*4*3*2*1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    free(itr as *mut ::core::ffi::c_void);
    i = 0 as size_t;
    while i < 10 as size_t {
        arr[0 as ::core::ffi::c_int as usize] = i;
        arr[1 as ::core::ffi::c_int as usize] = i;
        arr[2 as ::core::ffi::c_int as usize] = i;
        arr[3 as ::core::ffi::c_int as usize] = i;
        arr[4 as ::core::ffi::c_int as usize] = i;
        check_median5(arr.as_mut_ptr(), i);
        i = i.wrapping_add(1);
    }
    arr[0 as ::core::ffi::c_int as usize] = 10 as size_t;
    arr[1 as ::core::ffi::c_int as usize] = 0 as size_t;
    arr[2 as ::core::ffi::c_int as usize] = 10 as size_t;
    arr[3 as ::core::ffi::c_int as usize] = 0 as size_t;
    arr[4 as ::core::ffi::c_int as usize] = 10 as size_t;
    check_median5(arr.as_mut_ptr(), 10 as size_t);
    arr[0 as ::core::ffi::c_int as usize] = 1 as size_t;
    arr[1 as ::core::ffi::c_int as usize] = 9 as size_t;
    arr[2 as ::core::ffi::c_int as usize] = 9 as size_t;
    arr[3 as ::core::ffi::c_int as usize] = 10 as size_t;
    arr[4 as ::core::ffi::c_int as usize] = 10 as size_t;
    check_median5(arr.as_mut_ptr(), 9 as size_t);
    arr[0 as ::core::ffi::c_int as usize] = 10 as size_t;
    arr[1 as ::core::ffi::c_int as usize] = 10 as size_t;
    arr[2 as ::core::ffi::c_int as usize] = 9 as size_t;
    arr[3 as ::core::ffi::c_int as usize] = 8 as size_t;
    arr[4 as ::core::ffi::c_int as usize] = 7 as size_t;
    check_median5(arr.as_mut_ptr(), 9 as size_t);
}
#[no_mangle]
pub unsafe extern "C" fn test_median() {
    let mut arr: [size_t; 10] = [0; 10];
    let mut i: size_t = 0;
    let mut t: size_t = 0;
    let mut n: size_t = 0;
    arr[0 as ::core::ffi::c_int as usize] = 1 as size_t;
    arr[1 as ::core::ffi::c_int as usize] = 5 as size_t;
    arr[2 as ::core::ffi::c_int as usize] = 4 as size_t;
    num_tests_run = num_tests_run.wrapping_add(1);
    if !((if 0 as ::core::ffi::c_int != 0 {
        gca_qselect(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            0 as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            (0 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        );
        (if 0 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
            *arr
                .as_mut_ptr()
                .offset((0 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
        } else {
            (((*(gca_max(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                (0 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) as *mut size_t))
                .wrapping_add(
                    *arr
                        .as_mut_ptr()
                        .offset(
                            (0 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize,
                        ),
                ) as ::core::ffi::c_double + 1.0f64) / 2.0f64) as size_t
        })
    } else {
        0 as ::core::ffi::c_int as size_t
    }) == 0 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            376 as ::core::ffi::c_int,
            b"(0 ? (gca_qselect(arr,0,sizeof(size_t),(0)/2,gca_cmp2_size,((void *)0)), ((0)&1 ? *((size_t*)(arr) + (0)/2) : (size_t)(((*(size_t*)gca_max((arr),(0)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (0)/2))+1.0)/2.0))) : (size_t)(0)) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !((if 1 as ::core::ffi::c_int != 0 {
        gca_qselect(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            1 as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            (1 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        );
        (if 1 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
            *arr
                .as_mut_ptr()
                .offset((1 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
        } else {
            (((*(gca_max(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                (1 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) as *mut size_t))
                .wrapping_add(
                    *arr
                        .as_mut_ptr()
                        .offset(
                            (1 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize,
                        ),
                ) as ::core::ffi::c_double + 1.0f64) / 2.0f64) as size_t
        })
    } else {
        0 as ::core::ffi::c_int as size_t
    }) == 1 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            377 as ::core::ffi::c_int,
            b"(1 ? (gca_qselect(arr,1,sizeof(size_t),(1)/2,gca_cmp2_size,((void *)0)), ((1)&1 ? *((size_t*)(arr) + (1)/2) : (size_t)(((*(size_t*)gca_max((arr),(1)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (1)/2))+1.0)/2.0))) : (size_t)(0)) == 1\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !((if 2 as ::core::ffi::c_int != 0 {
        gca_qselect(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            2 as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            (2 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        );
        (if 2 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
            *arr
                .as_mut_ptr()
                .offset((2 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
        } else {
            (((*(gca_max(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                (2 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) as *mut size_t))
                .wrapping_add(
                    *arr
                        .as_mut_ptr()
                        .offset(
                            (2 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize,
                        ),
                ) as ::core::ffi::c_double + 1.0f64) / 2.0f64) as size_t
        })
    } else {
        0 as ::core::ffi::c_int as size_t
    }) == 3 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            378 as ::core::ffi::c_int,
            b"(2 ? (gca_qselect(arr,2,sizeof(size_t),(2)/2,gca_cmp2_size,((void *)0)), ((2)&1 ? *((size_t*)(arr) + (2)/2) : (size_t)(((*(size_t*)gca_max((arr),(2)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (2)/2))+1.0)/2.0))) : (size_t)(0)) == 3\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !((if 3 as ::core::ffi::c_int != 0 {
        gca_qselect(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            3 as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            (3 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        );
        (if 3 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
            *arr
                .as_mut_ptr()
                .offset((3 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
        } else {
            (((*(gca_max(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                (3 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) as *mut size_t))
                .wrapping_add(
                    *arr
                        .as_mut_ptr()
                        .offset(
                            (3 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize,
                        ),
                ) as ::core::ffi::c_double + 1.0f64) / 2.0f64) as size_t
        })
    } else {
        0 as ::core::ffi::c_int as size_t
    }) == 4 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            379 as ::core::ffi::c_int,
            b"(3 ? (gca_qselect(arr,3,sizeof(size_t),(3)/2,gca_cmp2_size,((void *)0)), ((3)&1 ? *((size_t*)(arr) + (3)/2) : (size_t)(((*(size_t*)gca_max((arr),(3)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (3)/2))+1.0)/2.0))) : (size_t)(0)) == 4\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !((if 0 as ::core::ffi::c_int != 0 {
        gca_qselect(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            0 as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            (0 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        );
        (if 0 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
            *arr
                .as_mut_ptr()
                .offset((0 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
        } else {
            (*(gca_max(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                (0 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) as *mut size_t))
                .wrapping_add(
                    *arr
                        .as_mut_ptr()
                        .offset(
                            (0 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize,
                        ),
                )
                .wrapping_add(1 as size_t)
                .wrapping_div(2 as size_t)
        })
    } else {
        0 as ::core::ffi::c_int as size_t
    }) == 0 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            381 as ::core::ffi::c_int,
            b"(0 ? (gca_qselect(arr,0,sizeof(size_t),(0)/2,gca_cmp2_size,((void *)0)), ((0)&1 ? *((size_t*)(arr) + (0)/2) : (size_t)(((*(size_t*)gca_max((arr),(0)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (0)/2))+1)/2))) : (size_t)(0)) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !((if 1 as ::core::ffi::c_int != 0 {
        gca_qselect(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            1 as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            (1 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        );
        (if 1 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
            *arr
                .as_mut_ptr()
                .offset((1 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
        } else {
            (*(gca_max(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                (1 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) as *mut size_t))
                .wrapping_add(
                    *arr
                        .as_mut_ptr()
                        .offset(
                            (1 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize,
                        ),
                )
                .wrapping_add(1 as size_t)
                .wrapping_div(2 as size_t)
        })
    } else {
        0 as ::core::ffi::c_int as size_t
    }) == 1 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            382 as ::core::ffi::c_int,
            b"(1 ? (gca_qselect(arr,1,sizeof(size_t),(1)/2,gca_cmp2_size,((void *)0)), ((1)&1 ? *((size_t*)(arr) + (1)/2) : (size_t)(((*(size_t*)gca_max((arr),(1)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (1)/2))+1)/2))) : (size_t)(0)) == 1\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !((if 2 as ::core::ffi::c_int != 0 {
        gca_qselect(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            2 as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            (2 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        );
        (if 2 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
            *arr
                .as_mut_ptr()
                .offset((2 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
        } else {
            (*(gca_max(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                (2 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) as *mut size_t))
                .wrapping_add(
                    *arr
                        .as_mut_ptr()
                        .offset(
                            (2 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize,
                        ),
                )
                .wrapping_add(1 as size_t)
                .wrapping_div(2 as size_t)
        })
    } else {
        0 as ::core::ffi::c_int as size_t
    }) == 3 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            383 as ::core::ffi::c_int,
            b"(2 ? (gca_qselect(arr,2,sizeof(size_t),(2)/2,gca_cmp2_size,((void *)0)), ((2)&1 ? *((size_t*)(arr) + (2)/2) : (size_t)(((*(size_t*)gca_max((arr),(2)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (2)/2))+1)/2))) : (size_t)(0)) == 3\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !((if 3 as ::core::ffi::c_int != 0 {
        gca_qselect(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            3 as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            (3 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        );
        (if 3 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
            *arr
                .as_mut_ptr()
                .offset((3 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
        } else {
            (*(gca_max(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                (3 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) as *mut size_t))
                .wrapping_add(
                    *arr
                        .as_mut_ptr()
                        .offset(
                            (3 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize,
                        ),
                )
                .wrapping_add(1 as size_t)
                .wrapping_div(2 as size_t)
        })
    } else {
        0 as ::core::ffi::c_int as size_t
    }) == 4 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            384 as ::core::ffi::c_int,
            b"(3 ? (gca_qselect(arr,3,sizeof(size_t),(3)/2,gca_cmp2_size,((void *)0)), ((3)&1 ? *((size_t*)(arr) + (3)/2) : (size_t)(((*(size_t*)gca_max((arr),(3)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (3)/2))+1)/2))) : (size_t)(0)) == 4\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    }
    i = 0 as size_t;
    while i < N_5 as size_t {
        arr[i as usize] = 7 as size_t;
        i = i.wrapping_add(1);
    }
    n = 1 as size_t;
    while n <= N_5 as size_t {
        num_tests_run = num_tests_run.wrapping_add(1);
        gca_qselect(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            n,
            ::core::mem::size_of::<size_t>() as size_t,
            n.wrapping_div(2 as size_t),
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        );
        if !((if n & 1 as size_t != 0 {
            *arr.as_mut_ptr().offset(n.wrapping_div(2 as size_t) as isize)
        } else {
            (((*(gca_max(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                n.wrapping_div(2 as size_t),
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) as *mut size_t))
                .wrapping_add(
                    *arr.as_mut_ptr().offset(n.wrapping_div(2 as size_t) as isize),
                ) as ::core::ffi::c_double + 1.0f64) / 2.0f64) as size_t
        }) == 7 as size_t)
        {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                389 as ::core::ffi::c_int,
                b"(gca_qselect(arr,n,sizeof(size_t),(n)/2,gca_cmp2_size,((void *)0)), ((n)&1 ? *((size_t*)(arr) + (n)/2) : (size_t)(((*(size_t*)gca_max((arr),(n)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (n)/2))+1.0)/2.0))) == 7\0"
                    as *const u8 as *const ::core::ffi::c_char,
            );
        }
        n = n.wrapping_add(1);
    }
    i = 0 as size_t;
    while i < N_5 as size_t {
        arr[i as usize] = i;
        i = i.wrapping_add(1);
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !((if 0 as ::core::ffi::c_int != 0 {
        gca_qselect(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            0 as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            (0 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        );
        (if 0 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
            *arr
                .as_mut_ptr()
                .offset((0 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
        } else {
            (((*(gca_max(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                (0 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) as *mut size_t))
                .wrapping_add(
                    *arr
                        .as_mut_ptr()
                        .offset(
                            (0 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize,
                        ),
                ) as ::core::ffi::c_double + 1.0f64) / 2.0f64) as size_t
        })
    } else {
        18446744073709551615 as ::core::ffi::c_ulong as size_t
    }) == 18446744073709551615 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            393 as ::core::ffi::c_int,
            b"(0 ? (gca_qselect(arr,0,sizeof(size_t),(0)/2,gca_cmp2_size,((void *)0)), ((0)&1 ? *((size_t*)(arr) + (0)/2) : (size_t)(((*(size_t*)gca_max((arr),(0)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (0)/2))+1.0)/2.0))) : (size_t)(18446744073709551615UL)) == 18446744073709551615UL\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !((if 0 as ::core::ffi::c_int != 0 {
        gca_qselect(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            0 as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            (0 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        );
        (if 0 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
            *arr
                .as_mut_ptr()
                .offset((0 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
        } else {
            (((*(gca_max(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                (0 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) as *mut size_t))
                .wrapping_add(
                    *arr
                        .as_mut_ptr()
                        .offset(
                            (0 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize,
                        ),
                ) as ::core::ffi::c_double + 1.0f64) / 2.0f64) as size_t
        })
    } else {
        0 as ::core::ffi::c_int as size_t
    }) == 0 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            394 as ::core::ffi::c_int,
            b"(0 ? (gca_qselect(arr,0,sizeof(size_t),(0)/2,gca_cmp2_size,((void *)0)), ((0)&1 ? *((size_t*)(arr) + (0)/2) : (size_t)(((*(size_t*)gca_max((arr),(0)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (0)/2))+1.0)/2.0))) : (size_t)(0)) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    gca_qselect(
        arr.as_mut_ptr() as *mut ::core::ffi::c_void,
        1 as size_t,
        ::core::mem::size_of::<size_t>() as size_t,
        (1 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
        Some(
            gca_cmp2_size
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                    *const ::core::ffi::c_void,
                    *mut ::core::ffi::c_void,
                ) -> ::core::ffi::c_int,
        ),
        0 as *mut ::core::ffi::c_void,
    );
    if !((if 1 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
        *arr
            .as_mut_ptr()
            .offset((1 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
    } else {
        (((*(gca_max(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            (1 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        ) as *mut size_t))
            .wrapping_add(
                *arr
                    .as_mut_ptr()
                    .offset((1 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize),
            ) as ::core::ffi::c_double + 1.0f64) / 2.0f64) as size_t
    }) == 0 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            395 as ::core::ffi::c_int,
            b"(gca_qselect(arr,1,sizeof(size_t),(1)/2,gca_cmp2_size,((void *)0)), ((1)&1 ? *((size_t*)(arr) + (1)/2) : (size_t)(((*(size_t*)gca_max((arr),(1)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (1)/2))+1.0)/2.0))) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    gca_qselect(
        arr.as_mut_ptr() as *mut ::core::ffi::c_void,
        2 as size_t,
        ::core::mem::size_of::<size_t>() as size_t,
        (2 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
        Some(
            gca_cmp2_size
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                    *const ::core::ffi::c_void,
                    *mut ::core::ffi::c_void,
                ) -> ::core::ffi::c_int,
        ),
        0 as *mut ::core::ffi::c_void,
    );
    if !((if 2 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
        *arr
            .as_mut_ptr()
            .offset((2 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
    } else {
        (((*(gca_max(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            (2 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        ) as *mut size_t))
            .wrapping_add(
                *arr
                    .as_mut_ptr()
                    .offset((2 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize),
            ) as ::core::ffi::c_double + 1.0f64) / 2.0f64) as size_t
    }) == 1 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            396 as ::core::ffi::c_int,
            b"(gca_qselect(arr,2,sizeof(size_t),(2)/2,gca_cmp2_size,((void *)0)), ((2)&1 ? *((size_t*)(arr) + (2)/2) : (size_t)(((*(size_t*)gca_max((arr),(2)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (2)/2))+1.0)/2.0))) == 1\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    gca_qselect(
        arr.as_mut_ptr() as *mut ::core::ffi::c_void,
        3 as size_t,
        ::core::mem::size_of::<size_t>() as size_t,
        (3 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
        Some(
            gca_cmp2_size
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                    *const ::core::ffi::c_void,
                    *mut ::core::ffi::c_void,
                ) -> ::core::ffi::c_int,
        ),
        0 as *mut ::core::ffi::c_void,
    );
    if !((if 3 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
        *arr
            .as_mut_ptr()
            .offset((3 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
    } else {
        (((*(gca_max(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            (3 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        ) as *mut size_t))
            .wrapping_add(
                *arr
                    .as_mut_ptr()
                    .offset((3 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize),
            ) as ::core::ffi::c_double + 1.0f64) / 2.0f64) as size_t
    }) == 1 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            397 as ::core::ffi::c_int,
            b"(gca_qselect(arr,3,sizeof(size_t),(3)/2,gca_cmp2_size,((void *)0)), ((3)&1 ? *((size_t*)(arr) + (3)/2) : (size_t)(((*(size_t*)gca_max((arr),(3)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (3)/2))+1.0)/2.0))) == 1\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    gca_qselect(
        arr.as_mut_ptr() as *mut ::core::ffi::c_void,
        4 as size_t,
        ::core::mem::size_of::<size_t>() as size_t,
        (4 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
        Some(
            gca_cmp2_size
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                    *const ::core::ffi::c_void,
                    *mut ::core::ffi::c_void,
                ) -> ::core::ffi::c_int,
        ),
        0 as *mut ::core::ffi::c_void,
    );
    if !((if 4 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
        *arr
            .as_mut_ptr()
            .offset((4 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
    } else {
        (((*(gca_max(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            (4 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        ) as *mut size_t))
            .wrapping_add(
                *arr
                    .as_mut_ptr()
                    .offset((4 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize),
            ) as ::core::ffi::c_double + 1.0f64) / 2.0f64) as size_t
    }) == 2 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            398 as ::core::ffi::c_int,
            b"(gca_qselect(arr,4,sizeof(size_t),(4)/2,gca_cmp2_size,((void *)0)), ((4)&1 ? *((size_t*)(arr) + (4)/2) : (size_t)(((*(size_t*)gca_max((arr),(4)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (4)/2))+1.0)/2.0))) == 2\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    }
    t = 0 as size_t;
    while t < NTESTS as size_t {
        i = 0 as size_t;
        while i < N_5 as size_t {
            arr[i as usize] = i;
            i = i.wrapping_add(1);
        }
        gca_shuffle(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            N_5 as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
        );
        num_tests_run = num_tests_run.wrapping_add(1);
        gca_qselect(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            10 as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            (10 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        );
        if !((if 10 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
            *arr
                .as_mut_ptr()
                .offset((10 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
        } else {
            (((*(gca_max(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                (10 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) as *mut size_t))
                .wrapping_add(
                    *arr
                        .as_mut_ptr()
                        .offset(
                            (10 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize,
                        ),
                ) as ::core::ffi::c_double + 1.0f64) / 2.0f64) as size_t
        }) == 5 as size_t)
        {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                405 as ::core::ffi::c_int,
                b"(gca_qselect(arr,10,sizeof(size_t),(10)/2,gca_cmp2_size,((void *)0)), ((10)&1 ? *((size_t*)(arr) + (10)/2) : (size_t)(((*(size_t*)gca_max((arr),(10)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (10)/2))+1.0)/2.0))) == 5\0"
                    as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = 0 as size_t;
        while i < N_5 as size_t {
            arr[i as usize] = (2 as size_t).wrapping_mul(i);
            i = i.wrapping_add(1);
        }
        gca_shuffle(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            N_5 as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
        );
        num_tests_run = num_tests_run.wrapping_add(1);
        gca_qselect(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            10 as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            (10 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        );
        if !((if 10 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
            *arr
                .as_mut_ptr()
                .offset((10 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
        } else {
            (((*(gca_max(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                (10 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) as *mut size_t))
                .wrapping_add(
                    *arr
                        .as_mut_ptr()
                        .offset(
                            (10 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize,
                        ),
                ) as ::core::ffi::c_double + 1.0f64) / 2.0f64) as size_t
        }) == 9 as size_t)
        {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                411 as ::core::ffi::c_int,
                b"(gca_qselect(arr,10,sizeof(size_t),(10)/2,gca_cmp2_size,((void *)0)), ((10)&1 ? *((size_t*)(arr) + (10)/2) : (size_t)(((*(size_t*)gca_max((arr),(10)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (10)/2))+1.0)/2.0))) == 9\0"
                    as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = 0 as size_t;
        while i < N_5 as size_t {
            arr[i as usize] = (3 as size_t).wrapping_mul(i);
            i = i.wrapping_add(1);
        }
        gca_shuffle(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            N_5 as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
        );
        num_tests_run = num_tests_run.wrapping_add(1);
        gca_qselect(
            arr.as_mut_ptr() as *mut ::core::ffi::c_void,
            10 as size_t,
            ::core::mem::size_of::<size_t>() as size_t,
            (10 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
            Some(
                gca_cmp2_size
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                        *mut ::core::ffi::c_void,
                    ) -> ::core::ffi::c_int,
            ),
            0 as *mut ::core::ffi::c_void,
        );
        if !((if 10 as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
            *arr
                .as_mut_ptr()
                .offset((10 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize)
        } else {
            (((*(gca_max(
                arr.as_mut_ptr() as *mut ::core::ffi::c_void,
                (10 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as size_t,
                ::core::mem::size_of::<size_t>() as size_t,
                Some(
                    gca_cmp2_size
                        as unsafe extern "C" fn(
                            *const ::core::ffi::c_void,
                            *const ::core::ffi::c_void,
                            *mut ::core::ffi::c_void,
                        ) -> ::core::ffi::c_int,
                ),
                0 as *mut ::core::ffi::c_void,
            ) as *mut size_t))
                .wrapping_add(
                    *arr
                        .as_mut_ptr()
                        .offset(
                            (10 as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as isize,
                        ),
                ) as ::core::ffi::c_double + 1.0f64) / 2.0f64) as size_t
        }) == 14 as size_t)
        {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                417 as ::core::ffi::c_int,
                b"(gca_qselect(arr,10,sizeof(size_t),(10)/2,gca_cmp2_size,((void *)0)), ((10)&1 ? *((size_t*)(arr) + (10)/2) : (size_t)(((*(size_t*)gca_max((arr),(10)/2,sizeof(size_t),gca_cmp2_size,((void *)0)))+(*((size_t*)(arr) + (10)/2))+1.0)/2.0))) == 14\0"
                    as *const u8 as *const ::core::ffi::c_char,
            );
        }
        t = t.wrapping_add(1);
    }
}
pub const N_5: ::core::ffi::c_int = 10 as ::core::ffi::c_int;
pub const NTESTS: ::core::ffi::c_int = 4 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn check_permutation5(
    mut pp: *mut *mut size_t,
    mut a: size_t,
    mut b: size_t,
    mut c: size_t,
    mut d: size_t,
    mut e: size_t,
    mut init: *mut size_t,
) {
    let mut p: *mut size_t = gca_itr_next(pp, 5 as size_t, init);
    num_tests_run = num_tests_run.wrapping_add(1);
    if p.is_null() {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            427 as ::core::ffi::c_int,
            b"p != ((void *)0)\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    let mut nxtpermut: bool = *p.offset(0 as ::core::ffi::c_int as isize) == a
        && *p.offset(1 as ::core::ffi::c_int as isize) == b
        && *p.offset(2 as ::core::ffi::c_int as isize) == c
        && *p.offset(3 as ::core::ffi::c_int as isize) == d
        && *p.offset(4 as ::core::ffi::c_int as isize) == e;
    num_tests_run = num_tests_run.wrapping_add(1);
    if !nxtpermut {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            430 as ::core::ffi::c_int,
            b"nxtpermut\0" as *const u8 as *const ::core::ffi::c_char,
        );
        if !(b"%zu %zu %zu %zu %zu / %zu %zu %zu %zu %zu\n\0" as *const u8
            as *const ::core::ffi::c_char)
            .is_null()
        {
            fprintf(
                __stderrp,
                b"%zu %zu %zu %zu %zu / %zu %zu %zu %zu %zu\n\0" as *const u8
                    as *const ::core::ffi::c_char,
                *p.offset(0 as ::core::ffi::c_int as isize),
                *p.offset(1 as ::core::ffi::c_int as isize),
                *p.offset(2 as ::core::ffi::c_int as isize),
                *p.offset(3 as ::core::ffi::c_int as isize),
                *p.offset(4 as ::core::ffi::c_int as isize),
                a,
                b,
                c,
                d,
                e,
            );
        }
    }
}
#[no_mangle]
pub unsafe extern "C" fn test_next_perm_with_dupes() {
    fprintf(
        __stdoutp,
        b"[%s:%i] Testing next permutation with duplicates...\n\0" as *const u8
            as *const ::core::ffi::c_char,
        b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
        435 as ::core::ffi::c_int,
    );
    let mut p: *mut size_t = 0 as *mut size_t;
    let mut init: [size_t; 5] = [
        0 as ::core::ffi::c_int as size_t,
        1 as ::core::ffi::c_int as size_t,
        2 as ::core::ffi::c_int as size_t,
        2 as ::core::ffi::c_int as size_t,
        2 as ::core::ffi::c_int as size_t,
    ];
    check_permutation5(
        &mut p,
        0 as size_t,
        1 as size_t,
        2 as size_t,
        2 as size_t,
        2 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        2 as size_t,
        1 as size_t,
        2 as size_t,
        2 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        2 as size_t,
        2 as size_t,
        1 as size_t,
        2 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        2 as size_t,
        2 as size_t,
        2 as size_t,
        1 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        0 as size_t,
        2 as size_t,
        2 as size_t,
        2 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        2 as size_t,
        0 as size_t,
        2 as size_t,
        2 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        2 as size_t,
        2 as size_t,
        0 as size_t,
        2 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        2 as size_t,
        2 as size_t,
        2 as size_t,
        0 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        0 as size_t,
        1 as size_t,
        2 as size_t,
        2 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        0 as size_t,
        2 as size_t,
        1 as size_t,
        2 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        0 as size_t,
        2 as size_t,
        2 as size_t,
        1 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        1 as size_t,
        0 as size_t,
        2 as size_t,
        2 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        1 as size_t,
        2 as size_t,
        0 as size_t,
        2 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        1 as size_t,
        2 as size_t,
        2 as size_t,
        0 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        2 as size_t,
        0 as size_t,
        1 as size_t,
        2 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        2 as size_t,
        0 as size_t,
        2 as size_t,
        1 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        2 as size_t,
        1 as size_t,
        0 as size_t,
        2 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        2 as size_t,
        1 as size_t,
        2 as size_t,
        0 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        2 as size_t,
        2 as size_t,
        0 as size_t,
        1 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        2 as size_t,
        2 as size_t,
        1 as size_t,
        0 as size_t,
        init.as_mut_ptr(),
    );
    num_tests_run = num_tests_run.wrapping_add(1);
    if !gca_itr_next(&mut p, 5 as size_t, init.as_mut_ptr()).is_null() {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            464 as ::core::ffi::c_int,
            b"gca_itr_next(&p, 5, init) == ((void *)0)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !gca_itr_next(&mut p, 5 as size_t, init.as_mut_ptr()).is_null() {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            465 as ::core::ffi::c_int,
            b"gca_itr_next(&p, 5, init) == ((void *)0)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_itr_reset(p, 5 as size_t) == p && !p.is_null()) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            467 as ::core::ffi::c_int,
            b"gca_itr_reset(p, 5) == p && p != ((void *)0)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    check_permutation5(
        &mut p,
        0 as size_t,
        1 as size_t,
        2 as size_t,
        2 as size_t,
        2 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        2 as size_t,
        1 as size_t,
        2 as size_t,
        2 as size_t,
        init.as_mut_ptr(),
    );
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_itr_reset(p, 5 as size_t) == p && !p.is_null()) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            472 as ::core::ffi::c_int,
            b"gca_itr_reset(p, 5) == p && p != ((void *)0)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    init[4 as ::core::ffi::c_int as usize] = 1 as size_t;
    init[3 as ::core::ffi::c_int as usize] = init[4 as ::core::ffi::c_int as usize];
    init[2 as ::core::ffi::c_int as usize] = init[3 as ::core::ffi::c_int as usize];
    init[1 as ::core::ffi::c_int as usize] = init[2 as ::core::ffi::c_int as usize];
    init[0 as ::core::ffi::c_int as usize] = init[1 as ::core::ffi::c_int as usize];
    check_permutation5(
        &mut p,
        1 as size_t,
        1 as size_t,
        1 as size_t,
        1 as size_t,
        1 as size_t,
        init.as_mut_ptr(),
    );
    num_tests_run = num_tests_run.wrapping_add(1);
    if !gca_itr_next(&mut p, 5 as size_t, init.as_mut_ptr()).is_null() {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            475 as ::core::ffi::c_int,
            b"gca_itr_next(&p, 5, init) == ((void *)0)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_itr_reset(p, 5 as size_t) == p && !p.is_null()) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            476 as ::core::ffi::c_int,
            b"gca_itr_reset(p, 5) == p && p != ((void *)0)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    check_permutation5(
        &mut p,
        1 as size_t,
        1 as size_t,
        1 as size_t,
        1 as size_t,
        1 as size_t,
        init.as_mut_ptr(),
    );
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_itr_reset(p, 5 as size_t) == p && !p.is_null()) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            480 as ::core::ffi::c_int,
            b"gca_itr_reset(p, 5) == p && p != ((void *)0)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    init[4 as ::core::ffi::c_int as usize] = 1 as size_t;
    init[3 as ::core::ffi::c_int as usize] = init[4 as ::core::ffi::c_int as usize];
    init[2 as ::core::ffi::c_int as usize] = init[3 as ::core::ffi::c_int as usize];
    init[1 as ::core::ffi::c_int as usize] = init[2 as ::core::ffi::c_int as usize];
    init[0 as ::core::ffi::c_int as usize] = init[1 as ::core::ffi::c_int as usize];
    init[4 as ::core::ffi::c_int as usize] = 7 as size_t;
    check_permutation5(
        &mut p,
        1 as size_t,
        1 as size_t,
        1 as size_t,
        1 as size_t,
        7 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        1 as size_t,
        1 as size_t,
        7 as size_t,
        1 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        1 as size_t,
        7 as size_t,
        1 as size_t,
        1 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        7 as size_t,
        1 as size_t,
        1 as size_t,
        1 as size_t,
        init.as_mut_ptr(),
    );
    check_permutation5(
        &mut p,
        7 as size_t,
        1 as size_t,
        1 as size_t,
        1 as size_t,
        1 as size_t,
        init.as_mut_ptr(),
    );
    num_tests_run = num_tests_run.wrapping_add(1);
    if !gca_itr_next(&mut p, 5 as size_t, init.as_mut_ptr()).is_null() {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            488 as ::core::ffi::c_int,
            b"gca_itr_next(&p, 5, init) == ((void *)0)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_itr_reset(p, 5 as size_t) == p && !p.is_null()) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            489 as ::core::ffi::c_int,
            b"gca_itr_reset(p, 5) == p && p != ((void *)0)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    check_permutation5(
        &mut p,
        1 as size_t,
        1 as size_t,
        1 as size_t,
        1 as size_t,
        7 as size_t,
        init.as_mut_ptr(),
    );
    free(p as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn test_next_permutation() {
    fprintf(
        __stdoutp,
        b"[%s:%i] Testing next permutation...\n\0" as *const u8
            as *const ::core::ffi::c_char,
        b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
        497 as ::core::ffi::c_int,
    );
    let mut i: size_t = 0;
    let mut n: size_t = 0;
    let mut p: *mut size_t = 0 as *mut size_t;
    check_permutation5(
        &mut p,
        0 as size_t,
        1 as size_t,
        2 as size_t,
        3 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        1 as size_t,
        2 as size_t,
        4 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        1 as size_t,
        3 as size_t,
        2 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        1 as size_t,
        3 as size_t,
        4 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        1 as size_t,
        4 as size_t,
        2 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        1 as size_t,
        4 as size_t,
        3 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        2 as size_t,
        1 as size_t,
        3 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        2 as size_t,
        1 as size_t,
        4 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        2 as size_t,
        3 as size_t,
        1 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        2 as size_t,
        3 as size_t,
        4 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        2 as size_t,
        4 as size_t,
        1 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        2 as size_t,
        4 as size_t,
        3 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        3 as size_t,
        1 as size_t,
        2 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        3 as size_t,
        1 as size_t,
        4 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        3 as size_t,
        2 as size_t,
        1 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        3 as size_t,
        2 as size_t,
        4 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        3 as size_t,
        4 as size_t,
        1 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        3 as size_t,
        4 as size_t,
        2 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        4 as size_t,
        1 as size_t,
        2 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        4 as size_t,
        1 as size_t,
        3 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        4 as size_t,
        2 as size_t,
        1 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        4 as size_t,
        2 as size_t,
        3 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        4 as size_t,
        3 as size_t,
        1 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        4 as size_t,
        3 as size_t,
        2 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        0 as size_t,
        2 as size_t,
        3 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        0 as size_t,
        2 as size_t,
        4 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        0 as size_t,
        3 as size_t,
        2 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        0 as size_t,
        3 as size_t,
        4 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        0 as size_t,
        4 as size_t,
        2 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        0 as size_t,
        4 as size_t,
        3 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        2 as size_t,
        0 as size_t,
        3 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        2 as size_t,
        0 as size_t,
        4 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        2 as size_t,
        3 as size_t,
        0 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        2 as size_t,
        3 as size_t,
        4 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        2 as size_t,
        4 as size_t,
        0 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        2 as size_t,
        4 as size_t,
        3 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        3 as size_t,
        0 as size_t,
        2 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        3 as size_t,
        0 as size_t,
        4 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        3 as size_t,
        2 as size_t,
        0 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        3 as size_t,
        2 as size_t,
        4 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        3 as size_t,
        4 as size_t,
        0 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        3 as size_t,
        4 as size_t,
        2 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        4 as size_t,
        0 as size_t,
        2 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        4 as size_t,
        0 as size_t,
        3 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        4 as size_t,
        2 as size_t,
        0 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        4 as size_t,
        2 as size_t,
        3 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        4 as size_t,
        3 as size_t,
        0 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        1 as size_t,
        4 as size_t,
        3 as size_t,
        2 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        0 as size_t,
        1 as size_t,
        3 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        0 as size_t,
        1 as size_t,
        4 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        0 as size_t,
        3 as size_t,
        1 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        0 as size_t,
        3 as size_t,
        4 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        0 as size_t,
        4 as size_t,
        1 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        0 as size_t,
        4 as size_t,
        3 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        1 as size_t,
        0 as size_t,
        3 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        1 as size_t,
        0 as size_t,
        4 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        1 as size_t,
        3 as size_t,
        0 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        1 as size_t,
        3 as size_t,
        4 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        1 as size_t,
        4 as size_t,
        0 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        1 as size_t,
        4 as size_t,
        3 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        3 as size_t,
        0 as size_t,
        1 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        3 as size_t,
        0 as size_t,
        4 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        3 as size_t,
        1 as size_t,
        0 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        3 as size_t,
        1 as size_t,
        4 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        3 as size_t,
        4 as size_t,
        0 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        3 as size_t,
        4 as size_t,
        1 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        4 as size_t,
        0 as size_t,
        1 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        4 as size_t,
        0 as size_t,
        3 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        4 as size_t,
        1 as size_t,
        0 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        4 as size_t,
        1 as size_t,
        3 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        4 as size_t,
        3 as size_t,
        0 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        2 as size_t,
        4 as size_t,
        3 as size_t,
        1 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        0 as size_t,
        1 as size_t,
        2 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        0 as size_t,
        1 as size_t,
        4 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        0 as size_t,
        2 as size_t,
        1 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        0 as size_t,
        2 as size_t,
        4 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        0 as size_t,
        4 as size_t,
        1 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        0 as size_t,
        4 as size_t,
        2 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        1 as size_t,
        0 as size_t,
        2 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        1 as size_t,
        0 as size_t,
        4 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        1 as size_t,
        2 as size_t,
        0 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        1 as size_t,
        2 as size_t,
        4 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        1 as size_t,
        4 as size_t,
        0 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        1 as size_t,
        4 as size_t,
        2 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        2 as size_t,
        0 as size_t,
        1 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        2 as size_t,
        0 as size_t,
        4 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        2 as size_t,
        1 as size_t,
        0 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        2 as size_t,
        1 as size_t,
        4 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        2 as size_t,
        4 as size_t,
        0 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        2 as size_t,
        4 as size_t,
        1 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        4 as size_t,
        0 as size_t,
        1 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        4 as size_t,
        0 as size_t,
        2 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        4 as size_t,
        1 as size_t,
        0 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        4 as size_t,
        1 as size_t,
        2 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        4 as size_t,
        2 as size_t,
        0 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        3 as size_t,
        4 as size_t,
        2 as size_t,
        1 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        0 as size_t,
        1 as size_t,
        2 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        0 as size_t,
        1 as size_t,
        3 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        0 as size_t,
        2 as size_t,
        1 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        0 as size_t,
        2 as size_t,
        3 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        0 as size_t,
        3 as size_t,
        1 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        0 as size_t,
        3 as size_t,
        2 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        1 as size_t,
        0 as size_t,
        2 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        1 as size_t,
        0 as size_t,
        3 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        1 as size_t,
        2 as size_t,
        0 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        1 as size_t,
        2 as size_t,
        3 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        1 as size_t,
        3 as size_t,
        0 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        1 as size_t,
        3 as size_t,
        2 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        2 as size_t,
        0 as size_t,
        1 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        2 as size_t,
        0 as size_t,
        3 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        2 as size_t,
        1 as size_t,
        0 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        2 as size_t,
        1 as size_t,
        3 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        2 as size_t,
        3 as size_t,
        0 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        2 as size_t,
        3 as size_t,
        1 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        3 as size_t,
        0 as size_t,
        1 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        3 as size_t,
        0 as size_t,
        2 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        3 as size_t,
        1 as size_t,
        0 as size_t,
        2 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        3 as size_t,
        1 as size_t,
        2 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        3 as size_t,
        2 as size_t,
        0 as size_t,
        1 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        4 as size_t,
        3 as size_t,
        2 as size_t,
        1 as size_t,
        0 as size_t,
        0 as *mut size_t,
    );
    num_tests_run = num_tests_run.wrapping_add(1);
    if !gca_itr_next(&mut p, 5 as size_t, 0 as *mut size_t).is_null() {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            646 as ::core::ffi::c_int,
            b"gca_itr_next(&p, 5, ((void *)0)) == ((void *)0)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !gca_itr_next(&mut p, 5 as size_t, 0 as *mut size_t).is_null() {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            647 as ::core::ffi::c_int,
            b"gca_itr_next(&p, 5, ((void *)0)) == ((void *)0)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !gca_itr_next(&mut p, 5 as size_t, 0 as *mut size_t).is_null() {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            648 as ::core::ffi::c_int,
            b"gca_itr_next(&p, 5, ((void *)0)) == ((void *)0)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_itr_reset(p, 5 as size_t) == p && !p.is_null()) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            650 as ::core::ffi::c_int,
            b"gca_itr_reset(p, 5) == p && p != ((void *)0)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    check_permutation5(
        &mut p,
        0 as size_t,
        1 as size_t,
        2 as size_t,
        3 as size_t,
        4 as size_t,
        0 as *mut size_t,
    );
    check_permutation5(
        &mut p,
        0 as size_t,
        1 as size_t,
        2 as size_t,
        4 as size_t,
        3 as size_t,
        0 as *mut size_t,
    );
    free(p as *mut ::core::ffi::c_void);
    p = 0 as *mut size_t;
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_itr_next(&mut p, 2 as size_t, 0 as *mut size_t) == p) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            657 as ::core::ffi::c_int,
            b"gca_itr_next(&p, 2, ((void *)0)) == p\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(*p.offset(0 as ::core::ffi::c_int as isize) == 0 as size_t
        && *p.offset(1 as ::core::ffi::c_int as isize) == 1 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            658 as ::core::ffi::c_int,
            b"p[0] == 0 && p[1] == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_itr_next(&mut p, 2 as size_t, 0 as *mut size_t) == p) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            659 as ::core::ffi::c_int,
            b"gca_itr_next(&p, 2, ((void *)0)) == p\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(*p.offset(0 as ::core::ffi::c_int as isize) == 1 as size_t
        && *p.offset(1 as ::core::ffi::c_int as isize) == 0 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            660 as ::core::ffi::c_int,
            b"p[0] == 1 && p[1] == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !gca_itr_next(&mut p, 2 as size_t, 0 as *mut size_t).is_null() {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            661 as ::core::ffi::c_int,
            b"gca_itr_next(&p, 2, ((void *)0)) == ((void *)0)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !gca_itr_next(&mut p, 2 as size_t, 0 as *mut size_t).is_null() {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            662 as ::core::ffi::c_int,
            b"gca_itr_next(&p, 2, ((void *)0)) == ((void *)0)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    p = gca_itr_reset(p, 2 as size_t);
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_itr_next(&mut p, 2 as size_t, 0 as *mut size_t) == p) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            665 as ::core::ffi::c_int,
            b"gca_itr_next(&p, 2, ((void *)0)) == p\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(*p.offset(0 as ::core::ffi::c_int as isize) == 0 as size_t
        && *p.offset(1 as ::core::ffi::c_int as isize) == 1 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            666 as ::core::ffi::c_int,
            b"p[0] == 0 && p[1] == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(gca_itr_next(&mut p, 2 as size_t, 0 as *mut size_t) == p) {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            667 as ::core::ffi::c_int,
            b"gca_itr_next(&p, 2, ((void *)0)) == p\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    num_tests_run = num_tests_run.wrapping_add(1);
    if !(*p.offset(0 as ::core::ffi::c_int as isize) == 1 as size_t
        && *p.offset(1 as ::core::ffi::c_int as isize) == 0 as size_t)
    {
        num_tests_failed = num_tests_failed.wrapping_add(1);
        fprintf(
            __stderrp,
            b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
            668 as ::core::ffi::c_int,
            b"p[0] == 1 && p[1] == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    free(p as *mut ::core::ffi::c_void);
    n = 0 as size_t;
    while n < 5 as size_t {
        p = gca_itr_reset(0 as *mut size_t, n);
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(gca_itr_next(&mut p, n, 0 as *mut size_t)
            == (if n != 0 { p } else { 0 as *mut size_t }))
        {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                675 as ::core::ffi::c_int,
                b"gca_itr_next(&p, n, ((void *)0)) == (n ? p : ((void *)0))\0"
                    as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = 0 as size_t;
        while i < n {
            num_tests_run = num_tests_run.wrapping_add(1);
            if !(*p.offset(i as isize) == i) {
                num_tests_failed = num_tests_failed.wrapping_add(1);
                fprintf(
                    __stderrp,
                    b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                    676 as ::core::ffi::c_int,
                    b"p[i] == i\0" as *const u8 as *const ::core::ffi::c_char,
                );
            }
            i = i.wrapping_add(1);
        }
        p = gca_itr_reset(p, n);
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(gca_itr_next(&mut p, n, 0 as *mut size_t)
            == (if n != 0 { p } else { 0 as *mut size_t }))
        {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                679 as ::core::ffi::c_int,
                b"gca_itr_next(&p, n, ((void *)0)) == (n ? p : ((void *)0))\0"
                    as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = 0 as size_t;
        while i < n {
            num_tests_run = num_tests_run.wrapping_add(1);
            if !(*p.offset(i as isize) == i) {
                num_tests_failed = num_tests_failed.wrapping_add(1);
                fprintf(
                    __stderrp,
                    b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                    680 as ::core::ffi::c_int,
                    b"p[i] == i\0" as *const u8 as *const ::core::ffi::c_char,
                );
            }
            i = i.wrapping_add(1);
        }
        free(p as *mut ::core::ffi::c_void);
        p = 0 as *mut size_t;
        num_tests_run = num_tests_run.wrapping_add(1);
        if !(gca_itr_next(&mut p, n, 0 as *mut size_t)
            == (if n != 0 { p } else { 0 as *mut size_t }))
        {
            num_tests_failed = num_tests_failed.wrapping_add(1);
            fprintf(
                __stderrp,
                b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                685 as ::core::ffi::c_int,
                b"gca_itr_next(&p, n, ((void *)0)) == (n ? p : ((void *)0))\0"
                    as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i = 0 as size_t;
        while i < n {
            num_tests_run = num_tests_run.wrapping_add(1);
            if !(*p.offset(i as isize) == i) {
                num_tests_failed = num_tests_failed.wrapping_add(1);
                fprintf(
                    __stderrp,
                    b"[%s:%i] Failed: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
                    686 as ::core::ffi::c_int,
                    b"p[i] == i\0" as *const u8 as *const ::core::ffi::c_char,
                );
            }
            i = i.wrapping_add(1);
        }
        free(p as *mut ::core::ffi::c_void);
        n = n.wrapping_add(1);
    }
}
#[inline]
unsafe extern "C" fn get_rand_seed() -> uint32_t {
    let mut now: timeval = timeval { tv_sec: 0, tv_usec: 0 };
    gettimeofday(&mut now, NULL);
    let mut h: uint32_t = rand() as uint32_t;
    h = h
        .wrapping_mul(37 as uint32_t)
        .wrapping_add(
            (now.tv_sec as uint32_t) << (h & 31 as uint32_t)
                | now.tv_sec as uint32_t
                    >> (32 as uint32_t).wrapping_sub(h & 31 as uint32_t),
        );
    h = h
        .wrapping_mul(37 as uint32_t)
        .wrapping_add(
            (now.tv_usec as uint32_t) << (h & 31 as uint32_t)
                | now.tv_usec as uint32_t
                    >> (32 as uint32_t).wrapping_sub(h & 31 as uint32_t),
        );
    h = h.wrapping_mul(37 as uint32_t).wrapping_add(getpid() as uint32_t);
    return h;
}
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut seed32: uint32_t = get_rand_seed();
    srand48(seed32 as ::core::ffi::c_long);
    srand(seed32 as ::core::ffi::c_uint);
    fprintf(
        __stdoutp,
        b"[%s:%i] Random seed = %u\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
        711 as ::core::ffi::c_int,
        seed32,
    );
    fprintf(
        __stdoutp,
        b"[%s:%i] Running tests...\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
        713 as ::core::ffi::c_int,
    );
    test_round();
    test_GCD();
    test_cycle();
    test_reverse();
    test_bsearch();
    test_quicksort();
    test_quickpartition();
    test_quickselect();
    test_heapsort();
    test_median5();
    test_median();
    test_next_permutation();
    test_next_perm_with_dupes();
    fprintf(
        __stdoutp,
        b"[%s:%i] Passed: %zu / %zu (%s)\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
        728 as ::core::ffi::c_int,
        num_tests_run.wrapping_sub(num_tests_failed),
        num_tests_run,
        if num_tests_failed == 0 {
            b"All\0" as *const u8 as *const ::core::ffi::c_char
        } else if num_tests_failed < num_tests_run {
            b"Some\0" as *const u8 as *const ::core::ffi::c_char
        } else {
            b"None\0" as *const u8 as *const ::core::ffi::c_char
        },
    );
    fprintf(
        __stdoutp,
        b"[%s:%i] Done.\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"tests/test.c\0" as *const u8 as *const ::core::ffi::c_char,
        729 as ::core::ffi::c_int,
    );
    return if num_tests_failed != 0 {
        -(1 as ::core::ffi::c_int)
    } else {
        0 as ::core::ffi::c_int
    };
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
