#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn calloc(__count: size_t, __size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn __error() -> *mut ::core::ffi::c_int;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct chtrie_edge {
    pub next: *mut chtrie_edge,
    pub from: ::core::ffi::c_int,
    pub sym: ::core::ffi::c_int,
    pub to: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct chtrie {
    pub etab: *mut *mut chtrie_edge,
    pub idxpool: *mut ::core::ffi::c_int,
    pub idxptr: *mut ::core::ffi::c_int,
    pub idxmax: ::core::ffi::c_int,
    pub maxn: ::core::ffi::c_int,
    pub alphsz: ::core::ffi::c_int,
    pub ecap: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const INT_MAX: ::core::ffi::c_int = 2147483647 as ::core::ffi::c_int;
pub const ENOMEM: ::core::ffi::c_int = 12 as ::core::ffi::c_int;
pub const ERANGE: ::core::ffi::c_int = 34 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn chtrie_alloc(mut n: size_t, mut m: size_t) -> *mut chtrie {
    let mut tr: *mut chtrie = 0 as *mut chtrie;
    if n < 1 as size_t {
        n = 1 as size_t;
    }
    if m < 1 as size_t {
        m = 1 as size_t;
    }
    if n > INT_MAX as size_t || m > INT_MAX as size_t {
        *__error() = ERANGE;
    } else if (if (2147483647 as size_t) < -(1 as ::core::ffi::c_int) as size_t {
        2147483647 as size_t
    } else {
        -(1 as ::core::ffi::c_int) as size_t
    })
        .wrapping_sub(n.wrapping_sub(1 as size_t))
        < n.wrapping_sub(1 as size_t).wrapping_div(3 as size_t)
    {
        *__error() = ERANGE;
    } else {
        tr = calloc(1 as size_t, ::core::mem::size_of::<chtrie>() as size_t)
            as *mut chtrie;
        if !tr.is_null() {
            (*tr).maxn = n as ::core::ffi::c_int;
            (*tr).alphsz = m as ::core::ffi::c_int;
            (*tr).ecap = n
                .wrapping_sub(1 as size_t)
                .wrapping_add(n.wrapping_sub(1 as size_t).wrapping_div(3 as size_t))
                as ::core::ffi::c_int;
            (*tr).etab = calloc(
                (*tr).ecap as size_t,
                ::core::mem::size_of::<*mut chtrie_edge>() as size_t,
            ) as *mut *mut chtrie_edge;
            if !(*tr).etab.is_null() {
                (*tr).idxpool = calloc(
                    n,
                    ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
                ) as *mut ::core::ffi::c_int;
                if (*tr).idxpool.is_null() {
                    free((*tr).etab as *mut ::core::ffi::c_void);
                } else {
                    (*tr).idxmax = 1 as ::core::ffi::c_int;
                    (*tr).idxptr = (*tr).idxpool;
                    return tr;
                }
            }
            free(tr as *mut ::core::ffi::c_void);
        }
    }
    return 0 as *mut chtrie;
}
#[no_mangle]
pub unsafe extern "C" fn chtrie_walk(
    mut tr: *mut chtrie,
    mut from: ::core::ffi::c_int,
    mut sym: ::core::ffi::c_int,
    mut creat: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut p: *mut chtrie_edge = 0 as *mut chtrie_edge;
    let mut h: ::core::ffi::c_ulong = 0;
    h = (from as ::core::ffi::c_ulong)
        .wrapping_mul((*tr).alphsz as ::core::ffi::c_ulong)
        .wrapping_add(sym as ::core::ffi::c_ulong);
    h = h.wrapping_rem((*tr).ecap as ::core::ffi::c_ulong);
    p = *(*tr).etab.offset(h as isize);
    while !p.is_null() {
        if (*p).from == from && (*p).sym == sym {
            return (*p).to;
        }
        p = (*p).next;
    }
    if creat != 0 {
        if (*tr).idxptr == (*tr).idxpool && (*tr).idxmax >= (*tr).maxn {
            *__error() = ENOMEM;
            return -(1 as ::core::ffi::c_int);
        }
        p = malloc(::core::mem::size_of::<chtrie_edge>() as size_t) as *mut chtrie_edge;
        if p.is_null() {
            return -(1 as ::core::ffi::c_int);
        }
        (*p).next = *(*tr).etab.offset(h as isize);
        let ref mut fresh0 = *(*tr).etab.offset(h as isize);
        *fresh0 = p;
        (*p).from = from;
        (*p).sym = sym;
        if (*tr).idxptr != (*tr).idxpool {
            (*tr).idxptr = (*tr).idxptr.offset(-1);
            (*p).to = *(*tr).idxptr;
        } else {
            let fresh1 = (*tr).idxmax;
            (*tr).idxmax = (*tr).idxmax + 1;
            (*p).to = fresh1;
        }
        return (*p).to;
    }
    return -(1 as ::core::ffi::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn chtrie_del(
    mut tr: *mut chtrie,
    mut from: ::core::ffi::c_int,
    mut sym: ::core::ffi::c_int,
) {
    let mut p: *mut chtrie_edge = 0 as *mut chtrie_edge;
    let mut q: *mut chtrie_edge = 0 as *mut chtrie_edge;
    let mut h: ::core::ffi::c_ulong = 0;
    h = (from as ::core::ffi::c_ulong)
        .wrapping_mul((*tr).alphsz as ::core::ffi::c_ulong)
        .wrapping_add(sym as ::core::ffi::c_ulong);
    h = h.wrapping_rem((*tr).ecap as ::core::ffi::c_ulong);
    p = *(*tr).etab.offset(h as isize);
    q = 0 as *mut chtrie_edge;
    while !p.is_null() {
        if (*p).from == from && (*p).sym == sym {
            break;
        }
        q = p;
        p = (*p).next;
    }
    if p.is_null() {
        return;
    }
    if !q.is_null() {
        (*q).next = (*p).next;
    } else {
        let ref mut fresh2 = *(*tr).etab.offset(h as isize);
        *fresh2 = 0 as *mut chtrie_edge;
    }
    let fresh3 = (*tr).idxptr;
    (*tr).idxptr = (*tr).idxptr.offset(1);
    *fresh3 = (*p).to;
    free(p as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn chtrie_free(mut tr: *mut chtrie) {
    let mut p: *mut chtrie_edge = 0 as *mut chtrie_edge;
    let mut q: *mut chtrie_edge = 0 as *mut chtrie_edge;
    let mut i: ::core::ffi::c_int = 0;
    i = 0 as ::core::ffi::c_int;
    while i < (*tr).ecap {
        p = *(*tr).etab.offset(i as isize);
        while !p.is_null() {
            q = (*p).next;
            free(p as *mut ::core::ffi::c_void);
            p = q;
        }
        i += 1;
    }
    free((*tr).etab as *mut ::core::ffi::c_void);
    free((*tr).idxpool as *mut ::core::ffi::c_void);
    free(tr as *mut ::core::ffi::c_void);
}
