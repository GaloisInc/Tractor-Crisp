#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(c_variadic, extern_types)]
extern "C" {
    pub type __sFILEX;
    pub type csvfield;
    static mut __stdinp: *mut FILE;
    static mut __stdoutp: *mut FILE;
    static mut __stderrp: *mut FILE;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn vfprintf(
        _: *mut FILE,
        _: *const ::core::ffi::c_char,
        _: va_list,
    ) -> ::core::ffi::c_int;
    fn getline(
        __linep: *mut *mut ::core::ffi::c_char,
        __linecapp: *mut size_t,
        __stream: *mut FILE,
    ) -> ssize_t;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn exit(_: ::core::ffi::c_int) -> !;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn rangeListToString(
        buf: *mut ::core::ffi::c_char,
        bufsize: uint32_t,
        startOfList: *mut rangeElement,
    ) -> *mut ::core::ffi::c_char;
    fn parseIntRanges(text: *const ::core::ffi::c_char) -> *mut rangeElement;
    fn csvline_getFieldCnt(cline: *mut csvline) -> size_t;
    fn csvline_getField(cline: *mut csvline, idx: size_t) -> *mut ::core::ffi::c_char;
    fn csvline_printToFile(cline: *mut csvline, fp: *mut FILE);
    fn csvline_create() -> *mut csvline;
    fn csvline_addField(
        cline: *mut csvline,
        txtfield: *const ::core::ffi::c_char,
        fieldstartidx: ::core::ffi::c_int,
        fieldlen: ::core::ffi::c_int,
    );
    fn csvline_appendField(
        cline: *mut csvline,
        txtfield: *const ::core::ffi::c_char,
        fieldstartidx: ::core::ffi::c_int,
        fieldlen: ::core::ffi::c_int,
    );
}
pub type __builtin_va_list = *mut ::core::ffi::c_char;
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_va_list = __builtin_va_list;
pub type __darwin_ssize_t = isize;
pub type __darwin_off_t = __int64_t;
pub type int32_t = i32;
pub type va_list = __darwin_va_list;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type ssize_t = __darwin_ssize_t;
pub type uint32_t = u32;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct rangeElement {
    pub start: uint32_t,
    pub end: uint32_t,
    pub rangetype: C2RustUnnamed,
    pub next: *mut rangeElement,
}
pub type C2RustUnnamed = ::core::ffi::c_uint;
pub const GREATEREQUAL: C2RustUnnamed = 3;
pub const STARTEND: C2RustUnnamed = 2;
pub const SINGLE: C2RustUnnamed = 1;
pub const EMPTY: C2RustUnnamed = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct csvline {
    pub field: *mut *mut csvfield,
    pub fieldsize: size_t,
    pub currentIdx: size_t,
    pub eolStr: *mut ::core::ffi::c_char,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const BUFSIZE: ::core::ffi::c_int = 4096 as ::core::ffi::c_int;
pub const MAXCOL: ::core::ffi::c_int = 1024 as ::core::ffi::c_int;
#[no_mangle]
pub static mut gLineCnt: int32_t = 0;
#[no_mangle]
pub static mut gpInput: *mut FILE = 0 as *const FILE as *mut FILE;
#[no_mangle]
pub static mut gpOutput: *mut FILE = 0 as *const FILE as *mut FILE;
#[no_mangle]
pub static mut gpDelimIn: ::core::ffi::c_char = 0;
#[no_mangle]
pub static mut gpDelimOut: ::core::ffi::c_char = 0;
#[no_mangle]
pub static mut gpQuoteIn: ::core::ffi::c_char = 0;
#[no_mangle]
pub static mut gpQuoteOut: ::core::ffi::c_char = 0;
#[no_mangle]
pub static mut gpEndLine: *mut ::core::ffi::c_char = 0 as *const ::core::ffi::c_char
    as *mut ::core::ffi::c_char;
#[no_mangle]
pub static mut gpAllowBinaryFlag: bool = false_0 != 0;
#[no_mangle]
pub static mut gpVerbose: ::core::ffi::c_int = 0;
#[no_mangle]
pub static mut gpOutColumns: *mut rangeElement = 0 as *const rangeElement
    as *mut rangeElement;
#[no_mangle]
pub static mut rvStateNormal: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
#[no_mangle]
pub static mut rvStateMultiline: ::core::ffi::c_int = 0x1 as ::core::ffi::c_int;
#[no_mangle]
pub static mut rvStateEOL: ::core::ffi::c_int = 0x2 as ::core::ffi::c_int;
#[no_mangle]
pub static mut rvDelim: ::core::ffi::c_int = 0x4 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn usage(mut fp: *mut FILE) {
    let mut help: *mut ::core::ffi::c_char = b"cissy [options]\n\t-i <inputfile>\t\t (defaults to stdin)\n\t-o <outputfile>\t\t (defaults to stdout)\n\n\t-c <columns>\t\t specify columns to output eg. [2][5-8][12-]\n\t-d <delimiter>\t\t set the input and output delimiter\n\t\t\t\t defaults to ','\n\t-di <input delimiter>\t set the input delimiter\n\t-do <output delimiter>\t set the output delimiter\n\n\t-q <quote character>\t defaults to \"\n\t-qi <quote input character>\n\t-qo <quote output character>\n\n\t-ed \t\t\t dos end of line \\r\\n\n\t-eu \t\t\t unix end of line \\n\n\t-em \t\t\t mac end of line \\r\n\n\t-b \t\t\t allow binary data\n\t-v \t\t\t send processing info to stderr\n\t-h \t\t\t help\n\0"
        as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char;
    fprintf(fp, help, NULL);
}
#[no_mangle]
pub unsafe extern "C" fn debug(
    mut level: ::core::ffi::c_int,
    mut fmt: *mut ::core::ffi::c_char,
    mut args: ...
) {
    if level <= gpVerbose {
        let mut args_0: va_list = 0 as *mut ::core::ffi::c_char;
        args_0 = args.clone();
        vfprintf(__stderrp, fmt, args_0 as va_list);
    }
}
#[no_mangle]
pub unsafe extern "C" fn isBinChar(mut c: ::core::ffi::c_char) -> bool {
    match c as ::core::ffi::c_int {
        1 | 11 | 12 | 14 | 28 | 127 => return true_0 != 0,
        _ => {}
    }
    return false_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn formatOutput(mut str: *mut *mut ::core::ffi::c_char) {
    debug(
        100 as ::core::ffi::c_int,
        b"formatOutput:start\n\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_char,
    );
    if gpQuoteIn as ::core::ffi::c_int == gpQuoteOut as ::core::ffi::c_int {
        return;
    }
    let mut slen: ::core::ffi::c_int = strlen(*str) as ::core::ffi::c_int;
    if slen < 2 as ::core::ffi::c_int {
        return;
    }
    debug(
        100 as ::core::ffi::c_int,
        b"formatOutput:slen(%d)\n\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_char,
        slen,
    );
    debug(
        100 as ::core::ffi::c_int,
        b"formatOutput:str[%d](%c) str[%d](%c)\n\0" as *const u8
            as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
        0 as ::core::ffi::c_int,
        *(*str).offset(0 as ::core::ffi::c_int as isize) as ::core::ffi::c_int,
        slen - 1 as ::core::ffi::c_int,
        *(*str).offset(2 as ::core::ffi::c_int as isize) as ::core::ffi::c_int,
    );
    if *(*str).offset(0 as ::core::ffi::c_int as isize) as ::core::ffi::c_int
        == gpQuoteIn as ::core::ffi::c_int
        && *(*str).offset((slen - 1 as ::core::ffi::c_int) as isize)
            as ::core::ffi::c_int == gpQuoteIn as ::core::ffi::c_int
    {
        debug(
            100 as ::core::ffi::c_int,
            b"formatOutput:quoted\n\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char,
        );
        *(*str).offset(0 as ::core::ffi::c_int as isize) = gpQuoteOut;
        *(*str).offset((slen - 1 as ::core::ffi::c_int) as isize) = gpQuoteOut;
    }
}
#[no_mangle]
pub unsafe extern "C" fn outputLine(mut cline: *mut csvline) {
    debug(
        50 as ::core::ffi::c_int,
        b"outputLine:start\n\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_char,
    );
    if cline.is_null() {
        return;
    }
    if gpOutColumns.is_null() {
        debug(
            50 as ::core::ffi::c_int,
            b"outputLine:printall\n\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char,
        );
        let mut fieldcnt: ::core::ffi::c_int = csvline_getFieldCnt(cline)
            as ::core::ffi::c_int;
        let mut i: ::core::ffi::c_int = 0;
        i = 0 as ::core::ffi::c_int;
        while i < fieldcnt {
            let mut str: *mut ::core::ffi::c_char = csvline_getField(cline, i as size_t);
            formatOutput(&mut str);
            fprintf(gpOutput, b"%s\0" as *const u8 as *const ::core::ffi::c_char, str);
            if i + 1 as ::core::ffi::c_int != fieldcnt {
                fprintf(
                    gpOutput,
                    b"%c\0" as *const u8 as *const ::core::ffi::c_char,
                    gpDelimOut as ::core::ffi::c_int,
                );
            }
            i += 1;
        }
    } else {
        debug(
            50 as ::core::ffi::c_int,
            b"outputLine:printranges\n\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char,
        );
        let mut list: *mut rangeElement = gpOutColumns;
        let mut colCnt: ::core::ffi::c_int = csvline_getFieldCnt(cline)
            as ::core::ffi::c_int;
        loop {
            let mut str_0: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
            match (*list).rangetype as ::core::ffi::c_uint {
                0 => {}
                1 => {
                    debug(
                        50 as ::core::ffi::c_int,
                        b"outputLine:single(%d)\n\0" as *const u8
                            as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
                        (*list).start,
                    );
                    str_0 = csvline_getField(
                        cline,
                        (*list).start.wrapping_sub(1 as uint32_t) as size_t,
                    );
                    formatOutput(&mut str_0);
                    if !(strlen(str_0) == 0 as size_t) {
                        fprintf(
                            gpOutput,
                            b"%s\0" as *const u8 as *const ::core::ffi::c_char,
                            str_0,
                        );
                    }
                    if !(*list).next.is_null() {
                        fprintf(
                            gpOutput,
                            b"%c\0" as *const u8 as *const ::core::ffi::c_char,
                            gpDelimOut as ::core::ffi::c_int,
                        );
                    }
                }
                2 => {
                    debug(
                        50 as ::core::ffi::c_int,
                        b"outputLine:startend (%d - %d)\n\0" as *const u8
                            as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
                        (*list).start,
                        (*list).end,
                    );
                    let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                    let mut str_1: *mut ::core::ffi::c_char = 0
                        as *mut ::core::ffi::c_char;
                    i_0 = (*list).start.wrapping_sub(1 as uint32_t)
                        as ::core::ffi::c_int;
                    while ((i_0 + 1 as ::core::ffi::c_int) as uint32_t) < (*list).end {
                        str_1 = csvline_getField(cline, i_0 as size_t);
                        formatOutput(&mut str_1);
                        if strlen(str_1) == 0 as size_t {
                            fprintf(
                                gpOutput,
                                b"%c\0" as *const u8 as *const ::core::ffi::c_char,
                                gpDelimOut as ::core::ffi::c_int,
                            );
                        } else {
                            fprintf(
                                gpOutput,
                                b"%s%c\0" as *const u8 as *const ::core::ffi::c_char,
                                str_1,
                                gpDelimOut as ::core::ffi::c_int,
                            );
                        }
                        i_0 += 1;
                    }
                    let mut last: ::core::ffi::c_int = (*list)
                        .end
                        .wrapping_sub(1 as uint32_t) as ::core::ffi::c_int;
                    if !(last >= colCnt) {
                        str_1 = csvline_getField(cline, last as size_t);
                        formatOutput(&mut str_1);
                        if !(strlen(str_1) == 0 as size_t) {
                            fprintf(
                                gpOutput,
                                b"%s\0" as *const u8 as *const ::core::ffi::c_char,
                                str_1,
                            );
                        }
                        if !(*list).next.is_null() {
                            fprintf(
                                gpOutput,
                                b"%c\0" as *const u8 as *const ::core::ffi::c_char,
                                gpDelimOut as ::core::ffi::c_int,
                            );
                        }
                    }
                }
                3 => {
                    debug(
                        50 as ::core::ffi::c_int,
                        b"outputLine:greaterequal\n\0" as *const u8
                            as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
                    );
                    let mut i_1: ::core::ffi::c_int = 0;
                    let mut str_2: *mut ::core::ffi::c_char = b"\0" as *const u8
                        as *const ::core::ffi::c_char as *mut ::core::ffi::c_char;
                    i_1 = (*list).start.wrapping_sub(1 as uint32_t)
                        as ::core::ffi::c_int;
                    while (i_1 + 1 as ::core::ffi::c_int) < colCnt {
                        str_2 = csvline_getField(cline, i_1 as size_t);
                        formatOutput(&mut str_2);
                        if !(strlen(str_2) == 0 as size_t) {
                            fprintf(
                                gpOutput,
                                b"%s%c\0" as *const u8 as *const ::core::ffi::c_char,
                                str_2,
                                gpDelimOut as ::core::ffi::c_int,
                            );
                        }
                        i_1 += 1;
                    }
                    let mut last_0: ::core::ffi::c_int = colCnt
                        - 1 as ::core::ffi::c_int;
                    str_2 = csvline_getField(cline, last_0 as size_t);
                    formatOutput(&mut str_2);
                    if !(strlen(str_2) == 0 as size_t) {
                        fprintf(
                            gpOutput,
                            b"%s\0" as *const u8 as *const ::core::ffi::c_char,
                            str_2,
                        );
                    }
                    if !(*list).next.is_null() {
                        fprintf(
                            gpOutput,
                            b"%c\0" as *const u8 as *const ::core::ffi::c_char,
                            gpDelimOut as ::core::ffi::c_int,
                        );
                    }
                }
                _ => {
                    debug(
                        50 as ::core::ffi::c_int,
                        b"outputLine:default (error)\n\0" as *const u8
                            as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
                    );
                }
            }
            list = (*list).next;
            if list.is_null() {
                break;
            }
        }
    }
    fprintf(
        gpOutput,
        b"%s\0" as *const u8 as *const ::core::ffi::c_char,
        if gpEndLine.is_null() { (*cline).eolStr } else { gpEndLine },
    );
    debug(
        50 as ::core::ffi::c_int,
        b"outputLine:end\n\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_char,
    );
}
#[no_mangle]
pub unsafe extern "C" fn getField(
    mut buf: *mut ::core::ffi::c_char,
    mut buflen: ::core::ffi::c_int,
    mut end: *mut ::core::ffi::c_int,
    mut inQuoted: *mut bool,
) -> ::core::ffi::c_int {
    let mut bquoted: bool = *inQuoted;
    *end = 0 as ::core::ffi::c_int;
    while *end < buflen {
        let mut c: ::core::ffi::c_char = *buf.offset(*end as isize);
        if !gpAllowBinaryFlag && isBinChar(c) as ::core::ffi::c_int != 0 {
            fprintf(
                __stderrp,
                b"error: line(%d): binary character (%d) found.  Use flag to ignore/pass\n\0"
                    as *const u8 as *const ::core::ffi::c_char,
                gLineCnt,
                c as ::core::ffi::c_int,
            );
            exit(-(1 as ::core::ffi::c_int));
        }
        if *inQuoted {
            if c as ::core::ffi::c_int == gpQuoteIn as ::core::ffi::c_int {
                *inQuoted = false_0 != 0;
            }
        } else {
            if c as ::core::ffi::c_int == gpQuoteIn as ::core::ffi::c_int {
                *inQuoted = true_0 != 0;
            }
            if c as ::core::ffi::c_int == gpDelimIn as ::core::ffi::c_int {
                return rvDelim;
            }
            if c as ::core::ffi::c_int == '\r' as i32 {
                return rvStateEOL;
            }
            if c as ::core::ffi::c_int == '\n' as i32 {
                return rvStateEOL;
            }
            if c as ::core::ffi::c_int == '\0' as i32
                && *end == buflen - 1 as ::core::ffi::c_int
            {
                return rvStateEOL;
            }
        }
        *end += 1 as ::core::ffi::c_int;
    }
    return rvStateEOL;
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    gpInput = __stdinp;
    gpOutput = __stdoutp;
    gpDelimIn = ',' as i32 as ::core::ffi::c_char;
    gpDelimOut = ',' as i32 as ::core::ffi::c_char;
    gpQuoteIn = '"' as i32 as ::core::ffi::c_char;
    gpQuoteOut = '"' as i32 as ::core::ffi::c_char;
    gpEndLine = 0 as *mut ::core::ffi::c_char;
    gpVerbose = 0 as ::core::ffi::c_int;
    let mut arginc: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    while arginc < argc {
        debug(
            5 as ::core::ffi::c_int,
            b"argc=(%d) arginc=(%d)  argv[arginc]=(%s)\n\0" as *const u8
                as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
            argc,
            arginc,
            *argv.offset(arginc as isize),
        );
        if strcmp(
            *argv.offset(arginc as isize),
            b"-i\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        {
            if argc <= arginc + 1 as ::core::ffi::c_int {
                fprintf(
                    __stderrp,
                    b"error: missing argument for '%s'\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    *argv.offset(arginc as isize),
                );
                return -(1 as ::core::ffi::c_int);
            }
            arginc += 1;
            debug(
                5 as ::core::ffi::c_int,
                b"arg %s\n\0" as *const u8 as *const ::core::ffi::c_char
                    as *mut ::core::ffi::c_char,
                *argv.offset(arginc as isize),
            );
            gpInput = fopen(
                *argv.offset(arginc as isize),
                b"r\0" as *const u8 as *const ::core::ffi::c_char,
            ) as *mut FILE;
            if gpInput.is_null() {
                fprintf(
                    __stderrp,
                    b"error: unable to open (%s) for gpInput\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    *argv.offset(arginc as isize),
                );
                return -(1 as ::core::ffi::c_int);
            }
            arginc += 1;
        } else if strcmp(
            *argv.offset(arginc as isize),
            b"-o\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        {
            if argc <= arginc + 1 as ::core::ffi::c_int {
                fprintf(
                    __stderrp,
                    b"error: missing argument for '%s'\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    *argv.offset(arginc as isize),
                );
                return -(1 as ::core::ffi::c_int);
            }
            arginc += 1;
            debug(
                5 as ::core::ffi::c_int,
                b"arg %s\n\0" as *const u8 as *const ::core::ffi::c_char
                    as *mut ::core::ffi::c_char,
                *argv.offset(arginc as isize),
            );
            gpOutput = fopen(
                *argv.offset(arginc as isize),
                b"r\0" as *const u8 as *const ::core::ffi::c_char,
            ) as *mut FILE;
            if gpOutput.is_null() {
                fprintf(
                    __stderrp,
                    b"error: unable to open (%s) for gpInput\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    *argv.offset(arginc as isize),
                );
                return -(1 as ::core::ffi::c_int);
            }
            arginc += 1;
        } else if strcmp(
            *argv.offset(arginc as isize),
            b"-d\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        {
            if argc <= arginc + 1 as ::core::ffi::c_int {
                fprintf(
                    __stderrp,
                    b"error: missing argument for '%s'\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    *argv.offset(arginc as isize),
                );
                return -(1 as ::core::ffi::c_int);
            }
            arginc += 1;
            if strlen(*argv.offset(arginc as isize)) != 1 as size_t {
                fprintf(
                    __stderrp,
                    b"error: only single character delimiters allowed: '%s'\n\0"
                        as *const u8 as *const ::core::ffi::c_char,
                    *argv.offset(arginc as isize),
                );
                return -(1 as ::core::ffi::c_int);
            }
            debug(
                5 as ::core::ffi::c_int,
                b"arg %s %d\n\0" as *const u8 as *const ::core::ffi::c_char
                    as *mut ::core::ffi::c_char,
                *argv.offset(arginc as isize),
                strlen(*argv.offset(arginc as isize)),
            );
            gpDelimIn = *(*argv.offset(arginc as isize))
                .offset(0 as ::core::ffi::c_int as isize);
            gpDelimOut = *(*argv.offset(arginc as isize))
                .offset(0 as ::core::ffi::c_int as isize);
            arginc += 1;
        } else if strcmp(
            *argv.offset(arginc as isize),
            b"-di\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        {
            if argc <= arginc + 1 as ::core::ffi::c_int {
                fprintf(
                    __stderrp,
                    b"error: missing argument for '%s'\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    *argv.offset(arginc as isize),
                );
                return -(1 as ::core::ffi::c_int);
            }
            arginc += 1;
            if strlen(*argv.offset(arginc as isize)) != 1 as size_t {
                fprintf(
                    __stderrp,
                    b"error: only single character delimiters allowed: '%s'\n\0"
                        as *const u8 as *const ::core::ffi::c_char,
                    *argv.offset(arginc as isize),
                );
                return -(1 as ::core::ffi::c_int);
            }
            debug(
                5 as ::core::ffi::c_int,
                b"arg %s %d\n\0" as *const u8 as *const ::core::ffi::c_char
                    as *mut ::core::ffi::c_char,
                *argv.offset(arginc as isize),
                strlen(*argv.offset(arginc as isize)),
            );
            gpDelimIn = *(*argv.offset(arginc as isize))
                .offset(0 as ::core::ffi::c_int as isize);
            arginc += 1;
        } else if strcmp(
            *argv.offset(arginc as isize),
            b"-do\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        {
            if argc <= arginc + 1 as ::core::ffi::c_int {
                fprintf(
                    __stderrp,
                    b"error: missing argument for '%s'\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    *argv.offset(arginc as isize),
                );
                return -(1 as ::core::ffi::c_int);
            }
            arginc += 1;
            if strlen(*argv.offset(arginc as isize)) != 1 as size_t {
                fprintf(
                    __stderrp,
                    b"error: only single character delimiters allowed: '%s'\n\0"
                        as *const u8 as *const ::core::ffi::c_char,
                    *argv.offset(arginc as isize),
                );
                return -(1 as ::core::ffi::c_int);
            }
            debug(
                5 as ::core::ffi::c_int,
                b"arg %s %d\n\0" as *const u8 as *const ::core::ffi::c_char
                    as *mut ::core::ffi::c_char,
                *argv.offset(arginc as isize),
                strlen(*argv.offset(arginc as isize)),
            );
            gpDelimOut = *(*argv.offset(arginc as isize))
                .offset(0 as ::core::ffi::c_int as isize);
            arginc += 1;
        } else if strcmp(
            *argv.offset(arginc as isize),
            b"-q\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        {
            if argc <= arginc + 1 as ::core::ffi::c_int {
                fprintf(
                    __stderrp,
                    b"error: missing argument for '%s'\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    *argv.offset(arginc as isize),
                );
                return -(1 as ::core::ffi::c_int);
            }
            arginc += 1;
            debug(
                5 as ::core::ffi::c_int,
                b"arg %s %d\n\0" as *const u8 as *const ::core::ffi::c_char
                    as *mut ::core::ffi::c_char,
                *argv.offset(arginc as isize),
                strlen(*argv.offset(arginc as isize)),
            );
            gpQuoteIn = *(*argv.offset(arginc as isize))
                .offset(0 as ::core::ffi::c_int as isize);
            arginc += 1;
        } else if strcmp(
            *argv.offset(arginc as isize),
            b"-qi\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        {
            if argc <= arginc + 1 as ::core::ffi::c_int {
                fprintf(
                    __stderrp,
                    b"error: missing argument for '%s'\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    *argv.offset(arginc as isize),
                );
                return -(1 as ::core::ffi::c_int);
            }
            arginc += 1;
            if strlen(*argv.offset(arginc as isize)) != 1 as size_t {
                fprintf(
                    __stderrp,
                    b"error: only single character delimiters allowed: '%s'\n\0"
                        as *const u8 as *const ::core::ffi::c_char,
                    *argv.offset(arginc as isize),
                );
                return -(1 as ::core::ffi::c_int);
            }
            debug(
                5 as ::core::ffi::c_int,
                b"arg %s %d\n\0" as *const u8 as *const ::core::ffi::c_char
                    as *mut ::core::ffi::c_char,
                *argv.offset(arginc as isize),
                strlen(*argv.offset(arginc as isize)),
            );
            gpQuoteIn = *(*argv.offset(arginc as isize))
                .offset(0 as ::core::ffi::c_int as isize);
            arginc += 1;
        } else if strcmp(
            *argv.offset(arginc as isize),
            b"-qo\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        {
            if argc <= arginc + 1 as ::core::ffi::c_int {
                fprintf(
                    __stderrp,
                    b"error: missing argument for '%s'\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    *argv.offset(arginc as isize),
                );
                return -(1 as ::core::ffi::c_int);
            }
            arginc += 1;
            if strlen(*argv.offset(arginc as isize)) != 1 as size_t {
                fprintf(
                    __stderrp,
                    b"error: only single character delimiters allowed: '%s'\n\0"
                        as *const u8 as *const ::core::ffi::c_char,
                    *argv.offset(arginc as isize),
                );
                return -(1 as ::core::ffi::c_int);
            }
            debug(
                5 as ::core::ffi::c_int,
                b"arg %s %d\n\0" as *const u8 as *const ::core::ffi::c_char
                    as *mut ::core::ffi::c_char,
                *argv.offset(arginc as isize),
                strlen(*argv.offset(arginc as isize)),
            );
            gpQuoteOut = *(*argv.offset(arginc as isize))
                .offset(0 as ::core::ffi::c_int as isize);
            arginc += 1;
        } else if strcmp(
            *argv.offset(arginc as isize),
            b"-eu\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        {
            gpEndLine = b"\n\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
            arginc += 1;
        } else if strcmp(
            *argv.offset(arginc as isize),
            b"-ed\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        {
            gpEndLine = b"\r\n\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
            arginc += 1;
        } else if strcmp(
            *argv.offset(arginc as isize),
            b"-em\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        {
            gpEndLine = b"\r\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
            arginc += 1;
        } else if strcmp(
            *argv.offset(arginc as isize),
            b"-c\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        {
            if argc <= arginc + 1 as ::core::ffi::c_int {
                fprintf(
                    __stderrp,
                    b"error: missing argument for '%s'\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    *argv.offset(arginc as isize),
                );
                return -(1 as ::core::ffi::c_int);
            }
            arginc += 1;
            debug(
                5 as ::core::ffi::c_int,
                b"arg %s %d\n\0" as *const u8 as *const ::core::ffi::c_char
                    as *mut ::core::ffi::c_char,
                *argv.offset(arginc as isize),
                strlen(*argv.offset(arginc as isize)),
            );
            gpOutColumns = parseIntRanges(*argv.offset(arginc as isize));
            arginc += 1;
        } else if strcmp(
            *argv.offset(arginc as isize),
            b"-h\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        {
            usage(__stdoutp);
            exit(0 as ::core::ffi::c_int);
        } else if strcmp(
            *argv.offset(arginc as isize),
            b"-v\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        {
            gpVerbose += 1;
            arginc += 1;
        } else if strcmp(
            *argv.offset(arginc as isize),
            b"-DDD\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        {
            gpVerbose += 100 as ::core::ffi::c_int;
            arginc += 1;
        } else if strcmp(
            *argv.offset(arginc as isize),
            b"-b\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        {
            gpAllowBinaryFlag = true_0 != 0;
            arginc += 1;
        } else {
            fprintf(
                __stderrp,
                b"error: unknown switch (%s)\n\0" as *const u8
                    as *const ::core::ffi::c_char,
                *argv.offset(arginc as isize),
            );
            fclose(gpInput);
            fclose(gpOutput);
            return -(1 as ::core::ffi::c_int);
        }
    }
    debug(
        5 as ::core::ffi::c_int,
        b"main: input delimiter(%c) output delimiter(%c)\n\0" as *const u8
            as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
        gpDelimIn as ::core::ffi::c_int,
        gpDelimOut as ::core::ffi::c_int,
    );
    debug(
        5 as ::core::ffi::c_int,
        b"main: input quote(%c) output quote(%c)\n\0" as *const u8
            as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
        gpQuoteIn as ::core::ffi::c_int,
        gpQuoteOut as ::core::ffi::c_int,
    );
    let mut sbuf: [::core::ffi::c_char; 1024] = [0; 1024];
    debug(
        5 as ::core::ffi::c_int,
        b"main: OutputColumns = %s\n\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_char,
        rangeListToString(
            sbuf.as_mut_ptr(),
            ::core::mem::size_of::<[::core::ffi::c_char; 1024]>() as uint32_t,
            gpOutColumns,
        ),
    );
    debug(
        5 as ::core::ffi::c_int,
        b"main:start\n\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_char,
    );
    let mut psAccumFlag: ::core::ffi::c_int = 0x1 as ::core::ffi::c_int;
    let mut psBeginFlag: ::core::ffi::c_int = 0x2 as ::core::ffi::c_int;
    let mut psQuotedFlag: ::core::ffi::c_int = 0x4 as ::core::ffi::c_int;
    let mut parseState: ::core::ffi::c_int = psBeginFlag;
    let mut colData: [::core::ffi::c_char; 4096] = [0; 4096];
    let mut colDataLen: [size_t; 1024] = [0; 1024];
    let mut colPtr: [*mut ::core::ffi::c_char; 1024] = [0
        as *mut ::core::ffi::c_char; 1024];
    memset(
        colData.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        BUFSIZE as size_t,
    );
    let mut i: ::core::ffi::c_int = 0;
    i = 0 as ::core::ffi::c_int;
    while i < MAXCOL {
        colPtr[i as usize] = 0 as *mut ::core::ffi::c_char;
        colDataLen[i as usize] = 0 as size_t;
        i += 1;
    }
    let mut rawInput: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut rawInputSize: size_t = 128 as size_t;
    rawInput = malloc(rawInputSize) as *mut ::core::ffi::c_char;
    if rawInput.is_null() {
        fprintf(
            __stderrp,
            b"main: rawInput malloc error\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        exit(-(1 as ::core::ffi::c_int));
    }
    let mut bdone: bool = false_0 != 0;
    gLineCnt = 0 as ::core::ffi::c_int as int32_t;
    while !bdone {
        let mut cline: *mut csvline = csvline_create();
        memset(
            rawInput as *mut ::core::ffi::c_void,
            0 as ::core::ffi::c_int,
            rawInputSize,
        );
        let mut c: ::core::ffi::c_int = getline(
            &mut rawInput,
            &mut rawInputSize,
            gpInput,
        ) as ::core::ffi::c_int;
        gLineCnt += 1;
        debug(
            5 as ::core::ffi::c_int,
            b"main: line(%d) read (%d) bytes\n\0" as *const u8
                as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
            gLineCnt,
            c,
        );
        if c == -(1 as ::core::ffi::c_int) || c == 0 as ::core::ffi::c_int {
            debug(
                10 as ::core::ffi::c_int,
                b"main: EOF\n\0" as *const u8 as *const ::core::ffi::c_char
                    as *mut ::core::ffi::c_char,
            );
            fclose(gpInput);
            fclose(gpOutput);
            return 0 as ::core::ffi::c_int;
        }
        let mut startIdx: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        let mut fieldLen: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        let mut bufsize: ::core::ffi::c_int = c - startIdx;
        let mut bline: bool = false_0 != 0;
        let mut d: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        let mut bInsideQuote: bool = false_0 != 0;
        let mut appendMode: bool = false_0 != 0;
        while !bline {
            let mut parseState_0: ::core::ffi::c_int = getField(
                &mut *rawInput.offset(startIdx as isize),
                bufsize - startIdx,
                &mut fieldLen,
                &mut bInsideQuote,
            );
            debug(
                50 as ::core::ffi::c_int,
                b"s(%d)e(%d) (%d)\n\0" as *const u8 as *const ::core::ffi::c_char
                    as *mut ::core::ffi::c_char,
                startIdx,
                fieldLen,
                bInsideQuote as ::core::ffi::c_int,
            );
            if appendMode {
                csvline_appendField(cline, rawInput, startIdx, fieldLen);
            } else {
                csvline_addField(cline, rawInput, startIdx, fieldLen);
            }
            startIdx += fieldLen;
            if parseState_0 == rvDelim {
                startIdx += 1;
            }
            appendMode = bInsideQuote;
            if parseState_0 == rvStateEOL {
                if bInsideQuote {
                    c = getline(&mut rawInput, &mut rawInputSize, gpInput)
                        as ::core::ffi::c_int;
                    if c == -(1 as ::core::ffi::c_int) || c == 0 as ::core::ffi::c_int {
                        fprintf(
                            __stderrp,
                            b"error: unterminated quote\n\0" as *const u8
                                as *const ::core::ffi::c_char,
                        );
                        fclose(gpInput);
                        fclose(gpOutput);
                        exit(-(1 as ::core::ffi::c_int));
                    }
                    startIdx = 0 as ::core::ffi::c_int;
                    fieldLen = 0 as ::core::ffi::c_int;
                    bufsize = c - startIdx;
                } else {
                    bline = true_0 != 0;
                }
            }
        }
        if gpVerbose > 2 as ::core::ffi::c_int {
            csvline_printToFile(cline, __stderrp);
        }
        outputLine(cline);
    }
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
