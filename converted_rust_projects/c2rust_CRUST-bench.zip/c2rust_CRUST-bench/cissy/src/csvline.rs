#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn exit(_: ::core::ffi::c_int) -> !;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn csvfield_create() -> *mut csvfield;
    fn csvfield_reset(pField: *mut csvfield);
    fn csvfield_set(
        pField: *mut csvfield,
        buf: *const ::core::ffi::c_char,
        bufStartIdx: ::core::ffi::c_int,
        len: ::core::ffi::c_int,
    );
    fn csvfield_append(
        pField: *mut csvfield,
        buf: *const ::core::ffi::c_char,
        bufStartIdx: ::core::ffi::c_int,
        buflen: ::core::ffi::c_int,
    );
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct csvline {
    pub field: *mut *mut csvfield,
    pub fieldsize: size_t,
    pub currentIdx: size_t,
    pub eolStr: *mut ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct csvfield {
    pub data: *mut ::core::ffi::c_char,
    pub len: size_t,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn csvline_getFieldCnt(mut cline: *mut csvline) -> size_t {
    return (*cline).currentIdx;
}
#[no_mangle]
pub unsafe extern "C" fn csvline_getField(
    mut cline: *mut csvline,
    mut idx: size_t,
) -> *mut ::core::ffi::c_char {
    if idx >= (*cline).currentIdx {
        return b"\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_char;
    }
    return (**(*cline).field.offset(idx as isize)).data;
}
#[no_mangle]
pub unsafe extern "C" fn csvline_reset(mut ptr: *mut csvline) {
    let mut i: ::core::ffi::c_int = 0;
    i = 0 as ::core::ffi::c_int;
    while (i as size_t) < (*ptr).fieldsize {
        if !(*(*ptr).field.offset(i as isize)).is_null() {
            csvfield_reset(*(*ptr).field.offset(i as isize));
        }
        i += 1;
    }
    (*ptr).currentIdx = 0 as size_t;
    (*ptr).eolStr = b"\n\0" as *const u8 as *const ::core::ffi::c_char
        as *mut ::core::ffi::c_char;
}
#[no_mangle]
pub unsafe extern "C" fn csvline_create() -> *mut csvline {
    let mut ptr: *mut csvline = malloc(::core::mem::size_of::<csvline>() as size_t)
        as *mut csvline;
    if ptr.is_null() {
        fprintf(
            __stderrp,
            b"error: malloc\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        exit(-(1 as ::core::ffi::c_int));
    }
    (*ptr).field = 0 as *mut *mut csvfield;
    (*ptr).fieldsize = 0 as size_t;
    (*ptr).currentIdx = 0 as size_t;
    (*ptr).eolStr = b"\n\0" as *const u8 as *const ::core::ffi::c_char
        as *mut ::core::ffi::c_char;
    return ptr;
}
#[no_mangle]
pub unsafe extern "C" fn csvline_printToFile(mut ptr: *mut csvline, mut fp: *mut FILE) {
    fprintf(fp, b"[[\0" as *const u8 as *const ::core::ffi::c_char);
    let mut i: ::core::ffi::c_int = 0;
    i = 0 as ::core::ffi::c_int;
    while (i as size_t) < (*ptr).fieldsize {
        fprintf(
            __stderrp,
            b"[%s:%d]\0" as *const u8 as *const ::core::ffi::c_char,
            (**(*ptr).field.offset(i as isize)).data,
            (**(*ptr).field.offset(i as isize)).len as ::core::ffi::c_int,
        );
        i += 1;
    }
    fprintf(fp, b"]\0" as *const u8 as *const ::core::ffi::c_char);
    fprintf(
        fp,
        b"fs(%d):\0" as *const u8 as *const ::core::ffi::c_char,
        (*ptr).fieldsize as ::core::ffi::c_int,
    );
    fprintf(
        fp,
        b"i(%d)\0" as *const u8 as *const ::core::ffi::c_char,
        (*ptr).currentIdx as ::core::ffi::c_int,
    );
    fprintf(fp, b"]\n\0" as *const u8 as *const ::core::ffi::c_char);
}
#[no_mangle]
pub unsafe extern "C" fn csvline_addField(
    mut cline: *mut csvline,
    mut txtfield: *const ::core::ffi::c_char,
    mut fieldstartidx: ::core::ffi::c_int,
    mut fieldlen: ::core::ffi::c_int,
) {
    if (*cline).fieldsize <= (*cline).currentIdx {
        let mut tmp: *mut *mut csvfield = (*cline).field as *mut *mut csvfield;
        (*cline).field = malloc(
            (*cline)
                .fieldsize
                .wrapping_add(10 as size_t)
                .wrapping_mul(::core::mem::size_of::<*mut csvfield>() as size_t),
        ) as *mut *mut csvfield;
        if (*cline).field.is_null() {
            fprintf(
                __stderrp,
                b"error: malloc\n\0" as *const u8 as *const ::core::ffi::c_char,
            );
            exit(-(1 as ::core::ffi::c_int));
        }
        if !tmp.is_null() {
            memcpy(
                (*cline).field as *mut ::core::ffi::c_void,
                tmp as *const ::core::ffi::c_void,
                (*cline)
                    .fieldsize
                    .wrapping_mul(::core::mem::size_of::<*mut csvfield>() as size_t),
            );
            free(tmp as *mut ::core::ffi::c_void);
        }
        (*cline).fieldsize = (*cline).fieldsize.wrapping_add(10 as size_t);
        let mut i: ::core::ffi::c_int = 0;
        i = (*cline).fieldsize.wrapping_sub(10 as size_t) as ::core::ffi::c_int;
        while (i as size_t) < (*cline).fieldsize {
            let ref mut fresh0 = *(*cline).field.offset(i as isize);
            *fresh0 = csvfield_create() as *mut csvfield;
            i += 1;
        }
    }
    csvfield_set(
        *(*cline).field.offset((*cline).currentIdx as isize),
        txtfield,
        fieldstartidx,
        fieldlen,
    );
    (*cline).currentIdx = (*cline).currentIdx.wrapping_add(1);
}
#[no_mangle]
pub unsafe extern "C" fn csvline_appendField(
    mut cline: *mut csvline,
    mut txtfield: *const ::core::ffi::c_char,
    mut fieldstartidx: ::core::ffi::c_int,
    mut fieldlen: ::core::ffi::c_int,
) {
    csvfield_append(
        *(*cline).field.offset((*cline).currentIdx.wrapping_sub(1 as size_t) as isize),
        txtfield,
        fieldstartidx,
        fieldlen,
    );
}
