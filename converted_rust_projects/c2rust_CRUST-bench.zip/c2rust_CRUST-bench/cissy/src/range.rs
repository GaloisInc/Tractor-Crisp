#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn atoi(_: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
    fn exit(_: ::core::ffi::c_int) -> !;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn snprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strncat(
        __s1: *mut ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> *mut ::core::ffi::c_char;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type uint32_t = u32;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct rangeElement {
    pub start: uint32_t,
    pub end: uint32_t,
    pub rangetype: C2RustUnnamed,
    pub next: *mut rangeElement,
}
pub type C2RustUnnamed = ::core::ffi::c_uint;
pub const GREATEREQUAL: C2RustUnnamed = 3;
pub const STARTEND: C2RustUnnamed = 2;
pub const SINGLE: C2RustUnnamed = 1;
pub const EMPTY: C2RustUnnamed = 0;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn rangeFree(mut list: *mut rangeElement) {
    if list.is_null() {
        return;
    }
    let mut ptr: *mut rangeElement = list;
    while !(*ptr).next.is_null() {
        let mut ptrNext: *mut rangeElement = (*ptr).next;
        free(ptr as *mut ::core::ffi::c_void);
        ptr = ptrNext;
    }
    free(ptr as *mut ::core::ffi::c_void);
    list = 0 as *mut rangeElement;
}
#[no_mangle]
pub unsafe extern "C" fn rangeCreate() -> *mut rangeElement {
    let mut ptr: *mut rangeElement = malloc(
        ::core::mem::size_of::<rangeElement>() as size_t,
    ) as *mut rangeElement;
    if ptr.is_null() {
        fprintf(
            __stderrp,
            b"rangeCreate: malloc error\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        exit(-(1 as ::core::ffi::c_int));
    }
    (*ptr).start = -(1 as ::core::ffi::c_int) as uint32_t;
    (*ptr).end = -(1 as ::core::ffi::c_int) as uint32_t;
    (*ptr).next = 0 as *mut rangeElement;
    return ptr;
}
#[no_mangle]
pub unsafe extern "C" fn rangeAddStartEnd(
    mut start: uint32_t,
    mut end: uint32_t,
    mut startOfList: *mut rangeElement,
) -> *mut rangeElement {
    if !(start > 0 as uint32_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 17],
                [::core::ffi::c_char; 17],
            >(*b"rangeAddStartEnd\0")
                .as_ptr(),
            b"range.c\0" as *const u8 as *const ::core::ffi::c_char,
            74 as ::core::ffi::c_int,
            b"start > 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(end >= start) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 17],
                [::core::ffi::c_char; 17],
            >(*b"rangeAddStartEnd\0")
                .as_ptr(),
            b"range.c\0" as *const u8 as *const ::core::ffi::c_char,
            75 as ::core::ffi::c_int,
            b"end >= start\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if startOfList.is_null() {
        startOfList = rangeCreate();
        (*startOfList).start = start;
        if start == end {
            (*startOfList).rangetype = SINGLE;
        } else {
            (*startOfList).rangetype = STARTEND;
            (*startOfList).end = end;
        }
        return startOfList;
    }
    let mut ptr: *mut rangeElement = startOfList;
    while !(*ptr).next.is_null() {
        ptr = (*ptr).next;
    }
    (*ptr).next = rangeCreate();
    ptr = (*ptr).next;
    (*ptr).start = start;
    if end == start {
        (*ptr).rangetype = SINGLE;
    } else {
        (*ptr).rangetype = STARTEND;
        (*ptr).end = end;
    }
    return startOfList;
}
#[no_mangle]
pub unsafe extern "C" fn rangeAddGreaterEqual(
    mut num: uint32_t,
    mut startOfList: *mut rangeElement,
) -> *mut rangeElement {
    if !(num >= 0 as uint32_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 21],
                [::core::ffi::c_char; 21],
            >(*b"rangeAddGreaterEqual\0")
                .as_ptr(),
            b"range.c\0" as *const u8 as *const ::core::ffi::c_char,
            116 as ::core::ffi::c_int,
            b"num >= 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if startOfList.is_null() {
        startOfList = rangeCreate();
        (*startOfList).start = num;
        (*startOfList).rangetype = GREATEREQUAL;
        return startOfList;
    }
    let mut ptr: *mut rangeElement = startOfList;
    while !(*ptr).next.is_null() {
        ptr = (*ptr).next;
    }
    (*ptr).next = rangeCreate();
    ptr = (*ptr).next;
    (*ptr).start = num;
    (*ptr).rangetype = GREATEREQUAL;
    return startOfList;
}
#[no_mangle]
pub unsafe extern "C" fn rangeAddSingle(
    mut num: uint32_t,
    mut startOfList: *mut rangeElement,
) -> *mut rangeElement {
    if !(num > 0 as uint32_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 15],
                [::core::ffi::c_char; 15],
            >(*b"rangeAddSingle\0")
                .as_ptr(),
            b"range.c\0" as *const u8 as *const ::core::ffi::c_char,
            145 as ::core::ffi::c_int,
            b"num > 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if startOfList.is_null() {
        startOfList = rangeCreate();
        (*startOfList).start = num;
        (*startOfList).rangetype = SINGLE;
        return startOfList;
    }
    let mut ptr: *mut rangeElement = startOfList;
    while !(*ptr).next.is_null() {
        ptr = (*ptr).next;
    }
    (*ptr).next = rangeCreate();
    ptr = (*ptr).next;
    (*ptr).start = num;
    (*ptr).rangetype = SINGLE;
    return startOfList;
}
#[no_mangle]
pub unsafe extern "C" fn rangeElementToString(
    mut buf: *mut ::core::ffi::c_char,
    mut bufsize: uint32_t,
    mut element: *mut rangeElement,
) -> *mut ::core::ffi::c_char {
    if !(bufsize >= 0 as uint32_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 21],
                [::core::ffi::c_char; 21],
            >(*b"rangeElementToString\0")
                .as_ptr(),
            b"range.c\0" as *const u8 as *const ::core::ffi::c_char,
            175 as ::core::ffi::c_int,
            b"bufsize >= 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if element.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 21],
                [::core::ffi::c_char; 21],
            >(*b"rangeElementToString\0")
                .as_ptr(),
            b"range.c\0" as *const u8 as *const ::core::ffi::c_char,
            176 as ::core::ffi::c_int,
            b"element != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    match (*element).rangetype as ::core::ffi::c_uint {
        1 => {
            snprintf(
                buf,
                bufsize as size_t,
                b"[%d]\0" as *const u8 as *const ::core::ffi::c_char,
                (*element).start,
            );
            return buf;
        }
        3 => {
            snprintf(
                buf,
                bufsize as size_t,
                b"[%d-]\0" as *const u8 as *const ::core::ffi::c_char,
                (*element).start,
            );
            return buf;
        }
        2 => {
            snprintf(
                buf,
                bufsize as size_t,
                b"[%d-%d]\0" as *const u8 as *const ::core::ffi::c_char,
                (*element).start,
                (*element).end,
            );
            return buf;
        }
        0 => {
            snprintf(
                buf,
                bufsize as size_t,
                b"[]\0" as *const u8 as *const ::core::ffi::c_char,
            );
            return buf;
        }
        _ => return buf,
    };
}
#[no_mangle]
pub unsafe extern "C" fn rangeListToString(
    mut buf: *mut ::core::ffi::c_char,
    mut bufsize: uint32_t,
    mut startOfList: *mut rangeElement,
) -> *mut ::core::ffi::c_char {
    let mut tmpbufsize: ::core::ffi::c_int = 256 as ::core::ffi::c_int;
    let vla = tmpbufsize as usize;
    let mut tmpbuf: Vec<::core::ffi::c_char> = ::std::vec::from_elem(0, vla);
    let mut ptr: *mut rangeElement = startOfList;
    memset(buf as *mut ::core::ffi::c_void, 0 as ::core::ffi::c_int, bufsize as size_t);
    let mut bufidx: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while !ptr.is_null() {
        memset(
            tmpbuf.as_mut_ptr() as *mut ::core::ffi::c_void,
            0 as ::core::ffi::c_int,
            tmpbufsize as size_t,
        );
        rangeElementToString(
            &mut *tmpbuf.as_mut_ptr().offset(0 as ::core::ffi::c_int as isize),
            tmpbufsize as uint32_t,
            ptr,
        );
        let mut tblen: ::core::ffi::c_int = (vla
            * ::core::mem::size_of::<::core::ffi::c_char>()) as ::core::ffi::c_int;
        let mut copylen: ::core::ffi::c_int = (if (tblen + bufidx) as uint32_t >= bufsize
        {
            bufsize.wrapping_sub(bufidx as uint32_t)
        } else {
            tblen as uint32_t
        }) as ::core::ffi::c_int;
        strncat(buf, tmpbuf.as_mut_ptr(), copylen as size_t);
        bufidx += copylen;
        ptr = (*ptr).next;
    }
    return buf;
}
#[no_mangle]
pub unsafe extern "C" fn rangeContainsNum(
    mut num: uint32_t,
    mut startOfList: *mut rangeElement,
) -> bool {
    if startOfList.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 17],
                [::core::ffi::c_char; 17],
            >(*b"rangeContainsNum\0")
                .as_ptr(),
            b"range.c\0" as *const u8 as *const ::core::ffi::c_char,
            233 as ::core::ffi::c_int,
            b"startOfList != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(num >= 0 as uint32_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 17],
                [::core::ffi::c_char; 17],
            >(*b"rangeContainsNum\0")
                .as_ptr(),
            b"range.c\0" as *const u8 as *const ::core::ffi::c_char,
            234 as ::core::ffi::c_int,
            b"num >= 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut ptr: *mut rangeElement = startOfList;
    loop {
        if (*ptr).rangetype as ::core::ffi::c_uint
            == SINGLE as ::core::ffi::c_int as ::core::ffi::c_uint && (*ptr).start == num
        {
            return true_0 != 0;
        }
        if (*ptr).rangetype as ::core::ffi::c_uint
            == GREATEREQUAL as ::core::ffi::c_int as ::core::ffi::c_uint
            && num >= (*ptr).start
        {
            return true_0 != 0;
        }
        if (*ptr).rangetype as ::core::ffi::c_uint
            == STARTEND as ::core::ffi::c_int as ::core::ffi::c_uint
            && num >= (*ptr).start && num <= (*ptr).end
        {
            return true_0 != 0;
        }
        ptr = (*ptr).next;
        if ptr.is_null() {
            return false_0 != 0;
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn parseIntRanges(
    mut text: *const ::core::ffi::c_char,
) -> *mut rangeElement {
    let mut state: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut flag_dash: ::core::ffi::c_int = 0x1 as ::core::ffi::c_int;
    let mut i: ::core::ffi::c_int = 0;
    let mut numbuf: [::core::ffi::c_char; 1024] = [0; 1024];
    let mut numbufi: ::core::ffi::c_int = 0;
    let mut rv: *mut rangeElement = 0 as *mut rangeElement;
    let mut start: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut end: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    memset(
        numbuf.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<[::core::ffi::c_char; 1024]>() as size_t,
    );
    numbufi = 0 as ::core::ffi::c_int;
    i = 0 as ::core::ffi::c_int;
    while (i as size_t) < strlen(text) {
        if *text.offset(i as isize) as ::core::ffi::c_int >= '0' as i32
            && *text.offset(i as isize) as ::core::ffi::c_int <= '9' as i32
        {
            numbuf[numbufi as usize] = *text.offset(i as isize);
            numbufi += 1;
        } else if *text.offset(i as isize) as ::core::ffi::c_int == '-' as i32 {
            if state & flag_dash != 0 {
                fprintf(
                    __stderrp,
                    b"error: too many dashes in range\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                );
                exit(-(1 as ::core::ffi::c_int));
            }
            state |= flag_dash;
            if numbufi == 0 as ::core::ffi::c_int {
                fprintf(
                    __stderrp,
                    b"error: range cannot start with '-'\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                );
                exit(-(1 as ::core::ffi::c_int));
            }
            start = atoi(numbuf.as_mut_ptr());
            if start <= 0 as ::core::ffi::c_int {
                fprintf(
                    __stderrp,
                    b"error: start range <= 0\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                );
                exit(-(1 as ::core::ffi::c_int));
            }
            memset(
                numbuf.as_mut_ptr() as *mut ::core::ffi::c_void,
                0 as ::core::ffi::c_int,
                ::core::mem::size_of::<[::core::ffi::c_char; 1024]>() as size_t,
            );
            numbufi = 0 as ::core::ffi::c_int;
        } else if *text.offset(i as isize) as ::core::ffi::c_int == ',' as i32 {
            if numbufi == 0 as ::core::ffi::c_int {
                if flag_dash != 0 {
                    rv = rangeAddGreaterEqual(start as uint32_t, rv);
                }
            } else if start > 0 as ::core::ffi::c_int {
                end = atoi(numbuf.as_mut_ptr());
                if end <= 0 as ::core::ffi::c_int || start > end {
                    fprintf(
                        __stderrp,
                        b"error: illegal start/end ranges\n\0" as *const u8
                            as *const ::core::ffi::c_char,
                    );
                    exit(-(1 as ::core::ffi::c_int));
                }
                rv = rangeAddStartEnd(start as uint32_t, end as uint32_t, rv);
            } else {
                start = atoi(numbuf.as_mut_ptr());
                rv = rangeAddSingle(start as uint32_t, rv);
            }
            memset(
                numbuf.as_mut_ptr() as *mut ::core::ffi::c_void,
                0 as ::core::ffi::c_int,
                ::core::mem::size_of::<[::core::ffi::c_char; 1024]>() as size_t,
            );
            numbufi = 0 as ::core::ffi::c_int;
            start = 0 as ::core::ffi::c_int;
            end = 0 as ::core::ffi::c_int;
            state = 0 as ::core::ffi::c_int;
        }
        i += 1;
    }
    if numbufi == 0 as ::core::ffi::c_int {
        if flag_dash != 0 {
            rv = rangeAddGreaterEqual(start as uint32_t, rv);
        }
    } else if start > 0 as ::core::ffi::c_int {
        end = atoi(numbuf.as_mut_ptr());
        if end <= 0 as ::core::ffi::c_int || start > end {
            fprintf(
                __stderrp,
                b"error: illegal start/end range %s\n\0" as *const u8
                    as *const ::core::ffi::c_char,
                text,
            );
            exit(-(1 as ::core::ffi::c_int));
        }
        rv = rangeAddStartEnd(start as uint32_t, end as uint32_t, rv);
    } else {
        start = atoi(numbuf.as_mut_ptr());
        rv = rangeAddSingle(start as uint32_t, rv);
    }
    return rv;
}
