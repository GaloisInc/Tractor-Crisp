#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn csvfield_create() -> *mut csvfield;
    fn csvfield_reset(pField: *mut csvfield);
    fn csvfield_set(
        pField: *mut csvfield,
        buf: *const ::core::ffi::c_char,
        bufStartIdx: ::core::ffi::c_int,
        len: ::core::ffi::c_int,
    );
    fn csvfield_append(
        pField: *mut csvfield,
        buf: *const ::core::ffi::c_char,
        bufStartIdx: ::core::ffi::c_int,
        buflen: ::core::ffi::c_int,
    );
    fn csvfield_printToFile(pField: *const csvfield, fp: *mut FILE);
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct csvfield {
    pub data: *mut ::core::ffi::c_char,
    pub len: size_t,
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    printf(b"test\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut cfield: *mut csvfield = 0 as *mut csvfield;
    cfield = csvfield_create();
    csvfield_printToFile(cfield, __stderrp);
    let mut txt: [::core::ffi::c_char; 6] = ::core::mem::transmute::<
        [u8; 6],
        [::core::ffi::c_char; 6],
    >(*b"hello\0");
    csvfield_set(
        cfield,
        txt.as_mut_ptr(),
        0 as ::core::ffi::c_int,
        strlen(txt.as_mut_ptr()) as ::core::ffi::c_int,
    );
    csvfield_printToFile(cfield, __stderrp);
    let mut txt_0: [::core::ffi::c_char; 4] = ::core::mem::transmute::<
        [u8; 4],
        [::core::ffi::c_char; 4],
    >(*b"123\0");
    csvfield_set(
        cfield,
        txt_0.as_mut_ptr(),
        0 as ::core::ffi::c_int,
        strlen(txt_0.as_mut_ptr()) as ::core::ffi::c_int,
    );
    csvfield_printToFile(cfield, __stderrp);
    let mut txt_1: [::core::ffi::c_char; 28] = ::core::mem::transmute::<
        [u8; 28],
        [::core::ffi::c_char; 28],
    >(*b"123456789012345678901234567\0");
    csvfield_set(
        cfield,
        txt_1.as_mut_ptr(),
        0 as ::core::ffi::c_int,
        strlen(txt_1.as_mut_ptr()) as ::core::ffi::c_int,
    );
    csvfield_printToFile(cfield, __stderrp);
    let mut txt_2: [::core::ffi::c_char; 4] = ::core::mem::transmute::<
        [u8; 4],
        [::core::ffi::c_char; 4],
    >(*b"123\0");
    csvfield_set(
        cfield,
        txt_2.as_mut_ptr(),
        0 as ::core::ffi::c_int,
        strlen(txt_2.as_mut_ptr()) as ::core::ffi::c_int,
    );
    csvfield_append(
        cfield,
        txt_2.as_mut_ptr(),
        0 as ::core::ffi::c_int,
        strlen(txt_2.as_mut_ptr()) as ::core::ffi::c_int,
    );
    csvfield_printToFile(cfield, __stderrp);
    csvfield_reset(cfield);
    csvfield_printToFile(cfield, __stderrp);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
