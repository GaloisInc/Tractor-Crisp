#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stdoutp: *mut FILE;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn csvline_getFieldCnt(cline: *mut csvline) -> size_t;
    fn csvline_getField(cline: *mut csvline, idx: size_t) -> *mut ::core::ffi::c_char;
    fn csvline_reset(cline: *mut csvline);
    fn csvline_printToFile(cline: *mut csvline, fp: *mut FILE);
    fn csvline_create() -> *mut csvline;
    fn csvline_addField(
        cline: *mut csvline,
        txtfield: *const ::core::ffi::c_char,
        fieldstartidx: ::core::ffi::c_int,
        fieldlen: ::core::ffi::c_int,
    );
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct csvfield {
    pub data: *mut ::core::ffi::c_char,
    pub len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct csvline {
    pub field: *mut *mut csvfield,
    pub fieldsize: size_t,
    pub currentIdx: size_t,
    pub eolStr: *mut ::core::ffi::c_char,
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut txt: [::core::ffi::c_char; 6] = ::core::mem::transmute::<
        [u8; 6],
        [::core::ffi::c_char; 6],
    >(*b"hello\0");
    let mut cline: *mut csvline = csvline_create();
    let mut i: ::core::ffi::c_int = 0;
    i = 0 as ::core::ffi::c_int;
    while i < 25 as ::core::ffi::c_int {
        csvline_addField(
            cline,
            txt.as_mut_ptr(),
            0 as ::core::ffi::c_int,
            strlen(txt.as_mut_ptr()) as ::core::ffi::c_int,
        );
        csvline_printToFile(cline, __stdoutp);
        i += 1;
    }
    printf(
        b"Count = %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        csvline_getFieldCnt(cline) as ::core::ffi::c_int,
    );
    printf(
        b"1st = %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        csvline_getField(cline, 0 as size_t),
    );
    csvline_reset(cline);
    csvline_printToFile(cline, __stdoutp);
    !cline.is_null();
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
