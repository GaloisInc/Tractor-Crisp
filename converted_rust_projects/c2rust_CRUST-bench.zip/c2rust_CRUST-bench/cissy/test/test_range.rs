#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn rangeFree(list: *mut rangeElement);
    fn rangeAddSingle(
        num: uint32_t,
        startOfList: *mut rangeElement,
    ) -> *mut rangeElement;
    fn rangeAddStartEnd(
        start: uint32_t,
        end: uint32_t,
        startOfList: *mut rangeElement,
    ) -> *mut rangeElement;
    fn rangeAddGreaterEqual(
        num: uint32_t,
        startOfList: *mut rangeElement,
    ) -> *mut rangeElement;
    fn rangeContainsNum(num: uint32_t, startOfList: *mut rangeElement) -> bool;
    fn rangeElementToString(
        buf: *mut ::core::ffi::c_char,
        bufsize: uint32_t,
        element: *mut rangeElement,
    ) -> *mut ::core::ffi::c_char;
    fn rangeListToString(
        buf: *mut ::core::ffi::c_char,
        bufsize: uint32_t,
        startOfList: *mut rangeElement,
    ) -> *mut ::core::ffi::c_char;
    fn parseIntRanges(text: *const ::core::ffi::c_char) -> *mut rangeElement;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint32_t = u32;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct rangeElement {
    pub start: uint32_t,
    pub end: uint32_t,
    pub rangetype: C2RustUnnamed,
    pub next: *mut rangeElement,
}
pub type C2RustUnnamed = ::core::ffi::c_uint;
pub const GREATEREQUAL: C2RustUnnamed = 3;
pub const STARTEND: C2RustUnnamed = 2;
pub const SINGLE: C2RustUnnamed = 1;
pub const EMPTY: C2RustUnnamed = 0;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    printf(b"start\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut list: *mut rangeElement = 0 as *mut rangeElement;
    let mut b: bool = false;
    let mut bufsize: ::core::ffi::c_int = 1024 as ::core::ffi::c_int;
    let vla = bufsize as usize;
    let mut buf: Vec<::core::ffi::c_char> = ::std::vec::from_elem(0, vla);
    let mut rv: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    list = rangeAddSingle(5 as uint32_t, list);
    printf(b"list = 5\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test: not contains 4\n\0" as *const u8 as *const ::core::ffi::c_char);
    b = rangeContainsNum(4 as uint32_t, list);
    if !(b as ::core::ffi::c_int == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            23 as ::core::ffi::c_int,
            b"b == false\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test: contains 5\n\0" as *const u8 as *const ::core::ffi::c_char);
    b = rangeContainsNum(5 as uint32_t, list);
    if !(b as ::core::ffi::c_int == 1 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            28 as ::core::ffi::c_int,
            b"b == true\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test: element to string\n\0" as *const u8 as *const ::core::ffi::c_char);
    memset(
        buf.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        bufsize as size_t,
    );
    rangeElementToString(buf.as_mut_ptr(), bufsize as uint32_t, list);
    rv = b"[5]\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char;
    printf(
        b"\t%s == %s ???\0" as *const u8 as *const ::core::ffi::c_char,
        rv,
        buf.as_mut_ptr(),
    );
    if !(strcmp(rv, buf.as_mut_ptr()) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            36 as ::core::ffi::c_int,
            b"strcmp(rv, buf) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test: list to string\n\0" as *const u8 as *const ::core::ffi::c_char);
    memset(
        buf.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        bufsize as size_t,
    );
    rangeListToString(buf.as_mut_ptr(), bufsize as uint32_t, list);
    rv = b"[5]\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char;
    printf(
        b"\t%s == %s ???\n\0" as *const u8 as *const ::core::ffi::c_char,
        rv,
        buf.as_mut_ptr(),
    );
    if !(strcmp(b"[5]\0" as *const u8 as *const ::core::ffi::c_char, buf.as_mut_ptr())
        == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            45 as ::core::ffi::c_int,
            b"strcmp(\"[5]\", buf) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test: free\n\0" as *const u8 as *const ::core::ffi::c_char);
    rangeFree(list);
    if (1 as ::core::ffi::c_int == 0) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            50 as ::core::ffi::c_int,
            b"true\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    list = 0 as *mut rangeElement;
    list = rangeAddStartEnd(5 as uint32_t, 10 as uint32_t, list);
    printf(b"test b1:\n\0" as *const u8 as *const ::core::ffi::c_char);
    b = rangeContainsNum(4 as uint32_t, list);
    if !(b as ::core::ffi::c_int == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            59 as ::core::ffi::c_int,
            b"b == false\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test b2:\n\0" as *const u8 as *const ::core::ffi::c_char);
    b = rangeContainsNum(5 as uint32_t, list);
    if !(b as ::core::ffi::c_int == 1 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            64 as ::core::ffi::c_int,
            b"b == true\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test b3:\n\0" as *const u8 as *const ::core::ffi::c_char);
    b = rangeContainsNum(7 as uint32_t, list);
    if !(b as ::core::ffi::c_int == 1 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            69 as ::core::ffi::c_int,
            b"b == true\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test b4:\n\0" as *const u8 as *const ::core::ffi::c_char);
    b = rangeContainsNum(10 as uint32_t, list);
    if !(b as ::core::ffi::c_int == 1 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            74 as ::core::ffi::c_int,
            b"b == true\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test b5:\n\0" as *const u8 as *const ::core::ffi::c_char);
    b = rangeContainsNum(12 as uint32_t, list);
    if !(b as ::core::ffi::c_int == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            79 as ::core::ffi::c_int,
            b"b == false\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test b6:\n\0" as *const u8 as *const ::core::ffi::c_char);
    memset(
        buf.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        bufsize as size_t,
    );
    rangeElementToString(buf.as_mut_ptr(), bufsize as uint32_t, list);
    rv = b"[5-10]\0" as *const u8 as *const ::core::ffi::c_char
        as *mut ::core::ffi::c_char;
    printf(
        b"\t%s == %s ???\0" as *const u8 as *const ::core::ffi::c_char,
        rv,
        buf.as_mut_ptr(),
    );
    if !(strcmp(rv, buf.as_mut_ptr()) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            87 as ::core::ffi::c_int,
            b"strcmp(rv, buf) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test b7:\n\0" as *const u8 as *const ::core::ffi::c_char);
    memset(
        buf.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        bufsize as size_t,
    );
    rangeListToString(buf.as_mut_ptr(), bufsize as uint32_t, list);
    rv = b"[5-10]\0" as *const u8 as *const ::core::ffi::c_char
        as *mut ::core::ffi::c_char;
    printf(
        b"\t%s == %s ???\0" as *const u8 as *const ::core::ffi::c_char,
        rv,
        buf.as_mut_ptr(),
    );
    if !(strcmp(rv, buf.as_mut_ptr()) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            95 as ::core::ffi::c_int,
            b"strcmp(rv, buf) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    rangeFree(list);
    list = 0 as *mut rangeElement;
    list = rangeAddStartEnd(5 as uint32_t, 10 as uint32_t, list);
    list = rangeAddSingle(15 as uint32_t, list);
    list = rangeAddGreaterEqual(40 as uint32_t, list);
    printf(b"test c1:\n\0" as *const u8 as *const ::core::ffi::c_char);
    b = rangeContainsNum(1 as uint32_t, list);
    if !(b as ::core::ffi::c_int == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            109 as ::core::ffi::c_int,
            b"b == false\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test c2:\n\0" as *const u8 as *const ::core::ffi::c_char);
    b = rangeContainsNum(6 as uint32_t, list);
    if !(b as ::core::ffi::c_int == 1 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            114 as ::core::ffi::c_int,
            b"b == true\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test c3:\n\0" as *const u8 as *const ::core::ffi::c_char);
    b = rangeContainsNum(12 as uint32_t, list);
    if !(b as ::core::ffi::c_int == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            119 as ::core::ffi::c_int,
            b"b == false\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test c4:\n\0" as *const u8 as *const ::core::ffi::c_char);
    b = rangeContainsNum(50 as uint32_t, list);
    if !(b as ::core::ffi::c_int == 1 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            124 as ::core::ffi::c_int,
            b"b == true\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test c6:\n\0" as *const u8 as *const ::core::ffi::c_char);
    memset(
        buf.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        bufsize as size_t,
    );
    rangeElementToString(buf.as_mut_ptr(), bufsize as uint32_t, list);
    printf(b"\t%s\0" as *const u8 as *const ::core::ffi::c_char, buf.as_mut_ptr());
    rv = b"[5-10]\0" as *const u8 as *const ::core::ffi::c_char
        as *mut ::core::ffi::c_char;
    if !(strcmp(buf.as_mut_ptr(), rv) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            132 as ::core::ffi::c_int,
            b"strcmp(buf, rv) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test c7:\0" as *const u8 as *const ::core::ffi::c_char);
    memset(
        buf.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        bufsize as size_t,
    );
    rangeListToString(buf.as_mut_ptr(), bufsize as uint32_t, list);
    rv = b"[5-10][15][40-]\0" as *const u8 as *const ::core::ffi::c_char
        as *mut ::core::ffi::c_char;
    printf(
        b"\t%s == %s ???\0" as *const u8 as *const ::core::ffi::c_char,
        rv,
        buf.as_mut_ptr(),
    );
    if !(strcmp(buf.as_mut_ptr(), rv) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            140 as ::core::ffi::c_int,
            b"strcmp(buf, rv) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    rangeFree(list);
    list = 0 as *mut rangeElement;
    list = rangeAddSingle(2 as uint32_t, list);
    list = rangeAddStartEnd(2 as uint32_t, 4 as uint32_t, list);
    printf(b"testd:\0" as *const u8 as *const ::core::ffi::c_char);
    memset(
        buf.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        bufsize as size_t,
    );
    rangeListToString(buf.as_mut_ptr(), bufsize as uint32_t, list);
    rv = b"[2][2-4]\0" as *const u8 as *const ::core::ffi::c_char
        as *mut ::core::ffi::c_char;
    printf(
        b"\t%s == %s ???\n\0" as *const u8 as *const ::core::ffi::c_char,
        rv,
        buf.as_mut_ptr(),
    );
    if !(strcmp(buf.as_mut_ptr(), rv) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            155 as ::core::ffi::c_int,
            b"strcmp(buf, rv) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"test:\0" as *const u8 as *const ::core::ffi::c_char);
    let mut l2: *mut rangeElement = parseIntRanges(
        b"2,2-4\0" as *const u8 as *const ::core::ffi::c_char,
    );
    memset(
        buf.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        bufsize as size_t,
    );
    rangeListToString(buf.as_mut_ptr(), bufsize as uint32_t, l2);
    rv = b"[2][2-4]\0" as *const u8 as *const ::core::ffi::c_char
        as *mut ::core::ffi::c_char;
    printf(
        b"\t%s == %s ???\n\0" as *const u8 as *const ::core::ffi::c_char,
        rv,
        buf.as_mut_ptr(),
    );
    if !(strcmp(buf.as_mut_ptr(), rv) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"test_range.c\0" as *const u8 as *const ::core::ffi::c_char,
            165 as ::core::ffi::c_int,
            b"strcmp(buf, rv) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"\tok\n\0" as *const u8 as *const ::core::ffi::c_char);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
