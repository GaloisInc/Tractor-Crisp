#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(c_variadic, extern_types)]
extern "C" {
    pub type __sFILEX;
    fn gettimeofday(_: *mut timeval, _: *mut ::core::ffi::c_void) -> ::core::ffi::c_int;
    static mut __stderrp: *mut FILE;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn fgets(
        _: *mut ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *mut FILE,
    ) -> *mut ::core::ffi::c_char;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn perror(_: *const ::core::ffi::c_char);
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn vfprintf(
        _: *mut FILE,
        _: *const ::core::ffi::c_char,
        _: va_list,
    ) -> ::core::ffi::c_int;
    fn snprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn vsnprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        _: va_list,
    ) -> ::core::ffi::c_int;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strcat(
        __s1: *mut ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strcpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
    fn strerror(__errnum: ::core::ffi::c_int) -> *mut ::core::ffi::c_char;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strrchr(
        __s: *const ::core::ffi::c_char,
        __c: ::core::ffi::c_int,
    ) -> *mut ::core::ffi::c_char;
    fn close(_: ::core::ffi::c_int) -> ::core::ffi::c_int;
    fn pipe(_: *mut ::core::ffi::c_int) -> ::core::ffi::c_int;
    fn read(_: ::core::ffi::c_int, _: *mut ::core::ffi::c_void, _: size_t) -> ssize_t;
    fn unlink(_: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
    fn write(
        __fd: ::core::ffi::c_int,
        __buf: *const ::core::ffi::c_void,
        __nbyte: size_t,
    ) -> ssize_t;
    fn __error() -> *mut ::core::ffi::c_int;
    fn open(
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        ...
    ) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn realloc(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn localtime(_: *const time_t) -> *mut tm;
    fn strftime(
        _: *mut ::core::ffi::c_char,
        _: size_t,
        _: *const ::core::ffi::c_char,
        _: *const tm,
    ) -> size_t;
    fn time(_: *mut time_t) -> time_t;
}
pub type __builtin_va_list = *mut ::core::ffi::c_char;
pub type __int32_t = i32;
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_va_list = __builtin_va_list;
pub type __darwin_ssize_t = isize;
pub type __darwin_time_t = ::core::ffi::c_long;
pub type __darwin_off_t = __int64_t;
pub type __darwin_suseconds_t = __int32_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct timeval {
    pub tv_sec: __darwin_time_t,
    pub tv_usec: __darwin_suseconds_t,
}
pub type time_t = __darwin_time_t;
pub type va_list = __darwin_va_list;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type ssize_t = __darwin_ssize_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tm {
    pub tm_sec: ::core::ffi::c_int,
    pub tm_min: ::core::ffi::c_int,
    pub tm_hour: ::core::ffi::c_int,
    pub tm_mday: ::core::ffi::c_int,
    pub tm_mon: ::core::ffi::c_int,
    pub tm_year: ::core::ffi::c_int,
    pub tm_wday: ::core::ffi::c_int,
    pub tm_yday: ::core::ffi::c_int,
    pub tm_isdst: ::core::ffi::c_int,
    pub tm_gmtoff: ::core::ffi::c_long,
    pub tm_zone: *mut ::core::ffi::c_char,
}
pub type clog_level = ::core::ffi::c_uint;
pub const CLOG_ERROR: clog_level = 3;
pub const CLOG_WARN: clog_level = 2;
pub const CLOG_INFO: clog_level = 1;
pub const CLOG_DEBUG: clog_level = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct clog {
    pub level: clog_level,
    pub fd: ::core::ffi::c_int,
    pub fmt: [::core::ffi::c_char; 256],
    pub date_fmt: [::core::ffi::c_char; 256],
    pub time_fmt: [::core::ffi::c_char; 256],
    pub opened: ::core::ffi::c_int,
}
pub type C2RustUnnamed = ::core::ffi::c_uint;
pub const SUBST: C2RustUnnamed = 1;
pub const NORMAL: C2RustUnnamed = 0;
pub type test_function_t = Option<unsafe extern "C" fn() -> ::core::ffi::c_int>;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct test_case {
    pub name: *const ::core::ffi::c_char,
    pub function: test_function_t,
    pub pass: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const ENOENT: ::core::ffi::c_int = 2 as ::core::ffi::c_int;
pub const O_WRONLY: ::core::ffi::c_int = 0x1 as ::core::ffi::c_int;
pub const O_APPEND: ::core::ffi::c_int = 0x8 as ::core::ffi::c_int;
pub const O_CREAT: ::core::ffi::c_int = 0x200 as ::core::ffi::c_int;
pub const CLOG_MAX_LOGGERS: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
pub const CLOG_FORMAT_LENGTH: ::core::ffi::c_int = 256 as ::core::ffi::c_int;
pub const CLOG_DATETIME_LENGTH: ::core::ffi::c_int = 256 as ::core::ffi::c_int;
pub const CLOG_DEFAULT_FORMAT: [::core::ffi::c_char; 22] = unsafe {
    ::core::mem::transmute::<
        [u8; 22],
        [::core::ffi::c_char; 22],
    >(*b"%d %t %f(%n): %l: %m\n\0")
};
pub const CLOG_DEFAULT_DATE_FORMAT: [::core::ffi::c_char; 9] = unsafe {
    ::core::mem::transmute::<[u8; 9], [::core::ffi::c_char; 9]>(*b"%Y-%m-%d\0")
};
pub const CLOG_DEFAULT_TIME_FORMAT: [::core::ffi::c_char; 9] = unsafe {
    ::core::mem::transmute::<[u8; 9], [::core::ffi::c_char; 9]>(*b"%H:%M:%S\0")
};
#[no_mangle]
pub static mut _clog_loggers: [*mut clog; 16] = [
    0 as *const clog as *mut clog,
    0 as *const clog as *mut clog,
    0 as *const clog as *mut clog,
    0 as *const clog as *mut clog,
    0 as *const clog as *mut clog,
    0 as *const clog as *mut clog,
    0 as *const clog as *mut clog,
    0 as *const clog as *mut clog,
    0 as *const clog as *mut clog,
    0 as *const clog as *mut clog,
    0 as *const clog as *mut clog,
    0 as *const clog as *mut clog,
    0 as *const clog as *mut clog,
    0 as *const clog as *mut clog,
    0 as *const clog as *mut clog,
    0 as *const clog as *mut clog,
];
#[no_mangle]
pub static mut CLOG_LEVEL_NAMES: [*const ::core::ffi::c_char; 4] = [
    b"DEBUG\0" as *const u8 as *const ::core::ffi::c_char,
    b"INFO\0" as *const u8 as *const ::core::ffi::c_char,
    b"WARN\0" as *const u8 as *const ::core::ffi::c_char,
    b"ERROR\0" as *const u8 as *const ::core::ffi::c_char,
];
#[no_mangle]
pub unsafe extern "C" fn clog_init_path(
    mut id: ::core::ffi::c_int,
    path: *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut fd: ::core::ffi::c_int = open(
        path,
        O_CREAT | O_WRONLY | O_APPEND,
        0o666 as ::core::ffi::c_int,
    );
    if fd == -(1 as ::core::ffi::c_int) {
        _clog_err(
            b"Unable to open %s: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            path,
            strerror(*__error()),
        );
        return 1 as ::core::ffi::c_int;
    }
    if clog_init_fd(id, fd) != 0 {
        close(fd);
        return 1 as ::core::ffi::c_int;
    }
    (*_clog_loggers[id as usize]).opened = 1 as ::core::ffi::c_int;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn clog_init_fd(
    mut id: ::core::ffi::c_int,
    mut fd: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut logger: *mut clog = 0 as *mut clog;
    if !_clog_loggers[id as usize].is_null() {
        _clog_err(
            b"Logger %d already initialized.\n\0" as *const u8
                as *const ::core::ffi::c_char,
            id,
        );
        return 1 as ::core::ffi::c_int;
    }
    logger = malloc(::core::mem::size_of::<clog>() as size_t) as *mut clog;
    if logger.is_null() {
        _clog_err(
            b"Failed to allocate logger: %s\n\0" as *const u8
                as *const ::core::ffi::c_char,
            strerror(*__error()),
        );
        return 1 as ::core::ffi::c_int;
    }
    (*logger).level = CLOG_DEBUG;
    (*logger).fd = fd;
    (*logger).opened = 0 as ::core::ffi::c_int;
    strcpy((*logger).fmt.as_mut_ptr(), CLOG_DEFAULT_FORMAT.as_ptr());
    strcpy((*logger).date_fmt.as_mut_ptr(), CLOG_DEFAULT_DATE_FORMAT.as_ptr());
    strcpy((*logger).time_fmt.as_mut_ptr(), CLOG_DEFAULT_TIME_FORMAT.as_ptr());
    _clog_loggers[id as usize] = logger;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn clog_free(mut id: ::core::ffi::c_int) {
    if !_clog_loggers[id as usize].is_null() {
        if (*_clog_loggers[id as usize]).opened != 0 {
            close((*_clog_loggers[id as usize]).fd);
        }
        free(_clog_loggers[id as usize] as *mut ::core::ffi::c_void);
        _clog_loggers[id as usize] = 0 as *mut clog;
    }
}
#[no_mangle]
pub unsafe extern "C" fn clog_set_level(
    mut id: ::core::ffi::c_int,
    mut level: clog_level,
) -> ::core::ffi::c_int {
    if _clog_loggers[id as usize].is_null() {
        return 1 as ::core::ffi::c_int;
    }
    if level as ::core::ffi::c_uint
        > CLOG_ERROR as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        return 1 as ::core::ffi::c_int;
    }
    (*_clog_loggers[id as usize]).level = level;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn clog_set_time_fmt(
    mut id: ::core::ffi::c_int,
    mut fmt: *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut logger: *mut clog = _clog_loggers[id as usize];
    if logger.is_null() {
        _clog_err(
            b"clog_set_time_fmt: No such logger: %d\n\0" as *const u8
                as *const ::core::ffi::c_char,
            id,
        );
        return 1 as ::core::ffi::c_int;
    }
    if strlen(fmt) >= CLOG_FORMAT_LENGTH as size_t {
        _clog_err(
            b"clog_set_time_fmt: Format specifier too long.\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    strcpy((*logger).time_fmt.as_mut_ptr(), fmt);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn clog_set_date_fmt(
    mut id: ::core::ffi::c_int,
    mut fmt: *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut logger: *mut clog = _clog_loggers[id as usize];
    if logger.is_null() {
        _clog_err(
            b"clog_set_date_fmt: No such logger: %d\n\0" as *const u8
                as *const ::core::ffi::c_char,
            id,
        );
        return 1 as ::core::ffi::c_int;
    }
    if strlen(fmt) >= CLOG_FORMAT_LENGTH as size_t {
        _clog_err(
            b"clog_set_date_fmt: Format specifier too long.\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    strcpy((*logger).date_fmt.as_mut_ptr(), fmt);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn clog_set_fmt(
    mut id: ::core::ffi::c_int,
    mut fmt: *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut logger: *mut clog = _clog_loggers[id as usize];
    if logger.is_null() {
        _clog_err(
            b"clog_set_fmt: No such logger: %d\n\0" as *const u8
                as *const ::core::ffi::c_char,
            id,
        );
        return 1 as ::core::ffi::c_int;
    }
    if strlen(fmt) >= CLOG_FORMAT_LENGTH as size_t {
        _clog_err(
            b"clog_set_fmt: Format specifier too long.\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    strcpy((*logger).fmt.as_mut_ptr(), fmt);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn _clog_append_str(
    mut dst: *mut *mut ::core::ffi::c_char,
    mut orig_buf: *mut ::core::ffi::c_char,
    mut src: *const ::core::ffi::c_char,
    mut cur_size: size_t,
) -> size_t {
    let mut new_size: size_t = cur_size;
    while strlen(*dst).wrapping_add(strlen(src)) >= new_size {
        new_size = new_size.wrapping_mul(2 as size_t);
    }
    if new_size != cur_size {
        if *dst == orig_buf {
            *dst = malloc(new_size) as *mut ::core::ffi::c_char;
            strcpy(*dst, orig_buf);
        } else {
            *dst = realloc(*dst as *mut ::core::ffi::c_void, new_size)
                as *mut ::core::ffi::c_char;
        }
    }
    strcat(*dst, src);
    return new_size;
}
#[no_mangle]
pub unsafe extern "C" fn _clog_append_int(
    mut dst: *mut *mut ::core::ffi::c_char,
    mut orig_buf: *mut ::core::ffi::c_char,
    mut d: ::core::ffi::c_long,
    mut cur_size: size_t,
) -> size_t {
    let mut buf: [::core::ffi::c_char; 40] = [0; 40];
    if snprintf(
        buf.as_mut_ptr(),
        40 as size_t,
        b"%ld\0" as *const u8 as *const ::core::ffi::c_char,
        d,
    ) >= 40 as ::core::ffi::c_int
    {
        return cur_size;
    }
    return _clog_append_str(dst, orig_buf, buf.as_mut_ptr(), cur_size);
}
#[no_mangle]
pub unsafe extern "C" fn _clog_append_time(
    mut dst: *mut *mut ::core::ffi::c_char,
    mut orig_buf: *mut ::core::ffi::c_char,
    mut lt: *mut tm,
    mut fmt: *const ::core::ffi::c_char,
    mut cur_size: size_t,
) -> size_t {
    let mut buf: [::core::ffi::c_char; 256] = [0; 256];
    let mut result: size_t = strftime(
        buf.as_mut_ptr(),
        CLOG_DATETIME_LENGTH as size_t,
        fmt,
        lt,
    );
    if result > 0 as size_t {
        return _clog_append_str(dst, orig_buf, buf.as_mut_ptr(), cur_size);
    }
    return cur_size;
}
#[no_mangle]
pub unsafe extern "C" fn _clog_basename(
    mut path: *const ::core::ffi::c_char,
) -> *const ::core::ffi::c_char {
    let mut slash: *const ::core::ffi::c_char = strrchr(path, '/' as i32);
    if !slash.is_null() {
        path = slash.offset(1 as ::core::ffi::c_int as isize);
    }
    return path;
}
#[no_mangle]
pub unsafe extern "C" fn _clog_format(
    mut logger: *const clog,
    mut buf: *mut ::core::ffi::c_char,
    mut buf_size: size_t,
    mut sfile: *const ::core::ffi::c_char,
    mut sline: ::core::ffi::c_int,
    mut level: *const ::core::ffi::c_char,
    mut message: *const ::core::ffi::c_char,
) -> *mut ::core::ffi::c_char {
    let mut cur_size: size_t = buf_size;
    let mut result: *mut ::core::ffi::c_char = buf as *mut ::core::ffi::c_char;
    let mut state: C2RustUnnamed = NORMAL;
    let mut fmtlen: size_t = strlen((*logger).fmt.as_ptr());
    let mut i: size_t = 0;
    let mut t: time_t = time(0 as *mut time_t);
    let mut lt: *mut tm = localtime(&mut t);
    sfile = _clog_basename(sfile);
    *result.offset(0 as ::core::ffi::c_int as isize) = 0 as ::core::ffi::c_char;
    i = 0 as size_t;
    while i < fmtlen {
        if state as ::core::ffi::c_uint
            == NORMAL as ::core::ffi::c_int as ::core::ffi::c_uint
        {
            if (*logger).fmt[i as usize] as ::core::ffi::c_int == '%' as i32 {
                state = SUBST;
            } else {
                let mut str: [::core::ffi::c_char; 2] = [
                    0 as ::core::ffi::c_int as ::core::ffi::c_char,
                    0,
                ];
                str[0 as ::core::ffi::c_int as usize] = (*logger).fmt[i as usize];
                cur_size = _clog_append_str(
                    &mut result,
                    buf as *mut ::core::ffi::c_char,
                    str.as_mut_ptr(),
                    cur_size,
                );
            }
        } else {
            match (*logger).fmt[i as usize] as ::core::ffi::c_int {
                37 => {
                    cur_size = _clog_append_str(
                        &mut result,
                        buf as *mut ::core::ffi::c_char,
                        b"%\0" as *const u8 as *const ::core::ffi::c_char,
                        cur_size,
                    );
                }
                116 => {
                    cur_size = _clog_append_time(
                        &mut result,
                        buf as *mut ::core::ffi::c_char,
                        lt,
                        (*logger).time_fmt.as_ptr(),
                        cur_size,
                    );
                }
                100 => {
                    cur_size = _clog_append_time(
                        &mut result,
                        buf as *mut ::core::ffi::c_char,
                        lt,
                        (*logger).date_fmt.as_ptr(),
                        cur_size,
                    );
                }
                108 => {
                    cur_size = _clog_append_str(
                        &mut result,
                        buf as *mut ::core::ffi::c_char,
                        level,
                        cur_size,
                    );
                }
                110 => {
                    cur_size = _clog_append_int(
                        &mut result,
                        buf as *mut ::core::ffi::c_char,
                        sline as ::core::ffi::c_long,
                        cur_size,
                    );
                }
                102 => {
                    cur_size = _clog_append_str(
                        &mut result,
                        buf as *mut ::core::ffi::c_char,
                        sfile,
                        cur_size,
                    );
                }
                109 => {
                    cur_size = _clog_append_str(
                        &mut result,
                        buf as *mut ::core::ffi::c_char,
                        message,
                        cur_size,
                    );
                }
                _ => {}
            }
            state = NORMAL;
        }
        i = i.wrapping_add(1);
    }
    return result;
}
#[no_mangle]
pub unsafe extern "C" fn _clog_log(
    mut sfile: *const ::core::ffi::c_char,
    mut sline: ::core::ffi::c_int,
    mut level: clog_level,
    mut id: ::core::ffi::c_int,
    mut fmt: *const ::core::ffi::c_char,
    mut ap: va_list,
) {
    let mut buf: [::core::ffi::c_char; 4096] = [0; 4096];
    let mut buf_size: size_t = 4096 as size_t;
    let mut dynbuf: *mut ::core::ffi::c_char = buf.as_mut_ptr();
    let mut message: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut ap_copy: va_list = 0 as *mut ::core::ffi::c_char;
    let mut result: ::core::ffi::c_int = 0;
    let mut logger: *mut clog = _clog_loggers[id as usize];
    if logger.is_null() {
        _clog_err(
            b"No such logger: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
            id,
        );
        return;
    }
    if (level as ::core::ffi::c_uint) < (*logger).level as ::core::ffi::c_uint {
        return;
    }
    ap_copy = ap.clone();
    result = vsnprintf(dynbuf, buf_size, fmt, ap as va_list);
    if result as size_t >= buf_size {
        buf_size = (result + 1 as ::core::ffi::c_int) as size_t;
        dynbuf = malloc(buf_size) as *mut ::core::ffi::c_char;
        result = vsnprintf(dynbuf, buf_size, fmt, ap_copy as va_list);
        if result as size_t >= buf_size {
            _clog_err(
                b"Formatting failed (1).\n\0" as *const u8 as *const ::core::ffi::c_char,
            );
            free(dynbuf as *mut ::core::ffi::c_void);
            return;
        }
    }
    let mut message_buf: [::core::ffi::c_char; 4096] = [0; 4096];
    message = _clog_format(
        logger,
        message_buf.as_mut_ptr(),
        4096 as size_t,
        sfile,
        sline,
        CLOG_LEVEL_NAMES[level as usize],
        dynbuf,
    );
    if message.is_null() {
        _clog_err(
            b"Formatting failed (2).\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        if dynbuf != buf.as_mut_ptr() {
            free(dynbuf as *mut ::core::ffi::c_void);
        }
        return;
    }
    result = write((*logger).fd, message as *const ::core::ffi::c_void, strlen(message))
        as ::core::ffi::c_int;
    if result == -(1 as ::core::ffi::c_int) {
        _clog_err(
            b"Unable to write to log file: %s\n\0" as *const u8
                as *const ::core::ffi::c_char,
            strerror(*__error()),
        );
    }
    if message != message_buf.as_mut_ptr() {
        free(message as *mut ::core::ffi::c_void);
    }
    if dynbuf != buf.as_mut_ptr() {
        free(dynbuf as *mut ::core::ffi::c_void);
    }
}
#[no_mangle]
pub unsafe extern "C" fn clog_debug(
    mut sfile: *const ::core::ffi::c_char,
    mut sline: ::core::ffi::c_int,
    mut id: ::core::ffi::c_int,
    mut fmt: *const ::core::ffi::c_char,
    mut args: ...
) {
    let mut ap: va_list = 0 as *mut ::core::ffi::c_char;
    ap = args.clone();
    _clog_log(sfile, sline, CLOG_DEBUG, id, fmt, ap);
}
#[no_mangle]
pub unsafe extern "C" fn clog_info(
    mut sfile: *const ::core::ffi::c_char,
    mut sline: ::core::ffi::c_int,
    mut id: ::core::ffi::c_int,
    mut fmt: *const ::core::ffi::c_char,
    mut args: ...
) {
    let mut ap: va_list = 0 as *mut ::core::ffi::c_char;
    ap = args.clone();
    _clog_log(sfile, sline, CLOG_INFO, id, fmt, ap);
}
#[no_mangle]
pub unsafe extern "C" fn clog_warn(
    mut sfile: *const ::core::ffi::c_char,
    mut sline: ::core::ffi::c_int,
    mut id: ::core::ffi::c_int,
    mut fmt: *const ::core::ffi::c_char,
    mut args: ...
) {
    let mut ap: va_list = 0 as *mut ::core::ffi::c_char;
    ap = args.clone();
    _clog_log(sfile, sline, CLOG_WARN, id, fmt, ap);
}
#[no_mangle]
pub unsafe extern "C" fn clog_error(
    mut sfile: *const ::core::ffi::c_char,
    mut sline: ::core::ffi::c_int,
    mut id: ::core::ffi::c_int,
    mut fmt: *const ::core::ffi::c_char,
    mut args: ...
) {
    let mut ap: va_list = 0 as *mut ::core::ffi::c_char;
    ap = args.clone();
    _clog_log(sfile, sline, CLOG_ERROR, id, fmt, ap);
}
#[no_mangle]
pub unsafe extern "C" fn _clog_err(mut fmt: *const ::core::ffi::c_char, mut args: ...) {
    let mut ap: va_list = 0 as *mut ::core::ffi::c_char;
    ap = args.clone();
    vfprintf(__stderrp, fmt, ap as va_list);
}
pub const THIS_FILE: [::core::ffi::c_char; 14] = unsafe {
    ::core::mem::transmute::<[u8; 14], [::core::ffi::c_char; 14]>(*b"clog_test_c.c\0")
};
pub const TEST_FILE: [::core::ffi::c_char; 14] = unsafe {
    ::core::mem::transmute::<[u8; 14], [::core::ffi::c_char; 14]>(*b"clog_test.out\0")
};
#[no_mangle]
pub static mut error_text: [::core::ffi::c_char; 16384] = [0; 16384];
#[no_mangle]
pub unsafe extern "C" fn error(mut fmt: *const ::core::ffi::c_char, mut args: ...) {
    let mut ap: va_list = 0 as *mut ::core::ffi::c_char;
    ap = args.clone();
    vsnprintf(error_text.as_mut_ptr(), 16384 as size_t, fmt, ap as va_list);
    error_text[16383 as ::core::ffi::c_int as usize] = 0 as ::core::ffi::c_char;
}
#[no_mangle]
pub unsafe extern "C" fn test_double_init() -> ::core::ffi::c_int {
    if clog_init_path(
        0 as ::core::ffi::c_int,
        b"clog_test.out\0" as *const u8 as *const ::core::ffi::c_char,
    ) != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    if clog_init_path(0 as ::core::ffi::c_int, TEST_FILE.as_ptr())
        == 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    clog_free(0 as ::core::ffi::c_int);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_file_write() -> ::core::ffi::c_int {
    let mut f: *mut FILE = 0 as *mut FILE;
    let mut buf: [::core::ffi::c_char; 256] = [0; 256];
    if clog_init_path(
        0 as ::core::ffi::c_int,
        b"clog_test.out\0" as *const u8 as *const ::core::ffi::c_char,
    ) != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    if clog_set_fmt(
        0 as ::core::ffi::c_int,
        b"%f: %l: %m\n\0" as *const u8 as *const ::core::ffi::c_char,
    ) != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    clog_debug(
        b"tests/clog_test_c.c\0" as *const u8 as *const ::core::ffi::c_char,
        50 as ::core::ffi::c_int,
        0 as ::core::ffi::c_int,
        b"Hello, %s!\0" as *const u8 as *const ::core::ffi::c_char,
        b"world\0" as *const u8 as *const ::core::ffi::c_char,
    );
    clog_free(0 as ::core::ffi::c_int);
    f = fopen(TEST_FILE.as_ptr(), b"r\0" as *const u8 as *const ::core::ffi::c_char)
        as *mut FILE;
    if f.is_null() {
        return 1 as ::core::ffi::c_int;
    }
    if fgets(buf.as_mut_ptr(), 256 as ::core::ffi::c_int, f).is_null() {
        fclose(f);
        return 1 as ::core::ffi::c_int;
    }
    fclose(f);
    if strcmp(
        buf.as_mut_ptr(),
        b"clog_test_c.c: DEBUG: Hello, world!\n\0" as *const u8
            as *const ::core::ffi::c_char,
    ) != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_file_write_nonexistent() -> ::core::ffi::c_int {
    if clog_init_path(
        0 as ::core::ffi::c_int,
        b"path-doesnt-exist/log.out\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    if !_clog_loggers[0 as ::core::ffi::c_int as usize].is_null() {
        return 1 as ::core::ffi::c_int;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_fd_write() -> ::core::ffi::c_int {
    let mut buf: [::core::ffi::c_char; 1024] = [0; 1024];
    let mut fd: [::core::ffi::c_int; 2] = [0; 2];
    let mut bytes: size_t = 0;
    if pipe(fd.as_mut_ptr()) != 0 as ::core::ffi::c_int {
        return 1 as ::core::ffi::c_int;
    }
    if clog_init_fd(0 as ::core::ffi::c_int, fd[1 as ::core::ffi::c_int as usize])
        != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    if clog_set_fmt(
        0 as ::core::ffi::c_int,
        b"%f: %l: %m\n\0" as *const u8 as *const ::core::ffi::c_char,
    ) != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    clog_debug(
        b"tests/clog_test_c.c\0" as *const u8 as *const ::core::ffi::c_char,
        91 as ::core::ffi::c_int,
        0 as ::core::ffi::c_int,
        b"Hello, %s!\0" as *const u8 as *const ::core::ffi::c_char,
        b"world\0" as *const u8 as *const ::core::ffi::c_char,
    );
    clog_free(0 as ::core::ffi::c_int);
    close(fd[1 as ::core::ffi::c_int as usize]);
    bytes = read(
        fd[0 as ::core::ffi::c_int as usize],
        buf.as_mut_ptr() as *mut ::core::ffi::c_void,
        1024 as size_t,
    ) as size_t;
    if bytes <= 0 as size_t {
        close(fd[0 as ::core::ffi::c_int as usize]);
        return 1 as ::core::ffi::c_int;
    }
    buf[bytes as usize] = 0 as ::core::ffi::c_char;
    close(fd[0 as ::core::ffi::c_int as usize]);
    if strcmp(
        buf.as_mut_ptr(),
        b"clog_test_c.c: DEBUG: Hello, world!\n\0" as *const u8
            as *const ::core::ffi::c_char,
    ) != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_all_levels() -> ::core::ffi::c_int {
    let mut buf: [::core::ffi::c_char; 1024] = [0; 1024];
    let mut fd: [::core::ffi::c_int; 2] = [0; 2];
    let mut bytes: size_t = 0;
    if pipe(fd.as_mut_ptr()) != 0 as ::core::ffi::c_int {
        return 1 as ::core::ffi::c_int;
    }
    if clog_init_fd(0 as ::core::ffi::c_int, fd[1 as ::core::ffi::c_int as usize])
        != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    if clog_set_fmt(
        0 as ::core::ffi::c_int,
        b"%f: %l: %m\n\0" as *const u8 as *const ::core::ffi::c_char,
    ) != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    clog_debug(
        b"tests/clog_test_c.c\0" as *const u8 as *const ::core::ffi::c_char,
        116 as ::core::ffi::c_int,
        0 as ::core::ffi::c_int,
        b"Hello, %s!\0" as *const u8 as *const ::core::ffi::c_char,
        b"world\0" as *const u8 as *const ::core::ffi::c_char,
    );
    clog_info(
        b"tests/clog_test_c.c\0" as *const u8 as *const ::core::ffi::c_char,
        117 as ::core::ffi::c_int,
        0 as ::core::ffi::c_int,
        b"Hello, %s!\0" as *const u8 as *const ::core::ffi::c_char,
        b"world\0" as *const u8 as *const ::core::ffi::c_char,
    );
    clog_warn(
        b"tests/clog_test_c.c\0" as *const u8 as *const ::core::ffi::c_char,
        118 as ::core::ffi::c_int,
        0 as ::core::ffi::c_int,
        b"Hello, %s!\0" as *const u8 as *const ::core::ffi::c_char,
        b"world\0" as *const u8 as *const ::core::ffi::c_char,
    );
    clog_error(
        b"tests/clog_test_c.c\0" as *const u8 as *const ::core::ffi::c_char,
        119 as ::core::ffi::c_int,
        0 as ::core::ffi::c_int,
        b"Hello, %s!\0" as *const u8 as *const ::core::ffi::c_char,
        b"world\0" as *const u8 as *const ::core::ffi::c_char,
    );
    clog_free(0 as ::core::ffi::c_int);
    close(fd[1 as ::core::ffi::c_int as usize]);
    bytes = read(
        fd[0 as ::core::ffi::c_int as usize],
        buf.as_mut_ptr() as *mut ::core::ffi::c_void,
        1024 as size_t,
    ) as size_t;
    if bytes <= 0 as size_t {
        close(fd[0 as ::core::ffi::c_int as usize]);
        return 1 as ::core::ffi::c_int;
    }
    buf[bytes as usize] = 0 as ::core::ffi::c_char;
    close(fd[0 as ::core::ffi::c_int as usize]);
    if strcmp(
        buf.as_mut_ptr(),
        b"clog_test_c.c: DEBUG: Hello, world!\nclog_test_c.c: INFO: Hello, world!\nclog_test_c.c: WARN: Hello, world!\nclog_test_c.c: ERROR: Hello, world!\n\0"
            as *const u8 as *const ::core::ffi::c_char,
    ) != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_level_filtering() -> ::core::ffi::c_int {
    let mut buf: [::core::ffi::c_char; 1024] = [0; 1024];
    let mut fd: [::core::ffi::c_int; 2] = [0; 2];
    let mut bytes: size_t = 0;
    if pipe(fd.as_mut_ptr()) != 0 as ::core::ffi::c_int {
        return 1 as ::core::ffi::c_int;
    }
    if clog_init_fd(0 as ::core::ffi::c_int, fd[1 as ::core::ffi::c_int as usize])
        != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    if clog_set_fmt(
        0 as ::core::ffi::c_int,
        b"%f: %l: %m\n\0" as *const u8 as *const ::core::ffi::c_char,
    ) != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    if clog_set_level(0 as ::core::ffi::c_int, CLOG_WARN) != 0 as ::core::ffi::c_int {
        return 1 as ::core::ffi::c_int;
    }
    clog_debug(
        b"tests/clog_test_c.c\0" as *const u8 as *const ::core::ffi::c_char,
        151 as ::core::ffi::c_int,
        0 as ::core::ffi::c_int,
        b"Hello, %s!\0" as *const u8 as *const ::core::ffi::c_char,
        b"world\0" as *const u8 as *const ::core::ffi::c_char,
    );
    clog_info(
        b"tests/clog_test_c.c\0" as *const u8 as *const ::core::ffi::c_char,
        152 as ::core::ffi::c_int,
        0 as ::core::ffi::c_int,
        b"Hello, %s!\0" as *const u8 as *const ::core::ffi::c_char,
        b"world\0" as *const u8 as *const ::core::ffi::c_char,
    );
    clog_warn(
        b"tests/clog_test_c.c\0" as *const u8 as *const ::core::ffi::c_char,
        153 as ::core::ffi::c_int,
        0 as ::core::ffi::c_int,
        b"Hello, %s!\0" as *const u8 as *const ::core::ffi::c_char,
        b"world\0" as *const u8 as *const ::core::ffi::c_char,
    );
    clog_error(
        b"tests/clog_test_c.c\0" as *const u8 as *const ::core::ffi::c_char,
        154 as ::core::ffi::c_int,
        0 as ::core::ffi::c_int,
        b"Hello, %s!\0" as *const u8 as *const ::core::ffi::c_char,
        b"world\0" as *const u8 as *const ::core::ffi::c_char,
    );
    clog_free(0 as ::core::ffi::c_int);
    close(fd[1 as ::core::ffi::c_int as usize]);
    bytes = read(
        fd[0 as ::core::ffi::c_int as usize],
        buf.as_mut_ptr() as *mut ::core::ffi::c_void,
        1024 as size_t,
    ) as size_t;
    if bytes <= 0 as size_t {
        close(fd[0 as ::core::ffi::c_int as usize]);
        return 1 as ::core::ffi::c_int;
    }
    buf[bytes as usize] = 0 as ::core::ffi::c_char;
    close(fd[0 as ::core::ffi::c_int as usize]);
    if strcmp(
        buf.as_mut_ptr(),
        b"clog_test_c.c: WARN: Hello, world!\nclog_test_c.c: ERROR: Hello, world!\n\0"
            as *const u8 as *const ::core::ffi::c_char,
    ) != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_multiple_loggers() -> ::core::ffi::c_int {
    let mut buf: [::core::ffi::c_char; 1024] = [0; 1024];
    let mut bytes: size_t = 0;
    let mut id: ::core::ffi::c_int = 0;
    id = 0 as ::core::ffi::c_int;
    while id < CLOG_MAX_LOGGERS {
        let mut fd: [::core::ffi::c_int; 2] = [0; 2];
        let mut exp: [::core::ffi::c_char; 256] = [0; 256];
        if pipe(fd.as_mut_ptr()) != 0 as ::core::ffi::c_int {
            return 1 as ::core::ffi::c_int;
        }
        if clog_init_fd(id, fd[1 as ::core::ffi::c_int as usize])
            != 0 as ::core::ffi::c_int
        {
            return 1 as ::core::ffi::c_int;
        }
        if clog_set_fmt(id, b"%f: %l: %m\n\0" as *const u8 as *const ::core::ffi::c_char)
            != 0 as ::core::ffi::c_int
        {
            return 1 as ::core::ffi::c_int;
        }
        clog_debug(
            b"tests/clog_test_c.c\0" as *const u8 as *const ::core::ffi::c_char,
            186 as ::core::ffi::c_int,
            id,
            b"Hello, %d!\0" as *const u8 as *const ::core::ffi::c_char,
            id,
        );
        close(fd[1 as ::core::ffi::c_int as usize]);
        bytes = read(
            fd[0 as ::core::ffi::c_int as usize],
            buf.as_mut_ptr() as *mut ::core::ffi::c_void,
            1024 as size_t,
        ) as size_t;
        if bytes <= 0 as size_t {
            close(fd[0 as ::core::ffi::c_int as usize]);
            return 1 as ::core::ffi::c_int;
        }
        buf[bytes as usize] = 0 as ::core::ffi::c_char;
        close(fd[0 as ::core::ffi::c_int as usize]);
        snprintf(
            exp.as_mut_ptr(),
            256 as size_t,
            b"%s: DEBUG: Hello, %d!\n\0" as *const u8 as *const ::core::ffi::c_char,
            THIS_FILE.as_ptr(),
            id,
        );
        if strcmp(buf.as_mut_ptr(), exp.as_mut_ptr()) != 0 as ::core::ffi::c_int {
            return 1 as ::core::ffi::c_int;
        }
        id += 1;
    }
    id = 0 as ::core::ffi::c_int;
    while id < CLOG_MAX_LOGGERS {
        clog_free(id);
        id += 1;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_bad_format() -> ::core::ffi::c_int {
    let mut too_long: [::core::ffi::c_char; 300] = [0; 300];
    memset(too_long.as_mut_ptr() as *mut ::core::ffi::c_void, 'a' as i32, 299 as size_t);
    too_long[299 as ::core::ffi::c_int as usize] = 0 as ::core::ffi::c_char;
    if clog_init_path(
        0 as ::core::ffi::c_int,
        b"clog_test.out\0" as *const u8 as *const ::core::ffi::c_char,
    ) != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    if clog_set_fmt(0 as ::core::ffi::c_int, too_long.as_mut_ptr())
        == 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    clog_free(0 as ::core::ffi::c_int);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_long_message() -> ::core::ffi::c_int {
    let mut f: *mut FILE = 0 as *mut FILE;
    let mut buf: [::core::ffi::c_char; 51000] = [0; 51000];
    let mut message: [::core::ffi::c_char; 50000] = [0; 50000];
    let mut exp: [::core::ffi::c_char; 51000] = [0; 51000];
    memset(
        message.as_mut_ptr() as *mut ::core::ffi::c_void,
        'b' as i32,
        49999 as size_t,
    );
    message[49999 as ::core::ffi::c_int as usize] = 0 as ::core::ffi::c_char;
    if clog_init_path(
        0 as ::core::ffi::c_int,
        b"clog_test.out\0" as *const u8 as *const ::core::ffi::c_char,
    ) != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    if clog_set_fmt(
        0 as ::core::ffi::c_int,
        b"%f: %l: %m\n\0" as *const u8 as *const ::core::ffi::c_char,
    ) != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    clog_debug(
        b"tests/clog_test_c.c\0" as *const u8 as *const ::core::ffi::c_char,
        231 as ::core::ffi::c_int,
        0 as ::core::ffi::c_int,
        message.as_mut_ptr(),
    );
    clog_free(0 as ::core::ffi::c_int);
    f = fopen(TEST_FILE.as_ptr(), b"r\0" as *const u8 as *const ::core::ffi::c_char)
        as *mut FILE;
    if f.is_null() {
        return 1 as ::core::ffi::c_int;
    }
    if fgets(buf.as_mut_ptr(), 51000 as ::core::ffi::c_int, f).is_null() {
        fclose(f);
        return 1 as ::core::ffi::c_int;
    }
    fclose(f);
    snprintf(
        exp.as_mut_ptr(),
        51000 as size_t,
        b"%s: DEBUG: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        THIS_FILE.as_ptr(),
        message.as_mut_ptr(),
    );
    if strcmp(buf.as_mut_ptr(), exp.as_mut_ptr()) != 0 as ::core::ffi::c_int {
        return 1 as ::core::ffi::c_int;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_performance() -> ::core::ffi::c_int {
    let MICROS_PER_SEC: ::core::ffi::c_int = 1000000 as ::core::ffi::c_int;
    let NUM_MESSAGES: size_t = 200000 as size_t;
    let mut start_time: ::core::ffi::c_ulong = 0;
    let mut end_time: ::core::ffi::c_ulong = 0;
    let mut tv: timeval = timeval { tv_sec: 0, tv_usec: 0 };
    let mut messages: size_t = 0 as size_t;
    let mut run_time: ::core::ffi::c_double = 0.;
    let mut messages_per_second: ::core::ffi::c_ulong = 0;
    if clog_init_path(
        0 as ::core::ffi::c_int,
        b"clog_test.out\0" as *const u8 as *const ::core::ffi::c_char,
    ) != 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    if gettimeofday(&mut tv, 0 as *mut ::core::ffi::c_void) != 0 as ::core::ffi::c_int {
        return 1 as ::core::ffi::c_int;
    }
    start_time = (tv.tv_sec * MICROS_PER_SEC as __darwin_time_t
        + tv.tv_usec as __darwin_time_t) as ::core::ffi::c_ulong;
    messages = 0 as size_t;
    while messages < NUM_MESSAGES {
        clog_debug(
            b"tests/clog_test_c.c\0" as *const u8 as *const ::core::ffi::c_char,
            268 as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"Hello, %s!\0" as *const u8 as *const ::core::ffi::c_char,
            b"high-performing world\0" as *const u8 as *const ::core::ffi::c_char,
        );
        messages = messages.wrapping_add(1);
    }
    if gettimeofday(&mut tv, 0 as *mut ::core::ffi::c_void) != 0 as ::core::ffi::c_int {
        return 1 as ::core::ffi::c_int;
    }
    end_time = (tv.tv_sec * MICROS_PER_SEC as __darwin_time_t
        + tv.tv_usec as __darwin_time_t) as ::core::ffi::c_ulong;
    clog_free(0 as ::core::ffi::c_int);
    run_time = end_time.wrapping_sub(start_time) as ::core::ffi::c_double
        / MICROS_PER_SEC as ::core::ffi::c_double;
    messages_per_second = (messages as ::core::ffi::c_double / run_time)
        as ::core::ffi::c_ulong;
    error(
        b"  Target 100000 msgs/sec, got %lu.\n\0" as *const u8
            as *const ::core::ffi::c_char,
        messages_per_second,
    );
    if messages_per_second < 100000 as ::core::ffi::c_ulong {
        return 1 as ::core::ffi::c_int;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_reuse_logger_id() -> ::core::ffi::c_int {
    let mut i: ::core::ffi::c_int = 0;
    i = 0 as ::core::ffi::c_int;
    while i < 2 as ::core::ffi::c_int {
        let mut buf: [::core::ffi::c_char; 1024] = [0; 1024];
        let mut fd: [::core::ffi::c_int; 2] = [0; 2];
        let mut bytes: size_t = 0;
        if pipe(fd.as_mut_ptr()) != 0 as ::core::ffi::c_int {
            return 1 as ::core::ffi::c_int;
        }
        if clog_init_fd(0 as ::core::ffi::c_int, fd[1 as ::core::ffi::c_int as usize])
            != 0 as ::core::ffi::c_int
        {
            return 1 as ::core::ffi::c_int;
        }
        if clog_set_fmt(
            0 as ::core::ffi::c_int,
            b"%f: %l: %m\n\0" as *const u8 as *const ::core::ffi::c_char,
        ) != 0 as ::core::ffi::c_int
        {
            return 1 as ::core::ffi::c_int;
        }
        clog_debug(
            b"tests/clog_test_c.c\0" as *const u8 as *const ::core::ffi::c_char,
            298 as ::core::ffi::c_int,
            0 as ::core::ffi::c_int,
            b"Hello, %s!\0" as *const u8 as *const ::core::ffi::c_char,
            b"world\0" as *const u8 as *const ::core::ffi::c_char,
        );
        clog_free(0 as ::core::ffi::c_int);
        close(fd[1 as ::core::ffi::c_int as usize]);
        bytes = read(
            fd[0 as ::core::ffi::c_int as usize],
            buf.as_mut_ptr() as *mut ::core::ffi::c_void,
            1024 as size_t,
        ) as size_t;
        if bytes <= 0 as size_t {
            close(fd[0 as ::core::ffi::c_int as usize]);
            return 1 as ::core::ffi::c_int;
        }
        buf[bytes as usize] = 0 as ::core::ffi::c_char;
        close(fd[0 as ::core::ffi::c_int as usize]);
        if strcmp(
            buf.as_mut_ptr(),
            b"clog_test_c.c: DEBUG: Hello, world!\n\0" as *const u8
                as *const ::core::ffi::c_char,
        ) != 0 as ::core::ffi::c_int
        {
            return 1 as ::core::ffi::c_int;
        }
        i += 1;
    }
    return 0 as ::core::ffi::c_int;
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut tests: [test_case; 11] = [
        {
            let mut init = test_case {
                name: b"test_double_init\0" as *const u8 as *const ::core::ffi::c_char,
                function: Some(
                    ::core::mem::transmute::<
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                    >(test_double_init),
                ),
                pass: -(1 as ::core::ffi::c_int),
            };
            init
        },
        {
            let mut init = test_case {
                name: b"test_file_write\0" as *const u8 as *const ::core::ffi::c_char,
                function: Some(
                    ::core::mem::transmute::<
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                    >(test_file_write),
                ),
                pass: -(1 as ::core::ffi::c_int),
            };
            init
        },
        {
            let mut init = test_case {
                name: b"test_file_write_nonexistent\0" as *const u8
                    as *const ::core::ffi::c_char,
                function: Some(
                    ::core::mem::transmute::<
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                    >(test_file_write_nonexistent),
                ),
                pass: -(1 as ::core::ffi::c_int),
            };
            init
        },
        {
            let mut init = test_case {
                name: b"test_fd_write\0" as *const u8 as *const ::core::ffi::c_char,
                function: Some(
                    ::core::mem::transmute::<
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                    >(test_fd_write),
                ),
                pass: -(1 as ::core::ffi::c_int),
            };
            init
        },
        {
            let mut init = test_case {
                name: b"test_all_levels\0" as *const u8 as *const ::core::ffi::c_char,
                function: Some(
                    ::core::mem::transmute::<
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                    >(test_all_levels),
                ),
                pass: -(1 as ::core::ffi::c_int),
            };
            init
        },
        {
            let mut init = test_case {
                name: b"test_level_filtering\0" as *const u8
                    as *const ::core::ffi::c_char,
                function: Some(
                    ::core::mem::transmute::<
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                    >(test_level_filtering),
                ),
                pass: -(1 as ::core::ffi::c_int),
            };
            init
        },
        {
            let mut init = test_case {
                name: b"test_multiple_loggers\0" as *const u8
                    as *const ::core::ffi::c_char,
                function: Some(
                    ::core::mem::transmute::<
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                    >(test_multiple_loggers),
                ),
                pass: -(1 as ::core::ffi::c_int),
            };
            init
        },
        {
            let mut init = test_case {
                name: b"test_bad_format\0" as *const u8 as *const ::core::ffi::c_char,
                function: Some(
                    ::core::mem::transmute::<
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                    >(test_bad_format),
                ),
                pass: -(1 as ::core::ffi::c_int),
            };
            init
        },
        {
            let mut init = test_case {
                name: b"test_long_message\0" as *const u8 as *const ::core::ffi::c_char,
                function: Some(
                    ::core::mem::transmute::<
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                    >(test_long_message),
                ),
                pass: -(1 as ::core::ffi::c_int),
            };
            init
        },
        {
            let mut init = test_case {
                name: b"test_reuse_logger_id\0" as *const u8
                    as *const ::core::ffi::c_char,
                function: Some(
                    ::core::mem::transmute::<
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                    >(test_reuse_logger_id),
                ),
                pass: -(1 as ::core::ffi::c_int),
            };
            init
        },
        {
            let mut init = test_case {
                name: b"test_performance\0" as *const u8 as *const ::core::ffi::c_char,
                function: Some(
                    ::core::mem::transmute::<
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                        unsafe extern "C" fn() -> ::core::ffi::c_int,
                    >(test_performance),
                ),
                pass: -(1 as ::core::ffi::c_int),
            };
            init
        },
    ];
    let num_tests: size_t = (::core::mem::size_of::<[test_case; 11]>() as size_t)
        .wrapping_div(::core::mem::size_of::<test_case>() as size_t);
    let mut test_name: *const ::core::ffi::c_char = 0 as *const ::core::ffi::c_char;
    let mut pass: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut fail: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut i: size_t = 0;
    let mut j: size_t = 0;
    if argc > 1 as ::core::ffi::c_int {
        test_name = *argv.offset(1 as ::core::ffi::c_int as isize);
    }
    i = 0 as size_t;
    while i < num_tests {
        if !(!test_name.is_null()
            && strcmp(tests[i as usize].name, test_name) != 0 as ::core::ffi::c_int)
        {
            if unlink(TEST_FILE.as_ptr()) == -(1 as ::core::ffi::c_int)
                && *__error() != ENOENT
            {
                perror(b"unlink\0" as *const u8 as *const ::core::ffi::c_char);
            }
            printf(
                b"%s: \0" as *const u8 as *const ::core::ffi::c_char,
                tests[i as usize].name,
            );
            if ::core::mem::transmute::<
                _,
                fn() -> ::core::ffi::c_int,
            >(tests[i as usize].function.expect("non-null function pointer"))()
                == 0 as ::core::ffi::c_int
            {
                tests[i as usize].pass = 1 as ::core::ffi::c_int;
                pass += 1;
                printf(b"OK\n\0" as *const u8 as *const ::core::ffi::c_char);
            } else {
                tests[i as usize].pass = 0 as ::core::ffi::c_int;
                fail += 1;
                printf(b"FAIL\n\0" as *const u8 as *const ::core::ffi::c_char);
            }
            if strlen(error_text.as_mut_ptr()) != 0 {
                printf(
                    b"%s\0" as *const u8 as *const ::core::ffi::c_char,
                    error_text.as_mut_ptr(),
                );
            }
            j = 0 as size_t;
            while j < CLOG_MAX_LOGGERS as size_t {
                _clog_loggers[j as usize] = 0 as *mut clog;
                j = j.wrapping_add(1);
            }
            error_text[0 as ::core::ffi::c_int as usize] = '\0' as i32
                as ::core::ffi::c_char;
        }
        i = i.wrapping_add(1);
    }
    printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
    if pass == 0 as ::core::ffi::c_int && fail == 0 as ::core::ffi::c_int {
        printf(
            b"No such test: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            test_name,
        );
        return 1 as ::core::ffi::c_int;
    } else {
        printf(
            b"%d successes, %d failures.\n\0" as *const u8 as *const ::core::ffi::c_char,
            pass,
            fail,
        );
    }
    if fail > 0 as ::core::ffi::c_int {
        printf(b"Failing cases:\n\0" as *const u8 as *const ::core::ffi::c_char);
        i = 0 as size_t;
        while i < num_tests {
            if tests[i as usize].pass == 0 as ::core::ffi::c_int {
                printf(
                    b"    %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    tests[i as usize].name,
                );
            }
            i = i.wrapping_add(1);
        }
    }
    return if fail != 0 { 1 as ::core::ffi::c_int } else { 0 as ::core::ffi::c_int };
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
