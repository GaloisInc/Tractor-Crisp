#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(c_variadic, linkage)]
extern "C" {
    static mut _DefaultRuneLocale: _RuneLocale;
    fn __maskrune(_: __darwin_ct_rune_t, _: ::core::ffi::c_ulong) -> ::core::ffi::c_int;
    fn acosf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn asinf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn atanf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn atan2f(_: ::core::ffi::c_float, _: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn cosf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn sinf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn tanf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn coshf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn sinhf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn tanhf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn expf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn exp2f(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn logf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn log10f(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn log2f(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn logbf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn fabsf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn cbrtf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn hypotf(_: ::core::ffi::c_float, _: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn powf(_: ::core::ffi::c_float, _: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn sqrtf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn ceilf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn floorf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn roundf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn truncf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn calloc(__count: size_t, __size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn atof(_: *const ::core::ffi::c_char) -> ::core::ffi::c_double;
    fn atoi(_: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strncmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> ::core::ffi::c_int;
}
pub type __uint32_t = u32;
pub type __darwin_ct_rune_t = ::core::ffi::c_int;
pub type __darwin_size_t = usize;
pub type __darwin_wchar_t = ::libc::wchar_t;
pub type __darwin_rune_t = __darwin_wchar_t;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneEntry {
    pub __min: __darwin_rune_t,
    pub __max: __darwin_rune_t,
    pub __map: __darwin_rune_t,
    pub __types: *mut __uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneRange {
    pub __nranges: ::core::ffi::c_int,
    pub __ranges: *mut _RuneEntry,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneCharClass {
    pub __name: [::core::ffi::c_char; 14],
    pub __mask: __uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneLocale {
    pub __magic: [::core::ffi::c_char; 8],
    pub __encoding: [::core::ffi::c_char; 32],
    pub __sgetrune: Option<
        unsafe extern "C" fn(
            *const ::core::ffi::c_char,
            __darwin_size_t,
            *mut *const ::core::ffi::c_char,
        ) -> __darwin_rune_t,
    >,
    pub __sputrune: Option<
        unsafe extern "C" fn(
            __darwin_rune_t,
            *mut ::core::ffi::c_char,
            __darwin_size_t,
            *mut *mut ::core::ffi::c_char,
        ) -> ::core::ffi::c_int,
    >,
    pub __invalid_rune: __darwin_rune_t,
    pub __runetype: [__uint32_t; 256],
    pub __maplower: [__darwin_rune_t; 256],
    pub __mapupper: [__darwin_rune_t; 256],
    pub __runetype_ext: _RuneRange,
    pub __maplower_ext: _RuneRange,
    pub __mapupper_ext: _RuneRange,
    pub __variable: *mut ::core::ffi::c_void,
    pub __variable_len: ::core::ffi::c_int,
    pub __ncharclasses: ::core::ffi::c_int,
    pub __charclasses: *mut _RuneCharClass,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _mapper_expr {
    pub node: exprnode,
    pub vector_size: ::core::ffi::c_int,
    pub history_size: ::core::ffi::c_int,
    pub history_pos: ::core::ffi::c_int,
    pub input_history: *mut mapper_signal_value_t,
    pub output_history: *mut mapper_signal_value_t,
}
pub type mapper_signal_value_t = _mapper_signal_value_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub union _mapper_signal_value_t {
    pub f: ::core::ffi::c_float,
    pub i32_0: ::core::ffi::c_int,
}
pub type exprnode = *mut _exprnode;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _exprnode {
    pub tok: token_t,
    pub is_float: ::core::ffi::c_int,
    pub history_index: ::core::ffi::c_int,
    pub vector_index: ::core::ffi::c_int,
    pub next: *mut _exprnode,
}
pub type token_t = _token;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _token {
    pub type_0: C2RustUnnamed_0,
    pub c2rust_unnamed: C2RustUnnamed,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed {
    pub f: ::core::ffi::c_float,
    pub i: ::core::ffi::c_int,
    pub var: ::core::ffi::c_char,
    pub op: ::core::ffi::c_char,
    pub func: expr_func_t,
}
pub type expr_func_t = ::core::ffi::c_int;
pub const N_FUNCS: expr_func_t = 28;
pub const FUNC_PI: expr_func_t = 27;
pub const FUNC_MAX: expr_func_t = 26;
pub const FUNC_MIN: expr_func_t = 25;
pub const FUNC_TRUNC: expr_func_t = 24;
pub const FUNC_CBRT: expr_func_t = 23;
pub const FUNC_HYPOT: expr_func_t = 22;
pub const FUNC_LOG2: expr_func_t = 21;
pub const FUNC_EXP2: expr_func_t = 20;
pub const FUNC_LOGB: expr_func_t = 19;
pub const FUNC_TANH: expr_func_t = 18;
pub const FUNC_COSH: expr_func_t = 17;
pub const FUNC_SINH: expr_func_t = 16;
pub const FUNC_ATAN2: expr_func_t = 15;
pub const FUNC_ATAN: expr_func_t = 14;
pub const FUNC_ACOS: expr_func_t = 13;
pub const FUNC_ASIN: expr_func_t = 12;
pub const FUNC_CEIL: expr_func_t = 11;
pub const FUNC_ROUND: expr_func_t = 10;
pub const FUNC_FLOOR: expr_func_t = 9;
pub const FUNC_EXP: expr_func_t = 8;
pub const FUNC_LOG10: expr_func_t = 7;
pub const FUNC_LOG: expr_func_t = 6;
pub const FUNC_SQRT: expr_func_t = 5;
pub const FUNC_ABS: expr_func_t = 4;
pub const FUNC_TAN: expr_func_t = 3;
pub const FUNC_COS: expr_func_t = 2;
pub const FUNC_SIN: expr_func_t = 1;
pub const FUNC_POW: expr_func_t = 0;
pub const FUNC_UNKNOWN: expr_func_t = -1;
pub type C2RustUnnamed_0 = ::core::ffi::c_uint;
pub const TOK_TOINT32: C2RustUnnamed_0 = 14;
pub const TOK_TOFLOAT: C2RustUnnamed_0 = 13;
pub const TOK_END: C2RustUnnamed_0 = 12;
pub const TOK_COMMA: C2RustUnnamed_0 = 11;
pub const TOK_FUNC: C2RustUnnamed_0 = 10;
pub const TOK_CLOSE_CURLY: C2RustUnnamed_0 = 9;
pub const TOK_OPEN_CURLY: C2RustUnnamed_0 = 8;
pub const TOK_CLOSE_SQUARE: C2RustUnnamed_0 = 7;
pub const TOK_OPEN_SQUARE: C2RustUnnamed_0 = 6;
pub const TOK_VAR: C2RustUnnamed_0 = 5;
pub const TOK_CLOSE_PAREN: C2RustUnnamed_0 = 4;
pub const TOK_OPEN_PAREN: C2RustUnnamed_0 = 3;
pub const TOK_OP: C2RustUnnamed_0 = 2;
pub const TOK_INT: C2RustUnnamed_0 = 1;
pub const TOK_FLOAT: C2RustUnnamed_0 = 0;
pub type mapper_expr = *mut _mapper_expr;
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed_1 {
    pub state: state_t,
    pub node: exprnode,
}
pub type state_t = ::core::ffi::c_uint;
pub const END: state_t = 16;
pub const COMMA: state_t = 15;
pub const CLOSE_PAREN: state_t = 14;
pub const OPEN_PAREN: state_t = 13;
pub const CLOSE_HISTINDEX: state_t = 12;
pub const CLOSE_VECTINDEX: state_t = 11;
pub const VAR_HISTINDEX: state_t = 10;
pub const VAR_VECTINDEX: state_t = 9;
pub const VAR_RIGHT: state_t = 8;
pub const NEGATE: state_t = 7;
pub const VALUE: state_t = 6;
pub const TERM_RIGHT: state_t = 5;
pub const TERM: state_t = 4;
pub const EXPR_RIGHT: state_t = 3;
pub const EXPR: state_t = 2;
pub const YEQUAL_EQ: state_t = 1;
pub const YEQUAL_Y: state_t = 0;
pub type stack_obj_t = _stack_obj;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _stack_obj {
    pub c2rust_unnamed: C2RustUnnamed_1,
    pub type_0: C2RustUnnamed_2,
}
pub type C2RustUnnamed_2 = ::core::ffi::c_uint;
pub const ST_NODE: C2RustUnnamed_2 = 1;
pub const ST_STATE: C2RustUnnamed_2 = 0;
pub type func_float_arity2 = unsafe extern "C" fn(
    ::core::ffi::c_float,
    ::core::ffi::c_float,
) -> ::core::ffi::c_float;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct C2RustUnnamed_3 {
    pub name: *const ::core::ffi::c_char,
    pub arity: ::core::ffi::c_uint,
    pub func: *mut ::core::ffi::c_void,
}
pub type func_float_arity1 = unsafe extern "C" fn(
    ::core::ffi::c_float,
) -> ::core::ffi::c_float;
pub type func_float_arity0 = unsafe extern "C" fn() -> ::core::ffi::c_float;
pub const _CACHED_RUNES: ::core::ffi::c_int = (1 as ::core::ffi::c_int)
    << 8 as ::core::ffi::c_int;
pub const _CTYPE_A: ::core::ffi::c_long = 0x100 as ::core::ffi::c_long;
pub const _CTYPE_D: ::core::ffi::c_long = 0x400 as ::core::ffi::c_long;
#[inline]
unsafe extern "C" fn isascii(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return (_c & !(0x7f as ::core::ffi::c_int) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn __istype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> ::core::ffi::c_int {
    return if isascii(_c as ::core::ffi::c_int) != 0 {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    } else {
        (__maskrune(_c, _f) != 0) as ::core::ffi::c_int
    };
}
#[inline]
unsafe extern "C" fn __isctype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> __darwin_ct_rune_t {
    return if _c < 0 as ::core::ffi::c_int || _c >= _CACHED_RUNES {
        0 as __darwin_ct_rune_t
    } else {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    };
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isalpha(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_A as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isdigit(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __isctype(_c as __darwin_ct_rune_t, _CTYPE_D as ::core::ffi::c_ulong)
        as ::core::ffi::c_int;
}
pub const M_PI: ::core::ffi::c_double = 3.14159265358979323846264338327950288f64;
unsafe extern "C" fn minf(
    mut x: ::core::ffi::c_float,
    mut y: ::core::ffi::c_float,
) -> ::core::ffi::c_float {
    if y < x { return y } else { return x };
}
unsafe extern "C" fn maxf(
    mut x: ::core::ffi::c_float,
    mut y: ::core::ffi::c_float,
) -> ::core::ffi::c_float {
    if y > x { return y } else { return x };
}
unsafe extern "C" fn pif() -> ::core::ffi::c_float {
    return M_PI as ::core::ffi::c_float;
}
static mut function_table: [C2RustUnnamed_3; 28] = unsafe {
    [
        {
            let mut init = C2RustUnnamed_3 {
                name: b"pow\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 2 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        powf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"sin\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        sinf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"cos\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        cosf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"tan\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        tanf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"abs\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        fabsf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"sqrt\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        sqrtf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"log\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        logf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"log10\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        log10f
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"exp\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        expf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"floor\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        floorf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"round\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        roundf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"ceil\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        ceilf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"asin\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        asinf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"acos\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        acosf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"atan\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        atanf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"atan2\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 2 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        atan2f
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"sinh\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        sinhf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"cosh\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        coshf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"tanh\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        tanhf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"logb\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        logbf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"exp2\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        exp2f
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"log2\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        log2f
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"hypot\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 2 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        hypotf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"cbrt\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        cbrtf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"trunc\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 1 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        truncf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"min\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 2 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        minf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"max\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 2 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<
                        unsafe extern "C" fn(
                            ::core::ffi::c_float,
                            ::core::ffi::c_float,
                        ) -> ::core::ffi::c_float,
                    >,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        maxf
                            as unsafe extern "C" fn(
                                ::core::ffi::c_float,
                                ::core::ffi::c_float,
                            ) -> ::core::ffi::c_float,
                    ),
                ),
            };
            init
        },
        {
            let mut init = C2RustUnnamed_3 {
                name: b"pi\0" as *const u8 as *const ::core::ffi::c_char,
                arity: 0 as ::core::ffi::c_uint,
                func: ::core::mem::transmute::<
                    Option<unsafe extern "C" fn() -> ::core::ffi::c_float>,
                    *mut ::core::ffi::c_void,
                >(
                    Some(
                        ::core::mem::transmute::<
                            unsafe extern "C" fn() -> ::core::ffi::c_float,
                            unsafe extern "C" fn() -> ::core::ffi::c_float,
                        >(pif),
                    ),
                ),
            };
            init
        },
    ]
};
unsafe extern "C" fn function_lookup(
    mut s: *const ::core::ffi::c_char,
    mut len: ::core::ffi::c_int,
) -> expr_func_t {
    let mut i: ::core::ffi::c_int = 0;
    i = 0 as ::core::ffi::c_int;
    while i < N_FUNCS as ::core::ffi::c_int {
        if strncmp(s, function_table[i as usize].name, len as size_t)
            == 0 as ::core::ffi::c_int
        {
            return i as expr_func_t;
        }
        i += 1;
    }
    return FUNC_UNKNOWN;
}
unsafe extern "C" fn expr_lex(
    mut str: *mut *const ::core::ffi::c_char,
    mut tok: *mut token_t,
) -> ::core::ffi::c_int {
    let mut current_block: u64;
    let mut n: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut c: ::core::ffi::c_char = **str;
    let mut s: *const ::core::ffi::c_char = 0 as *const ::core::ffi::c_char;
    let mut integer_found: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    if c as ::core::ffi::c_int == 0 as ::core::ffi::c_int {
        (*tok).type_0 = TOK_END;
        return 0 as ::core::ffi::c_int;
    }
    loop {
        if isdigit(c as ::core::ffi::c_int) != 0 {
            s = *str;
            loop {
                *str = (*str).offset(1);
                c = **str;
                if !(c as ::core::ffi::c_int != 0
                    && isdigit(c as ::core::ffi::c_int) != 0)
                {
                    break;
                }
            }
            n = atoi(s);
            integer_found = 1 as ::core::ffi::c_int;
            if c as ::core::ffi::c_int != '.' as i32 {
                (*tok).c2rust_unnamed.i = n;
                (*tok).type_0 = TOK_INT;
                return 0 as ::core::ffi::c_int;
            }
        }
        match c as ::core::ffi::c_int {
            46 => {
                s = *str;
                *str = (*str).offset(1);
                c = **str;
                if isdigit(c as ::core::ffi::c_int) == 0 && integer_found != 0 {
                    (*tok).type_0 = TOK_FLOAT;
                    (*tok).c2rust_unnamed.f = n as ::core::ffi::c_float;
                    return 0 as ::core::ffi::c_int;
                }
                if isdigit(c as ::core::ffi::c_int) == 0 {
                    current_block = 6072622540298447352;
                    break;
                } else {
                    current_block = 4808432441040389987;
                    break;
                }
            }
            43 | 45 | 47 | 42 | 61 => {
                (*tok).type_0 = TOK_OP;
                (*tok).c2rust_unnamed.op = c;
                *str = (*str).offset(1);
                return 0 as ::core::ffi::c_int;
            }
            40 => {
                (*tok).type_0 = TOK_OPEN_PAREN;
                *str = (*str).offset(1);
                return 0 as ::core::ffi::c_int;
            }
            41 => {
                (*tok).type_0 = TOK_CLOSE_PAREN;
                *str = (*str).offset(1);
                return 0 as ::core::ffi::c_int;
            }
            120 | 121 => {
                (*tok).type_0 = TOK_VAR;
                (*tok).c2rust_unnamed.var = c;
                *str = (*str).offset(1);
                return 0 as ::core::ffi::c_int;
            }
            91 => {
                (*tok).type_0 = TOK_OPEN_SQUARE;
                *str = (*str).offset(1);
                return 0 as ::core::ffi::c_int;
            }
            93 => {
                (*tok).type_0 = TOK_CLOSE_SQUARE;
                *str = (*str).offset(1);
                return 0 as ::core::ffi::c_int;
            }
            123 => {
                (*tok).type_0 = TOK_OPEN_CURLY;
                *str = (*str).offset(1);
                return 0 as ::core::ffi::c_int;
            }
            125 => {
                (*tok).type_0 = TOK_CLOSE_CURLY;
                *str = (*str).offset(1);
                return 0 as ::core::ffi::c_int;
            }
            32 | 9 | 13 | 10 => {
                *str = (*str).offset(1);
                c = **str;
            }
            44 => {
                (*tok).type_0 = TOK_COMMA;
                *str = (*str).offset(1);
                return 0 as ::core::ffi::c_int;
            }
            _ => {
                if isalpha(c as ::core::ffi::c_int) == 0 {
                    current_block = 11793792312832361944;
                    break;
                } else {
                    current_block = 5892776923941496671;
                    break;
                }
            }
        }
    }
    match current_block {
        4808432441040389987 => {
            loop {
                *str = (*str).offset(1);
                c = **str;
                if !(c as ::core::ffi::c_int != 0
                    && isdigit(c as ::core::ffi::c_int) != 0)
                {
                    break;
                }
            }
            (*tok).c2rust_unnamed.f = (n as ::core::ffi::c_float as ::core::ffi::c_double
                + atof(s)) as ::core::ffi::c_float;
            (*tok).type_0 = TOK_FLOAT;
            return 0 as ::core::ffi::c_int;
        }
        5892776923941496671 => {
            s = *str;
            while c as ::core::ffi::c_int != 0
                && (isalpha(c as ::core::ffi::c_int) != 0
                    || isdigit(c as ::core::ffi::c_int) != 0)
            {
                *str = (*str).offset(1);
                c = **str;
            }
            (*tok).type_0 = TOK_FUNC;
            (*tok).c2rust_unnamed.func = function_lookup(
                s,
                (*str).offset_from(s) as ::core::ffi::c_long as ::core::ffi::c_int,
            );
            return 0 as ::core::ffi::c_int;
        }
        11793792312832361944 => {
            printf(
                b"unknown character '%c' in lexer\n\0" as *const u8
                    as *const ::core::ffi::c_char,
                c as ::core::ffi::c_int,
            );
        }
        _ => {}
    }
    return 1 as ::core::ffi::c_int;
}
unsafe extern "C" fn exprnode_new(
    mut tok: *mut token_t,
    mut is_float: ::core::ffi::c_int,
) -> exprnode {
    let mut t: exprnode = malloc(::core::mem::size_of::<_exprnode>() as size_t)
        as exprnode;
    (*t).tok = *tok;
    (*t).is_float = is_float;
    (*t).history_index = 0 as ::core::ffi::c_int;
    (*t).vector_index = 0 as ::core::ffi::c_int;
    (*t).next = 0 as *mut _exprnode;
    return t;
}
unsafe extern "C" fn exprnode_free(mut e: exprnode) {
    while !e.is_null() {
        let mut tmp: exprnode = e;
        e = (*e).next as exprnode;
        free(tmp as *mut ::core::ffi::c_void);
    }
}
#[no_mangle]
pub unsafe extern "C" fn mapper_expr_free(mut expr: mapper_expr) {
    exprnode_free((*expr).node);
    free((*expr).input_history as *mut ::core::ffi::c_void);
    free((*expr).output_history as *mut ::core::ffi::c_void);
    free(expr as *mut ::core::ffi::c_void);
}
unsafe extern "C" fn collapse_expr_to_left(
    mut plhs: *mut exprnode,
    mut rhs: exprnode,
    mut constant_folding: ::core::ffi::c_int,
) {
    let mut refvar: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut is_float: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut rhs_last: exprnode = rhs;
    if (*rhs).tok.type_0 as ::core::ffi::c_uint
        == TOK_VAR as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        refvar = 1 as ::core::ffi::c_int;
    }
    while !(*rhs_last).next.is_null() {
        if (*rhs_last).tok.type_0 as ::core::ffi::c_uint
            == TOK_VAR as ::core::ffi::c_int as ::core::ffi::c_uint
        {
            refvar = 1 as ::core::ffi::c_int;
        }
        rhs_last = (*rhs_last).next as exprnode;
    }
    let mut plhs_last: *mut exprnode = plhs;
    if (**plhs_last).tok.type_0 as ::core::ffi::c_uint
        == TOK_VAR as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        refvar = 1 as ::core::ffi::c_int;
    }
    while !(**plhs_last).next.is_null() {
        if (**plhs_last).tok.type_0 as ::core::ffi::c_uint
            == TOK_VAR as ::core::ffi::c_int as ::core::ffi::c_uint
        {
            refvar = 1 as ::core::ffi::c_int;
        }
        plhs_last = &mut (**plhs_last).next as *mut exprnode;
    }
    let mut coerce: token_t = _token {
        type_0: TOK_FLOAT,
        c2rust_unnamed: C2RustUnnamed { f: 0. },
    };
    coerce.type_0 = TOK_TOFLOAT;
    is_float = ((**plhs_last).is_float != 0 || (*rhs_last).is_float != 0)
        as ::core::ffi::c_int;
    if (**plhs_last).is_float != 0 && (*rhs_last).is_float == 0 {
        (*rhs_last).next = exprnode_new(&mut coerce, 1 as ::core::ffi::c_int)
            as *mut _exprnode;
        rhs_last = (*rhs_last).next as exprnode;
    } else if (**plhs_last).is_float == 0 && (*rhs_last).is_float != 0 {
        let mut e: exprnode = exprnode_new(&mut coerce, 1 as ::core::ffi::c_int);
        (*e).next = *plhs_last as *mut _exprnode;
        *plhs_last = e;
        plhs_last = &mut (*e).next as *mut exprnode;
        (*(*e).next).is_float = 1 as ::core::ffi::c_int;
    }
    (*rhs_last).next = *plhs_last as *mut _exprnode;
    *plhs_last = rhs;
    if constant_folding != 0 && refvar == 0 {
        let mut e_0: _mapper_expr = _mapper_expr {
            node: 0 as *mut _exprnode,
            vector_size: 0,
            history_size: 0,
            history_pos: 0,
            input_history: 0 as *mut mapper_signal_value_t,
            output_history: 0 as *mut mapper_signal_value_t,
        };
        e_0.node = *plhs;
        let mut v: mapper_signal_value_t = _mapper_signal_value_t { f: 0. };
        mapper_expr_evaluate(
            &mut e_0,
            0 as *mut ::core::ffi::c_void,
            &mut v as *mut mapper_signal_value_t as *mut ::core::ffi::c_void,
        );
        exprnode_free((**plhs).next as exprnode);
        (**plhs).next = 0 as *mut _exprnode;
        (**plhs).is_float = is_float;
        if is_float != 0 {
            (**plhs).tok.type_0 = TOK_FLOAT;
            (**plhs).tok.c2rust_unnamed.f = v.f;
        } else {
            (**plhs).tok.type_0 = TOK_INT;
            (**plhs).tok.c2rust_unnamed.i = v.i32_0;
        }
    }
}
#[no_mangle]
pub unsafe extern "C" fn mapper_expr_new_from_string(
    mut str: *const ::core::ffi::c_char,
    mut input_is_float: ::core::ffi::c_int,
    mut output_is_float: ::core::ffi::c_int,
    mut vector_size: ::core::ffi::c_int,
) -> mapper_expr {
    let mut e_2: exprnode = 0 as *mut _exprnode;
    let mut expr: mapper_expr = 0 as *mut _mapper_expr;
    let mut current_block: u64;
    let mut s: *const ::core::ffi::c_char = str;
    if str.is_null() {
        return 0 as mapper_expr;
    }
    let mut stack: [stack_obj_t; 256] = [_stack_obj {
        c2rust_unnamed: C2RustUnnamed_1 { state: YEQUAL_Y },
        type_0: ST_STATE,
    }; 256];
    let mut top: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
    let mut result: exprnode = 0 as exprnode;
    let mut error_message: *const ::core::ffi::c_char = 0 as *const ::core::ffi::c_char;
    let mut tok: token_t = _token {
        type_0: TOK_FLOAT,
        c2rust_unnamed: C2RustUnnamed { f: 0. },
    };
    let mut i: ::core::ffi::c_int = 0;
    let mut next_token: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    let mut var_allowed: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    let mut oldest_samps: ::core::ffi::c_float = 0 as ::core::ffi::c_int
        as ::core::ffi::c_float;
    top += 1;
    stack[top as usize].c2rust_unnamed.state = EXPR;
    stack[top as usize].type_0 = ST_STATE;
    top += 1;
    stack[top as usize].c2rust_unnamed.state = YEQUAL_EQ;
    stack[top as usize].type_0 = ST_STATE;
    top += 1;
    stack[top as usize].c2rust_unnamed.state = YEQUAL_Y;
    stack[top as usize].type_0 = ST_STATE;
    while top >= 0 as ::core::ffi::c_int {
        if next_token != 0 && expr_lex(&mut s, &mut tok) != 0 {
            error_message = b"Error in lexical analysis.\0" as *const u8
                as *const ::core::ffi::c_char;
            result = 0 as exprnode;
            break;
        } else {
            next_token = 0 as ::core::ffi::c_int;
            if stack[top as usize].type_0 as ::core::ffi::c_uint
                == ST_NODE as ::core::ffi::c_int as ::core::ffi::c_uint
            {
                if top == 0 as ::core::ffi::c_int {
                    result = stack[top as usize].c2rust_unnamed.node;
                    break;
                } else {
                    if !(stack[(top - 1 as ::core::ffi::c_int) as usize].type_0
                        as ::core::ffi::c_uint
                        == ST_STATE as ::core::ffi::c_int as ::core::ffi::c_uint)
                    {
                        continue;
                    }
                    if top >= 2 as ::core::ffi::c_int
                        && stack[(top - 2 as ::core::ffi::c_int) as usize].type_0
                            as ::core::ffi::c_uint
                            == ST_NODE as ::core::ffi::c_int as ::core::ffi::c_uint
                    {
                        if stack[(top - 1 as ::core::ffi::c_int) as usize].type_0
                            as ::core::ffi::c_uint
                            == ST_STATE as ::core::ffi::c_int as ::core::ffi::c_uint
                            && (stack[(top - 1 as ::core::ffi::c_int) as usize]
                                .c2rust_unnamed
                                .state as ::core::ffi::c_uint
                                == EXPR_RIGHT as ::core::ffi::c_int as ::core::ffi::c_uint
                                || stack[(top - 1 as ::core::ffi::c_int) as usize]
                                    .c2rust_unnamed
                                    .state as ::core::ffi::c_uint
                                    == TERM_RIGHT as ::core::ffi::c_int as ::core::ffi::c_uint
                                || stack[(top - 1 as ::core::ffi::c_int) as usize]
                                    .c2rust_unnamed
                                    .state as ::core::ffi::c_uint
                                    == CLOSE_PAREN as ::core::ffi::c_int as ::core::ffi::c_uint)
                        {
                            collapse_expr_to_left(
                                &mut (*stack
                                    .as_mut_ptr()
                                    .offset((top - 2 as ::core::ffi::c_int) as isize))
                                    .c2rust_unnamed
                                    .node,
                                stack[top as usize].c2rust_unnamed.node,
                                1 as ::core::ffi::c_int,
                            );
                            top -= 1;
                        } else if stack[(top - 1 as ::core::ffi::c_int) as usize].type_0
                            as ::core::ffi::c_uint
                            == ST_STATE as ::core::ffi::c_int as ::core::ffi::c_uint
                            && stack[(top - 1 as ::core::ffi::c_int) as usize]
                                .c2rust_unnamed
                                .state as ::core::ffi::c_uint
                                == CLOSE_HISTINDEX as ::core::ffi::c_int
                                    as ::core::ffi::c_uint
                        {
                            if (*stack[top as usize].c2rust_unnamed.node).tok.type_0
                                as ::core::ffi::c_uint
                                == TOK_FLOAT as ::core::ffi::c_int as ::core::ffi::c_uint
                            {
                                (*stack[(top - 2 as ::core::ffi::c_int) as usize]
                                    .c2rust_unnamed
                                    .node)
                                    .history_index = (*stack[top as usize].c2rust_unnamed.node)
                                    .tok
                                    .c2rust_unnamed
                                    .f as ::core::ffi::c_int;
                            } else {
                                (*stack[(top - 2 as ::core::ffi::c_int) as usize]
                                    .c2rust_unnamed
                                    .node)
                                    .history_index = (*stack[top as usize].c2rust_unnamed.node)
                                    .tok
                                    .c2rust_unnamed
                                    .i;
                            }
                            if oldest_samps
                                > (*stack[(top - 2 as ::core::ffi::c_int) as usize]
                                    .c2rust_unnamed
                                    .node)
                                    .history_index as ::core::ffi::c_float
                            {
                                oldest_samps = (*stack[(top - 2 as ::core::ffi::c_int)
                                        as usize]
                                    .c2rust_unnamed
                                    .node)
                                    .history_index as ::core::ffi::c_float;
                            }
                            exprnode_free(stack[top as usize].c2rust_unnamed.node);
                            top -= 1;
                        } else {
                            if !(stack[(top - 1 as ::core::ffi::c_int) as usize].type_0
                                as ::core::ffi::c_uint
                                == ST_STATE as ::core::ffi::c_int as ::core::ffi::c_uint
                                && stack[(top - 1 as ::core::ffi::c_int) as usize]
                                    .c2rust_unnamed
                                    .state as ::core::ffi::c_uint
                                    == CLOSE_VECTINDEX as ::core::ffi::c_int
                                        as ::core::ffi::c_uint)
                            {
                                continue;
                            }
                            if (*stack[top as usize].c2rust_unnamed.node).tok.type_0
                                as ::core::ffi::c_uint
                                == TOK_FLOAT as ::core::ffi::c_int as ::core::ffi::c_uint
                            {
                                (*stack[(top - 2 as ::core::ffi::c_int) as usize]
                                    .c2rust_unnamed
                                    .node)
                                    .vector_index = (*stack[top as usize].c2rust_unnamed.node)
                                    .tok
                                    .c2rust_unnamed
                                    .f as ::core::ffi::c_int;
                            } else {
                                (*stack[(top - 2 as ::core::ffi::c_int) as usize]
                                    .c2rust_unnamed
                                    .node)
                                    .vector_index = (*stack[top as usize].c2rust_unnamed.node)
                                    .tok
                                    .c2rust_unnamed
                                    .i;
                            }
                            if (*stack[(top - 2 as ::core::ffi::c_int) as usize]
                                .c2rust_unnamed
                                .node)
                                .vector_index > 0 as ::core::ffi::c_int
                            {
                                error_message = b"Vector indexing not yet implemented.\0"
                                    as *const u8 as *const ::core::ffi::c_char;
                                result = 0 as exprnode;
                                break;
                            } else if (*stack[(top - 2 as ::core::ffi::c_int) as usize]
                                .c2rust_unnamed
                                .node)
                                .vector_index < 0 as ::core::ffi::c_int
                                || (*stack[(top - 2 as ::core::ffi::c_int) as usize]
                                    .c2rust_unnamed
                                    .node)
                                    .vector_index >= vector_size
                            {
                                error_message = b"Vector index outside input size.\0"
                                    as *const u8 as *const ::core::ffi::c_char;
                                result = 0 as exprnode;
                                break;
                            } else {
                                exprnode_free(stack[top as usize].c2rust_unnamed.node);
                                top -= 1;
                            }
                        }
                    } else {
                        let mut tmp: stack_obj_t = stack[(top - 1 as ::core::ffi::c_int)
                            as usize];
                        stack[(top - 1 as ::core::ffi::c_int) as usize] = stack[top
                            as usize];
                        stack[top as usize] = tmp;
                    }
                }
            } else {
                match stack[top as usize].c2rust_unnamed.state as ::core::ffi::c_uint {
                    0 => {
                        if tok.type_0 as ::core::ffi::c_uint
                            == TOK_VAR as ::core::ffi::c_int as ::core::ffi::c_uint
                            && tok.c2rust_unnamed.var as ::core::ffi::c_int == 'y' as i32
                        {
                            top -= 1;
                            next_token = 1 as ::core::ffi::c_int;
                        } else {
                            error_message = b"Error in y= prefix.\0" as *const u8
                                as *const ::core::ffi::c_char;
                            result = 0 as exprnode;
                            break;
                        }
                    }
                    1 => {
                        if tok.type_0 as ::core::ffi::c_uint
                            == TOK_OP as ::core::ffi::c_int as ::core::ffi::c_uint
                            && tok.c2rust_unnamed.op as ::core::ffi::c_int == '=' as i32
                        {
                            top -= 1;
                            next_token = 1 as ::core::ffi::c_int;
                        } else {
                            error_message = b"Error in y= prefix.\0" as *const u8
                                as *const ::core::ffi::c_char;
                            result = 0 as exprnode;
                            break;
                        }
                    }
                    2 => {
                        top -= 1;
                        top += 1;
                        stack[top as usize].c2rust_unnamed.state = EXPR_RIGHT;
                        stack[top as usize].type_0 = ST_STATE;
                        top += 1;
                        stack[top as usize].c2rust_unnamed.state = TERM;
                        stack[top as usize].type_0 = ST_STATE;
                    }
                    3 => {
                        if tok.type_0 as ::core::ffi::c_uint
                            == TOK_OP as ::core::ffi::c_int as ::core::ffi::c_uint
                        {
                            top -= 1;
                            if tok.c2rust_unnamed.op as ::core::ffi::c_int == '+' as i32
                                || tok.c2rust_unnamed.op as ::core::ffi::c_int == '-' as i32
                            {
                                if stack[top as usize].type_0 as ::core::ffi::c_uint
                                    == ST_NODE as ::core::ffi::c_int as ::core::ffi::c_uint
                                {
                                    let mut e: exprnode = stack[top as usize]
                                        .c2rust_unnamed
                                        .node;
                                    while !(*e).next.is_null() {
                                        e = (*e).next as exprnode;
                                    }
                                    (*e).next = exprnode_new(&mut tok, 0 as ::core::ffi::c_int)
                                        as *mut _exprnode;
                                    (*(*e).next).is_float = (*e).is_float;
                                }
                                top += 1;
                                stack[top as usize].c2rust_unnamed.state = EXPR;
                                stack[top as usize].type_0 = ST_STATE;
                                next_token = 1 as ::core::ffi::c_int;
                            }
                        } else {
                            top -= 1;
                        }
                    }
                    4 => {
                        top -= 1;
                        top += 1;
                        stack[top as usize].c2rust_unnamed.state = TERM_RIGHT;
                        stack[top as usize].type_0 = ST_STATE;
                        top += 1;
                        stack[top as usize].c2rust_unnamed.state = VALUE;
                        stack[top as usize].type_0 = ST_STATE;
                    }
                    5 => {
                        if tok.type_0 as ::core::ffi::c_uint
                            == TOK_OP as ::core::ffi::c_int as ::core::ffi::c_uint
                        {
                            top -= 1;
                            if tok.c2rust_unnamed.op as ::core::ffi::c_int == '*' as i32
                                || tok.c2rust_unnamed.op as ::core::ffi::c_int == '/' as i32
                            {
                                if stack[top as usize].type_0 as ::core::ffi::c_uint
                                    == ST_NODE as ::core::ffi::c_int as ::core::ffi::c_uint
                                {
                                    let mut e_0: exprnode = stack[top as usize]
                                        .c2rust_unnamed
                                        .node;
                                    while !(*e_0).next.is_null() {
                                        e_0 = (*e_0).next as exprnode;
                                    }
                                    (*e_0).next = exprnode_new(
                                        &mut tok,
                                        0 as ::core::ffi::c_int,
                                    ) as *mut _exprnode;
                                    (*(*e_0).next).is_float = (*e_0).is_float;
                                }
                                top += 1;
                                stack[top as usize].c2rust_unnamed.state = TERM;
                                stack[top as usize].type_0 = ST_STATE;
                                next_token = 1 as ::core::ffi::c_int;
                            }
                        } else {
                            top -= 1;
                        }
                    }
                    6 => {
                        if tok.type_0 as ::core::ffi::c_uint
                            == TOK_INT as ::core::ffi::c_int as ::core::ffi::c_uint
                        {
                            top -= 1;
                            top += 1;
                            stack[top as usize].c2rust_unnamed.node = exprnode_new(
                                &mut tok,
                                0 as ::core::ffi::c_int,
                            );
                            stack[top as usize].type_0 = ST_NODE;
                            next_token = 1 as ::core::ffi::c_int;
                        } else if tok.type_0 as ::core::ffi::c_uint
                            == TOK_FLOAT as ::core::ffi::c_int as ::core::ffi::c_uint
                        {
                            top -= 1;
                            top += 1;
                            stack[top as usize].c2rust_unnamed.node = exprnode_new(
                                &mut tok,
                                1 as ::core::ffi::c_int,
                            );
                            stack[top as usize].type_0 = ST_NODE;
                            next_token = 1 as ::core::ffi::c_int;
                        } else if tok.type_0 as ::core::ffi::c_uint
                            == TOK_VAR as ::core::ffi::c_int as ::core::ffi::c_uint
                        {
                            if var_allowed != 0 {
                                top -= 1;
                                top += 1;
                                stack[top as usize].c2rust_unnamed.node = exprnode_new(
                                    &mut tok,
                                    input_is_float,
                                );
                                stack[top as usize].type_0 = ST_NODE;
                                top += 1;
                                stack[top as usize].c2rust_unnamed.state = VAR_RIGHT;
                                stack[top as usize].type_0 = ST_STATE;
                                next_token = 1 as ::core::ffi::c_int;
                            } else {
                                error_message = b"Unexpected variable reference.\0"
                                    as *const u8 as *const ::core::ffi::c_char;
                                result = 0 as exprnode;
                                break;
                            }
                        } else if tok.type_0 as ::core::ffi::c_uint
                            == TOK_OPEN_PAREN as ::core::ffi::c_int
                                as ::core::ffi::c_uint
                        {
                            top -= 1;
                            top += 1;
                            stack[top as usize].c2rust_unnamed.state = CLOSE_PAREN;
                            stack[top as usize].type_0 = ST_STATE;
                            top += 1;
                            stack[top as usize].c2rust_unnamed.state = EXPR;
                            stack[top as usize].type_0 = ST_STATE;
                            next_token = 1 as ::core::ffi::c_int;
                        } else if tok.type_0 as ::core::ffi::c_uint
                            == TOK_FUNC as ::core::ffi::c_int as ::core::ffi::c_uint
                        {
                            top -= 1;
                            if tok.c2rust_unnamed.func as ::core::ffi::c_int
                                == FUNC_UNKNOWN as ::core::ffi::c_int
                            {
                                error_message = b"Unknown function.\0" as *const u8
                                    as *const ::core::ffi::c_char;
                                result = 0 as exprnode;
                                break;
                            } else {
                                top += 1;
                                stack[top as usize].c2rust_unnamed.node = exprnode_new(
                                    &mut tok,
                                    1 as ::core::ffi::c_int,
                                );
                                stack[top as usize].type_0 = ST_NODE;
                                let mut arity: ::core::ffi::c_int = function_table[tok
                                        .c2rust_unnamed
                                        .func as usize]
                                    .arity as ::core::ffi::c_int;
                                if arity > 0 as ::core::ffi::c_int {
                                    top += 1;
                                    stack[top as usize].c2rust_unnamed.state = CLOSE_PAREN;
                                    stack[top as usize].type_0 = ST_STATE;
                                    top += 1;
                                    stack[top as usize].c2rust_unnamed.state = EXPR;
                                    stack[top as usize].type_0 = ST_STATE;
                                    i = 1 as ::core::ffi::c_int;
                                    while i < arity {
                                        top += 1;
                                        stack[top as usize].c2rust_unnamed.state = COMMA;
                                        stack[top as usize].type_0 = ST_STATE;
                                        top += 1;
                                        stack[top as usize].c2rust_unnamed.state = EXPR;
                                        stack[top as usize].type_0 = ST_STATE;
                                        i += 1;
                                    }
                                    top += 1;
                                    stack[top as usize].c2rust_unnamed.state = OPEN_PAREN;
                                    stack[top as usize].type_0 = ST_STATE;
                                }
                                next_token = 1 as ::core::ffi::c_int;
                            }
                        } else if tok.type_0 as ::core::ffi::c_uint
                            == TOK_OP as ::core::ffi::c_int as ::core::ffi::c_uint
                            && tok.c2rust_unnamed.op as ::core::ffi::c_int == '-' as i32
                        {
                            top -= 1;
                            top += 1;
                            stack[top as usize].c2rust_unnamed.state = NEGATE;
                            stack[top as usize].type_0 = ST_STATE;
                            top += 1;
                            stack[top as usize].c2rust_unnamed.state = VALUE;
                            stack[top as usize].type_0 = ST_STATE;
                            next_token = 1 as ::core::ffi::c_int;
                        } else {
                            error_message = b"Expected value.\0" as *const u8
                                as *const ::core::ffi::c_char;
                            result = 0 as exprnode;
                            break;
                        }
                    }
                    7 => {
                        top -= 1;
                        if stack[top as usize].type_0 as ::core::ffi::c_uint
                            == ST_NODE as ::core::ffi::c_int as ::core::ffi::c_uint
                        {
                            let mut t: token_t = _token {
                                type_0: TOK_FLOAT,
                                c2rust_unnamed: C2RustUnnamed { f: 0. },
                            };
                            t.type_0 = TOK_INT;
                            t.c2rust_unnamed.i = 0 as ::core::ffi::c_int;
                            let mut e_1: exprnode = exprnode_new(
                                &mut t,
                                0 as ::core::ffi::c_int,
                            );
                            t.type_0 = TOK_OP;
                            t.c2rust_unnamed.op = '-' as i32 as ::core::ffi::c_char;
                            (*e_1).next = exprnode_new(&mut t, 0 as ::core::ffi::c_int)
                                as *mut _exprnode;
                            collapse_expr_to_left(
                                &mut e_1,
                                stack[top as usize].c2rust_unnamed.node,
                                1 as ::core::ffi::c_int,
                            );
                            stack[top as usize].c2rust_unnamed.node = e_1;
                        } else {
                            error_message = b"Expected to negate an expression.\0"
                                as *const u8 as *const ::core::ffi::c_char;
                            result = 0 as exprnode;
                            break;
                        }
                    }
                    8 => {
                        if tok.type_0 as ::core::ffi::c_uint
                            == TOK_OPEN_SQUARE as ::core::ffi::c_int
                                as ::core::ffi::c_uint
                        {
                            top -= 1;
                            top += 1;
                            stack[top as usize].c2rust_unnamed.state = VAR_VECTINDEX;
                            stack[top as usize].type_0 = ST_STATE;
                        } else if tok.type_0 as ::core::ffi::c_uint
                            == TOK_OPEN_CURLY as ::core::ffi::c_int
                                as ::core::ffi::c_uint
                        {
                            top -= 1;
                            top += 1;
                            stack[top as usize].c2rust_unnamed.state = VAR_HISTINDEX;
                            stack[top as usize].type_0 = ST_STATE;
                        } else {
                            top -= 1;
                        }
                    }
                    9 => {
                        top -= 1;
                        if tok.type_0 as ::core::ffi::c_uint
                            == TOK_OPEN_SQUARE as ::core::ffi::c_int
                                as ::core::ffi::c_uint
                        {
                            var_allowed = 0 as ::core::ffi::c_int;
                            top += 1;
                            stack[top as usize].c2rust_unnamed.state = CLOSE_VECTINDEX;
                            stack[top as usize].type_0 = ST_STATE;
                            top += 1;
                            stack[top as usize].c2rust_unnamed.state = EXPR;
                            stack[top as usize].type_0 = ST_STATE;
                            next_token = 1 as ::core::ffi::c_int;
                        }
                    }
                    10 => {
                        top -= 1;
                        if tok.type_0 as ::core::ffi::c_uint
                            == TOK_OPEN_CURLY as ::core::ffi::c_int
                                as ::core::ffi::c_uint
                        {
                            var_allowed = 0 as ::core::ffi::c_int;
                            top += 1;
                            stack[top as usize].c2rust_unnamed.state = CLOSE_HISTINDEX;
                            stack[top as usize].type_0 = ST_STATE;
                            top += 1;
                            stack[top as usize].c2rust_unnamed.state = EXPR;
                            stack[top as usize].type_0 = ST_STATE;
                            next_token = 1 as ::core::ffi::c_int;
                        }
                    }
                    11 => {
                        if tok.type_0 as ::core::ffi::c_uint
                            == TOK_CLOSE_SQUARE as ::core::ffi::c_int
                                as ::core::ffi::c_uint
                        {
                            var_allowed = 1 as ::core::ffi::c_int;
                            top -= 1;
                            top += 1;
                            stack[top as usize].c2rust_unnamed.state = VAR_HISTINDEX;
                            stack[top as usize].type_0 = ST_STATE;
                            next_token = 1 as ::core::ffi::c_int;
                        } else {
                            error_message = b"Expected ']'.\0" as *const u8
                                as *const ::core::ffi::c_char;
                            result = 0 as exprnode;
                            break;
                        }
                    }
                    12 => {
                        if tok.type_0 as ::core::ffi::c_uint
                            == TOK_CLOSE_CURLY as ::core::ffi::c_int
                                as ::core::ffi::c_uint
                        {
                            var_allowed = 1 as ::core::ffi::c_int;
                            top -= 1;
                            top += 1;
                            stack[top as usize].c2rust_unnamed.state = VAR_VECTINDEX;
                            stack[top as usize].type_0 = ST_STATE;
                            next_token = 1 as ::core::ffi::c_int;
                        } else {
                            error_message = b"Expected '}'.\0" as *const u8
                                as *const ::core::ffi::c_char;
                            result = 0 as exprnode;
                            break;
                        }
                    }
                    14 => {
                        if tok.type_0 as ::core::ffi::c_uint
                            == TOK_CLOSE_PAREN as ::core::ffi::c_int
                                as ::core::ffi::c_uint
                        {
                            top -= 1;
                            next_token = 1 as ::core::ffi::c_int;
                        } else {
                            error_message = b"Expected ')'.\0" as *const u8
                                as *const ::core::ffi::c_char;
                            result = 0 as exprnode;
                            break;
                        }
                    }
                    15 => {
                        if tok.type_0 as ::core::ffi::c_uint
                            == TOK_COMMA as ::core::ffi::c_int as ::core::ffi::c_uint
                        {
                            top -= 1;
                            i = top - 1 as ::core::ffi::c_int;
                            while i >= 0 as ::core::ffi::c_int
                                && stack[i as usize].type_0 as ::core::ffi::c_uint
                                    != ST_NODE as ::core::ffi::c_int as ::core::ffi::c_uint
                            {
                                i -= 1;
                            }
                            if i >= 0 as ::core::ffi::c_int {
                                collapse_expr_to_left(
                                    &mut (*stack.as_mut_ptr().offset(i as isize))
                                        .c2rust_unnamed
                                        .node,
                                    stack[top as usize].c2rust_unnamed.node,
                                    0 as ::core::ffi::c_int,
                                );
                                top -= 1;
                            }
                            next_token = 1 as ::core::ffi::c_int;
                        } else {
                            error_message = b"Expected ','.\0" as *const u8
                                as *const ::core::ffi::c_char;
                            result = 0 as exprnode;
                            break;
                        }
                    }
                    13 => {
                        if tok.type_0 as ::core::ffi::c_uint
                            == TOK_OPEN_PAREN as ::core::ffi::c_int
                                as ::core::ffi::c_uint
                        {
                            top -= 1;
                            next_token = 1 as ::core::ffi::c_int;
                        } else {
                            error_message = b"Expected '('.\0" as *const u8
                                as *const ::core::ffi::c_char;
                            result = 0 as exprnode;
                            break;
                        }
                    }
                    16 => {
                        if tok.type_0 as ::core::ffi::c_uint
                            == TOK_END as ::core::ffi::c_int as ::core::ffi::c_uint
                        {
                            top -= 1;
                        } else {
                            error_message = b"Expected END.\0" as *const u8
                                as *const ::core::ffi::c_char;
                            result = 0 as exprnode;
                            break;
                        }
                    }
                    _ => {
                        error_message = b"Unexpected parser state.\0" as *const u8
                            as *const ::core::ffi::c_char;
                        result = 0 as exprnode;
                        break;
                    }
                }
            }
        }
    }
    if result.is_null() {
        if !error_message.is_null() {
            printf(b"%s\n\0" as *const u8 as *const ::core::ffi::c_char, error_message);
        }
    } else if !(oldest_samps < -(100 as ::core::ffi::c_int) as ::core::ffi::c_float) {
        e_2 = result;
        while !(*e_2).next.is_null() {
            e_2 = (*e_2).next as exprnode;
        }
        if (*e_2).is_float != 0 && output_is_float == 0 {
            let mut coerce: token_t = _token {
                type_0: TOK_FLOAT,
                c2rust_unnamed: C2RustUnnamed { f: 0. },
            };
            coerce.type_0 = TOK_TOINT32;
            (*e_2).next = exprnode_new(&mut coerce, 0 as ::core::ffi::c_int)
                as *mut _exprnode;
            (*(*e_2).next).is_float = 0 as ::core::ffi::c_int;
        } else if (*e_2).is_float == 0 && output_is_float != 0 {
            let mut coerce_0: token_t = _token {
                type_0: TOK_FLOAT,
                c2rust_unnamed: C2RustUnnamed { f: 0. },
            };
            coerce_0.type_0 = TOK_TOFLOAT;
            (*e_2).next = exprnode_new(&mut coerce_0, 0 as ::core::ffi::c_int)
                as *mut _exprnode;
            (*(*e_2).next).is_float = 1 as ::core::ffi::c_int;
        }
        if vector_size > 1 as ::core::ffi::c_int {
            e_2 = result;
            loop {
                if e_2.is_null() {
                    current_block = 3753929071732272283;
                    break;
                }
                if (*e_2).tok.type_0 as ::core::ffi::c_uint
                    == TOK_VAR as ::core::ffi::c_int as ::core::ffi::c_uint
                    && (*e_2).vector_index > 0 as ::core::ffi::c_int
                {
                    current_block = 18205418528004294035;
                    break;
                }
                e_2 = (*e_2).next as exprnode;
            }
        } else {
            current_block = 3753929071732272283;
        }
        match current_block {
            18205418528004294035 => {}
            _ => {
                expr = malloc(::core::mem::size_of::<_mapper_expr>() as size_t)
                    as mapper_expr;
                (*expr).node = result;
                (*expr).vector_size = vector_size;
                (*expr).history_size = ceilf(-oldest_samps) as ::core::ffi::c_int
                    + 1 as ::core::ffi::c_int;
                (*expr).history_pos = -(1 as ::core::ffi::c_int);
                (*expr).input_history = calloc(
                    1 as size_t,
                    (::core::mem::size_of::<mapper_signal_value_t>() as size_t)
                        .wrapping_mul(vector_size as size_t)
                        .wrapping_mul((*expr).history_size as size_t),
                ) as *mut mapper_signal_value_t;
                (*expr).output_history = calloc(
                    1 as size_t,
                    (::core::mem::size_of::<mapper_signal_value_t>() as size_t)
                        .wrapping_mul((*expr).history_size as size_t),
                ) as *mut mapper_signal_value_t;
                return expr;
            }
        }
    }
    i = 0 as ::core::ffi::c_int;
    while i < top {
        if stack[i as usize].type_0 as ::core::ffi::c_uint
            == ST_NODE as ::core::ffi::c_int as ::core::ffi::c_uint
        {
            exprnode_free(stack[i as usize].c2rust_unnamed.node);
        }
        i += 1;
    }
    return 0 as mapper_expr;
}
unsafe extern "C" fn trace_eval(mut s: *const ::core::ffi::c_char, mut args: ...) {}
#[no_mangle]
pub unsafe extern "C" fn mapper_expr_evaluate(
    mut expr: mapper_expr,
    mut input_vector: *mut ::core::ffi::c_void,
    mut output_vector: *mut ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    let mut current_block: u64;
    let mut stack: [mapper_signal_value_t; 256] = [_mapper_signal_value_t {
        f: 0.,
    }; 256];
    let mut left: mapper_signal_value_t = _mapper_signal_value_t { f: 0. };
    let mut right: mapper_signal_value_t = _mapper_signal_value_t { f: 0. };
    let mut top: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
    let mut node: exprnode = (*expr).node;
    if !input_vector.is_null() {
        (*expr).history_pos = ((*expr).history_pos + 1 as ::core::ffi::c_int)
            % (*expr).history_size;
        memcpy(
            &mut *(*expr)
                .input_history
                .offset(((*expr).history_pos * (*expr).vector_size) as isize)
                as *mut mapper_signal_value_t as *mut ::core::ffi::c_void,
            input_vector,
            ((*expr).vector_size as size_t)
                .wrapping_mul(::core::mem::size_of::<mapper_signal_value_t>() as size_t),
        );
    }
    loop {
        if node.is_null() {
            current_block = 12829669402821218572;
            break;
        }
        match (*node).tok.type_0 as ::core::ffi::c_uint {
            1 => {
                top += 1;
                stack[top as usize].i32_0 = (*node).tok.c2rust_unnamed.i;
            }
            0 => {
                top += 1;
                stack[top as usize].f = (*node).tok.c2rust_unnamed.f;
            }
            5 => {
                let mut idx: ::core::ffi::c_int = ((*node).history_index
                    + (*expr).history_pos + (*expr).history_size) % (*expr).history_size;
                match (*node).tok.c2rust_unnamed.var as ::core::ffi::c_int {
                    120 => {
                        idx = idx * (*expr).vector_size + (*node).vector_index;
                        top += 1;
                        stack[top as usize] = *(*expr)
                            .input_history
                            .offset(idx as isize);
                    }
                    121 => {
                        top += 1;
                        stack[top as usize] = *(*expr)
                            .output_history
                            .offset(idx as isize);
                    }
                    _ => {
                        current_block = 13303144130133872306;
                        break;
                    }
                }
            }
            13 => {
                stack[top as usize].f = stack[top as usize].i32_0
                    as ::core::ffi::c_float;
            }
            14 => {
                stack[top as usize].i32_0 = stack[top as usize].f as ::core::ffi::c_int;
            }
            2 => {
                let fresh0 = top;
                top = top - 1;
                right = stack[fresh0 as usize];
                let fresh1 = top;
                top = top - 1;
                left = stack[fresh1 as usize];
                if (*node).is_float != 0 {
                    trace_eval(
                        b"%f %c %f = \0" as *const u8 as *const ::core::ffi::c_char,
                        left.f as ::core::ffi::c_double,
                        (*node).tok.c2rust_unnamed.op as ::core::ffi::c_int,
                        right.f as ::core::ffi::c_double,
                    );
                    match (*node).tok.c2rust_unnamed.op as ::core::ffi::c_int {
                        43 => {
                            top += 1;
                            stack[top as usize].f = left.f + right.f;
                        }
                        45 => {
                            top += 1;
                            stack[top as usize].f = left.f - right.f;
                        }
                        42 => {
                            top += 1;
                            stack[top as usize].f = left.f * right.f;
                        }
                        47 => {
                            top += 1;
                            stack[top as usize].f = left.f / right.f;
                        }
                        _ => {
                            current_block = 13303144130133872306;
                            break;
                        }
                    }
                    trace_eval(
                        b"%f\n\0" as *const u8 as *const ::core::ffi::c_char,
                        stack[top as usize].f as ::core::ffi::c_double,
                    );
                } else {
                    trace_eval(
                        b"%d %c %d = \0" as *const u8 as *const ::core::ffi::c_char,
                        left.i32_0,
                        (*node).tok.c2rust_unnamed.op as ::core::ffi::c_int,
                        right.i32_0,
                    );
                    match (*node).tok.c2rust_unnamed.op as ::core::ffi::c_int {
                        43 => {
                            top += 1;
                            stack[top as usize].i32_0 = left.i32_0 + right.i32_0;
                        }
                        45 => {
                            top += 1;
                            stack[top as usize].i32_0 = left.i32_0 - right.i32_0;
                        }
                        42 => {
                            top += 1;
                            stack[top as usize].i32_0 = left.i32_0 * right.i32_0;
                        }
                        47 => {
                            top += 1;
                            stack[top as usize].i32_0 = left.i32_0 / right.i32_0;
                        }
                        _ => {
                            current_block = 13303144130133872306;
                            break;
                        }
                    }
                    trace_eval(
                        b"%d\n\0" as *const u8 as *const ::core::ffi::c_char,
                        stack[top as usize].i32_0,
                    );
                }
            }
            10 => {
                match function_table[(*node).tok.c2rust_unnamed.func as usize].arity {
                    0 => {
                        top += 1;
                        stack[top as usize].f = ::core::mem::transmute::<
                            _,
                            fn() -> ::core::ffi::c_float,
                        >(
                            ::core::mem::transmute::<
                                *mut ::core::ffi::c_void,
                                Option<func_float_arity0>,
                            >(
                                    function_table[(*node).tok.c2rust_unnamed.func as usize]
                                        .func,
                                )
                                .expect("non-null function pointer"),
                        )();
                        trace_eval(
                            b"%s = %f\n\0" as *const u8 as *const ::core::ffi::c_char,
                            function_table[(*node).tok.c2rust_unnamed.func as usize]
                                .name,
                            stack[top as usize].f as ::core::ffi::c_double,
                        );
                    }
                    1 => {
                        let fresh2 = top;
                        top = top - 1;
                        right = stack[fresh2 as usize];
                        trace_eval(
                            b"%s(%f) = \0" as *const u8 as *const ::core::ffi::c_char,
                            function_table[(*node).tok.c2rust_unnamed.func as usize]
                                .name,
                            right.f as ::core::ffi::c_double,
                        );
                        right.f = ::core::mem::transmute::<
                            *mut ::core::ffi::c_void,
                            Option<func_float_arity1>,
                        >(function_table[(*node).tok.c2rust_unnamed.func as usize].func)
                            .expect("non-null function pointer")(right.f);
                        trace_eval(
                            b"%f\n\0" as *const u8 as *const ::core::ffi::c_char,
                            right.f as ::core::ffi::c_double,
                        );
                        top += 1;
                        stack[top as usize].f = right.f;
                    }
                    2 => {
                        let fresh3 = top;
                        top = top - 1;
                        right = stack[fresh3 as usize];
                        let fresh4 = top;
                        top = top - 1;
                        left = stack[fresh4 as usize];
                        trace_eval(
                            b"%s(%f,%f) = \0" as *const u8 as *const ::core::ffi::c_char,
                            function_table[(*node).tok.c2rust_unnamed.func as usize]
                                .name,
                            left.f as ::core::ffi::c_double,
                            right.f as ::core::ffi::c_double,
                        );
                        right.f = ::core::mem::transmute::<
                            *mut ::core::ffi::c_void,
                            Option<func_float_arity2>,
                        >(function_table[(*node).tok.c2rust_unnamed.func as usize].func)
                            .expect("non-null function pointer")(left.f, right.f);
                        trace_eval(
                            b"%f\n\0" as *const u8 as *const ::core::ffi::c_char,
                            right.f as ::core::ffi::c_double,
                        );
                        top += 1;
                        stack[top as usize].f = right.f;
                    }
                    _ => {
                        current_block = 13303144130133872306;
                        break;
                    }
                }
            }
            _ => {
                current_block = 13303144130133872306;
                break;
            }
        }
        node = (*node).next as exprnode;
    }
    match current_block {
        13303144130133872306 => {
            stack[0 as ::core::ffi::c_int as usize].i32_0 = 0 as ::core::ffi::c_int;
            *(output_vector as *mut mapper_signal_value_t) = stack[0
                as ::core::ffi::c_int as usize];
            return 1 as ::core::ffi::c_int;
        }
        _ => {
            if !input_vector.is_null() {
                *(*expr).output_history.offset((*expr).history_pos as isize) = stack[0
                    as ::core::ffi::c_int as usize];
            }
            *(output_vector as *mut mapper_signal_value_t) = stack[0
                as ::core::ffi::c_int as usize];
            return 0 as ::core::ffi::c_int;
        }
    };
}
