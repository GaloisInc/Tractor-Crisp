#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type _mapper_expr;
    fn cosf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn log10f(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn powf(_: ::core::ffi::c_float, _: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn mapper_expr_new_from_string(
        str: *const ::core::ffi::c_char,
        input_is_float: ::core::ffi::c_int,
        output_is_float: ::core::ffi::c_int,
        vector_size: ::core::ffi::c_int,
    ) -> mapper_expr;
    fn mapper_expr_evaluate(
        expr: mapper_expr,
        input_vector: *mut ::core::ffi::c_void,
        output_vector: *mut ::core::ffi::c_void,
    ) -> ::core::ffi::c_int;
    fn mapper_expr_free(expr: mapper_expr);
}
pub type mapper_expr = *mut _mapper_expr;
pub const M_PI: ::core::ffi::c_double = 3.14159265358979323846264338327950288f64;
#[no_mangle]
pub unsafe extern "C" fn test1() -> ::core::ffi::c_int {
    let str: [::core::ffi::c_char; 67] = ::core::mem::transmute::<
        [u8; 67],
        [::core::ffi::c_char; 67],
    >(*b"y=26*2/2+log10(pi)+2.*pow(2,1*(3+7*.1)*1.1+x{-6*2+12})*3*4+cos(2.)\0");
    let mut e: mapper_expr = mapper_expr_new_from_string(
        str.as_ptr(),
        1 as ::core::ffi::c_int,
        1 as ::core::ffi::c_int,
        1 as ::core::ffi::c_int,
    );
    printf(b"Parsing %s\n\0" as *const u8 as *const ::core::ffi::c_char, str.as_ptr());
    if e.is_null() {
        printf(b"Test FAILED.\n\0" as *const u8 as *const ::core::ffi::c_char);
        return 1 as ::core::ffi::c_int;
    }
    printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut inp: ::core::ffi::c_float = 0.;
    let mut outp: ::core::ffi::c_float = 0.;
    inp = 3.0f32;
    mapper_expr_evaluate(
        e,
        &mut inp as *mut ::core::ffi::c_float as *mut ::core::ffi::c_void,
        &mut outp as *mut ::core::ffi::c_float as *mut ::core::ffi::c_void,
    );
    printf(
        b"Evaluate with x=%f: %f (expected: %f)\n\0" as *const u8
            as *const ::core::ffi::c_char,
        inp as ::core::ffi::c_double,
        outp as ::core::ffi::c_double,
        ((26 as ::core::ffi::c_int * 2 as ::core::ffi::c_int / 2 as ::core::ffi::c_int)
            as ::core::ffi::c_float + log10f(M_PI as ::core::ffi::c_float)
            + 2.0f32
                * powf(
                    2 as ::core::ffi::c_int as ::core::ffi::c_float,
                    1 as ::core::ffi::c_int as ::core::ffi::c_float
                        * (3 as ::core::ffi::c_int as ::core::ffi::c_float
                            + 7 as ::core::ffi::c_int as ::core::ffi::c_float * 0.1f32)
                        * 1.1f32 + inp,
                ) * 3 as ::core::ffi::c_int as ::core::ffi::c_float
                * 4 as ::core::ffi::c_int as ::core::ffi::c_float + cosf(2.0f32))
            as ::core::ffi::c_double,
    );
    mapper_expr_free(e);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test2() -> ::core::ffi::c_int {
    let str: [::core::ffi::c_char; 21] = ::core::mem::transmute::<
        [u8; 21],
        [::core::ffi::c_char; 21],
    >(*b"y=26*2/2+x*30/(20*1)\0");
    let mut e: mapper_expr = mapper_expr_new_from_string(
        str.as_ptr(),
        0 as ::core::ffi::c_int,
        0 as ::core::ffi::c_int,
        1 as ::core::ffi::c_int,
    );
    printf(b"\nParsing %s\n\0" as *const u8 as *const ::core::ffi::c_char, str.as_ptr());
    if e.is_null() {
        printf(b"Test FAILED.\n\0" as *const u8 as *const ::core::ffi::c_char);
        return 1 as ::core::ffi::c_int;
    }
    printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut inp: ::core::ffi::c_int = 0;
    let mut outp: ::core::ffi::c_int = 0;
    inp = 3 as ::core::ffi::c_int;
    mapper_expr_evaluate(
        e,
        &mut inp as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
        &mut outp as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
    );
    printf(
        b"Evaluate with x=%d: %d (expected: %d)\n\0" as *const u8
            as *const ::core::ffi::c_char,
        inp,
        outp,
        26 as ::core::ffi::c_int * 2 as ::core::ffi::c_int / 2 as ::core::ffi::c_int
            + inp * 30 as ::core::ffi::c_int
                / (20 as ::core::ffi::c_int * 1 as ::core::ffi::c_int),
    );
    inp = 321 as ::core::ffi::c_int;
    mapper_expr_evaluate(
        e,
        &mut inp as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
        &mut outp as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
    );
    printf(
        b"Evaluate with x=%d: %d (expected: %d)\n\0" as *const u8
            as *const ::core::ffi::c_char,
        inp,
        outp,
        26 as ::core::ffi::c_int * 2 as ::core::ffi::c_int / 2 as ::core::ffi::c_int
            + inp * 30 as ::core::ffi::c_int
                / (20 as ::core::ffi::c_int * 1 as ::core::ffi::c_int),
    );
    mapper_expr_free(e);
    return 0 as ::core::ffi::c_int;
}
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut rc: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    rc |= test1();
    rc |= test2();
    return rc;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
