#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn ferror(_: *mut FILE) -> ::core::ffi::c_int;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn fread(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
        __nitems: size_t,
        __stream: *mut FILE,
    ) -> ::core::ffi::c_ulong;
    fn fseek(
        _: *mut FILE,
        _: ::core::ffi::c_long,
        _: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn ftell(_: *mut FILE) -> ::core::ffi::c_long;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const SEEK_SET: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const SEEK_END: ::core::ffi::c_int = 2 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn file2strl(
    mut path: *const ::core::ffi::c_char,
    mut file_len_out: *mut ::core::ffi::c_uint,
) -> *mut ::core::ffi::c_char {
    let mut file: *mut FILE = 0 as *mut FILE;
    let mut e: ::core::ffi::c_int = 0;
    file = fopen(path, b"rb\0" as *const u8 as *const ::core::ffi::c_char) as *mut FILE;
    if file.is_null() {
        fprintf(
            __stderrp,
            b"Unable to open file %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            path,
        );
        return 0 as *mut ::core::ffi::c_char;
    }
    e = fseek(file, 0 as ::core::ffi::c_long, SEEK_END);
    if -(1 as ::core::ffi::c_int) == e {
        fprintf(
            __stderrp,
            b"Unable to seek file %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            path,
        );
        fclose(file);
        return 0 as *mut ::core::ffi::c_char;
    }
    let mut file_len: ::core::ffi::c_long = ftell(file);
    if -(1 as ::core::ffi::c_int) as ::core::ffi::c_long == file_len {
        fprintf(
            __stderrp,
            b"Unable to ftell() file %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            path,
        );
        fclose(file);
        return 0 as *mut ::core::ffi::c_char;
    }
    e = fseek(file, 0 as ::core::ffi::c_long, SEEK_SET);
    if -(1 as ::core::ffi::c_int) == e {
        fprintf(
            __stderrp,
            b"Unable to seek file %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            path,
        );
        fclose(file);
        return 0 as *mut ::core::ffi::c_char;
    }
    let mut contents: *mut ::core::ffi::c_char = malloc(
        (file_len + 1 as ::core::ffi::c_long) as size_t,
    ) as *mut ::core::ffi::c_char;
    if contents.is_null() {
        fprintf(
            __stderrp,
            b"Memory error!\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        fclose(file);
        return 0 as *mut ::core::ffi::c_char;
    }
    let mut bytes_read: ::core::ffi::c_ulong = fread(
        contents as *mut ::core::ffi::c_void,
        file_len as size_t,
        1 as size_t,
        file,
    );
    if bytes_read == 0 as ::core::ffi::c_ulong && ferror(file) != 0 {
        fprintf(__stderrp, b"Read error\0" as *const u8 as *const ::core::ffi::c_char);
        free(contents as *mut ::core::ffi::c_void);
        fclose(file);
        return 0 as *mut ::core::ffi::c_char;
    }
    fclose(file);
    *contents.offset(file_len as isize) = '\0' as i32 as ::core::ffi::c_char;
    if !file_len_out.is_null() {
        *file_len_out = (file_len + 1 as ::core::ffi::c_long) as ::core::ffi::c_uint;
    }
    return contents;
}
#[no_mangle]
pub unsafe extern "C" fn file2str(
    mut path: *const ::core::ffi::c_char,
) -> *mut ::core::ffi::c_char {
    return file2strl(path, 0 as *mut ::core::ffi::c_uint);
}
