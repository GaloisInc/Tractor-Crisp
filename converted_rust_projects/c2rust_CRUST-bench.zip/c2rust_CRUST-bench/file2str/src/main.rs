#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn CuStringNew() -> *mut CuString;
    fn CuTestNew(
        name: *const ::core::ffi::c_char,
        function: TestFunction,
    ) -> *mut CuTest;
    fn CuSuiteNew() -> *mut CuSuite;
    fn CuSuiteAdd(testSuite: *mut CuSuite, testCase: *mut CuTest);
    fn CuSuiteRun(testSuite: *mut CuSuite);
    fn CuSuiteSummary(testSuite: *mut CuSuite, summary: *mut CuString);
    fn CuSuiteDetails(testSuite: *mut CuSuite, details: *mut CuString);
    fn TestFile2str_file_read_properly(_: *mut CuTest);
}
pub type jmp_buf = [::core::ffi::c_int; 48];
#[derive(Copy, Clone)]
#[repr(C)]
pub struct CuString {
    pub length: ::core::ffi::c_int,
    pub size: ::core::ffi::c_int,
    pub buffer: *mut ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct CuTest {
    pub name: *const ::core::ffi::c_char,
    pub function: TestFunction,
    pub failed: ::core::ffi::c_int,
    pub ran: ::core::ffi::c_int,
    pub message: *const ::core::ffi::c_char,
    pub jumpBuf: *mut jmp_buf,
}
pub type TestFunction = Option<unsafe extern "C" fn(*mut CuTest) -> ()>;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct CuSuite {
    pub count: ::core::ffi::c_int,
    pub list: [*mut CuTest; 1024],
    pub failCount: ::core::ffi::c_int,
}
#[no_mangle]
pub unsafe extern "C" fn RunAllTests() {
    let mut output: *mut CuString = CuStringNew();
    let mut suite: *mut CuSuite = CuSuiteNew();
    CuSuiteAdd(
        suite,
        CuTestNew(
            b"TestFile2str_file_read_properly\0" as *const u8
                as *const ::core::ffi::c_char,
            Some(
                TestFile2str_file_read_properly
                    as unsafe extern "C" fn(*mut CuTest) -> (),
            ),
        ),
    );
    CuSuiteRun(suite);
    CuSuiteSummary(suite, output);
    CuSuiteDetails(suite, output);
    printf(b"%s\n\0" as *const u8 as *const ::core::ffi::c_char, (*output).buffer);
}
unsafe fn main_0() -> ::core::ffi::c_int {
    RunAllTests();
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
