#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(c_variadic)]
extern "C" {
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn setjmp(_: *mut ::core::ffi::c_int) -> ::core::ffi::c_int;
    fn longjmp(_: *mut ::core::ffi::c_int, _: ::core::ffi::c_int) -> !;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn realloc(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn sprintf(
        _: *mut ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn vsprintf(
        _: *mut ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: va_list,
    ) -> ::core::ffi::c_int;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memmove(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strcat(
        __s1: *mut ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strcpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn fabs(_: ::core::ffi::c_double) -> ::core::ffi::c_double;
}
pub type __builtin_va_list = *mut ::core::ffi::c_char;
pub type jmp_buf = [::core::ffi::c_int; 48];
pub type __darwin_size_t = usize;
pub type __darwin_va_list = __builtin_va_list;
pub type size_t = __darwin_size_t;
pub type va_list = __darwin_va_list;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct CuString {
    pub length: ::core::ffi::c_int,
    pub size: ::core::ffi::c_int,
    pub buffer: *mut ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct CuTest {
    pub name: *const ::core::ffi::c_char,
    pub function: TestFunction,
    pub failed: ::core::ffi::c_int,
    pub ran: ::core::ffi::c_int,
    pub message: *const ::core::ffi::c_char,
    pub jumpBuf: *mut jmp_buf,
}
pub type TestFunction = Option<unsafe extern "C" fn(*mut CuTest) -> ()>;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct CuSuite {
    pub count: ::core::ffi::c_int,
    pub list: [*mut CuTest; 1024],
    pub failCount: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const STRING_MAX: ::core::ffi::c_int = 256 as ::core::ffi::c_int;
pub const STRING_INC: ::core::ffi::c_int = 256 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn CuStrAlloc(
    mut size: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_char {
    let mut newStr: *mut ::core::ffi::c_char = malloc(
        (::core::mem::size_of::<::core::ffi::c_char>() as size_t)
            .wrapping_mul(size as size_t),
    ) as *mut ::core::ffi::c_char;
    return newStr;
}
#[no_mangle]
pub unsafe extern "C" fn CuStrCopy(
    mut old: *const ::core::ffi::c_char,
) -> *mut ::core::ffi::c_char {
    let mut len: ::core::ffi::c_int = strlen(old) as ::core::ffi::c_int;
    let mut newStr: *mut ::core::ffi::c_char = CuStrAlloc(len + 1 as ::core::ffi::c_int);
    strcpy(newStr, old);
    return newStr;
}
#[no_mangle]
pub unsafe extern "C" fn CuStringInit(mut str: *mut CuString) {
    (*str).length = 0 as ::core::ffi::c_int;
    (*str).size = STRING_MAX;
    (*str).buffer = malloc(
        (::core::mem::size_of::<::core::ffi::c_char>() as size_t)
            .wrapping_mul((*str).size as size_t),
    ) as *mut ::core::ffi::c_char;
    *(*str).buffer.offset(0 as ::core::ffi::c_int as isize) = '\0' as i32
        as ::core::ffi::c_char;
}
#[no_mangle]
pub unsafe extern "C" fn CuStringNew() -> *mut CuString {
    let mut str: *mut CuString = malloc(::core::mem::size_of::<CuString>() as size_t)
        as *mut CuString;
    (*str).length = 0 as ::core::ffi::c_int;
    (*str).size = STRING_MAX;
    (*str).buffer = malloc(
        (::core::mem::size_of::<::core::ffi::c_char>() as size_t)
            .wrapping_mul((*str).size as size_t),
    ) as *mut ::core::ffi::c_char;
    *(*str).buffer.offset(0 as ::core::ffi::c_int as isize) = '\0' as i32
        as ::core::ffi::c_char;
    return str;
}
#[no_mangle]
pub unsafe extern "C" fn CuStringResize(
    mut str: *mut CuString,
    mut newSize: ::core::ffi::c_int,
) {
    (*str).buffer = realloc(
        (*str).buffer as *mut ::core::ffi::c_void,
        (::core::mem::size_of::<::core::ffi::c_char>() as size_t)
            .wrapping_mul(newSize as size_t),
    ) as *mut ::core::ffi::c_char;
    (*str).size = newSize;
}
#[no_mangle]
pub unsafe extern "C" fn CuStringAppend(
    mut str: *mut CuString,
    mut text: *const ::core::ffi::c_char,
) {
    let mut length: ::core::ffi::c_int = 0;
    if text.is_null() {
        text = b"NULL\0" as *const u8 as *const ::core::ffi::c_char;
    }
    length = strlen(text) as ::core::ffi::c_int;
    if (*str).length + length + 1 as ::core::ffi::c_int >= (*str).size {
        CuStringResize(
            str,
            (*str).length + length + 1 as ::core::ffi::c_int + STRING_INC,
        );
    }
    (*str).length += length;
    strcat((*str).buffer, text);
}
#[no_mangle]
pub unsafe extern "C" fn CuStringAppendChar(
    mut str: *mut CuString,
    mut ch: ::core::ffi::c_char,
) {
    let mut text: [::core::ffi::c_char; 2] = [0; 2];
    text[0 as ::core::ffi::c_int as usize] = ch;
    text[1 as ::core::ffi::c_int as usize] = '\0' as i32 as ::core::ffi::c_char;
    CuStringAppend(str, text.as_mut_ptr());
}
#[no_mangle]
pub unsafe extern "C" fn CuStringAppendFormat(
    mut str: *mut CuString,
    mut format: *const ::core::ffi::c_char,
    mut args: ...
) {
    let mut argp: va_list = 0 as *mut ::core::ffi::c_char;
    let mut buf: [::core::ffi::c_char; 8192] = [0; 8192];
    argp = args.clone();
    vsprintf(buf.as_mut_ptr(), format, argp as va_list);
    CuStringAppend(str, buf.as_mut_ptr());
}
#[no_mangle]
pub unsafe extern "C" fn CuStringInsert(
    mut str: *mut CuString,
    mut text: *const ::core::ffi::c_char,
    mut pos: ::core::ffi::c_int,
) {
    let mut length: ::core::ffi::c_int = strlen(text) as ::core::ffi::c_int;
    if pos > (*str).length {
        pos = (*str).length;
    }
    if (*str).length + length + 1 as ::core::ffi::c_int >= (*str).size {
        CuStringResize(
            str,
            (*str).length + length + 1 as ::core::ffi::c_int + STRING_INC,
        );
    }
    memmove(
        (*str).buffer.offset(pos as isize).offset(length as isize)
            as *mut ::core::ffi::c_void,
        (*str).buffer.offset(pos as isize) as *const ::core::ffi::c_void,
        ((*str).length - pos + 1 as ::core::ffi::c_int) as size_t,
    );
    (*str).length += length;
    memcpy(
        (*str).buffer.offset(pos as isize) as *mut ::core::ffi::c_void,
        text as *const ::core::ffi::c_void,
        length as size_t,
    );
}
#[no_mangle]
pub unsafe extern "C" fn CuTestInit(
    mut t: *mut CuTest,
    mut name: *const ::core::ffi::c_char,
    mut function: TestFunction,
) {
    (*t).name = CuStrCopy(name);
    (*t).failed = 0 as ::core::ffi::c_int;
    (*t).ran = 0 as ::core::ffi::c_int;
    (*t).message = 0 as *const ::core::ffi::c_char;
    (*t).function = function;
    (*t).jumpBuf = 0 as *mut jmp_buf;
}
#[no_mangle]
pub unsafe extern "C" fn CuTestNew(
    mut name: *const ::core::ffi::c_char,
    mut function: TestFunction,
) -> *mut CuTest {
    let mut tc: *mut CuTest = malloc(::core::mem::size_of::<CuTest>() as size_t)
        as *mut CuTest;
    CuTestInit(tc, name, function);
    return tc;
}
#[no_mangle]
pub unsafe extern "C" fn CuTestRun(mut tc: *mut CuTest) {
    printf(b" running %s\n\0" as *const u8 as *const ::core::ffi::c_char, (*tc).name);
    let mut buf: jmp_buf = [0; 48];
    (*tc).jumpBuf = &mut buf;
    if setjmp(buf.as_mut_ptr()) == 0 as ::core::ffi::c_int {
        (*tc).ran = 1 as ::core::ffi::c_int;
        (*tc).function.expect("non-null function pointer")(tc);
    }
    (*tc).jumpBuf = 0 as *mut jmp_buf;
}
unsafe extern "C" fn CuFailInternal(
    mut tc: *mut CuTest,
    mut file: *const ::core::ffi::c_char,
    mut line: ::core::ffi::c_int,
    mut string: *mut CuString,
) {
    let mut buf: [::core::ffi::c_char; 8192] = [0; 8192];
    sprintf(
        buf.as_mut_ptr(),
        b"%s:%d: \0" as *const u8 as *const ::core::ffi::c_char,
        file,
        line,
    );
    CuStringInsert(string, buf.as_mut_ptr(), 0 as ::core::ffi::c_int);
    (*tc).failed = 1 as ::core::ffi::c_int;
    (*tc).message = (*string).buffer;
    if !(*tc).jumpBuf.is_null() {
        longjmp((*(*tc).jumpBuf).as_mut_ptr(), 0 as ::core::ffi::c_int);
    }
}
#[no_mangle]
pub unsafe extern "C" fn CuFail_Line(
    mut tc: *mut CuTest,
    mut file: *const ::core::ffi::c_char,
    mut line: ::core::ffi::c_int,
    mut message2: *const ::core::ffi::c_char,
    mut message: *const ::core::ffi::c_char,
) {
    let mut string: CuString = CuString {
        length: 0,
        size: 0,
        buffer: 0 as *mut ::core::ffi::c_char,
    };
    CuStringInit(&mut string);
    if !message2.is_null() {
        CuStringAppend(&mut string, message2);
        CuStringAppend(&mut string, b": \0" as *const u8 as *const ::core::ffi::c_char);
    }
    CuStringAppend(&mut string, message);
    CuFailInternal(tc, file, line, &mut string);
}
#[no_mangle]
pub unsafe extern "C" fn CuAssert_Line(
    mut tc: *mut CuTest,
    mut file: *const ::core::ffi::c_char,
    mut line: ::core::ffi::c_int,
    mut message: *const ::core::ffi::c_char,
    mut condition: ::core::ffi::c_int,
) {
    if condition != 0 {
        return;
    }
    CuFail_Line(tc, file, line, 0 as *const ::core::ffi::c_char, message);
}
#[no_mangle]
pub unsafe extern "C" fn CuAssertStrEquals_LineMsg(
    mut tc: *mut CuTest,
    mut file: *const ::core::ffi::c_char,
    mut line: ::core::ffi::c_int,
    mut message: *const ::core::ffi::c_char,
    mut expected: *const ::core::ffi::c_char,
    mut actual: *const ::core::ffi::c_char,
) {
    let mut string: CuString = CuString {
        length: 0,
        size: 0,
        buffer: 0 as *mut ::core::ffi::c_char,
    };
    if expected.is_null() && actual.is_null()
        || !expected.is_null() && !actual.is_null()
            && strcmp(expected, actual) == 0 as ::core::ffi::c_int
    {
        return;
    }
    CuStringInit(&mut string);
    if !message.is_null() {
        CuStringAppend(&mut string, message);
        CuStringAppend(&mut string, b": \0" as *const u8 as *const ::core::ffi::c_char);
    }
    CuStringAppend(
        &mut string,
        b"expected <\0" as *const u8 as *const ::core::ffi::c_char,
    );
    CuStringAppend(&mut string, expected);
    CuStringAppend(
        &mut string,
        b"> but was <\0" as *const u8 as *const ::core::ffi::c_char,
    );
    CuStringAppend(&mut string, actual);
    CuStringAppend(&mut string, b">\0" as *const u8 as *const ::core::ffi::c_char);
    CuFailInternal(tc, file, line, &mut string);
}
#[no_mangle]
pub unsafe extern "C" fn CuAssertIntEquals_LineMsg(
    mut tc: *mut CuTest,
    mut file: *const ::core::ffi::c_char,
    mut line: ::core::ffi::c_int,
    mut message: *const ::core::ffi::c_char,
    mut expected: ::core::ffi::c_int,
    mut actual: ::core::ffi::c_int,
) {
    let mut buf: [::core::ffi::c_char; 256] = [0; 256];
    if expected == actual {
        return;
    }
    sprintf(
        buf.as_mut_ptr(),
        b"expected <%d> but was <%d>\0" as *const u8 as *const ::core::ffi::c_char,
        expected,
        actual,
    );
    CuFail_Line(tc, file, line, message, buf.as_mut_ptr());
}
#[no_mangle]
pub unsafe extern "C" fn CuAssertDblEquals_LineMsg(
    mut tc: *mut CuTest,
    mut file: *const ::core::ffi::c_char,
    mut line: ::core::ffi::c_int,
    mut message: *const ::core::ffi::c_char,
    mut expected: ::core::ffi::c_double,
    mut actual: ::core::ffi::c_double,
    mut delta: ::core::ffi::c_double,
) {
    let mut buf: [::core::ffi::c_char; 256] = [0; 256];
    if fabs(expected - actual) <= delta {
        return;
    }
    sprintf(
        buf.as_mut_ptr(),
        b"expected <%lf> but was <%lf>\0" as *const u8 as *const ::core::ffi::c_char,
        expected,
        actual,
    );
    CuFail_Line(tc, file, line, message, buf.as_mut_ptr());
}
#[no_mangle]
pub unsafe extern "C" fn CuAssertPtrEquals_LineMsg(
    mut tc: *mut CuTest,
    mut file: *const ::core::ffi::c_char,
    mut line: ::core::ffi::c_int,
    mut message: *const ::core::ffi::c_char,
    mut expected: *mut ::core::ffi::c_void,
    mut actual: *mut ::core::ffi::c_void,
) {
    let mut buf: [::core::ffi::c_char; 256] = [0; 256];
    if expected == actual {
        return;
    }
    sprintf(
        buf.as_mut_ptr(),
        b"expected pointer <0x%p> but was <0x%p>\0" as *const u8
            as *const ::core::ffi::c_char,
        expected,
        actual,
    );
    CuFail_Line(tc, file, line, message, buf.as_mut_ptr());
}
#[no_mangle]
pub unsafe extern "C" fn CuSuiteInit(mut testSuite: *mut CuSuite) {
    (*testSuite).count = 0 as ::core::ffi::c_int;
    (*testSuite).failCount = 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn CuSuiteNew() -> *mut CuSuite {
    let mut testSuite: *mut CuSuite = malloc(::core::mem::size_of::<CuSuite>() as size_t)
        as *mut CuSuite;
    CuSuiteInit(testSuite);
    return testSuite;
}
#[no_mangle]
pub unsafe extern "C" fn CuSuiteAdd(
    mut testSuite: *mut CuSuite,
    mut testCase: *mut CuTest,
) {
    if !((*testSuite).count < 1024 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"CuSuiteAdd\0")
                .as_ptr(),
            b"CuTest.c\0" as *const u8 as *const ::core::ffi::c_char,
            240 as ::core::ffi::c_int,
            b"testSuite->count < MAX_TEST_CASES\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    (*testSuite).list[(*testSuite).count as usize] = testCase;
    (*testSuite).count += 1;
}
#[no_mangle]
pub unsafe extern "C" fn CuSuiteAddSuite(
    mut testSuite: *mut CuSuite,
    mut testSuite2: *mut CuSuite,
) {
    let mut i: ::core::ffi::c_int = 0;
    i = 0 as ::core::ffi::c_int;
    while i < (*testSuite2).count {
        let mut testCase: *mut CuTest = (*testSuite2).list[i as usize];
        CuSuiteAdd(testSuite, testCase);
        i += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn CuSuiteRun(mut testSuite: *mut CuSuite) {
    let mut i: ::core::ffi::c_int = 0;
    i = 0 as ::core::ffi::c_int;
    while i < (*testSuite).count {
        let mut testCase: *mut CuTest = (*testSuite).list[i as usize];
        CuTestRun(testCase);
        if (*testCase).failed != 0 {
            (*testSuite).failCount += 1 as ::core::ffi::c_int;
        }
        i += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn CuSuiteSummary(
    mut testSuite: *mut CuSuite,
    mut summary: *mut CuString,
) {
    let mut i: ::core::ffi::c_int = 0;
    i = 0 as ::core::ffi::c_int;
    while i < (*testSuite).count {
        let mut testCase: *mut CuTest = (*testSuite).list[i as usize];
        CuStringAppend(
            summary,
            if (*testCase).failed != 0 {
                b"F\0" as *const u8 as *const ::core::ffi::c_char
            } else {
                b".\0" as *const u8 as *const ::core::ffi::c_char
            },
        );
        i += 1;
    }
    CuStringAppend(summary, b"\n\n\0" as *const u8 as *const ::core::ffi::c_char);
}
#[no_mangle]
pub unsafe extern "C" fn CuSuiteDetails(
    mut testSuite: *mut CuSuite,
    mut details: *mut CuString,
) {
    let mut i: ::core::ffi::c_int = 0;
    let mut failCount: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    if (*testSuite).failCount == 0 as ::core::ffi::c_int {
        let mut passCount: ::core::ffi::c_int = (*testSuite).count
            - (*testSuite).failCount;
        let mut testWord: *const ::core::ffi::c_char = if passCount
            == 1 as ::core::ffi::c_int
        {
            b"test\0" as *const u8 as *const ::core::ffi::c_char
        } else {
            b"tests\0" as *const u8 as *const ::core::ffi::c_char
        };
        CuStringAppendFormat(
            details,
            b"OK (%d %s)\n\0" as *const u8 as *const ::core::ffi::c_char,
            passCount,
            testWord,
        );
    } else {
        if (*testSuite).failCount == 1 as ::core::ffi::c_int {
            CuStringAppend(
                details,
                b"There was 1 failure:\n\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {
            CuStringAppendFormat(
                details,
                b"There were %d failures:\n\0" as *const u8
                    as *const ::core::ffi::c_char,
                (*testSuite).failCount,
            );
        }
        i = 0 as ::core::ffi::c_int;
        while i < (*testSuite).count {
            let mut testCase: *mut CuTest = (*testSuite).list[i as usize];
            if (*testCase).failed != 0 {
                failCount += 1;
                CuStringAppendFormat(
                    details,
                    b"%d) %s: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    failCount,
                    (*testCase).name,
                    (*testCase).message,
                );
            }
            i += 1;
        }
        CuStringAppend(
            details,
            b"\n!!!FAILURES!!!\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        CuStringAppendFormat(
            details,
            b"Runs: %d \0" as *const u8 as *const ::core::ffi::c_char,
            (*testSuite).count,
        );
        CuStringAppendFormat(
            details,
            b"Passes: %d \0" as *const u8 as *const ::core::ffi::c_char,
            (*testSuite).count - (*testSuite).failCount,
        );
        CuStringAppendFormat(
            details,
            b"Fails: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
            (*testSuite).failCount,
        );
    };
}
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
