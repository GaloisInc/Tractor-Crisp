#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn free(_: *mut ::core::ffi::c_void);
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn CuAssert_Line(
        tc: *mut CuTest,
        file: *const ::core::ffi::c_char,
        line: ::core::ffi::c_int,
        message: *const ::core::ffi::c_char,
        condition: ::core::ffi::c_int,
    );
    fn file2strl(
        path: *const ::core::ffi::c_char,
        len: *mut ::core::ffi::c_uint,
    ) -> *mut ::core::ffi::c_char;
}
pub type jmp_buf = [::core::ffi::c_int; 48];
#[derive(Copy, Clone)]
#[repr(C)]
pub struct CuTest {
    pub name: *const ::core::ffi::c_char,
    pub function: TestFunction,
    pub failed: ::core::ffi::c_int,
    pub ran: ::core::ffi::c_int,
    pub message: *const ::core::ffi::c_char,
    pub jumpBuf: *mut jmp_buf,
}
pub type TestFunction = Option<unsafe extern "C" fn(*mut CuTest) -> ()>;
#[no_mangle]
pub unsafe extern "C" fn TestFile2str_file_read_properly(mut tc: *mut CuTest) {
    let mut len: ::core::ffi::c_uint = 0;
    let mut buf: *mut ::core::ffi::c_char = file2strl(
        b"tests/test.txt\0" as *const u8 as *const ::core::ffi::c_char,
        &mut len,
    );
    CuAssert_Line(
        tc,
        b"tests/test_file2str.c\0" as *const u8 as *const ::core::ffi::c_char,
        17 as ::core::ffi::c_int,
        b"assert failed\0" as *const u8 as *const ::core::ffi::c_char,
        (11 as ::core::ffi::c_uint == len) as ::core::ffi::c_int,
    );
    CuAssert_Line(
        tc,
        b"tests/test_file2str.c\0" as *const u8 as *const ::core::ffi::c_char,
        18 as ::core::ffi::c_int,
        b"assert failed\0" as *const u8 as *const ::core::ffi::c_char,
        (0 as ::core::ffi::c_int
            == strcmp(buf, b"Text file\n\0" as *const u8 as *const ::core::ffi::c_char))
            as ::core::ffi::c_int,
    );
    free(buf as *mut ::core::ffi::c_void);
}
