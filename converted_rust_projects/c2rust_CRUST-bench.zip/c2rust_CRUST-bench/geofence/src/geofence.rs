#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn tan(_: ::core::ffi::c_double) -> ::core::ffi::c_double;
    fn log(_: ::core::ffi::c_double) -> ::core::ffi::c_double;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct point {
    pub x: ::core::ffi::c_double,
    pub y: ::core::ffi::c_double,
}
pub const M_PI: ::core::ffi::c_double = 3.14159265358979323846264338327950288f64;
pub const EARTH_RADIUS: ::core::ffi::c_int = 6378137 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn lat2y_m(
    mut lat: ::core::ffi::c_double,
) -> ::core::ffi::c_double {
    return log(
        tan(
            lat / (180 as ::core::ffi::c_int as ::core::ffi::c_double / M_PI)
                / 2 as ::core::ffi::c_int as ::core::ffi::c_double
                + M_PI / 4 as ::core::ffi::c_int as ::core::ffi::c_double,
        ),
    ) * EARTH_RADIUS as ::core::ffi::c_double;
}
#[no_mangle]
pub unsafe extern "C" fn lon2x_m(
    mut lon: ::core::ffi::c_double,
) -> ::core::ffi::c_double {
    return lon / (180 as ::core::ffi::c_int as ::core::ffi::c_double / M_PI)
        * EARTH_RADIUS as ::core::ffi::c_double;
}
#[no_mangle]
pub unsafe extern "C" fn is_position_in_geofence(
    mut p_ptr: *mut point,
    mut vertices: *const point,
    mut number_of_vertices: size_t,
) -> bool {
    let vla = number_of_vertices as usize;
    let mut xy: Vec<point> = ::std::vec::from_elem(point { x: 0., y: 0. }, vla);
    let mut i: size_t = 0 as size_t;
    while i < number_of_vertices {
        (*xy.as_mut_ptr().offset(i as isize)).x = lon2x_m(
            (*vertices.offset(i as isize)).x,
        );
        (*xy.as_mut_ptr().offset(i as isize)).y = lat2y_m(
            (*vertices.offset(i as isize)).y,
        );
        i = i.wrapping_add(1);
    }
    let mut p_m: *mut point = malloc(::core::mem::size_of::<point>() as size_t)
        as *mut point;
    (*p_m).x = lon2x_m((*p_ptr).x);
    (*p_m).y = lat2y_m((*p_ptr).y);
    return is_point_in_polygon(p_m, xy.as_mut_ptr(), number_of_vertices);
}
#[no_mangle]
pub unsafe extern "C" fn is_point_in_polygon(
    mut p_ptr: *mut point,
    mut vertices: *const point,
    mut number_of_vertices: size_t,
) -> bool {
    let mut number_of_intersections: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut inside: bool = false_0 != 0;
    let mut x: ::core::ffi::c_double = (*p_ptr).x;
    let mut y: ::core::ffi::c_double = (*p_ptr).y;
    if number_of_vertices < 3 as size_t {
        return false_0 != 0;
    }
    let mut i: size_t = 0 as size_t;
    while i < number_of_vertices {
        let mut x1: ::core::ffi::c_double = (*vertices.offset(i as isize)).x;
        let mut y1: ::core::ffi::c_double = (*vertices.offset(i as isize)).y;
        let mut x2: ::core::ffi::c_double = (*vertices
            .offset(
                i.wrapping_add(1 as size_t).wrapping_rem(number_of_vertices) as isize,
            ))
            .x;
        let mut y2: ::core::ffi::c_double = (*vertices
            .offset(
                i.wrapping_add(1 as size_t).wrapping_rem(number_of_vertices) as isize,
            ))
            .y;
        if !(y1 > y && y2 > y || y1 < y && y2 < y) {
            let mut s: ::core::ffi::c_double = x1 + (x2 - x1) * ((y - y1) / (y2 - y1));
            if s <= x {
                number_of_intersections += 1;
                if x == x1 && y == y1 {
                    number_of_intersections -= 1;
                } else if s == x1 && y == y1 {
                    number_of_intersections -= 1;
                }
            }
        }
        i = i.wrapping_add(1);
    }
    return number_of_intersections % 2 as ::core::ffi::c_int == 1 as ::core::ffi::c_int;
}
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
