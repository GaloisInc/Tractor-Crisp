#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type u8_0 = ::core::ffi::c_uchar;
pub type u32_0 = ::core::ffi::c_uint;
pub type u64_0 = ::core::ffi::c_ulong;
pub type f64_0 = ::core::ffi::c_double;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct bitwriter_s {
    pub cache: [u8_0; 1024],
    pub pos: u32_0,
    pub byte: u8_0,
    pub bit_count: u8_0,
}
pub type bitwriter_t = bitwriter_s;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct bitreader_s {
    pub data: *mut u8_0,
    pub len: u32_0,
    pub v: u64_0,
    pub n: u32_0,
}
pub type bitreader_t = bitreader_s;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct float_encoder_s {
    pub w: bitwriter_t,
    pub val: u64_0,
    pub leading: u64_0,
    pub trailing: u64_0,
    pub first: bool,
    pub finished: bool,
}
pub type float_encoder_t = float_encoder_s;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct float_decoder_s {
    pub val: u64_0,
    pub leading: u64_0,
    pub trailing: u64_0,
    pub br: bitreader_t,
    pub b: [u8_0; 1024],
    pub first: bool,
    pub finished: bool,
    pub err: ::core::ffi::c_int,
}
pub type float_decoder_t = float_decoder_s;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
static mut de_bruijn64: u64_0 = 0x3f79d71b4ca8b09 as u64_0;
static mut de_bruijn64_tab: [u8_0; 64] = [
    0 as ::core::ffi::c_int as u8_0,
    1 as ::core::ffi::c_int as u8_0,
    56 as ::core::ffi::c_int as u8_0,
    2 as ::core::ffi::c_int as u8_0,
    57 as ::core::ffi::c_int as u8_0,
    49 as ::core::ffi::c_int as u8_0,
    28 as ::core::ffi::c_int as u8_0,
    3 as ::core::ffi::c_int as u8_0,
    61 as ::core::ffi::c_int as u8_0,
    58 as ::core::ffi::c_int as u8_0,
    42 as ::core::ffi::c_int as u8_0,
    50 as ::core::ffi::c_int as u8_0,
    38 as ::core::ffi::c_int as u8_0,
    29 as ::core::ffi::c_int as u8_0,
    17 as ::core::ffi::c_int as u8_0,
    4 as ::core::ffi::c_int as u8_0,
    62 as ::core::ffi::c_int as u8_0,
    47 as ::core::ffi::c_int as u8_0,
    59 as ::core::ffi::c_int as u8_0,
    36 as ::core::ffi::c_int as u8_0,
    45 as ::core::ffi::c_int as u8_0,
    43 as ::core::ffi::c_int as u8_0,
    51 as ::core::ffi::c_int as u8_0,
    22 as ::core::ffi::c_int as u8_0,
    53 as ::core::ffi::c_int as u8_0,
    39 as ::core::ffi::c_int as u8_0,
    33 as ::core::ffi::c_int as u8_0,
    30 as ::core::ffi::c_int as u8_0,
    24 as ::core::ffi::c_int as u8_0,
    18 as ::core::ffi::c_int as u8_0,
    12 as ::core::ffi::c_int as u8_0,
    5 as ::core::ffi::c_int as u8_0,
    63 as ::core::ffi::c_int as u8_0,
    55 as ::core::ffi::c_int as u8_0,
    48 as ::core::ffi::c_int as u8_0,
    27 as ::core::ffi::c_int as u8_0,
    60 as ::core::ffi::c_int as u8_0,
    41 as ::core::ffi::c_int as u8_0,
    37 as ::core::ffi::c_int as u8_0,
    16 as ::core::ffi::c_int as u8_0,
    46 as ::core::ffi::c_int as u8_0,
    35 as ::core::ffi::c_int as u8_0,
    44 as ::core::ffi::c_int as u8_0,
    21 as ::core::ffi::c_int as u8_0,
    52 as ::core::ffi::c_int as u8_0,
    32 as ::core::ffi::c_int as u8_0,
    23 as ::core::ffi::c_int as u8_0,
    11 as ::core::ffi::c_int as u8_0,
    54 as ::core::ffi::c_int as u8_0,
    26 as ::core::ffi::c_int as u8_0,
    40 as ::core::ffi::c_int as u8_0,
    15 as ::core::ffi::c_int as u8_0,
    34 as ::core::ffi::c_int as u8_0,
    20 as ::core::ffi::c_int as u8_0,
    31 as ::core::ffi::c_int as u8_0,
    10 as ::core::ffi::c_int as u8_0,
    25 as ::core::ffi::c_int as u8_0,
    14 as ::core::ffi::c_int as u8_0,
    19 as ::core::ffi::c_int as u8_0,
    9 as ::core::ffi::c_int as u8_0,
    13 as ::core::ffi::c_int as u8_0,
    8 as ::core::ffi::c_int as u8_0,
    7 as ::core::ffi::c_int as u8_0,
    6 as ::core::ffi::c_int as u8_0,
];
static mut len8_tab: [u8_0; 256] = [
    0 as ::core::ffi::c_int as u8_0,
    0x1 as ::core::ffi::c_int as u8_0,
    0x2 as ::core::ffi::c_int as u8_0,
    0x2 as ::core::ffi::c_int as u8_0,
    0x3 as ::core::ffi::c_int as u8_0,
    0x3 as ::core::ffi::c_int as u8_0,
    0x3 as ::core::ffi::c_int as u8_0,
    0x3 as ::core::ffi::c_int as u8_0,
    0x4 as ::core::ffi::c_int as u8_0,
    0x4 as ::core::ffi::c_int as u8_0,
    0x4 as ::core::ffi::c_int as u8_0,
    0x4 as ::core::ffi::c_int as u8_0,
    0x4 as ::core::ffi::c_int as u8_0,
    0x4 as ::core::ffi::c_int as u8_0,
    0x4 as ::core::ffi::c_int as u8_0,
    0x4 as ::core::ffi::c_int as u8_0,
    0x5 as ::core::ffi::c_int as u8_0,
    0x5 as ::core::ffi::c_int as u8_0,
    0x5 as ::core::ffi::c_int as u8_0,
    0x5 as ::core::ffi::c_int as u8_0,
    0x5 as ::core::ffi::c_int as u8_0,
    0x5 as ::core::ffi::c_int as u8_0,
    0x5 as ::core::ffi::c_int as u8_0,
    0x5 as ::core::ffi::c_int as u8_0,
    0x5 as ::core::ffi::c_int as u8_0,
    0x5 as ::core::ffi::c_int as u8_0,
    0x5 as ::core::ffi::c_int as u8_0,
    0x5 as ::core::ffi::c_int as u8_0,
    0x5 as ::core::ffi::c_int as u8_0,
    0x5 as ::core::ffi::c_int as u8_0,
    0x5 as ::core::ffi::c_int as u8_0,
    0x5 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x6 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x7 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
    0x8 as ::core::ffi::c_int as u8_0,
];
static mut Nan: u64_0 = 0x7ff8000000000001 as u64_0;
#[no_mangle]
pub unsafe extern "C" fn bitwriter_init(mut w: *mut bitwriter_t) -> ::core::ffi::c_int {
    if w.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 15],
                [::core::ffi::c_char; 15],
            >(*b"bitwriter_init\0")
                .as_ptr(),
            b"gorilla.c\0" as *const u8 as *const ::core::ffi::c_char,
            40 as ::core::ffi::c_int,
            b"w\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    memset(
        w as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<bitwriter_t>() as size_t,
    );
    (*w).bit_count = 8 as u8_0;
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn append_to_cache(mut w: *mut bitwriter_t) -> ::core::ffi::c_int {
    if (*w).pos > (1024 as ::core::ffi::c_int - 1 as ::core::ffi::c_int) as u32_0 {
        return -(1 as ::core::ffi::c_int);
    }
    (*w).cache[(*w).pos as usize] = (*w).byte;
    (*w).pos = (*w).pos.wrapping_add(1);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn write_bit(
    mut w: *mut bitwriter_t,
    mut bit: bool,
) -> ::core::ffi::c_int {
    if bit {
        (*w).byte = ((*w).byte as ::core::ffi::c_int
            | (1 as ::core::ffi::c_int)
                << (*w).bit_count as ::core::ffi::c_int - 1 as ::core::ffi::c_int)
            as u8_0;
    }
    (*w).bit_count = (*w).bit_count.wrapping_sub(1);
    if (*w).bit_count as ::core::ffi::c_int == 0 as ::core::ffi::c_int {
        if append_to_cache(w) != 0 as ::core::ffi::c_int {
            return -(1 as ::core::ffi::c_int);
        }
        (*w).byte = 0 as u8_0;
        (*w).bit_count = 8 as u8_0;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn write_byte(
    mut w: *mut bitwriter_t,
    mut b: u8_0,
) -> ::core::ffi::c_int {
    (*w).byte = ((*w).byte as ::core::ffi::c_int
        | b as ::core::ffi::c_int
            >> 8 as ::core::ffi::c_int - (*w).bit_count as ::core::ffi::c_int) as u8_0;
    if append_to_cache(w) != 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    (*w).byte = ((b as ::core::ffi::c_int) << (*w).bit_count as ::core::ffi::c_int)
        as u8_0;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn write_bits(
    mut w: *mut bitwriter_t,
    mut u: u64_0,
    mut nbits: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    if nbits > 64 as ::core::ffi::c_int || nbits < 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    let mut byte: u8_0 = 0 as u8_0;
    u <<= 64 as ::core::ffi::c_int - nbits;
    while nbits >= 8 as ::core::ffi::c_int {
        byte = (u >> 56 as ::core::ffi::c_int) as u8_0;
        if write_byte(w, byte) != 0 as ::core::ffi::c_int {
            return -(1 as ::core::ffi::c_int);
        }
        u <<= 8 as ::core::ffi::c_int;
        nbits -= 8 as ::core::ffi::c_int;
    }
    while nbits > 0 as ::core::ffi::c_int {
        if write_bit(w, u >> 63 as ::core::ffi::c_int != 0) != 0 as ::core::ffi::c_int {
            return -(2 as ::core::ffi::c_int);
        }
        u <<= 1 as ::core::ffi::c_int;
        nbits -= 1;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn write_flush(
    mut w: *mut bitwriter_t,
    mut bit: bool,
) -> ::core::ffi::c_int {
    while (*w).bit_count as ::core::ffi::c_int != 8 as ::core::ffi::c_int {
        if write_bit(w, bit) != 0 as ::core::ffi::c_int {
            return -(1 as ::core::ffi::c_int);
        }
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn float_encoder_init(
    mut s: *mut float_encoder_t,
) -> ::core::ffi::c_int {
    if s.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"float_encoder_init\0")
                .as_ptr(),
            b"gorilla.c\0" as *const u8 as *const ::core::ffi::c_char,
            114 as ::core::ffi::c_int,
            b"s\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    memset(
        s as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<float_encoder_t>() as size_t,
    );
    bitwriter_init(&mut (*s).w);
    (*s).first = true_0 != 0;
    (*s).leading = !(0 as ::core::ffi::c_int) as u64_0;
    write_byte(&mut (*s).w, 0x10 as u8_0);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn bitslen(mut x: u64_0) -> ::core::ffi::c_int {
    let mut n: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    if x >= (1 as ::core::ffi::c_int as u64_0) << 32 as ::core::ffi::c_int {
        x >>= 32 as ::core::ffi::c_int;
        n = 32 as ::core::ffi::c_int;
    }
    if x >= ((1 as ::core::ffi::c_int) << 16 as ::core::ffi::c_int) as u64_0 {
        x >>= 16 as ::core::ffi::c_int;
        n += 16 as ::core::ffi::c_int;
    }
    if x >= ((1 as ::core::ffi::c_int) << 8 as ::core::ffi::c_int) as u64_0 {
        x >>= 8 as ::core::ffi::c_int;
        n += 8 as ::core::ffi::c_int;
    }
    return n + len8_tab[x as usize] as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn leading_zero64(mut u: u64_0) -> ::core::ffi::c_int {
    return 64 as ::core::ffi::c_int - bitslen(u);
}
#[no_mangle]
pub unsafe extern "C" fn trailing_zero64(mut u: u64_0) -> ::core::ffi::c_int {
    if u == 0 as u64_0 {
        return 64 as ::core::ffi::c_int;
    }
    return de_bruijn64_tab[((u & u.wrapping_neg()).wrapping_mul(de_bruijn64)
        >> 64 as ::core::ffi::c_int - 6 as ::core::ffi::c_int) as usize]
        as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn float_encode_write(
    mut s: *mut float_encoder_t,
    mut v: f64_0,
) -> ::core::ffi::c_int {
    let mut vp: *mut u64_0 = &mut v as *mut f64_0 as *mut u64_0;
    if (*s).first {
        (*s).val = *vp;
        (*s).first = false_0 != 0;
        write_bits(&mut (*s).w, *vp, 64 as ::core::ffi::c_int);
        return 0 as ::core::ffi::c_int;
    }
    let mut vdelta: u64_0 = *vp ^ (*s).val;
    if vdelta == 0 as u64_0 {
        write_bit(&mut (*s).w, 0 as ::core::ffi::c_int != 0);
    } else {
        write_bit(&mut (*s).w, 1 as ::core::ffi::c_int != 0);
    }
    let mut leading: u64_0 = leading_zero64(vdelta) as u64_0;
    let mut trailing: u64_0 = trailing_zero64(vdelta) as u64_0;
    leading &= 0x1f as u64_0;
    if leading >= 32 as u64_0 {
        leading = 31 as u64_0;
    }
    if (*s).leading != !(0 as ::core::ffi::c_int) as u64_0 && leading > (*s).leading
        && trailing >= (*s).trailing
    {
        write_bit(&mut (*s).w, 0 as ::core::ffi::c_int != 0);
        write_bits(
            &mut (*s).w,
            vdelta >> (*s).trailing,
            (64 as u64_0).wrapping_sub((*s).leading).wrapping_sub((*s).trailing)
                as ::core::ffi::c_int,
        );
    } else {
        (*s).leading = leading;
        (*s).trailing = trailing;
        write_bit(&mut (*s).w, 1 as ::core::ffi::c_int != 0);
        write_bits(&mut (*s).w, leading, 5 as ::core::ffi::c_int);
        let mut sigbits: u64_0 = (64 as u64_0)
            .wrapping_sub(leading)
            .wrapping_sub(trailing);
        write_bits(&mut (*s).w, sigbits, 6 as ::core::ffi::c_int);
        write_bits(&mut (*s).w, vdelta >> trailing, sigbits as ::core::ffi::c_int);
    }
    (*s).val = *vp;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn float_encode_flush(
    mut s: *mut float_encoder_t,
    mut dst: *mut u8_0,
    mut length: *mut u32_0,
) -> ::core::ffi::c_int {
    let mut na: *mut f64_0 = &Nan as *const u64_0 as *mut f64_0;
    if !(*s).finished {
        (*s).finished = true_0 != 0;
        float_encode_write(s, *na);
        write_flush(&mut (*s).w, 0 as ::core::ffi::c_int != 0);
    }
    *length = (*s).w.pos.wrapping_add(1 as u32_0);
    memcpy(
        dst as *mut ::core::ffi::c_void,
        (*s).w.cache.as_mut_ptr() as *const ::core::ffi::c_void,
        (*s).w.pos.wrapping_add(1 as u32_0) as size_t,
    );
    return *length as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn float_cache_print(
    mut s: *mut float_encoder_t,
) -> ::core::ffi::c_int {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut a: *mut u8_0 = (*s).w.cache.as_mut_ptr();
    i = 0 as ::core::ffi::c_int;
    while (i as u32_0) < (*s).w.pos.wrapping_add(1 as u32_0) {
        printf(
            b"%02x \0" as *const u8 as *const ::core::ffi::c_char,
            *a.offset(i as isize) as ::core::ffi::c_int,
        );
        if (i + 1 as ::core::ffi::c_int) % 16 as ::core::ffi::c_int
            == 0 as ::core::ffi::c_int
        {
            printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
        } else if (i + 1 as ::core::ffi::c_int) % 8 as ::core::ffi::c_int
            == 0 as ::core::ffi::c_int
        {
            printf(b"  \0" as *const u8 as *const ::core::ffi::c_char);
        }
        i += 1;
    }
    printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
    panic!("Reached end of non-void function without returning");
}
#[no_mangle]
pub unsafe extern "C" fn bit_readbuf(mut br: *mut bitreader_t) -> ::core::ffi::c_int {
    let mut i: u32_0 = 0 as u32_0;
    let mut byte_n: u32_0 = (8 as u32_0).wrapping_sub((*br).n.wrapping_div(8 as u32_0));
    if (*br).len != 0 && byte_n > (*br).len {
        byte_n = (*br).len;
    }
    if byte_n == 8 as u32_0 {
        (*br).v = *(*br).data.offset(7 as ::core::ffi::c_int as isize) as u64_0
            | (*(*br).data.offset(6 as ::core::ffi::c_int as isize) as u64_0)
                << 8 as ::core::ffi::c_int
            | (*(*br).data.offset(5 as ::core::ffi::c_int as isize) as u64_0)
                << 16 as ::core::ffi::c_int
            | (*(*br).data.offset(4 as ::core::ffi::c_int as isize) as u64_0)
                << 24 as ::core::ffi::c_int
            | (*(*br).data.offset(3 as ::core::ffi::c_int as isize) as u64_0)
                << 32 as ::core::ffi::c_int
            | (*(*br).data.offset(2 as ::core::ffi::c_int as isize) as u64_0)
                << 40 as ::core::ffi::c_int
            | (*(*br).data.offset(1 as ::core::ffi::c_int as isize) as u64_0)
                << 48 as ::core::ffi::c_int
            | (*(*br).data.offset(0 as ::core::ffi::c_int as isize) as u64_0)
                << 56 as ::core::ffi::c_int;
        (*br).n = 64 as u32_0;
        (*br).data = (*br).data.offset(8 as ::core::ffi::c_int as isize);
        (*br).len = (*br).len.wrapping_sub(8 as u32_0);
        return 0 as ::core::ffi::c_int;
    }
    i = 0 as u32_0;
    while i < byte_n {
        (*br).n = (*br).n.wrapping_add(8 as u32_0);
        (*br).v
            |= (*(*br).data.offset(i as isize) as u64_0)
                << (64 as u32_0).wrapping_sub((*br).n);
        i = i.wrapping_add(1);
    }
    (*br).data = (*br).data.offset(byte_n as isize);
    (*br).len = (*br).len.wrapping_sub(byte_n);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn bitread_reset(
    mut br: *mut bitreader_t,
    mut data: *mut u8_0,
    mut len: u32_0,
) -> ::core::ffi::c_int {
    (*br).data = data;
    (*br).len = len;
    (*br).n = 0 as u32_0;
    (*br).v = 0 as u64_0;
    bit_readbuf(br);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn read_bits(mut br: *mut bitreader_t, mut nbits: u32_0) -> u64_0 {
    let mut v: u64_0 = 0 as u64_0;
    let mut n: u64_0 = 0 as u64_0;
    if (*br).n == 0 as u32_0 {
        return !(0 as ::core::ffi::c_int) as u64_0;
    }
    if nbits <= (*br).n {
        if nbits == 64 as u32_0 {
            v = (*br).v;
            (*br).n = 0 as u32_0;
            (*br).v = 0 as u64_0;
            bit_readbuf(br);
            return v;
        }
        v = (*br).v >> (64 as u32_0).wrapping_sub(nbits);
        (*br).v = (*br).v << nbits;
        (*br).n = (*br).n.wrapping_sub(nbits);
        if (*br).n == 0 as u32_0 {
            bit_readbuf(br);
        }
        return v;
    }
    v = (*br).v;
    n = (*br).n as u64_0;
    (*br).v = 0 as u64_0;
    (*br).n = 0 as u32_0;
    bit_readbuf(br);
    v |= (*br).v >> n;
    v >>= (64 as u32_0).wrapping_sub(nbits);
    let mut buf_n: u32_0 = (nbits as u64_0).wrapping_sub(n) as u32_0;
    if buf_n > (*br).n {
        buf_n = (*br).n;
    }
    (*br).v <<= buf_n;
    (*br).n = (*br).n.wrapping_sub(buf_n);
    if (*br).n == 0 as u32_0 {
        bit_readbuf(br);
    }
    return v;
}
#[no_mangle]
pub unsafe extern "C" fn read_bit(mut br: *mut bitreader_t) -> u64_0 {
    return read_bits(br, 1 as u32_0);
}
#[no_mangle]
pub unsafe extern "C" fn can_read_bitfast(mut br: *mut bitreader_t) -> bool {
    if (*br).n > 1 as u32_0 { return true_0 != 0 } else { return false_0 != 0 };
}
#[no_mangle]
pub unsafe extern "C" fn read_bitfast(mut br: *mut bitreader_t) -> bool {
    let mut v: bool = (*br).v
        & (1 as ::core::ffi::c_int as u64_0) << 63 as ::core::ffi::c_int != 0 as u64_0;
    (*br).v <<= 1 as ::core::ffi::c_int;
    (*br).n = (*br).n.wrapping_sub(1 as u32_0);
    return v;
}
#[no_mangle]
pub unsafe extern "C" fn read_next(mut s: *mut float_decoder_t) -> bool {
    let mut v: u64_0 = 0 as u64_0;
    let mut bits: u64_0 = 0;
    let mut mbits: u64_0 = 0;
    let mut vbits: u64_0 = 0;
    if (*s).finished as ::core::ffi::c_int != 0 || (*s).err != 0 {
        return false_0 != 0;
    }
    if (*s).first {
        (*s).first = false_0 != 0;
        if (*s).val == Nan {
            (*s).finished = true_0 != 0;
            return false_0 != 0;
        }
        return true_0 != 0;
    }
    let mut abit: bool = false;
    if can_read_bitfast(&mut (*s).br) {
        abit = read_bitfast(&mut (*s).br);
    } else {
        v = (read_bit(&mut (*s).br) == !(0 as ::core::ffi::c_int) as u64_0)
            as ::core::ffi::c_int as u64_0;
        if v != 0 {
            (*s).err = 1 as ::core::ffi::c_int;
            return false_0 != 0;
        } else {
            abit = v != 0;
        }
    }
    if abit {
        let mut bit: bool = false;
        if can_read_bitfast(&mut (*s).br) {
            bit = read_bitfast(&mut (*s).br);
        } else {
            v = (read_bit(&mut (*s).br) == !(0 as ::core::ffi::c_int) as u64_0)
                as ::core::ffi::c_int as u64_0;
            if v != 0 {
                (*s).err = 1 as ::core::ffi::c_int;
                return false_0 != 0;
            } else {
                bit = v != 0;
            }
        }
        if bit {
            bits = read_bits(&mut (*s).br, 5 as u32_0);
            if bits == !(0 as ::core::ffi::c_int) as u64_0 {
                (*s).err = 1 as ::core::ffi::c_int;
                return false_0 != 0;
            }
            (*s).leading = bits;
            bits = read_bits(&mut (*s).br, 6 as u32_0);
            if bits == !(0 as ::core::ffi::c_int) as u64_0 {
                (*s).err = 1 as ::core::ffi::c_int;
                return false_0 != 0;
            }
            mbits = bits;
            if mbits == 0 as u64_0 {
                mbits = 64 as u64_0;
            }
            (*s).trailing = (64 as u64_0).wrapping_sub((*s).leading).wrapping_sub(mbits);
        }
        mbits = (64 as u64_0).wrapping_sub((*s).leading).wrapping_sub((*s).trailing);
        bits = read_bits(&mut (*s).br, mbits as u32_0);
        if bits == !(0 as ::core::ffi::c_int) as u64_0 {
            (*s).err = 1 as ::core::ffi::c_int;
            return false_0 != 0;
        }
        vbits = (*s).val;
        vbits ^= bits << (*s).trailing;
        if vbits == Nan {
            (*s).finished = true_0 != 0;
            return false_0 != 0;
        }
        (*s).val = vbits;
    }
    return true_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn float_decode_setbytes(
    mut s: *mut float_decoder_t,
    mut data: *mut u8_0,
    mut data_len: u32_0,
) -> ::core::ffi::c_int {
    memset(
        (*s).b.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<[u8_0; 1024]>() as size_t,
    );
    memcpy(
        (*s).b.as_mut_ptr() as *mut ::core::ffi::c_void,
        data as *const ::core::ffi::c_void,
        data_len as size_t,
    );
    bitread_reset(
        &mut (*s).br,
        (*s).b.as_mut_ptr().offset(1 as ::core::ffi::c_int as isize),
        data_len.wrapping_sub(1 as u32_0),
    );
    let mut v: u64_0 = read_bits(&mut (*s).br, 64 as u32_0);
    if v == !(0 as ::core::ffi::c_int) as u64_0 {
        return -(1 as ::core::ffi::c_int);
    }
    (*s).val = v;
    (*s).leading = 0 as u64_0;
    (*s).trailing = 0 as u64_0;
    (*s).first = true_0 != 0;
    (*s).finished = false_0 != 0;
    (*s).err = false_0;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn float_decode_block(
    mut s: *mut float_decoder_t,
    mut data: *mut u8_0,
    mut len: u32_0,
    mut res: *mut f64_0,
    mut res_len: *mut u32_0,
) -> ::core::ffi::c_int {
    let mut cnt: u32_0 = 0 as u32_0;
    let mut val: f64_0 = 0.0f64;
    let mut ret: ::core::ffi::c_int = float_decode_setbytes(s, data, len);
    if ret != 0 as ::core::ffi::c_int {
        printf(b"Error\n\0" as *const u8 as *const ::core::ffi::c_char);
        return ret;
    }
    while read_next(s) {
        val = *(&mut (*s).val as *mut u64_0 as *mut f64_0);
        *res.offset(cnt as isize) = val;
        cnt = cnt.wrapping_add(1);
        if cnt > 20 as u32_0 {
            break;
        }
    }
    *res_len = cnt;
    if (*s).err != 0 {
        printf(b"Error when decode\n\0" as *const u8 as *const ::core::ffi::c_char);
        return -(1 as ::core::ffi::c_int);
    }
    return 0 as ::core::ffi::c_int;
}
