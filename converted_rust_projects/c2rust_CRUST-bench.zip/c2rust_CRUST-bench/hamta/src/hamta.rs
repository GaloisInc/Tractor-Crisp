#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn putchar(_: ::core::ffi::c_int) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn memcmp(
        __s1: *const ::core::ffi::c_void,
        __s2: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> ::core::ffi::c_int;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type hash_fn_t = Option<
    unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_uint,
>;
pub type equals_fn_t = Option<
    unsafe extern "C" fn(*mut ::core::ffi::c_void, *mut ::core::ffi::c_void) -> bool,
>;
pub type str_fn_t = Option<
    unsafe extern "C" fn(*mut ::core::ffi::c_void) -> *mut ::core::ffi::c_char,
>;
pub type deallocate_fn_t = Option<unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ()>;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct key_value_t {
    pub key: *mut ::core::ffi::c_void,
    pub value: *mut ::core::ffi::c_void,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union hamt_node_ {
    pub leaf: key_value_t,
    pub sub: sub_node_t,
}
pub type sub_node_t = sub_node_;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct sub_node_ {
    pub bitmap: ::core::ffi::c_uint,
    pub children: *mut hamt_node_,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct hamt_t {
    pub root: *mut hamt_node_,
    pub size: ::core::ffi::c_int,
    pub hash_fn: hash_fn_t,
    pub equals_fn: equals_fn_t,
}
pub type hamt_node_t = hamt_node_;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const CHUNK_SIZE: ::core::ffi::c_int = 6 as ::core::ffi::c_int;
pub const FNV_BASE: ::core::ffi::c_ulonglong = 14695981039346656037
    as ::core::ffi::c_ulonglong;
pub const FNV_PRIME: ::core::ffi::c_long = 1099511628211 as ::core::ffi::c_long;
pub const KEY_VALUE_T_FLAG: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const HAMT_NODE_T_FLAG: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn hamt_int_equals(
    mut a: *mut ::core::ffi::c_void,
    mut b: *mut ::core::ffi::c_void,
) -> bool {
    if a.is_null() || b.is_null() {
        return a == b;
    }
    return memcmp(a, b, ::core::mem::size_of::<::core::ffi::c_int>() as size_t)
        == 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn hamt_str_equals(
    mut a: *mut ::core::ffi::c_void,
    mut b: *mut ::core::ffi::c_void,
) -> bool {
    if a.is_null() || b.is_null() {
        return a == b;
    }
    return strcmp(a as *const ::core::ffi::c_char, b as *const ::core::ffi::c_char)
        == 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn hamt_fnv1_hash(
    mut key: *mut ::core::ffi::c_void,
    mut len: size_t,
) -> ::core::ffi::c_uint {
    let mut hash: ::core::ffi::c_uint = FNV_BASE as ::core::ffi::c_uint;
    let mut i: size_t = 0 as size_t;
    while i < len {
        hash = (hash as ::core::ffi::c_long * FNV_PRIME) as ::core::ffi::c_uint;
        hash
            ^= *(key as *mut ::core::ffi::c_char).offset(i as isize)
                as ::core::ffi::c_uint;
        i = i.wrapping_add(1);
    }
    return hash;
}
#[no_mangle]
pub unsafe extern "C" fn hamt_int_hash(
    mut key: *mut ::core::ffi::c_void,
) -> ::core::ffi::c_uint {
    return hamt_fnv1_hash(key, ::core::mem::size_of::<::core::ffi::c_int>() as size_t);
}
#[no_mangle]
pub unsafe extern "C" fn hamt_str_hash(
    mut key: *mut ::core::ffi::c_void,
) -> ::core::ffi::c_uint {
    let mut hash: ::core::ffi::c_uint = FNV_BASE as ::core::ffi::c_uint;
    while *(key as *mut ::core::ffi::c_char) as ::core::ffi::c_int
        != 0 as ::core::ffi::c_int
    {
        hash = (hash as ::core::ffi::c_long * FNV_PRIME) as ::core::ffi::c_uint;
        hash ^= *(key as *mut ::core::ffi::c_char) as ::core::ffi::c_uint;
        key = key.offset(1);
    }
    return hash;
}
#[no_mangle]
pub unsafe extern "C" fn hamt_get_symbol(
    mut hash: ::core::ffi::c_uint,
    mut lvl: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut left: ::core::ffi::c_int = lvl * CHUNK_SIZE;
    let mut left_plus_chunk: ::core::ffi::c_int = left + CHUNK_SIZE;
    let mut right: ::core::ffi::c_int = 32 as ::core::ffi::c_int - left_plus_chunk;
    if left_plus_chunk > 32 as ::core::ffi::c_int {
        right = 0 as ::core::ffi::c_int;
    }
    let mut symbol: ::core::ffi::c_uint = hash << left;
    if !(symbol as ::core::ffi::c_ulong & 18446744073709551615 as ::core::ffi::c_ulong
        == symbol as ::core::ffi::c_ulong) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"hamt_get_symbol\0")
                .as_ptr(),
            b"hamta.c\0" as *const u8 as *const ::core::ffi::c_char,
            86 as ::core::ffi::c_int,
            b"(symbol & UINTPTR_MAX) == symbol\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    symbol >>= right + left;
    return symbol as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn get_children_pointer(
    mut node: *mut hamt_node_t,
) -> *mut hamt_node_t {
    let mut children_ptr: ::core::ffi::c_int = (*node).sub.children
        as ::core::ffi::c_int;
    children_ptr &= !HAMT_NODE_T_FLAG;
    return children_ptr as *mut hamt_node_t;
}
#[no_mangle]
pub unsafe extern "C" fn is_leaf(mut node: *mut hamt_node_t) -> bool {
    if node.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 8], [::core::ffi::c_char; 8]>(*b"is_leaf\0")
                .as_ptr(),
            b"hamta.c\0" as *const u8 as *const ::core::ffi::c_char,
            100 as ::core::ffi::c_int,
            b"node != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut children_ptr: ::core::ffi::c_int = (*node).sub.children
        as ::core::ffi::c_int;
    return children_ptr & 1 as ::core::ffi::c_int == KEY_VALUE_T_FLAG;
}
#[no_mangle]
pub unsafe extern "C" fn hamt_node_search(
    mut node: *mut hamt_node_t,
    mut hash: ::core::ffi::c_uint,
    mut lvl: ::core::ffi::c_int,
    mut key: *mut ::core::ffi::c_void,
    mut equals_fn: equals_fn_t,
) -> *mut key_value_t {
    if node.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 17],
                [::core::ffi::c_char; 17],
            >(*b"hamt_node_search\0")
                .as_ptr(),
            b"hamta.c\0" as *const u8 as *const ::core::ffi::c_char,
            107 as ::core::ffi::c_int,
            b"node != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if is_leaf(node) {
        if equals_fn.expect("non-null function pointer")((*node).leaf.key, key) {
            return node as *mut key_value_t;
        }
    } else {
        let mut children: *mut hamt_node_t = get_children_pointer(node);
        let mut symbol: ::core::ffi::c_int = hamt_get_symbol(hash, lvl);
        let mut shifted: ::core::ffi::c_uint = (*node).sub.bitmap >> symbol;
        let mut child_exists: bool = shifted & 1 as ::core::ffi::c_uint != 0;
        if child_exists {
            let mut child_position: ::core::ffi::c_int = (shifted
                >> 1 as ::core::ffi::c_int)
                .count_ones() as i32;
            return hamt_node_search(
                &mut *children.offset(child_position as isize),
                hash,
                lvl + 1 as ::core::ffi::c_int,
                key,
                equals_fn,
            );
        }
    }
    return 0 as *mut key_value_t;
}
#[no_mangle]
pub unsafe extern "C" fn hamt_node_insert(
    mut node: *mut hamt_node_t,
    mut hash: ::core::ffi::c_uint,
    mut lvl: ::core::ffi::c_int,
    mut key: *mut ::core::ffi::c_void,
    mut value: *mut ::core::ffi::c_void,
    mut hash_fn: hash_fn_t,
    mut equals_fn: equals_fn_t,
    mut conflict_kv: *mut key_value_t,
) -> bool {
    if lvl * CHUNK_SIZE > 32 as ::core::ffi::c_int {
        if (0 as ::core::ffi::c_int == 0) as ::core::ffi::c_int as ::core::ffi::c_long
            != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 17],
                    [::core::ffi::c_char; 17],
                >(*b"hamt_node_insert\0")
                    .as_ptr(),
                b"hamta.c\0" as *const u8 as *const ::core::ffi::c_char,
                133 as ::core::ffi::c_int,
                b"false\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        return false_0 != 0;
    }
    if is_leaf(node) {
        if equals_fn.expect("non-null function pointer")((*node).leaf.key, key) {
            (*conflict_kv).key = (*node).leaf.key;
            (*conflict_kv).value = (*node).leaf.value;
            (*node).leaf.key = key;
            (*node).leaf.value = value;
            if !is_leaf(node) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
                __assert_rtn(
                    ::core::mem::transmute::<
                        [u8; 17],
                        [::core::ffi::c_char; 17],
                    >(*b"hamt_node_insert\0")
                        .as_ptr(),
                    b"hamta.c\0" as *const u8 as *const ::core::ffi::c_char,
                    145 as ::core::ffi::c_int,
                    b"is_leaf(node)\0" as *const u8 as *const ::core::ffi::c_char,
                );
            } else {};
            return false_0 != 0;
        }
        let mut original_hash: ::core::ffi::c_uint = hash_fn
            .expect("non-null function pointer")((*node).leaf.key);
        let mut original_next_symbol: ::core::ffi::c_int = hamt_get_symbol(
            original_hash,
            lvl,
        );
        let mut new_children: *mut hamt_node_t = malloc(
            (::core::mem::size_of::<hamt_node_t>() as size_t).wrapping_mul(1 as size_t),
        ) as *mut hamt_node_t;
        let ref mut fresh0 = (*new_children.offset(0 as ::core::ffi::c_int as isize))
            .leaf
            .key;
        *fresh0 = (*node).leaf.key;
        let ref mut fresh1 = (*new_children.offset(0 as ::core::ffi::c_int as isize))
            .leaf
            .value;
        *fresh1 = (*node).leaf.value;
        if !is_leaf(&mut *new_children.offset(0 as ::core::ffi::c_int as isize))
            as ::core::ffi::c_int as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 17],
                    [::core::ffi::c_char; 17],
                >(*b"hamt_node_insert\0")
                    .as_ptr(),
                b"hamta.c\0" as *const u8 as *const ::core::ffi::c_char,
                156 as ::core::ffi::c_int,
                b"is_leaf(&new_children[0])\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        (*node).sub.bitmap = ((1 as ::core::ffi::c_int) << original_next_symbol)
            as ::core::ffi::c_uint;
        (*node).sub.children = (new_children as ::core::ffi::c_int | HAMT_NODE_T_FLAG)
            as *mut hamt_node_t as *mut hamt_node_;
        return hamt_node_insert(
            node,
            hash,
            lvl,
            key,
            value,
            hash_fn,
            equals_fn,
            conflict_kv,
        );
    }
    let mut children: *mut hamt_node_t = get_children_pointer(node);
    let mut symbol: ::core::ffi::c_int = hamt_get_symbol(hash, lvl);
    let mut shifted: ::core::ffi::c_uint = (*node).sub.bitmap >> symbol;
    let mut child_exists: bool = shifted & 1 as ::core::ffi::c_uint != 0;
    if child_exists {
        let mut child_position: ::core::ffi::c_int = (shifted >> 1 as ::core::ffi::c_int)
            .count_ones() as i32;
        return hamt_node_insert(
            &mut *children.offset(child_position as isize),
            hash,
            lvl + 1 as ::core::ffi::c_int,
            key,
            value,
            hash_fn,
            equals_fn,
            conflict_kv,
        );
    } else {
        let mut children_size: ::core::ffi::c_int = (*node).sub.bitmap.count_ones()
            as i32;
        let mut children_before: ::core::ffi::c_int = (shifted
            >> 1 as ::core::ffi::c_int)
            .count_ones() as i32;
        if !(children_size > 0 as ::core::ffi::c_int) as ::core::ffi::c_int
            as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 17],
                    [::core::ffi::c_char; 17],
                >(*b"hamt_node_insert\0")
                    .as_ptr(),
                b"hamta.c\0" as *const u8 as *const ::core::ffi::c_char,
                178 as ::core::ffi::c_int,
                b"children_size > 0\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        (*node).sub.bitmap
            |= ((1 as ::core::ffi::c_int) << symbol) as ::core::ffi::c_uint;
        let mut new_children_0: *mut hamt_node_t = malloc(
            (::core::mem::size_of::<hamt_node_t>() as size_t)
                .wrapping_mul((children_size + 1 as ::core::ffi::c_int) as size_t),
        ) as *mut hamt_node_t;
        let mut i: ::core::ffi::c_int = 0;
        i = 0 as ::core::ffi::c_int;
        while i < children_before {
            *new_children_0.offset(i as isize) = *children.offset(i as isize);
            i += 1;
        }
        let ref mut fresh2 = (*new_children_0.offset(i as isize)).leaf.key;
        *fresh2 = key;
        let ref mut fresh3 = (*new_children_0.offset(i as isize)).leaf.value;
        *fresh3 = value;
        if !is_leaf(&mut *new_children_0.offset(i as isize)) as ::core::ffi::c_int
            as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 17],
                    [::core::ffi::c_char; 17],
                >(*b"hamt_node_insert\0")
                    .as_ptr(),
                b"hamta.c\0" as *const u8 as *const ::core::ffi::c_char,
                191 as ::core::ffi::c_int,
                b"is_leaf(&new_children[i])\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        while i < children_size {
            *new_children_0.offset((i + 1 as ::core::ffi::c_int) as isize) = *children
                .offset(i as isize);
            i += 1;
        }
        free(children as *mut ::core::ffi::c_void);
        (*node).sub.children = (new_children_0 as ::core::ffi::c_int | HAMT_NODE_T_FLAG)
            as *mut hamt_node_t as *mut hamt_node_;
        return true_0 != 0;
    };
}
#[no_mangle]
pub unsafe extern "C" fn hamt_node_remove(
    mut node: *mut hamt_node_t,
    mut hash: ::core::ffi::c_uint,
    mut lvl: ::core::ffi::c_int,
    mut key: *mut ::core::ffi::c_void,
    mut equals_fn: equals_fn_t,
    mut removed_kv: *mut key_value_t,
) -> bool {
    let mut children: *mut hamt_node_t = get_children_pointer(node);
    let mut symbol: ::core::ffi::c_int = hamt_get_symbol(hash, lvl);
    let mut shifted: ::core::ffi::c_uint = (*node).sub.bitmap >> symbol;
    let mut child_exists: bool = shifted & 1 as ::core::ffi::c_uint != 0;
    let mut removed: bool = false_0 != 0;
    if child_exists {
        let mut child_position: ::core::ffi::c_int = (shifted >> 1 as ::core::ffi::c_int)
            .count_ones() as i32;
        let mut subnode: *mut hamt_node_t = &mut *children
            .offset(child_position as isize) as *mut hamt_node_t;
        if is_leaf(subnode) {
            if equals_fn.expect("non-null function pointer")((*subnode).leaf.key, key) {
                let mut children_size: ::core::ffi::c_int = (*node)
                    .sub
                    .bitmap
                    .count_ones() as i32;
                if (children_size == 0) as ::core::ffi::c_int as ::core::ffi::c_long != 0
                {
                    __assert_rtn(
                        ::core::mem::transmute::<
                            [u8; 17],
                            [::core::ffi::c_char; 17],
                        >(*b"hamt_node_remove\0")
                            .as_ptr(),
                        b"hamta.c\0" as *const u8 as *const ::core::ffi::c_char,
                        218 as ::core::ffi::c_int,
                        b"children_size\0" as *const u8 as *const ::core::ffi::c_char,
                    );
                } else {};
                (*node).sub.bitmap
                    &= !((1 as ::core::ffi::c_int) << symbol) as ::core::ffi::c_uint;
                children_size -= 1;
                removed = true_0 != 0;
                let mut new_children: *mut hamt_node_t = 0 as *mut hamt_node_t;
                if children_size > 0 as ::core::ffi::c_int {
                    new_children = malloc(
                        (::core::mem::size_of::<hamt_node_t>() as size_t)
                            .wrapping_mul(children_size as size_t),
                    ) as *mut hamt_node_t;
                    let mut i: ::core::ffi::c_int = 0;
                    i = 0 as ::core::ffi::c_int;
                    while i < child_position {
                        *new_children.offset(i as isize) = *children.offset(i as isize);
                        i += 1;
                    }
                    (*removed_kv).key = (*subnode).leaf.key;
                    (*removed_kv).value = (*subnode).leaf.value;
                    while i < children_size {
                        *new_children.offset(i as isize) = *children
                            .offset((i + 1 as ::core::ffi::c_int) as isize);
                        i += 1;
                    }
                }
                free(children as *mut ::core::ffi::c_void);
                (*node).sub.children = (new_children as ::core::ffi::c_int
                    | HAMT_NODE_T_FLAG) as *mut hamt_node_t as *mut hamt_node_;
                children = new_children;
            }
        } else {
            removed = hamt_node_remove(
                subnode,
                hash,
                lvl + 1 as ::core::ffi::c_int,
                key,
                equals_fn,
                removed_kv,
            );
        }
    }
    let mut children_size_0: ::core::ffi::c_int = (*node).sub.bitmap.count_ones() as i32;
    if children_size_0 < 2 as ::core::ffi::c_int {
        if !(children_size_0 == 1 as ::core::ffi::c_int) as ::core::ffi::c_int
            as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 17],
                    [::core::ffi::c_char; 17],
                >(*b"hamt_node_remove\0")
                    .as_ptr(),
                b"hamta.c\0" as *const u8 as *const ::core::ffi::c_char,
                257 as ::core::ffi::c_int,
                b"children_size == 1\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        let mut only_remaining_child: *mut hamt_node_t = &mut *children
            .offset(0 as ::core::ffi::c_int as isize) as *mut hamt_node_t;
        if is_leaf(only_remaining_child) {
            *node = *only_remaining_child;
            free(children as *mut ::core::ffi::c_void);
        }
    }
    return removed;
}
#[no_mangle]
pub unsafe extern "C" fn hamt_node_destroy(
    mut node: *mut hamt_node_t,
    mut deallocate_fn: deallocate_fn_t,
) {
    if !is_leaf(node) {
        let mut children: *mut hamt_node_t = get_children_pointer(node);
        let mut children_size: ::core::ffi::c_int = (*node).sub.bitmap.count_ones()
            as i32;
        let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while i < children_size {
            hamt_node_destroy(&mut *children.offset(i as isize), deallocate_fn);
            i += 1;
        }
        free(children as *mut ::core::ffi::c_void);
    } else if deallocate_fn.is_some() {
        deallocate_fn.expect("non-null function pointer")((*node).leaf.key);
        deallocate_fn.expect("non-null function pointer")((*node).leaf.value);
    }
}
#[no_mangle]
pub unsafe extern "C" fn hamt_node_print(
    mut node: *mut hamt_node_t,
    mut lvl: ::core::ffi::c_int,
    mut str_fn: str_fn_t,
) {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < lvl * 2 as ::core::ffi::c_int {
        putchar(' ' as i32);
        i += 1;
    }
    if is_leaf(node) {
        let mut leaf: *mut key_value_t = node as *mut key_value_t;
        printf(
            b"{%s -> %s}\n\0" as *const u8 as *const ::core::ffi::c_char,
            str_fn.expect("non-null function pointer")((*leaf).key),
            str_fn.expect("non-null function pointer")((*leaf).value),
        );
    } else {
        let mut children_size: ::core::ffi::c_int = (*node).sub.bitmap.count_ones()
            as i32;
        let mut children: *mut hamt_node_t = get_children_pointer(node);
        printf(
            b"bitmap: %08x\n\0" as *const u8 as *const ::core::ffi::c_char,
            (*node).sub.bitmap,
        );
        let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while i_0 < children_size {
            hamt_node_print(
                &mut *children.offset(i_0 as isize),
                lvl + 1 as ::core::ffi::c_int,
                str_fn,
            );
            i_0 += 1;
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn new_hamt(
    mut hash_fn: hash_fn_t,
    mut equals_fn: equals_fn_t,
) -> *mut hamt_t {
    let mut h: *mut hamt_t = malloc(::core::mem::size_of::<hamt_t>() as size_t)
        as *mut hamt_t;
    if h.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 9], [::core::ffi::c_char; 9]>(*b"new_hamt\0")
                .as_ptr(),
            b"hamta.c\0" as *const u8 as *const ::core::ffi::c_char,
            304 as ::core::ffi::c_int,
            b"h != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    (*h).root = malloc(
        (::core::mem::size_of::<hamt_node_t>() as size_t).wrapping_mul(1 as size_t),
    ) as *mut hamt_node_t as *mut hamt_node_;
    if (*h).root.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 9], [::core::ffi::c_char; 9]>(*b"new_hamt\0")
                .as_ptr(),
            b"hamta.c\0" as *const u8 as *const ::core::ffi::c_char,
            307 as ::core::ffi::c_int,
            b"h->root != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    (*(*h).root).leaf.key = NULL;
    (*(*h).root).leaf.value = NULL;
    (*h).size = 0 as ::core::ffi::c_int;
    (*h).hash_fn = hash_fn;
    (*h).equals_fn = equals_fn;
    return h;
}
#[no_mangle]
pub unsafe extern "C" fn hamt_size(mut trie: *mut hamt_t) -> ::core::ffi::c_int {
    return (*trie).size;
}
#[no_mangle]
pub unsafe extern "C" fn hamt_set(
    mut trie: *mut hamt_t,
    mut key: *mut ::core::ffi::c_void,
    mut value: *mut ::core::ffi::c_void,
    mut conflict_kv: *mut key_value_t,
) -> bool {
    let mut hash: ::core::ffi::c_uint = (*trie)
        .hash_fn
        .expect("non-null function pointer")(key);
    let mut inserted: bool = false_0 != 0;
    if (*trie).size == 0 as ::core::ffi::c_int {
        (*(*trie).root).leaf.key = key;
        (*(*trie).root).leaf.value = value;
        (*trie).size = 1 as ::core::ffi::c_int;
        return false_0 != 0;
    }
    inserted = hamt_node_insert(
        (*trie).root as *mut hamt_node_t,
        hash,
        0 as ::core::ffi::c_int,
        key,
        value,
        (*trie).hash_fn,
        (*trie).equals_fn,
        conflict_kv,
    );
    if inserted {
        (*trie).size += 1;
    }
    return !inserted;
}
#[no_mangle]
pub unsafe extern "C" fn hamt_search(
    mut trie: *mut hamt_t,
    mut key: *mut ::core::ffi::c_void,
) -> *mut key_value_t {
    let mut hash: ::core::ffi::c_uint = (*trie)
        .hash_fn
        .expect("non-null function pointer")(key);
    return hamt_node_search(
        (*trie).root as *mut hamt_node_t,
        hash,
        0 as ::core::ffi::c_int,
        key,
        (*trie).equals_fn,
    );
}
#[no_mangle]
pub unsafe extern "C" fn hamt_remove(
    mut trie: *mut hamt_t,
    mut key: *mut ::core::ffi::c_void,
    mut removed_kv: *mut key_value_t,
) -> bool {
    let mut hash: ::core::ffi::c_uint = (*trie)
        .hash_fn
        .expect("non-null function pointer")(key);
    if (*trie).size == 0 as ::core::ffi::c_int {
        return false_0 != 0;
    }
    let mut removed: bool = false_0 != 0;
    if (*trie).size == 1 as ::core::ffi::c_int {
        if !is_leaf((*trie).root as *mut hamt_node_t) as ::core::ffi::c_int
            as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 12],
                    [::core::ffi::c_char; 12],
                >(*b"hamt_remove\0")
                    .as_ptr(),
                b"hamta.c\0" as *const u8 as *const ::core::ffi::c_char,
                357 as ::core::ffi::c_int,
                b"is_leaf(trie->root)\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        (*removed_kv).key = (*(*trie).root).leaf.key;
        (*removed_kv).value = (*(*trie).root).leaf.value;
        removed = true_0 != 0;
    } else {
        removed = hamt_node_remove(
            (*trie).root as *mut hamt_node_t,
            hash,
            0 as ::core::ffi::c_int,
            key,
            (*trie).equals_fn,
            removed_kv,
        );
    }
    if removed {
        (*trie).size -= 1;
    }
    return removed;
}
#[no_mangle]
pub unsafe extern "C" fn hamt_destroy(
    mut trie: *mut hamt_t,
    mut deallocate_fn: deallocate_fn_t,
) {
    if (*trie).size > 0 as ::core::ffi::c_int {
        hamt_node_destroy((*trie).root as *mut hamt_node_t, deallocate_fn);
    }
    free((*trie).root as *mut ::core::ffi::c_void);
    free(trie as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn hamt_print(mut trie: *mut hamt_t, mut str_fn: str_fn_t) {
    if (*trie).size > 0 as ::core::ffi::c_int {
        hamt_node_print(
            (*trie).root as *mut hamt_node_t,
            0 as ::core::ffi::c_int,
            str_fn,
        );
    } else {
        printf(b"{}\n\0" as *const u8 as *const ::core::ffi::c_char);
    }
    printf(b"---\n\n\0" as *const u8 as *const ::core::ffi::c_char);
}
