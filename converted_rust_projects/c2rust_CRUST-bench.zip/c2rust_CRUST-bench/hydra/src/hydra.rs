#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stdoutp: *mut FILE;
    static mut __stderrp: *mut FILE;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn fread(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
        __nitems: size_t,
        __stream: *mut FILE,
    ) -> ::core::ffi::c_ulong;
    fn fseek(
        _: *mut FILE,
        _: ::core::ffi::c_long,
        _: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn ftell(_: *mut FILE) -> ::core::ffi::c_long;
    fn perror(_: *const ::core::ffi::c_char);
    fn rewind(_: *mut FILE);
    fn setbuf(_: *mut FILE, _: *mut ::core::ffi::c_char);
    fn calloc(__count: size_t, __size: size_t) -> *mut ::core::ffi::c_void;
    fn exit(_: ::core::ffi::c_int) -> !;
    fn ioctl(_: ::core::ffi::c_int, _: ::core::ffi::c_ulong, ...) -> ::core::ffi::c_int;
    fn tcgetattr(_: ::core::ffi::c_int, _: *mut termios) -> ::core::ffi::c_int;
    fn tcsetattr(
        _: ::core::ffi::c_int,
        _: ::core::ffi::c_int,
        _: *const termios,
    ) -> ::core::ffi::c_int;
    fn read(_: ::core::ffi::c_int, _: *mut ::core::ffi::c_void, _: size_t) -> ssize_t;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Command {
    pub key: ::core::ffi::c_char,
    pub name: *mut ::core::ffi::c_char,
    pub command: *mut ::core::ffi::c_char,
    pub children: *mut Command,
    pub next: *mut Command,
}
pub type size_t = __darwin_size_t;
pub type __darwin_size_t = usize;
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type fpos_t = __darwin_off_t;
pub type __darwin_off_t = __int64_t;
pub type __int64_t = i64;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct winsize {
    pub ws_row: ::core::ffi::c_ushort,
    pub ws_col: ::core::ffi::c_ushort,
    pub ws_xpixel: ::core::ffi::c_ushort,
    pub ws_ypixel: ::core::ffi::c_ushort,
}
pub type __uint32_t = u32;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct termios {
    pub c_iflag: tcflag_t,
    pub c_oflag: tcflag_t,
    pub c_cflag: tcflag_t,
    pub c_lflag: tcflag_t,
    pub c_cc: [cc_t; 20],
    pub c_ispeed: speed_t,
    pub c_ospeed: speed_t,
}
pub type speed_t = ::core::ffi::c_ulong;
pub type cc_t = ::core::ffi::c_uchar;
pub type tcflag_t = ::core::ffi::c_ulong;
pub type ssize_t = __darwin_ssize_t;
pub type __darwin_ssize_t = isize;
pub const ColorOff: [::core::ffi::c_char; 5] = unsafe {
    ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"\x1B[0m\0")
};
pub const Yellow: [::core::ffi::c_char; 8] = unsafe {
    ::core::mem::transmute::<[u8; 8], [::core::ffi::c_char; 8]>(*b"\x1B[0;33m\0")
};
pub const Blue: [::core::ffi::c_char; 8] = unsafe {
    ::core::mem::transmute::<[u8; 8], [::core::ffi::c_char; 8]>(*b"\x1B[0;34m\0")
};
pub const Purple: [::core::ffi::c_char; 8] = unsafe {
    ::core::mem::transmute::<[u8; 8], [::core::ffi::c_char; 8]>(*b"\x1B[0;35m\0")
};
pub const RightMargin: ::core::ffi::c_int = 5 as ::core::ffi::c_int;
pub const DefaultName: [::core::ffi::c_char; 8] = unsafe {
    ::core::mem::transmute::<[u8; 8], [::core::ffi::c_char; 8]>(*b"unnamed\0")
};
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const SEEK_END: ::core::ffi::c_int = 2 as ::core::ffi::c_int;
pub const EXIT_FAILURE: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const IOCPARM_MASK: ::core::ffi::c_int = 0x1fff as ::core::ffi::c_int;
pub const TIOCGWINSZ: usize = 0x40000000 as ::core::ffi::c_int as __uint32_t as usize
    | (::core::mem::size_of::<winsize>() as usize & IOCPARM_MASK as usize)
        << 16 as ::core::ffi::c_int | (('t' as i32) << 8 as ::core::ffi::c_int) as usize
    | 104 as usize;
pub const VMIN: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
pub const VTIME: ::core::ffi::c_int = 17 as ::core::ffi::c_int;
pub const ECHO: ::core::ffi::c_int = 0x8 as ::core::ffi::c_int;
pub const ICANON: ::core::ffi::c_int = 0x100 as ::core::ffi::c_int;
pub const TCSANOW: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const TCSADRAIN: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const STDERR_FILENO: ::core::ffi::c_int = 2 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn NewCommand(
    mut key: ::core::ffi::c_char,
    mut name: *mut ::core::ffi::c_char,
    mut command: *mut ::core::ffi::c_char,
) -> *mut Command {
    let mut cmd: *mut Command = calloc(
        1 as size_t,
        ::core::mem::size_of::<Command>() as size_t,
    ) as *mut Command;
    (*cmd).key = key;
    (*cmd).name = name;
    (*cmd).command = command;
    return cmd;
}
#[no_mangle]
pub unsafe extern "C" fn CommandRun(mut c: *mut Command) -> ::core::ffi::c_int {
    if !c.is_null() && !(*c).command.is_null() {
        return fprintf(
            __stdoutp,
            b"%s\0" as *const u8 as *const ::core::ffi::c_char,
            (*c).command,
        );
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn CommandAddChild(mut c: *mut Command, mut child: *mut Command) {
    if (*c).children.is_null() {
        (*c).children = child as *mut Command;
        return;
    }
    if (*(*c).children).key as ::core::ffi::c_int > (*child).key as ::core::ffi::c_int {
        (*child).next = (*c).children;
        (*c).children = child as *mut Command;
        return;
    }
    let mut lastChild: *mut Command = (*c).children as *mut Command;
    while !(*lastChild).next.is_null()
        && (*(*lastChild).next).key as ::core::ffi::c_int
            <= (*child).key as ::core::ffi::c_int
    {
        lastChild = (*lastChild).next as *mut Command;
    }
    (*child).next = (*lastChild).next;
    (*lastChild).next = child as *mut Command;
}
#[no_mangle]
pub unsafe extern "C" fn FindCommand(
    mut c: *mut Command,
    mut key: ::core::ffi::c_char,
) -> *mut Command {
    let mut child: *mut Command = (*c).children as *mut Command;
    while !child.is_null()
        && (*child).key as ::core::ffi::c_int != key as ::core::ffi::c_int
    {
        child = (*child).next as *mut Command;
    }
    return child;
}
#[no_mangle]
pub unsafe extern "C" fn TreeAddCommand(
    mut tree: *mut Command,
    mut keys: *mut ::core::ffi::c_char,
    mut name: *mut ::core::ffi::c_char,
    mut command: *mut ::core::ffi::c_char,
) {
    let mut c: *mut Command = FindCommand(tree, *keys);
    if *keys.offset(1 as ::core::ffi::c_int as isize) as ::core::ffi::c_int
        == 0 as ::core::ffi::c_int
    {
        if c.is_null() {
            CommandAddChild(tree, NewCommand(*keys, name, command));
        } else {
            (*c).name = name;
            (*c).command = command;
        }
        return;
    }
    if c.is_null() {
        c = NewCommand(
            *keys,
            DefaultName.as_ptr() as *mut ::core::ffi::c_char,
            0 as *mut ::core::ffi::c_char,
        );
        CommandAddChild(tree, c);
    }
    TreeAddCommand(c, keys.offset(1 as ::core::ffi::c_int as isize), name, command);
}
#[no_mangle]
pub unsafe extern "C" fn PrintCommand(mut c: *mut Command) -> ::core::ffi::c_int {
    let mut terminal: winsize = winsize {
        ws_row: 0,
        ws_col: 0,
        ws_xpixel: 0,
        ws_ypixel: 0,
    };
    ioctl(
        STDERR_FILENO,
        TIOCGWINSZ as ::core::ffi::c_ulong,
        &mut terminal as *mut winsize,
    );
    let mut width: ::core::ffi::c_int = terminal.ws_col as ::core::ffi::c_int;
    let mut lines: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    if !(*c).name.is_null() {
        fprintf(
            __stderrp,
            b"%s%s:%s\n\0" as *const u8 as *const ::core::ffi::c_char,
            Blue.as_ptr(),
            (*c).name,
            ColorOff.as_ptr(),
        );
        lines += 1;
    }
    let mut maxLineWidth: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut child: *mut Command = (*c).children as *mut Command;
    while !child.is_null() {
        let mut lineWidth: ::core::ffi::c_int = strlen((*child).name)
            as ::core::ffi::c_int;
        if lineWidth > maxLineWidth {
            maxLineWidth = lineWidth;
        }
        child = (*child).next as *mut Command;
    }
    maxLineWidth += RightMargin;
    if maxLineWidth > width {
        maxLineWidth = width;
    }
    let mut itemsPerRow: ::core::ffi::c_int = width
        / (maxLineWidth + 5 as ::core::ffi::c_int);
    child = (*c).children as *mut Command;
    let mut currentItem: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while !child.is_null() {
        currentItem += 1;
        if !(*child).children.is_null() {
            fprintf(
                __stderrp,
                b"%s%c%s %s\xE2\x9E\x94%s %s+%-*s%s\0" as *const u8
                    as *const ::core::ffi::c_char,
                Yellow.as_ptr(),
                (*child).key as ::core::ffi::c_int,
                ColorOff.as_ptr(),
                Purple.as_ptr(),
                ColorOff.as_ptr(),
                Blue.as_ptr(),
                maxLineWidth,
                (*child).name,
                ColorOff.as_ptr(),
            );
        } else {
            fprintf(
                __stderrp,
                b"%s%c%s %s\xE2\x9E\x94%s  %-*s\0" as *const u8
                    as *const ::core::ffi::c_char,
                Yellow.as_ptr(),
                (*child).key as ::core::ffi::c_int,
                ColorOff.as_ptr(),
                Purple.as_ptr(),
                ColorOff.as_ptr(),
                maxLineWidth,
                (*child).name,
            );
        }
        if currentItem % itemsPerRow == 0 as ::core::ffi::c_int {
            fprintf(__stderrp, b"\n\0" as *const u8 as *const ::core::ffi::c_char);
            lines += 1;
        }
        child = (*child).next as *mut Command;
    }
    fprintf(__stderrp, b"\n\0" as *const u8 as *const ::core::ffi::c_char);
    lines += 1;
    return lines;
}
#[no_mangle]
pub unsafe extern "C" fn getch() -> ::core::ffi::c_char {
    let mut old: termios = {
        let mut init = termios {
            c_iflag: 0 as tcflag_t,
            c_oflag: 0,
            c_cflag: 0,
            c_lflag: 0,
            c_cc: [0; 20],
            c_ispeed: 0,
            c_ospeed: 0,
        };
        init
    };
    if tcgetattr(0 as ::core::ffi::c_int, &mut old) < 0 as ::core::ffi::c_int {
        perror(b"tcsetattr()\0" as *const u8 as *const ::core::ffi::c_char);
    }
    let mut oldflags: tcflag_t = old.c_lflag;
    old.c_lflag &= !ICANON as tcflag_t;
    old.c_lflag &= !ECHO as tcflag_t;
    old.c_cc[VMIN as usize] = 1 as cc_t;
    old.c_cc[VTIME as usize] = 0 as cc_t;
    if tcsetattr(0 as ::core::ffi::c_int, TCSANOW, &mut old) < 0 as ::core::ffi::c_int {
        perror(b"tcsetattr ICANON\0" as *const u8 as *const ::core::ffi::c_char);
    }
    let mut buf: ::core::ffi::c_char = 0 as ::core::ffi::c_char;
    if read(
        0 as ::core::ffi::c_int,
        &mut buf as *mut ::core::ffi::c_char as *mut ::core::ffi::c_void,
        1 as size_t,
    ) < 0 as ssize_t
    {
        perror(b"read()\0" as *const u8 as *const ::core::ffi::c_char);
    }
    old.c_lflag = oldflags;
    if tcsetattr(0 as ::core::ffi::c_int, TCSADRAIN, &mut old) < 0 as ::core::ffi::c_int
    {
        perror(b"tcsetattr ~ICANON\0" as *const u8 as *const ::core::ffi::c_char);
    }
    return buf;
}
#[no_mangle]
pub unsafe extern "C" fn ReadFile(
    mut file: *mut ::core::ffi::c_char,
) -> *mut ::core::ffi::c_char {
    let mut f: *mut FILE = fopen(file, b"r\0" as *const u8 as *const ::core::ffi::c_char)
        as *mut FILE;
    if f.is_null() {
        perror(b"Failed to open file\0" as *const u8 as *const ::core::ffi::c_char);
        exit(EXIT_FAILURE);
    }
    fseek(f, 0 as ::core::ffi::c_long, SEEK_END);
    let mut fileSize: ::core::ffi::c_long = ftell(f);
    rewind(f);
    let mut content: *mut ::core::ffi::c_char = calloc(
        (fileSize + 1 as ::core::ffi::c_long) as size_t,
        ::core::mem::size_of::<::core::ffi::c_char>() as size_t,
    ) as *mut ::core::ffi::c_char;
    fread(content as *mut ::core::ffi::c_void, fileSize as size_t, 1 as size_t, f);
    fclose(f);
    return content;
}
#[no_mangle]
pub unsafe extern "C" fn ReadField(
    mut file: *mut *mut ::core::ffi::c_char,
    mut field: *mut ::core::ffi::c_char,
) -> *mut ::core::ffi::c_char {
    let mut key: *mut ::core::ffi::c_char = *file;
    while **file as ::core::ffi::c_int != ',' as i32
        && **file as ::core::ffi::c_int != '\n' as i32
        && **file as ::core::ffi::c_int != 0 as ::core::ffi::c_int
    {
        *file = (*file).offset(1);
    }
    if **file as ::core::ffi::c_int != ',' as i32 {
        fprintf(
            __stderrp,
            b"Found incorrect end after %s, found: %c\0" as *const u8
                as *const ::core::ffi::c_char,
            field,
            **file as ::core::ffi::c_int,
        );
        exit(EXIT_FAILURE);
    }
    **file = 0 as ::core::ffi::c_char;
    *file = (*file).offset(1);
    return key;
}
#[no_mangle]
pub unsafe extern "C" fn ReadUntilEOL(
    mut file: *mut *mut ::core::ffi::c_char,
) -> *mut ::core::ffi::c_char {
    let mut s: *mut ::core::ffi::c_char = *file;
    while **file as ::core::ffi::c_int != '\n' as i32
        && **file as ::core::ffi::c_int != 0 as ::core::ffi::c_int
    {
        *file = (*file).offset(1);
    }
    if **file as ::core::ffi::c_int == '\n' as i32 {
        **file = 0 as ::core::ffi::c_char;
        *file = (*file).offset(1);
    }
    return s;
}
#[no_mangle]
pub unsafe extern "C" fn ReadLine(
    mut c: *mut Command,
    mut file: *mut *mut ::core::ffi::c_char,
) {
    let mut key: *mut ::core::ffi::c_char = ReadField(
        file,
        b"key\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    );
    let mut name: *mut ::core::ffi::c_char = ReadField(
        file,
        b"name\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    );
    let mut command: *mut ::core::ffi::c_char = ReadUntilEOL(file);
    TreeAddCommand(c, key, name, command);
}
#[no_mangle]
pub unsafe extern "C" fn ClearLines(mut count: ::core::ffi::c_int) {
    setbuf(__stdoutp, 0 as *mut ::core::ffi::c_char);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < count {
        fprintf(
            __stderrp,
            b"\x1B[A\r\x1B[2K\0" as *const u8 as *const ::core::ffi::c_char,
        );
        i += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn LoadFile(
    mut c: *mut Command,
    mut file: *mut ::core::ffi::c_char,
) {
    let mut content: *mut ::core::ffi::c_char = ReadFile(file);
    while *content as ::core::ffi::c_int != 0 as ::core::ffi::c_int {
        ReadLine(c, &mut content);
    }
}
#[no_mangle]
pub unsafe extern "C" fn Start(mut c: *mut Command) {
    while !c.is_null() && !(*c).children.is_null() {
        let mut lastPrintedLines: ::core::ffi::c_int = PrintCommand(c);
        c = FindCommand(c, getch());
        ClearLines(lastPrintedLines);
        if CommandRun(c) > 0 as ::core::ffi::c_int {
            return;
        }
    }
}
