#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn trusted_utils_copy_bytes(to: *mut u8_0, from: *const u8_0, nb_bytes: u64_0);
    fn siphash_reset();
    fn siphash_update(data: *const ::core::ffi::c_uchar, nb_bytes: u64_0);
    fn siphash_digest() -> *mut u8_0;
}
pub type u64_0 = ::core::ffi::c_ulong;
pub type u8_0 = ::core::ffi::c_uchar;
pub const SIG_SIZE_BYTES: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn confirm_result(
    mut f_sig: *mut u8_0,
    mut constant: u8_0,
    mut out: *mut u8_0,
) {
    siphash_reset();
    siphash_update(f_sig, SIG_SIZE_BYTES as u64_0);
    siphash_update(&mut constant, 1 as u64_0);
    let mut sig: *mut u8_0 = siphash_digest();
    trusted_utils_copy_bytes(out, sig, SIG_SIZE_BYTES as u64_0);
}
