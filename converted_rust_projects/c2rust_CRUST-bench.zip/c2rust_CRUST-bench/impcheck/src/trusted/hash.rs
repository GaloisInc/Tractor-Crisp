#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn trusted_utils_malloc(size: u64_0) -> *mut ::core::ffi::c_void;
    fn trusted_utils_calloc(
        nb_objs: u64_0,
        size_per_obj: u64_0,
    ) -> *mut ::core::ffi::c_void;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn free(_: *mut ::core::ffi::c_void);
}
pub type u64_0 = ::core::ffi::c_ulong;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct hash_table_entry {
    pub key: u64_0,
    pub val: *mut ::core::ffi::c_void,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct hash_table {
    pub size: u64_0,
    pub max_size: u64_0,
    pub growth_factor: ::core::ffi::c_float,
    pub capacity: u64_0,
    pub data: *mut hash_table_entry,
    pub last_found_idx: u64_0,
}
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn compute_hash(mut key: u64_0) -> u64_0 {
    return (0xcbf29ce484222325 as u64_0 ^ key).wrapping_mul(0x100000001b3 as u64_0);
}
#[no_mangle]
pub unsafe extern "C" fn compute_idx(mut ht: *mut hash_table, mut key: u64_0) -> u64_0 {
    return compute_hash(key) & (*ht).capacity.wrapping_sub(1 as u64_0);
}
#[no_mangle]
pub unsafe extern "C" fn cell_empty(mut entry: *mut hash_table_entry) -> bool {
    return (*entry).key == 0 as u64_0;
}
#[no_mangle]
pub unsafe extern "C" fn find_entry(
    mut ht: *mut hash_table,
    mut key: u64_0,
    mut idx: *mut u64_0,
) -> bool {
    let mut i: u64_0 = compute_idx(ht, key);
    let orig_idx: u64_0 = i;
    while i < (*ht).capacity {
        let mut entry: *mut hash_table_entry = &mut *(*ht).data.offset(i as isize)
            as *mut hash_table_entry;
        if cell_empty(entry) {
            *idx = i;
            return false_0 != 0;
        }
        if (*entry).key == key {
            *idx = i;
            return true_0 != 0;
        }
        i = i.wrapping_add(1);
    }
    i = 0 as u64_0;
    while i < orig_idx {
        let mut entry_0: *mut hash_table_entry = &mut *(*ht).data.offset(i as isize)
            as *mut hash_table_entry;
        if cell_empty(entry_0) {
            *idx = i;
            return false_0 != 0;
        }
        if (*entry_0).key == key {
            *idx = i;
            return true_0 != 0;
        }
        i = i.wrapping_add(1);
    }
    return false_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn realloc_table(mut ht: *mut hash_table) -> bool {
    let mut new_capacity: u64_0 = ((*ht).growth_factor
        * (*ht).capacity as ::core::ffi::c_float) as u64_0;
    let mut old_data: *mut hash_table_entry = (*ht).data;
    let mut old_capacity: u64_0 = (*ht).capacity;
    (*ht).data = trusted_utils_calloc(
        new_capacity,
        ::core::mem::size_of::<hash_table_entry>() as u64_0,
    ) as *mut hash_table_entry;
    if (*ht).data.is_null() {
        return false_0 != 0;
    }
    (*ht).size = 0 as u64_0;
    (*ht).max_size = ((*ht).growth_factor * (*ht).max_size as ::core::ffi::c_float)
        as u64_0;
    (*ht).capacity = new_capacity;
    let mut i: u64_0 = 0 as u64_0;
    while i < old_capacity {
        let mut cell: *mut hash_table_entry = &mut *old_data.offset(i as isize)
            as *mut hash_table_entry;
        if !cell_empty(cell) {
            if !hash_table_insert(ht, (*cell).key, (*cell).val) {
                return false_0 != 0;
            }
        }
        i = i.wrapping_add(1);
    }
    free(old_data as *mut ::core::ffi::c_void);
    return true_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn handle_gap(
    mut ht: *mut hash_table,
    mut idx_of_gap: u64_0,
) -> bool {
    let mut i: u64_0 = idx_of_gap;
    let mut j: u64_0 = i;
    loop {
        j = j.wrapping_add(1 as u64_0) & (*ht).capacity.wrapping_sub(1 as u64_0);
        if cell_empty(&mut *(*ht).data.offset(j as isize)) {
            let mut entry: *mut hash_table_entry = &mut *(*ht).data.offset(i as isize)
                as *mut hash_table_entry;
            (*entry).key = 0 as u64_0;
            (*entry).val = 0 as *mut ::core::ffi::c_void;
            return true_0 != 0;
        }
        let mut k: u64_0 = compute_idx(ht, (*(*ht).data.offset(j as isize)).key);
        if j > i && (k <= i || k > j) || j < i && k <= i && k > j {
            let mut entry_at_deletion: *mut hash_table_entry = &mut *(*ht)
                .data
                .offset(i as isize) as *mut hash_table_entry;
            let mut entry2move: *mut hash_table_entry = &mut *(*ht)
                .data
                .offset(j as isize) as *mut hash_table_entry;
            *entry_at_deletion = *entry2move;
            (*entry2move).key = 0 as u64_0;
            (*entry2move).val = 0 as *mut ::core::ffi::c_void;
            i = j;
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn hash_table_init(
    mut log_init_capacity: ::core::ffi::c_int,
) -> *mut hash_table {
    let mut ht: *mut hash_table = trusted_utils_malloc(
        ::core::mem::size_of::<hash_table>() as u64_0,
    ) as *mut hash_table;
    (*ht).capacity = ((1 as ::core::ffi::c_int) << log_init_capacity) as u64_0;
    (*ht).size = 0 as u64_0;
    (*ht).max_size = (*ht).capacity >> 1 as ::core::ffi::c_int;
    (*ht).growth_factor = 2 as ::core::ffi::c_int as ::core::ffi::c_float;
    (*ht).data = trusted_utils_calloc(
        (*ht).capacity,
        ::core::mem::size_of::<hash_table_entry>() as u64_0,
    ) as *mut hash_table_entry;
    return ht;
}
#[no_mangle]
pub unsafe extern "C" fn hash_table_find(
    mut ht: *mut hash_table,
    mut key: u64_0,
) -> *mut ::core::ffi::c_void {
    let mut idx: u64_0 = 0;
    if !find_entry(ht, key, &mut idx) {
        return 0 as *mut ::core::ffi::c_void;
    }
    (*ht).last_found_idx = idx;
    if !((*(*ht).data.offset(idx as isize)).key == key) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"hash_table_find\0")
                .as_ptr(),
            b"hash.c\0" as *const u8 as *const ::core::ffi::c_char,
            123 as ::core::ffi::c_int,
            b"ht->data[idx].key == key\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if (*(*ht).data.offset(idx as isize)).val.is_null() as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"hash_table_find\0")
                .as_ptr(),
            b"hash.c\0" as *const u8 as *const ::core::ffi::c_char,
            124 as ::core::ffi::c_int,
            b"ht->data[idx].val\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return (*(*ht).data.offset(idx as isize)).val;
}
#[no_mangle]
pub unsafe extern "C" fn hash_table_insert(
    mut ht: *mut hash_table,
    mut key: u64_0,
    mut val: *mut ::core::ffi::c_void,
) -> bool {
    if key == 0 as u64_0 {
        return false_0 != 0;
    }
    if (*ht).size == (*ht).max_size {
        if !realloc_table(ht) {
            return false_0 != 0;
        }
        if (*ht).size >= (*ht).max_size {
            return false_0 != 0;
        }
    }
    let mut idx: u64_0 = 0;
    if find_entry(ht, key, &mut idx) {
        return false_0 != 0;
    }
    if !cell_empty(&mut *(*ht).data.offset(idx as isize)) {
        return false_0 != 0;
    }
    let mut entry: *mut hash_table_entry = &mut *(*ht).data.offset(idx as isize)
        as *mut hash_table_entry;
    (*entry).key = key;
    (*entry).val = val;
    (*ht).size = (*ht).size.wrapping_add(1);
    return true_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn hash_table_delete(
    mut ht: *mut hash_table,
    mut key: u64_0,
) -> bool {
    let mut idx: u64_0 = 0;
    if !find_entry(ht, key, &mut idx) {
        return false_0 != 0;
    }
    if !handle_gap(ht, idx) {
        return false_0 != 0;
    }
    (*ht).size = (*ht).size.wrapping_sub(1);
    return true_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn hash_table_delete_last_found(mut ht: *mut hash_table) -> bool {
    if !handle_gap(ht, (*ht).last_found_idx) {
        return false_0 != 0;
    }
    (*ht).size = (*ht).size.wrapping_sub(1);
    return true_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn hash_table_free(mut ht: *mut hash_table) {
    free(ht as *mut ::core::ffi::c_void);
}
