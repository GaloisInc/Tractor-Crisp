#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn free(_: *mut ::core::ffi::c_void);
    fn snprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    static mut trusted_utils_msgstr: [::core::ffi::c_char; 512];
    fn trusted_utils_calloc(
        nb_objs: u64_0,
        size_per_obj: u64_0,
    ) -> *mut ::core::ffi::c_void;
    fn hash_table_init(log_init_capacity: ::core::ffi::c_int) -> *mut hash_table;
    fn hash_table_find(ht: *mut hash_table, key: u64_0) -> *mut ::core::ffi::c_void;
    fn hash_table_insert(
        ht: *mut hash_table,
        key: u64_0,
        data: *mut ::core::ffi::c_void,
    ) -> bool;
    fn hash_table_delete_last_found(ht: *mut hash_table) -> bool;
    fn siphash_update(data: *const ::core::ffi::c_uchar, nb_bytes: u64_0);
    fn siphash_pad(nb_bytes: u64_0);
    fn siphash_digest() -> *mut u8_0;
    fn int_vec_init(capacity: u64_0) -> *mut int_vec;
    fn int_vec_reserve(vec: *mut int_vec, new_size: u64_0);
    fn int_vec_push(vec: *mut int_vec, elem: ::core::ffi::c_int);
    fn int_vec_clear(vec: *mut int_vec);
    fn i8_vec_init(capacity: u64_0) -> *mut i8_vec;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type u64_0 = ::core::ffi::c_ulong;
pub type u8_0 = ::core::ffi::c_uchar;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct hash_table_entry {
    pub key: u64_0,
    pub val: *mut ::core::ffi::c_void,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct hash_table {
    pub size: u64_0,
    pub max_size: u64_0,
    pub growth_factor: ::core::ffi::c_float,
    pub capacity: u64_0,
    pub data: *mut hash_table_entry,
    pub last_found_idx: u64_0,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct int_vec {
    pub capacity: u64_0,
    pub size: u64_0,
    pub data: *mut ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct i8_vec {
    pub capacity: u64_0,
    pub size: u64_0,
    pub data: *mut ::core::ffi::c_schar,
}
#[no_mangle]
pub static mut clause_table: *mut hash_table = 0 as *const hash_table as *mut hash_table;
#[no_mangle]
pub static mut var_values: *mut i8_vec = 0 as *const i8_vec as *mut i8_vec;
#[no_mangle]
pub static mut assigned_units: *mut int_vec = 0 as *const int_vec as *mut int_vec;
#[no_mangle]
pub static mut check_model: bool = false;
#[no_mangle]
pub static mut lenient: bool = false;
#[no_mangle]
pub static mut id_to_add: u64_0 = 1 as u64_0;
#[no_mangle]
pub static mut nb_loaded_clauses: u64_0 = 0 as u64_0;
#[no_mangle]
pub static mut clause_to_add: *mut int_vec = 0 as *const int_vec as *mut int_vec;
#[no_mangle]
pub static mut done_loading: bool = false_0 != 0;
#[no_mangle]
pub static mut unsat_proven: bool = false_0 != 0;
#[no_mangle]
pub unsafe extern "C" fn clause_init(
    mut data: *const ::core::ffi::c_int,
    mut nb_lits: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_int {
    let mut cls: *mut ::core::ffi::c_int = trusted_utils_calloc(
        (nb_lits + 1 as ::core::ffi::c_int) as u64_0,
        ::core::mem::size_of::<::core::ffi::c_int>() as u64_0,
    ) as *mut ::core::ffi::c_int;
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < nb_lits {
        *cls.offset(i as isize) = *data.offset(i as isize);
        i += 1;
    }
    *cls.offset(nb_lits as isize) = 0 as ::core::ffi::c_int;
    return cls;
}
#[no_mangle]
pub unsafe extern "C" fn reset_assignments() {
    let mut i: u64_0 = 0 as u64_0;
    while i < (*assigned_units).size {
        *(*var_values)
            .data
            .offset(*(*assigned_units).data.offset(i as isize) as isize) = 0
            as ::core::ffi::c_schar;
        i = i.wrapping_add(1);
    }
    int_vec_clear(assigned_units);
}
#[no_mangle]
pub unsafe extern "C" fn check_clause(
    mut base_id: u64_0,
    mut lits: *const ::core::ffi::c_int,
    mut nb_lits: ::core::ffi::c_int,
    mut hints: *const u64_0,
    mut nb_hints: ::core::ffi::c_int,
) -> bool {
    int_vec_reserve(assigned_units, (nb_lits + nb_hints) as u64_0);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < nb_lits {
        let var: ::core::ffi::c_int = if *lits.offset(i as isize)
            > 0 as ::core::ffi::c_int
        {
            *lits.offset(i as isize)
        } else {
            -*lits.offset(i as isize)
        };
        *(*var_values).data.offset(var as isize) = (if *lits.offset(i as isize)
            > 0 as ::core::ffi::c_int
        {
            -(1 as ::core::ffi::c_int)
        } else {
            1 as ::core::ffi::c_int
        }) as ::core::ffi::c_schar;
        int_vec_push(assigned_units, var);
        i += 1;
    }
    let mut ok: bool = true_0 != 0;
    let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_0 < nb_hints {
        let hint_id: u64_0 = *hints.offset(i_0 as isize);
        let mut cls: *mut ::core::ffi::c_int = hash_table_find(clause_table, hint_id)
            as *mut ::core::ffi::c_int;
        if cls.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
            snprintf(
                trusted_utils_msgstr.as_mut_ptr(),
                512 as size_t,
                b"Derivation %lu: hint %lu not found\0" as *const u8
                    as *const ::core::ffi::c_char,
                base_id,
                hint_id,
            );
            break;
        } else {
            let mut new_unit: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
            let mut lit_idx: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
            loop {
                let lit: ::core::ffi::c_int = *cls.offset(lit_idx as isize);
                if lit == 0 as ::core::ffi::c_int {
                    break;
                }
                let var_0: ::core::ffi::c_int = if lit > 0 as ::core::ffi::c_int {
                    lit
                } else {
                    -lit
                };
                if *(*var_values).data.offset(var_0 as isize) as ::core::ffi::c_int
                    == 0 as ::core::ffi::c_int
                {
                    if (new_unit != 0 as ::core::ffi::c_int) as ::core::ffi::c_int
                        as ::core::ffi::c_long != 0
                    {
                        snprintf(
                            trusted_utils_msgstr.as_mut_ptr(),
                            512 as size_t,
                            b"Derivation %lu: multiple literals unassigned\0"
                                as *const u8 as *const ::core::ffi::c_char,
                            base_id,
                        );
                        ok = false_0 != 0;
                        break;
                    } else {
                        new_unit = lit;
                    }
                } else {
                    let sign: bool = *(*var_values).data.offset(var_0 as isize)
                        as ::core::ffi::c_int > 0 as ::core::ffi::c_int;
                    if (sign as ::core::ffi::c_int
                        == (lit > 0 as ::core::ffi::c_int) as ::core::ffi::c_int)
                        as ::core::ffi::c_int as ::core::ffi::c_long != 0
                    {
                        snprintf(
                            trusted_utils_msgstr.as_mut_ptr(),
                            512 as size_t,
                            b"Derivation %lu: dependency %lu is satisfied\0" as *const u8
                                as *const ::core::ffi::c_char,
                            base_id,
                            hint_id,
                        );
                        ok = false_0 != 0;
                        break;
                    }
                }
                lit_idx += 1;
            }
            if !ok {
                break;
            }
            if new_unit == 0 as ::core::ffi::c_int {
                if ((i_0 + 1 as ::core::ffi::c_int) < nb_hints) as ::core::ffi::c_int
                    as ::core::ffi::c_long != 0
                {
                    snprintf(
                        trusted_utils_msgstr.as_mut_ptr(),
                        512 as size_t,
                        b"Derivation %lu: empty clause produced at non-final hint %lu\0"
                            as *const u8 as *const ::core::ffi::c_char,
                        base_id,
                        hint_id,
                    );
                    break;
                } else {
                    reset_assignments();
                    return true_0 != 0;
                }
            } else {
                let mut var_1: ::core::ffi::c_int = if new_unit > 0 as ::core::ffi::c_int
                {
                    new_unit
                } else {
                    -new_unit
                };
                *(*var_values).data.offset(var_1 as isize) = (if new_unit
                    > 0 as ::core::ffi::c_int
                {
                    1 as ::core::ffi::c_int
                } else {
                    -(1 as ::core::ffi::c_int)
                }) as ::core::ffi::c_schar;
                int_vec_push(assigned_units, var_1);
                i_0 += 1;
            }
        }
    }
    if trusted_utils_msgstr[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
        == '\0' as i32
    {
        snprintf(
            trusted_utils_msgstr.as_mut_ptr(),
            512 as size_t,
            b"Derivation %lu: no empty clause was produced\0" as *const u8
                as *const ::core::ffi::c_char,
            base_id,
        );
    }
    reset_assignments();
    return false_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn clauses_equivalent(
    mut left_cls: *mut ::core::ffi::c_int,
    mut right_cls: *mut ::core::ffi::c_int,
) -> bool {
    let mut lit_idx: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while *left_cls.offset(lit_idx as isize) != 0 as ::core::ffi::c_int {
        let left_lit: ::core::ffi::c_int = *left_cls.offset(lit_idx as isize);
        let mut found: bool = false_0 != 0;
        let mut right_lit_idx: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while *right_cls.offset(right_lit_idx as isize) != 0 as ::core::ffi::c_int {
            if *right_cls.offset(right_lit_idx as isize) == left_lit {
                found = true_0 != 0;
                break;
            } else {
                right_lit_idx += 1;
            }
        }
        if !found {
            return false_0 != 0;
        }
        lit_idx += 1;
    }
    let left_size: ::core::ffi::c_int = lit_idx;
    lit_idx = 0 as ::core::ffi::c_int;
    while *right_cls.offset(lit_idx as isize) != 0 as ::core::ffi::c_int {
        lit_idx += 1;
    }
    let right_size: ::core::ffi::c_int = lit_idx;
    return left_size == right_size;
}
#[no_mangle]
pub unsafe extern "C" fn lrat_check_add_axiomatic_clause(
    mut id: u64_0,
    mut lits: *const ::core::ffi::c_int,
    mut nb_lits: ::core::ffi::c_int,
) -> bool {
    let mut cls: *mut ::core::ffi::c_int = clause_init(lits, nb_lits);
    let mut ok: bool = hash_table_insert(
        clause_table,
        id,
        cls as *mut ::core::ffi::c_void,
    );
    if !ok {
        if lenient {
            let mut old_cls: *mut ::core::ffi::c_int = hash_table_find(clause_table, id)
                as *mut ::core::ffi::c_int;
            if !old_cls.is_null()
                && clauses_equivalent(old_cls, cls) as ::core::ffi::c_int != 0
            {
                ok = true_0 != 0;
            }
        }
        if !ok {
            snprintf(
                trusted_utils_msgstr.as_mut_ptr(),
                512 as size_t,
                b"Insertion of clause %lu unsuccessful - already present?\0" as *const u8
                    as *const ::core::ffi::c_char,
                id,
            );
        }
    } else if nb_lits == 0 as ::core::ffi::c_int {
        unsat_proven = true_0 != 0;
    }
    return ok;
}
#[no_mangle]
pub unsafe extern "C" fn lrat_check_init(
    mut nb_vars: ::core::ffi::c_int,
    mut opt_check_model: bool,
    mut opt_lenient: bool,
) {
    clause_table = hash_table_init(16 as ::core::ffi::c_int);
    clause_to_add = int_vec_init(512 as u64_0);
    var_values = i8_vec_init((nb_vars + 1 as ::core::ffi::c_int) as u64_0);
    assigned_units = int_vec_init(512 as u64_0);
    check_model = opt_check_model;
    lenient = opt_lenient;
}
#[no_mangle]
pub unsafe extern "C" fn lrat_check_load(mut lit: ::core::ffi::c_int) -> bool {
    if lit == 0 as ::core::ffi::c_int {
        if !lrat_check_add_axiomatic_clause(
            id_to_add,
            (*clause_to_add).data,
            (*clause_to_add).size as ::core::ffi::c_int,
        ) {
            return false_0 != 0;
        }
        id_to_add = id_to_add.wrapping_add(1);
        int_vec_push(clause_to_add, 0 as ::core::ffi::c_int);
        siphash_update(
            (*clause_to_add).data as *mut u8_0,
            (*clause_to_add)
                .size
                .wrapping_mul(::core::mem::size_of::<::core::ffi::c_int>() as u64_0),
        );
        int_vec_clear(clause_to_add);
        return true_0 != 0;
    }
    int_vec_push(clause_to_add, lit);
    return true_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn lrat_check_end_load(mut out_sig: *mut *mut u8_0) -> bool {
    if (*clause_to_add).size > 0 as u64_0 {
        snprintf(
            trusted_utils_msgstr.as_mut_ptr(),
            512 as size_t,
            b"literals left in unterminated clause\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return false_0 != 0;
    }
    siphash_pad(2 as u64_0);
    *out_sig = siphash_digest();
    done_loading = true_0 != 0;
    nb_loaded_clauses = id_to_add.wrapping_sub(1 as u64_0);
    return true_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn lrat_check_add_clause(
    mut id: u64_0,
    mut lits: *const ::core::ffi::c_int,
    mut nb_lits: ::core::ffi::c_int,
    mut hints: *const u64_0,
    mut nb_hints: ::core::ffi::c_int,
) -> bool {
    if !check_clause(id, lits, nb_lits, hints, nb_hints) {
        return false_0 != 0;
    }
    return lrat_check_add_axiomatic_clause(id, lits, nb_lits);
}
#[no_mangle]
pub unsafe extern "C" fn lrat_check_delete_clause(
    mut ids: *const u64_0,
    mut nb_ids: ::core::ffi::c_int,
) -> bool {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < nb_ids {
        let mut id: u64_0 = *ids.offset(i as isize);
        let mut cls: *mut ::core::ffi::c_int = hash_table_find(clause_table, id)
            as *mut ::core::ffi::c_int;
        if cls.is_null() {
            snprintf(
                trusted_utils_msgstr.as_mut_ptr(),
                512 as size_t,
                b"Clause deletion: ID %lu not found\0" as *const u8
                    as *const ::core::ffi::c_char,
                id,
            );
            return false_0 != 0;
        }
        if !(check_model as ::core::ffi::c_int != 0 && id <= nb_loaded_clauses) {
            free(cls as *mut ::core::ffi::c_void);
            if !hash_table_delete_last_found(clause_table) {
                snprintf(
                    trusted_utils_msgstr.as_mut_ptr(),
                    512 as size_t,
                    b"Clause deletion: Hash table error for ID %lu\0" as *const u8
                        as *const ::core::ffi::c_char,
                    id,
                );
                return false_0 != 0;
            }
        }
        i += 1;
    }
    return true_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn lrat_check_validate_unsat() -> bool {
    if !done_loading {
        snprintf(
            trusted_utils_msgstr.as_mut_ptr(),
            512 as size_t,
            b"UNSAT validation illegal - loading formula was not concluded\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
        return false_0 != 0;
    }
    if !unsat_proven {
        snprintf(
            trusted_utils_msgstr.as_mut_ptr(),
            512 as size_t,
            b"UNSAT validation unsuccessful - did not derive or import empty clause\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
        return false_0 != 0;
    }
    return true_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn lrat_check_validate_sat(
    mut model: *mut ::core::ffi::c_int,
    mut size: u64_0,
) -> bool {
    if !done_loading {
        snprintf(
            trusted_utils_msgstr.as_mut_ptr(),
            512 as size_t,
            b"SAT validation illegal - loading formula was not concluded\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return false_0 != 0;
    }
    if !check_model {
        snprintf(
            trusted_utils_msgstr.as_mut_ptr(),
            512 as size_t,
            b"SAT validation illegal - not executed to explicitly support this\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
        return false_0 != 0;
    }
    let mut id: u64_0 = 1 as u64_0;
    while id <= nb_loaded_clauses {
        let mut cls: *const ::core::ffi::c_int = hash_table_find(clause_table, id)
            as *mut ::core::ffi::c_int;
        if cls.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
            snprintf(
                trusted_utils_msgstr.as_mut_ptr(),
                512 as size_t,
                b"SAT validation: original ID %lu not found\0" as *const u8
                    as *const ::core::ffi::c_char,
                id,
            );
            return false_0 != 0;
        }
        let mut satisfied: bool = false_0 != 0;
        let mut lit_idx: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while *cls.offset(lit_idx as isize) != 0 as ::core::ffi::c_int {
            let lit: ::core::ffi::c_int = *cls.offset(lit_idx as isize);
            let var: ::core::ffi::c_int = if lit > 0 as ::core::ffi::c_int {
                lit
            } else {
                -lit
            };
            if ((var - 1 as ::core::ffi::c_int) as u64_0 >= size) as ::core::ffi::c_int
                as ::core::ffi::c_long != 0
            {
                snprintf(
                    trusted_utils_msgstr.as_mut_ptr(),
                    512 as size_t,
                    b"SAT validation: model does not cover variable %i\0" as *const u8
                        as *const ::core::ffi::c_char,
                    var,
                );
                return false_0 != 0;
            }
            let mut modelLit: ::core::ffi::c_int = *model
                .offset((var - 1 as ::core::ffi::c_int) as isize);
            if (modelLit != var && modelLit != -var
                && modelLit != 0 as ::core::ffi::c_int) as ::core::ffi::c_int
                as ::core::ffi::c_long != 0
            {
                snprintf(
                    trusted_utils_msgstr.as_mut_ptr(),
                    512 as size_t,
                    b"SAT validation: unexpected literal %i in assignment of variable %i\0"
                        as *const u8 as *const ::core::ffi::c_char,
                    modelLit,
                    var,
                );
                return false_0 != 0;
            }
            if modelLit == 0 as ::core::ffi::c_int {
                let ref mut fresh0 = *model
                    .offset((var - 1 as ::core::ffi::c_int) as isize);
                *fresh0 = lit;
                modelLit = *fresh0;
            }
            if modelLit == lit {
                satisfied = true_0 != 0;
                break;
            } else {
                lit_idx += 1;
            }
        }
        if !satisfied as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
            snprintf(
                trusted_utils_msgstr.as_mut_ptr(),
                512 as size_t,
                b"SAT validation: original clause %lu not satisfied\0" as *const u8
                    as *const ::core::ffi::c_char,
                id,
            );
            return false_0 != 0;
        }
        id = id.wrapping_add(1);
    }
    return true_0 != 0;
}
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
