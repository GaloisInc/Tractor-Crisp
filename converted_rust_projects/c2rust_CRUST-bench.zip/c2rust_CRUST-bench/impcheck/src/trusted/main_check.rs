#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stdoutp: *mut FILE;
    fn fflush(_: *mut FILE) -> ::core::ffi::c_int;
    fn tc_init(
        fifo_in: *const ::core::ffi::c_char,
        fifo_out: *const ::core::ffi::c_char,
    );
    fn tc_run(check_model: bool, lenient: bool) -> ::core::ffi::c_int;
    fn trusted_utils_try_match_arg(
        arg: *const ::core::ffi::c_char,
        opt: *const ::core::ffi::c_char,
        out: *mut *const ::core::ffi::c_char,
    );
    fn trusted_utils_try_match_flag(
        arg: *const ::core::ffi::c_char,
        opt: *const ::core::ffi::c_char,
        out: *mut bool,
    );
}
pub type __int64_t = i64;
pub type __darwin_off_t = __int64_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut fifo_directives: *const ::core::ffi::c_char = b"\0" as *const u8
        as *const ::core::ffi::c_char;
    let mut fifo_feedback: *const ::core::ffi::c_char = b"\0" as *const u8
        as *const ::core::ffi::c_char;
    let mut check_model: bool = false_0 != 0;
    let mut lenient: bool = false_0 != 0;
    let mut i: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    while i < argc {
        trusted_utils_try_match_arg(
            *argv.offset(i as isize),
            b"-fifo-directives=\0" as *const u8 as *const ::core::ffi::c_char,
            &mut fifo_directives,
        );
        trusted_utils_try_match_arg(
            *argv.offset(i as isize),
            b"-fifo-feedback=\0" as *const u8 as *const ::core::ffi::c_char,
            &mut fifo_feedback,
        );
        trusted_utils_try_match_flag(
            *argv.offset(i as isize),
            b"-check-model\0" as *const u8 as *const ::core::ffi::c_char,
            &mut check_model,
        );
        trusted_utils_try_match_flag(
            *argv.offset(i as isize),
            b"-lenient\0" as *const u8 as *const ::core::ffi::c_char,
            &mut lenient,
        );
        i += 1;
    }
    tc_init(fifo_directives, fifo_feedback);
    let mut res: ::core::ffi::c_int = tc_run(check_model, lenient);
    fflush(__stdoutp);
    return res;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
