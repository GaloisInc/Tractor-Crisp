#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn atoi(_: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
    fn strnlen(__s1: *const ::core::ffi::c_char, __n: size_t) -> size_t;
    fn trusted_utils_log_err(msg: *const ::core::ffi::c_char);
    fn trusted_utils_try_match_arg(
        arg: *const ::core::ffi::c_char,
        opt: *const ::core::ffi::c_char,
        out: *mut *const ::core::ffi::c_char,
    );
    fn trusted_utils_equal_signatures(left: *const u8_0, right: *const u8_0) -> bool;
    fn trusted_utils_str_to_sig(str: *const ::core::ffi::c_char, out: *mut u8_0) -> bool;
    fn tp_init(filename: *const ::core::ffi::c_char, out: *mut FILE);
    fn tp_parse(sig: *mut *mut u8_0) -> bool;
    fn confirm_result(f_sig: *mut u8_0, constant: u8_0, out: *mut u8_0);
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type u8_0 = ::core::ffi::c_uchar;
pub type signature = [u8_0; 16];
pub const SIG_SIZE_BYTES: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn error() -> ::core::ffi::c_int {
    printf(b"s NOT VERIFIED\n\0" as *const u8 as *const ::core::ffi::c_char);
    return 1 as ::core::ffi::c_int;
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut formula_input: *const ::core::ffi::c_char = b"\0" as *const u8
        as *const ::core::ffi::c_char;
    let mut result_sig: *const ::core::ffi::c_char = b"\0" as *const u8
        as *const ::core::ffi::c_char;
    let mut resultint_str: *const ::core::ffi::c_char = b"\0" as *const u8
        as *const ::core::ffi::c_char;
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < argc {
        trusted_utils_try_match_arg(
            *argv.offset(i as isize),
            b"-formula-input=\0" as *const u8 as *const ::core::ffi::c_char,
            &mut formula_input,
        );
        trusted_utils_try_match_arg(
            *argv.offset(i as isize),
            b"-result-sig=\0" as *const u8 as *const ::core::ffi::c_char,
            &mut result_sig,
        );
        trusted_utils_try_match_arg(
            *argv.offset(i as isize),
            b"-result=\0" as *const u8 as *const ::core::ffi::c_char,
            &mut resultint_str,
        );
        i += 1;
    }
    let mut result: ::core::ffi::c_int = atoi(resultint_str);
    if result != 10 as ::core::ffi::c_int && result != 20 as ::core::ffi::c_int {
        trusted_utils_log_err(
            b"Result code missing or invalid\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return error();
    }
    if strnlen(
        result_sig,
        (2 as ::core::ffi::c_int * SIG_SIZE_BYTES + 1 as ::core::ffi::c_int) as size_t,
    ) != (2 as ::core::ffi::c_int * SIG_SIZE_BYTES) as size_t
    {
        trusted_utils_log_err(
            b"Result signature missing or malformed\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return error();
    }
    let mut source: *mut FILE = fopen(
        b"/dev/null\0" as *const u8 as *const ::core::ffi::c_char,
        b"w\0" as *const u8 as *const ::core::ffi::c_char,
    ) as *mut FILE;
    tp_init(formula_input, source);
    let mut sig_formula: *mut u8_0 = 0 as *mut u8_0;
    let mut ok: bool = tp_parse(&mut sig_formula as *mut *mut u8_0);
    if !ok {
        trusted_utils_log_err(
            b"Problem during parsing\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return error();
    }
    let mut sig_res_reported: signature = [0; 16];
    ok = trusted_utils_str_to_sig(result_sig, sig_res_reported.as_mut_ptr());
    if !ok {
        trusted_utils_log_err(
            b"Invalid signature string\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return error();
    }
    let mut sig_res_computed: signature = [0; 16];
    confirm_result(sig_formula, result as u8_0, sig_res_computed.as_mut_ptr());
    if !trusted_utils_equal_signatures(
        sig_res_computed.as_mut_ptr(),
        sig_res_reported.as_mut_ptr(),
    ) {
        trusted_utils_log_err(
            b"Signature does not match!\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return error();
    }
    if result == 10 as ::core::ffi::c_int {
        printf(b"s VERIFIED SATISFIABLE\n\0" as *const u8 as *const ::core::ffi::c_char);
    }
    if result == 20 as ::core::ffi::c_int {
        printf(
            b"s VERIFIED UNSATISFIABLE\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
