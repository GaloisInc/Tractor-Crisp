#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn trusted_utils_malloc(size: u64_0) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
}
pub type u64_0 = ::core::ffi::c_ulong;
pub type u32_0 = ::core::ffi::c_uint;
pub type u8_0 = ::core::ffi::c_uchar;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const cROUNDS: ::core::ffi::c_int = 2 as ::core::ffi::c_int;
pub const dROUNDS: ::core::ffi::c_int = 4 as ::core::ffi::c_int;
#[no_mangle]
pub static mut kk: *const ::core::ffi::c_uchar = 0 as *const ::core::ffi::c_uchar;
#[no_mangle]
pub static mut out: *mut u8_0 = 0 as *const u8_0 as *mut u8_0;
#[no_mangle]
pub static mut outlen: ::core::ffi::c_int = 128 as ::core::ffi::c_int
    / 8 as ::core::ffi::c_int;
#[no_mangle]
pub static mut v0: u64_0 = 0;
#[no_mangle]
pub static mut v1: u64_0 = 0;
#[no_mangle]
pub static mut v2: u64_0 = 0;
#[no_mangle]
pub static mut v3: u64_0 = 0;
#[no_mangle]
pub static mut k0: u64_0 = 0;
#[no_mangle]
pub static mut k1: u64_0 = 0;
#[no_mangle]
pub static mut m: u64_0 = 0;
#[no_mangle]
pub static mut i: ::core::ffi::c_int = 0;
#[no_mangle]
pub static mut inlen: u64_0 = 0;
#[no_mangle]
pub static mut buf: *mut u8_0 = 0 as *const u8_0 as *mut u8_0;
#[no_mangle]
pub static mut buflen: ::core::ffi::c_uchar = 0 as ::core::ffi::c_uchar;
#[no_mangle]
pub unsafe extern "C" fn process_next_block() {
    m = *buf.offset(0 as ::core::ffi::c_int as isize) as u64_0
        | (*buf.offset(1 as ::core::ffi::c_int as isize) as u64_0)
            << 8 as ::core::ffi::c_int
        | (*buf.offset(2 as ::core::ffi::c_int as isize) as u64_0)
            << 16 as ::core::ffi::c_int
        | (*buf.offset(3 as ::core::ffi::c_int as isize) as u64_0)
            << 24 as ::core::ffi::c_int
        | (*buf.offset(4 as ::core::ffi::c_int as isize) as u64_0)
            << 32 as ::core::ffi::c_int
        | (*buf.offset(5 as ::core::ffi::c_int as isize) as u64_0)
            << 40 as ::core::ffi::c_int
        | (*buf.offset(6 as ::core::ffi::c_int as isize) as u64_0)
            << 48 as ::core::ffi::c_int
        | (*buf.offset(7 as ::core::ffi::c_int as isize) as u64_0)
            << 56 as ::core::ffi::c_int;
    v3 ^= m;
    i = 0 as ::core::ffi::c_int;
    while i < cROUNDS {
        v0 = v0.wrapping_add(v1);
        v1 = v1 << 13 as ::core::ffi::c_int
            | v1 >> 64 as ::core::ffi::c_int - 13 as ::core::ffi::c_int;
        v1 ^= v0;
        v0 = v0 << 32 as ::core::ffi::c_int
            | v0 >> 64 as ::core::ffi::c_int - 32 as ::core::ffi::c_int;
        v2 = v2.wrapping_add(v3);
        v3 = v3 << 16 as ::core::ffi::c_int
            | v3 >> 64 as ::core::ffi::c_int - 16 as ::core::ffi::c_int;
        v3 ^= v2;
        v0 = v0.wrapping_add(v3);
        v3 = v3 << 21 as ::core::ffi::c_int
            | v3 >> 64 as ::core::ffi::c_int - 21 as ::core::ffi::c_int;
        v3 ^= v0;
        v2 = v2.wrapping_add(v1);
        v1 = v1 << 17 as ::core::ffi::c_int
            | v1 >> 64 as ::core::ffi::c_int - 17 as ::core::ffi::c_int;
        v1 ^= v2;
        v2 = v2 << 32 as ::core::ffi::c_int
            | v2 >> 64 as ::core::ffi::c_int - 32 as ::core::ffi::c_int;
        i += 1;
    }
    v0 ^= m;
}
#[no_mangle]
pub unsafe extern "C" fn process_final_block() {
    let left: ::core::ffi::c_int = (inlen & 7 as u64_0) as ::core::ffi::c_int;
    if !(left == buflen as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"process_final_block\0")
                .as_ptr(),
            b"siphash.c\0" as *const u8 as *const ::core::ffi::c_char,
            71 as ::core::ffi::c_int,
            b"left == buflen\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut b: u64_0 = inlen << 56 as ::core::ffi::c_int;
    let mut ni: *mut u8_0 = buf;
    let mut current_block_7: u64;
    match left {
        7 => {
            b
                |= (*ni.offset(6 as ::core::ffi::c_int as isize) as u64_0)
                    << 48 as ::core::ffi::c_int;
            current_block_7 = 12130757521475837749;
        }
        6 => {
            current_block_7 = 12130757521475837749;
        }
        5 => {
            current_block_7 = 3195112868688608738;
        }
        4 => {
            current_block_7 = 14539374535960507663;
        }
        3 => {
            current_block_7 = 3496016712527261675;
        }
        2 => {
            current_block_7 = 10861016926129603098;
        }
        1 => {
            current_block_7 = 15916681505374426136;
        }
        0 | _ => {
            current_block_7 = 13109137661213826276;
        }
    }
    match current_block_7 {
        12130757521475837749 => {
            b
                |= (*ni.offset(5 as ::core::ffi::c_int as isize) as u64_0)
                    << 40 as ::core::ffi::c_int;
            current_block_7 = 3195112868688608738;
        }
        _ => {}
    }
    match current_block_7 {
        3195112868688608738 => {
            b
                |= (*ni.offset(4 as ::core::ffi::c_int as isize) as u64_0)
                    << 32 as ::core::ffi::c_int;
            current_block_7 = 14539374535960507663;
        }
        _ => {}
    }
    match current_block_7 {
        14539374535960507663 => {
            b
                |= (*ni.offset(3 as ::core::ffi::c_int as isize) as u64_0)
                    << 24 as ::core::ffi::c_int;
            current_block_7 = 3496016712527261675;
        }
        _ => {}
    }
    match current_block_7 {
        3496016712527261675 => {
            b
                |= (*ni.offset(2 as ::core::ffi::c_int as isize) as u64_0)
                    << 16 as ::core::ffi::c_int;
            current_block_7 = 10861016926129603098;
        }
        _ => {}
    }
    match current_block_7 {
        10861016926129603098 => {
            b
                |= (*ni.offset(1 as ::core::ffi::c_int as isize) as u64_0)
                    << 8 as ::core::ffi::c_int;
            current_block_7 = 15916681505374426136;
        }
        _ => {}
    }
    match current_block_7 {
        15916681505374426136 => {
            b |= *ni.offset(0 as ::core::ffi::c_int as isize) as u64_0;
        }
        _ => {}
    }
    v3 ^= b;
    i = 0 as ::core::ffi::c_int;
    while i < cROUNDS {
        v0 = v0.wrapping_add(v1);
        v1 = v1 << 13 as ::core::ffi::c_int
            | v1 >> 64 as ::core::ffi::c_int - 13 as ::core::ffi::c_int;
        v1 ^= v0;
        v0 = v0 << 32 as ::core::ffi::c_int
            | v0 >> 64 as ::core::ffi::c_int - 32 as ::core::ffi::c_int;
        v2 = v2.wrapping_add(v3);
        v3 = v3 << 16 as ::core::ffi::c_int
            | v3 >> 64 as ::core::ffi::c_int - 16 as ::core::ffi::c_int;
        v3 ^= v2;
        v0 = v0.wrapping_add(v3);
        v3 = v3 << 21 as ::core::ffi::c_int
            | v3 >> 64 as ::core::ffi::c_int - 21 as ::core::ffi::c_int;
        v3 ^= v0;
        v2 = v2.wrapping_add(v1);
        v1 = v1 << 17 as ::core::ffi::c_int
            | v1 >> 64 as ::core::ffi::c_int - 17 as ::core::ffi::c_int;
        v1 ^= v2;
        v2 = v2 << 32 as ::core::ffi::c_int
            | v2 >> 64 as ::core::ffi::c_int - 32 as ::core::ffi::c_int;
        i += 1;
    }
    v0 ^= b;
    if outlen == 16 as ::core::ffi::c_int {
        v2 ^= 0xee as u64_0;
    } else {
        v2 ^= 0xff as u64_0;
    }
    i = 0 as ::core::ffi::c_int;
    while i < dROUNDS {
        v0 = v0.wrapping_add(v1);
        v1 = v1 << 13 as ::core::ffi::c_int
            | v1 >> 64 as ::core::ffi::c_int - 13 as ::core::ffi::c_int;
        v1 ^= v0;
        v0 = v0 << 32 as ::core::ffi::c_int
            | v0 >> 64 as ::core::ffi::c_int - 32 as ::core::ffi::c_int;
        v2 = v2.wrapping_add(v3);
        v3 = v3 << 16 as ::core::ffi::c_int
            | v3 >> 64 as ::core::ffi::c_int - 16 as ::core::ffi::c_int;
        v3 ^= v2;
        v0 = v0.wrapping_add(v3);
        v3 = v3 << 21 as ::core::ffi::c_int
            | v3 >> 64 as ::core::ffi::c_int - 21 as ::core::ffi::c_int;
        v3 ^= v0;
        v2 = v2.wrapping_add(v1);
        v1 = v1 << 17 as ::core::ffi::c_int
            | v1 >> 64 as ::core::ffi::c_int - 17 as ::core::ffi::c_int;
        v1 ^= v2;
        v2 = v2 << 32 as ::core::ffi::c_int
            | v2 >> 64 as ::core::ffi::c_int - 32 as ::core::ffi::c_int;
        i += 1;
    }
    b = v0 ^ v1 ^ v2 ^ v3;
    *out.offset(0 as ::core::ffi::c_int as isize) = b as ::core::ffi::c_uint as u8_0;
    *out.offset(1 as ::core::ffi::c_int as isize) = (b as ::core::ffi::c_uint
        >> 8 as ::core::ffi::c_int) as u8_0;
    *out.offset(2 as ::core::ffi::c_int as isize) = (b as ::core::ffi::c_uint
        >> 16 as ::core::ffi::c_int) as u8_0;
    *out.offset(3 as ::core::ffi::c_int as isize) = (b as ::core::ffi::c_uint
        >> 24 as ::core::ffi::c_int) as u8_0;
    *out
        .offset(4 as ::core::ffi::c_int as isize)
        .offset(0 as ::core::ffi::c_int as isize) = (b >> 32 as ::core::ffi::c_int)
        as ::core::ffi::c_uint as u8_0;
    *out
        .offset(4 as ::core::ffi::c_int as isize)
        .offset(1 as ::core::ffi::c_int as isize) = ((b >> 32 as ::core::ffi::c_int)
        as ::core::ffi::c_uint >> 8 as ::core::ffi::c_int) as u8_0;
    *out
        .offset(4 as ::core::ffi::c_int as isize)
        .offset(2 as ::core::ffi::c_int as isize) = ((b >> 32 as ::core::ffi::c_int)
        as ::core::ffi::c_uint >> 16 as ::core::ffi::c_int) as u8_0;
    *out
        .offset(4 as ::core::ffi::c_int as isize)
        .offset(3 as ::core::ffi::c_int as isize) = ((b >> 32 as ::core::ffi::c_int)
        as ::core::ffi::c_uint >> 24 as ::core::ffi::c_int) as u8_0;
    v1 ^= 0xdd as u64_0;
    i = 0 as ::core::ffi::c_int;
    while i < dROUNDS {
        v0 = v0.wrapping_add(v1);
        v1 = v1 << 13 as ::core::ffi::c_int
            | v1 >> 64 as ::core::ffi::c_int - 13 as ::core::ffi::c_int;
        v1 ^= v0;
        v0 = v0 << 32 as ::core::ffi::c_int
            | v0 >> 64 as ::core::ffi::c_int - 32 as ::core::ffi::c_int;
        v2 = v2.wrapping_add(v3);
        v3 = v3 << 16 as ::core::ffi::c_int
            | v3 >> 64 as ::core::ffi::c_int - 16 as ::core::ffi::c_int;
        v3 ^= v2;
        v0 = v0.wrapping_add(v3);
        v3 = v3 << 21 as ::core::ffi::c_int
            | v3 >> 64 as ::core::ffi::c_int - 21 as ::core::ffi::c_int;
        v3 ^= v0;
        v2 = v2.wrapping_add(v1);
        v1 = v1 << 17 as ::core::ffi::c_int
            | v1 >> 64 as ::core::ffi::c_int - 17 as ::core::ffi::c_int;
        v1 ^= v2;
        v2 = v2 << 32 as ::core::ffi::c_int
            | v2 >> 64 as ::core::ffi::c_int - 32 as ::core::ffi::c_int;
        i += 1;
    }
    b = v0 ^ v1 ^ v2 ^ v3;
    *out
        .offset(8 as ::core::ffi::c_int as isize)
        .offset(0 as ::core::ffi::c_int as isize) = b as ::core::ffi::c_uint as u8_0;
    *out
        .offset(8 as ::core::ffi::c_int as isize)
        .offset(1 as ::core::ffi::c_int as isize) = (b as ::core::ffi::c_uint
        >> 8 as ::core::ffi::c_int) as u8_0;
    *out
        .offset(8 as ::core::ffi::c_int as isize)
        .offset(2 as ::core::ffi::c_int as isize) = (b as ::core::ffi::c_uint
        >> 16 as ::core::ffi::c_int) as u8_0;
    *out
        .offset(8 as ::core::ffi::c_int as isize)
        .offset(3 as ::core::ffi::c_int as isize) = (b as ::core::ffi::c_uint
        >> 24 as ::core::ffi::c_int) as u8_0;
    *out
        .offset(8 as ::core::ffi::c_int as isize)
        .offset(4 as ::core::ffi::c_int as isize)
        .offset(0 as ::core::ffi::c_int as isize) = (b >> 32 as ::core::ffi::c_int)
        as ::core::ffi::c_uint as u8_0;
    *out
        .offset(8 as ::core::ffi::c_int as isize)
        .offset(4 as ::core::ffi::c_int as isize)
        .offset(1 as ::core::ffi::c_int as isize) = ((b >> 32 as ::core::ffi::c_int)
        as ::core::ffi::c_uint >> 8 as ::core::ffi::c_int) as u8_0;
    *out
        .offset(8 as ::core::ffi::c_int as isize)
        .offset(4 as ::core::ffi::c_int as isize)
        .offset(2 as ::core::ffi::c_int as isize) = ((b >> 32 as ::core::ffi::c_int)
        as ::core::ffi::c_uint >> 16 as ::core::ffi::c_int) as u8_0;
    *out
        .offset(8 as ::core::ffi::c_int as isize)
        .offset(4 as ::core::ffi::c_int as isize)
        .offset(3 as ::core::ffi::c_int as isize) = ((b >> 32 as ::core::ffi::c_int)
        as ::core::ffi::c_uint >> 24 as ::core::ffi::c_int) as u8_0;
}
#[no_mangle]
pub unsafe extern "C" fn siphash_init(mut key_128bit: *const ::core::ffi::c_uchar) {
    kk = key_128bit;
    out = trusted_utils_malloc(
        (128 as ::core::ffi::c_int / 8 as ::core::ffi::c_int) as u64_0,
    ) as *mut u8_0;
    buf = trusted_utils_malloc(8 as u64_0) as *mut u8_0;
    if !kk.is_null() {
        siphash_reset();
    }
}
#[no_mangle]
pub unsafe extern "C" fn siphash_reset() {
    v0 = 0x736f6d6570736575 as ::core::ffi::c_ulong as u64_0;
    v1 = 0x646f72616e646f6d as ::core::ffi::c_ulong as u64_0;
    v2 = 0x6c7967656e657261 as ::core::ffi::c_ulong as u64_0;
    v3 = 0x7465646279746573 as ::core::ffi::c_ulong as u64_0;
    k0 = *kk.offset(0 as ::core::ffi::c_int as isize) as u64_0
        | (*kk.offset(1 as ::core::ffi::c_int as isize) as u64_0)
            << 8 as ::core::ffi::c_int
        | (*kk.offset(2 as ::core::ffi::c_int as isize) as u64_0)
            << 16 as ::core::ffi::c_int
        | (*kk.offset(3 as ::core::ffi::c_int as isize) as u64_0)
            << 24 as ::core::ffi::c_int
        | (*kk.offset(4 as ::core::ffi::c_int as isize) as u64_0)
            << 32 as ::core::ffi::c_int
        | (*kk.offset(5 as ::core::ffi::c_int as isize) as u64_0)
            << 40 as ::core::ffi::c_int
        | (*kk.offset(6 as ::core::ffi::c_int as isize) as u64_0)
            << 48 as ::core::ffi::c_int
        | (*kk.offset(7 as ::core::ffi::c_int as isize) as u64_0)
            << 56 as ::core::ffi::c_int;
    k1 = *kk
        .offset(8 as ::core::ffi::c_int as isize)
        .offset(0 as ::core::ffi::c_int as isize) as u64_0
        | (*kk
            .offset(8 as ::core::ffi::c_int as isize)
            .offset(1 as ::core::ffi::c_int as isize) as u64_0)
            << 8 as ::core::ffi::c_int
        | (*kk
            .offset(8 as ::core::ffi::c_int as isize)
            .offset(2 as ::core::ffi::c_int as isize) as u64_0)
            << 16 as ::core::ffi::c_int
        | (*kk
            .offset(8 as ::core::ffi::c_int as isize)
            .offset(3 as ::core::ffi::c_int as isize) as u64_0)
            << 24 as ::core::ffi::c_int
        | (*kk
            .offset(8 as ::core::ffi::c_int as isize)
            .offset(4 as ::core::ffi::c_int as isize) as u64_0)
            << 32 as ::core::ffi::c_int
        | (*kk
            .offset(8 as ::core::ffi::c_int as isize)
            .offset(5 as ::core::ffi::c_int as isize) as u64_0)
            << 40 as ::core::ffi::c_int
        | (*kk
            .offset(8 as ::core::ffi::c_int as isize)
            .offset(6 as ::core::ffi::c_int as isize) as u64_0)
            << 48 as ::core::ffi::c_int
        | (*kk
            .offset(8 as ::core::ffi::c_int as isize)
            .offset(7 as ::core::ffi::c_int as isize) as u64_0)
            << 56 as ::core::ffi::c_int;
    v3 ^= k1;
    v2 ^= k0;
    v1 ^= k1;
    v0 ^= k0;
    inlen = 0 as u64_0;
    buflen = 0 as ::core::ffi::c_uchar;
    if outlen == 16 as ::core::ffi::c_int {
        v1 ^= 0xee as u64_0;
    }
}
#[no_mangle]
pub unsafe extern "C" fn siphash_update(
    mut data: *const ::core::ffi::c_uchar,
    mut nb_bytes: u64_0,
) {
    let mut datapos: u32_0 = 0 as u32_0;
    loop {
        while (buflen as ::core::ffi::c_uint) < 8 as ::core::ffi::c_uint
            && (datapos as u64_0) < nb_bytes
        {
            let fresh0 = datapos;
            datapos = datapos.wrapping_add(1);
            let fresh1 = buflen;
            buflen = buflen.wrapping_add(1);
            *buf.offset(fresh1 as isize) = *data.offset(fresh0 as isize) as u8_0;
        }
        if (buflen as ::core::ffi::c_uint) < 8 as ::core::ffi::c_uint {
            break;
        }
        process_next_block();
        buflen = 0 as ::core::ffi::c_uchar;
    }
    inlen = inlen.wrapping_add(nb_bytes);
}
#[no_mangle]
pub unsafe extern "C" fn siphash_pad(mut nb_bytes: u64_0) {
    let c: ::core::ffi::c_uchar = 0 as ::core::ffi::c_uchar;
    let mut i_0: u64_0 = 0 as u64_0;
    while i_0 < nb_bytes {
        siphash_update(&c, 1 as u64_0);
        i_0 = i_0.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn siphash_digest() -> *mut u8_0 {
    process_final_block();
    return out;
}
#[no_mangle]
pub unsafe extern "C" fn siphash_free() {
    free(buf as *mut ::core::ffi::c_void);
    free(out as *mut ::core::ffi::c_void);
}
