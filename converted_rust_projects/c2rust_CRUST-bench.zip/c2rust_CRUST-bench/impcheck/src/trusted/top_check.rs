#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn snprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    static mut trusted_utils_msgstr: [::core::ffi::c_char; 512];
    fn trusted_utils_copy_bytes(to: *mut u8_0, from: *const u8_0, nb_bytes: u64_0);
    fn trusted_utils_equal_signatures(left: *const u8_0, right: *const u8_0) -> bool;
    fn lrat_check_init(
        nb_vars: ::core::ffi::c_int,
        opt_check_model: bool,
        opt_lenient: bool,
    );
    fn lrat_check_load(lit: ::core::ffi::c_int) -> bool;
    fn lrat_check_end_load(out_sig: *mut *mut u8_0) -> bool;
    fn lrat_check_add_axiomatic_clause(
        id: u64_0,
        lits: *const ::core::ffi::c_int,
        nb_lits: ::core::ffi::c_int,
    ) -> bool;
    fn lrat_check_add_clause(
        id: u64_0,
        lits: *const ::core::ffi::c_int,
        nb_lits: ::core::ffi::c_int,
        hints: *const u64_0,
        nb_hints: ::core::ffi::c_int,
    ) -> bool;
    fn lrat_check_delete_clause(ids: *const u64_0, nb_ids: ::core::ffi::c_int) -> bool;
    fn lrat_check_validate_unsat() -> bool;
    fn lrat_check_validate_sat(model: *mut ::core::ffi::c_int, size: u64_0) -> bool;
    static SECRET_KEY: [::core::ffi::c_uchar; 0];
    fn siphash_init(key_128bit: *const ::core::ffi::c_uchar);
    fn siphash_reset();
    fn siphash_update(data: *const ::core::ffi::c_uchar, nb_bytes: u64_0);
    fn siphash_digest() -> *mut u8_0;
    fn confirm_result(f_sig: *mut u8_0, constant: u8_0, out: *mut u8_0);
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type u64_0 = ::core::ffi::c_ulong;
pub type u8_0 = ::core::ffi::c_uchar;
pub type signature = [u8_0; 16];
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const SIG_SIZE_BYTES: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
#[no_mangle]
pub static mut parsed_formula: bool = false_0 != 0;
#[no_mangle]
pub static mut formula_signature: signature = [0; 16];
#[no_mangle]
pub static mut valid: bool = true_0 != 0;
#[no_mangle]
pub unsafe extern "C" fn compute_clause_signature(
    mut id: u64_0,
    mut lits: *const ::core::ffi::c_int,
    mut nb_lits: ::core::ffi::c_int,
    mut out: *mut u8_0,
) {
    siphash_reset();
    siphash_update(
        &mut id as *mut u64_0 as *mut u8_0,
        ::core::mem::size_of::<u64_0>() as u64_0,
    );
    siphash_update(
        lits as *mut u8_0,
        (nb_lits as u64_0)
            .wrapping_mul(::core::mem::size_of::<::core::ffi::c_int>() as u64_0),
    );
    siphash_update(formula_signature.as_mut_ptr(), SIG_SIZE_BYTES as u64_0);
    let mut hash_out: *const u8_0 = siphash_digest();
    trusted_utils_copy_bytes(out, hash_out, SIG_SIZE_BYTES as u64_0);
}
#[no_mangle]
pub unsafe extern "C" fn top_check_init(
    mut nb_vars: ::core::ffi::c_int,
    mut check_model: bool,
    mut lenient: bool,
) {
    siphash_init(SECRET_KEY.as_ptr());
    lrat_check_init(nb_vars, check_model, lenient);
}
#[no_mangle]
pub unsafe extern "C" fn top_check_commit_formula_sig(mut f_sig: *const u8_0) {
    trusted_utils_copy_bytes(
        formula_signature.as_mut_ptr(),
        f_sig,
        SIG_SIZE_BYTES as u64_0,
    );
}
#[no_mangle]
pub unsafe extern "C" fn top_check_load(mut lit: ::core::ffi::c_int) {
    valid = (valid as ::core::ffi::c_int & lrat_check_load(lit) as ::core::ffi::c_int)
        as bool;
}
#[no_mangle]
pub unsafe extern "C" fn top_check_end_load() -> bool {
    let mut sig_from_chk: *mut u8_0 = 0 as *mut u8_0;
    valid = valid as ::core::ffi::c_int != 0
        && lrat_check_end_load(&mut sig_from_chk) as ::core::ffi::c_int != 0;
    if !valid {
        return false_0 != 0;
    }
    valid = trusted_utils_equal_signatures(sig_from_chk, formula_signature.as_mut_ptr());
    if !valid {
        snprintf(
            trusted_utils_msgstr.as_mut_ptr(),
            512 as size_t,
            b"Formula signature check failed\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    return valid;
}
#[no_mangle]
pub unsafe extern "C" fn top_check_produce(
    mut id: ::core::ffi::c_ulong,
    mut literals: *const ::core::ffi::c_int,
    mut nb_literals: ::core::ffi::c_int,
    mut hints: *const ::core::ffi::c_ulong,
    mut nb_hints: ::core::ffi::c_int,
    mut out_sig_or_null: *mut u8_0,
) -> bool {
    valid = (valid as ::core::ffi::c_int
        & lrat_check_add_clause(
            id as u64_0,
            literals,
            nb_literals,
            hints as *const u64_0,
            nb_hints,
        ) as ::core::ffi::c_int) as bool;
    if !valid {
        return false_0 != 0;
    }
    if !out_sig_or_null.is_null() {
        compute_clause_signature(id as u64_0, literals, nb_literals, out_sig_or_null);
    }
    return true_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn top_check_import(
    mut id: ::core::ffi::c_ulong,
    mut literals: *const ::core::ffi::c_int,
    mut nb_literals: ::core::ffi::c_int,
    mut signature_data: *const u8_0,
) -> bool {
    let mut computed_sig: signature = [0; 16];
    compute_clause_signature(
        id as u64_0,
        literals,
        nb_literals,
        computed_sig.as_mut_ptr(),
    );
    if !trusted_utils_equal_signatures(signature_data, computed_sig.as_mut_ptr()) {
        valid = false_0 != 0;
        snprintf(
            trusted_utils_msgstr.as_mut_ptr(),
            512 as size_t,
            b"Signature check of clause %lu failed\0" as *const u8
                as *const ::core::ffi::c_char,
            id,
        );
        return false_0 != 0;
    }
    valid = (valid as ::core::ffi::c_int
        & lrat_check_add_axiomatic_clause(id as u64_0, literals, nb_literals)
            as ::core::ffi::c_int) as bool;
    return valid;
}
#[no_mangle]
pub unsafe extern "C" fn top_check_delete(
    mut ids: *const ::core::ffi::c_ulong,
    mut nb_ids: ::core::ffi::c_int,
) -> bool {
    return lrat_check_delete_clause(ids as *const u64_0, nb_ids);
}
#[no_mangle]
pub unsafe extern "C" fn top_check_validate_unsat(
    mut out_signature_or_null: *mut u8_0,
) -> bool {
    valid = (valid as ::core::ffi::c_int
        & lrat_check_validate_unsat() as ::core::ffi::c_int) as bool;
    if !valid {
        return false_0 != 0;
    }
    if !out_signature_or_null.is_null() {
        confirm_result(
            formula_signature.as_mut_ptr(),
            20 as u8_0,
            out_signature_or_null,
        );
    }
    return true_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn top_check_validate_sat(
    mut model: *mut ::core::ffi::c_int,
    mut size: u64_0,
    mut out_signature_or_null: *mut u8_0,
) -> bool {
    valid = (valid as ::core::ffi::c_int
        & lrat_check_validate_sat(model, size) as ::core::ffi::c_int) as bool;
    if !valid {
        return false_0 != 0;
    }
    if !out_signature_or_null.is_null() {
        confirm_result(
            formula_signature.as_mut_ptr(),
            10 as u8_0,
            out_signature_or_null,
        );
    }
    return true_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn top_check_valid() -> bool {
    return valid;
}
