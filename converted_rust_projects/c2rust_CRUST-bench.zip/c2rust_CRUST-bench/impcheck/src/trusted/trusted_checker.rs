#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn fflush(_: *mut FILE) -> ::core::ffi::c_int;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn snprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn free(_: *mut ::core::ffi::c_void);
    fn clock() -> clock_t;
    static mut trusted_utils_msgstr: [::core::ffi::c_char; 512];
    fn trusted_utils_log(msg: *const ::core::ffi::c_char);
    fn trusted_utils_log_err(msg: *const ::core::ffi::c_char);
    fn trusted_utils_exit_eof();
    fn trusted_utils_malloc(size: u64_0) -> *mut ::core::ffi::c_void;
    fn trusted_utils_read_bool(file: *mut FILE) -> bool;
    fn trusted_utils_read_char(file: *mut FILE) -> ::core::ffi::c_int;
    fn trusted_utils_read_int(file: *mut FILE) -> ::core::ffi::c_int;
    fn trusted_utils_read_ints(
        data: *mut ::core::ffi::c_int,
        nb_ints: u64_0,
        file: *mut FILE,
    );
    fn trusted_utils_read_ul(file: *mut FILE) -> u64_0;
    fn trusted_utils_read_uls(data: *mut u64_0, nb_uls: u64_0, file: *mut FILE);
    fn trusted_utils_read_sig(out_sig: *mut u8_0, file: *mut FILE);
    fn trusted_utils_write_char(c: ::core::ffi::c_char, file: *mut FILE);
    fn trusted_utils_write_sig(sig: *const u8_0, file: *mut FILE);
    fn top_check_init(nb_vars_0: ::core::ffi::c_int, check_model: bool, lenient: bool);
    fn top_check_commit_formula_sig(f_sig: *const u8_0);
    fn top_check_load(lit: ::core::ffi::c_int);
    fn top_check_end_load() -> bool;
    fn top_check_produce(
        id: ::core::ffi::c_ulong,
        literals: *const ::core::ffi::c_int,
        nb_literals: ::core::ffi::c_int,
        hints: *const ::core::ffi::c_ulong,
        nb_hints: ::core::ffi::c_int,
        out_sig_or_null: *mut u8_0,
    ) -> bool;
    fn top_check_import(
        id: ::core::ffi::c_ulong,
        literals: *const ::core::ffi::c_int,
        nb_literals: ::core::ffi::c_int,
        signature_data: *const u8_0,
    ) -> bool;
    fn top_check_delete(
        ids: *const ::core::ffi::c_ulong,
        nb_ids: ::core::ffi::c_int,
    ) -> bool;
    fn top_check_validate_unsat(out_signature_or_null: *mut u8_0) -> bool;
    fn top_check_validate_sat(
        model: *mut ::core::ffi::c_int,
        size: u64_0,
        out_signature_or_null: *mut u8_0,
    ) -> bool;
    fn top_check_valid() -> bool;
    fn int_vec_init(capacity: u64_0) -> *mut int_vec;
    fn int_vec_reserve(vec: *mut int_vec, new_size: u64_0);
    fn u64_vec_init(capacity: u64_0) -> *mut u64_vec;
    fn u64_vec_reserve(vec: *mut u64_vec, new_size: u64_0);
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_clock_t = ::core::ffi::c_ulong;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type clock_t = __darwin_clock_t;
pub type u64_0 = ::core::ffi::c_ulong;
pub type u8_0 = ::core::ffi::c_uchar;
pub type signature = [u8_0; 16];
#[derive(Copy, Clone)]
#[repr(C)]
pub struct int_vec {
    pub capacity: u64_0,
    pub size: u64_0,
    pub data: *mut ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct u64_vec {
    pub capacity: u64_0,
    pub size: u64_0,
    pub data: *mut u64_0,
}
pub const TRUSTED_CHK_INIT: ::core::ffi::c_int = 'B' as i32;
pub const TRUSTED_CHK_LOAD: ::core::ffi::c_int = 'L' as i32;
pub const TRUSTED_CHK_END_LOAD: ::core::ffi::c_int = 'E' as i32;
pub const TRUSTED_CHK_CLS_PRODUCE: ::core::ffi::c_int = 'a' as i32;
pub const TRUSTED_CHK_CLS_IMPORT: ::core::ffi::c_int = 'i' as i32;
pub const TRUSTED_CHK_CLS_DELETE: ::core::ffi::c_int = 'd' as i32;
pub const TRUSTED_CHK_VALIDATE_UNSAT: ::core::ffi::c_int = 'V' as i32;
pub const TRUSTED_CHK_VALIDATE_SAT: ::core::ffi::c_int = 'M' as i32;
pub const TRUSTED_CHK_TERMINATE: ::core::ffi::c_int = 'T' as i32;
pub const TRUSTED_CHK_RES_ACCEPT: ::core::ffi::c_int = 'A' as i32;
pub const TRUSTED_CHK_RES_ERROR: ::core::ffi::c_int = 'E' as i32;
pub const CLOCKS_PER_SEC: clock_t = 1000000 as ::core::ffi::c_int as clock_t;
#[no_mangle]
pub static mut input: *mut FILE = 0 as *const FILE as *mut FILE;
#[no_mangle]
pub static mut output: *mut FILE = 0 as *const FILE as *mut FILE;
#[no_mangle]
pub static mut nb_vars: ::core::ffi::c_int = 0;
#[no_mangle]
pub static mut formula_sig: signature = [0; 16];
#[no_mangle]
pub static mut do_logging: bool = true_0 != 0;
#[no_mangle]
pub static mut buf_sig: signature = [0; 16];
#[no_mangle]
pub static mut buf_lits: *mut int_vec = 0 as *const int_vec as *mut int_vec;
#[no_mangle]
pub static mut buf_hints: *mut u64_vec = 0 as *const u64_vec as *mut u64_vec;
#[no_mangle]
pub unsafe extern "C" fn say(mut ok: bool) {
    trusted_utils_write_char(
        (if ok as ::core::ffi::c_int != 0 {
            TRUSTED_CHK_RES_ACCEPT
        } else {
            TRUSTED_CHK_RES_ERROR
        }) as ::core::ffi::c_char,
        output,
    );
}
#[no_mangle]
pub unsafe extern "C" fn say_with_flush(mut ok: bool) {
    say(ok);
    fflush(output);
}
#[no_mangle]
pub unsafe extern "C" fn read_literals(mut nb_lits: ::core::ffi::c_int) {
    int_vec_reserve(buf_lits, nb_lits as u64_0);
    trusted_utils_read_ints((*buf_lits).data, nb_lits as u64_0, input);
}
#[no_mangle]
pub unsafe extern "C" fn read_hints(mut nb_hints: ::core::ffi::c_int) {
    u64_vec_reserve(buf_hints, nb_hints as u64_0);
    trusted_utils_read_uls((*buf_hints).data, nb_hints as u64_0, input);
}
#[no_mangle]
pub unsafe extern "C" fn tc_init(
    mut fifo_in: *const ::core::ffi::c_char,
    mut fifo_out: *const ::core::ffi::c_char,
) {
    input = fopen(fifo_in, b"r\0" as *const u8 as *const ::core::ffi::c_char)
        as *mut FILE;
    if input.is_null() {
        trusted_utils_exit_eof();
    }
    output = fopen(fifo_out, b"w\0" as *const u8 as *const ::core::ffi::c_char)
        as *mut FILE;
    if output.is_null() {
        trusted_utils_exit_eof();
    }
    buf_lits = int_vec_init(
        ((1 as ::core::ffi::c_int) << 14 as ::core::ffi::c_int) as u64_0,
    );
    buf_hints = u64_vec_init(
        ((1 as ::core::ffi::c_int) << 14 as ::core::ffi::c_int) as u64_0,
    );
}
#[no_mangle]
pub unsafe extern "C" fn tc_end() {
    free(buf_hints as *mut ::core::ffi::c_void);
    free(buf_lits as *mut ::core::ffi::c_void);
    fclose(output);
    fclose(input);
}
#[no_mangle]
pub unsafe extern "C" fn tc_run(
    mut check_model: bool,
    mut lenient: bool,
) -> ::core::ffi::c_int {
    let mut start: clock_t = clock();
    let mut nb_produced: u64_0 = 0 as u64_0;
    let mut nb_imported: u64_0 = 0 as u64_0;
    let mut nb_deleted: u64_0 = 0 as u64_0;
    let mut reported_error: bool = false_0 != 0;
    loop {
        let mut c: ::core::ffi::c_int = trusted_utils_read_char(input);
        if c == TRUSTED_CHK_CLS_PRODUCE {
            let id: u64_0 = trusted_utils_read_ul(input) as u64_0;
            let nb_lits: ::core::ffi::c_int = trusted_utils_read_int(input)
                as ::core::ffi::c_int;
            read_literals(nb_lits);
            let nb_hints: ::core::ffi::c_int = trusted_utils_read_int(input)
                as ::core::ffi::c_int;
            read_hints(nb_hints);
            let share: bool = trusted_utils_read_bool(input) as bool;
            let mut res: bool = top_check_produce(
                id as ::core::ffi::c_ulong,
                (*buf_lits).data,
                nb_lits,
                (*buf_hints).data,
                nb_hints,
                if share as ::core::ffi::c_int != 0 {
                    buf_sig.as_mut_ptr()
                } else {
                    0 as *mut u8_0
                },
            );
            say(res);
            if share {
                trusted_utils_write_sig(buf_sig.as_mut_ptr(), output);
            }
            nb_produced = nb_produced.wrapping_add(1);
        } else if c == TRUSTED_CHK_CLS_IMPORT {
            let id_0: u64_0 = trusted_utils_read_ul(input) as u64_0;
            let nb_lits_0: ::core::ffi::c_int = trusted_utils_read_int(input)
                as ::core::ffi::c_int;
            read_literals(nb_lits_0);
            trusted_utils_read_sig(buf_sig.as_mut_ptr(), input);
            let mut res_0: bool = top_check_import(
                id_0 as ::core::ffi::c_ulong,
                (*buf_lits).data,
                nb_lits_0,
                buf_sig.as_mut_ptr(),
            );
            say(res_0);
            nb_imported = nb_imported.wrapping_add(1);
        } else if c == TRUSTED_CHK_CLS_DELETE {
            let nb_hints_0: ::core::ffi::c_int = trusted_utils_read_int(input)
                as ::core::ffi::c_int;
            read_hints(nb_hints_0);
            let mut res_1: bool = top_check_delete((*buf_hints).data, nb_hints_0);
            say(res_1);
            nb_deleted = nb_deleted.wrapping_add(nb_hints_0 as u64_0);
        } else if c == TRUSTED_CHK_LOAD {
            let nb_lits_1: ::core::ffi::c_int = trusted_utils_read_int(input)
                as ::core::ffi::c_int;
            read_literals(nb_lits_1);
            let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
            while i < nb_lits_1 {
                top_check_load(*(*buf_lits).data.offset(i as isize));
                i += 1;
            }
        } else if c == TRUSTED_CHK_INIT {
            nb_vars = trusted_utils_read_int(input);
            top_check_init(nb_vars, check_model, lenient);
            trusted_utils_read_sig(formula_sig.as_mut_ptr(), input);
            top_check_commit_formula_sig(formula_sig.as_mut_ptr());
            say_with_flush(true_0 != 0);
        } else if c == TRUSTED_CHK_END_LOAD {
            say_with_flush(top_check_end_load());
        } else if c == TRUSTED_CHK_VALIDATE_UNSAT {
            let mut res_2: bool = top_check_validate_unsat(buf_sig.as_mut_ptr());
            say(res_2);
            trusted_utils_write_sig(buf_sig.as_mut_ptr(), output);
            fflush(output);
            if res_2 {
                trusted_utils_log(
                    b"UNSAT validated\0" as *const u8 as *const ::core::ffi::c_char,
                );
            }
        } else if c == TRUSTED_CHK_VALIDATE_SAT {
            let model_size: ::core::ffi::c_int = trusted_utils_read_int(input)
                as ::core::ffi::c_int;
            let mut model: *mut ::core::ffi::c_int = trusted_utils_malloc(
                (::core::mem::size_of::<::core::ffi::c_int>() as u64_0)
                    .wrapping_mul(model_size as u64_0),
            ) as *mut ::core::ffi::c_int;
            trusted_utils_read_ints(model, model_size as u64_0, input);
            let mut res_3: bool = top_check_validate_sat(
                model,
                model_size as u64_0,
                buf_sig.as_mut_ptr(),
            );
            say(res_3);
            trusted_utils_write_sig(buf_sig.as_mut_ptr(), output);
            fflush(output);
            if res_3 {
                trusted_utils_log(
                    b"SAT validated\0" as *const u8 as *const ::core::ffi::c_char,
                );
            }
            free(model as *mut ::core::ffi::c_void);
        } else if c == TRUSTED_CHK_TERMINATE {
            say_with_flush(true_0 != 0);
            break;
        } else {
            trusted_utils_log_err(
                b"Invalid directive!\0" as *const u8 as *const ::core::ffi::c_char,
            );
            break;
        }
        if !top_check_valid() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
            if !reported_error {
                trusted_utils_log_err(trusted_utils_msgstr.as_mut_ptr());
                reported_error = true_0 != 0;
            }
        }
    }
    let mut elapsed: ::core::ffi::c_float = clock().wrapping_sub(start)
        as ::core::ffi::c_float / CLOCKS_PER_SEC as ::core::ffi::c_float;
    snprintf(
        trusted_utils_msgstr.as_mut_ptr(),
        512 as size_t,
        b"cpu:%.3f prod:%lu imp:%lu del:%lu\0" as *const u8
            as *const ::core::ffi::c_char,
        elapsed as ::core::ffi::c_double,
        nb_produced,
        nb_imported,
        nb_deleted,
    );
    trusted_utils_log(trusted_utils_msgstr.as_mut_ptr());
    return 0 as ::core::ffi::c_int;
}
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
