#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn fgetc(_: *mut FILE) -> ::core::ffi::c_int;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn free(_: *mut ::core::ffi::c_void);
    fn abort() -> !;
    static SECRET_KEY: [::core::ffi::c_uchar; 0];
    fn trusted_utils_write_int(i: ::core::ffi::c_int, file: *mut FILE);
    fn trusted_utils_write_ints(
        data_0: *const ::core::ffi::c_int,
        nb_ints: u64_0,
        file: *mut FILE,
    );
    fn trusted_utils_write_sig(sig: *const u8_0, file: *mut FILE);
    fn siphash_init(key_128bit: *const ::core::ffi::c_uchar);
    fn siphash_update(data_0: *const ::core::ffi::c_uchar, nb_bytes: u64_0);
    fn siphash_pad(nb_bytes: u64_0);
    fn siphash_digest() -> *mut u8_0;
    fn int_vec_init(capacity: u64_0) -> *mut int_vec;
    fn int_vec_push(vec: *mut int_vec, elem: ::core::ffi::c_int);
    fn int_vec_clear(vec: *mut int_vec);
}
pub type __int64_t = i64;
pub type __darwin_off_t = __int64_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type u64_0 = ::core::ffi::c_ulong;
pub type u8_0 = ::core::ffi::c_uchar;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct int_vec {
    pub capacity: u64_0,
    pub size: u64_0,
    pub data: *mut ::core::ffi::c_int,
}
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const EOF: ::core::ffi::c_int = -1;
pub const TRUSTED_CHK_MAX_BUF_SIZE: ::core::ffi::c_int = (1 as ::core::ffi::c_int)
    << 14 as ::core::ffi::c_int;
#[no_mangle]
pub static mut f: *mut FILE = 0 as *const FILE as *mut FILE;
#[no_mangle]
pub static mut f_out: *mut FILE = 0 as *const FILE as *mut FILE;
#[no_mangle]
pub static mut data: *mut int_vec = 0 as *const int_vec as *mut int_vec;
#[no_mangle]
pub static mut comment: bool = false_0 != 0;
#[no_mangle]
pub static mut header: bool = false_0 != 0;
#[no_mangle]
pub static mut input_finished: bool = false_0 != 0;
#[no_mangle]
pub static mut input_invalid: bool = false_0 != 0;
#[no_mangle]
pub static mut began_num: bool = false_0 != 0;
#[no_mangle]
pub static mut num: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
#[no_mangle]
pub static mut sign: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
#[no_mangle]
pub static mut nb_read_cls: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
#[no_mangle]
pub static mut nb_vars: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
#[no_mangle]
pub static mut nb_cls: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
#[no_mangle]
pub unsafe extern "C" fn output_literal_buffer() {
    siphash_update(
        (*data).data as *mut ::core::ffi::c_uchar,
        (*data).size.wrapping_mul(::core::mem::size_of::<::core::ffi::c_int>() as u64_0),
    );
    trusted_utils_write_ints((*data).data, (*data).size, f_out);
    int_vec_clear(data);
}
#[no_mangle]
pub unsafe extern "C" fn append_integer() {
    if header {
        if nb_vars == -(1 as ::core::ffi::c_int) {
            nb_vars = num;
            trusted_utils_write_int(nb_vars, f_out);
        } else if nb_cls == -(1 as ::core::ffi::c_int) {
            nb_cls = num;
            trusted_utils_write_int(nb_cls, f_out);
            header = false_0 != 0;
        } else {
            abort();
        }
        num = 0 as ::core::ffi::c_int;
        began_num = false_0 != 0;
        return;
    }
    let lit: ::core::ffi::c_int = sign * num;
    if lit == 0 as ::core::ffi::c_int {
        nb_read_cls += 1;
    }
    num = 0 as ::core::ffi::c_int;
    sign = 1 as ::core::ffi::c_int;
    began_num = false_0 != 0;
    if (*data).size == (*data).capacity {
        output_literal_buffer();
    }
    int_vec_push(data, lit);
}
#[no_mangle]
pub unsafe extern "C" fn process(mut c: ::core::ffi::c_char) -> bool {
    if comment as ::core::ffi::c_int != 0 && c as ::core::ffi::c_int != '\n' as i32
        && c as ::core::ffi::c_int != '\r' as i32
    {
        return false_0 != 0;
    }
    let mut uc: ::core::ffi::c_schar = *(&mut c as *mut ::core::ffi::c_char
        as *mut ::core::ffi::c_schar);
    match uc as ::core::ffi::c_int {
        EOF => {
            input_finished = true_0 != 0;
            return true_0 != 0;
        }
        10 | 13 => {
            comment = false_0 != 0;
            if began_num {
                append_integer();
            }
        }
        112 => {
            header = true_0 != 0;
        }
        99 => {
            if !header {
                comment = true_0 != 0;
            }
        }
        32 => {
            if began_num {
                append_integer();
            }
        }
        45 => {
            sign = -(1 as ::core::ffi::c_int);
            began_num = true_0 != 0;
        }
        48 | 49 | 50 | 51 | 52 | 53 | 54 | 55 | 56 | 57 => {
            num = num * 10 as ::core::ffi::c_int
                + (c as ::core::ffi::c_int - '0' as i32);
            began_num = true_0 != 0;
        }
        _ => {}
    }
    return false_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn tp_init(
    mut filename: *const ::core::ffi::c_char,
    mut out: *mut FILE,
) {
    siphash_init(SECRET_KEY.as_ptr());
    f = fopen(filename, b"r\0" as *const u8 as *const ::core::ffi::c_char) as *mut FILE;
    f_out = out;
    data = int_vec_init(TRUSTED_CHK_MAX_BUF_SIZE as u64_0);
}
#[no_mangle]
pub unsafe extern "C" fn tp_end() {
    free(data as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn tp_parse(mut sig: *mut *mut u8_0) -> bool {
    loop {
        let mut c_int: ::core::ffi::c_int = fgetc(f);
        if process(c_int as ::core::ffi::c_char) {
            break;
        }
    }
    if began_num {
        append_integer();
    }
    if (*data).size > 0 as u64_0 {
        output_literal_buffer();
    }
    siphash_pad(2 as u64_0);
    *sig = siphash_digest();
    trusted_utils_write_sig(*sig, f_out);
    return input_finished as ::core::ffi::c_int != 0 && !input_invalid;
}
