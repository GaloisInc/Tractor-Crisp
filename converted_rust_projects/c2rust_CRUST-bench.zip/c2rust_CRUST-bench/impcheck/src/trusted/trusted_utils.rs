#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn fgetc(_: *mut FILE) -> ::core::ffi::c_int;
    fn fputc(_: ::core::ffi::c_int, _: *mut FILE) -> ::core::ffi::c_int;
    fn fread(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
        __nitems: size_t,
        __stream: *mut FILE,
    ) -> ::core::ffi::c_ulong;
    fn fwrite(
        __ptr: *const ::core::ffi::c_void,
        __size: size_t,
        __nitems: size_t,
        __stream: *mut FILE,
    ) -> ::core::ffi::c_ulong;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn calloc(__count: size_t, __size: size_t) -> *mut ::core::ffi::c_void;
    fn realloc(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn exit(_: ::core::ffi::c_int) -> !;
    fn getpid() -> pid_t;
}
pub type __int32_t = i32;
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type __darwin_pid_t = __int32_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type u64_0 = ::core::ffi::c_ulong;
pub type u8_0 = ::core::ffi::c_uchar;
pub type signature = [u8_0; 16];
pub type pid_t = __darwin_pid_t;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const EOF: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
pub const SIG_SIZE_BYTES: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
#[no_mangle]
pub static mut trusted_utils_msgstr: [::core::ffi::c_char; 512] = unsafe {
    ::core::mem::transmute::<
        [u8; 512],
        [::core::ffi::c_char; 512],
    >(
        *b"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
    )
};
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_log(mut msg: *const ::core::ffi::c_char) {
    printf(
        b"c [TRUSTED_CORE %i] %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        getpid(),
        msg,
    );
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_log_err(mut msg: *const ::core::ffi::c_char) {
    printf(
        b"c [TRUSTED_CORE %i] [ERROR] %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        getpid(),
        msg,
    );
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_exit_eof() {
    trusted_utils_log(
        b"end-of-file - terminating\0" as *const u8 as *const ::core::ffi::c_char,
    );
    exit(0 as ::core::ffi::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn exit_oom() {
    trusted_utils_log(
        b"allocation failed - terminating\0" as *const u8 as *const ::core::ffi::c_char,
    );
    exit(0 as ::core::ffi::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn begins_with(
    mut str: *const ::core::ffi::c_char,
    mut prefix: *const ::core::ffi::c_char,
) -> bool {
    let mut i: u64_0 = 0 as u64_0;
    loop {
        if *prefix.offset(i as isize) as ::core::ffi::c_int == '\0' as i32 {
            return true_0 != 0;
        }
        if *str.offset(i as isize) as ::core::ffi::c_int == '\0' as i32 {
            return *prefix.offset(i as isize) as ::core::ffi::c_int == '\0' as i32;
        }
        if *str.offset(i as isize) as ::core::ffi::c_int
            != *prefix.offset(i as isize) as ::core::ffi::c_int
        {
            return false_0 != 0;
        }
        i = i.wrapping_add(1);
    };
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_try_match_arg(
    mut arg: *const ::core::ffi::c_char,
    mut opt: *const ::core::ffi::c_char,
    mut out: *mut *const ::core::ffi::c_char,
) {
    if begins_with(arg, opt) {
        *out = arg.offset(strlen(opt) as isize);
    }
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_try_match_flag(
    mut arg: *const ::core::ffi::c_char,
    mut opt: *const ::core::ffi::c_char,
    mut out: *mut bool,
) {
    if begins_with(arg, opt) {
        *out = true_0 != 0;
    }
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_copy_bytes(
    mut to: *mut u8_0,
    mut from: *const u8_0,
    mut nb_bytes: u64_0,
) {
    let mut i: u64_0 = 0 as u64_0;
    while i < nb_bytes {
        *to.offset(i as isize) = *from.offset(i as isize);
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_equal_signatures(
    mut left: *const u8_0,
    mut right: *const u8_0,
) -> bool {
    let mut i: u64_0 = 0 as u64_0;
    while i < SIG_SIZE_BYTES as u64_0 {
        if *left.offset(i as isize) as ::core::ffi::c_int
            != *right.offset(i as isize) as ::core::ffi::c_int
        {
            return false_0 != 0;
        }
        i = i.wrapping_add(1);
    }
    return true_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_malloc(
    mut size: u64_0,
) -> *mut ::core::ffi::c_void {
    let mut res: *mut ::core::ffi::c_void = malloc(size as size_t);
    if res.is_null() {
        exit_oom();
    }
    return res;
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_realloc(
    mut from: *mut ::core::ffi::c_void,
    mut new_size: u64_0,
) -> *mut ::core::ffi::c_void {
    let mut res: *mut ::core::ffi::c_void = realloc(from, new_size as size_t);
    if res.is_null() {
        exit_oom();
    }
    return res;
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_calloc(
    mut nb_objs: u64_0,
    mut size_per_obj: u64_0,
) -> *mut ::core::ffi::c_void {
    let mut res: *mut ::core::ffi::c_void = calloc(
        nb_objs as size_t,
        size_per_obj as size_t,
    );
    if res.is_null() {
        exit_oom();
    }
    return res;
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_read_bool(mut file: *mut FILE) -> bool {
    let mut res: ::core::ffi::c_int = fgetc(file);
    if res == EOF {
        trusted_utils_exit_eof();
    }
    return if res != 0 { 1 as ::core::ffi::c_int } else { 0 as ::core::ffi::c_int } != 0;
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_read_char(
    mut file: *mut FILE,
) -> ::core::ffi::c_int {
    let mut res: ::core::ffi::c_int = fgetc(file);
    if res == EOF {
        trusted_utils_exit_eof();
    }
    return res;
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_read_objs(
    mut data: *mut ::core::ffi::c_void,
    mut size: size_t,
    mut nb_objs: size_t,
    mut file: *mut FILE,
) {
    let mut nb_read: u64_0 = fread(data, size, nb_objs, file) as u64_0;
    if (nb_read as size_t) < nb_objs {
        trusted_utils_exit_eof();
    }
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_read_int(
    mut file: *mut FILE,
) -> ::core::ffi::c_int {
    let mut i: ::core::ffi::c_int = 0;
    trusted_utils_read_objs(
        &mut i as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        1 as size_t,
        file,
    );
    return i;
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_read_ints(
    mut data: *mut ::core::ffi::c_int,
    mut nb_ints: u64_0,
    mut file: *mut FILE,
) {
    trusted_utils_read_objs(
        data as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        nb_ints as size_t,
        file,
    );
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_read_ul(mut file: *mut FILE) -> u64_0 {
    let mut u: u64_0 = 0;
    trusted_utils_read_objs(
        &mut u as *mut u64_0 as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<u64_0>() as size_t,
        1 as size_t,
        file,
    );
    return u;
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_read_uls(
    mut data: *mut u64_0,
    mut nb_uls: u64_0,
    mut file: *mut FILE,
) {
    trusted_utils_read_objs(
        data as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<u64_0>() as size_t,
        nb_uls as size_t,
        file,
    );
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_read_sig(
    mut out_sig: *mut u8_0,
    mut file: *mut FILE,
) {
    let mut dummy: signature = [0; 16];
    if out_sig.is_null() {
        out_sig = dummy.as_mut_ptr();
    }
    trusted_utils_read_objs(
        out_sig as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        4 as size_t,
        file,
    );
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_write_char(
    mut c: ::core::ffi::c_char,
    mut file: *mut FILE,
) {
    let mut res: ::core::ffi::c_int = fputc(c as ::core::ffi::c_int, file);
    if res == EOF {
        trusted_utils_exit_eof();
    }
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_write_bool(mut b: bool, mut file: *mut FILE) {
    let mut res: ::core::ffi::c_int = fputc(
        if b as ::core::ffi::c_int != 0 {
            1 as ::core::ffi::c_int
        } else {
            0 as ::core::ffi::c_int
        },
        file,
    );
    if res == EOF {
        trusted_utils_exit_eof();
    }
}
#[no_mangle]
pub unsafe extern "C" fn write_objs(
    mut data: *const ::core::ffi::c_void,
    mut size: size_t,
    mut nb_objs: size_t,
    mut file: *mut FILE,
) {
    let mut nb_read: u64_0 = fwrite(data, size, nb_objs, file) as u64_0;
    if (nb_read as size_t) < nb_objs {
        trusted_utils_exit_eof();
    }
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_write_int(
    mut i: ::core::ffi::c_int,
    mut file: *mut FILE,
) {
    write_objs(
        &mut i as *mut ::core::ffi::c_int as *const ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        1 as size_t,
        file,
    );
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_write_ints(
    mut data: *const ::core::ffi::c_int,
    mut nb_ints: u64_0,
    mut file: *mut FILE,
) {
    write_objs(
        data as *const ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        nb_ints as size_t,
        file,
    );
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_write_ul(mut u: u64_0, mut file: *mut FILE) {
    write_objs(
        &mut u as *mut u64_0 as *const ::core::ffi::c_void,
        ::core::mem::size_of::<u64_0>() as size_t,
        1 as size_t,
        file,
    );
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_write_uls(
    mut data: *const u64_0,
    mut nb_uls: u64_0,
    mut file: *mut FILE,
) {
    write_objs(
        data as *const ::core::ffi::c_void,
        ::core::mem::size_of::<u64_0>() as size_t,
        nb_uls as size_t,
        file,
    );
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_write_sig(
    mut sig: *const u8_0,
    mut file: *mut FILE,
) {
    write_objs(
        sig as *const ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        4 as size_t,
        file,
    );
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_sig_to_str(
    mut sig: *const u8_0,
    mut out: *mut ::core::ffi::c_char,
) {
    let mut charpos: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while charpos < SIG_SIZE_BYTES {
        let mut val1: ::core::ffi::c_char = (*sig.offset(charpos as isize)
            as ::core::ffi::c_int >> 4 as ::core::ffi::c_int & 0xf as ::core::ffi::c_int)
            as ::core::ffi::c_char;
        let mut val2: ::core::ffi::c_char = (*sig.offset(charpos as isize)
            as ::core::ffi::c_int & 0xf as ::core::ffi::c_int) as ::core::ffi::c_char;
        if !(val1 as ::core::ffi::c_int >= 0 as ::core::ffi::c_int
            && (val1 as ::core::ffi::c_int) < 16 as ::core::ffi::c_int)
            as ::core::ffi::c_int as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 25],
                    [::core::ffi::c_char; 25],
                >(*b"trusted_utils_sig_to_str\0")
                    .as_ptr(),
                b"trusted_utils.c\0" as *const u8 as *const ::core::ffi::c_char,
                161 as ::core::ffi::c_int,
                b"val1 >= 0 && val1 < 16\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        if !(val2 as ::core::ffi::c_int >= 0 as ::core::ffi::c_int
            && (val2 as ::core::ffi::c_int) < 16 as ::core::ffi::c_int)
            as ::core::ffi::c_int as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 25],
                    [::core::ffi::c_char; 25],
                >(*b"trusted_utils_sig_to_str\0")
                    .as_ptr(),
                b"trusted_utils.c\0" as *const u8 as *const ::core::ffi::c_char,
                162 as ::core::ffi::c_int,
                b"val2 >= 0 && val2 < 16\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        *out
            .offset(
                (2 as ::core::ffi::c_int * charpos + 0 as ::core::ffi::c_int) as isize,
            ) = (if val1 as ::core::ffi::c_int >= 10 as ::core::ffi::c_int {
            'a' as i32 + val1 as ::core::ffi::c_int - 10 as ::core::ffi::c_int
        } else {
            '0' as i32 + val1 as ::core::ffi::c_int
        }) as ::core::ffi::c_char;
        *out
            .offset(
                (2 as ::core::ffi::c_int * charpos + 1 as ::core::ffi::c_int) as isize,
            ) = (if val2 as ::core::ffi::c_int >= 10 as ::core::ffi::c_int {
            'a' as i32 + val2 as ::core::ffi::c_int - 10 as ::core::ffi::c_int
        } else {
            '0' as i32 + val2 as ::core::ffi::c_int
        }) as ::core::ffi::c_char;
        charpos += 1;
    }
    *out.offset((SIG_SIZE_BYTES * 2 as ::core::ffi::c_int) as isize) = '\0' as i32
        as ::core::ffi::c_char;
}
#[no_mangle]
pub unsafe extern "C" fn trusted_utils_str_to_sig(
    mut str: *const ::core::ffi::c_char,
    mut out: *mut u8_0,
) -> bool {
    let mut bytepos: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while bytepos < SIG_SIZE_BYTES {
        let mut hex_pair: *const ::core::ffi::c_char = str
            .offset((bytepos * 2 as ::core::ffi::c_int) as isize);
        let mut hex1: ::core::ffi::c_char = *hex_pair
            .offset(0 as ::core::ffi::c_int as isize);
        let mut hex2: ::core::ffi::c_char = *hex_pair
            .offset(1 as ::core::ffi::c_int as isize);
        let mut byte: ::core::ffi::c_int = 16 as ::core::ffi::c_int
            * (if hex1 as ::core::ffi::c_int >= '0' as i32
                && hex1 as ::core::ffi::c_int <= '9' as i32
            {
                hex1 as ::core::ffi::c_int - '0' as i32
            } else {
                10 as ::core::ffi::c_int + hex1 as ::core::ffi::c_int - 'a' as i32
            })
            + (if hex2 as ::core::ffi::c_int >= '0' as i32
                && hex2 as ::core::ffi::c_int <= '9' as i32
            {
                hex2 as ::core::ffi::c_int - '0' as i32
            } else {
                10 as ::core::ffi::c_int + hex2 as ::core::ffi::c_int - 'a' as i32
            });
        if byte < 0 as ::core::ffi::c_int || byte >= 256 as ::core::ffi::c_int {
            return false_0 != 0;
        }
        *out.offset(bytepos as isize) = byte as u8_0;
        bytepos += 1;
    }
    return true_0 != 0;
}
