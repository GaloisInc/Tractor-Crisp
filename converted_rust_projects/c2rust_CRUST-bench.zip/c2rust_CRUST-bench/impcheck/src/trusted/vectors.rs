#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn trusted_utils_malloc(size: u64_0) -> *mut ::core::ffi::c_void;
    fn trusted_utils_realloc(
        from: *mut ::core::ffi::c_void,
        new_size: u64_0,
    ) -> *mut ::core::ffi::c_void;
    fn trusted_utils_calloc(
        nb_objs: u64_0,
        size_per_obj: u64_0,
    ) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
}
pub type u64_0 = ::core::ffi::c_ulong;
pub type u8_0 = ::core::ffi::c_uchar;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct u8_vec {
    pub capacity: u64_0,
    pub size: u64_0,
    pub data: *mut u8_0,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct i8_vec {
    pub capacity: u64_0,
    pub size: u64_0,
    pub data: *mut ::core::ffi::c_schar,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct int_vec {
    pub capacity: u64_0,
    pub size: u64_0,
    pub data: *mut ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct u64_vec {
    pub capacity: u64_0,
    pub size: u64_0,
    pub data: *mut u64_0,
}
#[no_mangle]
pub unsafe extern "C" fn u8_vec_init(mut capacity: u64_0) -> *mut u8_vec {
    let mut vector: *mut u8_vec = trusted_utils_malloc(
        ::core::mem::size_of::<u8_vec>() as u64_0,
    ) as *mut u8_vec;
    (*vector).size = 0 as u64_0;
    (*vector).capacity = capacity;
    (*vector).data = trusted_utils_calloc(
        capacity,
        ::core::mem::size_of::<u8_0>() as u64_0,
    ) as *mut u8_0;
    return vector;
}
#[no_mangle]
pub unsafe extern "C" fn u8_vec_free(mut vec: *mut u8_vec) {
    free((*vec).data as *mut ::core::ffi::c_void);
    (*vec).size = 0 as u64_0;
    (*vec).capacity = 0 as u64_0;
}
#[no_mangle]
pub unsafe extern "C" fn u8_vec_reserve(mut vec: *mut u8_vec, mut new_cap: u64_0) {
    if new_cap > (*vec).capacity {
        (*vec).data = trusted_utils_realloc(
            (*vec).data as *mut ::core::ffi::c_void,
            new_cap.wrapping_mul(::core::mem::size_of::<u8_0>() as u64_0),
        ) as *mut u8_0;
        (*vec).capacity = new_cap;
    }
    if (*vec).size > new_cap {
        (*vec).size = new_cap;
    }
}
#[no_mangle]
pub unsafe extern "C" fn u8_vec_push(mut vec: *mut u8_vec, mut elem: u8_0) {
    if (*vec).size == (*vec).capacity {
        let mut new_cap: u64_0 = ((*vec).capacity as ::core::ffi::c_double * 1.3f64)
            as u64_0;
        if new_cap < (*vec).capacity.wrapping_add(1 as u64_0) {
            new_cap = (*vec).capacity.wrapping_add(1 as u64_0);
        }
        u8_vec_reserve(vec, new_cap);
    }
    let fresh0 = (*vec).size;
    (*vec).size = (*vec).size.wrapping_add(1);
    *(*vec).data.offset(fresh0 as isize) = elem;
}
#[no_mangle]
pub unsafe extern "C" fn u8_vec_clear(mut vec: *mut u8_vec) {
    u8_vec_reserve(vec, 0 as u64_0);
}
#[no_mangle]
pub unsafe extern "C" fn i8_vec_init(mut capacity: u64_0) -> *mut i8_vec {
    let mut vector: *mut i8_vec = trusted_utils_malloc(
        ::core::mem::size_of::<i8_vec>() as u64_0,
    ) as *mut i8_vec;
    (*vector).size = 0 as u64_0;
    (*vector).capacity = capacity;
    (*vector).data = trusted_utils_calloc(
        capacity,
        ::core::mem::size_of::<::core::ffi::c_schar>() as u64_0,
    ) as *mut ::core::ffi::c_schar;
    return vector;
}
#[no_mangle]
pub unsafe extern "C" fn i8_vec_free(mut vec: *mut i8_vec) {
    free((*vec).data as *mut ::core::ffi::c_void);
    (*vec).size = 0 as u64_0;
    (*vec).capacity = 0 as u64_0;
}
#[no_mangle]
pub unsafe extern "C" fn i8_vec_reserve(mut vec: *mut i8_vec, mut new_cap: u64_0) {
    if new_cap > (*vec).capacity {
        (*vec).data = trusted_utils_realloc(
            (*vec).data as *mut ::core::ffi::c_void,
            new_cap.wrapping_mul(::core::mem::size_of::<::core::ffi::c_schar>() as u64_0),
        ) as *mut ::core::ffi::c_schar;
        (*vec).capacity = new_cap;
    }
    if (*vec).size > new_cap {
        (*vec).size = new_cap;
    }
}
#[no_mangle]
pub unsafe extern "C" fn i8_vec_push(
    mut vec: *mut i8_vec,
    mut elem: ::core::ffi::c_schar,
) {
    if (*vec).size == (*vec).capacity {
        let mut new_cap: u64_0 = ((*vec).capacity as ::core::ffi::c_double * 1.3f64)
            as u64_0;
        if new_cap < (*vec).capacity.wrapping_add(1 as u64_0) {
            new_cap = (*vec).capacity.wrapping_add(1 as u64_0);
        }
        i8_vec_reserve(vec, new_cap);
    }
    let fresh1 = (*vec).size;
    (*vec).size = (*vec).size.wrapping_add(1);
    *(*vec).data.offset(fresh1 as isize) = elem;
}
#[no_mangle]
pub unsafe extern "C" fn i8_vec_clear(mut vec: *mut i8_vec) {
    i8_vec_reserve(vec, 0 as u64_0);
}
#[no_mangle]
pub unsafe extern "C" fn int_vec_init(mut capacity: u64_0) -> *mut int_vec {
    let mut vector: *mut int_vec = trusted_utils_malloc(
        ::core::mem::size_of::<int_vec>() as u64_0,
    ) as *mut int_vec;
    (*vector).size = 0 as u64_0;
    (*vector).capacity = capacity;
    (*vector).data = trusted_utils_calloc(
        capacity,
        ::core::mem::size_of::<::core::ffi::c_int>() as u64_0,
    ) as *mut ::core::ffi::c_int;
    return vector;
}
#[no_mangle]
pub unsafe extern "C" fn int_vec_free(mut vec: *mut int_vec) {
    free((*vec).data as *mut ::core::ffi::c_void);
    (*vec).size = 0 as u64_0;
    (*vec).capacity = 0 as u64_0;
}
#[no_mangle]
pub unsafe extern "C" fn int_vec_reserve(mut vec: *mut int_vec, mut new_cap: u64_0) {
    if new_cap > (*vec).capacity {
        (*vec).data = trusted_utils_realloc(
            (*vec).data as *mut ::core::ffi::c_void,
            new_cap.wrapping_mul(::core::mem::size_of::<::core::ffi::c_int>() as u64_0),
        ) as *mut ::core::ffi::c_int;
        (*vec).capacity = new_cap;
    }
    if (*vec).size > new_cap {
        (*vec).size = new_cap;
    }
}
#[no_mangle]
pub unsafe extern "C" fn int_vec_push(
    mut vec: *mut int_vec,
    mut elem: ::core::ffi::c_int,
) {
    if (*vec).size == (*vec).capacity {
        let mut new_cap: u64_0 = ((*vec).capacity as ::core::ffi::c_double * 1.3f64)
            as u64_0;
        if new_cap < (*vec).capacity.wrapping_add(1 as u64_0) {
            new_cap = (*vec).capacity.wrapping_add(1 as u64_0);
        }
        int_vec_reserve(vec, new_cap);
    }
    let fresh2 = (*vec).size;
    (*vec).size = (*vec).size.wrapping_add(1);
    *(*vec).data.offset(fresh2 as isize) = elem;
}
#[no_mangle]
pub unsafe extern "C" fn int_vec_clear(mut vec: *mut int_vec) {
    int_vec_reserve(vec, 0 as u64_0);
}
#[no_mangle]
pub unsafe extern "C" fn u64_vec_init(mut capacity: u64_0) -> *mut u64_vec {
    let mut vector: *mut u64_vec = trusted_utils_malloc(
        ::core::mem::size_of::<u64_vec>() as u64_0,
    ) as *mut u64_vec;
    (*vector).size = 0 as u64_0;
    (*vector).capacity = capacity;
    (*vector).data = trusted_utils_calloc(
        capacity,
        ::core::mem::size_of::<u64_0>() as u64_0,
    ) as *mut u64_0;
    return vector;
}
#[no_mangle]
pub unsafe extern "C" fn u64_vec_free(mut vec: *mut u64_vec) {
    free((*vec).data as *mut ::core::ffi::c_void);
    (*vec).size = 0 as u64_0;
    (*vec).capacity = 0 as u64_0;
}
#[no_mangle]
pub unsafe extern "C" fn u64_vec_reserve(mut vec: *mut u64_vec, mut new_cap: u64_0) {
    if new_cap > (*vec).capacity {
        (*vec).data = trusted_utils_realloc(
            (*vec).data as *mut ::core::ffi::c_void,
            new_cap.wrapping_mul(::core::mem::size_of::<u64_0>() as u64_0),
        ) as *mut u64_0;
        (*vec).capacity = new_cap;
    }
    if (*vec).size > new_cap {
        (*vec).size = new_cap;
    }
}
#[no_mangle]
pub unsafe extern "C" fn u64_vec_push(mut vec: *mut u64_vec, mut elem: u64_0) {
    if (*vec).size == (*vec).capacity {
        let mut new_cap: u64_0 = ((*vec).capacity as ::core::ffi::c_double * 1.3f64)
            as u64_0;
        if new_cap < (*vec).capacity.wrapping_add(1 as u64_0) {
            new_cap = (*vec).capacity.wrapping_add(1 as u64_0);
        }
        u64_vec_reserve(vec, new_cap);
    }
    let fresh3 = (*vec).size;
    (*vec).size = (*vec).size.wrapping_add(1);
    *(*vec).data.offset(fresh3 as isize) = elem;
}
#[no_mangle]
pub unsafe extern "C" fn u64_vec_clear(mut vec: *mut u64_vec) {
    u64_vec_reserve(vec, 0 as u64_0);
}
