#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
}
#[no_mangle]
pub unsafe extern "C" fn do_assert(mut cond: bool) {
    if !cond as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"do_assert\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            9 as ::core::ffi::c_int,
            b"cond\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
