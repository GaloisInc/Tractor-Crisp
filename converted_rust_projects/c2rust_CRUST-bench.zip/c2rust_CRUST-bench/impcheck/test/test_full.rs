#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn fflush(_: *mut FILE) -> ::core::ffi::c_int;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn fread(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
        __nitems: size_t,
        __stream: *mut FILE,
    ) -> ::core::ffi::c_ulong;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn remove(_: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
    fn snprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn wait(_: *mut ::core::ffi::c_int) -> pid_t;
    fn exit(_: ::core::ffi::c_int) -> !;
    fn system(_: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
    fn fork() -> pid_t;
    fn mkfifo(_: *const ::core::ffi::c_char, _: mode_t) -> ::core::ffi::c_int;
    fn do_assert(cond: bool);
    fn trusted_utils_read_char(file: *mut FILE) -> ::core::ffi::c_int;
    fn trusted_utils_read_int(file: *mut FILE) -> ::core::ffi::c_int;
    fn trusted_utils_read_sig(out_sig: *mut u8_0, file: *mut FILE);
    fn trusted_utils_write_bool(b: bool, file: *mut FILE);
    fn trusted_utils_write_char(c: ::core::ffi::c_char, file: *mut FILE);
    fn trusted_utils_write_int(i: ::core::ffi::c_int, file: *mut FILE);
    fn trusted_utils_write_ints(
        data: *const ::core::ffi::c_int,
        nb_ints: u64_0,
        file: *mut FILE,
    );
    fn trusted_utils_write_ul(u: u64_0, file: *mut FILE);
    fn trusted_utils_write_uls(data: *const u64_0, nb_uls: u64_0, file: *mut FILE);
    fn trusted_utils_write_sig(sig: *const u8_0, file: *mut FILE);
    fn trusted_utils_sig_to_str(sig: *const u8_0, out: *mut ::core::ffi::c_char);
    fn int_vec_init(capacity: u64_0) -> *mut int_vec;
    fn int_vec_free(vec: *mut int_vec);
    fn int_vec_push(vec: *mut int_vec, elem: ::core::ffi::c_int);
}
pub type __uint16_t = u16;
pub type __int32_t = i32;
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_mode_t = __uint16_t;
pub type __darwin_off_t = __int64_t;
pub type __darwin_pid_t = __int32_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type pid_t = __darwin_pid_t;
pub type mode_t = __darwin_mode_t;
pub type u64_0 = ::core::ffi::c_ulong;
pub type u8_0 = ::core::ffi::c_uchar;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct int_vec {
    pub capacity: u64_0,
    pub size: u64_0,
    pub data: *mut ::core::ffi::c_int,
}
pub const TRUSTED_CHK_INIT: ::core::ffi::c_int = 'B' as i32;
pub const TRUSTED_CHK_LOAD: ::core::ffi::c_int = 'L' as i32;
pub const TRUSTED_CHK_END_LOAD: ::core::ffi::c_int = 'E' as i32;
pub const TRUSTED_CHK_CLS_PRODUCE: ::core::ffi::c_int = 'a' as i32;
pub const TRUSTED_CHK_CLS_IMPORT: ::core::ffi::c_int = 'i' as i32;
pub const TRUSTED_CHK_CLS_DELETE: ::core::ffi::c_int = 'd' as i32;
pub const TRUSTED_CHK_VALIDATE_UNSAT: ::core::ffi::c_int = 'V' as i32;
pub const TRUSTED_CHK_VALIDATE_SAT: ::core::ffi::c_int = 'M' as i32;
pub const TRUSTED_CHK_TERMINATE: ::core::ffi::c_int = 'T' as i32;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const SIG_SIZE_BYTES: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
#[no_mangle]
pub static mut checker_instance_id: u64_0 = 1 as u64_0;
#[no_mangle]
pub unsafe extern "C" fn do_fork() -> bool {
    let mut child_pid: pid_t = fork();
    do_assert(child_pid >= 0 as pid_t);
    return child_pid == 0 as pid_t;
}
#[no_mangle]
pub unsafe extern "C" fn create_pipe(mut path: *const ::core::ffi::c_char) {
    remove(path);
    let mut res: ::core::ffi::c_int = mkfifo(path, 0o777 as mode_t);
    do_assert(res == 0 as ::core::ffi::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn await_ok(mut out: *mut FILE, mut in_0: *mut FILE) {
    fflush(out);
    let mut ok: bool = trusted_utils_read_char(in_0) != 0;
    do_assert(ok);
}
#[no_mangle]
pub unsafe extern "C" fn setup(
    mut cnfInput: *const ::core::ffi::c_char,
    mut f_directives_out: *mut *mut FILE,
    mut f_feedback_out: *mut *mut FILE,
) -> u64_0 {
    let mut charbuf: [::core::ffi::c_char; 1024] = [0; 1024];
    let mut pipeParsed: [::core::ffi::c_char; 64] = [0; 64];
    let mut pipeDirectives: [::core::ffi::c_char; 64] = [0; 64];
    let mut pipeFeedback: [::core::ffi::c_char; 64] = [0; 64];
    snprintf(
        pipeParsed.as_mut_ptr(),
        64 as size_t,
        b".parsed.%lu.pipe\0" as *const u8 as *const ::core::ffi::c_char,
        checker_instance_id,
    );
    snprintf(
        pipeDirectives.as_mut_ptr(),
        64 as size_t,
        b".directives.%lu.pipe\0" as *const u8 as *const ::core::ffi::c_char,
        checker_instance_id,
    );
    snprintf(
        pipeFeedback.as_mut_ptr(),
        64 as size_t,
        b".feedback.%lu.pipe\0" as *const u8 as *const ::core::ffi::c_char,
        checker_instance_id,
    );
    create_pipe(pipeParsed.as_mut_ptr());
    create_pipe(pipeDirectives.as_mut_ptr());
    create_pipe(pipeFeedback.as_mut_ptr());
    if do_fork() {
        snprintf(
            charbuf.as_mut_ptr(),
            1024 as size_t,
            b"build/impcheck_parse -formula-input=%s -fifo-parsed-formula=%s\0"
                as *const u8 as *const ::core::ffi::c_char,
            cnfInput,
            pipeParsed.as_mut_ptr(),
        );
        let mut res: ::core::ffi::c_int = system(charbuf.as_mut_ptr());
        do_assert(res == 0 as ::core::ffi::c_int);
        exit(0 as ::core::ffi::c_int);
    }
    let mut in_parsed: *mut FILE = fopen(
        pipeParsed.as_mut_ptr(),
        b"r\0" as *const u8 as *const ::core::ffi::c_char,
    ) as *mut FILE;
    let nb_vars: ::core::ffi::c_int = trusted_utils_read_int(in_parsed)
        as ::core::ffi::c_int;
    trusted_utils_read_int(in_parsed);
    let mut fvec: *mut int_vec = int_vec_init(
        ((1 as ::core::ffi::c_int) << 14 as ::core::ffi::c_int) as u64_0,
    );
    loop {
        let mut lit: ::core::ffi::c_int = 0;
        let nb_read: ::core::ffi::c_int = fread(
            &mut lit as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
            ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
            1 as size_t,
            in_parsed,
        ) as ::core::ffi::c_int;
        if nb_read == 0 as ::core::ffi::c_int {
            break;
        }
        int_vec_push(fvec, lit);
    }
    let mut f: *const ::core::ffi::c_int = (*fvec).data;
    let mut fsig: *const u8_0 = ((*fvec).data.offset((*fvec).size as isize) as *mut u8_0)
        .offset(-(SIG_SIZE_BYTES as isize));
    let fsize: u64_0 = (*fvec)
        .size
        .wrapping_sub(
            (SIG_SIZE_BYTES as u64_0)
                .wrapping_div(::core::mem::size_of::<::core::ffi::c_int>() as u64_0),
        );
    wait(0 as *mut ::core::ffi::c_int);
    fclose(in_parsed);
    if do_fork() {
        snprintf(
            charbuf.as_mut_ptr(),
            1024 as size_t,
            b"build/impcheck_check -fifo-directives=%s -fifo-feedback=%s -check-model\0"
                as *const u8 as *const ::core::ffi::c_char,
            pipeDirectives.as_mut_ptr(),
            pipeFeedback.as_mut_ptr(),
        );
        let mut res_0: ::core::ffi::c_int = system(charbuf.as_mut_ptr());
        do_assert(res_0 == 0 as ::core::ffi::c_int);
        exit(0 as ::core::ffi::c_int);
    }
    let mut out_directives: *mut FILE = fopen(
        pipeDirectives.as_mut_ptr(),
        b"w\0" as *const u8 as *const ::core::ffi::c_char,
    ) as *mut FILE;
    let mut in_feedback: *mut FILE = fopen(
        pipeFeedback.as_mut_ptr(),
        b"r\0" as *const u8 as *const ::core::ffi::c_char,
    ) as *mut FILE;
    trusted_utils_write_char(TRUSTED_CHK_INIT as ::core::ffi::c_char, out_directives);
    trusted_utils_write_int(nb_vars, out_directives);
    trusted_utils_write_sig(fsig, out_directives);
    await_ok(out_directives, in_feedback);
    trusted_utils_write_char(TRUSTED_CHK_LOAD as ::core::ffi::c_char, out_directives);
    trusted_utils_write_int(fsize as ::core::ffi::c_int, out_directives);
    trusted_utils_write_ints(f, fsize, out_directives);
    trusted_utils_write_char(
        TRUSTED_CHK_END_LOAD as ::core::ffi::c_char,
        out_directives,
    );
    await_ok(out_directives, in_feedback);
    int_vec_free(fvec);
    *f_directives_out = out_directives;
    *f_feedback_out = in_feedback;
    let fresh0 = checker_instance_id;
    checker_instance_id = checker_instance_id.wrapping_add(1);
    return fresh0;
}
#[no_mangle]
pub unsafe extern "C" fn confirm(
    mut cnfInput: *const ::core::ffi::c_char,
    mut result: ::core::ffi::c_int,
    mut sig: *const u8_0,
) -> bool {
    let mut sigstr: [::core::ffi::c_char; 33] = [0; 33];
    trusted_utils_sig_to_str(sig, sigstr.as_mut_ptr());
    let mut charbuf: [::core::ffi::c_char; 1024] = [0; 1024];
    snprintf(
        charbuf.as_mut_ptr(),
        1024 as size_t,
        b"build/impcheck_confirm -formula-input=%s -result=%i -result-sig=%s\0"
            as *const u8 as *const ::core::ffi::c_char,
        cnfInput,
        result,
        sigstr.as_mut_ptr(),
    );
    let res: ::core::ffi::c_int = system(charbuf.as_mut_ptr()) as ::core::ffi::c_int;
    return res == 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn clean_up(
    mut checker_id: u64_0,
    mut out_directives: *mut FILE,
    mut in_feedback: *mut FILE,
) {
    trusted_utils_write_char(
        TRUSTED_CHK_TERMINATE as ::core::ffi::c_char,
        out_directives,
    );
    await_ok(out_directives, in_feedback);
    fclose(out_directives);
    fclose(in_feedback);
    let mut pipeParsed: [::core::ffi::c_char; 64] = [0; 64];
    let mut pipeDirectives: [::core::ffi::c_char; 64] = [0; 64];
    let mut pipeFeedback: [::core::ffi::c_char; 64] = [0; 64];
    snprintf(
        pipeParsed.as_mut_ptr(),
        64 as size_t,
        b".parsed.%lu.pipe\0" as *const u8 as *const ::core::ffi::c_char,
        checker_id,
    );
    snprintf(
        pipeDirectives.as_mut_ptr(),
        64 as size_t,
        b".directives.%lu.pipe\0" as *const u8 as *const ::core::ffi::c_char,
        checker_id,
    );
    snprintf(
        pipeFeedback.as_mut_ptr(),
        64 as size_t,
        b".feedback.%lu.pipe\0" as *const u8 as *const ::core::ffi::c_char,
        checker_id,
    );
    remove(pipeParsed.as_mut_ptr());
    remove(pipeDirectives.as_mut_ptr());
    remove(pipeFeedback.as_mut_ptr());
    wait(0 as *mut ::core::ffi::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn produce_cls(
    mut out_directives: *mut FILE,
    mut in_feedback: *mut FILE,
    mut id: u64_0,
    mut clslen: ::core::ffi::c_int,
    mut lits: *const ::core::ffi::c_int,
    mut hintlen: ::core::ffi::c_int,
    mut hints: *const u64_0,
    mut sig_or_null: *mut u8_0,
) {
    trusted_utils_write_char(
        TRUSTED_CHK_CLS_PRODUCE as ::core::ffi::c_char,
        out_directives,
    );
    trusted_utils_write_ul(id, out_directives);
    trusted_utils_write_int(clslen, out_directives);
    trusted_utils_write_ints(lits, clslen as u64_0, out_directives);
    trusted_utils_write_int(hintlen, out_directives);
    trusted_utils_write_uls(hints, hintlen as u64_0, out_directives);
    trusted_utils_write_bool(!sig_or_null.is_null(), out_directives);
    await_ok(out_directives, in_feedback);
    if !sig_or_null.is_null() {
        trusted_utils_read_sig(sig_or_null, in_feedback);
    }
}
#[no_mangle]
pub unsafe extern "C" fn import_cls(
    mut out_directives: *mut FILE,
    mut in_feedback: *mut FILE,
    mut id: u64_0,
    mut clslen: ::core::ffi::c_int,
    mut lits: *const ::core::ffi::c_int,
    mut signature: *mut u8_0,
) {
    trusted_utils_write_char(
        TRUSTED_CHK_CLS_IMPORT as ::core::ffi::c_char,
        out_directives,
    );
    trusted_utils_write_ul(id, out_directives);
    trusted_utils_write_int(clslen, out_directives);
    trusted_utils_write_ints(lits, clslen as u64_0, out_directives);
    trusted_utils_write_sig(signature, out_directives);
    await_ok(out_directives, in_feedback);
}
#[no_mangle]
pub unsafe extern "C" fn delete_cls(
    mut out_directives: *mut FILE,
    mut in_feedback: *mut FILE,
    mut ids: *const u64_0,
    mut nb_ids: ::core::ffi::c_int,
) {
    trusted_utils_write_char(
        TRUSTED_CHK_CLS_DELETE as ::core::ffi::c_char,
        out_directives,
    );
    trusted_utils_write_int(nb_ids, out_directives);
    trusted_utils_write_uls(ids, nb_ids as u64_0, out_directives);
    await_ok(out_directives, in_feedback);
}
#[no_mangle]
pub unsafe extern "C" fn test_trivial_sat() {
    printf(
        b"[TEST] --- begin test_trivial_sat() ---\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut cnf: *const ::core::ffi::c_char = b"cnf/trivial-sat.cnf\0" as *const u8
        as *const ::core::ffi::c_char;
    let mut out_directives: *mut FILE = 0 as *mut FILE;
    let mut in_feedback: *mut FILE = 0 as *mut FILE;
    let mut chkid: u64_0 = setup(cnf, &mut out_directives, &mut in_feedback);
    trusted_utils_write_char(
        TRUSTED_CHK_VALIDATE_SAT as ::core::ffi::c_char,
        out_directives,
    );
    trusted_utils_write_int(2 as ::core::ffi::c_int, out_directives);
    let mut model: [::core::ffi::c_int; 2] = [
        1 as ::core::ffi::c_int,
        -(2 as ::core::ffi::c_int),
    ];
    trusted_utils_write_ints(model.as_mut_ptr(), 2 as u64_0, out_directives);
    await_ok(out_directives, in_feedback);
    let mut sat_sig: [u8_0; 16] = [0; 16];
    trusted_utils_read_sig(sat_sig.as_mut_ptr(), in_feedback);
    let mut ok: bool = confirm(cnf, 10 as ::core::ffi::c_int, sat_sig.as_mut_ptr());
    do_assert(ok);
    clean_up(chkid, out_directives, in_feedback);
    printf(
        b"[TEST] ---  end  test_trivial_sat() ---\n\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_trivial_unsat() {
    printf(
        b"[TEST] --- begin test_trivial_unsat() ---\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut cnf: *const ::core::ffi::c_char = b"cnf/trivial-unsat.cnf\0" as *const u8
        as *const ::core::ffi::c_char;
    let mut out_directives: *mut FILE = 0 as *mut FILE;
    let mut in_feedback: *mut FILE = 0 as *mut FILE;
    let mut chkid: u64_0 = setup(cnf, &mut out_directives, &mut in_feedback);
    let cls_5: [::core::ffi::c_int; 1] = [1 as ::core::ffi::c_int];
    let hints_5: [u64_0; 2] = [
        1 as ::core::ffi::c_int as u64_0,
        2 as ::core::ffi::c_int as u64_0,
    ];
    produce_cls(
        out_directives,
        in_feedback,
        5 as u64_0,
        1 as ::core::ffi::c_int,
        cls_5.as_ptr(),
        2 as ::core::ffi::c_int,
        hints_5.as_ptr(),
        0 as *mut u8_0,
    );
    let cls_6: [::core::ffi::c_int; 1] = [-(1 as ::core::ffi::c_int)];
    let hints_6: [u64_0; 2] = [
        3 as ::core::ffi::c_int as u64_0,
        4 as ::core::ffi::c_int as u64_0,
    ];
    produce_cls(
        out_directives,
        in_feedback,
        6 as u64_0,
        1 as ::core::ffi::c_int,
        cls_6.as_ptr(),
        2 as ::core::ffi::c_int,
        hints_6.as_ptr(),
        0 as *mut u8_0,
    );
    let hints_7: [u64_0; 2] = [
        5 as ::core::ffi::c_int as u64_0,
        6 as ::core::ffi::c_int as u64_0,
    ];
    produce_cls(
        out_directives,
        in_feedback,
        7 as u64_0,
        0 as ::core::ffi::c_int,
        0 as *const ::core::ffi::c_int,
        2 as ::core::ffi::c_int,
        hints_7.as_ptr(),
        0 as *mut u8_0,
    );
    trusted_utils_write_char(
        TRUSTED_CHK_VALIDATE_UNSAT as ::core::ffi::c_char,
        out_directives,
    );
    await_ok(out_directives, in_feedback);
    let mut unsat_sig: [u8_0; 16] = [0; 16];
    trusted_utils_read_sig(unsat_sig.as_mut_ptr(), in_feedback);
    let mut ok: bool = confirm(cnf, 20 as ::core::ffi::c_int, unsat_sig.as_mut_ptr());
    do_assert(ok);
    clean_up(chkid, out_directives, in_feedback);
    printf(
        b"[TEST] ---  end  test_trivial_unsat() ---\n\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_trivial_unsat_x2() {
    printf(
        b"[TEST] --- begin test_trivial_unsat_x2() ---\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut cnf: *const ::core::ffi::c_char = b"cnf/trivial-unsat.cnf\0" as *const u8
        as *const ::core::ffi::c_char;
    let mut out_directives_1: *mut FILE = 0 as *mut FILE;
    let mut in_feedback_1: *mut FILE = 0 as *mut FILE;
    let mut chkid_1: u64_0 = setup(cnf, &mut out_directives_1, &mut in_feedback_1);
    let mut out_directives_2: *mut FILE = 0 as *mut FILE;
    let mut in_feedback_2: *mut FILE = 0 as *mut FILE;
    let mut chkid_2: u64_0 = setup(cnf, &mut out_directives_2, &mut in_feedback_2);
    let cls_5: [::core::ffi::c_int; 1] = [1 as ::core::ffi::c_int];
    let hints_5: [u64_0; 2] = [
        1 as ::core::ffi::c_int as u64_0,
        2 as ::core::ffi::c_int as u64_0,
    ];
    let mut sig_5: [u8_0; 16] = [0; 16];
    produce_cls(
        out_directives_1,
        in_feedback_1,
        5 as u64_0,
        1 as ::core::ffi::c_int,
        cls_5.as_ptr(),
        2 as ::core::ffi::c_int,
        hints_5.as_ptr(),
        sig_5.as_mut_ptr(),
    );
    let cls_6: [::core::ffi::c_int; 1] = [-(1 as ::core::ffi::c_int)];
    let hints_6: [u64_0; 2] = [
        3 as ::core::ffi::c_int as u64_0,
        4 as ::core::ffi::c_int as u64_0,
    ];
    let mut sig_6: [u8_0; 16] = [0; 16];
    produce_cls(
        out_directives_2,
        in_feedback_2,
        6 as u64_0,
        1 as ::core::ffi::c_int,
        cls_6.as_ptr(),
        2 as ::core::ffi::c_int,
        hints_6.as_ptr(),
        sig_6.as_mut_ptr(),
    );
    let del_ids: [u64_0; 4] = [
        3 as ::core::ffi::c_int as u64_0,
        4 as ::core::ffi::c_int as u64_0,
        0,
        0,
    ];
    delete_cls(
        out_directives_2,
        in_feedback_2,
        del_ids.as_ptr(),
        2 as ::core::ffi::c_int,
    );
    import_cls(
        out_directives_1,
        in_feedback_1,
        6 as u64_0,
        1 as ::core::ffi::c_int,
        cls_6.as_ptr(),
        sig_6.as_mut_ptr(),
    );
    import_cls(
        out_directives_2,
        in_feedback_2,
        5 as u64_0,
        1 as ::core::ffi::c_int,
        cls_5.as_ptr(),
        sig_5.as_mut_ptr(),
    );
    let hints_7: [u64_0; 2] = [
        5 as ::core::ffi::c_int as u64_0,
        6 as ::core::ffi::c_int as u64_0,
    ];
    produce_cls(
        out_directives_1,
        in_feedback_1,
        7 as u64_0,
        0 as ::core::ffi::c_int,
        0 as *const ::core::ffi::c_int,
        2 as ::core::ffi::c_int,
        hints_7.as_ptr(),
        0 as *mut u8_0,
    );
    trusted_utils_write_char(
        TRUSTED_CHK_VALIDATE_UNSAT as ::core::ffi::c_char,
        out_directives_1,
    );
    await_ok(out_directives_1, in_feedback_1);
    let mut unsat_sig: [u8_0; 16] = [0; 16];
    trusted_utils_read_sig(unsat_sig.as_mut_ptr(), in_feedback_1);
    let mut ok: bool = confirm(cnf, 20 as ::core::ffi::c_int, unsat_sig.as_mut_ptr());
    do_assert(ok);
    clean_up(chkid_1, out_directives_1, in_feedback_1);
    clean_up(chkid_2, out_directives_2, in_feedback_2);
    printf(
        b"[TEST] ---  end  test_trivial_unsat_x2() ---\n\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
}
unsafe fn main_0() -> ::core::ffi::c_int {
    test_trivial_sat();
    test_trivial_unsat();
    test_trivial_unsat_x2();
    return 0;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
