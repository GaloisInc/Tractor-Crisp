#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn do_assert(cond: bool);
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn hash_table_init(log_init_capacity: ::core::ffi::c_int) -> *mut hash_table;
    fn hash_table_find(ht: *mut hash_table, key: u64_0) -> *mut ::core::ffi::c_void;
    fn hash_table_insert(
        ht: *mut hash_table,
        key: u64_0,
        data: *mut ::core::ffi::c_void,
    ) -> bool;
    fn hash_table_delete(ht: *mut hash_table, key: u64_0) -> bool;
    fn hash_table_delete_last_found(ht: *mut hash_table) -> bool;
    fn hash_table_free(ht: *mut hash_table);
}
pub type u64_0 = ::core::ffi::c_ulong;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct hash_table_entry {
    pub key: u64_0,
    pub val: *mut ::core::ffi::c_void,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct hash_table {
    pub size: u64_0,
    pub max_size: u64_0,
    pub growth_factor: ::core::ffi::c_float,
    pub capacity: u64_0,
    pub data: *mut hash_table_entry,
    pub last_found_idx: u64_0,
}
#[no_mangle]
pub unsafe extern "C" fn test_small() {
    printf(
        b"[TEST] --- begin test_small() ---\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut ht: *mut hash_table = hash_table_init(7 as ::core::ffi::c_int);
    do_assert((*ht).size == 0 as u64_0);
    do_assert(
        (*ht).capacity == ((1 as ::core::ffi::c_int) << 7 as ::core::ffi::c_int) as u64_0,
    );
    let mut ok: bool = false;
    let mut arr: [::core::ffi::c_int; 128] = [0; 128];
    let mut cap: u64_0 = (*ht).capacity;
    let mut i: u64_0 = 1 as u64_0;
    while i <= 63 as u64_0 {
        ok = hash_table_insert(
            ht,
            i,
            arr.as_mut_ptr().offset(i as isize) as *mut ::core::ffi::c_void,
        );
        do_assert(ok);
        do_assert((*ht).size == i);
        do_assert((*ht).capacity == cap);
        do_assert(
            hash_table_find(ht, i)
                == arr.as_mut_ptr().offset(i as isize) as *mut ::core::ffi::c_void,
        );
        i = i.wrapping_add(1);
    }
    do_assert((*ht).size == 63 as u64_0);
    do_assert((*ht).capacity == 128 as u64_0);
    let mut i_0: u64_0 = 1 as u64_0;
    while i_0 <= 63 as u64_0 {
        do_assert(
            hash_table_find(ht, i_0)
                == arr.as_mut_ptr().offset(i_0 as isize) as *mut ::core::ffi::c_void,
        );
        i_0 = i_0.wrapping_add(1);
    }
    ok = hash_table_insert(
        ht,
        64 as u64_0,
        arr.as_mut_ptr().offset(64 as ::core::ffi::c_int as isize)
            as *mut ::core::ffi::c_void,
    );
    do_assert(ok);
    do_assert((*ht).size == 64 as u64_0);
    do_assert((*ht).capacity == 128 as u64_0);
    ok = hash_table_insert(
        ht,
        65 as u64_0,
        arr.as_mut_ptr().offset(65 as ::core::ffi::c_int as isize)
            as *mut ::core::ffi::c_void,
    );
    do_assert(ok);
    do_assert((*ht).size == 65 as u64_0);
    do_assert((*ht).capacity == 256 as u64_0);
    let mut i_1: u64_0 = 1 as u64_0;
    while i_1 <= 65 as u64_0 {
        if !(i_1 == 40 as u64_0) {
            do_assert(
                hash_table_find(ht, i_1)
                    == arr.as_mut_ptr().offset(i_1 as isize) as *mut ::core::ffi::c_void,
            );
            do_assert(hash_table_delete(ht, i_1));
            do_assert(hash_table_find(ht, i_1).is_null());
        }
        i_1 = i_1.wrapping_add(1);
    }
    do_assert((*ht).size == 1 as u64_0);
    do_assert(
        hash_table_find(ht, 40 as u64_0)
            == arr.as_mut_ptr().offset(40 as ::core::ffi::c_int as isize)
                as *mut ::core::ffi::c_void,
    );
    do_assert(hash_table_delete_last_found(ht));
    do_assert((*ht).size == 0 as u64_0);
    do_assert(hash_table_find(ht, 40 as u64_0).is_null());
    hash_table_free(ht);
    printf(
        b"[TEST] ---  end  test_small() ---\n\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_big() {
    printf(
        b"[TEST] --- begin test_big() ---\n\0" as *const u8 as *const ::core::ffi::c_char,
    );
    let mut ht: *mut hash_table = hash_table_init(7 as ::core::ffi::c_int);
    do_assert((*ht).size == 0 as u64_0);
    let mut ok: bool = false;
    let mut obj: ::core::ffi::c_int = 0;
    let mut nb_elems: u64_0 = (((1 as ::core::ffi::c_int) << 20 as ::core::ffi::c_int)
        + 3 as ::core::ffi::c_int) as u64_0;
    let mut i: u64_0 = 1 as u64_0;
    while i <= nb_elems {
        do_assert(hash_table_find(ht, i).is_null());
        ok = hash_table_insert(
            ht,
            i,
            (&mut obj as *mut ::core::ffi::c_int).offset(i as isize)
                as *mut ::core::ffi::c_void,
        );
        do_assert(ok);
        let mut val: *mut ::core::ffi::c_void = hash_table_find(ht, i);
        do_assert(!val.is_null());
        do_assert(
            val
                == (&mut obj as *mut ::core::ffi::c_int).offset(i as isize)
                    as *mut ::core::ffi::c_void,
        );
        i = i.wrapping_add(1);
    }
    do_assert((*ht).size == nb_elems);
    let mut i_0: u64_0 = 1 as u64_0;
    while i_0 <= nb_elems {
        do_assert((*ht).size == nb_elems.wrapping_sub(i_0).wrapping_add(1 as u64_0));
        let mut val_0: *mut ::core::ffi::c_void = hash_table_find(ht, i_0);
        do_assert(!val_0.is_null());
        do_assert(
            val_0
                == (&mut obj as *mut ::core::ffi::c_int).offset(i_0 as isize)
                    as *mut ::core::ffi::c_void,
        );
        let mut ok_0: bool = hash_table_delete_last_found(ht);
        do_assert(ok_0);
        do_assert(hash_table_find(ht, i_0).is_null());
        i_0 = i_0.wrapping_add(1);
    }
    do_assert((*ht).size == 0 as u64_0);
    hash_table_free(ht);
    printf(
        b"[TEST] ---  end  test_big() ---\n\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_alternate() {
    printf(
        b"[TEST] --- begin test_alternate() ---\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut ht: *mut hash_table = hash_table_init(7 as ::core::ffi::c_int);
    do_assert((*ht).size == 0 as u64_0);
    let mut ok: bool = false;
    let mut obj: ::core::ffi::c_int = 0;
    let block_size: ::core::ffi::c_int = 256 as ::core::ffi::c_int;
    let nb_iterations: ::core::ffi::c_int = 9999 as ::core::ffi::c_int;
    let mut counter: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    let mut outer: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while outer < nb_iterations {
        let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while i < block_size {
            do_assert(hash_table_find(ht, counter as u64_0).is_null());
            ok = hash_table_insert(
                ht,
                counter as u64_0,
                (&mut obj as *mut ::core::ffi::c_int).offset(counter as isize)
                    as *mut ::core::ffi::c_void,
            );
            do_assert(ok);
            let mut val: *mut ::core::ffi::c_void = hash_table_find(
                ht,
                counter as u64_0,
            );
            do_assert(!val.is_null());
            do_assert(
                val
                    == (&mut obj as *mut ::core::ffi::c_int).offset(counter as isize)
                        as *mut ::core::ffi::c_void,
            );
            counter += 1;
            i += 1;
        }
        let mut delcounter: ::core::ffi::c_int = counter - block_size;
        while delcounter < counter {
            let mut val_0: *mut ::core::ffi::c_void = hash_table_find(
                ht,
                delcounter as u64_0,
            );
            do_assert(!val_0.is_null());
            do_assert(
                val_0
                    == (&mut obj as *mut ::core::ffi::c_int).offset(delcounter as isize)
                        as *mut ::core::ffi::c_void,
            );
            ok = hash_table_delete_last_found(ht);
            do_assert(ok);
            do_assert(hash_table_find(ht, delcounter as u64_0).is_null());
            delcounter += 2 as ::core::ffi::c_int;
        }
        outer += 1;
    }
    printf(
        b"size=%lu counter=%i\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*ht).size,
        counter,
    );
    let mut i_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    while i_0 <= counter {
        if i_0 % 2 as ::core::ffi::c_int == 1 as ::core::ffi::c_int {
            do_assert(hash_table_find(ht, i_0 as u64_0).is_null());
        } else {
            let mut val_1: *mut ::core::ffi::c_void = hash_table_find(ht, i_0 as u64_0);
            do_assert(!val_1.is_null());
            do_assert(
                val_1
                    == (&mut obj as *mut ::core::ffi::c_int).offset(i_0 as isize)
                        as *mut ::core::ffi::c_void,
            );
        }
        i_0 += 1;
    }
    do_assert((*ht).size as ::core::ffi::c_int == counter / 2 as ::core::ffi::c_int);
    printf(
        b"[TEST] ---  end  test_alternate() ---\n\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
}
unsafe fn main_0() -> ::core::ffi::c_int {
    test_small();
    test_big();
    test_alternate();
    return 0;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
