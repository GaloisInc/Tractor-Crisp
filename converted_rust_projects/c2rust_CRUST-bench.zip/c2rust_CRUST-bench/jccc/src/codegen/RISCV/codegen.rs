#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
pub type uint32_t = u32;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct RGenState {
    pub registers_in_use: uint32_t,
    pub sp_offset: ::core::ffi::c_uint,
}
#[no_mangle]
pub static mut RGEN_STATE: RGenState = RGenState {
    registers_in_use: 0,
    sp_offset: 0,
};
#[no_mangle]
pub unsafe extern "C" fn r_code_gen_init() {
    RGEN_STATE.registers_in_use = 0 as uint32_t;
    RGEN_STATE.sp_offset = 0 as ::core::ffi::c_uint;
}
#[no_mangle]
pub unsafe extern "C" fn r_start_main() -> *mut ::core::ffi::c_char {
    static mut start: [::core::ffi::c_char; 256] = unsafe {
        ::core::mem::transmute::<
            [u8; 256],
            [::core::ffi::c_char; 256],
        >(
            *b".global _start\n_start:\n\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
        )
    };
    return start.as_mut_ptr();
}
