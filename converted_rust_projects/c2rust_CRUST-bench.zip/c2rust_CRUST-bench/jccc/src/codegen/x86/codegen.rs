#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn sprintf(
        _: *mut ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn testing_single_test_internal(func_name: *const ::core::ffi::c_char);
}
pub type uint32_t = u32;
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type TokenType = ::core::ffi::c_uint;
pub const TT_WHILE: TokenType = 84;
pub const TT_VOLATILE: TokenType = 83;
pub const TT_VOID: TokenType = 82;
pub const TT_UNION: TokenType = 81;
pub const TT_UNSIGNED: TokenType = 80;
pub const TT_TYPEDEF: TokenType = 79;
pub const TT_SIZEOF: TokenType = 78;
pub const TT_STRUCT: TokenType = 77;
pub const TT_SIGNED: TokenType = 76;
pub const TT_SHORT: TokenType = 75;
pub const TT_SWITCH: TokenType = 74;
pub const TT_STATIC: TokenType = 73;
pub const TT_REGISTER: TokenType = 72;
pub const TT_RETURN: TokenType = 71;
pub const TT_LONG: TokenType = 70;
pub const TT_INT: TokenType = 69;
pub const TT_IF: TokenType = 68;
pub const TT_GOTO: TokenType = 67;
pub const TT_FOR: TokenType = 66;
pub const TT_FLOAT: TokenType = 65;
pub const TT_EXTERN: TokenType = 64;
pub const TT_ELSE: TokenType = 63;
pub const TT_ENUM: TokenType = 62;
pub const TT_DEFAULT: TokenType = 61;
pub const TT_DO: TokenType = 60;
pub const TT_DOUBLE: TokenType = 59;
pub const TT_CONTINUE: TokenType = 58;
pub const TT_CASE: TokenType = 57;
pub const TT_CONST: TokenType = 56;
pub const TT_CHAR: TokenType = 55;
pub const TT_BREAK: TokenType = 54;
pub const TT_AUTO: TokenType = 53;
pub const TT_RIGHTSHIFTEQUALS: TokenType = 52;
pub const TT_LEFTSHIFTEQUALS: TokenType = 51;
pub const TT_POINT: TokenType = 50;
pub const TT_XOREQ: TokenType = 49;
pub const TT_XOR: TokenType = 48;
pub const TT_NOTEQ: TokenType = 47;
pub const TT_EQUALS: TokenType = 46;
pub const TT_BNOT: TokenType = 45;
pub const TT_LNOT: TokenType = 44;
pub const TT_RIGHTSHIFT: TokenType = 43;
pub const TT_LEFTSHIFT: TokenType = 42;
pub const TT_GREATEREQ: TokenType = 41;
pub const TT_LESSEQ: TokenType = 40;
pub const TT_LESS: TokenType = 39;
pub const TT_GREATER: TokenType = 38;
pub const TT_LOREQ: TokenType = 37;
pub const TT_LANDEQ: TokenType = 36;
pub const TT_BOREQ: TokenType = 35;
pub const TT_BANDEQ: TokenType = 34;
pub const TT_MODEQ: TokenType = 33;
pub const TT_MULEQ: TokenType = 32;
pub const TT_DIVEQ: TokenType = 31;
pub const TT_MINUSMINUS: TokenType = 30;
pub const TT_PLUSPLUS: TokenType = 29;
pub const TT_INC: TokenType = 28;
pub const TT_DEC: TokenType = 27;
pub const TT_LOR: TokenType = 26;
pub const TT_BOR: TokenType = 25;
pub const TT_LAND: TokenType = 24;
pub const TT_BAND: TokenType = 23;
pub const TT_MOD: TokenType = 22;
pub const TT_COLON: TokenType = 21;
pub const TT_ASSIGN: TokenType = 20;
pub const TT_SLASH: TokenType = 19;
pub const TT_STAR: TokenType = 18;
pub const TT_PLUS: TokenType = 17;
pub const TT_MINUS: TokenType = 16;
pub const TT_QMARK: TokenType = 15;
pub const TT_COMMA: TokenType = 14;
pub const TT_PERIOD: TokenType = 13;
pub const TT_POUND: TokenType = 12;
pub const TT_NEWLINE: TokenType = 11;
pub const TT_EOF: TokenType = 10;
pub const TT_NO_TOKEN: TokenType = 9;
pub const TT_SEMI: TokenType = 8;
pub const TT_CBRACKET: TokenType = 7;
pub const TT_OBRACKET: TokenType = 6;
pub const TT_CBRACE: TokenType = 5;
pub const TT_OBRACE: TokenType = 4;
pub const TT_CPAREN: TokenType = 3;
pub const TT_OPAREN: TokenType = 2;
pub const TT_IDENTIFIER: TokenType = 1;
pub const TT_LITERAL: TokenType = 0;
pub type Op = ::core::ffi::c_uint;
pub const OP_NOP: Op = 3;
pub const OP_MOV: Op = 2;
pub const OP_SUB: Op = 1;
pub const OP_ADD: Op = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct GenState {
    pub registers_in_use: uint32_t,
    pub rsp_offset: ::core::ffi::c_uint,
}
#[no_mangle]
pub static mut GEN_STATE: GenState = GenState {
    registers_in_use: 0,
    rsp_offset: 0,
};
#[no_mangle]
pub unsafe extern "C" fn code_gen_init() {
    GEN_STATE.registers_in_use = 0 as uint32_t;
    GEN_STATE.rsp_offset = 0 as ::core::ffi::c_uint;
}
#[no_mangle]
pub unsafe extern "C" fn ttype_to_op(mut t: TokenType) -> Op {
    match t as ::core::ffi::c_uint {
        17 => return OP_ADD,
        16 => return OP_SUB,
        _ => return OP_NOP,
    };
}
#[no_mangle]
pub unsafe extern "C" fn start_main() -> *mut ::core::ffi::c_char {
    static mut start: [::core::ffi::c_char; 256] = unsafe {
        ::core::mem::transmute::<
            [u8; 256],
            [::core::ffi::c_char; 256],
        >(
            *b"global _start\nsection .text\n\n_start:\n\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
        )
    };
    return start.as_mut_ptr();
}
#[no_mangle]
pub unsafe extern "C" fn end_main() -> *mut ::core::ffi::c_char {
    static mut end: [::core::ffi::c_char; 256] = unsafe {
        ::core::mem::transmute::<
            [u8; 256],
            [::core::ffi::c_char; 256],
        >(
            *b"\tmov rax, 60\tmov rdi, 0\tsyscall\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
        )
    };
    return end.as_mut_ptr();
}
#[no_mangle]
pub unsafe extern "C" fn end_main_custom_return(
    mut val: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_char {
    let mut end: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    end = malloc(
        (256 as size_t)
            .wrapping_mul(::core::mem::size_of::<::core::ffi::c_char>() as size_t),
    ) as *mut ::core::ffi::c_char;
    sprintf(
        end,
        b"\tmov rax, 60\n\tmov rdi, %d\n\tsyscall\n\0" as *const u8
            as *const ::core::ffi::c_char,
        val,
    );
    return end;
}
static mut op_strs: [*mut ::core::ffi::c_char; 4] = [
    b"add\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"sub\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"mov\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    0 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
];
#[no_mangle]
pub unsafe extern "C" fn op_on_rax_with_rdi(mut op: Op) -> *mut ::core::ffi::c_char {
    let mut end: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    end = malloc(
        (256 as size_t)
            .wrapping_mul(::core::mem::size_of::<::core::ffi::c_char>() as size_t),
    ) as *mut ::core::ffi::c_char;
    let mut op_str: *mut ::core::ffi::c_char = op_strs[op as usize];
    sprintf(
        end,
        b"\t%s rax, rdi\n\0" as *const u8 as *const ::core::ffi::c_char,
        op_str,
    );
    return end;
}
#[no_mangle]
pub unsafe extern "C" fn start_func() -> *mut ::core::ffi::c_char {
    static mut start: [::core::ffi::c_char; 256] = unsafe {
        ::core::mem::transmute::<
            [u8; 256],
            [::core::ffi::c_char; 256],
        >(
            *b"\tsub rsp, 32\tmov [rsp], r12\tmov [rsp+8], r13\tmov [rsp+16], r14\tmov [rsp+24], r15\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
        )
    };
    return start.as_mut_ptr();
}
#[no_mangle]
pub unsafe extern "C" fn end_func() -> *mut ::core::ffi::c_char {
    static mut end: [::core::ffi::c_char; 256] = unsafe {
        ::core::mem::transmute::<
            [u8; 256],
            [::core::ffi::c_char; 256],
        >(
            *b"\tmov r12, [rsp]\tmov r13, [rsp+8]\tmov r14, [rsp+16]\tmov r15, [rsp+24]\tadd rsp, 32\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
        )
    };
    return end.as_mut_ptr();
}
#[no_mangle]
pub unsafe extern "C" fn init_int_literal(
    mut val: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_char {
    GEN_STATE.rsp_offset = GEN_STATE.rsp_offset.wrapping_add(8 as ::core::ffi::c_uint);
    let mut init: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    init = malloc(
        (256 as size_t)
            .wrapping_mul(::core::mem::size_of::<::core::ffi::c_char>() as size_t),
    ) as *mut ::core::ffi::c_char;
    sprintf(
        init,
        b"\tmov [rsp+%d], %d\0" as *const u8 as *const ::core::ffi::c_char,
        GEN_STATE.rsp_offset,
        val,
    );
    return init;
}
#[no_mangle]
pub unsafe extern "C" fn test_init_int_literal() -> ::core::ffi::c_int {
    testing_single_test_internal(
        ::core::mem::transmute::<
            [u8; 22],
            [::core::ffi::c_char; 22],
        >(*b"test_init_int_literal\0")
            .as_ptr(),
    );
    code_gen_init();
    if strcmp(
        init_int_literal(100 as ::core::ffi::c_int),
        b"\tmov [rsp+8], 100\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/codegen/x86/codegen.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            110 as ::core::ffi::c_int,
            b"strcmp(init_int_literal(100), \"\tmov [rsp+8], 100\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_op_on_rax_with_rdi() -> ::core::ffi::c_int {
    testing_single_test_internal(
        ::core::mem::transmute::<
            [u8; 24],
            [::core::ffi::c_char; 24],
        >(*b"test_op_on_rax_with_rdi\0")
            .as_ptr(),
    );
    let mut out: *mut ::core::ffi::c_char = op_on_rax_with_rdi(OP_ADD);
    if strcmp(out, b"\tadd rax, rdi\n\0" as *const u8 as *const ::core::ffi::c_char)
        == 0 as ::core::ffi::c_int
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/codegen/x86/codegen.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            119 as ::core::ffi::c_int,
            b"strcmp(out, \"\tadd rax, rdi\\n\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    let mut out2: *mut ::core::ffi::c_char = op_on_rax_with_rdi(OP_MOV);
    if strcmp(out2, b"\tmov rax, rdi\n\0" as *const u8 as *const ::core::ffi::c_char)
        == 0 as ::core::ffi::c_int
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/codegen/x86/codegen.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            122 as ::core::ffi::c_int,
            b"strcmp(out2, \"\tmov rax, rdi\\n\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    return 0 as ::core::ffi::c_int;
}
