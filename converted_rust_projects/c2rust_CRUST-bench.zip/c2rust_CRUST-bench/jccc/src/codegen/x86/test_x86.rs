#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn testing_setup_internal(func_name: *const ::core::ffi::c_char);
    fn testing_cleanup_internal(func_name: *const ::core::ffi::c_char);
    fn test_init_int_literal() -> ::core::ffi::c_int;
    fn test_op_on_rax_with_rdi() -> ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_x86() -> ::core::ffi::c_int {
    testing_setup_internal(
        ::core::mem::transmute::<[u8; 9], [::core::ffi::c_char; 9]>(*b"test_x86\0")
            .as_ptr(),
    );
    test_init_int_literal();
    test_op_on_rax_with_rdi();
    testing_cleanup_internal(
        ::core::mem::transmute::<[u8; 9], [::core::ffi::c_char; 9]>(*b"test_x86\0")
            .as_ptr(),
    );
    return 0 as ::core::ffi::c_int;
}
