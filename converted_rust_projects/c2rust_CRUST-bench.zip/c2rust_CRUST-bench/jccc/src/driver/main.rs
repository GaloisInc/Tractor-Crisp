#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn lex(l: *mut Lexer, token: *mut Token) -> ::core::ffi::c_int;
    fn ttype_name(tt: TokenType) -> *const ::core::ffi::c_char;
    fn parse(filename: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
}
pub type __int64_t = i64;
pub type __darwin_off_t = __int64_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type TokenType = ::core::ffi::c_uint;
pub const TT_WHILE: TokenType = 84;
pub const TT_VOLATILE: TokenType = 83;
pub const TT_VOID: TokenType = 82;
pub const TT_UNION: TokenType = 81;
pub const TT_UNSIGNED: TokenType = 80;
pub const TT_TYPEDEF: TokenType = 79;
pub const TT_SIZEOF: TokenType = 78;
pub const TT_STRUCT: TokenType = 77;
pub const TT_SIGNED: TokenType = 76;
pub const TT_SHORT: TokenType = 75;
pub const TT_SWITCH: TokenType = 74;
pub const TT_STATIC: TokenType = 73;
pub const TT_REGISTER: TokenType = 72;
pub const TT_RETURN: TokenType = 71;
pub const TT_LONG: TokenType = 70;
pub const TT_INT: TokenType = 69;
pub const TT_IF: TokenType = 68;
pub const TT_GOTO: TokenType = 67;
pub const TT_FOR: TokenType = 66;
pub const TT_FLOAT: TokenType = 65;
pub const TT_EXTERN: TokenType = 64;
pub const TT_ELSE: TokenType = 63;
pub const TT_ENUM: TokenType = 62;
pub const TT_DEFAULT: TokenType = 61;
pub const TT_DO: TokenType = 60;
pub const TT_DOUBLE: TokenType = 59;
pub const TT_CONTINUE: TokenType = 58;
pub const TT_CASE: TokenType = 57;
pub const TT_CONST: TokenType = 56;
pub const TT_CHAR: TokenType = 55;
pub const TT_BREAK: TokenType = 54;
pub const TT_AUTO: TokenType = 53;
pub const TT_RIGHTSHIFTEQUALS: TokenType = 52;
pub const TT_LEFTSHIFTEQUALS: TokenType = 51;
pub const TT_POINT: TokenType = 50;
pub const TT_XOREQ: TokenType = 49;
pub const TT_XOR: TokenType = 48;
pub const TT_NOTEQ: TokenType = 47;
pub const TT_EQUALS: TokenType = 46;
pub const TT_BNOT: TokenType = 45;
pub const TT_LNOT: TokenType = 44;
pub const TT_RIGHTSHIFT: TokenType = 43;
pub const TT_LEFTSHIFT: TokenType = 42;
pub const TT_GREATEREQ: TokenType = 41;
pub const TT_LESSEQ: TokenType = 40;
pub const TT_LESS: TokenType = 39;
pub const TT_GREATER: TokenType = 38;
pub const TT_LOREQ: TokenType = 37;
pub const TT_LANDEQ: TokenType = 36;
pub const TT_BOREQ: TokenType = 35;
pub const TT_BANDEQ: TokenType = 34;
pub const TT_MODEQ: TokenType = 33;
pub const TT_MULEQ: TokenType = 32;
pub const TT_DIVEQ: TokenType = 31;
pub const TT_MINUSMINUS: TokenType = 30;
pub const TT_PLUSPLUS: TokenType = 29;
pub const TT_INC: TokenType = 28;
pub const TT_DEC: TokenType = 27;
pub const TT_LOR: TokenType = 26;
pub const TT_BOR: TokenType = 25;
pub const TT_LAND: TokenType = 24;
pub const TT_BAND: TokenType = 23;
pub const TT_MOD: TokenType = 22;
pub const TT_COLON: TokenType = 21;
pub const TT_ASSIGN: TokenType = 20;
pub const TT_SLASH: TokenType = 19;
pub const TT_STAR: TokenType = 18;
pub const TT_PLUS: TokenType = 17;
pub const TT_MINUS: TokenType = 16;
pub const TT_QMARK: TokenType = 15;
pub const TT_COMMA: TokenType = 14;
pub const TT_PERIOD: TokenType = 13;
pub const TT_POUND: TokenType = 12;
pub const TT_NEWLINE: TokenType = 11;
pub const TT_EOF: TokenType = 10;
pub const TT_NO_TOKEN: TokenType = 9;
pub const TT_SEMI: TokenType = 8;
pub const TT_CBRACKET: TokenType = 7;
pub const TT_OBRACKET: TokenType = 6;
pub const TT_CBRACE: TokenType = 5;
pub const TT_OBRACE: TokenType = 4;
pub const TT_CPAREN: TokenType = 3;
pub const TT_OPAREN: TokenType = 2;
pub const TT_IDENTIFIER: TokenType = 1;
pub const TT_LITERAL: TokenType = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Token {
    pub type_0: TokenType,
    pub contents: [::core::ffi::c_char; 256],
    pub length: ::core::ffi::c_uint,
    pub source_file: [::core::ffi::c_char; 256],
    pub line: ::core::ffi::c_int,
    pub column: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Lexer {
    pub fp: *mut FILE,
    pub current_file: [::core::ffi::c_char; 256],
    pub buffer: [::core::ffi::c_char; 1],
    pub position: ::core::ffi::c_long,
    pub last_column: ::core::ffi::c_int,
    pub column: ::core::ffi::c_int,
    pub line: ::core::ffi::c_int,
    pub unlexed: [Token; 5],
    pub unlexed_count: ::core::ffi::c_uint,
}
#[no_mangle]
pub unsafe extern "C" fn lexer_dump(
    mut filename: *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut lexer: Lexer = Lexer {
        fp: 0 as *mut FILE,
        current_file: [0; 256],
        buffer: [0; 1],
        position: 0,
        last_column: 0,
        column: 0,
        line: 0,
        unlexed: [Token {
            type_0: TT_LITERAL,
            contents: [0; 256],
            length: 0,
            source_file: [0; 256],
            line: 0,
            column: 0,
        }; 5],
        unlexed_count: 0,
    };
    let mut fp: *mut FILE = fopen(
        filename,
        b"r\0" as *const u8 as *const ::core::ffi::c_char,
    ) as *mut FILE;
    if fp.is_null() {
        fprintf(
            __stderrp,
            b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
            31 as ::core::ffi::c_int,
        );
        fprintf(
            __stderrp,
            b"Error: jccc: File %s not found\n\0" as *const u8
                as *const ::core::ffi::c_char,
            filename,
        );
        fprintf(__stderrp, b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
        return 1 as ::core::ffi::c_int;
    }
    lexer.fp = fp;
    lexer.unlexed_count = 0 as ::core::ffi::c_uint;
    lexer.line = 1 as ::core::ffi::c_int;
    lexer.column = lexer.line;
    let mut t: Token = Token {
        type_0: TT_LITERAL,
        contents: [0; 256],
        length: 0,
        source_file: [0; 256],
        line: 0,
        column: 0,
    };
    loop {
        if lex(&mut lexer, &mut t) != 0 {
            return 1 as ::core::ffi::c_int;
        }
        printf(
            b"Contents: %20s, type: %20s, position: %d/%d\n\0" as *const u8
                as *const ::core::ffi::c_char,
            t.contents.as_mut_ptr(),
            ttype_name(t.type_0),
            t.line,
            t.column,
        );
        if !(t.type_0 as ::core::ffi::c_uint
            != TT_EOF as ::core::ffi::c_int as ::core::ffi::c_uint)
        {
            break;
        }
    }
    fclose(fp);
    return 0 as ::core::ffi::c_int;
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    argc -= 1;
    argv = argv.offset(1);
    if argc == 0 as ::core::ffi::c_int {
        fprintf(
            __stderrp,
            b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
            37 as ::core::ffi::c_int,
        );
        fprintf(
            __stderrp,
            b"jccc: Usage: --token-dump <filename> to see all tokens\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        fprintf(__stderrp, b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
        return 0 as ::core::ffi::c_int;
    }
    if argc == 1 as ::core::ffi::c_int {
        fprintf(
            __stderrp,
            b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
            37 as ::core::ffi::c_int,
        );
        fprintf(
            __stderrp,
            b"jccc: default compilation not supported yet -- try 'jccc --token-dump %s' instead.\n\0"
                as *const u8 as *const ::core::ffi::c_char,
            *argv.offset(0 as ::core::ffi::c_int as isize),
        );
        fprintf(__stderrp, b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
        return 1 as ::core::ffi::c_int;
    }
    if argc > 2 as ::core::ffi::c_int {
        fprintf(
            __stderrp,
            b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
            37 as ::core::ffi::c_int,
        );
        fprintf(
            __stderrp,
            b"jccc: expected only two arguments!\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        fprintf(__stderrp, b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
        return 1 as ::core::ffi::c_int;
    }
    if strcmp(
        *argv.offset(0 as ::core::ffi::c_int as isize),
        b"--token-dump\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
    {
        return lexer_dump(*argv.offset(1 as ::core::ffi::c_int as isize))
    } else if strcmp(
        *argv.offset(0 as ::core::ffi::c_int as isize),
        b"--test-parse\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
    {
        parse(*argv.offset(1 as ::core::ffi::c_int as isize));
        return 0 as ::core::ffi::c_int;
    }
    fprintf(
        __stderrp,
        b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
        31 as ::core::ffi::c_int,
    );
    fprintf(
        __stderrp,
        b"Error: jccc: option %s not recognized.\n\0" as *const u8
            as *const ::core::ffi::c_char,
        *argv.offset(1 as ::core::ffi::c_int as isize),
    );
    fprintf(__stderrp, b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
    return 1 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
