#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types, linkage)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn getc(_: *mut FILE) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn ungetc(_: ::core::ffi::c_int, _: *mut FILE) -> ::core::ffi::c_int;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn testing_single_test_internal(func_name: *const ::core::ffi::c_char);
    static mut _DefaultRuneLocale: _RuneLocale;
    fn __maskrune(_: __darwin_ct_rune_t, _: ::core::ffi::c_ulong) -> ::core::ffi::c_int;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strcpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
}
pub type __uint32_t = u32;
pub type __int64_t = i64;
pub type __darwin_ct_rune_t = ::core::ffi::c_int;
pub type __darwin_size_t = usize;
pub type __darwin_wchar_t = ::libc::wchar_t;
pub type __darwin_rune_t = __darwin_wchar_t;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type TokenType = ::core::ffi::c_uint;
pub const TT_WHILE: TokenType = 84;
pub const TT_VOLATILE: TokenType = 83;
pub const TT_VOID: TokenType = 82;
pub const TT_UNION: TokenType = 81;
pub const TT_UNSIGNED: TokenType = 80;
pub const TT_TYPEDEF: TokenType = 79;
pub const TT_SIZEOF: TokenType = 78;
pub const TT_STRUCT: TokenType = 77;
pub const TT_SIGNED: TokenType = 76;
pub const TT_SHORT: TokenType = 75;
pub const TT_SWITCH: TokenType = 74;
pub const TT_STATIC: TokenType = 73;
pub const TT_REGISTER: TokenType = 72;
pub const TT_RETURN: TokenType = 71;
pub const TT_LONG: TokenType = 70;
pub const TT_INT: TokenType = 69;
pub const TT_IF: TokenType = 68;
pub const TT_GOTO: TokenType = 67;
pub const TT_FOR: TokenType = 66;
pub const TT_FLOAT: TokenType = 65;
pub const TT_EXTERN: TokenType = 64;
pub const TT_ELSE: TokenType = 63;
pub const TT_ENUM: TokenType = 62;
pub const TT_DEFAULT: TokenType = 61;
pub const TT_DO: TokenType = 60;
pub const TT_DOUBLE: TokenType = 59;
pub const TT_CONTINUE: TokenType = 58;
pub const TT_CASE: TokenType = 57;
pub const TT_CONST: TokenType = 56;
pub const TT_CHAR: TokenType = 55;
pub const TT_BREAK: TokenType = 54;
pub const TT_AUTO: TokenType = 53;
pub const TT_RIGHTSHIFTEQUALS: TokenType = 52;
pub const TT_LEFTSHIFTEQUALS: TokenType = 51;
pub const TT_POINT: TokenType = 50;
pub const TT_XOREQ: TokenType = 49;
pub const TT_XOR: TokenType = 48;
pub const TT_NOTEQ: TokenType = 47;
pub const TT_EQUALS: TokenType = 46;
pub const TT_BNOT: TokenType = 45;
pub const TT_LNOT: TokenType = 44;
pub const TT_RIGHTSHIFT: TokenType = 43;
pub const TT_LEFTSHIFT: TokenType = 42;
pub const TT_GREATEREQ: TokenType = 41;
pub const TT_LESSEQ: TokenType = 40;
pub const TT_LESS: TokenType = 39;
pub const TT_GREATER: TokenType = 38;
pub const TT_LOREQ: TokenType = 37;
pub const TT_LANDEQ: TokenType = 36;
pub const TT_BOREQ: TokenType = 35;
pub const TT_BANDEQ: TokenType = 34;
pub const TT_MODEQ: TokenType = 33;
pub const TT_MULEQ: TokenType = 32;
pub const TT_DIVEQ: TokenType = 31;
pub const TT_MINUSMINUS: TokenType = 30;
pub const TT_PLUSPLUS: TokenType = 29;
pub const TT_INC: TokenType = 28;
pub const TT_DEC: TokenType = 27;
pub const TT_LOR: TokenType = 26;
pub const TT_BOR: TokenType = 25;
pub const TT_LAND: TokenType = 24;
pub const TT_BAND: TokenType = 23;
pub const TT_MOD: TokenType = 22;
pub const TT_COLON: TokenType = 21;
pub const TT_ASSIGN: TokenType = 20;
pub const TT_SLASH: TokenType = 19;
pub const TT_STAR: TokenType = 18;
pub const TT_PLUS: TokenType = 17;
pub const TT_MINUS: TokenType = 16;
pub const TT_QMARK: TokenType = 15;
pub const TT_COMMA: TokenType = 14;
pub const TT_PERIOD: TokenType = 13;
pub const TT_POUND: TokenType = 12;
pub const TT_NEWLINE: TokenType = 11;
pub const TT_EOF: TokenType = 10;
pub const TT_NO_TOKEN: TokenType = 9;
pub const TT_SEMI: TokenType = 8;
pub const TT_CBRACKET: TokenType = 7;
pub const TT_OBRACKET: TokenType = 6;
pub const TT_CBRACE: TokenType = 5;
pub const TT_OBRACE: TokenType = 4;
pub const TT_CPAREN: TokenType = 3;
pub const TT_OPAREN: TokenType = 2;
pub const TT_IDENTIFIER: TokenType = 1;
pub const TT_LITERAL: TokenType = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Token {
    pub type_0: TokenType,
    pub contents: [::core::ffi::c_char; 256],
    pub length: ::core::ffi::c_uint,
    pub source_file: [::core::ffi::c_char; 256],
    pub line: ::core::ffi::c_int,
    pub column: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Lexer {
    pub fp: *mut FILE,
    pub current_file: [::core::ffi::c_char; 256],
    pub buffer: [::core::ffi::c_char; 1],
    pub position: ::core::ffi::c_long,
    pub last_column: ::core::ffi::c_int,
    pub column: ::core::ffi::c_int,
    pub line: ::core::ffi::c_int,
    pub unlexed: [Token; 5],
    pub unlexed_count: ::core::ffi::c_uint,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneLocale {
    pub __magic: [::core::ffi::c_char; 8],
    pub __encoding: [::core::ffi::c_char; 32],
    pub __sgetrune: Option<
        unsafe extern "C" fn(
            *const ::core::ffi::c_char,
            __darwin_size_t,
            *mut *const ::core::ffi::c_char,
        ) -> __darwin_rune_t,
    >,
    pub __sputrune: Option<
        unsafe extern "C" fn(
            __darwin_rune_t,
            *mut ::core::ffi::c_char,
            __darwin_size_t,
            *mut *mut ::core::ffi::c_char,
        ) -> ::core::ffi::c_int,
    >,
    pub __invalid_rune: __darwin_rune_t,
    pub __runetype: [__uint32_t; 256],
    pub __maplower: [__darwin_rune_t; 256],
    pub __mapupper: [__darwin_rune_t; 256],
    pub __runetype_ext: _RuneRange,
    pub __maplower_ext: _RuneRange,
    pub __mapupper_ext: _RuneRange,
    pub __variable: *mut ::core::ffi::c_void,
    pub __variable_len: ::core::ffi::c_int,
    pub __ncharclasses: ::core::ffi::c_int,
    pub __charclasses: *mut _RuneCharClass,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneCharClass {
    pub __name: [::core::ffi::c_char; 14],
    pub __mask: __uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneRange {
    pub __nranges: ::core::ffi::c_int,
    pub __ranges: *mut _RuneEntry,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneEntry {
    pub __min: __darwin_rune_t,
    pub __max: __darwin_rune_t,
    pub __map: __darwin_rune_t,
    pub __types: *mut __uint32_t,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const EOF: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
pub const TOKEN_LENGTH: ::core::ffi::c_int = 256 as ::core::ffi::c_int;
pub const TOKEN_PUTBACKS: ::core::ffi::c_int = 5 as ::core::ffi::c_int;
pub const _CACHED_RUNES: ::core::ffi::c_int = (1 as ::core::ffi::c_int)
    << 8 as ::core::ffi::c_int;
pub const _CTYPE_A: ::core::ffi::c_long = 0x100 as ::core::ffi::c_long;
pub const _CTYPE_D: ::core::ffi::c_long = 0x400 as ::core::ffi::c_long;
#[inline]
unsafe extern "C" fn isascii(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return (_c & !(0x7f as ::core::ffi::c_int) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn __istype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> ::core::ffi::c_int {
    return if isascii(_c as ::core::ffi::c_int) != 0 {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    } else {
        (__maskrune(_c, _f) != 0) as ::core::ffi::c_int
    };
}
#[inline]
unsafe extern "C" fn __isctype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> __darwin_ct_rune_t {
    return if _c < 0 as ::core::ffi::c_int || _c >= _CACHED_RUNES {
        0 as __darwin_ct_rune_t
    } else {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    };
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isalnum(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(
        _c as __darwin_ct_rune_t,
        (_CTYPE_A | _CTYPE_D) as ::core::ffi::c_ulong,
    );
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isdigit(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __isctype(_c as __darwin_ct_rune_t, _CTYPE_D as ::core::ffi::c_ulong)
        as ::core::ffi::c_int;
}
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn in_string(
    mut c: ::core::ffi::c_char,
    mut s: *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut d: *mut ::core::ffi::c_char = s as *mut ::core::ffi::c_char;
    while *d != 0 {
        if *d as ::core::ffi::c_int == c as ::core::ffi::c_int {
            return 1 as ::core::ffi::c_int;
        }
        d = d.offset(1);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub static mut single_char_tokens: [::core::ffi::c_char; 15] = unsafe {
    ::core::mem::transmute::<[u8; 15], [::core::ffi::c_char; 15]>(*b"(){}[];~#,.:?~\0")
};
#[no_mangle]
pub static mut operator_strings: [*mut ::core::ffi::c_char; 37] = [
    b"-\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"+\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"*\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"/\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"=\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b":\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"%\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"&\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"&&\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"|\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"||\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"-=\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"+=\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"++\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"--\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"/=\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"*=\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"%=\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"&=\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"|=\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"&&=\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"||=\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b">\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"<\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"<=\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b">=\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"<<\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b">>\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"!\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"==\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"!=\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"^\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"^=\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"->\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b"<<=\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    b">>=\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    0 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
];
#[no_mangle]
pub unsafe extern "C" fn starts_operator(
    mut c: ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    match c as ::core::ffi::c_int {
        45 | 43 | 42 | 47 | 61 | 58 | 37 | 38 | 124 | 60 | 62 | 33 | 126 | 94 => {
            return 1 as ::core::ffi::c_int;
        }
        _ => return 0 as ::core::ffi::c_int,
    };
}
#[no_mangle]
pub unsafe extern "C" fn valid_operator_sequence(
    mut op: *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut top: *mut *mut ::core::ffi::c_char = operator_strings.as_mut_ptr();
    while !(*top).is_null() {
        if strcmp(*top, op) == 0 {
            return 1 as ::core::ffi::c_int;
        }
        top = top.offset(1);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn is_valid_numeric_or_id_char(
    mut c: ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    return (isalnum(c as ::core::ffi::c_int) != 0
        || c as ::core::ffi::c_int == '_' as i32
        || c as ::core::ffi::c_int == '.' as i32) as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn lexer_getchar(mut l: *mut Lexer) -> ::core::ffi::c_int {
    (*l).position += 1;
    (*l).last_column = (*l).column;
    (*l).buffer[0 as ::core::ffi::c_int as usize] = getc((*l).fp) as ::core::ffi::c_char;
    if (*l).buffer[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_int == '\n' as i32
    {
        (*l).line += 1;
        (*l).column = 0 as ::core::ffi::c_int;
    } else {
        (*l).column += 1;
    }
    return (*l).buffer[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn lexer_ungetchar(mut l: *mut Lexer) -> ::core::ffi::c_int {
    if !((*l).position >= 0 as ::core::ffi::c_long) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"lexer_ungetchar\0")
                .as_ptr(),
            b"lex.c\0" as *const u8 as *const ::core::ffi::c_char,
            103 as ::core::ffi::c_int,
            b"l->position >= 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    (*l).position -= 1;
    (*l).column = (*l).last_column;
    if (*l).buffer[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_int == '\n' as i32
    {
        (*l).line -= 1;
    }
    ungetc((*l).buffer[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_int, (*l).fp);
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn lex(
    mut l: *mut Lexer,
    mut t: *mut Token,
) -> ::core::ffi::c_int {
    loop {
        real_lex(l, t);
        if (*t).type_0 as ::core::ffi::c_uint
            != TT_NEWLINE as ::core::ffi::c_int as ::core::ffi::c_uint
        {
            break;
        }
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn real_lex(
    mut l: *mut Lexer,
    mut t: *mut Token,
) -> ::core::ffi::c_int {
    if (*l).unlexed_count > 0 as ::core::ffi::c_uint {
        (*l).unlexed_count = (*l).unlexed_count.wrapping_sub(1);
        memcpy(
            t as *mut ::core::ffi::c_void,
            &mut *(*l).unlexed.as_mut_ptr().offset((*l).unlexed_count as isize)
                as *mut Token as *const ::core::ffi::c_void,
            ::core::mem::size_of::<Token>() as size_t,
        );
        return 0 as ::core::ffi::c_int;
    }
    skip_to_token(l);
    let mut init: ::core::ffi::c_int = lexer_getchar(l);
    memset(
        (*t).contents.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        TOKEN_LENGTH as size_t,
    );
    memcpy(
        (*t).source_file.as_mut_ptr() as *mut ::core::ffi::c_void,
        &mut (*l).current_file as *mut [::core::ffi::c_char; 256]
            as *const ::core::ffi::c_void,
        TOKEN_LENGTH as size_t,
    );
    static mut eof: [::core::ffi::c_char; 14] = unsafe {
        ::core::mem::transmute::<
            [u8; 14],
            [::core::ffi::c_char; 14],
        >(*b"[end of file]\0")
    };
    if init == EOF {
        strcpy((*t).contents.as_mut_ptr(), eof.as_mut_ptr());
        (*t).length = strlen(eof.as_mut_ptr()) as ::core::ffi::c_uint;
        (*t).type_0 = TT_EOF;
        (*t).line = (*l).line;
        (*t).column = (*l).column;
        return 0 as ::core::ffi::c_int;
    }
    if init == ' ' as i32 || init == '\t' as i32 {
        fprintf(
            __stderrp,
            b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
            31 as ::core::ffi::c_int,
        );
        fprintf(
            __stderrp,
            b"Error: jccc: internal error: did not skip whitespace correctly\n\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
        fprintf(__stderrp, b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
        return -(1 as ::core::ffi::c_int);
    }
    static mut nline: [::core::ffi::c_char; 10] = unsafe {
        ::core::mem::transmute::<[u8; 10], [::core::ffi::c_char; 10]>(*b"[newline]\0")
    };
    if init == '\n' as i32 {
        strcpy((*t).contents.as_mut_ptr(), nline.as_mut_ptr());
        (*t).length = strlen(nline.as_mut_ptr()) as ::core::ffi::c_uint;
        (*t).type_0 = TT_NEWLINE;
        (*t).line = (*l).line;
        (*t).column = (*l).column;
        return 0 as ::core::ffi::c_int;
    }
    let mut pos: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let fresh0 = pos;
    pos = pos + 1;
    (*t).contents[fresh0 as usize] = init as ::core::ffi::c_char;
    if in_string(init as ::core::ffi::c_char, single_char_tokens.as_mut_ptr()) != 0 {
        (*t).length = pos as ::core::ffi::c_uint;
        (*t).type_0 = ttype_one_char(init as ::core::ffi::c_char);
        (*t).line = (*l).line;
        (*t).column = (*l).column;
        return 0 as ::core::ffi::c_int;
    }
    let mut c: ::core::ffi::c_int = 0;
    let mut starting_line: ::core::ffi::c_int = 0;
    let mut starting_col: ::core::ffi::c_int = 0;
    if is_valid_numeric_or_id_char(init as ::core::ffi::c_char) != 0 {
        starting_line = (*l).line;
        starting_col = (*l).column;
        loop {
            c = lexer_getchar(l);
            if is_valid_numeric_or_id_char(c as ::core::ffi::c_char) == 0 {
                break;
            }
            if pos >= TOKEN_LENGTH - 1 as ::core::ffi::c_int {
                fprintf(
                    __stderrp,
                    b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
                    31 as ::core::ffi::c_int,
                );
                fprintf(
                    __stderrp,
                    b"Error: jccc: identifier too long, over %d characters\n\0"
                        as *const u8 as *const ::core::ffi::c_char,
                    256 as ::core::ffi::c_int,
                );
                fprintf(
                    __stderrp,
                    b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char,
                );
                fprintf(
                    __stderrp,
                    b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
                    31 as ::core::ffi::c_int,
                );
                fprintf(
                    __stderrp,
                    b"Error: jccc: identifier began with the following:\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                );
                fprintf(
                    __stderrp,
                    b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char,
                );
                fprintf(
                    __stderrp,
                    b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
                    31 as ::core::ffi::c_int,
                );
                fprintf(
                    __stderrp,
                    b"Error: jccc: %.*s\n\0" as *const u8 as *const ::core::ffi::c_char,
                    256 as ::core::ffi::c_int,
                    (*t).contents.as_mut_ptr(),
                );
                fprintf(
                    __stderrp,
                    b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char,
                );
                return -(1 as ::core::ffi::c_int);
            }
            let fresh1 = pos;
            pos = pos + 1;
            (*t).contents[fresh1 as usize] = c as ::core::ffi::c_char;
        }
        lexer_ungetchar(l);
        (*t).contents[pos as usize] = '\0' as i32 as ::core::ffi::c_char;
        (*t).type_0 = ttype_many_chars((*t).contents.as_mut_ptr());
        (*t).length = pos as ::core::ffi::c_uint;
        (*t).line = starting_line;
        (*t).column = starting_col;
        return 0 as ::core::ffi::c_int;
    }
    if starts_operator(init as ::core::ffi::c_char) != 0 {
        while valid_operator_sequence((*t).contents.as_mut_ptr()) != 0 {
            c = lexer_getchar(l);
            let fresh2 = pos;
            pos = pos + 1;
            (*t).contents[fresh2 as usize] = c as ::core::ffi::c_char;
        }
        lexer_ungetchar(l);
        (*t).contents[(pos - 1 as ::core::ffi::c_int) as usize] = '\0' as i32
            as ::core::ffi::c_char;
        (*t).type_0 = ttype_from_string((*t).contents.as_mut_ptr());
        (*t).length = pos as ::core::ffi::c_uint;
        return 0 as ::core::ffi::c_int;
    }
    fprintf(
        __stderrp,
        b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
        31 as ::core::ffi::c_int,
    );
    fprintf(
        __stderrp,
        b"Error: jccc: lexer unable to identify token starting with: %c\n\0" as *const u8
            as *const ::core::ffi::c_char,
        init,
    );
    fprintf(__stderrp, b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn unlex(
    mut l: *mut Lexer,
    mut t: *mut Token,
) -> ::core::ffi::c_int {
    if (*l).unlexed_count >= TOKEN_PUTBACKS as ::core::ffi::c_uint {
        fprintf(
            __stderrp,
            b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
            31 as ::core::ffi::c_int,
        );
        fprintf(
            __stderrp,
            b"Error: jccc: internal: tried to unlex more than %d tokens at a time\n\0"
                as *const u8 as *const ::core::ffi::c_char,
            5 as ::core::ffi::c_int,
        );
        fprintf(__stderrp, b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
        return -(1 as ::core::ffi::c_int);
    }
    memcpy(
        &mut *(*l).unlexed.as_mut_ptr().offset((*l).unlexed_count as isize) as *mut Token
            as *mut ::core::ffi::c_void,
        t as *const ::core::ffi::c_void,
        ::core::mem::size_of::<Token>() as size_t,
    );
    (*l).unlexed_count = (*l).unlexed_count.wrapping_add(1);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn skip_to_token(mut l: *mut Lexer) -> ::core::ffi::c_int {
    let mut cur: ::core::ffi::c_char = 0;
    let mut prev: ::core::ffi::c_char = 0;
    let mut in_block: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut pass: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    cur = lexer_getchar(l) as ::core::ffi::c_char;
    if cur as ::core::ffi::c_int != EOF {
        prev = cur;
        if !(cur as ::core::ffi::c_int == ' ' as i32
            || cur as ::core::ffi::c_int == '\t' as i32
            || cur as ::core::ffi::c_int == '/' as i32)
        {
            lexer_ungetchar(l);
            return 0 as ::core::ffi::c_int;
        }
    } else {
        return -(1 as ::core::ffi::c_int)
    }
    loop {
        cur = lexer_getchar(l) as ::core::ffi::c_char;
        if !(cur as ::core::ffi::c_int != EOF) {
            break;
        }
        if cur as ::core::ffi::c_int == '/' as i32
            && prev as ::core::ffi::c_int == '/' as i32
            && in_block == 0 as ::core::ffi::c_int
        {
            in_block = 1 as ::core::ffi::c_int;
        } else if cur as ::core::ffi::c_int == '*' as i32
            && prev as ::core::ffi::c_int == '/' as i32
            && in_block == 0 as ::core::ffi::c_int
        {
            in_block = 2 as ::core::ffi::c_int;
            pass = 2 as ::core::ffi::c_int;
        } else if in_block == 1 as ::core::ffi::c_int
            && cur as ::core::ffi::c_int == '\n' as i32
            || in_block == 2 as ::core::ffi::c_int
                && cur as ::core::ffi::c_int == '/' as i32
                && prev as ::core::ffi::c_int == '*' as i32
                && pass <= 0 as ::core::ffi::c_int
        {
            in_block = 0 as ::core::ffi::c_int;
        } else if prev as ::core::ffi::c_int == '/' as i32
            && !(cur as ::core::ffi::c_int == '*' as i32
                || cur as ::core::ffi::c_int == '/' as i32)
            && in_block == 0 as ::core::ffi::c_int
        {
            lexer_ungetchar(l);
            return 0 as ::core::ffi::c_int;
        }
        if !(cur as ::core::ffi::c_int == ' ' as i32
            || cur as ::core::ffi::c_int == '\t' as i32
            || cur as ::core::ffi::c_int == '/' as i32)
            && in_block == 0 as ::core::ffi::c_int
        {
            lexer_ungetchar(l);
            return 0 as ::core::ffi::c_int;
        }
        pass -= 1 as ::core::ffi::c_int;
        prev = cur;
    }
    return -(1 as ::core::ffi::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn ttype_one_char(mut c: ::core::ffi::c_char) -> TokenType {
    match c as ::core::ffi::c_int {
        40 => return TT_OPAREN,
        41 => return TT_CPAREN,
        123 => return TT_OBRACE,
        125 => return TT_CBRACE,
        91 => return TT_OBRACKET,
        93 => return TT_CBRACKET,
        59 => return TT_SEMI,
        46 => return TT_PERIOD,
        44 => return TT_COMMA,
        45 => return TT_MINUS,
        43 => return TT_PLUS,
        42 => return TT_STAR,
        47 => return TT_SLASH,
        61 => return TT_ASSIGN,
        58 => return TT_COLON,
        37 => return TT_MOD,
        38 => return TT_BAND,
        124 => return TT_BOR,
        62 => return TT_GREATER,
        60 => return TT_LESS,
        33 => return TT_LNOT,
        126 => return TT_BNOT,
        94 => return TT_XOR,
        35 => return TT_POUND,
        63 => return TT_QMARK,
        _ => {
            if isdigit(c as ::core::ffi::c_int) != 0 {
                return TT_LITERAL
            } else {
                return TT_IDENTIFIER
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn ttype_many_chars(
    mut contents: *const ::core::ffi::c_char,
) -> TokenType {
    if strcmp(contents, b"auto\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_AUTO
    } else if strcmp(contents, b"break\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_BREAK
    } else if strcmp(contents, b"continue\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_CONTINUE
    } else if strcmp(contents, b"const\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_CONST
    } else if strcmp(contents, b"case\0" as *const u8 as *const ::core::ffi::c_char) == 0
    {
        return TT_CASE
    } else if strcmp(contents, b"char\0" as *const u8 as *const ::core::ffi::c_char) == 0
    {
        return TT_CHAR
    } else if strcmp(contents, b"do\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_DO
    } else if strcmp(contents, b"double\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_DOUBLE
    } else if strcmp(contents, b"default\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_DEFAULT
    } else if strcmp(contents, b"enum\0" as *const u8 as *const ::core::ffi::c_char) == 0
    {
        return TT_ENUM
    } else if strcmp(contents, b"else\0" as *const u8 as *const ::core::ffi::c_char) == 0
    {
        return TT_ELSE
    } else if strcmp(contents, b"extern\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_EXTERN
    } else if strcmp(contents, b"float\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_FLOAT
    } else if strcmp(contents, b"for\0" as *const u8 as *const ::core::ffi::c_char) == 0
    {
        return TT_FOR
    } else if strcmp(contents, b"goto\0" as *const u8 as *const ::core::ffi::c_char) == 0
    {
        return TT_GOTO
    } else if strcmp(contents, b"int\0" as *const u8 as *const ::core::ffi::c_char) == 0
    {
        return TT_INT
    } else if strcmp(contents, b"if\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_IF
    } else if strcmp(contents, b"long\0" as *const u8 as *const ::core::ffi::c_char) == 0
    {
        return TT_LONG
    } else if strcmp(contents, b"return\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_RETURN
    } else if strcmp(contents, b"register\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_REGISTER
    } else if strcmp(contents, b"struct\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_STRUCT
    } else if strcmp(contents, b"signed\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_SIGNED
    } else if strcmp(contents, b"sizeof\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_SIZEOF
    } else if strcmp(contents, b"static\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_STATIC
    } else if strcmp(contents, b"short\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_SHORT
    } else if strcmp(contents, b"switch\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_SWITCH
    } else if strcmp(contents, b"typedef\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_TYPEDEF
    } else if strcmp(contents, b"union\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_UNION
    } else if strcmp(contents, b"unsigned\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_UNSIGNED
    } else if strcmp(contents, b"void\0" as *const u8 as *const ::core::ffi::c_char) == 0
    {
        return TT_VOID
    } else if strcmp(contents, b"volatile\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_VOLATILE
    } else if strcmp(contents, b"while\0" as *const u8 as *const ::core::ffi::c_char)
        == 0
    {
        return TT_WHILE
    } else if strcmp(contents, b"&&\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_LAND
    } else if strcmp(contents, b"||\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_LOR
    } else if strcmp(contents, b"-=\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_DEC
    } else if strcmp(contents, b"+=\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_INC
    } else if strcmp(contents, b"++\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_PLUSPLUS
    } else if strcmp(contents, b"--\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_MINUSMINUS
    } else if strcmp(contents, b"/=\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_DIVEQ
    } else if strcmp(contents, b"*=\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_MULEQ
    } else if strcmp(contents, b"%=\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_MODEQ
    } else if strcmp(contents, b"&=\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_BANDEQ
    } else if strcmp(contents, b"|=\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_BOREQ
    } else if strcmp(contents, b"&&=\0" as *const u8 as *const ::core::ffi::c_char) == 0
    {
        return TT_LANDEQ
    } else if strcmp(contents, b"||=\0" as *const u8 as *const ::core::ffi::c_char) == 0
    {
        return TT_LOREQ
    } else if strcmp(contents, b"<=\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_LESSEQ
    } else if strcmp(contents, b">=\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_GREATEREQ
    } else if strcmp(contents, b"<<\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_LEFTSHIFT
    } else if strcmp(contents, b">>\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_RIGHTSHIFT
    } else if strcmp(contents, b"==\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_EQUALS
    } else if strcmp(contents, b"^=\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_XOREQ
    } else if strcmp(contents, b"->\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_POINT
    } else if strcmp(contents, b"<<=\0" as *const u8 as *const ::core::ffi::c_char) == 0
    {
        return TT_LEFTSHIFTEQUALS
    } else if strcmp(contents, b">>=\0" as *const u8 as *const ::core::ffi::c_char) == 0
    {
        return TT_RIGHTSHIFTEQUALS
    } else if strcmp(contents, b"!=\0" as *const u8 as *const ::core::ffi::c_char) == 0 {
        return TT_NOTEQ
    }
    let mut all_numeric: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    let mut count_fs: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut count_us: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut i: ::core::ffi::c_int = 0;
    if contents.is_null() {
        return TT_NO_TOKEN;
    }
    i = 0 as ::core::ffi::c_int;
    while *contents.offset(i as isize) as ::core::ffi::c_int != '\0' as i32 {
        let mut c: ::core::ffi::c_char = *contents.offset(i as isize);
        if c as ::core::ffi::c_int == '.' as i32 {
            return TT_LITERAL;
        }
        if c as ::core::ffi::c_int == 'f' as i32 {
            count_fs += 1;
        }
        if c as ::core::ffi::c_int == 'u' as i32 {
            count_us += 1;
        }
        if (c as ::core::ffi::c_int > '9' as i32
            || (c as ::core::ffi::c_int) < '0' as i32)
            && c as ::core::ffi::c_int != 'u' as i32
        {
            all_numeric = 0 as ::core::ffi::c_int;
        }
        if c as ::core::ffi::c_int == '\'' as i32
            || c as ::core::ffi::c_int == '"' as i32
        {
            return TT_LITERAL;
        }
        i += 1;
    }
    if all_numeric != 0 {
        if count_us == 1 as ::core::ffi::c_int
            && *contents.offset((i - 1 as ::core::ffi::c_int) as isize)
                as ::core::ffi::c_int == 'u' as i32
        {
            return TT_LITERAL;
        }
        if count_us == 0 as ::core::ffi::c_int {
            return TT_LITERAL;
        }
    }
    return TT_IDENTIFIER;
}
#[no_mangle]
pub unsafe extern "C" fn ttype_from_string(
    mut contents: *const ::core::ffi::c_char,
) -> TokenType {
    let mut len: ::core::ffi::c_int = 0;
    len = strlen(contents) as ::core::ffi::c_int;
    if len == 1 as ::core::ffi::c_int {
        let mut token: TokenType = ttype_one_char(
            *contents.offset(0 as ::core::ffi::c_int as isize),
        );
        return token;
    }
    return ttype_many_chars(contents);
}
static mut ttype_names: [*const ::core::ffi::c_char; 85] = [
    b"literal\0" as *const u8 as *const ::core::ffi::c_char,
    b"identifier\0" as *const u8 as *const ::core::ffi::c_char,
    b"open paren\0" as *const u8 as *const ::core::ffi::c_char,
    b"close paren\0" as *const u8 as *const ::core::ffi::c_char,
    b"open brace\0" as *const u8 as *const ::core::ffi::c_char,
    b"close brace\0" as *const u8 as *const ::core::ffi::c_char,
    b"open bracket\0" as *const u8 as *const ::core::ffi::c_char,
    b"close bracket\0" as *const u8 as *const ::core::ffi::c_char,
    b"semicolon\0" as *const u8 as *const ::core::ffi::c_char,
    b"no token\0" as *const u8 as *const ::core::ffi::c_char,
    b"end of file\0" as *const u8 as *const ::core::ffi::c_char,
    b"newline\0" as *const u8 as *const ::core::ffi::c_char,
    b"pound\0" as *const u8 as *const ::core::ffi::c_char,
    b".\0" as *const u8 as *const ::core::ffi::c_char,
    b",\0" as *const u8 as *const ::core::ffi::c_char,
    b"?\0" as *const u8 as *const ::core::ffi::c_char,
    b"-\0" as *const u8 as *const ::core::ffi::c_char,
    b"+\0" as *const u8 as *const ::core::ffi::c_char,
    b"*\0" as *const u8 as *const ::core::ffi::c_char,
    b"/\0" as *const u8 as *const ::core::ffi::c_char,
    b"=\0" as *const u8 as *const ::core::ffi::c_char,
    b":\0" as *const u8 as *const ::core::ffi::c_char,
    b"%\0" as *const u8 as *const ::core::ffi::c_char,
    b"&\0" as *const u8 as *const ::core::ffi::c_char,
    b"&&\0" as *const u8 as *const ::core::ffi::c_char,
    b"|\0" as *const u8 as *const ::core::ffi::c_char,
    b"||\0" as *const u8 as *const ::core::ffi::c_char,
    b"-=\0" as *const u8 as *const ::core::ffi::c_char,
    b"+=\0" as *const u8 as *const ::core::ffi::c_char,
    b"++\0" as *const u8 as *const ::core::ffi::c_char,
    b"--\0" as *const u8 as *const ::core::ffi::c_char,
    b"/=\0" as *const u8 as *const ::core::ffi::c_char,
    b"*=\0" as *const u8 as *const ::core::ffi::c_char,
    b"%=\0" as *const u8 as *const ::core::ffi::c_char,
    b"&=\0" as *const u8 as *const ::core::ffi::c_char,
    b"|=\0" as *const u8 as *const ::core::ffi::c_char,
    b"&&=\0" as *const u8 as *const ::core::ffi::c_char,
    b"||=\0" as *const u8 as *const ::core::ffi::c_char,
    b">\0" as *const u8 as *const ::core::ffi::c_char,
    b"<\0" as *const u8 as *const ::core::ffi::c_char,
    b"<=\0" as *const u8 as *const ::core::ffi::c_char,
    b">=\0" as *const u8 as *const ::core::ffi::c_char,
    b"<<\0" as *const u8 as *const ::core::ffi::c_char,
    b">>\0" as *const u8 as *const ::core::ffi::c_char,
    b"!\0" as *const u8 as *const ::core::ffi::c_char,
    b"~\0" as *const u8 as *const ::core::ffi::c_char,
    b"==\0" as *const u8 as *const ::core::ffi::c_char,
    b"!=\0" as *const u8 as *const ::core::ffi::c_char,
    b"^\0" as *const u8 as *const ::core::ffi::c_char,
    b"^=\0" as *const u8 as *const ::core::ffi::c_char,
    b"->\0" as *const u8 as *const ::core::ffi::c_char,
    b"<<=\0" as *const u8 as *const ::core::ffi::c_char,
    b">>=\0" as *const u8 as *const ::core::ffi::c_char,
    b"auto\0" as *const u8 as *const ::core::ffi::c_char,
    b"break\0" as *const u8 as *const ::core::ffi::c_char,
    b"char\0" as *const u8 as *const ::core::ffi::c_char,
    b"const\0" as *const u8 as *const ::core::ffi::c_char,
    b"case\0" as *const u8 as *const ::core::ffi::c_char,
    b"continue\0" as *const u8 as *const ::core::ffi::c_char,
    b"double\0" as *const u8 as *const ::core::ffi::c_char,
    b"do\0" as *const u8 as *const ::core::ffi::c_char,
    b"default\0" as *const u8 as *const ::core::ffi::c_char,
    b"enum\0" as *const u8 as *const ::core::ffi::c_char,
    b"else\0" as *const u8 as *const ::core::ffi::c_char,
    b"extern\0" as *const u8 as *const ::core::ffi::c_char,
    b"float\0" as *const u8 as *const ::core::ffi::c_char,
    b"for\0" as *const u8 as *const ::core::ffi::c_char,
    b"goto\0" as *const u8 as *const ::core::ffi::c_char,
    b"if\0" as *const u8 as *const ::core::ffi::c_char,
    b"int\0" as *const u8 as *const ::core::ffi::c_char,
    b"long\0" as *const u8 as *const ::core::ffi::c_char,
    b"return\0" as *const u8 as *const ::core::ffi::c_char,
    b"register\0" as *const u8 as *const ::core::ffi::c_char,
    b"static\0" as *const u8 as *const ::core::ffi::c_char,
    b"switch\0" as *const u8 as *const ::core::ffi::c_char,
    b"short\0" as *const u8 as *const ::core::ffi::c_char,
    b"signed\0" as *const u8 as *const ::core::ffi::c_char,
    b"struct\0" as *const u8 as *const ::core::ffi::c_char,
    b"sizeof\0" as *const u8 as *const ::core::ffi::c_char,
    b"typedef\0" as *const u8 as *const ::core::ffi::c_char,
    b"unsigned\0" as *const u8 as *const ::core::ffi::c_char,
    b"union\0" as *const u8 as *const ::core::ffi::c_char,
    b"void\0" as *const u8 as *const ::core::ffi::c_char,
    b"volatile\0" as *const u8 as *const ::core::ffi::c_char,
    b"while\0" as *const u8 as *const ::core::ffi::c_char,
];
#[no_mangle]
pub unsafe extern "C" fn ttype_name(mut tt: TokenType) -> *const ::core::ffi::c_char {
    return ttype_names[tt as usize];
}
#[no_mangle]
pub unsafe extern "C" fn test_ttype_many_chars() -> ::core::ffi::c_int {
    testing_single_test_internal(
        ::core::mem::transmute::<
            [u8; 22],
            [::core::ffi::c_char; 22],
        >(*b"test_ttype_many_chars\0")
            .as_ptr(),
    );
    if ttype_many_chars(b"foo\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint
        == TT_IDENTIFIER as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            664 as ::core::ffi::c_int,
            b"ttype_many_chars(\"foo\") == TT_IDENTIFIER\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_many_chars(b"struct\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint == TT_STRUCT as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            665 as ::core::ffi::c_int,
            b"ttype_many_chars(\"struct\") == TT_STRUCT\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_many_chars(b"while\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint == TT_WHILE as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            666 as ::core::ffi::c_int,
            b"ttype_many_chars(\"while\") == TT_WHILE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_ttype_one_char() -> ::core::ffi::c_int {
    testing_single_test_internal(
        ::core::mem::transmute::<
            [u8; 20],
            [::core::ffi::c_char; 20],
        >(*b"test_ttype_one_char\0")
            .as_ptr(),
    );
    if ttype_one_char('a' as i32 as ::core::ffi::c_char) as ::core::ffi::c_uint
        == TT_IDENTIFIER as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            675 as ::core::ffi::c_int,
            b"ttype_one_char('a') == TT_IDENTIFIER\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_one_char('1' as i32 as ::core::ffi::c_char) as ::core::ffi::c_uint
        == TT_LITERAL as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            676 as ::core::ffi::c_int,
            b"ttype_one_char('1') == TT_LITERAL\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_one_char('+' as i32 as ::core::ffi::c_char) as ::core::ffi::c_uint
        == TT_PLUS as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            678 as ::core::ffi::c_int,
            b"ttype_one_char('+') == TT_PLUS\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_one_char('-' as i32 as ::core::ffi::c_char) as ::core::ffi::c_uint
        == TT_MINUS as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            679 as ::core::ffi::c_int,
            b"ttype_one_char('-') == TT_MINUS\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_one_char('>' as i32 as ::core::ffi::c_char) as ::core::ffi::c_uint
        == TT_GREATER as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            680 as ::core::ffi::c_int,
            b"ttype_one_char('>') == TT_GREATER\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_one_char('~' as i32 as ::core::ffi::c_char) as ::core::ffi::c_uint
        == TT_BNOT as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            681 as ::core::ffi::c_int,
            b"ttype_one_char('~') == TT_BNOT\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_ttype_name() -> ::core::ffi::c_int {
    testing_single_test_internal(
        ::core::mem::transmute::<
            [u8; 16],
            [::core::ffi::c_char; 16],
        >(*b"test_ttype_name\0")
            .as_ptr(),
    );
    if strcmp(
        ttype_name(TT_LITERAL),
        b"literal\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            689 as ::core::ffi::c_int,
            b"strcmp(ttype_name(TT_LITERAL), \"literal\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if strcmp(ttype_name(TT_PLUS), b"+\0" as *const u8 as *const ::core::ffi::c_char)
        == 0 as ::core::ffi::c_int
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            690 as ::core::ffi::c_int,
            b"strcmp(ttype_name(TT_PLUS), \"+\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if strcmp(
        ttype_name(TT_SIZEOF),
        b"sizeof\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            691 as ::core::ffi::c_int,
            b"strcmp(ttype_name(TT_SIZEOF), \"sizeof\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if strcmp(
        ttype_name(TT_WHILE),
        b"while\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            692 as ::core::ffi::c_int,
            b"strcmp(ttype_name(TT_WHILE), \"while\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_ttype_from_string() -> ::core::ffi::c_int {
    testing_single_test_internal(
        ::core::mem::transmute::<
            [u8; 23],
            [::core::ffi::c_char; 23],
        >(*b"test_ttype_from_string\0")
            .as_ptr(),
    );
    if ttype_from_string(b"+\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint == TT_PLUS as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            700 as ::core::ffi::c_int,
            b"ttype_from_string(\"+\") == TT_PLUS\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_from_string(b"=\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint == TT_ASSIGN as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            701 as ::core::ffi::c_int,
            b"ttype_from_string(\"=\") == TT_ASSIGN\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_from_string(b"1\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint == TT_LITERAL as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            703 as ::core::ffi::c_int,
            b"ttype_from_string(\"1\") == TT_LITERAL\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_from_string(b"1.2\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint == TT_LITERAL as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            704 as ::core::ffi::c_int,
            b"ttype_from_string(\"1.2\") == TT_LITERAL\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_from_string(b"1u\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint == TT_LITERAL as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            706 as ::core::ffi::c_int,
            b"ttype_from_string(\"1u\") == TT_LITERAL\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_from_string(b"1.2f\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint == TT_LITERAL as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            707 as ::core::ffi::c_int,
            b"ttype_from_string(\"1.2f\") == TT_LITERAL\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_from_string(b"1.f\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint == TT_LITERAL as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            708 as ::core::ffi::c_int,
            b"ttype_from_string(\"1.f\") == TT_LITERAL\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_from_string(b"\"Planck\"\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint == TT_LITERAL as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            710 as ::core::ffi::c_int,
            b"ttype_from_string(\"\\\"Planck\\\"\") == TT_LITERAL\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_from_string(b"'Language'\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint == TT_LITERAL as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            711 as ::core::ffi::c_int,
            b"ttype_from_string(\"'Language'\") == TT_LITERAL\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_from_string(b"Jaba\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint
        == TT_IDENTIFIER as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            713 as ::core::ffi::c_int,
            b"ttype_from_string(\"Jaba\") == TT_IDENTIFIER\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_from_string(b"cat_\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint
        == TT_IDENTIFIER as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            714 as ::core::ffi::c_int,
            b"ttype_from_string(\"cat_\") == TT_IDENTIFIER\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_from_string(b"(\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint == TT_OPAREN as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            716 as ::core::ffi::c_int,
            b"ttype_from_string(\"(\") == TT_OPAREN\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_from_string(b"}\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint == TT_CBRACE as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            717 as ::core::ffi::c_int,
            b"ttype_from_string(\"}\") == TT_CBRACE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    if ttype_from_string(b";\0" as *const u8 as *const ::core::ffi::c_char)
        as ::core::ffi::c_uint == TT_SEMI as ::core::ffi::c_int as ::core::ffi::c_uint
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/lexer/lex.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            719 as ::core::ffi::c_int,
            b"ttype_from_string(\";\") == TT_SEMI\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    return 0 as ::core::ffi::c_int;
}
