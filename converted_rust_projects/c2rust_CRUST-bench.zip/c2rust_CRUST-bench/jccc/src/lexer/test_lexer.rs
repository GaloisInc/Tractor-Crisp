#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn test_ttype_from_string() -> ::core::ffi::c_int;
    fn test_ttype_many_chars() -> ::core::ffi::c_int;
    fn test_ttype_one_char() -> ::core::ffi::c_int;
    fn test_ttype_name() -> ::core::ffi::c_int;
    fn testing_setup_internal(func_name: *const ::core::ffi::c_char);
    fn testing_cleanup_internal(func_name: *const ::core::ffi::c_char);
}
#[no_mangle]
pub unsafe extern "C" fn test_lexer() -> ::core::ffi::c_int {
    testing_setup_internal(
        ::core::mem::transmute::<[u8; 11], [::core::ffi::c_char; 11]>(*b"test_lexer\0")
            .as_ptr(),
    );
    test_ttype_name();
    test_ttype_from_string();
    test_ttype_many_chars();
    test_ttype_one_char();
    testing_cleanup_internal(
        ::core::mem::transmute::<[u8; 11], [::core::ffi::c_char; 11]>(*b"test_lexer\0")
            .as_ptr(),
    );
    return 0 as ::core::ffi::c_int;
}
