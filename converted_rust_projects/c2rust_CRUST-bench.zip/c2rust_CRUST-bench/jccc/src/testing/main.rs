#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn test_x86() -> ::core::ffi::c_int;
    fn test_lexer() -> ::core::ffi::c_int;
    fn test_list() -> ::core::ffi::c_int;
    fn test_util() -> ::core::ffi::c_int;
}
unsafe fn main_0() -> ::core::ffi::c_int {
    test_lexer();
    test_x86();
    test_list();
    test_util();
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
