#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn calloc(__count: size_t, __size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn testing_single_test_internal(func_name: *const ::core::ffi::c_char);
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct BucketNode {
    pub key: *mut ::core::ffi::c_char,
    pub value: *mut ::core::ffi::c_void,
    pub next: *mut BucketNode,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Hashmap {
    pub buckets: *mut *mut BucketNode,
    pub size: ::core::ffi::c_int,
    pub cap: ::core::ffi::c_int,
    pub hash: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_char) -> ::core::ffi::c_uint,
    >,
    pub equals: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_char,
            *mut ::core::ffi::c_char,
        ) -> ::core::ffi::c_uint,
    >,
}
pub type size_t = __darwin_size_t;
pub type __darwin_size_t = usize;
pub type uint64_t = u64;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn fnva1(
    mut value: *mut ::core::ffi::c_char,
) -> ::core::ffi::c_uint {
    let mut h: ::core::ffi::c_ulong = 16777619 as ::core::ffi::c_ulong;
    let mut prime: ::core::ffi::c_long = 2166136261 as ::core::ffi::c_long;
    while *value as ::core::ffi::c_int != '\0' as i32 {
        h ^= *value as ::core::ffi::c_ulong;
        h = h.wrapping_mul(prime as ::core::ffi::c_ulong);
        value = value.offset(1);
    }
    return h as ::core::ffi::c_uint;
}
#[no_mangle]
pub unsafe extern "C" fn equal_key(
    mut a: *mut ::core::ffi::c_char,
    mut b: *mut ::core::ffi::c_char,
) -> ::core::ffi::c_uint {
    return (strcmp(a, b) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_uint;
}
#[no_mangle]
pub unsafe extern "C" fn create_hashmap(
    mut capacity: ::core::ffi::c_int,
) -> *mut Hashmap {
    let mut h: *mut Hashmap = malloc(::core::mem::size_of::<Hashmap>() as size_t)
        as *mut Hashmap;
    (*h).buckets = calloc(
        capacity as size_t,
        ::core::mem::size_of::<*mut BucketNode>() as size_t,
    ) as *mut *mut BucketNode;
    (*h).size = 0 as ::core::ffi::c_int;
    (*h).cap = capacity;
    (*h).hash = Some(
        fnva1 as unsafe extern "C" fn(*mut ::core::ffi::c_char) -> ::core::ffi::c_uint,
    ) as Option<unsafe extern "C" fn(*mut ::core::ffi::c_char) -> ::core::ffi::c_uint>;
    (*h).equals = Some(
        equal_key
            as unsafe extern "C" fn(
                *mut ::core::ffi::c_char,
                *mut ::core::ffi::c_char,
            ) -> ::core::ffi::c_uint,
    )
        as Option<
            unsafe extern "C" fn(
                *mut ::core::ffi::c_char,
                *mut ::core::ffi::c_char,
            ) -> ::core::ffi::c_uint,
        >;
    return h;
}
#[no_mangle]
pub unsafe extern "C" fn destroy_hashmap(mut h: *mut Hashmap) {
    free((*h).buckets as *mut ::core::ffi::c_void);
    free(h as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn create_bucket(
    mut key: *mut ::core::ffi::c_char,
    mut value: *mut ::core::ffi::c_void,
) -> *mut BucketNode {
    let mut b: *mut BucketNode = malloc(::core::mem::size_of::<BucketNode>() as size_t)
        as *mut BucketNode;
    (*b).key = key;
    (*b).value = value;
    (*b).next = 0 as *mut BucketNode;
    return b;
}
#[no_mangle]
pub unsafe extern "C" fn hm_get(
    mut h: *mut Hashmap,
    mut key: *mut ::core::ffi::c_char,
) -> *mut BucketNode {
    let mut a: ::core::ffi::c_uint = (*h)
        .hash
        .expect("non-null function pointer")(key)
        .wrapping_rem((*h).cap as ::core::ffi::c_uint);
    let mut b: *mut BucketNode = *(*h).buckets.offset(a as isize);
    if b.is_null() {
        return 0 as *mut BucketNode;
    }
    if (*h).equals.expect("non-null function pointer")((*b).key, key) != 0 {
        return b;
    }
    return 0 as *mut BucketNode;
}
#[no_mangle]
pub unsafe extern "C" fn hm_set(
    mut h: *mut Hashmap,
    mut key: *mut ::core::ffi::c_char,
    mut value: *mut ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    let mut a: ::core::ffi::c_uint = (*h)
        .hash
        .expect("non-null function pointer")(key)
        .wrapping_rem((*h).cap as ::core::ffi::c_uint);
    let mut b: *mut BucketNode = *(*h).buckets.offset(a as isize);
    if b.is_null() {
        if (*h).size == (*h).cap {
            double_cap(h);
        }
        (*h).size += 1;
        let ref mut fresh0 = *(*h).buckets.offset(a as isize);
        *fresh0 = malloc(::core::mem::size_of::<*mut BucketNode>() as size_t)
            as *mut BucketNode;
        let ref mut fresh1 = (**(*h).buckets.offset(a as isize)).key;
        *fresh1 = key;
        let ref mut fresh2 = (**(*h).buckets.offset(a as isize)).value;
        *fresh2 = value;
        let ref mut fresh3 = (**(*h).buckets.offset(a as isize)).next;
        *fresh3 = 0 as *mut BucketNode;
        return 0 as ::core::ffi::c_int;
    } else {
        return -(1 as ::core::ffi::c_int)
    };
}
#[no_mangle]
pub unsafe extern "C" fn double_cap(mut h: *mut Hashmap) {
    let mut new_buckets: *mut *mut BucketNode = calloc(
        ((*h).cap * 2 as ::core::ffi::c_int) as size_t,
        ::core::mem::size_of::<*mut BucketNode>() as size_t,
    ) as *mut *mut BucketNode;
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*h).cap {
        if !(*(*h).buckets.offset(i as isize)).is_null() {
            let mut b: *mut BucketNode = *(*h).buckets.offset(i as isize);
            let mut a: ::core::ffi::c_uint = (*h)
                .hash
                .expect("non-null function pointer")((*b).key)
                .wrapping_rem((*h).cap as ::core::ffi::c_uint);
            let ref mut fresh4 = *new_buckets.offset(a as isize);
            *fresh4 = b;
        }
        i += 1;
    }
    (*h).buckets = new_buckets;
    (*h).cap = (*h).cap * 2 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_hash_init() -> ::core::ffi::c_int {
    testing_single_test_internal(
        ::core::mem::transmute::<
            [u8; 15],
            [::core::ffi::c_char; 15],
        >(*b"test_hash_init\0")
            .as_ptr(),
    );
    let mut h: *mut Hashmap = create_hashmap(100 as ::core::ffi::c_int);
    if (*h).size == 0 as ::core::ffi::c_int {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/util/hashmap.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            117 as ::core::ffi::c_int,
            b"h->size == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    };
    if (*h).cap == 100 as ::core::ffi::c_int {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/util/hashmap.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            118 as ::core::ffi::c_int,
            b"h->cap == 100\0" as *const u8 as *const ::core::ffi::c_char,
        );
    };
    panic!("Reached end of non-void function without returning");
}
#[no_mangle]
pub unsafe extern "C" fn test_hash_init_and_store() -> ::core::ffi::c_int {
    testing_single_test_internal(
        ::core::mem::transmute::<
            [u8; 25],
            [::core::ffi::c_char; 25],
        >(*b"test_hash_init_and_store\0")
            .as_ptr(),
    );
    let mut h: *mut Hashmap = create_hashmap(100 as ::core::ffi::c_int);
    if (*h).size == 0 as ::core::ffi::c_int {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/util/hashmap.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            125 as ::core::ffi::c_int,
            b"h->size == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    };
    if (*h).cap == 100 as ::core::ffi::c_int {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/util/hashmap.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            126 as ::core::ffi::c_int,
            b"h->cap == 100\0" as *const u8 as *const ::core::ffi::c_char,
        );
    };
    let mut name: [::core::ffi::c_char; 5] = ::core::mem::transmute::<
        [u8; 5],
        [::core::ffi::c_char; 5],
    >(*b"jake\0");
    let mut key: [::core::ffi::c_char; 5] = ::core::mem::transmute::<
        [u8; 5],
        [::core::ffi::c_char; 5],
    >(*b"test\0");
    let mut ret: ::core::ffi::c_int = hm_set(
        h,
        key.as_mut_ptr(),
        name.as_mut_ptr() as *mut ::core::ffi::c_void,
    );
    if ret != -(1 as ::core::ffi::c_int) {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/util/hashmap.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            132 as ::core::ffi::c_int,
            b"ret != -1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    };
    let mut ind: uint64_t = (*h)
        .hash
        .expect("non-null function pointer")(key.as_mut_ptr())
        .wrapping_rem((*h).cap as ::core::ffi::c_uint) as uint64_t;
    let mut b: *mut BucketNode = *(*h).buckets.offset(ind as isize);
    if strcmp((*b).key, key.as_mut_ptr()) == 0 as ::core::ffi::c_int {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/util/hashmap.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            136 as ::core::ffi::c_int,
            b"strcmp(b->key, key) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    };
    if (*h).size == 1 as ::core::ffi::c_int {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/util/hashmap.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            138 as ::core::ffi::c_int,
            b"h->size == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    };
    if (*h).cap == 100 as ::core::ffi::c_int {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/util/hashmap.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            139 as ::core::ffi::c_int,
            b"h->cap == 100\0" as *const u8 as *const ::core::ffi::c_char,
        );
    };
    panic!("Reached end of non-void function without returning");
}
#[no_mangle]
pub unsafe extern "C" fn test_hash_set_and_get() -> ::core::ffi::c_int {
    testing_single_test_internal(
        ::core::mem::transmute::<
            [u8; 22],
            [::core::ffi::c_char; 22],
        >(*b"test_hash_set_and_get\0")
            .as_ptr(),
    );
    let mut h: *mut Hashmap = create_hashmap(100 as ::core::ffi::c_int);
    let mut name: [::core::ffi::c_char; 100] = ::core::mem::transmute::<
        [u8; 100],
        [::core::ffi::c_char; 100],
    >(
        *b"jake\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
    );
    let mut key: [::core::ffi::c_char; 10] = ::core::mem::transmute::<
        [u8; 10],
        [::core::ffi::c_char; 10],
    >(*b"test\0\0\0\0\0\0");
    let mut ret: ::core::ffi::c_int = hm_set(
        h,
        key.as_mut_ptr(),
        name.as_mut_ptr() as *mut ::core::ffi::c_void,
    );
    if ret != -(1 as ::core::ffi::c_int) {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/util/hashmap.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            150 as ::core::ffi::c_int,
            b"ret != -1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    };
    let mut got: *mut BucketNode = hm_get(
        h,
        b"test\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    );
    if strcmp(
        (*got).value as *const ::core::ffi::c_char,
        b"jake\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/util/hashmap.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            153 as ::core::ffi::c_int,
            b"strcmp(got->value, \"jake\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_hash_set_and_double_get() -> ::core::ffi::c_int {
    testing_single_test_internal(
        ::core::mem::transmute::<
            [u8; 29],
            [::core::ffi::c_char; 29],
        >(*b"test_hash_set_and_double_get\0")
            .as_ptr(),
    );
    let mut h: *mut Hashmap = create_hashmap(100 as ::core::ffi::c_int);
    let mut name: [::core::ffi::c_char; 100] = ::core::mem::transmute::<
        [u8; 100],
        [::core::ffi::c_char; 100],
    >(
        *b"jake\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
    );
    let mut key: [::core::ffi::c_char; 10] = ::core::mem::transmute::<
        [u8; 10],
        [::core::ffi::c_char; 10],
    >(*b"test\0\0\0\0\0\0");
    let mut ret: ::core::ffi::c_int = hm_set(
        h,
        key.as_mut_ptr(),
        name.as_mut_ptr() as *mut ::core::ffi::c_void,
    );
    if ret != -(1 as ::core::ffi::c_int) {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/util/hashmap.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            166 as ::core::ffi::c_int,
            b"ret != -1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    };
    double_cap(h);
    let mut got: *mut BucketNode = hm_get(
        h,
        b"test\0" as *const u8 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    );
    if strcmp(
        (*got).value as *const ::core::ffi::c_char,
        b"jake\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
    {} else {
        printf(
            b"%s:%u: failed assertion `%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/util/hashmap.c\0"
                as *const u8 as *const ::core::ffi::c_char,
            171 as ::core::ffi::c_int,
            b"strcmp(got->value, \"jake\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
    return 0 as ::core::ffi::c_int;
}
