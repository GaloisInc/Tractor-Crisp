#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct List {
    pub head: *mut ListBlock,
    pub tail: *mut ListBlock,
    pub blocksize: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct ListBlock {
    pub array: *mut *mut ::core::ffi::c_void,
    pub size: ::core::ffi::c_int,
    pub full: ::core::ffi::c_int,
    pub next: *mut ListBlock,
}
pub type size_t = __darwin_size_t;
pub type __darwin_size_t = usize;
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type fpos_t = __darwin_off_t;
pub type __darwin_off_t = __int64_t;
pub type __int64_t = i64;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn create_list(mut blocksize: ::core::ffi::c_int) -> *mut List {
    let mut l: *mut List = malloc(::core::mem::size_of::<List>() as size_t) as *mut List;
    if l.is_null() {
        fprintf(
            __stderrp,
            b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
            31 as ::core::ffi::c_int,
        );
        fprintf(
            __stderrp,
            b"Error: jccc: internal: failed to allocate memory\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        fprintf(__stderrp, b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
        return 0 as *mut List;
    }
    (*l).blocksize = blocksize;
    (*l).tail = 0 as *mut ListBlock;
    (*l).head = (*l).tail;
    return l as *mut List;
}
#[no_mangle]
pub unsafe extern "C" fn destroy_list(mut l: *mut List) -> ::core::ffi::c_int {
    let mut lb: *mut ListBlock = (*l).head;
    let mut next: *mut ListBlock = 0 as *mut ListBlock;
    while !lb.is_null() {
        next = (*lb).next as *mut ListBlock;
        free((*lb).array as *mut ::core::ffi::c_void);
        free(lb as *mut ::core::ffi::c_void);
        lb = next;
    }
    free(l as *mut ::core::ffi::c_void);
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn lfind_index(
    mut l: *mut List,
    mut lb: *mut *mut ListBlock,
    mut i: *mut ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    *lb = (*l).head;
    if *i < 0 as ::core::ffi::c_int {
        fprintf(
            __stderrp,
            b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
            31 as ::core::ffi::c_int,
        );
        fprintf(
            __stderrp,
            b"Error: jccc: internal: list index was negative (%d)\n\0" as *const u8
                as *const ::core::ffi::c_char,
            *i,
        );
        fprintf(__stderrp, b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
        return -(1 as ::core::ffi::c_int);
    }
    while *i >= (**lb).size {
        if !lb.is_null() {
            *lb = (**lb).next as *mut ListBlock;
            *i -= (**lb).size;
        } else {
            fprintf(
                __stderrp,
                b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
                31 as ::core::ffi::c_int,
            );
            fprintf(
                __stderrp,
                b"Error: jccc: internal: list index %d out of bounds\n\0" as *const u8
                    as *const ::core::ffi::c_char,
                *i,
            );
            fprintf(__stderrp, b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
            return -(1 as ::core::ffi::c_int);
        }
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn lget_element(
    mut l: *mut List,
    mut index: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_void {
    let mut i: ::core::ffi::c_int = index;
    let mut lb: *mut ListBlock = 0 as *mut ListBlock;
    lfind_index(l, &mut lb, &mut i);
    if i >= (*lb).full {
        fprintf(
            __stderrp,
            b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
            31 as ::core::ffi::c_int,
        );
        fprintf(
            __stderrp,
            b"Error: jccc: internal: list index %d out of bounds\n\0" as *const u8
                as *const ::core::ffi::c_char,
            index,
        );
        fprintf(__stderrp, b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
        return NULL;
    }
    return *(*lb).array.offset(i as isize);
}
#[no_mangle]
pub unsafe extern "C" fn lset_element(
    mut l: *mut List,
    mut index: ::core::ffi::c_int,
    mut value: *mut ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    let mut i: ::core::ffi::c_int = index;
    let mut ret: ::core::ffi::c_int = 0;
    let mut lb: *mut ListBlock = 0 as *mut ListBlock;
    ret = lfind_index(l, &mut lb, &mut i);
    if ret != 0 {
        return ret;
    }
    if i >= (*lb).full {
        fprintf(
            __stderrp,
            b"\x1B[%dm\0" as *const u8 as *const ::core::ffi::c_char,
            31 as ::core::ffi::c_int,
        );
        fprintf(
            __stderrp,
            b"Error: jccc: internal: list index %d out of bounds\n\0" as *const u8
                as *const ::core::ffi::c_char,
            index,
        );
        fprintf(__stderrp, b"\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
        return -(1 as ::core::ffi::c_int);
    }
    let ref mut fresh4 = *(*lb).array.offset(i as isize);
    *fresh4 = value;
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn new_block(mut l: *mut List) -> *mut ListBlock {
    let mut lb: *mut ListBlock = malloc(::core::mem::size_of::<ListBlock>() as size_t)
        as *mut ListBlock;
    if lb.is_null() {
        return 0 as *mut ListBlock;
    }
    (*lb).array = malloc(
        ((*l).blocksize as size_t)
            .wrapping_mul(::core::mem::size_of::<*mut ::core::ffi::c_void>() as size_t),
    ) as *mut *mut ::core::ffi::c_void;
    if (*lb).array.is_null() {
        free(lb as *mut ::core::ffi::c_void);
        return 0 as *mut ListBlock;
    }
    (*lb).full = 0 as ::core::ffi::c_int;
    (*lb).size = (*l).blocksize;
    (*lb).next = 0 as *mut ListBlock;
    return lb;
}
#[no_mangle]
pub unsafe extern "C" fn ladd_element(
    mut l: *mut List,
    mut element: *mut ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    if (*l).head.is_null() {
        (*l).tail = new_block(l);
        (*l).head = (*l).tail;
    }
    let mut lb: *mut ListBlock = (*l).tail;
    if (*lb).full < (*lb).size {
        let fresh0 = (*lb).full;
        (*lb).full = (*lb).full + 1;
        let ref mut fresh1 = *(*lb).array.offset(fresh0 as isize);
        *fresh1 = element;
    } else {
        (*l).tail = new_block(l);
        (*lb).next = (*l).tail as *mut ListBlock;
        lb = (*lb).next as *mut ListBlock;
        let fresh2 = (*lb).full;
        (*lb).full = (*lb).full + 1;
        let ref mut fresh3 = *(*lb).array.offset(fresh2 as isize);
        *fresh3 = element;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn literate(
    mut l: *mut List,
    mut fn_0: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
) -> ::core::ffi::c_int {
    let mut lb: *mut ListBlock = (*l).head;
    let mut acc: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while !lb.is_null() {
        let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while i < (*lb).full {
            acc
                += fn_0
                    .expect(
                        "non-null function pointer",
                    )(*(*lb).array.offset(i as isize));
            i += 1;
        }
        lb = (*lb).next as *mut ListBlock;
    }
    return acc;
}
