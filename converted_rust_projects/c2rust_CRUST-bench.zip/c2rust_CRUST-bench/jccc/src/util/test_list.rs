#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type List;
    fn create_list(blocksize: ::core::ffi::c_int) -> *mut List;
    fn destroy_list(l: *mut List) -> ::core::ffi::c_int;
    fn lget_element(l: *mut List, index: ::core::ffi::c_int) -> *mut ::core::ffi::c_void;
    fn ladd_element(
        l: *mut List,
        element: *mut ::core::ffi::c_void,
    ) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn testing_setup_internal(func_name: *const ::core::ffi::c_char);
    fn testing_cleanup_internal(func_name: *const ::core::ffi::c_char);
}
#[no_mangle]
pub unsafe extern "C" fn basic_100_test() -> ::core::ffi::c_int {
    static mut BS: ::core::ffi::c_int = 10 as ::core::ffi::c_int;
    static mut TS: ::core::ffi::c_int = 100 as ::core::ffi::c_int;
    let mut l: *mut List = create_list(BS) as *mut List;
    if l.is_null() {
        return 0 as ::core::ffi::c_int;
    }
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < TS {
        ladd_element(l, i as *mut ::core::ffi::c_void);
        i += 1;
    }
    let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_0 < TS {
        if lget_element(l, i_0) as ::core::ffi::c_int == i_0 {} else {
            printf(
                b"%s:%u: failed assertion `%s'\n\0" as *const u8
                    as *const ::core::ffi::c_char,
                b"/Users/sourya/work/Tractor/CRUST-bench/datasets/CBench/jccc/src/util/test_list.c\0"
                    as *const u8 as *const ::core::ffi::c_char,
                18 as ::core::ffi::c_int,
                b"(int) lget_element(l, i) == i\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        };
        i_0 += 1;
    }
    destroy_list(l);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_list() -> ::core::ffi::c_int {
    testing_setup_internal(
        ::core::mem::transmute::<[u8; 10], [::core::ffi::c_char; 10]>(*b"test_list\0")
            .as_ptr(),
    );
    basic_100_test();
    testing_cleanup_internal(
        ::core::mem::transmute::<[u8; 10], [::core::ffi::c_char; 10]>(*b"test_list\0")
            .as_ptr(),
    );
    return 0 as ::core::ffi::c_int;
}
