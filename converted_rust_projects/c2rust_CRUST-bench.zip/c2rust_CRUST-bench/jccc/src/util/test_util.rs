#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn test_hash_init() -> ::core::ffi::c_int;
    fn test_hash_init_and_store() -> ::core::ffi::c_int;
    fn test_hash_set_and_get() -> ::core::ffi::c_int;
    fn test_hash_set_and_double_get() -> ::core::ffi::c_int;
    fn testing_setup_internal(func_name: *const ::core::ffi::c_char);
    fn testing_cleanup_internal(func_name: *const ::core::ffi::c_char);
}
#[no_mangle]
pub unsafe extern "C" fn test_util() -> ::core::ffi::c_int {
    testing_setup_internal(
        ::core::mem::transmute::<[u8; 10], [::core::ffi::c_char; 10]>(*b"test_util\0")
            .as_ptr(),
    );
    test_hash_init();
    test_hash_init_and_store();
    test_hash_set_and_get();
    test_hash_set_and_double_get();
    testing_cleanup_internal(
        ::core::mem::transmute::<[u8; 10], [::core::ffi::c_char; 10]>(*b"test_util\0")
            .as_ptr(),
    );
    return 0 as ::core::ffi::c_int;
}
