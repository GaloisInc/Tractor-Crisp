#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(c_variadic, extern_types)]
extern "C" {
    pub type __sFILEX;
    pub type buffer;
    pub type vector;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn vfprintf(
        _: *mut FILE,
        _: *const ::core::ffi::c_char,
        _: va_list,
    ) -> ::core::ffi::c_int;
    fn compile_process_create(
        filename: *const ::core::ffi::c_char,
        filename_out: *const ::core::ffi::c_char,
        flags: ::core::ffi::c_int,
    ) -> *mut compile_process;
    fn compile_process_next_char(lex_process: *mut lex_process) -> ::core::ffi::c_char;
    fn compile_process_peek_char(lex_process: *mut lex_process) -> ::core::ffi::c_char;
    fn compile_process_push_char(lex_process: *mut lex_process, c: ::core::ffi::c_char);
    fn lex_process_create(
        compiler: *mut compile_process,
        functions: *mut lex_process_functions,
        private: *mut ::core::ffi::c_void,
    ) -> *mut lex_process;
    fn lex(process: *mut lex_process) -> ::core::ffi::c_int;
    fn parse(process: *mut compile_process) -> ::core::ffi::c_int;
    fn exit(_: ::core::ffi::c_int) -> !;
}
pub type __builtin_va_list = *mut ::core::ffi::c_char;
pub type __int64_t = i64;
pub type __darwin_va_list = __builtin_va_list;
pub type __darwin_off_t = __int64_t;
pub type va_list = __darwin_va_list;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct pos {
    pub line: ::core::ffi::c_int,
    pub col: ::core::ffi::c_int,
    pub filename: *const ::core::ffi::c_char,
}
pub type C2RustUnnamed = ::core::ffi::c_uint;
pub const LEXICAL_ANALYSIS_INPUT_ERROR: C2RustUnnamed = 1;
pub const LEXICAL_ANALYSIS_ALL_OK: C2RustUnnamed = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct lex_process {
    pub pos: pos,
    pub token_vec: *mut vector,
    pub compiler: *mut compile_process,
    pub current_expression_count: ::core::ffi::c_int,
    pub parentheses_buffer: *mut buffer,
    pub function: *mut lex_process_functions,
    pub private: *mut ::core::ffi::c_void,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct lex_process_functions {
    pub next_char: LEX_PROCESS_NEXT_CHAR,
    pub peek_char: LEX_PROCESS_PEEK_CHAR,
    pub push_char: LEX_PROCESS_PUSH_CHAR,
}
pub type LEX_PROCESS_PUSH_CHAR = Option<
    unsafe extern "C" fn(*mut lex_process, ::core::ffi::c_char) -> (),
>;
pub type LEX_PROCESS_PEEK_CHAR = Option<
    unsafe extern "C" fn(*mut lex_process) -> ::core::ffi::c_char,
>;
pub type LEX_PROCESS_NEXT_CHAR = Option<
    unsafe extern "C" fn(*mut lex_process) -> ::core::ffi::c_char,
>;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct compile_process {
    pub flags: ::core::ffi::c_int,
    pub pos: pos,
    pub cfile: compile_process_input_file,
    pub token_vec: *mut vector,
    pub node_vec: *mut vector,
    pub node_tree_vec: *mut vector,
    pub ofile: *mut FILE,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct compile_process_input_file {
    pub fp: *mut FILE,
    pub abs_path: *const ::core::ffi::c_char,
}
pub type C2RustUnnamed_0 = ::core::ffi::c_uint;
pub const COMPILER_FAILED_WITH_ERRORS: C2RustUnnamed_0 = 1;
pub const COMPILER_FILE_COMPILED_OK: C2RustUnnamed_0 = 0;
pub type C2RustUnnamed_1 = ::core::ffi::c_uint;
pub const PARSE_GENERAL_ERROR: C2RustUnnamed_1 = 1;
pub const PARSE_ALL_OK: C2RustUnnamed_1 = 0;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub static mut compiler_lex_functions: lex_process_functions = unsafe {
    {
        let mut init = lex_process_functions {
            next_char: Some(
                compile_process_next_char
                    as unsafe extern "C" fn(*mut lex_process) -> ::core::ffi::c_char,
            ),
            peek_char: Some(
                compile_process_peek_char
                    as unsafe extern "C" fn(*mut lex_process) -> ::core::ffi::c_char,
            ),
            push_char: Some(
                compile_process_push_char
                    as unsafe extern "C" fn(*mut lex_process, ::core::ffi::c_char) -> (),
            ),
        };
        init
    }
};
#[no_mangle]
pub unsafe extern "C" fn compiler_error(
    mut compiler: *mut compile_process,
    mut msg: *const ::core::ffi::c_char,
    mut args: ...
) {
    let mut args_0: va_list = 0 as *mut ::core::ffi::c_char;
    args_0 = args.clone();
    vfprintf(__stderrp, msg, args_0 as va_list);
    fprintf(
        __stderrp,
        b" on line %i, col %i in file %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*compiler).pos.line,
        (*compiler).pos.col,
        (*compiler).pos.filename,
    );
    exit(-(1 as ::core::ffi::c_int));
}
#[no_mangle]
pub unsafe extern "C" fn compiler_warning(
    mut compiler: *mut compile_process,
    mut msg: *const ::core::ffi::c_char,
    mut args: ...
) {
    let mut args_0: va_list = 0 as *mut ::core::ffi::c_char;
    args_0 = args.clone();
    vfprintf(__stderrp, msg, args_0 as va_list);
    fprintf(
        __stderrp,
        b" on line %i, col %i in file %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*compiler).pos.line,
        (*compiler).pos.col,
        (*compiler).pos.filename,
    );
}
#[no_mangle]
pub unsafe extern "C" fn compile_file(
    mut filename: *const ::core::ffi::c_char,
    mut out_filename: *const ::core::ffi::c_char,
    mut flags: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut process: *mut compile_process = compile_process_create(
        filename,
        out_filename,
        flags,
    );
    if process.is_null() {
        return COMPILER_FAILED_WITH_ERRORS as ::core::ffi::c_int;
    }
    let mut lex_process: *mut lex_process = lex_process_create(
        process,
        &mut compiler_lex_functions,
        NULL,
    );
    if lex_process.is_null() {
        return COMPILER_FAILED_WITH_ERRORS as ::core::ffi::c_int;
    }
    if lex(lex_process) != LEXICAL_ANALYSIS_ALL_OK as ::core::ffi::c_int {
        return COMPILER_FAILED_WITH_ERRORS as ::core::ffi::c_int;
    }
    (*process).token_vec = (*lex_process).token_vec as *mut vector;
    if parse(process) != PARSE_ALL_OK as ::core::ffi::c_int {
        return COMPILER_FAILED_WITH_ERRORS as ::core::ffi::c_int;
    }
    return COMPILER_FILE_COMPILED_OK as ::core::ffi::c_int;
}
