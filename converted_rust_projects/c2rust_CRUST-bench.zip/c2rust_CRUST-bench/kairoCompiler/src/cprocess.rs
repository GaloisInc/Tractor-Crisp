#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    pub type buffer;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn getc(_: *mut FILE) -> ::core::ffi::c_int;
    fn ungetc(_: ::core::ffi::c_int, _: *mut FILE) -> ::core::ffi::c_int;
    fn calloc(__count: size_t, __size: size_t) -> *mut ::core::ffi::c_void;
    fn vector_create(esize: size_t) -> *mut vector;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct pos {
    pub line: ::core::ffi::c_int,
    pub col: ::core::ffi::c_int,
    pub filename: *const ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct lex_process {
    pub pos: pos,
    pub token_vec: *mut vector,
    pub compiler: *mut compile_process,
    pub current_expression_count: ::core::ffi::c_int,
    pub parentheses_buffer: *mut buffer,
    pub function: *mut lex_process_functions,
    pub private: *mut ::core::ffi::c_void,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct lex_process_functions {
    pub next_char: LEX_PROCESS_NEXT_CHAR,
    pub peek_char: LEX_PROCESS_PEEK_CHAR,
    pub push_char: LEX_PROCESS_PUSH_CHAR,
}
pub type LEX_PROCESS_PUSH_CHAR = Option<
    unsafe extern "C" fn(*mut lex_process, ::core::ffi::c_char) -> (),
>;
pub type LEX_PROCESS_PEEK_CHAR = Option<
    unsafe extern "C" fn(*mut lex_process) -> ::core::ffi::c_char,
>;
pub type LEX_PROCESS_NEXT_CHAR = Option<
    unsafe extern "C" fn(*mut lex_process) -> ::core::ffi::c_char,
>;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct compile_process {
    pub flags: ::core::ffi::c_int,
    pub pos: pos,
    pub cfile: compile_process_input_file,
    pub token_vec: *mut vector,
    pub node_vec: *mut vector,
    pub node_tree_vec: *mut vector,
    pub ofile: *mut FILE,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct vector {
    pub data: *mut ::core::ffi::c_void,
    pub pindex: ::core::ffi::c_int,
    pub rindex: ::core::ffi::c_int,
    pub mindex: ::core::ffi::c_int,
    pub count: ::core::ffi::c_int,
    pub flags: ::core::ffi::c_int,
    pub esize: size_t,
    pub saves: *mut vector,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct compile_process_input_file {
    pub fp: *mut FILE,
    pub abs_path: *const ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct node {
    pub type_0: ::core::ffi::c_int,
    pub flags: ::core::ffi::c_int,
    pub pos: pos,
    pub binded: node_binded,
    pub c2rust_unnamed: C2RustUnnamed,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed {
    pub cval: ::core::ffi::c_char,
    pub sval: *const ::core::ffi::c_char,
    pub inum: ::core::ffi::c_uint,
    pub lnum: ::core::ffi::c_ulong,
    pub llnum: ::core::ffi::c_ulonglong,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct node_binded {
    pub owner: *mut node,
    pub function: *mut node,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn compile_process_create(
    mut filename: *const ::core::ffi::c_char,
    mut filename_out: *const ::core::ffi::c_char,
    mut flags: ::core::ffi::c_int,
) -> *mut compile_process {
    let mut file: *mut FILE = fopen(
        filename,
        b"r\0" as *const u8 as *const ::core::ffi::c_char,
    ) as *mut FILE;
    if file.is_null() {
        return 0 as *mut compile_process;
    }
    let mut out_file: *mut FILE = 0 as *mut FILE;
    if !filename_out.is_null() {
        out_file = fopen(filename_out, b"w\0" as *const u8 as *const ::core::ffi::c_char)
            as *mut FILE;
        if out_file.is_null() {
            return 0 as *mut compile_process;
        }
    }
    let mut process: *mut compile_process = calloc(
        1 as size_t,
        ::core::mem::size_of::<compile_process>() as size_t,
    ) as *mut compile_process;
    (*process).node_vec = vector_create(::core::mem::size_of::<*mut node>() as size_t);
    (*process).node_tree_vec = vector_create(
        ::core::mem::size_of::<*mut node>() as size_t,
    );
    (*process).flags = flags;
    (*process).cfile.fp = file;
    (*process).ofile = out_file;
    return process;
}
#[no_mangle]
pub unsafe extern "C" fn compile_process_next_char(
    mut lex_process: *mut lex_process,
) -> ::core::ffi::c_char {
    let mut compiler: *mut compile_process = (*lex_process).compiler
        as *mut compile_process;
    (*compiler).pos.col += 1 as ::core::ffi::c_int;
    let mut c: ::core::ffi::c_char = getc((*compiler).cfile.fp) as ::core::ffi::c_char;
    if c as ::core::ffi::c_int == '\n' as i32 {
        (*compiler).pos.line += 1 as ::core::ffi::c_int;
        (*compiler).pos.col = 1 as ::core::ffi::c_int;
    }
    return c;
}
#[no_mangle]
pub unsafe extern "C" fn compile_process_peek_char(
    mut lex_process: *mut lex_process,
) -> ::core::ffi::c_char {
    let mut compiler: *mut compile_process = (*lex_process).compiler
        as *mut compile_process;
    let mut c: ::core::ffi::c_char = getc((*compiler).cfile.fp) as ::core::ffi::c_char;
    ungetc(c as ::core::ffi::c_int, (*compiler).cfile.fp);
    return c;
}
#[no_mangle]
pub unsafe extern "C" fn compile_process_push_char(
    mut lex_process: *mut lex_process,
    mut c: ::core::ffi::c_char,
) {
    let mut compiler: *mut compile_process = (*lex_process).compiler
        as *mut compile_process;
    ungetc(c as ::core::ffi::c_int, (*compiler).cfile.fp);
}
