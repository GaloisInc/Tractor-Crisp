#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(c_variadic)]
extern "C" {
    fn calloc(__count: size_t, __size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn realloc(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn vsnprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        _: va_list,
    ) -> ::core::ffi::c_int;
}
pub type __builtin_va_list = *mut ::core::ffi::c_char;
pub type __darwin_size_t = usize;
pub type __darwin_va_list = __builtin_va_list;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct buffer {
    pub data: *mut ::core::ffi::c_char,
    pub rindex: ::core::ffi::c_int,
    pub len: ::core::ffi::c_int,
    pub msize: ::core::ffi::c_int,
}
pub type va_list = __darwin_va_list;
pub const BUFFER_REALLOC_AMOUNT: ::core::ffi::c_int = 2000 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn buffer_create() -> *mut buffer {
    let mut buf: *mut buffer = calloc(
        ::core::mem::size_of::<buffer>() as size_t,
        1 as size_t,
    ) as *mut buffer;
    (*buf).data = calloc(BUFFER_REALLOC_AMOUNT as size_t, 1 as size_t)
        as *mut ::core::ffi::c_char;
    (*buf).len = 0 as ::core::ffi::c_int;
    (*buf).msize = BUFFER_REALLOC_AMOUNT;
    return buf;
}
#[no_mangle]
pub unsafe extern "C" fn buffer_extend(mut buffer: *mut buffer, mut size: size_t) {
    (*buffer).data = realloc(
        (*buffer).data as *mut ::core::ffi::c_void,
        ((*buffer).msize as size_t).wrapping_add(size),
    ) as *mut ::core::ffi::c_char;
    (*buffer).msize = ((*buffer).msize as size_t).wrapping_add(size)
        as ::core::ffi::c_int as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn buffer_need(mut buffer: *mut buffer, mut size: size_t) {
    if (*buffer).msize as size_t <= ((*buffer).len as size_t).wrapping_add(size) {
        size = size.wrapping_add(BUFFER_REALLOC_AMOUNT as size_t);
        buffer_extend(buffer, size);
    }
}
#[no_mangle]
pub unsafe extern "C" fn buffer_printf(
    mut buffer: *mut buffer,
    mut fmt: *const ::core::ffi::c_char,
    mut args: ...
) {
    let mut args_0: va_list = 0 as *mut ::core::ffi::c_char;
    args_0 = args.clone();
    let mut index: ::core::ffi::c_int = (*buffer).len;
    let mut len: ::core::ffi::c_int = 2048 as ::core::ffi::c_int;
    buffer_extend(buffer, len as size_t);
    let mut actual_len: ::core::ffi::c_int = vsnprintf(
        &mut *(*buffer).data.offset(index as isize),
        len as size_t,
        fmt,
        args_0 as va_list,
    );
    (*buffer).len += actual_len;
}
#[no_mangle]
pub unsafe extern "C" fn buffer_printf_no_terminator(
    mut buffer: *mut buffer,
    mut fmt: *const ::core::ffi::c_char,
    mut args: ...
) {
    let mut args_0: va_list = 0 as *mut ::core::ffi::c_char;
    args_0 = args.clone();
    let mut index: ::core::ffi::c_int = (*buffer).len;
    let mut len: ::core::ffi::c_int = 2048 as ::core::ffi::c_int;
    buffer_extend(buffer, len as size_t);
    let mut actual_len: ::core::ffi::c_int = vsnprintf(
        &mut *(*buffer).data.offset(index as isize),
        len as size_t,
        fmt,
        args_0 as va_list,
    );
    (*buffer).len += actual_len - 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn buffer_write(
    mut buffer: *mut buffer,
    mut c: ::core::ffi::c_char,
) {
    buffer_need(buffer, ::core::mem::size_of::<::core::ffi::c_char>() as size_t);
    *(*buffer).data.offset((*buffer).len as isize) = c;
    (*buffer).len += 1;
}
#[no_mangle]
pub unsafe extern "C" fn buffer_ptr(
    mut buffer: *mut buffer,
) -> *mut ::core::ffi::c_void {
    return (*buffer).data as *mut ::core::ffi::c_void;
}
#[no_mangle]
pub unsafe extern "C" fn buffer_read(mut buffer: *mut buffer) -> ::core::ffi::c_char {
    if (*buffer).rindex >= (*buffer).len {
        return -(1 as ::core::ffi::c_int) as ::core::ffi::c_char;
    }
    let mut c: ::core::ffi::c_char = *(*buffer).data.offset((*buffer).rindex as isize);
    (*buffer).rindex += 1;
    return c;
}
#[no_mangle]
pub unsafe extern "C" fn buffer_peek(mut buffer: *mut buffer) -> ::core::ffi::c_char {
    if (*buffer).rindex >= (*buffer).len {
        return -(1 as ::core::ffi::c_int) as ::core::ffi::c_char;
    }
    let mut c: ::core::ffi::c_char = *(*buffer).data.offset((*buffer).rindex as isize);
    return c;
}
#[no_mangle]
pub unsafe extern "C" fn buffer_free(mut buffer: *mut buffer) {
    free((*buffer).data as *mut ::core::ffi::c_void);
    free(buffer as *mut ::core::ffi::c_void);
}
