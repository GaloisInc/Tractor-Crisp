#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn calloc(__count: size_t, __size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn realloc(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn fread(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
        __nitems: size_t,
        __stream: *mut FILE,
    ) -> ::core::ffi::c_ulong;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type C2RustUnnamed = ::core::ffi::c_uint;
pub const VECTOR_FLAG_PEEK_DECREMENT: C2RustUnnamed = 1;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct vector {
    pub data: *mut ::core::ffi::c_void,
    pub pindex: ::core::ffi::c_int,
    pub rindex: ::core::ffi::c_int,
    pub mindex: ::core::ffi::c_int,
    pub count: ::core::ffi::c_int,
    pub flags: ::core::ffi::c_int,
    pub esize: size_t,
    pub saves: *mut vector,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const VECTOR_ELEMENT_INCREMENT: ::core::ffi::c_int = 20 as ::core::ffi::c_int;
unsafe extern "C" fn vector_in_bounds_for_at(
    mut vector: *mut vector,
    mut index: ::core::ffi::c_int,
) -> bool {
    return index >= 0 as ::core::ffi::c_int && index < (*vector).rindex;
}
unsafe extern "C" fn vector_in_bounds_for_pop(
    mut vector: *mut vector,
    mut index: ::core::ffi::c_int,
) -> bool {
    return index >= 0 as ::core::ffi::c_int && index < (*vector).mindex;
}
unsafe extern "C" fn vector_assert_bounds_for_pop(
    mut vector: *mut vector,
    mut index: ::core::ffi::c_int,
) {
    if !vector_in_bounds_for_pop(vector, index) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 29],
                [::core::ffi::c_char; 29],
            >(*b"vector_assert_bounds_for_pop\0")
                .as_ptr(),
            b"vector.c\0" as *const u8 as *const ::core::ffi::c_char,
            22 as ::core::ffi::c_int,
            b"vector_in_bounds_for_pop(vector, index)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn vector_create_no_saves(mut esize: size_t) -> *mut vector {
    let mut vector: *mut vector = calloc(
        ::core::mem::size_of::<vector>() as size_t,
        1 as size_t,
    ) as *mut vector;
    (*vector).data = malloc(esize.wrapping_mul(VECTOR_ELEMENT_INCREMENT as size_t));
    (*vector).mindex = VECTOR_ELEMENT_INCREMENT;
    (*vector).rindex = 0 as ::core::ffi::c_int;
    (*vector).pindex = 0 as ::core::ffi::c_int;
    (*vector).esize = esize;
    (*vector).count = 0 as ::core::ffi::c_int;
    return vector;
}
#[no_mangle]
pub unsafe extern "C" fn vector_total_size(mut vector: *mut vector) -> size_t {
    return ((*vector).count as size_t).wrapping_mul((*vector).esize);
}
#[no_mangle]
pub unsafe extern "C" fn vector_element_size(mut vector: *mut vector) -> size_t {
    return (*vector).esize;
}
#[no_mangle]
pub unsafe extern "C" fn vector_clone(mut vector: *mut vector) -> *mut vector {
    let mut new_data_address: *mut ::core::ffi::c_void = calloc(
        (*vector).esize,
        ((*vector).count + VECTOR_ELEMENT_INCREMENT) as size_t,
    );
    memcpy(new_data_address, (*vector).data, vector_total_size(vector));
    let mut new_vec: *mut vector = calloc(
        ::core::mem::size_of::<vector>() as size_t,
        1 as size_t,
    ) as *mut vector;
    memcpy(
        new_vec as *mut ::core::ffi::c_void,
        vector as *const ::core::ffi::c_void,
        ::core::mem::size_of::<vector>() as size_t,
    );
    (*new_vec).data = new_data_address;
    return new_vec;
}
#[no_mangle]
pub unsafe extern "C" fn vector_create(mut esize: size_t) -> *mut vector {
    let mut vec: *mut vector = vector_create_no_saves(esize);
    (*vec).saves = vector_create_no_saves(::core::mem::size_of::<vector>() as size_t);
    return vec;
}
#[no_mangle]
pub unsafe extern "C" fn vector_free(mut vector: *mut vector) {
    free((*vector).data);
    free(vector as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn vector_current_index(
    mut vector: *mut vector,
) -> ::core::ffi::c_int {
    return (*vector).rindex;
}
#[no_mangle]
pub unsafe extern "C" fn vector_resize_for_index(
    mut vector: *mut vector,
    mut start_index: ::core::ffi::c_int,
    mut total_elements: ::core::ffi::c_int,
) {
    if start_index + total_elements < (*vector).mindex {
        return;
    }
    (*vector).data = realloc(
        (*vector).data,
        ((start_index + total_elements + VECTOR_ELEMENT_INCREMENT) as size_t)
            .wrapping_mul((*vector).esize),
    );
    if (*vector).data.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"vector_resize_for_index\0")
                .as_ptr(),
            b"vector.c\0" as *const u8 as *const ::core::ffi::c_char,
            87 as ::core::ffi::c_int,
            b"vector->data\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    (*vector).mindex = start_index + total_elements;
}
#[no_mangle]
pub unsafe extern "C" fn vector_resize_for(
    mut vector: *mut vector,
    mut total_elements: ::core::ffi::c_int,
) {
    vector_resize_for_index(vector, (*vector).rindex, total_elements);
}
#[no_mangle]
pub unsafe extern "C" fn vector_resize(mut vector: *mut vector) {
    vector_resize_for(vector, 0 as ::core::ffi::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn vector_at(
    mut vector: *mut vector,
    mut index: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_void {
    return (*vector)
        .data
        .offset((index as size_t).wrapping_mul((*vector).esize) as isize);
}
#[no_mangle]
pub unsafe extern "C" fn vector_set_peek_pointer(
    mut vector: *mut vector,
    mut index: ::core::ffi::c_int,
) {
    (*vector).pindex = index;
}
#[no_mangle]
pub unsafe extern "C" fn vector_set_peek_pointer_end(mut vector: *mut vector) {
    vector_set_peek_pointer(vector, (*vector).rindex - 1 as ::core::ffi::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn vector_peek_at(
    mut vector: *mut vector,
    mut index: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_void {
    if !vector_in_bounds_for_at(vector, index) {
        return NULL;
    }
    let mut ptr: *mut ::core::ffi::c_void = vector_at(vector, index);
    return ptr;
}
#[no_mangle]
pub unsafe extern "C" fn vector_peek_no_increment(
    mut vector: *mut vector,
) -> *mut ::core::ffi::c_void {
    if !vector_in_bounds_for_at(vector, (*vector).pindex) {
        return NULL;
    }
    let mut ptr: *mut ::core::ffi::c_void = vector_at(vector, (*vector).pindex);
    return ptr;
}
#[no_mangle]
pub unsafe extern "C" fn vector_peek_back(mut vector: *mut vector) {
    (*vector).pindex -= 1;
}
#[no_mangle]
pub unsafe extern "C" fn vector_peek(
    mut vector: *mut vector,
) -> *mut ::core::ffi::c_void {
    let mut ptr: *mut ::core::ffi::c_void = vector_peek_no_increment(vector);
    if ptr.is_null() {
        return NULL;
    }
    if (*vector).flags & VECTOR_FLAG_PEEK_DECREMENT as ::core::ffi::c_int != 0 {
        (*vector).pindex -= 1;
    } else {
        (*vector).pindex += 1;
    }
    return ptr;
}
#[no_mangle]
pub unsafe extern "C" fn vector_set_flag(
    mut vector: *mut vector,
    mut flag: ::core::ffi::c_int,
) {
    (*vector).flags |= flag;
}
#[no_mangle]
pub unsafe extern "C" fn vector_unset_flag(
    mut vector: *mut vector,
    mut flag: ::core::ffi::c_int,
) {
    (*vector).flags &= !flag;
}
#[no_mangle]
pub unsafe extern "C" fn vector_peek_ptr(
    mut vector: *mut vector,
) -> *mut ::core::ffi::c_void {
    let mut ptr: *mut *mut ::core::ffi::c_void = vector_peek(vector)
        as *mut *mut ::core::ffi::c_void;
    if ptr.is_null() {
        return NULL;
    }
    return *ptr;
}
#[no_mangle]
pub unsafe extern "C" fn vector_peek_ptr_at(
    mut vector: *mut vector,
    mut index: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_void {
    if index < 0 as ::core::ffi::c_int || index > (*vector).count {
        return NULL;
    }
    let mut ptr: *mut *mut ::core::ffi::c_void = vector_at(vector, index)
        as *mut *mut ::core::ffi::c_void;
    if ptr.is_null() {
        return NULL;
    }
    return *ptr;
}
#[no_mangle]
pub unsafe extern "C" fn vector_back_ptr(
    mut vector: *mut vector,
) -> *mut ::core::ffi::c_void {
    let mut ptr: *mut *mut ::core::ffi::c_void = vector_back(vector)
        as *mut *mut ::core::ffi::c_void;
    if ptr.is_null() {
        return NULL;
    }
    return *ptr;
}
#[no_mangle]
pub unsafe extern "C" fn vector_save(mut vector: *mut vector) {
    let mut tmp_vec: vector = *vector;
    tmp_vec.saves = 0 as *mut vector;
    vector_push(
        (*vector).saves,
        &mut tmp_vec as *mut vector as *mut ::core::ffi::c_void,
    );
}
#[no_mangle]
pub unsafe extern "C" fn vector_restore(mut vector: *mut vector) {
    let mut save_vec: vector = *(vector_back((*vector).saves) as *mut vector);
    save_vec.saves = (*vector).saves;
    *vector = save_vec;
    vector_pop((*vector).saves);
}
#[no_mangle]
pub unsafe extern "C" fn vector_save_purge(mut vector: *mut vector) {
    vector_pop((*vector).saves);
}
#[no_mangle]
pub unsafe extern "C" fn vector_pop_last_peek(mut vector: *mut vector) {
    if !((*vector).pindex >= 1 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 21],
                [::core::ffi::c_char; 21],
            >(*b"vector_pop_last_peek\0")
                .as_ptr(),
            b"vector.c\0" as *const u8 as *const ::core::ffi::c_char,
            233 as ::core::ffi::c_int,
            b"vector->pindex >= 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    vector_pop_at(vector, (*vector).pindex - 1 as ::core::ffi::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn vector_push(
    mut vector: *mut vector,
    mut elem: *mut ::core::ffi::c_void,
) {
    let mut ptr: *mut ::core::ffi::c_void = vector_at(vector, (*vector).rindex);
    memcpy(ptr, elem, (*vector).esize);
    (*vector).rindex += 1;
    (*vector).count += 1;
    if (*vector).rindex >= (*vector).mindex {
        vector_resize(vector);
    }
}
#[no_mangle]
pub unsafe extern "C" fn vector_fread(
    mut vector: *mut vector,
    mut amount: ::core::ffi::c_int,
    mut fp: *mut FILE,
) -> ::core::ffi::c_int {
    let mut read_amount: size_t = fread((*vector).data, 1 as size_t, 1 as size_t, fp)
        as size_t;
    while read_amount != 0 {
        vector_push(vector, &mut read_amount as *mut size_t as *mut ::core::ffi::c_void);
        read_amount = fread((*vector).data, 1 as size_t, 1 as size_t, fp) as size_t;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn vector_string(
    mut vec: *mut vector,
) -> *const ::core::ffi::c_char {
    return (*vec).data as *const ::core::ffi::c_char;
}
#[no_mangle]
pub unsafe extern "C" fn vector_data_end(
    mut vector: *mut vector,
) -> *mut ::core::ffi::c_void {
    return (*vector)
        .data
        .offset(((*vector).rindex as size_t).wrapping_mul((*vector).esize) as isize);
}
#[no_mangle]
pub unsafe extern "C" fn vector_elements_left(
    mut vector: *mut vector,
    mut index: ::core::ffi::c_int,
) -> size_t {
    return ((*vector).count - index) as size_t;
}
#[no_mangle]
pub unsafe extern "C" fn vector_elements_until_end(
    mut vector: *mut vector,
    mut index: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    return (*vector).count - index;
}
#[no_mangle]
pub unsafe extern "C" fn vector_shift_right_in_bounds_no_increment(
    mut vector: *mut vector,
    mut index: ::core::ffi::c_int,
    mut amount: ::core::ffi::c_int,
) {
    vector_resize_for_index(vector, index, amount);
    let mut eindex: ::core::ffi::c_int = index + amount;
    let mut bytes_to_move: size_t = (vector_elements_until_end(vector, index) as size_t)
        .wrapping_mul((*vector).esize);
    memcpy(vector_at(vector, eindex), vector_at(vector, index), bytes_to_move);
    memset(
        vector_at(vector, index),
        0 as ::core::ffi::c_int,
        (amount as size_t).wrapping_mul((*vector).esize),
    );
}
#[no_mangle]
pub unsafe extern "C" fn vector_shift_right_in_bounds(
    mut vector: *mut vector,
    mut index: ::core::ffi::c_int,
    mut amount: ::core::ffi::c_int,
) {
    vector_shift_right_in_bounds_no_increment(vector, index, amount);
    (*vector).rindex += amount;
    (*vector).count += amount;
}
#[no_mangle]
pub unsafe extern "C" fn vector_stretch(
    mut vector: *mut vector,
    mut index: ::core::ffi::c_int,
) {
    if index < (*vector).rindex {
        return;
    }
    vector_resize_for_index(vector, index, 0 as ::core::ffi::c_int);
    (*vector).count = index;
    (*vector).rindex = index;
}
#[no_mangle]
pub unsafe extern "C" fn vector_pop_value(
    mut vector: *mut vector,
    mut val: *mut ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    let mut old_pp: ::core::ffi::c_int = (*vector).pindex;
    vector_set_peek_pointer(vector, 0 as ::core::ffi::c_int);
    let mut ptr: *mut ::core::ffi::c_void = vector_peek_ptr(vector);
    let mut index: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while !ptr.is_null() {
        if ptr == val {
            vector_pop_at(vector, index);
            break;
        } else {
            ptr = vector_peek_ptr(vector);
            index += 1;
        }
    }
    vector_set_peek_pointer(vector, old_pp);
    panic!("Reached end of non-void function without returning");
}
#[no_mangle]
pub unsafe extern "C" fn vector_pop_at_data_address(
    mut vector: *mut vector,
    mut address: *mut ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    let mut index: ::core::ffi::c_int = (address.offset_from((*vector).data)
        as ::core::ffi::c_long as size_t)
        .wrapping_div((*vector).esize) as ::core::ffi::c_int;
    vector_pop_at(vector, index);
    return index;
}
#[no_mangle]
pub unsafe extern "C" fn vector_shift_right(
    mut vector: *mut vector,
    mut index: ::core::ffi::c_int,
    mut amount: ::core::ffi::c_int,
) {
    if index < (*vector).rindex {
        vector_shift_right_in_bounds(vector, index, amount);
        return;
    }
    vector_stretch(vector, index + amount);
    vector_shift_right_in_bounds_no_increment(vector, index, amount);
}
#[no_mangle]
pub unsafe extern "C" fn vector_pop_at(
    mut vector: *mut vector,
    mut index: ::core::ffi::c_int,
) {
    let mut dst_pos: *mut ::core::ffi::c_void = vector_at(vector, index);
    let mut next_element_pos: *mut ::core::ffi::c_void = dst_pos
        .offset((*vector).esize as isize);
    let mut end_pos: *mut ::core::ffi::c_void = vector_data_end(vector);
    let mut total: size_t = (end_pos as size_t).wrapping_sub(next_element_pos as size_t);
    memcpy(dst_pos, next_element_pos, total);
    (*vector).count -= 1 as ::core::ffi::c_int;
    (*vector).rindex -= 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn vector_peek_pop(mut vector: *mut vector) {
    vector_pop_at(vector, (*vector).pindex);
}
#[no_mangle]
pub unsafe extern "C" fn vector_push_multiple_at(
    mut vector: *mut vector,
    mut dst_index: ::core::ffi::c_int,
    mut ptr: *mut ::core::ffi::c_void,
    mut total: ::core::ffi::c_int,
) {
    vector_shift_right(vector, dst_index, total);
    let mut dst_ptr: *mut ::core::ffi::c_void = vector_at(vector, dst_index);
    let mut total_bytes: size_t = (total as size_t).wrapping_mul((*vector).esize);
    memcpy(dst_ptr, ptr, total_bytes);
}
#[no_mangle]
pub unsafe extern "C" fn vector_push_at(
    mut vector: *mut vector,
    mut index: ::core::ffi::c_int,
    mut ptr: *mut ::core::ffi::c_void,
) {
    vector_shift_right(vector, index, 1 as ::core::ffi::c_int);
    let mut data_ptr: *mut ::core::ffi::c_void = vector_at(vector, index);
    memcpy(data_ptr, ptr, (*vector).esize);
}
#[no_mangle]
pub unsafe extern "C" fn vector_insert(
    mut vector_dst: *mut vector,
    mut vector_src: *mut vector,
    mut dst_index: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    if (*vector_dst).esize != (*vector_src).esize {
        return -(1 as ::core::ffi::c_int);
    }
    vector_push_multiple_at(
        vector_dst,
        dst_index,
        vector_at(vector_src, 0 as ::core::ffi::c_int),
        vector_count(vector_src),
    );
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn vector_pop(mut vector: *mut vector) {
    (*vector).rindex -= 1 as ::core::ffi::c_int;
    (*vector).count -= 1 as ::core::ffi::c_int;
    vector_assert_bounds_for_pop(vector, (*vector).rindex);
}
#[no_mangle]
pub unsafe extern "C" fn vector_data_ptr(
    mut vector: *mut vector,
) -> *mut ::core::ffi::c_void {
    return (*vector).data;
}
#[no_mangle]
pub unsafe extern "C" fn vector_empty(mut vector: *mut vector) -> bool {
    return vector_count(vector) == 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn vector_clear(mut vector: *mut vector) {
    while vector_count(vector) != 0 {
        vector_pop(vector);
    }
}
#[no_mangle]
pub unsafe extern "C" fn vector_back_or_null(
    mut vector: *mut vector,
) -> *mut ::core::ffi::c_void {
    if !vector_in_bounds_for_at(vector, (*vector).rindex - 1 as ::core::ffi::c_int) {
        return NULL;
    }
    return vector_at(vector, (*vector).rindex - 1 as ::core::ffi::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn vector_back_ptr_or_null(
    mut vector: *mut vector,
) -> *mut ::core::ffi::c_void {
    let mut ptr: *mut *mut ::core::ffi::c_void = vector_back_or_null(vector)
        as *mut *mut ::core::ffi::c_void;
    if !ptr.is_null() {
        return *ptr;
    }
    return NULL;
}
#[no_mangle]
pub unsafe extern "C" fn vector_back(
    mut vector: *mut vector,
) -> *mut ::core::ffi::c_void {
    vector_assert_bounds_for_pop(vector, (*vector).rindex - 1 as ::core::ffi::c_int);
    return vector_at(vector, (*vector).rindex - 1 as ::core::ffi::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn vector_count(mut vector: *mut vector) -> ::core::ffi::c_int {
    return (*vector).count;
}
