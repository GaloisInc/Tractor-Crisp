#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types, linkage)]
extern "C" {
    pub type __sFILEX;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn compiler_error(
        compiler: *mut compile_process,
        msg: *const ::core::ffi::c_char,
        ...
    );
    fn lex_process_create(
        compiler: *mut compile_process,
        functions: *mut lex_process_functions,
        private: *mut ::core::ffi::c_void,
    ) -> *mut lex_process;
    fn lex_process_private(process: *mut lex_process) -> *mut ::core::ffi::c_void;
    fn token_is_keyword(token: *mut token, value: *const ::core::ffi::c_char) -> bool;
    fn atoll(_: *const ::core::ffi::c_char) -> ::core::ffi::c_longlong;
    fn strtol(
        __str: *const ::core::ffi::c_char,
        __endptr: *mut *mut ::core::ffi::c_char,
        __base: ::core::ffi::c_int,
    ) -> ::core::ffi::c_long;
    fn vector_push(vector: *mut vector, elem: *mut ::core::ffi::c_void);
    fn vector_pop(vector: *mut vector);
    fn vector_back_or_null(vector: *mut vector) -> *mut ::core::ffi::c_void;
    fn buffer_create() -> *mut buffer;
    fn buffer_read(buffer: *mut buffer) -> ::core::ffi::c_char;
    fn buffer_peek(buffer: *mut buffer) -> ::core::ffi::c_char;
    fn buffer_printf(buffer: *mut buffer, fmt: *const ::core::ffi::c_char, ...);
    fn buffer_write(buffer: *mut buffer, c: ::core::ffi::c_char);
    fn buffer_ptr(buffer: *mut buffer) -> *mut ::core::ffi::c_void;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    static mut _DefaultRuneLocale: _RuneLocale;
    fn __maskrune(_: __darwin_ct_rune_t, _: ::core::ffi::c_ulong) -> ::core::ffi::c_int;
    fn __tolower(_: __darwin_ct_rune_t) -> __darwin_ct_rune_t;
}
pub type __uint32_t = u32;
pub type __int64_t = i64;
pub type __darwin_ct_rune_t = ::core::ffi::c_int;
pub type __darwin_size_t = usize;
pub type __darwin_wchar_t = ::libc::wchar_t;
pub type __darwin_rune_t = __darwin_wchar_t;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct pos {
    pub line: ::core::ffi::c_int,
    pub col: ::core::ffi::c_int,
    pub filename: *const ::core::ffi::c_char,
}
pub type C2RustUnnamed = ::core::ffi::c_uint;
pub const LEXICAL_ANALYSIS_INPUT_ERROR: C2RustUnnamed = 1;
pub const LEXICAL_ANALYSIS_ALL_OK: C2RustUnnamed = 0;
pub type C2RustUnnamed_0 = ::core::ffi::c_uint;
pub const TOKEN_TYPE_NEWLINE: C2RustUnnamed_0 = 7;
pub const TOKEN_TYPE_COMMENT: C2RustUnnamed_0 = 6;
pub const TOKEN_TYPE_STRING: C2RustUnnamed_0 = 5;
pub const TOKEN_TYPE_NUMBER: C2RustUnnamed_0 = 4;
pub const TOKEN_TYPE_SYMBOL: C2RustUnnamed_0 = 3;
pub const TOKEN_TYPE_OPERATOR: C2RustUnnamed_0 = 2;
pub const TOKEN_TYPE_KEYWORD: C2RustUnnamed_0 = 1;
pub const TOKEN_TYPE_IDENTIFIER: C2RustUnnamed_0 = 0;
pub type C2RustUnnamed_1 = ::core::ffi::c_uint;
pub const NUMBER_TYPE_DOUBLE: C2RustUnnamed_1 = 3;
pub const NUMBER_TYPE_FLOAT: C2RustUnnamed_1 = 2;
pub const NUMBER_TYPE_LONG: C2RustUnnamed_1 = 1;
pub const NUMBER_TYPE_NORMAL: C2RustUnnamed_1 = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct token {
    pub type_0: ::core::ffi::c_int,
    pub flags: ::core::ffi::c_int,
    pub pos: pos,
    pub c2rust_unnamed: C2RustUnnamed_2,
    pub num: token_number,
    pub whitespace: bool,
    pub between_brackets: *const ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct token_number {
    pub type_0: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed_2 {
    pub cval: ::core::ffi::c_char,
    pub sval: *const ::core::ffi::c_char,
    pub inum: ::core::ffi::c_uint,
    pub lnum: ::core::ffi::c_ulong,
    pub llnum: ::core::ffi::c_ulonglong,
    pub any: *mut ::core::ffi::c_void,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct lex_process {
    pub pos: pos,
    pub token_vec: *mut vector,
    pub compiler: *mut compile_process,
    pub current_expression_count: ::core::ffi::c_int,
    pub parentheses_buffer: *mut buffer,
    pub function: *mut lex_process_functions,
    pub private: *mut ::core::ffi::c_void,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct lex_process_functions {
    pub next_char: LEX_PROCESS_NEXT_CHAR,
    pub peek_char: LEX_PROCESS_PEEK_CHAR,
    pub push_char: LEX_PROCESS_PUSH_CHAR,
}
pub type LEX_PROCESS_PUSH_CHAR = Option<
    unsafe extern "C" fn(*mut lex_process, ::core::ffi::c_char) -> (),
>;
pub type LEX_PROCESS_PEEK_CHAR = Option<
    unsafe extern "C" fn(*mut lex_process) -> ::core::ffi::c_char,
>;
pub type LEX_PROCESS_NEXT_CHAR = Option<
    unsafe extern "C" fn(*mut lex_process) -> ::core::ffi::c_char,
>;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct buffer {
    pub data: *mut ::core::ffi::c_char,
    pub rindex: ::core::ffi::c_int,
    pub len: ::core::ffi::c_int,
    pub msize: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct compile_process {
    pub flags: ::core::ffi::c_int,
    pub pos: pos,
    pub cfile: compile_process_input_file,
    pub token_vec: *mut vector,
    pub node_vec: *mut vector,
    pub node_tree_vec: *mut vector,
    pub ofile: *mut FILE,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct vector {
    pub data: *mut ::core::ffi::c_void,
    pub pindex: ::core::ffi::c_int,
    pub rindex: ::core::ffi::c_int,
    pub mindex: ::core::ffi::c_int,
    pub count: ::core::ffi::c_int,
    pub flags: ::core::ffi::c_int,
    pub esize: size_t,
    pub saves: *mut vector,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct compile_process_input_file {
    pub fp: *mut FILE,
    pub abs_path: *const ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneLocale {
    pub __magic: [::core::ffi::c_char; 8],
    pub __encoding: [::core::ffi::c_char; 32],
    pub __sgetrune: Option<
        unsafe extern "C" fn(
            *const ::core::ffi::c_char,
            __darwin_size_t,
            *mut *const ::core::ffi::c_char,
        ) -> __darwin_rune_t,
    >,
    pub __sputrune: Option<
        unsafe extern "C" fn(
            __darwin_rune_t,
            *mut ::core::ffi::c_char,
            __darwin_size_t,
            *mut *mut ::core::ffi::c_char,
        ) -> ::core::ffi::c_int,
    >,
    pub __invalid_rune: __darwin_rune_t,
    pub __runetype: [__uint32_t; 256],
    pub __maplower: [__darwin_rune_t; 256],
    pub __mapupper: [__darwin_rune_t; 256],
    pub __runetype_ext: _RuneRange,
    pub __maplower_ext: _RuneRange,
    pub __mapupper_ext: _RuneRange,
    pub __variable: *mut ::core::ffi::c_void,
    pub __variable_len: ::core::ffi::c_int,
    pub __ncharclasses: ::core::ffi::c_int,
    pub __charclasses: *mut _RuneCharClass,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneCharClass {
    pub __name: [::core::ffi::c_char; 14],
    pub __mask: __uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneRange {
    pub __nranges: ::core::ffi::c_int,
    pub __ranges: *mut _RuneEntry,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneEntry {
    pub __min: __darwin_rune_t,
    pub __max: __darwin_rune_t,
    pub __map: __darwin_rune_t,
    pub __types: *mut __uint32_t,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const EOF: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const _CTYPE_A: ::core::ffi::c_long = 0x100 as ::core::ffi::c_long;
#[inline]
unsafe extern "C" fn isascii(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return (_c & !(0x7f as ::core::ffi::c_int) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn __istype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> ::core::ffi::c_int {
    return if isascii(_c as ::core::ffi::c_int) != 0 {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    } else {
        (__maskrune(_c, _f) != 0) as ::core::ffi::c_int
    };
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isalpha(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_A as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn tolower(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __tolower(_c as __darwin_ct_rune_t) as ::core::ffi::c_int;
}
static mut lex_process: *mut lex_process = 0 as *const lex_process as *mut lex_process;
static mut tmp_token: token = token {
    type_0: 0,
    flags: 0,
    pos: pos {
        line: 0,
        col: 0,
        filename: 0 as *const ::core::ffi::c_char,
    },
    c2rust_unnamed: C2RustUnnamed_2 { cval: 0 },
    num: token_number { type_0: 0 },
    whitespace: false,
    between_brackets: 0 as *const ::core::ffi::c_char,
};
unsafe extern "C" fn peekc() -> ::core::ffi::c_char {
    return (*(*lex_process).function)
        .peek_char
        .expect("non-null function pointer")(lex_process);
}
unsafe extern "C" fn nextc() -> ::core::ffi::c_char {
    let mut c: ::core::ffi::c_char = (*(*lex_process).function)
        .next_char
        .expect("non-null function pointer")(lex_process);
    if lex_is_in_expression() {
        buffer_write((*lex_process).parentheses_buffer as *mut buffer, c);
    }
    (*lex_process).pos.col += 1 as ::core::ffi::c_int;
    if c as ::core::ffi::c_int == '\n' as i32 {
        (*lex_process).pos.line += 1 as ::core::ffi::c_int;
        (*lex_process).pos.col = 1 as ::core::ffi::c_int;
    }
    return c;
}
unsafe extern "C" fn pushc(mut c: ::core::ffi::c_char) {
    (*(*lex_process).function)
        .push_char
        .expect("non-null function pointer")(lex_process, c);
}
unsafe extern "C" fn assert_next_char(
    mut c: ::core::ffi::c_char,
) -> ::core::ffi::c_char {
    let mut next_c: ::core::ffi::c_char = nextc();
    if !(c as ::core::ffi::c_int == next_c as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 17],
                [::core::ffi::c_char; 17],
            >(*b"assert_next_char\0")
                .as_ptr(),
            b"lexer.c\0" as *const u8 as *const ::core::ffi::c_char,
            49 as ::core::ffi::c_int,
            b"c == next_c\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return next_c;
}
unsafe extern "C" fn lex_file_position() -> pos {
    return (*lex_process).pos;
}
#[no_mangle]
pub unsafe extern "C" fn token_create(mut _token: *mut token) -> *mut token {
    memcpy(
        &mut tmp_token as *mut token as *mut ::core::ffi::c_void,
        _token as *const ::core::ffi::c_void,
        ::core::mem::size_of::<token>() as size_t,
    );
    tmp_token.pos = lex_file_position();
    if lex_is_in_expression() {
        tmp_token.between_brackets = buffer_ptr(
            (*lex_process).parentheses_buffer as *mut buffer,
        ) as *const ::core::ffi::c_char;
    }
    return &mut tmp_token;
}
unsafe extern "C" fn lexer_last_token() -> *mut token {
    return vector_back_or_null((*lex_process).token_vec as *mut vector) as *mut token;
}
unsafe extern "C" fn handle_whitespace() -> *mut token {
    let mut last_token: *mut token = lexer_last_token();
    if !last_token.is_null() {
        (*last_token).whitespace = true_0 != 0;
    }
    nextc();
    return read_next_token();
}
#[no_mangle]
pub unsafe extern "C" fn read_number_str() -> *const ::core::ffi::c_char {
    let mut num: *const ::core::ffi::c_char = 0 as *const ::core::ffi::c_char;
    let mut buffer: *mut buffer = buffer_create();
    let mut c: ::core::ffi::c_char = peekc();
    c = peekc();
    while c as ::core::ffi::c_int >= '0' as i32 && c as ::core::ffi::c_int <= '9' as i32
    {
        buffer_write(buffer, c);
        nextc();
        c = peekc();
    }
    buffer_write(buffer, 0 as ::core::ffi::c_char);
    return buffer_ptr(buffer) as *const ::core::ffi::c_char;
}
#[no_mangle]
pub unsafe extern "C" fn read_number() -> ::core::ffi::c_ulonglong {
    let mut s: *const ::core::ffi::c_char = read_number_str();
    return atoll(s) as ::core::ffi::c_ulonglong;
}
#[no_mangle]
pub unsafe extern "C" fn lexer_number_type(
    mut c: ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut res: ::core::ffi::c_int = NUMBER_TYPE_NORMAL as ::core::ffi::c_int;
    if c as ::core::ffi::c_int == 'L' as i32 {
        res = NUMBER_TYPE_LONG as ::core::ffi::c_int;
    } else if c as ::core::ffi::c_int == 'f' as i32 {
        res = NUMBER_TYPE_FLOAT as ::core::ffi::c_int;
    }
    return res;
}
#[no_mangle]
pub unsafe extern "C" fn token_make_number_for_value(
    mut number: ::core::ffi::c_ulong,
) -> *mut token {
    let mut number_type: ::core::ffi::c_int = lexer_number_type(peekc());
    if number_type != NUMBER_TYPE_NORMAL as ::core::ffi::c_int {
        nextc();
    }
    let mut fresh5: token = {
        let mut init = token {
            type_0: TOKEN_TYPE_NUMBER as ::core::ffi::c_int,
            flags: 0,
            pos: pos {
                line: 0,
                col: 0,
                filename: 0 as *const ::core::ffi::c_char,
            },
            c2rust_unnamed: C2RustUnnamed_2 {
                llnum: number as ::core::ffi::c_ulonglong,
            },
            num: {
                let mut init = token_number {
                    type_0: number_type,
                };
                init
            },
            whitespace: false,
            between_brackets: 0 as *const ::core::ffi::c_char,
        };
        init
    };
    return token_create(&mut fresh5);
}
#[no_mangle]
pub unsafe extern "C" fn token_make_number() -> *mut token {
    return token_make_number_for_value(read_number() as ::core::ffi::c_ulong);
}
#[no_mangle]
pub unsafe extern "C" fn token_make_string(
    mut start_delim: ::core::ffi::c_char,
    mut end_delim: ::core::ffi::c_char,
) -> *mut token {
    let mut buf: *mut buffer = buffer_create();
    if !(nextc() as ::core::ffi::c_int == start_delim as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 18],
                [::core::ffi::c_char; 18],
            >(*b"token_make_string\0")
                .as_ptr(),
            b"lexer.c\0" as *const u8 as *const ::core::ffi::c_char,
            129 as ::core::ffi::c_int,
            b"nextc() == start_delim\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut c: ::core::ffi::c_char = nextc();
    while c as ::core::ffi::c_int != end_delim as ::core::ffi::c_int
        && c as ::core::ffi::c_int != EOF
    {
        if !(c as ::core::ffi::c_int == '\\' as i32) {
            buffer_write(buf, c);
        }
        c = nextc();
    }
    buffer_write(buf, 0 as ::core::ffi::c_char);
    let mut fresh3: token = {
        let mut init = token {
            type_0: TOKEN_TYPE_STRING as ::core::ffi::c_int,
            flags: 0,
            pos: pos {
                line: 0,
                col: 0,
                filename: 0 as *const ::core::ffi::c_char,
            },
            c2rust_unnamed: C2RustUnnamed_2 {
                sval: (buffer_ptr
                    as unsafe extern "C" fn(
                        *mut buffer,
                    ) -> *mut ::core::ffi::c_void)(buf) as *const ::core::ffi::c_char,
            },
            num: token_number { type_0: 0 },
            whitespace: false,
            between_brackets: 0 as *const ::core::ffi::c_char,
        };
        init
    };
    return token_create(&mut fresh3);
}
unsafe extern "C" fn op_treated_as_one(mut op: ::core::ffi::c_char) -> bool {
    return op as ::core::ffi::c_int == '(' as i32
        || op as ::core::ffi::c_int == '[' as i32
        || op as ::core::ffi::c_int == ',' as i32
        || op as ::core::ffi::c_int == '.' as i32
        || op as ::core::ffi::c_int == '*' as i32
        || op as ::core::ffi::c_int == '?' as i32;
}
unsafe extern "C" fn is_single_operator(mut op: ::core::ffi::c_char) -> bool {
    return op as ::core::ffi::c_int == '+' as i32
        || op as ::core::ffi::c_int == '-' as i32
        || op as ::core::ffi::c_int == '/' as i32
        || op as ::core::ffi::c_int == '*' as i32
        || op as ::core::ffi::c_int == '=' as i32
        || op as ::core::ffi::c_int == '>' as i32
        || op as ::core::ffi::c_int == '<' as i32
        || op as ::core::ffi::c_int == '|' as i32
        || op as ::core::ffi::c_int == '&' as i32
        || op as ::core::ffi::c_int == '^' as i32
        || op as ::core::ffi::c_int == '%' as i32
        || op as ::core::ffi::c_int == '~' as i32
        || op as ::core::ffi::c_int == '!' as i32
        || op as ::core::ffi::c_int == '(' as i32
        || op as ::core::ffi::c_int == '[' as i32
        || op as ::core::ffi::c_int == ',' as i32
        || op as ::core::ffi::c_int == '.' as i32
        || op as ::core::ffi::c_int == '?' as i32;
}
#[no_mangle]
pub unsafe extern "C" fn op_valid(mut op: *mut ::core::ffi::c_char) -> bool {
    return !op.is_null()
        && !(b"+\0" as *const u8 as *const ::core::ffi::c_char).is_null()
        && strcmp(op, b"+\0" as *const u8 as *const ::core::ffi::c_char)
            == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"-\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"-\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"*\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"*\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"/\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"/\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"!\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"!\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"^\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"^\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"+=\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"+=\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"-=\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"-=\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"*=\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"*=\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"/=\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"/=\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b">>\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b">>\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"<<\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"<<\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b">=\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b">=\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"<=\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"<=\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b">\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b">\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"<\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"<\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"||\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"||\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"&&\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"&&\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"|\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"|\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"&\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"&\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"++\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"++\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"--\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"--\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"= \0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"= \0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"!=\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"!=\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"==\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"==\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"->\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"->\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"(\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"(\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"[\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"[\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b",\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b",\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b".\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b".\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"...\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"...\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"~\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"~\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"?\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"?\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !op.is_null()
            && !(b"%\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(op, b"%\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn read_op_flush_back_keep_first(mut buffer: *mut buffer) {
    let mut data: *const ::core::ffi::c_char = buffer_ptr(buffer)
        as *const ::core::ffi::c_char;
    let mut len: ::core::ffi::c_int = (*buffer).len;
    let mut i: ::core::ffi::c_int = len - 1 as ::core::ffi::c_int;
    while i >= 1 as ::core::ffi::c_int {
        if !(*data.offset(i as isize) as ::core::ffi::c_int == 0 as ::core::ffi::c_int) {
            pushc(*data.offset(i as isize));
        }
        i -= 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn read_op() -> *const ::core::ffi::c_char {
    let mut single_operator: bool = true_0 != 0;
    let mut op: ::core::ffi::c_char = nextc();
    let mut buffer: *mut buffer = buffer_create();
    buffer_write(buffer, op);
    if !op_treated_as_one(op) {
        op = peekc();
        if is_single_operator(op) {
            buffer_write(buffer, op);
            nextc();
            single_operator = false_0 != 0;
        }
    }
    buffer_write(buffer, 0 as ::core::ffi::c_char);
    let mut ptr: *mut ::core::ffi::c_char = buffer_ptr(buffer)
        as *mut ::core::ffi::c_char;
    if !single_operator {
        if !op_valid(ptr) {
            read_op_flush_back_keep_first(buffer);
            *ptr.offset(1 as ::core::ffi::c_int as isize) = 0 as ::core::ffi::c_char;
        }
    } else if Some(op_valid as unsafe extern "C" fn(*mut ::core::ffi::c_char) -> bool)
        .is_none()
    {
        compiler_error(
            (*lex_process).compiler as *mut compile_process,
            b"The operator %s is not valid\n\0" as *const u8
                as *const ::core::ffi::c_char,
            ptr,
        );
    }
    panic!("Reached end of non-void function without returning");
}
unsafe extern "C" fn lex_new_expression() {
    (*lex_process).current_expression_count += 1;
    if (*lex_process).current_expression_count == 1 as ::core::ffi::c_int {
        (*lex_process).parentheses_buffer = buffer_create() as *mut buffer;
    }
}
unsafe extern "C" fn lex_finish_expression() {
    (*lex_process).current_expression_count -= 1;
    if (*lex_process).current_expression_count < 0 as ::core::ffi::c_int {
        compiler_error(
            (*lex_process).compiler as *mut compile_process,
            b"You closed an expression that you never opened\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
}
#[no_mangle]
pub unsafe extern "C" fn lex_is_in_expression() -> bool {
    return (*lex_process).current_expression_count > 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn is_keyword(mut str: *const ::core::ffi::c_char) -> bool {
    return !str.is_null()
        && !(b"auto\0" as *const u8 as *const ::core::ffi::c_char).is_null()
        && strcmp(str, b"auto\0" as *const u8 as *const ::core::ffi::c_char)
            == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"break\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"break\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"case\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"case\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"char\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"char\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"const\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"const\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"continue\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"continue\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"default\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"default\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"do\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"do\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"double\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"double\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"else\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"else\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"enum\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"enum\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"extern\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"extern\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"float\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"float\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"for\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"for\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"goto\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"goto\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"if\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"if\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"inline\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"inline\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"int\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"int\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"long\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"long\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"register\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"register\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"restrict\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"restrict\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"return\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"return\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"short\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"short\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"signed\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"signed\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"sizeof\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"sizeof\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"static\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"static\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"struct\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"struct\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"switch\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"switch\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"typedef\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"typedef\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"union\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"union\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"unsigned\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"unsigned\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"void\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"void\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"volatile\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"volatile\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"while\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"while\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"_Alignas\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"_Alignas\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"_Alignof\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"_Alignof\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"_Atomic\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"_Atomic\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"_Bool\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"_Bool\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"_Complex\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"_Complex\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"_Generic\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"_Generic\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"_Imaginary\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"_Imaginary\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"_Noreturn\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"_Noreturn\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"_Static_assert\0" as *const u8 as *const ::core::ffi::c_char)
                .is_null()
            && strcmp(
                str,
                b"_Static_assert\0" as *const u8 as *const ::core::ffi::c_char,
            ) == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"_Thread_local\0" as *const u8 as *const ::core::ffi::c_char).is_null()
            && strcmp(str, b"_Thread_local\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
        || !str.is_null()
            && !(b"__ignore_typecheck\0" as *const u8 as *const ::core::ffi::c_char)
                .is_null()
            && strcmp(
                str,
                b"__ignore_typecheck\0" as *const u8 as *const ::core::ffi::c_char,
            ) == 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn token_make_operator_or_string() -> *mut token {
    let mut op: ::core::ffi::c_char = peekc();
    if op as ::core::ffi::c_int == '<' as i32 {
        let mut last_token: *mut token = lexer_last_token();
        if token_is_keyword(
            last_token,
            b"include\0" as *const u8 as *const ::core::ffi::c_char,
        ) {
            return token_make_string(
                '<' as i32 as ::core::ffi::c_char,
                '>' as i32 as ::core::ffi::c_char,
            );
        }
    }
    let mut fresh7: token = {
        let mut init = token {
            type_0: TOKEN_TYPE_OPERATOR as ::core::ffi::c_int,
            flags: 0,
            pos: pos {
                line: 0,
                col: 0,
                filename: 0 as *const ::core::ffi::c_char,
            },
            c2rust_unnamed: C2RustUnnamed_2 {
                sval: ::core::mem::transmute::<
                    unsafe extern "C" fn() -> *const ::core::ffi::c_char,
                    unsafe extern "C" fn() -> *const ::core::ffi::c_char,
                >(read_op)(),
            },
            num: token_number { type_0: 0 },
            whitespace: false,
            between_brackets: 0 as *const ::core::ffi::c_char,
        };
        init
    };
    let mut token: *mut token = token_create(&mut fresh7);
    if op as ::core::ffi::c_int == '(' as i32 {
        lex_new_expression();
    }
    return token;
}
unsafe extern "C" fn token_make_symbol() -> *mut token {
    let mut c: ::core::ffi::c_char = nextc();
    if c as ::core::ffi::c_int == ')' as i32 {
        lex_finish_expression();
    }
    let mut fresh6: token = {
        let mut init = token {
            type_0: TOKEN_TYPE_SYMBOL as ::core::ffi::c_int,
            flags: 0,
            pos: pos {
                line: 0,
                col: 0,
                filename: 0 as *const ::core::ffi::c_char,
            },
            c2rust_unnamed: C2RustUnnamed_2 { cval: c },
            num: token_number { type_0: 0 },
            whitespace: false,
            between_brackets: 0 as *const ::core::ffi::c_char,
        };
        init
    };
    let mut token: *mut token = token_create(&mut fresh6);
    return token;
}
unsafe extern "C" fn token_make_identifier_or_keyword() -> *mut token {
    let mut buffer: *mut buffer = buffer_create();
    let mut c: ::core::ffi::c_char = 0 as ::core::ffi::c_char;
    c = peekc();
    while c as ::core::ffi::c_int >= 'a' as i32 && c as ::core::ffi::c_int <= 'z' as i32
        || c as ::core::ffi::c_int >= 'A' as i32 && c as ::core::ffi::c_int <= 'Z' as i32
        || c as ::core::ffi::c_int >= '0' as i32 && c as ::core::ffi::c_int <= '9' as i32
        || c as ::core::ffi::c_int == '_' as i32
    {
        buffer_write(buffer, c);
        nextc();
        c = peekc();
    }
    buffer_write(buffer, 0 as ::core::ffi::c_char);
    if is_keyword(buffer_ptr(buffer) as *const ::core::ffi::c_char) {
        let mut fresh0: token = {
            let mut init = token {
                type_0: TOKEN_TYPE_KEYWORD as ::core::ffi::c_int,
                flags: 0,
                pos: pos {
                    line: 0,
                    col: 0,
                    filename: 0 as *const ::core::ffi::c_char,
                },
                c2rust_unnamed: C2RustUnnamed_2 {
                    sval: (buffer_ptr
                        as unsafe extern "C" fn(
                            *mut buffer,
                        ) -> *mut ::core::ffi::c_void)(buffer)
                        as *const ::core::ffi::c_char,
                },
                num: token_number { type_0: 0 },
                whitespace: false,
                between_brackets: 0 as *const ::core::ffi::c_char,
            };
            init
        };
        return token_create(&mut fresh0);
    }
    let mut fresh1: token = {
        let mut init = token {
            type_0: TOKEN_TYPE_IDENTIFIER as ::core::ffi::c_int,
            flags: 0,
            pos: pos {
                line: 0,
                col: 0,
                filename: 0 as *const ::core::ffi::c_char,
            },
            c2rust_unnamed: C2RustUnnamed_2 {
                sval: (buffer_ptr
                    as unsafe extern "C" fn(
                        *mut buffer,
                    ) -> *mut ::core::ffi::c_void)(buffer) as *const ::core::ffi::c_char,
            },
            num: token_number { type_0: 0 },
            whitespace: false,
            between_brackets: 0 as *const ::core::ffi::c_char,
        };
        init
    };
    return token_create(&mut fresh1);
}
#[no_mangle]
pub unsafe extern "C" fn read_special_token() -> *mut token {
    let mut c: ::core::ffi::c_char = peekc();
    if isalpha(c as ::core::ffi::c_int) != 0 || c as ::core::ffi::c_int == '_' as i32 {
        return token_make_identifier_or_keyword();
    }
    return 0 as *mut token;
}
#[no_mangle]
pub unsafe extern "C" fn token_make_newline() -> *mut token {
    nextc();
    let mut fresh2: token = {
        let mut init = token {
            type_0: TOKEN_TYPE_NEWLINE as ::core::ffi::c_int,
            flags: 0,
            pos: pos {
                line: 0,
                col: 0,
                filename: 0 as *const ::core::ffi::c_char,
            },
            c2rust_unnamed: C2RustUnnamed_2 { cval: 0 },
            num: token_number { type_0: 0 },
            whitespace: false,
            between_brackets: 0 as *const ::core::ffi::c_char,
        };
        init
    };
    return token_create(&mut fresh2);
}
#[no_mangle]
pub unsafe extern "C" fn token_make_one_line_comment() -> *mut token {
    let mut buffer: *mut buffer = buffer_create();
    let mut c: ::core::ffi::c_char = 0 as ::core::ffi::c_char;
    c = peekc();
    while c as ::core::ffi::c_int != '\n' as i32
        && c as ::core::ffi::c_int != -(1 as ::core::ffi::c_int)
    {
        buffer_write(buffer, c);
        nextc();
        c = peekc();
    }
    let mut fresh9: token = {
        let mut init = token {
            type_0: TOKEN_TYPE_COMMENT as ::core::ffi::c_int,
            flags: 0,
            pos: pos {
                line: 0,
                col: 0,
                filename: 0 as *const ::core::ffi::c_char,
            },
            c2rust_unnamed: C2RustUnnamed_2 { cval: 0 },
            num: token_number { type_0: 0 },
            whitespace: false,
            between_brackets: 0 as *const ::core::ffi::c_char,
        };
        init
    };
    return token_create(&mut fresh9);
}
#[no_mangle]
pub unsafe extern "C" fn token_make_multiline_comment() -> *mut token {
    let mut buffer: *mut buffer = buffer_create();
    let mut c: ::core::ffi::c_char = 0 as ::core::ffi::c_char;
    loop {
        c = peekc();
        while c as ::core::ffi::c_int != '*' as i32
            && c as ::core::ffi::c_int != -(1 as ::core::ffi::c_int)
        {
            buffer_write(buffer, c);
            nextc();
            c = peekc();
        }
        if c as ::core::ffi::c_int == EOF {
            compiler_error(
                (*lex_process).compiler as *mut compile_process,
                b"You did not close this multiline comment\n\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        } else {
            if !(c as ::core::ffi::c_int == '*' as i32) {
                continue;
            }
            nextc();
            if !(peekc() as ::core::ffi::c_int == '/' as i32) {
                continue;
            }
            nextc();
            break;
        }
    }
    let mut fresh8: token = {
        let mut init = token {
            type_0: TOKEN_TYPE_COMMENT as ::core::ffi::c_int,
            flags: 0,
            pos: pos {
                line: 0,
                col: 0,
                filename: 0 as *const ::core::ffi::c_char,
            },
            c2rust_unnamed: C2RustUnnamed_2 {
                sval: (buffer_ptr
                    as unsafe extern "C" fn(
                        *mut buffer,
                    ) -> *mut ::core::ffi::c_void)(buffer) as *const ::core::ffi::c_char,
            },
            num: token_number { type_0: 0 },
            whitespace: false,
            between_brackets: 0 as *const ::core::ffi::c_char,
        };
        init
    };
    return token_create(&mut fresh8);
}
#[no_mangle]
pub unsafe extern "C" fn handle_comment() -> *mut token {
    let mut c: ::core::ffi::c_char = peekc();
    if c as ::core::ffi::c_int == '/' as i32 {
        nextc();
        if peekc() as ::core::ffi::c_int == '/' as i32 {
            nextc();
            return token_make_one_line_comment();
        } else if peekc() as ::core::ffi::c_int == '*' as i32 {
            nextc();
            return token_make_multiline_comment();
        }
        pushc('/' as i32 as ::core::ffi::c_char);
        return token_make_operator_or_string();
    }
    return 0 as *mut token;
}
#[no_mangle]
pub unsafe extern "C" fn lex_get_escaped_char(
    mut c: ::core::ffi::c_char,
) -> ::core::ffi::c_char {
    let mut co: ::core::ffi::c_char = 0 as ::core::ffi::c_char;
    match c as ::core::ffi::c_int {
        110 => {
            co = '\n' as i32 as ::core::ffi::c_char;
        }
        92 => {
            co = '\\' as i32 as ::core::ffi::c_char;
        }
        116 => {
            co = '\t' as i32 as ::core::ffi::c_char;
        }
        98 => {
            co = '\u{8}' as i32 as ::core::ffi::c_char;
        }
        39 => {
            co = '\'' as i32 as ::core::ffi::c_char;
        }
        _ => {}
    }
    return co;
}
#[no_mangle]
pub unsafe extern "C" fn lexer_pop_token() {
    vector_pop((*lex_process).token_vec as *mut vector);
}
#[no_mangle]
pub unsafe extern "C" fn is_hex_char(mut c: ::core::ffi::c_char) -> bool {
    c = tolower(c as ::core::ffi::c_int) as ::core::ffi::c_char;
    return c as ::core::ffi::c_int >= '0' as i32 && c as ::core::ffi::c_int <= '9' as i32
        || c as ::core::ffi::c_int >= 'a' as i32
            && c as ::core::ffi::c_int <= 'f' as i32;
}
#[no_mangle]
pub unsafe extern "C" fn read_hex_number_str() -> *const ::core::ffi::c_char {
    let mut buffer: *mut buffer = buffer_create();
    let mut c: ::core::ffi::c_char = peekc();
    c = peekc();
    while is_hex_char(c) {
        buffer_write(buffer, c);
        nextc();
        c = peekc();
    }
    buffer_write(buffer, 0 as ::core::ffi::c_char);
    return buffer_ptr(buffer) as *const ::core::ffi::c_char;
}
#[no_mangle]
pub unsafe extern "C" fn token_make_special_number_hexadecimal() -> *mut token {
    nextc();
    let mut number: ::core::ffi::c_ulong = 0 as ::core::ffi::c_ulong;
    let mut number_str: *const ::core::ffi::c_char = read_hex_number_str();
    number = strtol(
        number_str,
        0 as *mut *mut ::core::ffi::c_char,
        16 as ::core::ffi::c_int,
    ) as ::core::ffi::c_ulong;
    return token_make_number_for_value(number);
}
#[no_mangle]
pub unsafe extern "C" fn lexer_validate_binary_string(
    mut str: *const ::core::ffi::c_char,
) {
    let mut len: size_t = strlen(str);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while (i as size_t) < len {
        if *str.offset(i as isize) as ::core::ffi::c_int != '0' as i32
            && *str.offset(i as isize) as ::core::ffi::c_int != '1' as i32
        {
            compiler_error(
                (*lex_process).compiler as *mut compile_process,
                b"Invalid Binary number\n\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        i += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn token_make_special_number_binary() -> *mut token {
    nextc();
    let mut number: ::core::ffi::c_ulong = 0 as ::core::ffi::c_ulong;
    let mut number_str: *const ::core::ffi::c_char = read_number_str();
    lexer_validate_binary_string(number_str);
    number = strtol(
        number_str,
        0 as *mut *mut ::core::ffi::c_char,
        2 as ::core::ffi::c_int,
    ) as ::core::ffi::c_ulong;
    return token_make_number_for_value(number);
}
#[no_mangle]
pub unsafe extern "C" fn token_make_special_number() -> *mut token {
    let mut token: *mut token = 0 as *mut token;
    let mut last_token: *mut token = lexer_last_token();
    if last_token.is_null()
        || {
            (*last_token).type_0 = (TOKEN_TYPE_NUMBER as ::core::ffi::c_int != 0
                && (*last_token).c2rust_unnamed.llnum == 0 as ::core::ffi::c_ulonglong)
                as ::core::ffi::c_int;
            (*last_token).type_0 == 0
        }
    {
        return token_make_identifier_or_keyword();
    }
    lexer_pop_token();
    let mut c: ::core::ffi::c_char = peekc();
    if c as ::core::ffi::c_int == 'x' as i32 {
        token = token_make_special_number_hexadecimal();
    } else if c as ::core::ffi::c_int == 'b' as i32 {
        token = token_make_special_number_binary();
    }
    return token;
}
#[no_mangle]
pub unsafe extern "C" fn token_make_quote() -> *mut token {
    assert_next_char('\'' as i32 as ::core::ffi::c_char);
    let mut c: ::core::ffi::c_char = nextc();
    if c as ::core::ffi::c_int == '\\' as i32 {
        c = nextc();
        c = lex_get_escaped_char(c);
    }
    if nextc() as ::core::ffi::c_int != '\'' as i32 {
        compiler_error(
            (*lex_process).compiler as *mut compile_process,
            b"You opened a quote ' but did not close it\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    let mut fresh4: token = {
        let mut init = token {
            type_0: TOKEN_TYPE_NUMBER as ::core::ffi::c_int,
            flags: 0,
            pos: pos {
                line: 0,
                col: 0,
                filename: 0 as *const ::core::ffi::c_char,
            },
            c2rust_unnamed: C2RustUnnamed_2 { cval: c },
            num: token_number { type_0: 0 },
            whitespace: false,
            between_brackets: 0 as *const ::core::ffi::c_char,
        };
        init
    };
    return token_create(&mut fresh4);
}
#[no_mangle]
pub unsafe extern "C" fn read_next_token() -> *mut token {
    let mut token: *mut token = 0 as *mut token;
    let mut c: ::core::ffi::c_char = peekc();
    token = handle_comment();
    if !token.is_null() {
        return token;
    }
    match c as ::core::ffi::c_int {
        48 | 49 | 50 | 51 | 52 | 53 | 54 | 55 | 56 | 57 => {
            token = token_make_number();
        }
        43 | 45 | 42 | 62 | 60 | 94 | 37 | 33 | 61 | 126 | 124 | 38 | 40 | 91 | 44 | 46
        | 63 => {
            token = token_make_operator_or_string();
        }
        123 | 125 | 58 | 59 | 35 | 92 | 41 | 93 => {
            token = token_make_symbol();
        }
        98 => {
            token = token_make_special_number();
        }
        120 => {
            token = token_make_special_number();
        }
        39 => {
            token = token_make_quote();
        }
        34 => {
            token = token_make_string(
                '"' as i32 as ::core::ffi::c_char,
                '"' as i32 as ::core::ffi::c_char,
            );
        }
        32 | 9 => {
            token = handle_whitespace();
        }
        10 => {
            token = token_make_newline();
        }
        36 => {}
        _ => {
            token = read_special_token();
            if token.is_null() {
                compiler_error(
                    (*lex_process).compiler as *mut compile_process,
                    b"Unexpected token\n\0" as *const u8 as *const ::core::ffi::c_char,
                );
            }
        }
    }
    return token;
}
#[no_mangle]
pub unsafe extern "C" fn lex(mut process: *mut lex_process) -> ::core::ffi::c_int {
    (*process).current_expression_count = 0 as ::core::ffi::c_int;
    (*process).parentheses_buffer = 0 as *mut buffer;
    lex_process = process;
    (*process).pos.filename = (*(*process).compiler).cfile.abs_path;
    let mut token: *mut token = read_next_token();
    while !token.is_null() {
        vector_push(
            (*process).token_vec as *mut vector,
            token as *mut ::core::ffi::c_void,
        );
        token = read_next_token();
    }
    return LEXICAL_ANALYSIS_ALL_OK as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn lexer_string_buffer_next_char(
    mut process: *mut lex_process,
) -> ::core::ffi::c_char {
    let mut buf: *mut buffer = lex_process_private(process) as *mut buffer;
    return buffer_read(buf);
}
#[no_mangle]
pub unsafe extern "C" fn lexer_string_buffer_peek_char(
    mut process: *mut lex_process,
) -> ::core::ffi::c_char {
    let mut buf: *mut buffer = lex_process_private(process) as *mut buffer;
    return buffer_peek(buf);
}
#[no_mangle]
pub unsafe extern "C" fn lexer_string_buffer_push_char(
    mut process: *mut lex_process,
    mut c: ::core::ffi::c_char,
) {
    let mut buf: *mut buffer = lex_process_private(process) as *mut buffer;
    buffer_write(buf, c);
}
#[no_mangle]
pub static mut lexer_string_buffer_functions: lex_process_functions = unsafe {
    {
        let mut init = lex_process_functions {
            next_char: Some(
                lexer_string_buffer_next_char
                    as unsafe extern "C" fn(*mut lex_process) -> ::core::ffi::c_char,
            ),
            peek_char: Some(
                lexer_string_buffer_peek_char
                    as unsafe extern "C" fn(*mut lex_process) -> ::core::ffi::c_char,
            ),
            push_char: Some(
                lexer_string_buffer_push_char
                    as unsafe extern "C" fn(*mut lex_process, ::core::ffi::c_char) -> (),
            ),
        };
        init
    }
};
#[no_mangle]
pub unsafe extern "C" fn tokens_build_for_string(
    mut compiler: *mut compile_process,
    mut str: *const ::core::ffi::c_char,
) -> *mut lex_process {
    let mut buffer: *mut buffer = buffer_create();
    buffer_printf(buffer, str);
    let mut lex_process_0: *mut lex_process = lex_process_create(
        compiler,
        &mut lexer_string_buffer_functions,
        buffer as *mut ::core::ffi::c_void,
    );
    if lex_process_0.is_null() {
        return 0 as *mut lex_process;
    }
    if lex(lex_process_0) != LEXICAL_ANALYSIS_ALL_OK as ::core::ffi::c_int {
        return 0 as *mut lex_process;
    }
    return lex_process_0;
}
