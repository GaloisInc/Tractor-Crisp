#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn vector_push(vector: *mut vector, elem: *mut ::core::ffi::c_void);
    fn vector_pop(vector: *mut vector);
    fn vector_back(vector: *mut vector) -> *mut ::core::ffi::c_void;
    fn vector_back_ptr(vector: *mut vector) -> *mut ::core::ffi::c_void;
    fn vector_back_ptr_or_null(vector: *mut vector) -> *mut ::core::ffi::c_void;
    fn vector_empty(vector: *mut vector) -> bool;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct pos {
    pub line: ::core::ffi::c_int,
    pub col: ::core::ffi::c_int,
    pub filename: *const ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct vector {
    pub data: *mut ::core::ffi::c_void,
    pub pindex: ::core::ffi::c_int,
    pub rindex: ::core::ffi::c_int,
    pub mindex: ::core::ffi::c_int,
    pub count: ::core::ffi::c_int,
    pub flags: ::core::ffi::c_int,
    pub esize: size_t,
    pub saves: *mut vector,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct node {
    pub type_0: ::core::ffi::c_int,
    pub flags: ::core::ffi::c_int,
    pub pos: pos,
    pub binded: node_binded,
    pub c2rust_unnamed: C2RustUnnamed,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed {
    pub cval: ::core::ffi::c_char,
    pub sval: *const ::core::ffi::c_char,
    pub inum: ::core::ffi::c_uint,
    pub lnum: ::core::ffi::c_ulong,
    pub llnum: ::core::ffi::c_ulonglong,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct node_binded {
    pub owner: *mut node,
    pub function: *mut node,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub static mut node_vector: *mut vector = 0 as *const vector as *mut vector;
#[no_mangle]
pub static mut node_vector_root: *mut vector = 0 as *const vector as *mut vector;
#[no_mangle]
pub unsafe extern "C" fn node_set_vector(
    mut vec: *mut vector,
    mut root_vec: *mut vector,
) {
    node_vector = vec;
    node_vector_root = root_vec;
}
#[no_mangle]
pub unsafe extern "C" fn node_push(mut node: *mut node) {
    vector_push(node_vector, &mut node as *mut *mut node as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn node_peek_or_null() -> *mut node {
    return vector_back_ptr_or_null(node_vector) as *mut node;
}
#[no_mangle]
pub unsafe extern "C" fn node_peek() -> *mut node {
    return *(vector_back(node_vector) as *mut *mut node);
}
#[no_mangle]
pub unsafe extern "C" fn node_pop() -> *mut node {
    let mut last_node: *mut node = vector_back_ptr(node_vector) as *mut node;
    let mut last_node_root: *mut node = (if vector_empty(node_vector)
        as ::core::ffi::c_int != 0
    {
        NULL
    } else {
        vector_back_ptr(node_vector_root)
    }) as *mut node;
    vector_pop(node_vector);
    if last_node == last_node_root {
        vector_pop(node_vector_root);
    }
    return last_node;
}
#[no_mangle]
pub unsafe extern "C" fn node_create(mut _node: *mut node) -> *mut node {
    let mut node: *mut node = malloc(::core::mem::size_of::<node>() as size_t)
        as *mut node;
    memcpy(
        node as *mut ::core::ffi::c_void,
        _node as *const ::core::ffi::c_void,
        ::core::mem::size_of::<node>() as size_t,
    );
    node_push(node);
    return node;
}
