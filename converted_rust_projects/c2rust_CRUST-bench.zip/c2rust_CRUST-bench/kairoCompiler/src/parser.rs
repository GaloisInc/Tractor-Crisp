#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn compiler_error(
        compiler: *mut compile_process,
        msg: *const ::core::ffi::c_char,
        ...
    );
    fn token_is_nl_or_comment_or_newline_separator(token: *mut token) -> bool;
    fn node_peek() -> *mut node;
    fn node_set_vector(vec: *mut vector, root_vec: *mut vector);
    fn node_create(_node: *mut node) -> *mut node;
    fn vector_peek_no_increment(vector: *mut vector) -> *mut ::core::ffi::c_void;
    fn vector_peek(vector: *mut vector) -> *mut ::core::ffi::c_void;
    fn vector_set_peek_pointer(vector: *mut vector, index: ::core::ffi::c_int);
    fn vector_push(vector: *mut vector, elem: *mut ::core::ffi::c_void);
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct pos {
    pub line: ::core::ffi::c_int,
    pub col: ::core::ffi::c_int,
    pub filename: *const ::core::ffi::c_char,
}
pub type C2RustUnnamed = ::core::ffi::c_uint;
pub const TOKEN_TYPE_NEWLINE: C2RustUnnamed = 7;
pub const TOKEN_TYPE_COMMENT: C2RustUnnamed = 6;
pub const TOKEN_TYPE_STRING: C2RustUnnamed = 5;
pub const TOKEN_TYPE_NUMBER: C2RustUnnamed = 4;
pub const TOKEN_TYPE_SYMBOL: C2RustUnnamed = 3;
pub const TOKEN_TYPE_OPERATOR: C2RustUnnamed = 2;
pub const TOKEN_TYPE_KEYWORD: C2RustUnnamed = 1;
pub const TOKEN_TYPE_IDENTIFIER: C2RustUnnamed = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct token {
    pub type_0: ::core::ffi::c_int,
    pub flags: ::core::ffi::c_int,
    pub pos: pos,
    pub c2rust_unnamed: C2RustUnnamed_0,
    pub num: token_number,
    pub whitespace: bool,
    pub between_brackets: *const ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct token_number {
    pub type_0: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed_0 {
    pub cval: ::core::ffi::c_char,
    pub sval: *const ::core::ffi::c_char,
    pub inum: ::core::ffi::c_uint,
    pub lnum: ::core::ffi::c_ulong,
    pub llnum: ::core::ffi::c_ulonglong,
    pub any: *mut ::core::ffi::c_void,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct compile_process {
    pub flags: ::core::ffi::c_int,
    pub pos: pos,
    pub cfile: compile_process_input_file,
    pub token_vec: *mut vector,
    pub node_vec: *mut vector,
    pub node_tree_vec: *mut vector,
    pub ofile: *mut FILE,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct vector {
    pub data: *mut ::core::ffi::c_void,
    pub pindex: ::core::ffi::c_int,
    pub rindex: ::core::ffi::c_int,
    pub mindex: ::core::ffi::c_int,
    pub count: ::core::ffi::c_int,
    pub flags: ::core::ffi::c_int,
    pub esize: size_t,
    pub saves: *mut vector,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct compile_process_input_file {
    pub fp: *mut FILE,
    pub abs_path: *const ::core::ffi::c_char,
}
pub type C2RustUnnamed_1 = ::core::ffi::c_uint;
pub const PARSE_GENERAL_ERROR: C2RustUnnamed_1 = 1;
pub const PARSE_ALL_OK: C2RustUnnamed_1 = 0;
pub type C2RustUnnamed_2 = ::core::ffi::c_uint;
pub const NODE_TYPE_BLANK: C2RustUnnamed_2 = 28;
pub const NODE_TYPE_CAST: C2RustUnnamed_2 = 27;
pub const NODE_TYPE_BRACKET: C2RustUnnamed_2 = 26;
pub const NODE_TYPE_UNION: C2RustUnnamed_2 = 25;
pub const NODE_TYPE_STRUCT: C2RustUnnamed_2 = 24;
pub const NODE_TYPE_LABEL: C2RustUnnamed_2 = 23;
pub const NODE_TYPE_TENARY: C2RustUnnamed_2 = 22;
pub const NODE_TYPE_UNARY: C2RustUnnamed_2 = 21;
pub const NODE_TYPE_STATEMENT_GOTO: C2RustUnnamed_2 = 20;
pub const NODE_TYPE_STATEMENT_DEFAULT: C2RustUnnamed_2 = 19;
pub const NODE_TYPE_STATEMENT_CASE: C2RustUnnamed_2 = 18;
pub const NODE_TYPE_STATEMENT_SWITCH: C2RustUnnamed_2 = 17;
pub const NODE_TYPE_STATEMENT_CONTINUE: C2RustUnnamed_2 = 16;
pub const NODE_TYPE_STATEMENT_BREAK: C2RustUnnamed_2 = 15;
pub const NODE_TYPE_STATEMENT_FOR: C2RustUnnamed_2 = 14;
pub const NODE_TYPE_STATEMENT_DO_WHILE: C2RustUnnamed_2 = 13;
pub const NODE_TYPE_STATEMENT_WHILE: C2RustUnnamed_2 = 12;
pub const NODE_TYPE_STATEMENT_ELSE: C2RustUnnamed_2 = 11;
pub const NODE_TYPE_STATEMENT_IF: C2RustUnnamed_2 = 10;
pub const NODE_TYPE_STATEMENT_RETURN: C2RustUnnamed_2 = 9;
pub const NODE_TYPE_BODY: C2RustUnnamed_2 = 8;
pub const NODE_TYPE_FUNCTION: C2RustUnnamed_2 = 7;
pub const NODE_TYPE_VARIABLE_LIST: C2RustUnnamed_2 = 6;
pub const NODE_TYPE_VARIABLE: C2RustUnnamed_2 = 5;
pub const NODE_TYPE_STRING: C2RustUnnamed_2 = 4;
pub const NODE_TYPE_IDENTIFIER: C2RustUnnamed_2 = 3;
pub const NODE_TYPE_NUMBER: C2RustUnnamed_2 = 2;
pub const NODE_TYPE_EXPRESSION_PARENTHESES: C2RustUnnamed_2 = 1;
pub const NODE_TYPE_EXPRESSION: C2RustUnnamed_2 = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct node {
    pub type_0: ::core::ffi::c_int,
    pub flags: ::core::ffi::c_int,
    pub pos: pos,
    pub binded: node_binded,
    pub c2rust_unnamed: C2RustUnnamed_3,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed_3 {
    pub cval: ::core::ffi::c_char,
    pub sval: *const ::core::ffi::c_char,
    pub inum: ::core::ffi::c_uint,
    pub lnum: ::core::ffi::c_ulong,
    pub llnum: ::core::ffi::c_ulonglong,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct node_binded {
    pub owner: *mut node,
    pub function: *mut node,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
static mut current_process: *mut compile_process = 0 as *const compile_process
    as *mut compile_process;
static mut parser_last_token: *mut token = 0 as *const token as *mut token;
unsafe extern "C" fn parser_ignore_nl_or_comment(mut token: *mut token) {
    while !token.is_null()
        && token_is_nl_or_comment_or_newline_separator(token) as ::core::ffi::c_int != 0
    {
        vector_peek((*current_process).token_vec);
        token = vector_peek_no_increment((*current_process).token_vec) as *mut token;
    }
}
unsafe extern "C" fn token_next() -> *mut token {
    let mut next_token: *mut token = vector_peek_no_increment(
        (*current_process).token_vec,
    ) as *mut token;
    parser_ignore_nl_or_comment(next_token);
    (*current_process).pos = (*next_token).pos;
    parser_last_token = next_token;
    return vector_peek((*current_process).token_vec) as *mut token;
}
unsafe extern "C" fn token_peek_next() -> *mut token {
    let mut next_token: *mut token = vector_peek_no_increment(
        (*current_process).token_vec,
    ) as *mut token;
    parser_ignore_nl_or_comment(next_token);
    return vector_peek_no_increment((*current_process).token_vec) as *mut token;
}
#[no_mangle]
pub unsafe extern "C" fn parse_single_token_to_node() {
    let mut token: *mut token = token_next();
    let mut node: *mut node = 0 as *mut node;
    match (*token).type_0 {
        4 => {
            let mut fresh0: node = {
                let mut init = node {
                    type_0: NODE_TYPE_NUMBER as ::core::ffi::c_int,
                    flags: 0,
                    pos: pos {
                        line: 0,
                        col: 0,
                        filename: 0 as *const ::core::ffi::c_char,
                    },
                    binded: node_binded {
                        owner: 0 as *mut node,
                        function: 0 as *mut node,
                    },
                    c2rust_unnamed: C2RustUnnamed_3 {
                        llnum: (*token).c2rust_unnamed.llnum,
                    },
                };
                init
            };
            node = node_create(&mut fresh0);
        }
        0 => {
            let mut fresh1: node = {
                let mut init = node {
                    type_0: NODE_TYPE_IDENTIFIER as ::core::ffi::c_int,
                    flags: 0,
                    pos: pos {
                        line: 0,
                        col: 0,
                        filename: 0 as *const ::core::ffi::c_char,
                    },
                    binded: node_binded {
                        owner: 0 as *mut node,
                        function: 0 as *mut node,
                    },
                    c2rust_unnamed: C2RustUnnamed_3 {
                        sval: (*token).c2rust_unnamed.sval,
                    },
                };
                init
            };
            node = node_create(&mut fresh1);
        }
        5 => {
            let mut fresh2: node = {
                let mut init = node {
                    type_0: NODE_TYPE_STRING as ::core::ffi::c_int,
                    flags: 0,
                    pos: pos {
                        line: 0,
                        col: 0,
                        filename: 0 as *const ::core::ffi::c_char,
                    },
                    binded: node_binded {
                        owner: 0 as *mut node,
                        function: 0 as *mut node,
                    },
                    c2rust_unnamed: C2RustUnnamed_3 {
                        sval: (*token).c2rust_unnamed.sval,
                    },
                };
                init
            };
            node = node_create(&mut fresh2);
        }
        _ => {
            compiler_error(
                current_process,
                b"This is not a token that can be converted to a node\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn parse_next() -> ::core::ffi::c_int {
    let mut token: *mut token = token_peek_next();
    if token.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    let mut res: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    match (*token).type_0 {
        4 | 0 | 5 => {
            parse_single_token_to_node();
        }
        _ => {}
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn parse(mut process: *mut compile_process) -> ::core::ffi::c_int {
    current_process = process;
    parser_last_token = 0 as *mut token;
    node_set_vector((*process).node_vec, (*process).node_tree_vec);
    let mut node: *mut node = 0 as *mut node;
    vector_set_peek_pointer((*process).token_vec, 0 as ::core::ffi::c_int);
    while parse_next() == 0 as ::core::ffi::c_int {
        node = node_peek();
        vector_push(
            (*process).node_tree_vec,
            &mut node as *mut *mut node as *mut ::core::ffi::c_void,
        );
    }
    return PARSE_ALL_OK as ::core::ffi::c_int;
}
