#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn compile_file(
        filename: *const ::core::ffi::c_char,
        out_filename: *const ::core::ffi::c_char,
        flags: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
}
pub type C2RustUnnamed = ::core::ffi::c_uint;
pub const COMPILER_FAILED_WITH_ERRORS: C2RustUnnamed = 1;
pub const COMPILER_FILE_COMPILED_OK: C2RustUnnamed = 0;
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut res: ::core::ffi::c_int = compile_file(
        b"./test.txt\0" as *const u8 as *const ::core::ffi::c_char,
        b"./test\0" as *const u8 as *const ::core::ffi::c_char,
        0 as ::core::ffi::c_int,
    );
    if res == COMPILER_FILE_COMPILED_OK as ::core::ffi::c_int {
        printf(b"Compiled fine\n\0" as *const u8 as *const ::core::ffi::c_char);
    } else if res == COMPILER_FAILED_WITH_ERRORS as ::core::ffi::c_int {
        printf(b"compile failed\n\0" as *const u8 as *const ::core::ffi::c_char);
    } else {
        printf(
            b"Unknown response Compile failed\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
