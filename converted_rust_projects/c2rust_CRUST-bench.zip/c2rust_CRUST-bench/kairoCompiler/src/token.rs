#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct pos {
    pub line: ::core::ffi::c_int,
    pub col: ::core::ffi::c_int,
    pub filename: *const ::core::ffi::c_char,
}
pub type C2RustUnnamed = ::core::ffi::c_uint;
pub const TOKEN_TYPE_NEWLINE: C2RustUnnamed = 7;
pub const TOKEN_TYPE_COMMENT: C2RustUnnamed = 6;
pub const TOKEN_TYPE_STRING: C2RustUnnamed = 5;
pub const TOKEN_TYPE_NUMBER: C2RustUnnamed = 4;
pub const TOKEN_TYPE_SYMBOL: C2RustUnnamed = 3;
pub const TOKEN_TYPE_OPERATOR: C2RustUnnamed = 2;
pub const TOKEN_TYPE_KEYWORD: C2RustUnnamed = 1;
pub const TOKEN_TYPE_IDENTIFIER: C2RustUnnamed = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct token {
    pub type_0: ::core::ffi::c_int,
    pub flags: ::core::ffi::c_int,
    pub pos: pos,
    pub c2rust_unnamed: C2RustUnnamed_0,
    pub num: token_number,
    pub whitespace: bool,
    pub between_brackets: *const ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct token_number {
    pub type_0: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed_0 {
    pub cval: ::core::ffi::c_char,
    pub sval: *const ::core::ffi::c_char,
    pub inum: ::core::ffi::c_uint,
    pub lnum: ::core::ffi::c_ulong,
    pub llnum: ::core::ffi::c_ulonglong,
    pub any: *mut ::core::ffi::c_void,
}
#[no_mangle]
pub unsafe extern "C" fn token_is_keyword(
    mut token: *mut token,
    mut value: *const ::core::ffi::c_char,
) -> bool {
    (*token).type_0 = (TOKEN_TYPE_KEYWORD as ::core::ffi::c_int != 0
        && (!(*token).c2rust_unnamed.sval.is_null() && !value.is_null()
            && strcmp((*token).c2rust_unnamed.sval, value) == 0 as ::core::ffi::c_int))
        as ::core::ffi::c_int;
    return (*token).type_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn token_is_symbol(
    mut token: *mut token,
    mut c: ::core::ffi::c_char,
) -> bool {
    return (*token).type_0 == TOKEN_TYPE_SYMBOL as ::core::ffi::c_int
        && (*token).c2rust_unnamed.cval as ::core::ffi::c_int == c as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn token_is_nl_or_comment_or_newline_separator(
    mut token: *mut token,
) -> bool {
    return (*token).type_0 == TOKEN_TYPE_NEWLINE as ::core::ffi::c_int
        || (*token).type_0 == TOKEN_TYPE_COMMENT as ::core::ffi::c_int
        || token_is_symbol(token, '\\' as i32 as ::core::ffi::c_char)
            as ::core::ffi::c_int != 0;
}
