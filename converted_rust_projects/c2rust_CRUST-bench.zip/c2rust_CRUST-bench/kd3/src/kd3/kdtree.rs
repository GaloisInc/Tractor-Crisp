#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn realloc(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn qsort(
        __base: *mut ::core::ffi::c_void,
        __nel: size_t,
        __width: size_t,
        __compar: Option<
            unsafe extern "C" fn(
                *const ::core::ffi::c_void,
                *const ::core::ffi::c_void,
            ) -> ::core::ffi::c_int,
        >,
    );
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct data_point {
    pub x: ::core::ffi::c_double,
    pub y: ::core::ffi::c_double,
    pub z: ::core::ffi::c_double,
    pub idx: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tree_node {
    pub left: *mut tree_node,
    pub right: *mut tree_node,
    pub split: ::core::ffi::c_double,
    pub idx: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct boundaries {
    pub min: ::core::ffi::c_double,
    pub max: ::core::ffi::c_double,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct space {
    pub dim: [boundaries; 3],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct kdtree {
    pub count: size_t,
    pub max_nodes: size_t,
    pub next_node: size_t,
    pub points: *mut data_point,
    pub node_data: *mut tree_node,
    pub root: *mut tree_node,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct kdtree_iterator {
    pub data: *mut size_t,
    pub capacity: size_t,
    pub size: size_t,
    pub current: size_t,
}
pub const NDIMS: DIMENSIONS = 3;
pub type cmp_func = Option<
    unsafe extern "C" fn(
        *const ::core::ffi::c_void,
        *const ::core::ffi::c_void,
    ) -> ::core::ffi::c_int,
>;
pub const DIM_Z: DIMENSIONS = 2;
pub const DIM_Y: DIMENSIONS = 1;
pub const DIM_X: DIMENSIONS = 0;
pub type DIMENSIONS = ::core::ffi::c_uint;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const UINTPTR_MAX: ::core::ffi::c_ulong = 18446744073709551615
    as ::core::ffi::c_ulong;
pub const SIZE_MAX: ::core::ffi::c_ulong = UINTPTR_MAX;
pub const KDTREE_ITERATOR_INITIAL_SIZE: ::core::ffi::c_int = 50 as ::core::ffi::c_int;
pub const KDTREE_ITERATOR_GROWTH_RATIO: ::core::ffi::c_int = 2 as ::core::ffi::c_int;
pub const KDTREE_END: ::core::ffi::c_ulong = SIZE_MAX;
unsafe extern "C" fn cmp_x(
    mut a1: *const ::core::ffi::c_void,
    mut a2: *const ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    let mut A1: *const data_point = a1 as *const data_point;
    let mut A2: *const data_point = a2 as *const data_point;
    return if (*A1).x > (*A2).x {
        1 as ::core::ffi::c_int
    } else if (*A1).x < (*A2).x {
        -(1 as ::core::ffi::c_int)
    } else {
        0 as ::core::ffi::c_int
    };
}
unsafe extern "C" fn cmp_y(
    mut a1: *const ::core::ffi::c_void,
    mut a2: *const ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    let mut A1: *const data_point = a1 as *const data_point;
    let mut A2: *const data_point = a2 as *const data_point;
    return if (*A1).y > (*A2).y {
        1 as ::core::ffi::c_int
    } else if (*A1).y < (*A2).y {
        -(1 as ::core::ffi::c_int)
    } else {
        0 as ::core::ffi::c_int
    };
}
unsafe extern "C" fn cmp_z(
    mut a1: *const ::core::ffi::c_void,
    mut a2: *const ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    let mut A1: *const data_point = a1 as *const data_point;
    let mut A2: *const data_point = a2 as *const data_point;
    return if (*A1).z > (*A2).z {
        1 as ::core::ffi::c_int
    } else if (*A1).z < (*A2).z {
        -(1 as ::core::ffi::c_int)
    } else {
        0 as ::core::ffi::c_int
    };
}
unsafe extern "C" fn cmp_size_t(
    mut a1: *const ::core::ffi::c_void,
    mut a2: *const ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    let mut A1: *const size_t = a1 as *const size_t;
    let mut A2: *const size_t = a2 as *const size_t;
    return if *A1 > *A2 {
        1 as ::core::ffi::c_int
    } else if *A1 < *A2 {
        -(1 as ::core::ffi::c_int)
    } else {
        0 as ::core::ffi::c_int
    };
}
#[no_mangle]
pub static mut func_select: [cmp_func; 3] = unsafe {
    [
        Some(
            cmp_x
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                    *const ::core::ffi::c_void,
                ) -> ::core::ffi::c_int,
        ),
        Some(
            cmp_y
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                    *const ::core::ffi::c_void,
                ) -> ::core::ffi::c_int,
        ),
        Some(
            cmp_z
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                    *const ::core::ffi::c_void,
                ) -> ::core::ffi::c_int,
        ),
    ]
};
#[no_mangle]
pub unsafe extern "C" fn kdtree_build(
    mut x: *mut ::core::ffi::c_double,
    mut y: *mut ::core::ffi::c_double,
    mut z: *mut ::core::ffi::c_double,
    mut count: size_t,
    mut tree_ptr: *mut *mut kdtree,
) {
    let mut i: size_t = 0;
    let mut tree: *mut kdtree = *tree_ptr;
    if !(count > 1 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 13],
                [::core::ffi::c_char; 13],
            >(*b"kdtree_build\0")
                .as_ptr(),
            b"kdtree.c\0" as *const u8 as *const ::core::ffi::c_char,
            142 as ::core::ffi::c_int,
            b"count > 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if tree.is_null() || (*tree).count != count {
        if !tree.is_null() {
            kdtree_delete(&mut tree);
        }
        tree = malloc(::core::mem::size_of::<kdtree>() as size_t) as *mut kdtree;
        if tree.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 13],
                    [::core::ffi::c_char; 13],
                >(*b"kdtree_build\0")
                    .as_ptr(),
                b"kdtree.c\0" as *const u8 as *const ::core::ffi::c_char,
                150 as ::core::ffi::c_int,
                b"tree != NULL\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        *tree_ptr = tree;
        (*tree).count = count;
        (*tree).max_nodes = count
            .wrapping_sub(1 as size_t)
            .wrapping_mul(2 as size_t)
            .wrapping_add(1 as size_t);
        (*tree).points = malloc(
            (::core::mem::size_of::<data_point>() as size_t).wrapping_mul(count),
        ) as *mut data_point;
        (*tree).node_data = malloc(
            (::core::mem::size_of::<tree_node>() as size_t)
                .wrapping_mul((*tree).max_nodes),
        ) as *mut tree_node;
        if (*tree).points.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 13],
                    [::core::ffi::c_char; 13],
                >(*b"kdtree_build\0")
                    .as_ptr(),
                b"kdtree.c\0" as *const u8 as *const ::core::ffi::c_char,
                158 as ::core::ffi::c_int,
                b"tree->points != NULL\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        if (*tree).node_data.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 13],
                    [::core::ffi::c_char; 13],
                >(*b"kdtree_build\0")
                    .as_ptr(),
                b"kdtree.c\0" as *const u8 as *const ::core::ffi::c_char,
                159 as ::core::ffi::c_int,
                b"tree->node_data != NULL\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
    }
    (*tree).next_node = 0 as size_t;
    i = 0 as size_t;
    while i < count {
        (*(*tree).points.offset(i as isize)).idx = i;
        (*(*tree).points.offset(i as isize)).x = *x.offset(i as isize);
        (*(*tree).points.offset(i as isize)).y = *y.offset(i as isize);
        (*(*tree).points.offset(i as isize)).z = *z.offset(i as isize);
        i = i.wrapping_add(1);
    }
    (*tree).root = _build_kdtree(
        0 as size_t,
        count.wrapping_sub(1 as size_t),
        0 as size_t,
        tree,
    );
}
#[no_mangle]
pub unsafe extern "C" fn kdtree_search(
    mut tree: *mut kdtree,
    mut iter_ptr: *mut *mut kdtree_iterator,
    mut x: ::core::ffi::c_double,
    mut y: ::core::ffi::c_double,
    mut z: ::core::ffi::c_double,
    mut apothem: ::core::ffi::c_double,
) {
    if !(apothem >= 0.0f64) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"kdtree_search\0")
                .as_ptr(),
            b"kdtree.c\0" as *const u8 as *const ::core::ffi::c_char,
            184 as ::core::ffi::c_int,
            b"apothem >= 0.0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    kdtree_search_space(
        tree,
        iter_ptr,
        x - apothem,
        x + apothem,
        y - apothem,
        y + apothem,
        z - apothem,
        z + apothem,
    );
}
#[no_mangle]
pub unsafe extern "C" fn kdtree_search_space(
    mut tree: *mut kdtree,
    mut iter_ptr: *mut *mut kdtree_iterator,
    mut x_min: ::core::ffi::c_double,
    mut x_max: ::core::ffi::c_double,
    mut y_min: ::core::ffi::c_double,
    mut y_max: ::core::ffi::c_double,
    mut z_min: ::core::ffi::c_double,
    mut z_max: ::core::ffi::c_double,
) {
    let mut iter: *mut kdtree_iterator = *iter_ptr;
    let mut search_space: space = space {
        dim: [boundaries { min: 0., max: 0. }; 3],
    };
    let mut domain: space = space {
        dim: [boundaries { min: 0., max: 0. }; 3],
    };
    if tree.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"kdtree_search_space\0")
                .as_ptr(),
            b"kdtree.c\0" as *const u8 as *const ::core::ffi::c_char,
            203 as ::core::ffi::c_int,
            b"tree != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if (*tree).root.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"kdtree_search_space\0")
                .as_ptr(),
            b"kdtree.c\0" as *const u8 as *const ::core::ffi::c_char,
            206 as ::core::ffi::c_int,
            b"tree->root != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if (_is_leaf_node((*tree).root) != 0) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"kdtree_search_space\0")
                .as_ptr(),
            b"kdtree.c\0" as *const u8 as *const ::core::ffi::c_char,
            207 as ::core::ffi::c_int,
            b"!_is_leaf_node(tree->root)\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !iter.is_null() {
        _iterator_reset(iter);
    } else {
        iter = _iterator_new();
        *iter_ptr = iter;
    }
    search_space.dim[DIM_X as ::core::ffi::c_int as usize].min = x_min;
    search_space.dim[DIM_X as ::core::ffi::c_int as usize].max = x_max;
    search_space.dim[DIM_Y as ::core::ffi::c_int as usize].min = y_min;
    search_space.dim[DIM_Y as ::core::ffi::c_int as usize].max = y_max;
    search_space.dim[DIM_Z as ::core::ffi::c_int as usize].min = z_min;
    search_space.dim[DIM_Z as ::core::ffi::c_int as usize].max = z_max;
    domain.dim[DIM_X as ::core::ffi::c_int as usize].min = -DBL_MAX;
    domain.dim[DIM_X as ::core::ffi::c_int as usize].max = DBL_MAX;
    domain.dim[DIM_Y as ::core::ffi::c_int as usize].min = -DBL_MAX;
    domain.dim[DIM_Y as ::core::ffi::c_int as usize].max = DBL_MAX;
    domain.dim[DIM_Z as ::core::ffi::c_int as usize].min = -DBL_MAX;
    domain.dim[DIM_Z as ::core::ffi::c_int as usize].max = DBL_MAX;
    _search_kdtree(
        tree,
        (*tree).root,
        0 as size_t,
        &mut search_space,
        &mut domain,
        iter,
    );
}
#[no_mangle]
pub unsafe extern "C" fn kdtree_delete(mut tree_ptr: *mut *mut kdtree) {
    let mut tree: *mut kdtree = *tree_ptr;
    if tree.is_null() {
        return;
    }
    free((*tree).points as *mut ::core::ffi::c_void);
    free((*tree).node_data as *mut ::core::ffi::c_void);
    free(tree as *mut ::core::ffi::c_void);
    *tree_ptr = 0 as *mut kdtree;
}
#[no_mangle]
pub unsafe extern "C" fn kdtree_iterator_get_next(
    mut iter: *mut kdtree_iterator,
) -> size_t {
    if (*iter).current == (*iter).size {
        return KDTREE_END as size_t;
    }
    let fresh2 = (*iter).current;
    (*iter).current = (*iter).current.wrapping_add(1);
    return *(*iter).data.offset(fresh2 as isize);
}
#[no_mangle]
pub unsafe extern "C" fn kdtree_iterator_rewind(mut iter: *mut kdtree_iterator) {
    if iter.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"kdtree_iterator_rewind\0")
                .as_ptr(),
            b"kdtree.c\0" as *const u8 as *const ::core::ffi::c_char,
            256 as ::core::ffi::c_int,
            b"iter != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    (*iter).current = 0 as size_t;
}
#[no_mangle]
pub unsafe extern "C" fn kdtree_iterator_delete(
    mut iter_ptr: *mut *mut kdtree_iterator,
) {
    let mut iter: *mut kdtree_iterator = *iter_ptr;
    if iter.is_null() {
        return;
    }
    free((*iter).data as *mut ::core::ffi::c_void);
    free(iter as *mut ::core::ffi::c_void);
    *iter_ptr = 0 as *mut kdtree_iterator;
}
#[no_mangle]
pub unsafe extern "C" fn kdtree_iterator_sort(mut iter: *mut kdtree_iterator) {
    qsort(
        (*iter).data as *mut ::core::ffi::c_void,
        (*iter).size,
        ::core::mem::size_of::<size_t>() as size_t,
        Some(
            cmp_size_t
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                    *const ::core::ffi::c_void,
                ) -> ::core::ffi::c_int,
        ),
    );
}
#[inline]
unsafe extern "C" fn _next_node(mut tree: *mut kdtree) -> *mut tree_node {
    if !((*tree).next_node < (*tree).max_nodes) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"_next_node\0")
                .as_ptr(),
            b"kdtree.c\0" as *const u8 as *const ::core::ffi::c_char,
            280 as ::core::ffi::c_int,
            b"tree->next_node < tree->max_nodes\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let fresh0 = (*tree).next_node;
    (*tree).next_node = (*tree).next_node.wrapping_add(1);
    return &mut *(*tree).node_data.offset(fresh0 as isize) as *mut tree_node;
}
#[inline]
unsafe extern "C" fn _get_branch_node(
    mut tree: *mut kdtree,
    mut split: ::core::ffi::c_double,
) -> *mut tree_node {
    let mut node: *mut tree_node = _next_node(tree);
    (*node).split = split;
    return node;
}
#[inline]
unsafe extern "C" fn _get_leaf_node(
    mut tree: *mut kdtree,
    mut offset: size_t,
) -> *mut tree_node {
    let mut node: *mut tree_node = _next_node(tree);
    (*node).left = 0 as *mut tree_node;
    (*node).right = 0 as *mut tree_node;
    (*node).idx = offset;
    return node;
}
#[inline]
unsafe extern "C" fn _is_leaf_node(mut node: *const tree_node) -> ::core::ffi::c_int {
    return ((*node).left.is_null() && (*node).right.is_null()) as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn _point_in_search_space(
    mut point: *const data_point,
    mut search_space: *const space,
) -> ::core::ffi::c_int {
    return ((*point).x <= (*search_space).dim[DIM_X as ::core::ffi::c_int as usize].max
        && (*point).x >= (*search_space).dim[DIM_X as ::core::ffi::c_int as usize].min
        && (*point).y <= (*search_space).dim[DIM_Y as ::core::ffi::c_int as usize].max
        && (*point).y >= (*search_space).dim[DIM_Y as ::core::ffi::c_int as usize].min
        && (*point).z <= (*search_space).dim[DIM_Z as ::core::ffi::c_int as usize].max
        && (*point).z >= (*search_space).dim[DIM_Z as ::core::ffi::c_int as usize].min)
        as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn _completely_enclosed(
    mut search_space: *const space,
    mut domain: *const space,
) -> ::core::ffi::c_int {
    return ((*domain).dim[DIM_X as ::core::ffi::c_int as usize].min
        <= (*search_space).dim[DIM_X as ::core::ffi::c_int as usize].max
        && (*domain).dim[DIM_X as ::core::ffi::c_int as usize].min
            >= (*search_space).dim[DIM_X as ::core::ffi::c_int as usize].min
        && (*domain).dim[DIM_X as ::core::ffi::c_int as usize].max
            <= (*search_space).dim[DIM_X as ::core::ffi::c_int as usize].max
        && (*domain).dim[DIM_X as ::core::ffi::c_int as usize].max
            >= (*search_space).dim[DIM_X as ::core::ffi::c_int as usize].min
        && (*domain).dim[DIM_Y as ::core::ffi::c_int as usize].min
            <= (*search_space).dim[DIM_Y as ::core::ffi::c_int as usize].max
        && (*domain).dim[DIM_Y as ::core::ffi::c_int as usize].min
            >= (*search_space).dim[DIM_Y as ::core::ffi::c_int as usize].min
        && (*domain).dim[DIM_Y as ::core::ffi::c_int as usize].max
            <= (*search_space).dim[DIM_Y as ::core::ffi::c_int as usize].max
        && (*domain).dim[DIM_Y as ::core::ffi::c_int as usize].max
            >= (*search_space).dim[DIM_Y as ::core::ffi::c_int as usize].min
        && (*domain).dim[DIM_Z as ::core::ffi::c_int as usize].min
            <= (*search_space).dim[DIM_Z as ::core::ffi::c_int as usize].max
        && (*domain).dim[DIM_Z as ::core::ffi::c_int as usize].min
            >= (*search_space).dim[DIM_Z as ::core::ffi::c_int as usize].min
        && (*domain).dim[DIM_Z as ::core::ffi::c_int as usize].max
            <= (*search_space).dim[DIM_Z as ::core::ffi::c_int as usize].max
        && (*domain).dim[DIM_Z as ::core::ffi::c_int as usize].max
            >= (*search_space).dim[DIM_Z as ::core::ffi::c_int as usize].min)
        as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn _search_area_intersects(
    mut search_space: *const space,
    mut domain: *const space,
) -> ::core::ffi::c_int {
    return !((*search_space).dim[DIM_X as ::core::ffi::c_int as usize].min
        > (*domain).dim[DIM_X as ::core::ffi::c_int as usize].max
        || (*search_space).dim[DIM_X as ::core::ffi::c_int as usize].max
            < (*domain).dim[DIM_X as ::core::ffi::c_int as usize].min
        || (*search_space).dim[DIM_Y as ::core::ffi::c_int as usize].min
            > (*domain).dim[DIM_Y as ::core::ffi::c_int as usize].max
        || (*search_space).dim[DIM_Y as ::core::ffi::c_int as usize].max
            < (*domain).dim[DIM_Y as ::core::ffi::c_int as usize].min
        || (*search_space).dim[DIM_Z as ::core::ffi::c_int as usize].min
            > (*domain).dim[DIM_Z as ::core::ffi::c_int as usize].max
        || (*search_space).dim[DIM_Z as ::core::ffi::c_int as usize].max
            < (*domain).dim[DIM_Z as ::core::ffi::c_int as usize].min)
        as ::core::ffi::c_int;
}
unsafe extern "C" fn _report_all_leaves(
    mut tree: *const kdtree,
    mut node: *const tree_node,
    mut iter: *mut kdtree_iterator,
) {
    if _is_leaf_node(node) != 0 {
        _iterator_push(iter, (*(*tree).points.offset((*node).idx as isize)).idx);
    } else {
        _report_all_leaves(tree, (*node).left, iter);
        _report_all_leaves(tree, (*node).right, iter);
    };
}
#[inline]
unsafe extern "C" fn _explore_branch(
    mut tree: *mut kdtree,
    mut node: *mut tree_node,
    mut depth: size_t,
    mut search_space: *const space,
    mut domain: *const space,
    mut iter: *mut kdtree_iterator,
) {
    if _is_leaf_node(node) != 0 {
        if _point_in_search_space(
            (*tree).points.offset((*node).idx as isize),
            search_space,
        ) != 0
        {
            _iterator_push(iter, (*(*tree).points.offset((*node).idx as isize)).idx);
        }
    } else if _search_area_intersects(search_space, domain) != 0 {
        if _completely_enclosed(search_space, domain) != 0 {
            _report_all_leaves(tree, node, iter);
        } else {
            _search_kdtree(
                tree,
                node,
                depth.wrapping_add(1 as size_t),
                search_space,
                domain,
                iter,
            );
        }
    }
}
unsafe extern "C" fn _search_kdtree(
    mut tree: *mut kdtree,
    mut root: *mut tree_node,
    mut depth: size_t,
    mut search_space: *const space,
    mut domain: *const space,
    mut iter: *mut kdtree_iterator,
) {
    let axis: size_t = depth.wrapping_rem(NDIMS as ::core::ffi::c_int as size_t);
    let mut new_domain: space = space {
        dim: [boundaries { min: 0., max: 0. }; 3],
    };
    memcpy(
        &mut new_domain as *mut space as *mut ::core::ffi::c_void,
        domain as *const ::core::ffi::c_void,
        ::core::mem::size_of::<space>() as size_t,
    );
    new_domain.dim[axis as usize].max = (*root).split;
    _explore_branch(tree, (*root).left, depth, search_space, &mut new_domain, iter);
    new_domain.dim[axis as usize].max = (*domain).dim[axis as usize].max;
    new_domain.dim[axis as usize].min = (*root).split;
    _explore_branch(tree, (*root).right, depth, search_space, &mut new_domain, iter);
}
unsafe extern "C" fn _build_kdtree(
    mut idx_from: size_t,
    mut idx_to: size_t,
    mut depth: size_t,
    mut tree: *mut kdtree,
) -> *mut tree_node {
    let mut split: ::core::ffi::c_double = 0.;
    let mut node: *mut tree_node = 0 as *mut tree_node;
    let mut point: *mut data_point = 0 as *mut data_point;
    let count: size_t = idx_to.wrapping_sub(idx_from).wrapping_add(1 as size_t);
    let mid: size_t = idx_from
        .wrapping_add(idx_to.wrapping_sub(idx_from).wrapping_div(2 as size_t));
    let axis: size_t = depth.wrapping_rem(NDIMS as ::core::ffi::c_int as size_t);
    if count == 1 as size_t {
        return _get_leaf_node(tree, idx_from);
    }
    qsort(
        (*tree).points.offset(idx_from as isize) as *mut ::core::ffi::c_void,
        count,
        ::core::mem::size_of::<data_point>() as size_t,
        func_select[axis as usize],
    );
    point = &mut *(*tree).points.offset(mid as isize) as *mut data_point;
    split = if axis == 0 as size_t {
        (*point).x
    } else if axis == 1 as size_t {
        (*point).y
    } else {
        (*point).z
    };
    node = _get_branch_node(tree, split);
    (*node).left = _build_kdtree(idx_from, mid, depth.wrapping_add(1 as size_t), tree);
    (*node).right = _build_kdtree(
        mid.wrapping_add(1 as size_t),
        idx_to,
        depth.wrapping_add(1 as size_t),
        tree,
    );
    return node;
}
#[inline]
unsafe extern "C" fn _iterator_new() -> *mut kdtree_iterator {
    let mut iter: *mut kdtree_iterator = malloc(
        ::core::mem::size_of::<kdtree_iterator>() as size_t,
    ) as *mut kdtree_iterator;
    if iter.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"_iterator_new\0")
                .as_ptr(),
            b"kdtree.c\0" as *const u8 as *const ::core::ffi::c_char,
            450 as ::core::ffi::c_int,
            b"iter != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    (*iter).current = 0 as size_t;
    (*iter).size = 0 as size_t;
    (*iter).capacity = KDTREE_ITERATOR_INITIAL_SIZE as size_t;
    (*iter).data = malloc(
        (::core::mem::size_of::<size_t>() as size_t).wrapping_mul((*iter).capacity),
    ) as *mut size_t;
    if (*iter).data.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"_iterator_new\0")
                .as_ptr(),
            b"kdtree.c\0" as *const u8 as *const ::core::ffi::c_char,
            456 as ::core::ffi::c_int,
            b"iter->data != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return iter;
}
#[inline]
unsafe extern "C" fn _iterator_reset(mut iter: *mut kdtree_iterator) {
    if iter.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"_iterator_reset\0")
                .as_ptr(),
            b"kdtree.c\0" as *const u8 as *const ::core::ffi::c_char,
            463 as ::core::ffi::c_int,
            b"iter != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    (*iter).size = 0 as size_t;
    (*iter).current = 0 as size_t;
}
#[inline]
unsafe extern "C" fn _iterator_push(mut iter: *mut kdtree_iterator, mut value: size_t) {
    if (*iter).size == (*iter).capacity {
        if !(2 as ::core::ffi::c_int as ::core::ffi::c_double > 1.0f64)
            as ::core::ffi::c_int as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 15],
                    [::core::ffi::c_char; 15],
                >(*b"_iterator_push\0")
                    .as_ptr(),
                b"kdtree.c\0" as *const u8 as *const ::core::ffi::c_char,
                471 as ::core::ffi::c_int,
                b"KDTREE_ITERATOR_GROWTH_RATIO > 1.0\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        } else {};
        (*iter).capacity = (*iter)
            .capacity
            .wrapping_mul(KDTREE_ITERATOR_GROWTH_RATIO as size_t);
        (*iter).data = realloc(
            (*iter).data as *mut ::core::ffi::c_void,
            (::core::mem::size_of::<size_t>() as size_t).wrapping_mul((*iter).capacity),
        ) as *mut size_t;
    }
    let fresh1 = (*iter).size;
    (*iter).size = (*iter).size.wrapping_add(1);
    *(*iter).data.offset(fresh1 as isize) = value;
}
pub const __DBL_MAX__: ::core::ffi::c_double = 1.7976931348623157e+308f64;
pub const DBL_MAX: ::core::ffi::c_double = __DBL_MAX__;
