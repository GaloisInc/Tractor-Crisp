#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn qsort(
        __base: *mut ::core::ffi::c_void,
        __nel: size_t,
        __width: size_t,
        __compar: Option<
            unsafe extern "C" fn(
                *const ::core::ffi::c_void,
                *const ::core::ffi::c_void,
            ) -> ::core::ffi::c_int,
        >,
    );
    fn kdtree_build(
        x_0: *mut ::core::ffi::c_double,
        y_0: *mut ::core::ffi::c_double,
        z_0: *mut ::core::ffi::c_double,
        count: size_t,
        tree: *mut *mut kdtree,
    );
    fn kdtree_delete(tree_ptr: *mut *mut kdtree);
    fn kdtree_search(
        tree: *mut kdtree,
        iter_ptr: *mut *mut kdtree_iterator,
        x_0: ::core::ffi::c_double,
        y_0: ::core::ffi::c_double,
        z_0: ::core::ffi::c_double,
        apothem: ::core::ffi::c_double,
    );
    fn kdtree_search_space(
        tree: *mut kdtree,
        iter_ptr: *mut *mut kdtree_iterator,
        x_min: ::core::ffi::c_double,
        x_max: ::core::ffi::c_double,
        y_min: ::core::ffi::c_double,
        y_max: ::core::ffi::c_double,
        z_min: ::core::ffi::c_double,
        z_max: ::core::ffi::c_double,
    );
    fn kdtree_iterator_get_next(iter: *mut kdtree_iterator) -> size_t;
    fn kdtree_iterator_delete(iter_ptr: *mut *mut kdtree_iterator);
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct data_point {
    pub x: ::core::ffi::c_double,
    pub y: ::core::ffi::c_double,
    pub z: ::core::ffi::c_double,
    pub idx: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tree_node {
    pub left: *mut tree_node,
    pub right: *mut tree_node,
    pub split: ::core::ffi::c_double,
    pub idx: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct kdtree {
    pub count: size_t,
    pub max_nodes: size_t,
    pub next_node: size_t,
    pub points: *mut data_point,
    pub node_data: *mut tree_node,
    pub root: *mut tree_node,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct kdtree_iterator {
    pub data: *mut size_t,
    pub capacity: size_t,
    pub size: size_t,
    pub current: size_t,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub static mut x: *mut ::core::ffi::c_double = 0 as *const ::core::ffi::c_double
    as *mut ::core::ffi::c_double;
#[no_mangle]
pub static mut y: *mut ::core::ffi::c_double = 0 as *const ::core::ffi::c_double
    as *mut ::core::ffi::c_double;
#[no_mangle]
pub static mut z: *mut ::core::ffi::c_double = 0 as *const ::core::ffi::c_double
    as *mut ::core::ffi::c_double;
#[inline]
unsafe extern "C" fn set_point(
    mut idx: size_t,
    mut X: ::core::ffi::c_double,
    mut Y: ::core::ffi::c_double,
    mut Z: ::core::ffi::c_double,
) {
    *x.offset(idx as isize) = X;
    *y.offset(idx as isize) = Y;
    *z.offset(idx as isize) = Z;
}
unsafe extern "C" fn initialise_points() {
    x = malloc(
        (::core::mem::size_of::<::core::ffi::c_double>() as size_t)
            .wrapping_mul(11 as size_t),
    ) as *mut ::core::ffi::c_double;
    y = malloc(
        (::core::mem::size_of::<::core::ffi::c_double>() as size_t)
            .wrapping_mul(11 as size_t),
    ) as *mut ::core::ffi::c_double;
    z = malloc(
        (::core::mem::size_of::<::core::ffi::c_double>() as size_t)
            .wrapping_mul(11 as size_t),
    ) as *mut ::core::ffi::c_double;
    set_point(0 as size_t, 0.5f64, 0.5f64, 0.5f64);
    set_point(1 as size_t, 0.5f64, 0.5f64, 0.5f64);
    set_point(2 as size_t, 0.5f64, 0.5f64, 0.5f64);
    set_point(3 as size_t, 0.0f64, 0.0f64, 0.0f64);
    set_point(4 as size_t, 1.0f64, 0.0f64, 0.0f64);
    set_point(5 as size_t, 1.0f64, 1.0f64, 0.0f64);
    set_point(6 as size_t, 0.0f64, 1.0f64, 0.0f64);
    set_point(7 as size_t, 0.0f64, 0.0f64, 1.0f64);
    set_point(8 as size_t, 1.0f64, 0.0f64, 1.0f64);
    set_point(9 as size_t, 1.0f64, 1.0f64, 1.0f64);
    set_point(10 as size_t, 0.0f64, 1.0f64, 1.0f64);
}
unsafe extern "C" fn cmp(
    mut v1: *const ::core::ffi::c_void,
    mut v2: *const ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    let a: ::core::ffi::c_int = *(v1 as *const ::core::ffi::c_int);
    let b: ::core::ffi::c_int = *(v2 as *const ::core::ffi::c_int);
    return if a > b {
        1 as ::core::ffi::c_int
    } else if a < b {
        -(1 as ::core::ffi::c_int)
    } else {
        0 as ::core::ffi::c_int
    };
}
unsafe extern "C" fn validate(
    mut iter: *mut kdtree_iterator,
    mut count: size_t,
    mut v: *const size_t,
) {
    let mut i: size_t = 0 as size_t;
    let mut content: *mut size_t = 0 as *mut size_t;
    if iter.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 9], [::core::ffi::c_char; 9]>(*b"validate\0")
                .as_ptr(),
            b"run_test.c\0" as *const u8 as *const ::core::ffi::c_char,
            40 as ::core::ffi::c_int,
            b"iter != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*iter).size == count) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 9], [::core::ffi::c_char; 9]>(*b"validate\0")
                .as_ptr(),
            b"run_test.c\0" as *const u8 as *const ::core::ffi::c_char,
            41 as ::core::ffi::c_int,
            b"iter->size == count\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    content = malloc((::core::mem::size_of::<size_t>() as size_t).wrapping_mul(count))
        as *mut size_t;
    i = 0 as size_t;
    while i < count {
        *content.offset(i as isize) = kdtree_iterator_get_next(iter);
        i = i.wrapping_add(1);
    }
    if !(kdtree_iterator_get_next(iter) == 18446744073709551615 as size_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 9], [::core::ffi::c_char; 9]>(*b"validate\0")
                .as_ptr(),
            b"run_test.c\0" as *const u8 as *const ::core::ffi::c_char,
            45 as ::core::ffi::c_int,
            b"kdtree_iterator_get_next(iter) == KDTREE_END\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    qsort(
        content as *mut ::core::ffi::c_void,
        count,
        ::core::mem::size_of::<size_t>() as size_t,
        Some(
            cmp
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                    *const ::core::ffi::c_void,
                ) -> ::core::ffi::c_int,
        ),
    );
    i = 0 as size_t;
    while i < count {
        if !(*content.offset(i as isize) == *v.offset(i as isize)) as ::core::ffi::c_int
            as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 9],
                    [::core::ffi::c_char; 9],
                >(*b"validate\0")
                    .as_ptr(),
                b"run_test.c\0" as *const u8 as *const ::core::ffi::c_char,
                48 as ::core::ffi::c_int,
                b"content[i] == v[i]\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        i = i.wrapping_add(1);
    }
    free(content as *mut ::core::ffi::c_void);
}
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut tree: *mut kdtree = 0 as *mut kdtree;
    let mut iter: *mut kdtree_iterator = 0 as *mut kdtree_iterator;
    initialise_points();
    kdtree_build(x, y, z, 11 as size_t, &mut tree);
    kdtree_search(
        tree,
        &mut iter,
        -(10 as ::core::ffi::c_int) as ::core::ffi::c_double,
        0 as ::core::ffi::c_int as ::core::ffi::c_double,
        0 as ::core::ffi::c_int as ::core::ffi::c_double,
        9.999f64,
    );
    let e0: [size_t; 1] = [0 as ::core::ffi::c_int as size_t];
    validate(iter, 0 as size_t, e0.as_ptr());
    kdtree_search(
        tree,
        &mut iter,
        0 as ::core::ffi::c_int as ::core::ffi::c_double,
        0 as ::core::ffi::c_int as ::core::ffi::c_double,
        0 as ::core::ffi::c_int as ::core::ffi::c_double,
        0.499f64,
    );
    let e1: [size_t; 1] = [3 as ::core::ffi::c_int as size_t];
    validate(iter, 1 as size_t, e1.as_ptr());
    kdtree_search(tree, &mut iter, 0.5f64, 0.5f64, 0.5f64, 0.5f64);
    let e2: [size_t; 11] = [
        0 as ::core::ffi::c_int as size_t,
        1 as ::core::ffi::c_int as size_t,
        2 as ::core::ffi::c_int as size_t,
        3 as ::core::ffi::c_int as size_t,
        4 as ::core::ffi::c_int as size_t,
        5 as ::core::ffi::c_int as size_t,
        6 as ::core::ffi::c_int as size_t,
        7 as ::core::ffi::c_int as size_t,
        8 as ::core::ffi::c_int as size_t,
        9 as ::core::ffi::c_int as size_t,
        10 as ::core::ffi::c_int as size_t,
    ];
    validate(iter, 11 as size_t, e2.as_ptr());
    kdtree_search(tree, &mut iter, 0.5f64, 0.5f64, 0.5f64, 100.0f64);
    validate(iter, 11 as size_t, e2.as_ptr());
    kdtree_search(tree, &mut iter, 0.5f64, 0.5f64, 0.0f64, 0.5f64);
    let e3: [size_t; 7] = [
        0 as ::core::ffi::c_int as size_t,
        1 as ::core::ffi::c_int as size_t,
        2 as ::core::ffi::c_int as size_t,
        3 as ::core::ffi::c_int as size_t,
        4 as ::core::ffi::c_int as size_t,
        5 as ::core::ffi::c_int as size_t,
        6 as ::core::ffi::c_int as size_t,
    ];
    validate(iter, 7 as size_t, e3.as_ptr());
    kdtree_search(tree, &mut iter, 0.5f64, 0.5f64, 1.0f64, 0.5f64);
    let e4: [size_t; 7] = [
        0 as ::core::ffi::c_int as size_t,
        1 as ::core::ffi::c_int as size_t,
        2 as ::core::ffi::c_int as size_t,
        7 as ::core::ffi::c_int as size_t,
        8 as ::core::ffi::c_int as size_t,
        9 as ::core::ffi::c_int as size_t,
        10 as ::core::ffi::c_int as size_t,
    ];
    validate(iter, 7 as size_t, e4.as_ptr());
    kdtree_search_space(tree, &mut iter, 0.0f64, 1.0f64, 0.5f64, 1.0f64, 0.0f64, 1.0f64);
    let e5: [size_t; 7] = [
        0 as ::core::ffi::c_int as size_t,
        1 as ::core::ffi::c_int as size_t,
        2 as ::core::ffi::c_int as size_t,
        5 as ::core::ffi::c_int as size_t,
        6 as ::core::ffi::c_int as size_t,
        9 as ::core::ffi::c_int as size_t,
        10 as ::core::ffi::c_int as size_t,
    ];
    validate(iter, 7 as size_t, e5.as_ptr());
    printf(
        b"\n ---- ALL TESTS PASSED ---- \n\0" as *const u8 as *const ::core::ffi::c_char,
    );
    kdtree_iterator_delete(&mut iter);
    kdtree_delete(&mut tree);
    free(x as *mut ::core::ffi::c_void);
    free(y as *mut ::core::ffi::c_void);
    free(z as *mut ::core::ffi::c_void);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
