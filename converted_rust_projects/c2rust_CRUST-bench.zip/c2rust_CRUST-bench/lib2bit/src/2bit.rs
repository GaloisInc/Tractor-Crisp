#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types, linkage)]
extern "C" {
    pub type __sFILEX;
    fn fstat(_: ::core::ffi::c_int, _: *mut stat) -> ::core::ffi::c_int;
    fn mmap(
        _: *mut ::core::ffi::c_void,
        _: size_t,
        _: ::core::ffi::c_int,
        _: ::core::ffi::c_int,
        _: ::core::ffi::c_int,
        _: off_t,
    ) -> *mut ::core::ffi::c_void;
    fn munmap(_: *mut ::core::ffi::c_void, _: size_t) -> ::core::ffi::c_int;
    fn madvise(
        _: *mut ::core::ffi::c_void,
        _: size_t,
        _: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    static mut __stderrp: *mut FILE;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn fread(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
        __nitems: size_t,
        __stream: *mut FILE,
    ) -> ::core::ffi::c_ulong;
    fn fseek(
        _: *mut FILE,
        _: ::core::ffi::c_long,
        _: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn ftell(_: *mut FILE) -> ::core::ffi::c_long;
    fn fileno(_: *mut FILE) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn calloc(__count: size_t, __size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn __tolower(_: __darwin_ct_rune_t) -> __darwin_ct_rune_t;
}
pub type __uint16_t = u16;
pub type __int32_t = i32;
pub type __uint32_t = u32;
pub type __int64_t = i64;
pub type __uint64_t = u64;
pub type __darwin_ct_rune_t = ::core::ffi::c_int;
pub type __darwin_size_t = usize;
pub type __darwin_time_t = ::core::ffi::c_long;
pub type __darwin_blkcnt_t = __int64_t;
pub type __darwin_blksize_t = __int32_t;
pub type __darwin_dev_t = __int32_t;
pub type __darwin_gid_t = __uint32_t;
pub type __darwin_ino64_t = __uint64_t;
pub type __darwin_mode_t = __uint16_t;
pub type __darwin_off_t = __int64_t;
pub type __darwin_uid_t = __uint32_t;
pub type uint8_t = u8;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type dev_t = __darwin_dev_t;
pub type blkcnt_t = __darwin_blkcnt_t;
pub type blksize_t = __darwin_blksize_t;
pub type gid_t = __darwin_gid_t;
pub type mode_t = __darwin_mode_t;
pub type nlink_t = __uint16_t;
pub type off_t = __darwin_off_t;
pub type uid_t = __darwin_uid_t;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct timespec {
    pub tv_sec: __darwin_time_t,
    pub tv_nsec: ::core::ffi::c_long,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct stat {
    pub st_dev: dev_t,
    pub st_mode: mode_t,
    pub st_nlink: nlink_t,
    pub st_ino: __darwin_ino64_t,
    pub st_uid: uid_t,
    pub st_gid: gid_t,
    pub st_rdev: dev_t,
    pub st_atimespec: timespec,
    pub st_mtimespec: timespec,
    pub st_ctimespec: timespec,
    pub st_birthtimespec: timespec,
    pub st_size: off_t,
    pub st_blocks: blkcnt_t,
    pub st_blksize: blksize_t,
    pub st_flags: __uint32_t,
    pub st_gen: __uint32_t,
    pub st_lspare: __int32_t,
    pub st_qspare: [__int64_t; 2],
}
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct TwoBitHeader {
    pub magic: uint32_t,
    pub version: uint32_t,
    pub nChroms: uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct TwoBitCL {
    pub chrom: *mut *mut ::core::ffi::c_char,
    pub offset: *mut uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct TwoBitMaskedIdx {
    pub size: *mut uint32_t,
    pub nBlockCount: *mut uint32_t,
    pub nBlockStart: *mut *mut uint32_t,
    pub nBlockSizes: *mut *mut uint32_t,
    pub maskBlockCount: *mut uint32_t,
    pub maskBlockStart: *mut *mut uint32_t,
    pub maskBlockSizes: *mut *mut uint32_t,
    pub offset: *mut uint64_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct TwoBit {
    pub fp: *mut FILE,
    pub sz: uint64_t,
    pub offset: uint64_t,
    pub data: *mut ::core::ffi::c_void,
    pub hdr: *mut TwoBitHeader,
    pub cl: *mut TwoBitCL,
    pub idx: *mut TwoBitMaskedIdx,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const PROT_READ: ::core::ffi::c_int = 0x1 as ::core::ffi::c_int;
pub const MAP_SHARED: ::core::ffi::c_int = 0x1 as ::core::ffi::c_int;
pub const POSIX_MADV_RANDOM: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const MADV_RANDOM: ::core::ffi::c_int = POSIX_MADV_RANDOM;
pub const SEEK_SET: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn tolower(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __tolower(_c as __darwin_ct_rune_t) as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn twobitRead(
    mut data: *mut ::core::ffi::c_void,
    mut sz: size_t,
    mut nmemb: size_t,
    mut tb: *mut TwoBit,
) -> size_t {
    if !(*tb).data.is_null() {
        if memcpy(data, (*tb).data.offset((*tb).offset as isize), nmemb.wrapping_mul(sz))
            .is_null()
        {
            return 0 as size_t;
        }
        (*tb).offset = (*tb).offset.wrapping_add(nmemb.wrapping_mul(sz) as uint64_t);
        return nmemb;
    } else {
        return fread(data, sz, nmemb, (*tb).fp) as size_t
    };
}
#[no_mangle]
pub unsafe extern "C" fn twobitSeek(
    mut tb: *mut TwoBit,
    mut offset: uint64_t,
) -> ::core::ffi::c_int {
    if offset >= (*tb).sz {
        return -(1 as ::core::ffi::c_int);
    }
    if !(*tb).data.is_null() {
        (*tb).offset = offset;
        return 0 as ::core::ffi::c_int;
    } else {
        return fseek((*tb).fp, offset as ::core::ffi::c_long, SEEK_SET)
    };
}
#[no_mangle]
pub unsafe extern "C" fn twobitTell(mut tb: *mut TwoBit) -> uint64_t {
    if !(*tb).data.is_null() {
        return (*tb).offset;
    }
    return ftell((*tb).fp) as uint64_t;
}
#[no_mangle]
pub unsafe extern "C" fn byte2base(
    mut byte: uint8_t,
    mut offset: ::core::ffi::c_int,
) -> ::core::ffi::c_char {
    let mut rev: ::core::ffi::c_int = 3 as ::core::ffi::c_int - offset;
    let mut mask: uint8_t = ((3 as ::core::ffi::c_int) << 2 as ::core::ffi::c_int * rev)
        as uint8_t;
    let mut foo: ::core::ffi::c_int = (mask as ::core::ffi::c_int
        & byte as ::core::ffi::c_int) >> 2 as ::core::ffi::c_int * rev;
    let mut bases: [::core::ffi::c_char; 4] = ::core::mem::transmute::<
        [u8; 4],
        [::core::ffi::c_char; 4],
    >(*b"TCAG");
    return bases[foo as usize];
}
#[no_mangle]
pub unsafe extern "C" fn bytes2bases(
    mut seq: *mut ::core::ffi::c_char,
    mut byte: *mut uint8_t,
    mut sz: uint32_t,
    mut offset: ::core::ffi::c_int,
) {
    let mut pos: uint32_t = 0 as uint32_t;
    let mut remainder: uint32_t = 0 as uint32_t;
    let mut i: uint32_t = 0 as uint32_t;
    let mut bases: [::core::ffi::c_char; 4] = ::core::mem::transmute::<
        [u8; 4],
        [::core::ffi::c_char; 4],
    >(*b"TCAG");
    let mut foo: uint8_t = *byte.offset(0 as ::core::ffi::c_int as isize);
    if offset != 0 as ::core::ffi::c_int {
        while offset < 4 as ::core::ffi::c_int && pos < sz {
            let fresh5 = offset;
            offset = offset + 1;
            let fresh6 = pos;
            pos = pos.wrapping_add(1);
            *seq.offset(fresh6 as isize) = byte2base(foo, fresh5);
        }
        if pos >= sz {
            return;
        }
        i = i.wrapping_add(1);
        foo = *byte.offset(i as isize);
    }
    remainder = sz.wrapping_sub(pos).wrapping_rem(4 as uint32_t);
    while pos < sz.wrapping_sub(remainder) {
        let fresh7 = i;
        i = i.wrapping_add(1);
        foo = *byte.offset(fresh7 as isize);
        *seq.offset(pos.wrapping_add(3 as uint32_t) as isize) = bases[(foo
            as ::core::ffi::c_int & 3 as ::core::ffi::c_int) as usize];
        foo = (foo as ::core::ffi::c_int >> 2 as ::core::ffi::c_int) as uint8_t;
        *seq.offset(pos.wrapping_add(2 as uint32_t) as isize) = bases[(foo
            as ::core::ffi::c_int & 3 as ::core::ffi::c_int) as usize];
        foo = (foo as ::core::ffi::c_int >> 2 as ::core::ffi::c_int) as uint8_t;
        *seq.offset(pos.wrapping_add(1 as uint32_t) as isize) = bases[(foo
            as ::core::ffi::c_int & 3 as ::core::ffi::c_int) as usize];
        foo = (foo as ::core::ffi::c_int >> 2 as ::core::ffi::c_int) as uint8_t;
        *seq.offset(pos as isize) = bases[(foo as ::core::ffi::c_int
            & 3 as ::core::ffi::c_int) as usize];
        foo = (foo as ::core::ffi::c_int >> 2 as ::core::ffi::c_int) as uint8_t;
        pos = pos.wrapping_add(4 as uint32_t);
    }
    if remainder > 0 as uint32_t {
        foo = *byte.offset(i as isize);
    }
    offset = 0 as ::core::ffi::c_int;
    while (offset as uint32_t) < remainder {
        let fresh8 = pos;
        pos = pos.wrapping_add(1);
        *seq.offset(fresh8 as isize) = byte2base(foo, offset);
        offset += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn NMask(
    mut seq: *mut ::core::ffi::c_char,
    mut tb: *mut TwoBit,
    mut tid: uint32_t,
    mut start: uint32_t,
    mut end: uint32_t,
) {
    let mut i: uint32_t = 0;
    let mut width: uint32_t = 0;
    let mut pos: uint32_t = 0 as uint32_t;
    let mut blockStart: uint32_t = 0;
    let mut blockEnd: uint32_t = 0;
    i = 0 as uint32_t;
    while i < *(*(*tb).idx).nBlockCount.offset(tid as isize) {
        blockStart = *(*(*(*tb).idx).nBlockStart.offset(tid as isize))
            .offset(i as isize);
        blockEnd = blockStart
            .wrapping_add(
                *(*(*(*tb).idx).nBlockSizes.offset(tid as isize)).offset(i as isize),
            );
        if !(blockEnd <= start) {
            if blockStart >= end {
                break;
            }
            if blockStart < start {
                blockEnd = if blockEnd < end { blockEnd } else { end };
                pos = 0 as uint32_t;
                width = blockEnd.wrapping_sub(start);
            } else {
                blockEnd = if blockEnd < end { blockEnd } else { end };
                pos = blockStart.wrapping_sub(start);
                width = blockEnd.wrapping_sub(blockStart);
            }
            width = width.wrapping_add(pos);
            while pos < width {
                *seq.offset(pos as isize) = 'N' as i32 as ::core::ffi::c_char;
                pos = pos.wrapping_add(1);
            }
        }
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn softMask(
    mut seq: *mut ::core::ffi::c_char,
    mut tb: *mut TwoBit,
    mut tid: uint32_t,
    mut start: uint32_t,
    mut end: uint32_t,
) {
    let mut i: uint32_t = 0;
    let mut width: uint32_t = 0;
    let mut pos: uint32_t = 0 as uint32_t;
    let mut blockStart: uint32_t = 0;
    let mut blockEnd: uint32_t = 0;
    if (*(*tb).idx).maskBlockStart.is_null() {
        return;
    }
    i = 0 as uint32_t;
    while i < *(*(*tb).idx).maskBlockCount.offset(tid as isize) {
        blockStart = *(*(*(*tb).idx).maskBlockStart.offset(tid as isize))
            .offset(i as isize);
        blockEnd = blockStart
            .wrapping_add(
                *(*(*(*tb).idx).maskBlockSizes.offset(tid as isize)).offset(i as isize),
            );
        if !(blockEnd <= start) {
            if blockStart >= end {
                break;
            }
            if blockStart < start {
                blockEnd = if blockEnd < end { blockEnd } else { end };
                pos = 0 as uint32_t;
                width = blockEnd.wrapping_sub(start);
            } else {
                blockEnd = if blockEnd < end { blockEnd } else { end };
                pos = blockStart.wrapping_sub(start);
                width = blockEnd.wrapping_sub(blockStart);
            }
            width = width.wrapping_add(pos);
            while pos < width {
                if *seq.offset(pos as isize) as ::core::ffi::c_int != 'N' as i32 {
                    *seq.offset(pos as isize) = tolower(
                        *seq.offset(pos as isize) as ::core::ffi::c_int,
                    ) as ::core::ffi::c_char;
                }
                pos = pos.wrapping_add(1);
            }
        }
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn constructSequence(
    mut tb: *mut TwoBit,
    mut tid: uint32_t,
    mut start: uint32_t,
    mut end: uint32_t,
) -> *mut ::core::ffi::c_char {
    let mut sz: uint32_t = end.wrapping_sub(start).wrapping_add(1 as uint32_t);
    let mut blockStart: uint32_t = 0;
    let mut blockEnd: uint32_t = 0;
    let mut seq: *mut ::core::ffi::c_char = malloc(
        (sz as size_t)
            .wrapping_mul(::core::mem::size_of::<::core::ffi::c_char>() as size_t),
    ) as *mut ::core::ffi::c_char;
    let mut bytes: *mut uint8_t = 0 as *mut uint8_t;
    let mut offset: ::core::ffi::c_int = 0;
    if seq.is_null() {
        return 0 as *mut ::core::ffi::c_char;
    }
    blockStart = start.wrapping_div(4 as uint32_t);
    offset = start.wrapping_rem(4 as uint32_t) as ::core::ffi::c_int;
    blockEnd = end
        .wrapping_div(4 as uint32_t)
        .wrapping_add(
            (if end.wrapping_rem(4 as uint32_t) != 0 {
                1 as ::core::ffi::c_int
            } else {
                0 as ::core::ffi::c_int
            }) as uint32_t,
        );
    bytes = malloc(blockEnd.wrapping_sub(blockStart) as size_t) as *mut uint8_t;
    if !bytes.is_null() {
        if !(twobitSeek(
            tb,
            (*(*(*tb).idx).offset.offset(tid as isize))
                .wrapping_add(blockStart as uint64_t),
        ) != 0 as ::core::ffi::c_int)
        {
            if !(twobitRead(
                bytes as *mut ::core::ffi::c_void,
                blockEnd.wrapping_sub(blockStart) as size_t,
                1 as size_t,
                tb,
            ) != 1 as size_t)
            {
                bytes2bases(seq, bytes, sz.wrapping_sub(1 as uint32_t), offset);
                free(bytes as *mut ::core::ffi::c_void);
                *seq.offset(sz.wrapping_sub(1 as uint32_t) as isize) = '\0' as i32
                    as ::core::ffi::c_char;
                NMask(seq, tb, tid, start, end);
                softMask(seq, tb, tid, start, end);
                return seq;
            }
        }
    }
    if !seq.is_null() {
        free(seq as *mut ::core::ffi::c_void);
    }
    if !bytes.is_null() {
        free(bytes as *mut ::core::ffi::c_void);
    }
    return 0 as *mut ::core::ffi::c_char;
}
#[no_mangle]
pub unsafe extern "C" fn twobitSequence(
    mut tb: *mut TwoBit,
    mut chrom: *mut ::core::ffi::c_char,
    mut start: uint32_t,
    mut end: uint32_t,
) -> *mut ::core::ffi::c_char {
    let mut i: uint32_t = 0;
    let mut tid: uint32_t = 0 as uint32_t;
    i = 0 as uint32_t;
    while i < (*(*tb).hdr).nChroms {
        if strcmp(*(*(*tb).cl).chrom.offset(i as isize), chrom)
            == 0 as ::core::ffi::c_int
        {
            tid = i;
            break;
        } else {
            i = i.wrapping_add(1);
        }
    }
    if tid == 0 as uint32_t
        && strcmp(*(*(*tb).cl).chrom.offset(i as isize), chrom)
            != 0 as ::core::ffi::c_int
    {
        return 0 as *mut ::core::ffi::c_char;
    }
    if start == end && end == 0 as uint32_t {
        end = *(*(*tb).idx).size.offset(tid as isize);
    }
    if end > *(*(*tb).idx).size.offset(tid as isize) {
        return 0 as *mut ::core::ffi::c_char;
    }
    if start >= end {
        return 0 as *mut ::core::ffi::c_char;
    }
    return constructSequence(tb, tid, start, end);
}
#[no_mangle]
pub unsafe extern "C" fn getMask(
    mut tb: *mut TwoBit,
    mut tid: uint32_t,
    mut start: uint32_t,
    mut end: uint32_t,
    mut maskIdx: *mut uint32_t,
    mut maskStart: *mut uint32_t,
    mut maskEnd: *mut uint32_t,
) {
    if *maskIdx == -(1 as ::core::ffi::c_int) as uint32_t {
        *maskIdx = 0 as uint32_t;
        while *maskIdx < *(*(*tb).idx).nBlockCount.offset(tid as isize) {
            *maskStart = *(*(*(*tb).idx).nBlockStart.offset(tid as isize))
                .offset(*maskIdx as isize);
            *maskEnd = (*maskStart)
                .wrapping_add(
                    *(*(*(*tb).idx).nBlockSizes.offset(tid as isize))
                        .offset(*maskIdx as isize),
                );
            if !(*maskEnd < start) {
                if *maskEnd >= start {
                    break;
                }
            }
            *maskIdx = (*maskIdx).wrapping_add(1);
        }
    } else if *maskIdx >= *(*(*tb).idx).nBlockCount.offset(tid as isize) {
        *maskStart = -(1 as ::core::ffi::c_int) as uint32_t;
        *maskEnd = -(1 as ::core::ffi::c_int) as uint32_t;
    } else {
        *maskIdx = (*maskIdx).wrapping_add(1 as uint32_t);
        if *maskIdx >= *(*(*tb).idx).nBlockCount.offset(tid as isize) {
            *maskStart = -(1 as ::core::ffi::c_int) as uint32_t;
            *maskEnd = -(1 as ::core::ffi::c_int) as uint32_t;
        } else {
            *maskStart = *(*(*(*tb).idx).nBlockStart.offset(tid as isize))
                .offset(*maskIdx as isize);
            *maskEnd = (*maskStart)
                .wrapping_add(
                    *(*(*(*tb).idx).nBlockSizes.offset(tid as isize))
                        .offset(*maskIdx as isize),
                );
        }
    }
    if *maskIdx >= *(*(*tb).idx).nBlockCount.offset(tid as isize) || *maskStart >= end {
        *maskStart = -(1 as ::core::ffi::c_int) as uint32_t;
        *maskEnd = -(1 as ::core::ffi::c_int) as uint32_t;
    }
}
#[no_mangle]
pub unsafe extern "C" fn getByteMaskFromOffset(
    mut offset: ::core::ffi::c_int,
) -> uint8_t {
    match offset {
        0 => return 15 as ::core::ffi::c_int as uint8_t,
        1 => return 7 as ::core::ffi::c_int as uint8_t,
        2 => return 3 as ::core::ffi::c_int as uint8_t,
        _ => {}
    }
    return 1 as uint8_t;
}
#[no_mangle]
pub unsafe extern "C" fn twobitBasesWorker(
    mut tb: *mut TwoBit,
    mut tid: uint32_t,
    mut start: uint32_t,
    mut end: uint32_t,
    mut fraction: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_void {
    let mut out: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
    let mut tmp: [uint32_t; 4] = [
        0 as ::core::ffi::c_int as uint32_t,
        0 as ::core::ffi::c_int as uint32_t,
        0 as ::core::ffi::c_int as uint32_t,
        0 as ::core::ffi::c_int as uint32_t,
    ];
    let mut len: uint32_t = end
        .wrapping_sub(start)
        .wrapping_add(start.wrapping_rem(4 as uint32_t));
    let mut i: uint32_t = 0 as uint32_t;
    let mut j: uint32_t = 0 as uint32_t;
    let mut seqLen: uint32_t = end.wrapping_sub(start);
    let mut blockStart: uint32_t = 0;
    let mut blockEnd: uint32_t = 0;
    let mut maskIdx: uint32_t = -(1 as ::core::ffi::c_int) as uint32_t;
    let mut maskStart: uint32_t = 0;
    let mut maskEnd: uint32_t = 0;
    let mut foo: uint32_t = 0;
    let mut bytes: *mut uint8_t = 0 as *mut uint8_t;
    let mut mask: uint8_t = 0 as uint8_t;
    let mut offset: uint8_t = 0;
    if fraction != 0 {
        out = malloc(
            (4 as size_t)
                .wrapping_mul(::core::mem::size_of::<::core::ffi::c_double>() as size_t),
        );
    } else {
        out = malloc(
            (4 as size_t).wrapping_mul(::core::mem::size_of::<uint32_t>() as size_t),
        );
    }
    if out.is_null() {
        return NULL;
    }
    blockStart = start.wrapping_div(4 as uint32_t);
    offset = start.wrapping_rem(4 as uint32_t) as uint8_t;
    blockEnd = end
        .wrapping_div(4 as uint32_t)
        .wrapping_add(
            (if end.wrapping_rem(4 as uint32_t) != 0 {
                1 as ::core::ffi::c_int
            } else {
                0 as ::core::ffi::c_int
            }) as uint32_t,
        );
    bytes = malloc(blockEnd.wrapping_sub(blockStart) as size_t) as *mut uint8_t;
    if !bytes.is_null() {
        mask = getByteMaskFromOffset(offset as ::core::ffi::c_int);
        start = (4 as uint32_t).wrapping_mul(blockStart);
        offset = 0 as uint8_t;
        if !(twobitSeek(
            tb,
            (*(*(*tb).idx).offset.offset(tid as isize))
                .wrapping_add(blockStart as uint64_t),
        ) != 0 as ::core::ffi::c_int)
        {
            if !(twobitRead(
                bytes as *mut ::core::ffi::c_void,
                blockEnd.wrapping_sub(blockStart) as size_t,
                1 as size_t,
                tb,
            ) != 1 as size_t)
            {
                getMask(tb, tid, start, end, &mut maskIdx, &mut maskStart, &mut maskEnd);
                while i < len {
                    if maskIdx != -(1 as ::core::ffi::c_int) as uint32_t
                        && start.wrapping_add(i).wrapping_add(4 as uint32_t) >= maskStart
                    {
                        if start.wrapping_add(i) >= maskStart
                            || start
                                .wrapping_add(i)
                                .wrapping_add(4 as uint32_t)
                                .wrapping_sub(offset as uint32_t) > maskStart
                        {
                            if start.wrapping_add(i) >= maskStart
                                && start
                                    .wrapping_add(i)
                                    .wrapping_add(4 as uint32_t)
                                    .wrapping_sub(offset as uint32_t) < maskEnd
                            {
                                i = maskEnd.wrapping_sub(start);
                                getMask(
                                    tb,
                                    tid,
                                    i,
                                    end,
                                    &mut maskIdx,
                                    &mut maskStart,
                                    &mut maskEnd,
                                );
                                offset = start.wrapping_add(i).wrapping_rem(4 as uint32_t)
                                    as uint8_t;
                                j = i.wrapping_div(4 as uint32_t);
                                mask = getByteMaskFromOffset(offset as ::core::ffi::c_int);
                                i = (4 as uint32_t).wrapping_mul(j);
                                offset = 0 as uint8_t;
                                continue;
                            } else {
                                foo = (4 as uint32_t)
                                    .wrapping_mul(j)
                                    .wrapping_add((4 as uint32_t).wrapping_mul(blockStart));
                                if mask as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0
                                    && (foo.wrapping_add(3 as uint32_t) >= maskStart
                                        && foo.wrapping_add(3 as uint32_t) < maskEnd)
                                {
                                    mask = (mask as ::core::ffi::c_int
                                        - 1 as ::core::ffi::c_int) as uint8_t;
                                }
                                if mask as ::core::ffi::c_int & 2 as ::core::ffi::c_int != 0
                                    && (foo.wrapping_add(2 as uint32_t) >= maskStart
                                        && foo.wrapping_add(2 as uint32_t) < maskEnd)
                                {
                                    mask = (mask as ::core::ffi::c_int
                                        - 2 as ::core::ffi::c_int) as uint8_t;
                                }
                                if mask as ::core::ffi::c_int & 4 as ::core::ffi::c_int != 0
                                    && (foo.wrapping_add(1 as uint32_t) >= maskStart
                                        && foo.wrapping_add(1 as uint32_t) < maskEnd)
                                {
                                    mask = (mask as ::core::ffi::c_int
                                        - 4 as ::core::ffi::c_int) as uint8_t;
                                }
                                if mask as ::core::ffi::c_int & 8 as ::core::ffi::c_int != 0
                                    && (foo >= maskStart && foo < maskEnd)
                                {
                                    mask = (mask as ::core::ffi::c_int
                                        - 8 as ::core::ffi::c_int) as uint8_t;
                                }
                                if foo.wrapping_add(4 as uint32_t) > maskEnd {
                                    getMask(
                                        tb,
                                        tid,
                                        i,
                                        end,
                                        &mut maskIdx,
                                        &mut maskStart,
                                        &mut maskEnd,
                                    );
                                    continue;
                                }
                            }
                        }
                    }
                    if i.wrapping_add(4 as uint32_t) >= len {
                        if mask as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0
                            && i.wrapping_add(3 as uint32_t) >= len
                        {
                            mask = (mask as ::core::ffi::c_int - 1 as ::core::ffi::c_int)
                                as uint8_t;
                        }
                        if mask as ::core::ffi::c_int & 2 as ::core::ffi::c_int != 0
                            && i.wrapping_add(2 as uint32_t) >= len
                        {
                            mask = (mask as ::core::ffi::c_int - 2 as ::core::ffi::c_int)
                                as uint8_t;
                        }
                        if mask as ::core::ffi::c_int & 4 as ::core::ffi::c_int != 0
                            && i.wrapping_add(1 as uint32_t) >= len
                        {
                            mask = (mask as ::core::ffi::c_int - 4 as ::core::ffi::c_int)
                                as uint8_t;
                        }
                        if mask as ::core::ffi::c_int & 8 as ::core::ffi::c_int != 0
                            && i >= len
                        {
                            mask = (mask as ::core::ffi::c_int - 8 as ::core::ffi::c_int)
                                as uint8_t;
                        }
                    }
                    let fresh9 = j;
                    j = j.wrapping_add(1);
                    foo = *bytes.offset(fresh9 as isize) as uint32_t;
                    if mask as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
                        tmp[(foo & 3 as uint32_t) as usize] = tmp[(foo & 3 as uint32_t)
                                as usize]
                            .wrapping_add(1);
                    }
                    foo >>= 2 as ::core::ffi::c_int;
                    mask = (mask as ::core::ffi::c_int >> 1 as ::core::ffi::c_int)
                        as uint8_t;
                    if mask as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
                        tmp[(foo & 3 as uint32_t) as usize] = tmp[(foo & 3 as uint32_t)
                                as usize]
                            .wrapping_add(1);
                    }
                    foo >>= 2 as ::core::ffi::c_int;
                    mask = (mask as ::core::ffi::c_int >> 1 as ::core::ffi::c_int)
                        as uint8_t;
                    if mask as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
                        tmp[(foo & 3 as uint32_t) as usize] = tmp[(foo & 3 as uint32_t)
                                as usize]
                            .wrapping_add(1);
                    }
                    foo >>= 2 as ::core::ffi::c_int;
                    mask = (mask as ::core::ffi::c_int >> 1 as ::core::ffi::c_int)
                        as uint8_t;
                    if mask as ::core::ffi::c_int & 1 as ::core::ffi::c_int != 0 {
                        tmp[(foo & 3 as uint32_t) as usize] = tmp[(foo & 3 as uint32_t)
                                as usize]
                            .wrapping_add(1);
                    }
                    i = i.wrapping_add(4 as uint32_t);
                    mask = 15 as uint8_t;
                }
                free(bytes as *mut ::core::ffi::c_void);
                if fraction != 0 {
                    *(out as *mut ::core::ffi::c_double)
                        .offset(0 as ::core::ffi::c_int as isize) = tmp[2
                        as ::core::ffi::c_int as usize] as ::core::ffi::c_double
                        / seqLen as ::core::ffi::c_double;
                    *(out as *mut ::core::ffi::c_double)
                        .offset(1 as ::core::ffi::c_int as isize) = tmp[1
                        as ::core::ffi::c_int as usize] as ::core::ffi::c_double
                        / seqLen as ::core::ffi::c_double;
                    *(out as *mut ::core::ffi::c_double)
                        .offset(2 as ::core::ffi::c_int as isize) = tmp[0
                        as ::core::ffi::c_int as usize] as ::core::ffi::c_double
                        / seqLen as ::core::ffi::c_double;
                    *(out as *mut ::core::ffi::c_double)
                        .offset(3 as ::core::ffi::c_int as isize) = tmp[3
                        as ::core::ffi::c_int as usize] as ::core::ffi::c_double
                        / seqLen as ::core::ffi::c_double;
                } else {
                    *(out as *mut uint32_t).offset(0 as ::core::ffi::c_int as isize) = tmp[2
                        as ::core::ffi::c_int as usize];
                    *(out as *mut uint32_t).offset(1 as ::core::ffi::c_int as isize) = tmp[1
                        as ::core::ffi::c_int as usize];
                    *(out as *mut uint32_t).offset(2 as ::core::ffi::c_int as isize) = tmp[0
                        as ::core::ffi::c_int as usize];
                    *(out as *mut uint32_t).offset(3 as ::core::ffi::c_int as isize) = tmp[3
                        as ::core::ffi::c_int as usize];
                }
                return out;
            }
        }
    }
    if !out.is_null() {
        free(out);
    }
    if !bytes.is_null() {
        free(bytes as *mut ::core::ffi::c_void);
    }
    return NULL;
}
#[no_mangle]
pub unsafe extern "C" fn twobitBases(
    mut tb: *mut TwoBit,
    mut chrom: *mut ::core::ffi::c_char,
    mut start: uint32_t,
    mut end: uint32_t,
    mut fraction: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_void {
    let mut tid: uint32_t = 0 as uint32_t;
    let mut i: uint32_t = 0;
    i = 0 as uint32_t;
    while i < (*(*tb).hdr).nChroms {
        if strcmp(*(*(*tb).cl).chrom.offset(i as isize), chrom)
            == 0 as ::core::ffi::c_int
        {
            tid = i;
            break;
        } else {
            i = i.wrapping_add(1);
        }
    }
    if tid == 0 as uint32_t
        && strcmp(*(*(*tb).cl).chrom.offset(i as isize), chrom)
            != 0 as ::core::ffi::c_int
    {
        return NULL;
    }
    if start == end && end == 0 as uint32_t {
        end = *(*(*tb).idx).size.offset(tid as isize);
    }
    if end > *(*(*tb).idx).size.offset(tid as isize) {
        return NULL;
    }
    if start >= end {
        return NULL;
    }
    return twobitBasesWorker(tb, tid, start, end, fraction);
}
#[no_mangle]
pub unsafe extern "C" fn twobitChromLen(
    mut tb: *mut TwoBit,
    mut chrom: *mut ::core::ffi::c_char,
) -> uint32_t {
    let mut i: uint32_t = 0;
    i = 0 as uint32_t;
    while i < (*(*tb).hdr).nChroms {
        if strcmp(*(*(*tb).cl).chrom.offset(i as isize), chrom)
            == 0 as ::core::ffi::c_int
        {
            return *(*(*tb).idx).size.offset(i as isize);
        }
        i = i.wrapping_add(1);
    }
    return 0 as uint32_t;
}
#[no_mangle]
pub unsafe extern "C" fn twobitIndexRead(
    mut tb: *mut TwoBit,
    mut storeMasked: ::core::ffi::c_int,
) {
    let mut current_block: u64;
    let mut i: uint32_t = 0;
    let mut data: [uint32_t; 2] = [0; 2];
    let mut idx: *mut TwoBitMaskedIdx = calloc(
        1 as size_t,
        ::core::mem::size_of::<TwoBitMaskedIdx>() as size_t,
    ) as *mut TwoBitMaskedIdx;
    if idx.is_null() {
        return;
    }
    (*idx).size = malloc(
        ((*(*tb).hdr).nChroms as size_t)
            .wrapping_mul(::core::mem::size_of::<uint32_t>() as size_t),
    ) as *mut uint32_t;
    (*idx).nBlockCount = calloc(
        (*(*tb).hdr).nChroms as size_t,
        ::core::mem::size_of::<uint32_t>() as size_t,
    ) as *mut uint32_t;
    (*idx).nBlockStart = calloc(
        (*(*tb).hdr).nChroms as size_t,
        ::core::mem::size_of::<*mut uint32_t>() as size_t,
    ) as *mut *mut uint32_t;
    (*idx).nBlockSizes = calloc(
        (*(*tb).hdr).nChroms as size_t,
        ::core::mem::size_of::<*mut uint32_t>() as size_t,
    ) as *mut *mut uint32_t;
    if !(*idx).size.is_null() {
        if !(*idx).nBlockCount.is_null() {
            if !(*idx).nBlockStart.is_null() {
                if !(*idx).nBlockSizes.is_null() {
                    (*idx).maskBlockCount = calloc(
                        (*(*tb).hdr).nChroms as size_t,
                        ::core::mem::size_of::<uint32_t>() as size_t,
                    ) as *mut uint32_t;
                    if !(*idx).maskBlockCount.is_null() {
                        if storeMasked != 0 {
                            (*idx).maskBlockStart = calloc(
                                (*(*tb).hdr).nChroms as size_t,
                                ::core::mem::size_of::<*mut uint32_t>() as size_t,
                            ) as *mut *mut uint32_t;
                            (*idx).maskBlockSizes = calloc(
                                (*(*tb).hdr).nChroms as size_t,
                                ::core::mem::size_of::<*mut uint32_t>() as size_t,
                            ) as *mut *mut uint32_t;
                            if (*idx).maskBlockStart.is_null() {
                                current_block = 5983306788189195986;
                            } else if (*idx).maskBlockSizes.is_null() {
                                current_block = 5983306788189195986;
                            } else {
                                current_block = 10048703153582371463;
                            }
                        } else {
                            current_block = 10048703153582371463;
                        }
                        match current_block {
                            5983306788189195986 => {}
                            _ => {
                                (*idx).offset = malloc(
                                    ((*(*tb).hdr).nChroms as size_t)
                                        .wrapping_mul(::core::mem::size_of::<uint64_t>() as size_t),
                                ) as *mut uint64_t;
                                if !(*idx).offset.is_null() {
                                    i = 0 as uint32_t;
                                    loop {
                                        if !(i < (*(*tb).hdr).nChroms) {
                                            current_block = 5529461102203738653;
                                            break;
                                        }
                                        if twobitSeek(
                                            tb,
                                            *(*(*tb).cl).offset.offset(i as isize) as uint64_t,
                                        ) != 0 as ::core::ffi::c_int
                                        {
                                            current_block = 5983306788189195986;
                                            break;
                                        }
                                        if twobitRead(
                                            data.as_mut_ptr() as *mut ::core::ffi::c_void,
                                            ::core::mem::size_of::<uint32_t>() as size_t,
                                            2 as size_t,
                                            tb,
                                        ) != 2 as size_t
                                        {
                                            current_block = 5983306788189195986;
                                            break;
                                        }
                                        *(*idx).size.offset(i as isize) = data[0
                                            as ::core::ffi::c_int as usize];
                                        *(*idx).nBlockCount.offset(i as isize) = data[1
                                            as ::core::ffi::c_int as usize];
                                        let ref mut fresh0 = *(*idx).nBlockStart.offset(i as isize);
                                        *fresh0 = malloc(
                                            (*(*idx).nBlockCount.offset(i as isize) as size_t)
                                                .wrapping_mul(::core::mem::size_of::<uint32_t>() as size_t),
                                        ) as *mut uint32_t;
                                        let ref mut fresh1 = *(*idx).nBlockSizes.offset(i as isize);
                                        *fresh1 = malloc(
                                            (*(*idx).nBlockCount.offset(i as isize) as size_t)
                                                .wrapping_mul(::core::mem::size_of::<uint32_t>() as size_t),
                                        ) as *mut uint32_t;
                                        if (*(*idx).nBlockStart.offset(i as isize)).is_null() {
                                            current_block = 5983306788189195986;
                                            break;
                                        }
                                        if (*(*idx).nBlockSizes.offset(i as isize)).is_null() {
                                            current_block = 5983306788189195986;
                                            break;
                                        }
                                        if twobitRead(
                                            *(*idx).nBlockStart.offset(i as isize)
                                                as *mut ::core::ffi::c_void,
                                            ::core::mem::size_of::<uint32_t>() as size_t,
                                            *(*idx).nBlockCount.offset(i as isize) as size_t,
                                            tb,
                                        ) != *(*idx).nBlockCount.offset(i as isize) as size_t
                                        {
                                            current_block = 5983306788189195986;
                                            break;
                                        }
                                        if twobitRead(
                                            *(*idx).nBlockSizes.offset(i as isize)
                                                as *mut ::core::ffi::c_void,
                                            ::core::mem::size_of::<uint32_t>() as size_t,
                                            *(*idx).nBlockCount.offset(i as isize) as size_t,
                                            tb,
                                        ) != *(*idx).nBlockCount.offset(i as isize) as size_t
                                        {
                                            current_block = 5983306788189195986;
                                            break;
                                        }
                                        if twobitRead(
                                            (*idx).maskBlockCount.offset(i as isize)
                                                as *mut ::core::ffi::c_void,
                                            ::core::mem::size_of::<uint32_t>() as size_t,
                                            1 as size_t,
                                            tb,
                                        ) != 1 as size_t
                                        {
                                            current_block = 5983306788189195986;
                                            break;
                                        }
                                        if storeMasked != 0 {
                                            let ref mut fresh2 = *(*idx)
                                                .maskBlockStart
                                                .offset(i as isize);
                                            *fresh2 = malloc(
                                                (*(*idx).maskBlockCount.offset(i as isize) as size_t)
                                                    .wrapping_mul(::core::mem::size_of::<uint32_t>() as size_t),
                                            ) as *mut uint32_t;
                                            let ref mut fresh3 = *(*idx)
                                                .maskBlockSizes
                                                .offset(i as isize);
                                            *fresh3 = malloc(
                                                (*(*idx).maskBlockCount.offset(i as isize) as size_t)
                                                    .wrapping_mul(::core::mem::size_of::<uint32_t>() as size_t),
                                            ) as *mut uint32_t;
                                            if (*(*idx).maskBlockStart.offset(i as isize)).is_null() {
                                                current_block = 5983306788189195986;
                                                break;
                                            }
                                            if (*(*idx).maskBlockSizes.offset(i as isize)).is_null() {
                                                current_block = 5983306788189195986;
                                                break;
                                            }
                                            if twobitRead(
                                                *(*idx).maskBlockStart.offset(i as isize)
                                                    as *mut ::core::ffi::c_void,
                                                ::core::mem::size_of::<uint32_t>() as size_t,
                                                *(*idx).maskBlockCount.offset(i as isize) as size_t,
                                                tb,
                                            ) != *(*idx).maskBlockCount.offset(i as isize) as size_t
                                            {
                                                current_block = 5983306788189195986;
                                                break;
                                            }
                                            if twobitRead(
                                                *(*idx).maskBlockSizes.offset(i as isize)
                                                    as *mut ::core::ffi::c_void,
                                                ::core::mem::size_of::<uint32_t>() as size_t,
                                                *(*idx).maskBlockCount.offset(i as isize) as size_t,
                                                tb,
                                            ) != *(*idx).maskBlockCount.offset(i as isize) as size_t
                                            {
                                                current_block = 5983306788189195986;
                                                break;
                                            }
                                        } else if twobitSeek(
                                            tb,
                                            twobitTell(tb)
                                                .wrapping_add(
                                                    (8 as uint32_t)
                                                        .wrapping_mul(*(*idx).maskBlockCount.offset(i as isize))
                                                        as uint64_t,
                                                ),
                                        ) != 0 as ::core::ffi::c_int
                                        {
                                            current_block = 5983306788189195986;
                                            break;
                                        }
                                        if twobitRead(
                                            data.as_mut_ptr() as *mut ::core::ffi::c_void,
                                            ::core::mem::size_of::<uint32_t>() as size_t,
                                            1 as size_t,
                                            tb,
                                        ) != 1 as size_t
                                        {
                                            current_block = 5983306788189195986;
                                            break;
                                        }
                                        *(*idx).offset.offset(i as isize) = twobitTell(tb);
                                        i = i.wrapping_add(1);
                                    }
                                    match current_block {
                                        5983306788189195986 => {}
                                        _ => {
                                            (*tb).idx = idx;
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if !idx.is_null() {
        if !(*idx).size.is_null() {
            free((*idx).size as *mut ::core::ffi::c_void);
        }
        if !(*idx).nBlockCount.is_null() {
            free((*idx).nBlockCount as *mut ::core::ffi::c_void);
        }
        if !(*idx).nBlockStart.is_null() {
            i = 0 as uint32_t;
            while i < (*(*tb).hdr).nChroms {
                if !(*(*idx).nBlockStart.offset(i as isize)).is_null() {
                    free(
                        *(*idx).nBlockStart.offset(i as isize)
                            as *mut ::core::ffi::c_void,
                    );
                }
                i = i.wrapping_add(1);
            }
            free(*(*idx).nBlockStart.offset(i as isize) as *mut ::core::ffi::c_void);
        }
        if !(*idx).nBlockSizes.is_null() {
            i = 0 as uint32_t;
            while i < (*(*tb).hdr).nChroms {
                if !(*(*idx).nBlockSizes.offset(i as isize)).is_null() {
                    free(
                        *(*idx).nBlockSizes.offset(i as isize)
                            as *mut ::core::ffi::c_void,
                    );
                }
                i = i.wrapping_add(1);
            }
            free(*(*idx).nBlockSizes.offset(i as isize) as *mut ::core::ffi::c_void);
        }
        if !(*idx).maskBlockCount.is_null() {
            free((*idx).maskBlockCount as *mut ::core::ffi::c_void);
        }
        if !(*idx).maskBlockStart.is_null() {
            i = 0 as uint32_t;
            while i < (*(*tb).hdr).nChroms {
                if !(*(*idx).maskBlockStart.offset(i as isize)).is_null() {
                    free(
                        *(*idx).maskBlockStart.offset(i as isize)
                            as *mut ::core::ffi::c_void,
                    );
                }
                i = i.wrapping_add(1);
            }
            free(*(*idx).maskBlockStart.offset(i as isize) as *mut ::core::ffi::c_void);
        }
        if !(*idx).maskBlockSizes.is_null() {
            i = 0 as uint32_t;
            while i < (*(*tb).hdr).nChroms {
                if !(*(*idx).maskBlockSizes.offset(i as isize)).is_null() {
                    free(
                        *(*idx).maskBlockSizes.offset(i as isize)
                            as *mut ::core::ffi::c_void,
                    );
                }
                i = i.wrapping_add(1);
            }
            free(*(*idx).maskBlockSizes.offset(i as isize) as *mut ::core::ffi::c_void);
        }
        if !(*idx).offset.is_null() {
            free((*idx).offset as *mut ::core::ffi::c_void);
        }
        free(idx as *mut ::core::ffi::c_void);
    }
}
#[no_mangle]
pub unsafe extern "C" fn twobitIndexDestroy(mut tb: *mut TwoBit) {
    let mut i: uint32_t = 0;
    if !(*tb).idx.is_null() {
        if !(*(*tb).idx).size.is_null() {
            free((*(*tb).idx).size as *mut ::core::ffi::c_void);
        }
        if !(*(*tb).idx).nBlockCount.is_null() {
            free((*(*tb).idx).nBlockCount as *mut ::core::ffi::c_void);
        }
        if !(*(*tb).idx).nBlockStart.is_null() {
            i = 0 as uint32_t;
            while i < (*(*tb).hdr).nChroms {
                if !(*(*(*tb).idx).nBlockStart.offset(i as isize)).is_null() {
                    free(
                        *(*(*tb).idx).nBlockStart.offset(i as isize)
                            as *mut ::core::ffi::c_void,
                    );
                }
                i = i.wrapping_add(1);
            }
            free((*(*tb).idx).nBlockStart as *mut ::core::ffi::c_void);
        }
        if !(*(*tb).idx).nBlockSizes.is_null() {
            i = 0 as uint32_t;
            while i < (*(*tb).hdr).nChroms {
                if !(*(*(*tb).idx).nBlockSizes.offset(i as isize)).is_null() {
                    free(
                        *(*(*tb).idx).nBlockSizes.offset(i as isize)
                            as *mut ::core::ffi::c_void,
                    );
                }
                i = i.wrapping_add(1);
            }
            free((*(*tb).idx).nBlockSizes as *mut ::core::ffi::c_void);
        }
        if !(*(*tb).idx).maskBlockCount.is_null() {
            free((*(*tb).idx).maskBlockCount as *mut ::core::ffi::c_void);
        }
        if !(*(*tb).idx).maskBlockStart.is_null() {
            i = 0 as uint32_t;
            while i < (*(*tb).hdr).nChroms {
                if !(*(*(*tb).idx).maskBlockStart.offset(i as isize)).is_null() {
                    free(
                        *(*(*tb).idx).maskBlockStart.offset(i as isize)
                            as *mut ::core::ffi::c_void,
                    );
                }
                i = i.wrapping_add(1);
            }
            free((*(*tb).idx).maskBlockStart as *mut ::core::ffi::c_void);
        }
        if !(*(*tb).idx).maskBlockSizes.is_null() {
            i = 0 as uint32_t;
            while i < (*(*tb).hdr).nChroms {
                if !(*(*(*tb).idx).maskBlockSizes.offset(i as isize)).is_null() {
                    free(
                        *(*(*tb).idx).maskBlockSizes.offset(i as isize)
                            as *mut ::core::ffi::c_void,
                    );
                }
                i = i.wrapping_add(1);
            }
            free((*(*tb).idx).maskBlockSizes as *mut ::core::ffi::c_void);
        }
        if !(*(*tb).idx).offset.is_null() {
            free((*(*tb).idx).offset as *mut ::core::ffi::c_void);
        }
        free((*tb).idx as *mut ::core::ffi::c_void);
    }
}
#[no_mangle]
pub unsafe extern "C" fn twobitChromListRead(mut tb: *mut TwoBit) {
    let mut current_block: u64;
    let mut i: uint32_t = 0;
    let mut byte: uint8_t = 0;
    let mut str: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut cl: *mut TwoBitCL = calloc(
        1 as size_t,
        ::core::mem::size_of::<TwoBitCL>() as size_t,
    ) as *mut TwoBitCL;
    if !cl.is_null() {
        (*cl).chrom = calloc(
            (*(*tb).hdr).nChroms as size_t,
            ::core::mem::size_of::<*mut ::core::ffi::c_char>() as size_t,
        ) as *mut *mut ::core::ffi::c_char;
        (*cl).offset = malloc(
            (::core::mem::size_of::<uint32_t>() as size_t)
                .wrapping_mul((*(*tb).hdr).nChroms as size_t),
        ) as *mut uint32_t;
        if !(*cl).chrom.is_null() {
            if !(*cl).offset.is_null() {
                i = 0 as uint32_t;
                loop {
                    if !(i < (*(*tb).hdr).nChroms) {
                        current_block = 3512920355445576850;
                        break;
                    }
                    if twobitRead(
                        &mut byte as *mut uint8_t as *mut ::core::ffi::c_void,
                        1 as size_t,
                        1 as size_t,
                        tb,
                    ) != 1 as size_t
                    {
                        current_block = 17500608819442762874;
                        break;
                    }
                    str = calloc(
                        (1 as ::core::ffi::c_int + byte as ::core::ffi::c_int) as size_t,
                        ::core::mem::size_of::<::core::ffi::c_char>() as size_t,
                    ) as *mut ::core::ffi::c_char;
                    if str.is_null() {
                        current_block = 17500608819442762874;
                        break;
                    }
                    if twobitRead(
                        str as *mut ::core::ffi::c_void,
                        1 as size_t,
                        byte as size_t,
                        tb,
                    ) != byte as size_t
                    {
                        current_block = 17500608819442762874;
                        break;
                    }
                    let ref mut fresh4 = *(*cl).chrom.offset(i as isize);
                    *fresh4 = str;
                    str = 0 as *mut ::core::ffi::c_char;
                    if twobitRead(
                        (*cl).offset.offset(i as isize) as *mut ::core::ffi::c_void,
                        ::core::mem::size_of::<uint32_t>() as size_t,
                        1 as size_t,
                        tb,
                    ) != 1 as size_t
                    {
                        current_block = 17500608819442762874;
                        break;
                    }
                    i = i.wrapping_add(1);
                }
                match current_block {
                    17500608819442762874 => {}
                    _ => {
                        (*tb).cl = cl;
                        return;
                    }
                }
            }
        }
    }
    if !str.is_null() {
        free(str as *mut ::core::ffi::c_void);
    }
    if !cl.is_null() {
        if !(*cl).offset.is_null() {
            free((*cl).offset as *mut ::core::ffi::c_void);
        }
        if !(*cl).chrom.is_null() {
            i = 0 as uint32_t;
            while i < (*(*tb).hdr).nChroms {
                if !(*(*cl).chrom.offset(i as isize)).is_null() {
                    free(*(*cl).chrom.offset(i as isize) as *mut ::core::ffi::c_void);
                }
                i = i.wrapping_add(1);
            }
            free((*cl).chrom as *mut ::core::ffi::c_void);
        }
        free(cl as *mut ::core::ffi::c_void);
    }
}
#[no_mangle]
pub unsafe extern "C" fn twobitChromListDestroy(mut tb: *mut TwoBit) {
    let mut i: uint32_t = 0;
    if !(*tb).cl.is_null() {
        if !(*(*tb).cl).offset.is_null() {
            free((*(*tb).cl).offset as *mut ::core::ffi::c_void);
        }
        if !(*(*tb).cl).chrom.is_null() {
            i = 0 as uint32_t;
            while i < (*(*tb).hdr).nChroms {
                if !(*(*(*tb).cl).chrom.offset(i as isize)).is_null() {
                    free(
                        *(*(*tb).cl).chrom.offset(i as isize) as *mut ::core::ffi::c_void,
                    );
                }
                i = i.wrapping_add(1);
            }
            free((*(*tb).cl).chrom as *mut ::core::ffi::c_void);
        }
        free((*tb).cl as *mut ::core::ffi::c_void);
    }
}
#[no_mangle]
pub unsafe extern "C" fn twobitHdrRead(mut tb: *mut TwoBit) {
    let mut data: [uint32_t; 4] = [0; 4];
    let mut hdr: *mut TwoBitHeader = calloc(
        1 as size_t,
        ::core::mem::size_of::<TwoBitHeader>() as size_t,
    ) as *mut TwoBitHeader;
    if hdr.is_null() {
        return;
    }
    if !(twobitRead(
        data.as_mut_ptr() as *mut ::core::ffi::c_void,
        4 as size_t,
        4 as size_t,
        tb,
    ) != 4 as size_t)
    {
        (*hdr).magic = data[0 as ::core::ffi::c_int as usize];
        if (*hdr).magic != 0x1a412743 as uint32_t {
            fprintf(
                __stderrp,
                b"[twobitHdrRead] Received an invalid file magic number (0x%x)!\n\0"
                    as *const u8 as *const ::core::ffi::c_char,
                (*hdr).magic,
            );
        } else {
            (*hdr).version = data[1 as ::core::ffi::c_int as usize];
            if (*hdr).version != 0 as uint32_t {
                fprintf(
                    __stderrp,
                    b"[twobitHdrRead] The file version is %u while only version 0 is defined!\n\0"
                        as *const u8 as *const ::core::ffi::c_char,
                    (*hdr).version,
                );
            } else {
                (*hdr).nChroms = data[2 as ::core::ffi::c_int as usize];
                if (*hdr).nChroms == 0 as uint32_t {
                    fprintf(
                        __stderrp,
                        b"[twobitHdrRead] There are apparently no chromosomes/contigs in this file!\n\0"
                            as *const u8 as *const ::core::ffi::c_char,
                    );
                } else {
                    (*tb).hdr = hdr;
                    return;
                }
            }
        }
    }
    if !hdr.is_null() {
        free(hdr as *mut ::core::ffi::c_void);
    }
}
#[no_mangle]
pub unsafe extern "C" fn twobitHdrDestroy(mut tb: *mut TwoBit) {
    if !(*tb).hdr.is_null() {
        free((*tb).hdr as *mut ::core::ffi::c_void);
    }
}
#[no_mangle]
pub unsafe extern "C" fn twobitClose(mut tb: *mut TwoBit) {
    if !tb.is_null() {
        if !(*tb).fp.is_null() {
            fclose((*tb).fp);
        }
        if !(*tb).data.is_null() {
            munmap((*tb).data, (*tb).sz as size_t);
        }
        twobitChromListDestroy(tb);
        twobitIndexDestroy(tb);
        twobitHdrDestroy(tb);
        free(tb as *mut ::core::ffi::c_void);
    }
}
#[no_mangle]
pub unsafe extern "C" fn twobitOpen(
    mut fname: *mut ::core::ffi::c_char,
    mut storeMasked: ::core::ffi::c_int,
) -> *mut TwoBit {
    let mut fd: ::core::ffi::c_int = 0;
    let mut fs: stat = stat {
        st_dev: 0,
        st_mode: 0,
        st_nlink: 0,
        st_ino: 0,
        st_uid: 0,
        st_gid: 0,
        st_rdev: 0,
        st_atimespec: timespec { tv_sec: 0, tv_nsec: 0 },
        st_mtimespec: timespec { tv_sec: 0, tv_nsec: 0 },
        st_ctimespec: timespec { tv_sec: 0, tv_nsec: 0 },
        st_birthtimespec: timespec { tv_sec: 0, tv_nsec: 0 },
        st_size: 0,
        st_blocks: 0,
        st_blksize: 0,
        st_flags: 0,
        st_gen: 0,
        st_lspare: 0,
        st_qspare: [0; 2],
    };
    let mut tb: *mut TwoBit = calloc(
        1 as size_t,
        ::core::mem::size_of::<TwoBit>() as size_t,
    ) as *mut TwoBit;
    if tb.is_null() {
        return 0 as *mut TwoBit;
    }
    (*tb).fp = fopen(fname, b"rb\0" as *const u8 as *const ::core::ffi::c_char)
        as *mut FILE;
    if !(*tb).fp.is_null() {
        fd = fileno((*tb).fp);
        if fstat(fd, &mut fs) == 0 as ::core::ffi::c_int {
            (*tb).sz = fs.st_size as uint64_t;
            (*tb).data = mmap(
                NULL,
                fs.st_size as size_t,
                PROT_READ,
                MAP_SHARED,
                fd,
                0 as off_t,
            );
            if !(*tb).data.is_null() {
                if madvise((*tb).data, fs.st_size as size_t, MADV_RANDOM)
                    != 0 as ::core::ffi::c_int
                {
                    munmap((*tb).data, fs.st_size as size_t);
                    (*tb).data = NULL;
                }
            }
        }
        twobitHdrRead(tb);
        if !(*tb).hdr.is_null() {
            twobitChromListRead(tb);
            if !(*tb).cl.is_null() {
                twobitIndexRead(tb, storeMasked);
                if !(*tb).idx.is_null() {
                    return tb;
                }
            }
        }
    }
    twobitClose(tb);
    return 0 as *mut TwoBit;
}
