#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn q_abs_diff(v1: uint16_t, v2: uint16_t) -> uint16_t;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type int8_t = i8;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
pub const NUM_STATES: ::core::ffi::c_int = (1 as ::core::ffi::c_int)
    << 5 as ::core::ffi::c_int - 1 as ::core::ffi::c_int;
#[no_mangle]
pub static mut lsf_sync_symbols: [int8_t; 8] = [
    3 as ::core::ffi::c_int as int8_t,
    3 as ::core::ffi::c_int as int8_t,
    3 as ::core::ffi::c_int as int8_t,
    3 as ::core::ffi::c_int as int8_t,
    -(3 as ::core::ffi::c_int) as int8_t,
    -(3 as ::core::ffi::c_int) as int8_t,
    3 as ::core::ffi::c_int as int8_t,
    -(3 as ::core::ffi::c_int) as int8_t,
];
#[no_mangle]
pub static mut str_sync_symbols: [int8_t; 8] = [
    -(3 as ::core::ffi::c_int) as int8_t,
    -(3 as ::core::ffi::c_int) as int8_t,
    -(3 as ::core::ffi::c_int) as int8_t,
    -(3 as ::core::ffi::c_int) as int8_t,
    3 as ::core::ffi::c_int as int8_t,
    3 as ::core::ffi::c_int as int8_t,
    -(3 as ::core::ffi::c_int) as int8_t,
    3 as ::core::ffi::c_int as int8_t,
];
#[no_mangle]
pub static mut pkt_sync_symbols: [int8_t; 8] = [
    3 as ::core::ffi::c_int as int8_t,
    -(3 as ::core::ffi::c_int) as int8_t,
    3 as ::core::ffi::c_int as int8_t,
    3 as ::core::ffi::c_int as int8_t,
    -(3 as ::core::ffi::c_int) as int8_t,
    -(3 as ::core::ffi::c_int) as int8_t,
    -(3 as ::core::ffi::c_int) as int8_t,
    -(3 as ::core::ffi::c_int) as int8_t,
];
#[no_mangle]
pub static mut symbol_levels: [::core::ffi::c_float; 4] = [
    -3.0f64 as ::core::ffi::c_float,
    -1.0f64 as ::core::ffi::c_float,
    1.0f64 as ::core::ffi::c_float,
    3.0f64 as ::core::ffi::c_float,
];
static mut prevMetrics: [uint32_t; 16] = [0; 16];
static mut currMetrics: [uint32_t; 16] = [0; 16];
static mut prevMetricsData: [uint32_t; 16] = [0; 16];
static mut currMetricsData: [uint32_t; 16] = [0; 16];
static mut viterbi_history: [uint16_t; 244] = [0; 244];
#[no_mangle]
pub unsafe extern "C" fn viterbi_decode(
    mut out: *mut uint8_t,
    mut in_0: *const uint16_t,
    len: uint16_t,
) -> uint32_t {
    if len as ::core::ffi::c_int > 244 as ::core::ffi::c_int * 2 as ::core::ffi::c_int {
        fprintf(
            __stderrp,
            b"Input size exceeds max history\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    viterbi_reset();
    let mut pos: size_t = 0 as size_t;
    let mut i: size_t = 0 as size_t;
    while i < len as size_t {
        let mut s0: uint16_t = *in_0.offset(i as isize);
        let mut s1: uint16_t = *in_0.offset(i.wrapping_add(1 as size_t) as isize);
        viterbi_decode_bit(s0, s1, pos);
        pos = pos.wrapping_add(1);
        i = i.wrapping_add(2 as size_t);
    }
    return viterbi_chainback(
        out,
        pos,
        (len as ::core::ffi::c_int / 2 as ::core::ffi::c_int) as uint16_t,
    );
}
#[no_mangle]
pub unsafe extern "C" fn viterbi_decode_punctured(
    mut out: *mut uint8_t,
    mut in_0: *const uint16_t,
    mut punct: *const uint8_t,
    in_len: uint16_t,
    p_len: uint16_t,
) -> uint32_t {
    if in_len as ::core::ffi::c_int > 244 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
    {
        fprintf(
            __stderrp,
            b"Input size exceeds max history\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    }
    let mut umsg: [uint16_t; 488] = [0; 488];
    let mut p: uint8_t = 0 as uint8_t;
    let mut u: uint16_t = 0 as uint16_t;
    let mut i: uint16_t = 0 as uint16_t;
    while (i as ::core::ffi::c_int) < in_len as ::core::ffi::c_int {
        if *punct.offset(p as isize) != 0 {
            umsg[u as usize] = *in_0.offset(i as isize);
            i = i.wrapping_add(1);
        } else {
            umsg[u as usize] = 0x7fff as uint16_t;
        }
        u = u.wrapping_add(1);
        p = p.wrapping_add(1);
        p = (p as ::core::ffi::c_int % p_len as ::core::ffi::c_int) as uint8_t;
    }
    return viterbi_decode(out, umsg.as_mut_ptr(), u)
        .wrapping_sub(
            ((u as ::core::ffi::c_int - in_len as ::core::ffi::c_int)
                * 0x7fff as ::core::ffi::c_int) as uint32_t,
        );
}
#[no_mangle]
pub unsafe extern "C" fn viterbi_decode_bit(
    mut s0: uint16_t,
    mut s1: uint16_t,
    pos: size_t,
) {
    static mut COST_TABLE_0: [uint16_t; 8] = [
        0 as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
        0xffff as ::core::ffi::c_int as uint16_t,
        0xffff as ::core::ffi::c_int as uint16_t,
        0xffff as ::core::ffi::c_int as uint16_t,
        0xffff as ::core::ffi::c_int as uint16_t,
    ];
    static mut COST_TABLE_1: [uint16_t; 8] = [
        0 as ::core::ffi::c_int as uint16_t,
        0xffff as ::core::ffi::c_int as uint16_t,
        0xffff as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
        0xffff as ::core::ffi::c_int as uint16_t,
        0xffff as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
    ];
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < NUM_STATES / 2 as ::core::ffi::c_int {
        let mut metric: uint32_t = (q_abs_diff(COST_TABLE_0[i as usize], s0)
            as ::core::ffi::c_int
            + q_abs_diff(COST_TABLE_1[i as usize], s1) as ::core::ffi::c_int)
            as uint32_t;
        let mut m0: uint32_t = prevMetrics[i as usize].wrapping_add(metric);
        let mut m1: uint32_t = prevMetrics[(i as ::core::ffi::c_int
                + NUM_STATES / 2 as ::core::ffi::c_int) as usize]
            .wrapping_add((0x1fffe as uint32_t).wrapping_sub(metric));
        let mut m2: uint32_t = prevMetrics[i as usize]
            .wrapping_add((0x1fffe as uint32_t).wrapping_sub(metric));
        let mut m3: uint32_t = prevMetrics[(i as ::core::ffi::c_int
                + NUM_STATES / 2 as ::core::ffi::c_int) as usize]
            .wrapping_add(metric);
        let mut i0: uint8_t = (2 as ::core::ffi::c_int * i as ::core::ffi::c_int)
            as uint8_t;
        let mut i1: uint8_t = (i0 as ::core::ffi::c_int + 1 as ::core::ffi::c_int)
            as uint8_t;
        if m0 >= m1 {
            viterbi_history[pos as usize] = (viterbi_history[pos as usize]
                as ::core::ffi::c_int
                | (1 as ::core::ffi::c_int) << i0 as ::core::ffi::c_int) as uint16_t;
            currMetrics[i0 as usize] = m1;
        } else {
            viterbi_history[pos as usize] = (viterbi_history[pos as usize]
                as ::core::ffi::c_int
                & !((1 as ::core::ffi::c_int) << i0 as ::core::ffi::c_int)) as uint16_t;
            currMetrics[i0 as usize] = m0;
        }
        if m2 >= m3 {
            viterbi_history[pos as usize] = (viterbi_history[pos as usize]
                as ::core::ffi::c_int
                | (1 as ::core::ffi::c_int) << i1 as ::core::ffi::c_int) as uint16_t;
            currMetrics[i1 as usize] = m3;
        } else {
            viterbi_history[pos as usize] = (viterbi_history[pos as usize]
                as ::core::ffi::c_int
                & !((1 as ::core::ffi::c_int) << i1 as ::core::ffi::c_int)) as uint16_t;
            currMetrics[i1 as usize] = m2;
        }
        i = i.wrapping_add(1);
    }
    let mut tmp: [uint32_t; 16] = [0; 16];
    let mut i_0: uint8_t = 0 as uint8_t;
    while (i_0 as ::core::ffi::c_int) < NUM_STATES {
        tmp[i_0 as usize] = currMetrics[i_0 as usize];
        i_0 = i_0.wrapping_add(1);
    }
    let mut i_1: uint8_t = 0 as uint8_t;
    while (i_1 as ::core::ffi::c_int) < NUM_STATES {
        currMetrics[i_1 as usize] = prevMetrics[i_1 as usize];
        prevMetrics[i_1 as usize] = tmp[i_1 as usize];
        i_1 = i_1.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn viterbi_chainback(
    mut out: *mut uint8_t,
    mut pos: size_t,
    mut len: uint16_t,
) -> uint32_t {
    let mut state: uint8_t = 0 as uint8_t;
    let mut bitPos: size_t = (len as ::core::ffi::c_int + 4 as ::core::ffi::c_int)
        as size_t;
    memset(
        out as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ((len as ::core::ffi::c_int - 1 as ::core::ffi::c_int) / 8 as ::core::ffi::c_int
            + 1 as ::core::ffi::c_int) as size_t,
    );
    while pos > 0 as size_t {
        bitPos = bitPos.wrapping_sub(1);
        pos = pos.wrapping_sub(1);
        let mut bit: uint16_t = (viterbi_history[pos as usize] as ::core::ffi::c_int
            & (1 as ::core::ffi::c_int)
                << (state as ::core::ffi::c_int >> 4 as ::core::ffi::c_int)) as uint16_t;
        state = (state as ::core::ffi::c_int >> 1 as ::core::ffi::c_int) as uint8_t;
        if bit != 0 {
            state = (state as ::core::ffi::c_int | 0x80 as ::core::ffi::c_int)
                as uint8_t;
            let ref mut fresh0 = *out.offset(bitPos.wrapping_div(8 as size_t) as isize);
            *fresh0 = (*fresh0 as ::core::ffi::c_int
                | (1 as ::core::ffi::c_int)
                    << (7 as size_t).wrapping_sub(bitPos.wrapping_rem(8 as size_t)))
                as uint8_t;
        }
    }
    let mut cost: uint32_t = prevMetrics[0 as ::core::ffi::c_int as usize];
    let mut i: size_t = 0 as size_t;
    while i < NUM_STATES as size_t {
        let mut m: uint32_t = prevMetrics[i as usize];
        if m < cost {
            cost = m;
        }
        i = i.wrapping_add(1);
    }
    return cost;
}
#[no_mangle]
pub unsafe extern "C" fn viterbi_reset() {
    memset(
        viterbi_history.as_mut_ptr() as *mut uint8_t as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        (2 as ::core::ffi::c_int * 244 as ::core::ffi::c_int) as size_t,
    );
    memset(
        currMetrics.as_mut_ptr() as *mut uint8_t as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        (4 as ::core::ffi::c_int * NUM_STATES) as size_t,
    );
    memset(
        prevMetrics.as_mut_ptr() as *mut uint8_t as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        (4 as ::core::ffi::c_int * NUM_STATES) as size_t,
    );
    memset(
        currMetricsData.as_mut_ptr() as *mut uint8_t as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        (4 as ::core::ffi::c_int * NUM_STATES) as size_t,
    );
    memset(
        prevMetricsData.as_mut_ptr() as *mut uint8_t as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        (4 as ::core::ffi::c_int * NUM_STATES) as size_t,
    );
}
