#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type int8_t = i8;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct lsf_t {
    pub dst: [uint8_t; 6],
    pub src: [uint8_t; 6],
    pub type_0: [uint8_t; 2],
    pub meta: [uint8_t; 14],
    pub crc: [uint8_t; 2],
}
#[no_mangle]
pub static mut symbol_map: [int8_t; 4] = [
    1 as ::core::ffi::c_int as int8_t,
    3 as ::core::ffi::c_int as int8_t,
    -(1 as ::core::ffi::c_int) as int8_t,
    -(3 as ::core::ffi::c_int) as int8_t,
];
#[no_mangle]
pub static mut symbol_list: [int8_t; 4] = [
    -(3 as ::core::ffi::c_int) as int8_t,
    -(1 as ::core::ffi::c_int) as int8_t,
    1 as ::core::ffi::c_int as int8_t,
    3 as ::core::ffi::c_int as int8_t,
];
#[no_mangle]
pub static mut eot_symbols: [::core::ffi::c_float; 8] = [
    3 as ::core::ffi::c_int as ::core::ffi::c_float,
    3 as ::core::ffi::c_int as ::core::ffi::c_float,
    3 as ::core::ffi::c_int as ::core::ffi::c_float,
    3 as ::core::ffi::c_int as ::core::ffi::c_float,
    3 as ::core::ffi::c_int as ::core::ffi::c_float,
    3 as ::core::ffi::c_int as ::core::ffi::c_float,
    -(3 as ::core::ffi::c_int) as ::core::ffi::c_float,
    3 as ::core::ffi::c_int as ::core::ffi::c_float,
];
#[no_mangle]
pub static mut puncture_pattern_1: [uint8_t; 61] = [
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
];
#[no_mangle]
pub static mut puncture_pattern_2: [uint8_t; 12] = [
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
];
#[no_mangle]
pub static mut puncture_pattern_3: [uint8_t; 8] = [
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    1 as ::core::ffi::c_int as uint8_t,
    0 as ::core::ffi::c_int as uint8_t,
];
#[no_mangle]
pub unsafe extern "C" fn conv_encode_stream_frame(
    mut out: *mut uint8_t,
    mut in_0: *const uint8_t,
    fn_0: uint16_t,
) {
    let mut pp_len: uint8_t = ::core::mem::size_of::<[uint8_t; 12]>() as uint8_t;
    let mut p: uint8_t = 0 as uint8_t;
    let mut pb: uint16_t = 0 as uint16_t;
    let mut ud: [uint8_t; 152] = [0; 152];
    memset(
        ud.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        (144 as ::core::ffi::c_int + 4 as ::core::ffi::c_int + 4 as ::core::ffi::c_int)
            as size_t,
    );
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < 16 as ::core::ffi::c_int {
        ud[(4 as ::core::ffi::c_int + i as ::core::ffi::c_int) as usize] = (fn_0
            as ::core::ffi::c_int >> 15 as ::core::ffi::c_int - i as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        i = i.wrapping_add(1);
    }
    let mut i_0: uint8_t = 0 as uint8_t;
    while (i_0 as ::core::ffi::c_int) < 16 as ::core::ffi::c_int {
        let mut j: uint8_t = 0 as uint8_t;
        while (j as ::core::ffi::c_int) < 8 as ::core::ffi::c_int {
            ud[(4 as ::core::ffi::c_int + 16 as ::core::ffi::c_int
                + i_0 as ::core::ffi::c_int * 8 as ::core::ffi::c_int
                + j as ::core::ffi::c_int) as usize] = (*in_0.offset(i_0 as isize)
                as ::core::ffi::c_int
                >> 7 as ::core::ffi::c_int - j as ::core::ffi::c_int
                & 1 as ::core::ffi::c_int) as uint8_t;
            j = j.wrapping_add(1);
        }
        i_0 = i_0.wrapping_add(1);
    }
    let mut i_1: uint8_t = 0 as uint8_t;
    while (i_1 as ::core::ffi::c_int)
        < 144 as ::core::ffi::c_int + 4 as ::core::ffi::c_int
    {
        let mut G1: uint8_t = ((ud[(i_1 as ::core::ffi::c_int + 4 as ::core::ffi::c_int)
            as usize] as ::core::ffi::c_int
            + ud[(i_1 as ::core::ffi::c_int + 1 as ::core::ffi::c_int) as usize]
                as ::core::ffi::c_int
            + ud[(i_1 as ::core::ffi::c_int + 0 as ::core::ffi::c_int) as usize]
                as ::core::ffi::c_int) % 2 as ::core::ffi::c_int) as uint8_t;
        let mut G2: uint8_t = ((ud[(i_1 as ::core::ffi::c_int + 4 as ::core::ffi::c_int)
            as usize] as ::core::ffi::c_int
            + ud[(i_1 as ::core::ffi::c_int + 3 as ::core::ffi::c_int) as usize]
                as ::core::ffi::c_int
            + ud[(i_1 as ::core::ffi::c_int + 2 as ::core::ffi::c_int) as usize]
                as ::core::ffi::c_int
            + ud[(i_1 as ::core::ffi::c_int + 0 as ::core::ffi::c_int) as usize]
                as ::core::ffi::c_int) % 2 as ::core::ffi::c_int) as uint8_t;
        if puncture_pattern_2[p as usize] != 0 {
            *out.offset(pb as isize) = G1;
            pb = pb.wrapping_add(1);
        }
        p = p.wrapping_add(1);
        p = (p as ::core::ffi::c_int % pp_len as ::core::ffi::c_int) as uint8_t;
        if puncture_pattern_2[p as usize] != 0 {
            *out.offset(pb as isize) = G2;
            pb = pb.wrapping_add(1);
        }
        p = p.wrapping_add(1);
        p = (p as ::core::ffi::c_int % pp_len as ::core::ffi::c_int) as uint8_t;
        i_1 = i_1.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn conv_encode_packet_frame(
    mut out: *mut uint8_t,
    mut in_0: *const uint8_t,
) {
    let mut pp_len: uint8_t = ::core::mem::size_of::<[uint8_t; 8]>() as uint8_t;
    let mut p: uint8_t = 0 as uint8_t;
    let mut pb: uint16_t = 0 as uint16_t;
    let mut ud: [uint8_t; 214] = [0; 214];
    memset(
        ud.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        (206 as ::core::ffi::c_int + 4 as ::core::ffi::c_int + 4 as ::core::ffi::c_int)
            as size_t,
    );
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < 26 as ::core::ffi::c_int {
        let mut j: uint8_t = 0 as uint8_t;
        while (j as ::core::ffi::c_int) < 8 as ::core::ffi::c_int {
            if i as ::core::ffi::c_int <= 24 as ::core::ffi::c_int
                || j as ::core::ffi::c_int <= 5 as ::core::ffi::c_int
            {
                ud[(4 as ::core::ffi::c_int
                    + i as ::core::ffi::c_int * 8 as ::core::ffi::c_int
                    + j as ::core::ffi::c_int) as usize] = (*in_0.offset(i as isize)
                    as ::core::ffi::c_int
                    >> 7 as ::core::ffi::c_int - j as ::core::ffi::c_int
                    & 1 as ::core::ffi::c_int) as uint8_t;
            }
            j = j.wrapping_add(1);
        }
        i = i.wrapping_add(1);
    }
    let mut i_0: uint8_t = 0 as uint8_t;
    while (i_0 as ::core::ffi::c_int)
        < 206 as ::core::ffi::c_int + 4 as ::core::ffi::c_int
    {
        let mut G1: uint8_t = ((ud[(i_0 as ::core::ffi::c_int + 4 as ::core::ffi::c_int)
            as usize] as ::core::ffi::c_int
            + ud[(i_0 as ::core::ffi::c_int + 1 as ::core::ffi::c_int) as usize]
                as ::core::ffi::c_int
            + ud[(i_0 as ::core::ffi::c_int + 0 as ::core::ffi::c_int) as usize]
                as ::core::ffi::c_int) % 2 as ::core::ffi::c_int) as uint8_t;
        let mut G2: uint8_t = ((ud[(i_0 as ::core::ffi::c_int + 4 as ::core::ffi::c_int)
            as usize] as ::core::ffi::c_int
            + ud[(i_0 as ::core::ffi::c_int + 3 as ::core::ffi::c_int) as usize]
                as ::core::ffi::c_int
            + ud[(i_0 as ::core::ffi::c_int + 2 as ::core::ffi::c_int) as usize]
                as ::core::ffi::c_int
            + ud[(i_0 as ::core::ffi::c_int + 0 as ::core::ffi::c_int) as usize]
                as ::core::ffi::c_int) % 2 as ::core::ffi::c_int) as uint8_t;
        if puncture_pattern_3[p as usize] != 0 {
            *out.offset(pb as isize) = G1;
            pb = pb.wrapping_add(1);
        }
        p = p.wrapping_add(1);
        p = (p as ::core::ffi::c_int % pp_len as ::core::ffi::c_int) as uint8_t;
        if puncture_pattern_3[p as usize] != 0 {
            *out.offset(pb as isize) = G2;
            pb = pb.wrapping_add(1);
        }
        p = p.wrapping_add(1);
        p = (p as ::core::ffi::c_int % pp_len as ::core::ffi::c_int) as uint8_t;
        i_0 = i_0.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn conv_encode_LSF(mut out: *mut uint8_t, mut in_0: *const lsf_t) {
    let mut pp_len: uint8_t = ::core::mem::size_of::<[uint8_t; 61]>() as uint8_t;
    let mut p: uint8_t = 0 as uint8_t;
    let mut pb: uint16_t = 0 as uint16_t;
    let mut ud: [uint8_t; 248] = [0; 248];
    memset(
        ud.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        (240 as ::core::ffi::c_int + 4 as ::core::ffi::c_int + 4 as ::core::ffi::c_int)
            as size_t,
    );
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < 8 as ::core::ffi::c_int {
        ud[(4 as ::core::ffi::c_int + i as ::core::ffi::c_int) as usize] = ((*in_0)
            .dst[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i as ::core::ffi::c_int + 8 as ::core::ffi::c_int)
            as usize] = ((*in_0).dst[1 as ::core::ffi::c_int as usize]
            as ::core::ffi::c_int >> 7 as ::core::ffi::c_int - i as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i as ::core::ffi::c_int + 16 as ::core::ffi::c_int)
            as usize] = ((*in_0).dst[2 as ::core::ffi::c_int as usize]
            as ::core::ffi::c_int >> 7 as ::core::ffi::c_int - i as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i as ::core::ffi::c_int + 24 as ::core::ffi::c_int)
            as usize] = ((*in_0).dst[3 as ::core::ffi::c_int as usize]
            as ::core::ffi::c_int >> 7 as ::core::ffi::c_int - i as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i as ::core::ffi::c_int + 32 as ::core::ffi::c_int)
            as usize] = ((*in_0).dst[4 as ::core::ffi::c_int as usize]
            as ::core::ffi::c_int >> 7 as ::core::ffi::c_int - i as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i as ::core::ffi::c_int + 40 as ::core::ffi::c_int)
            as usize] = ((*in_0).dst[5 as ::core::ffi::c_int as usize]
            as ::core::ffi::c_int >> 7 as ::core::ffi::c_int - i as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        i = i.wrapping_add(1);
    }
    let mut i_0: uint8_t = 0 as uint8_t;
    while (i_0 as ::core::ffi::c_int) < 8 as ::core::ffi::c_int {
        ud[(4 as ::core::ffi::c_int + i_0 as ::core::ffi::c_int
            + 48 as ::core::ffi::c_int) as usize] = ((*in_0)
            .src[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_0 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_0 as ::core::ffi::c_int
            + 56 as ::core::ffi::c_int) as usize] = ((*in_0)
            .src[1 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_0 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_0 as ::core::ffi::c_int
            + 64 as ::core::ffi::c_int) as usize] = ((*in_0)
            .src[2 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_0 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_0 as ::core::ffi::c_int
            + 72 as ::core::ffi::c_int) as usize] = ((*in_0)
            .src[3 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_0 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_0 as ::core::ffi::c_int
            + 80 as ::core::ffi::c_int) as usize] = ((*in_0)
            .src[4 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_0 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_0 as ::core::ffi::c_int
            + 88 as ::core::ffi::c_int) as usize] = ((*in_0)
            .src[5 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_0 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        i_0 = i_0.wrapping_add(1);
    }
    let mut i_1: uint8_t = 0 as uint8_t;
    while (i_1 as ::core::ffi::c_int) < 8 as ::core::ffi::c_int {
        ud[(4 as ::core::ffi::c_int + i_1 as ::core::ffi::c_int
            + 96 as ::core::ffi::c_int) as usize] = ((*in_0)
            .type_0[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_1 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_1 as ::core::ffi::c_int
            + 104 as ::core::ffi::c_int) as usize] = ((*in_0)
            .type_0[1 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_1 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        i_1 = i_1.wrapping_add(1);
    }
    let mut i_2: uint8_t = 0 as uint8_t;
    while (i_2 as ::core::ffi::c_int) < 8 as ::core::ffi::c_int {
        ud[(4 as ::core::ffi::c_int + i_2 as ::core::ffi::c_int
            + 112 as ::core::ffi::c_int) as usize] = ((*in_0)
            .meta[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_2 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_2 as ::core::ffi::c_int
            + 120 as ::core::ffi::c_int) as usize] = ((*in_0)
            .meta[1 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_2 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_2 as ::core::ffi::c_int
            + 128 as ::core::ffi::c_int) as usize] = ((*in_0)
            .meta[2 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_2 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_2 as ::core::ffi::c_int
            + 136 as ::core::ffi::c_int) as usize] = ((*in_0)
            .meta[3 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_2 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_2 as ::core::ffi::c_int
            + 144 as ::core::ffi::c_int) as usize] = ((*in_0)
            .meta[4 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_2 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_2 as ::core::ffi::c_int
            + 152 as ::core::ffi::c_int) as usize] = ((*in_0)
            .meta[5 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_2 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_2 as ::core::ffi::c_int
            + 160 as ::core::ffi::c_int) as usize] = ((*in_0)
            .meta[6 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_2 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_2 as ::core::ffi::c_int
            + 168 as ::core::ffi::c_int) as usize] = ((*in_0)
            .meta[7 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_2 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_2 as ::core::ffi::c_int
            + 176 as ::core::ffi::c_int) as usize] = ((*in_0)
            .meta[8 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_2 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_2 as ::core::ffi::c_int
            + 184 as ::core::ffi::c_int) as usize] = ((*in_0)
            .meta[9 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_2 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_2 as ::core::ffi::c_int
            + 192 as ::core::ffi::c_int) as usize] = ((*in_0)
            .meta[10 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_2 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_2 as ::core::ffi::c_int
            + 200 as ::core::ffi::c_int) as usize] = ((*in_0)
            .meta[11 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_2 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_2 as ::core::ffi::c_int
            + 208 as ::core::ffi::c_int) as usize] = ((*in_0)
            .meta[12 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_2 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_2 as ::core::ffi::c_int
            + 216 as ::core::ffi::c_int) as usize] = ((*in_0)
            .meta[13 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_2 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        i_2 = i_2.wrapping_add(1);
    }
    let mut i_3: uint8_t = 0 as uint8_t;
    while (i_3 as ::core::ffi::c_int) < 8 as ::core::ffi::c_int {
        ud[(4 as ::core::ffi::c_int + i_3 as ::core::ffi::c_int
            + 224 as ::core::ffi::c_int) as usize] = ((*in_0)
            .crc[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_3 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        ud[(4 as ::core::ffi::c_int + i_3 as ::core::ffi::c_int
            + 232 as ::core::ffi::c_int) as usize] = ((*in_0)
            .crc[1 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int - i_3 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int) as uint8_t;
        i_3 = i_3.wrapping_add(1);
    }
    let mut i_4: uint8_t = 0 as uint8_t;
    while (i_4 as ::core::ffi::c_int)
        < 240 as ::core::ffi::c_int + 4 as ::core::ffi::c_int
    {
        let mut G1: uint8_t = ((ud[(i_4 as ::core::ffi::c_int + 4 as ::core::ffi::c_int)
            as usize] as ::core::ffi::c_int
            + ud[(i_4 as ::core::ffi::c_int + 1 as ::core::ffi::c_int) as usize]
                as ::core::ffi::c_int
            + ud[(i_4 as ::core::ffi::c_int + 0 as ::core::ffi::c_int) as usize]
                as ::core::ffi::c_int) % 2 as ::core::ffi::c_int) as uint8_t;
        let mut G2: uint8_t = ((ud[(i_4 as ::core::ffi::c_int + 4 as ::core::ffi::c_int)
            as usize] as ::core::ffi::c_int
            + ud[(i_4 as ::core::ffi::c_int + 3 as ::core::ffi::c_int) as usize]
                as ::core::ffi::c_int
            + ud[(i_4 as ::core::ffi::c_int + 2 as ::core::ffi::c_int) as usize]
                as ::core::ffi::c_int
            + ud[(i_4 as ::core::ffi::c_int + 0 as ::core::ffi::c_int) as usize]
                as ::core::ffi::c_int) % 2 as ::core::ffi::c_int) as uint8_t;
        if puncture_pattern_1[p as usize] != 0 {
            *out.offset(pb as isize) = G1;
            pb = pb.wrapping_add(1);
        }
        p = p.wrapping_add(1);
        p = (p as ::core::ffi::c_int % pp_len as ::core::ffi::c_int) as uint8_t;
        if puncture_pattern_1[p as usize] != 0 {
            *out.offset(pb as isize) = G2;
            pb = pb.wrapping_add(1);
        }
        p = p.wrapping_add(1);
        p = (p as ::core::ffi::c_int % pp_len as ::core::ffi::c_int) as uint8_t;
        i_4 = i_4.wrapping_add(1);
    }
}
