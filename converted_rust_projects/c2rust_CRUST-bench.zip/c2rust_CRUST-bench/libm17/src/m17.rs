#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn conv_encode_stream_frame(out: *mut uint8_t, in_0: *const uint8_t, fn_0: uint16_t);
    fn conv_encode_packet_frame(out: *mut uint8_t, in_0: *const uint8_t);
    fn conv_encode_LSF(out: *mut uint8_t, in_0: *const lsf_t);
    fn extract_LICH(outp: *mut uint8_t, cnt: uint8_t, inp: *const lsf_t);
    fn unpack_LICH(out: *mut uint8_t, in_0: *const uint8_t);
    fn encode_LICH(outp: *mut uint8_t, inp: *const uint8_t);
    fn reorder_bits(outp: *mut uint8_t, inp: *const uint8_t);
    fn randomize_bits(inp: *mut uint8_t);
    static symbol_map: [int8_t; 4];
    static SYNC_LSF: uint16_t;
    static SYNC_STR: uint16_t;
    static SYNC_PKT: uint16_t;
    static eot_symbols: [::core::ffi::c_float; 8];
}
pub type int8_t = i8;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type pream_t = ::core::ffi::c_uint;
pub const PREAM_BERT: pream_t = 1;
pub const PREAM_LSF: pream_t = 0;
pub type frame_t = ::core::ffi::c_uint;
pub const FRAME_PKT: frame_t = 2;
pub const FRAME_STR: frame_t = 1;
pub const FRAME_LSF: frame_t = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct lsf_t {
    pub dst: [uint8_t; 6],
    pub src: [uint8_t; 6],
    pub type_0: [uint8_t; 2],
    pub meta: [uint8_t; 14],
    pub crc: [uint8_t; 2],
}
pub const SYM_PER_SWD: ::core::ffi::c_int = 8 as ::core::ffi::c_int;
pub const SYM_PER_PLD: ::core::ffi::c_int = 184 as ::core::ffi::c_int;
pub const SYM_PER_FRA: ::core::ffi::c_int = 192 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn send_preamble(
    mut out: *mut ::core::ffi::c_float,
    mut cnt: *mut uint32_t,
    type_0: pream_t,
) {
    if type_0 as ::core::ffi::c_uint
        == PREAM_BERT as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        let mut i: uint16_t = 0 as uint16_t;
        while (i as ::core::ffi::c_int) < SYM_PER_FRA / 2 as ::core::ffi::c_int {
            let fresh0 = *cnt;
            *cnt = (*cnt).wrapping_add(1);
            *out.offset(fresh0 as isize) = -3.0f64 as ::core::ffi::c_float;
            let fresh1 = *cnt;
            *cnt = (*cnt).wrapping_add(1);
            *out.offset(fresh1 as isize) = 3.0f64 as ::core::ffi::c_float;
            i = i.wrapping_add(1);
        }
    } else {
        let mut i_0: uint16_t = 0 as uint16_t;
        while (i_0 as ::core::ffi::c_int) < SYM_PER_FRA / 2 as ::core::ffi::c_int {
            let fresh2 = *cnt;
            *cnt = (*cnt).wrapping_add(1);
            *out.offset(fresh2 as isize) = 3.0f64 as ::core::ffi::c_float;
            let fresh3 = *cnt;
            *cnt = (*cnt).wrapping_add(1);
            *out.offset(fresh3 as isize) = -3.0f64 as ::core::ffi::c_float;
            i_0 = i_0.wrapping_add(1);
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn send_syncword(
    mut out: *mut ::core::ffi::c_float,
    mut cnt: *mut uint32_t,
    syncword: uint16_t,
) {
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < SYM_PER_SWD * 2 as ::core::ffi::c_int {
        let fresh4 = *cnt;
        *cnt = (*cnt).wrapping_add(1);
        *out.offset(fresh4 as isize) = symbol_map[(syncword as ::core::ffi::c_int
            >> 14 as ::core::ffi::c_int - i as ::core::ffi::c_int
            & 3 as ::core::ffi::c_int) as usize] as ::core::ffi::c_float;
        i = (i as ::core::ffi::c_int + 2 as ::core::ffi::c_int) as uint8_t;
    }
}
#[no_mangle]
pub unsafe extern "C" fn send_data(
    mut out: *mut ::core::ffi::c_float,
    mut cnt: *mut uint32_t,
    mut in_0: *const uint8_t,
) {
    let mut i: uint16_t = 0 as uint16_t;
    while (i as ::core::ffi::c_int) < SYM_PER_PLD {
        let fresh5 = *cnt;
        *cnt = (*cnt).wrapping_add(1);
        *out.offset(fresh5 as isize) = symbol_map[(*in_0
            .offset((2 as ::core::ffi::c_int * i as ::core::ffi::c_int) as isize)
            as ::core::ffi::c_int * 2 as ::core::ffi::c_int
            + *in_0
                .offset(
                    (2 as ::core::ffi::c_int * i as ::core::ffi::c_int
                        + 1 as ::core::ffi::c_int) as isize,
                ) as ::core::ffi::c_int) as usize] as ::core::ffi::c_float;
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn send_eot(
    mut out: *mut ::core::ffi::c_float,
    mut cnt: *mut uint32_t,
) {
    let mut i: uint16_t = 0 as uint16_t;
    while (i as ::core::ffi::c_int) < SYM_PER_FRA {
        let fresh6 = *cnt;
        *cnt = (*cnt).wrapping_add(1);
        *out.offset(fresh6 as isize) = eot_symbols[(i as ::core::ffi::c_int
            % 8 as ::core::ffi::c_int) as usize];
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn send_frame(
    mut out: *mut ::core::ffi::c_float,
    mut data: *const uint8_t,
    type_0: frame_t,
    mut lsf: *const lsf_t,
    lich_cnt: uint8_t,
    fn_0: uint16_t,
) {
    let mut lich: [uint8_t; 6] = [0; 6];
    let mut lich_encoded: [uint8_t; 12] = [0; 12];
    let mut enc_bits: [uint8_t; 368] = [0; 368];
    let mut rf_bits: [uint8_t; 368] = [0; 368];
    let mut sym_cnt: uint32_t = 0 as uint32_t;
    if type_0 as ::core::ffi::c_uint
        == FRAME_LSF as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        send_syncword(out as *mut ::core::ffi::c_float, &mut sym_cnt, SYNC_LSF);
        conv_encode_LSF(enc_bits.as_mut_ptr(), lsf);
    } else if type_0 as ::core::ffi::c_uint
        == FRAME_STR as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        send_syncword(out as *mut ::core::ffi::c_float, &mut sym_cnt, SYNC_STR);
        extract_LICH(lich.as_mut_ptr(), lich_cnt, lsf);
        encode_LICH(lich_encoded.as_mut_ptr(), lich.as_mut_ptr() as *const uint8_t);
        unpack_LICH(enc_bits.as_mut_ptr(), lich_encoded.as_mut_ptr() as *const uint8_t);
        conv_encode_stream_frame(
            &mut *enc_bits.as_mut_ptr().offset(96 as ::core::ffi::c_int as isize),
            data,
            fn_0,
        );
    } else if type_0 as ::core::ffi::c_uint
        == FRAME_PKT as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        send_syncword(out as *mut ::core::ffi::c_float, &mut sym_cnt, SYNC_PKT);
        conv_encode_packet_frame(enc_bits.as_mut_ptr(), data);
    }
    reorder_bits(rf_bits.as_mut_ptr(), enc_bits.as_mut_ptr() as *const uint8_t);
    randomize_bits(rf_bits.as_mut_ptr());
    send_data(out as *mut ::core::ffi::c_float, &mut sym_cnt, rf_bits.as_mut_ptr());
}
