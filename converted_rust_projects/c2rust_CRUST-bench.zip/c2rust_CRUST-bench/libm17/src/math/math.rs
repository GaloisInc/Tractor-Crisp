#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn sqrtf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
}
pub type int8_t = i8;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
#[no_mangle]
pub static mut rrc_taps_10: [::core::ffi::c_float; 81] = [
    -0.003195702904062073f32,
    -0.002930279157647190f32,
    -0.001940667871554463f32,
    -0.000356087678023658f32,
    0.001547011339077758f32,
    0.003389554791179751f32,
    0.004761898604225673f32,
    0.005310860846138910f32,
    0.004824746306020221f32,
    0.003297923526848786f32,
    0.000958710871218619f32,
    -0.001749908029791816f32,
    -0.004238694106631223f32,
    -0.005881783042101693f32,
    -0.006150256456781309f32,
    -0.004745376707651645f32,
    -0.001704189656473565f32,
    0.002547854551539951f32,
    0.007215575568844704f32,
    0.011231038205363532f32,
    0.013421952197060707f32,
    0.012730475385624438f32,
    0.008449554307303753f32,
    0.000436744366018287f32,
    -0.010735380379191660f32,
    -0.023726883538258272f32,
    -0.036498030780605324f32,
    -0.046500883189991064f32,
    -0.050979050575999614f32,
    -0.047340680079891187f32,
    -0.033554880492651755f32,
    -0.008513823955725943f32,
    0.027696543159614194f32,
    0.073664520037517042f32,
    0.126689053778116234f32,
    0.182990955139333916f32,
    0.238080025892859704f32,
    0.287235637987091563f32,
    0.326040247765297220f32,
    0.350895727088112619f32,
    0.359452932027607974f32,
    0.350895727088112619f32,
    0.326040247765297220f32,
    0.287235637987091563f32,
    0.238080025892859704f32,
    0.182990955139333916f32,
    0.126689053778116234f32,
    0.073664520037517042f32,
    0.027696543159614194f32,
    -0.008513823955725943f32,
    -0.033554880492651755f32,
    -0.047340680079891187f32,
    -0.050979050575999614f32,
    -0.046500883189991064f32,
    -0.036498030780605324f32,
    -0.023726883538258272f32,
    -0.010735380379191660f32,
    0.000436744366018287f32,
    0.008449554307303753f32,
    0.012730475385624438f32,
    0.013421952197060707f32,
    0.011231038205363532f32,
    0.007215575568844704f32,
    0.002547854551539951f32,
    -0.001704189656473565f32,
    -0.004745376707651645f32,
    -0.006150256456781309f32,
    -0.005881783042101693f32,
    -0.004238694106631223f32,
    -0.001749908029791816f32,
    0.000958710871218619f32,
    0.003297923526848786f32,
    0.004824746306020221f32,
    0.005310860846138910f32,
    0.004761898604225673f32,
    0.003389554791179751f32,
    0.001547011339077758f32,
    -0.000356087678023658f32,
    -0.001940667871554463f32,
    -0.002930279157647190f32,
    -0.003195702904062073f32,
];
#[no_mangle]
pub static mut rrc_taps_5: [::core::ffi::c_float; 41] = [
    -0.004519384154389f32,
    -0.002744505321971f32,
    0.002187793653660f32,
    0.006734308458208f32,
    0.006823188093192f32,
    0.001355815246317f32,
    -0.005994389201970f32,
    -0.008697733303330f32,
    -0.002410076268276f32,
    0.010204314627992f32,
    0.018981413448435f32,
    0.011949415510291f32,
    -0.015182045838927f32,
    -0.051615756197679f32,
    -0.072094910038768f32,
    -0.047453533621088f32,
    0.039168634270669f32,
    0.179164496628150f32,
    0.336694345124862f32,
    0.461088271869920f32,
    0.508340710642860f32,
    0.461088271869920f32,
    0.336694345124862f32,
    0.179164496628150f32,
    0.039168634270669f32,
    -0.047453533621088f32,
    -0.072094910038768f32,
    -0.051615756197679f32,
    -0.015182045838927f32,
    0.011949415510291f32,
    0.018981413448435f32,
    0.010204314627992f32,
    -0.002410076268276f32,
    -0.008697733303330f32,
    -0.005994389201970f32,
    0.001355815246317f32,
    0.006823188093192f32,
    0.006734308458208f32,
    0.002187793653660f32,
    -0.002744505321971f32,
    -0.004519384154389f32,
];
#[no_mangle]
pub static mut encode_matrix: [uint16_t; 12] = [
    0x8eb as ::core::ffi::c_int as uint16_t,
    0x93e as ::core::ffi::c_int as uint16_t,
    0xa97 as ::core::ffi::c_int as uint16_t,
    0xdc6 as ::core::ffi::c_int as uint16_t,
    0x367 as ::core::ffi::c_int as uint16_t,
    0x6cd as ::core::ffi::c_int as uint16_t,
    0xd99 as ::core::ffi::c_int as uint16_t,
    0x3da as ::core::ffi::c_int as uint16_t,
    0x7b4 as ::core::ffi::c_int as uint16_t,
    0xf68 as ::core::ffi::c_int as uint16_t,
    0x63b as ::core::ffi::c_int as uint16_t,
    0xc75 as ::core::ffi::c_int as uint16_t,
];
#[no_mangle]
pub static mut decode_matrix: [uint16_t; 12] = [
    0xc75 as ::core::ffi::c_int as uint16_t,
    0x49f as ::core::ffi::c_int as uint16_t,
    0x93e as ::core::ffi::c_int as uint16_t,
    0x6e3 as ::core::ffi::c_int as uint16_t,
    0xdc6 as ::core::ffi::c_int as uint16_t,
    0xf13 as ::core::ffi::c_int as uint16_t,
    0xab9 as ::core::ffi::c_int as uint16_t,
    0x1ed as ::core::ffi::c_int as uint16_t,
    0x3da as ::core::ffi::c_int as uint16_t,
    0x7b4 as ::core::ffi::c_int as uint16_t,
    0xf68 as ::core::ffi::c_int as uint16_t,
    0xa4f as ::core::ffi::c_int as uint16_t,
];
#[no_mangle]
pub unsafe extern "C" fn golay24_encode(data: uint16_t) -> uint32_t {
    let mut checksum: uint16_t = 0 as uint16_t;
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < 12 as ::core::ffi::c_int {
        if data as ::core::ffi::c_int
            & (1 as ::core::ffi::c_int) << i as ::core::ffi::c_int != 0
        {
            checksum = (checksum as ::core::ffi::c_int
                ^ encode_matrix[i as usize] as ::core::ffi::c_int) as uint16_t;
        }
        i = i.wrapping_add(1);
    }
    return (data as uint32_t) << 12 as ::core::ffi::c_int | checksum as uint32_t;
}
#[no_mangle]
pub unsafe extern "C" fn s_popcount(
    mut in_0: *const uint16_t,
    mut siz: uint8_t,
) -> uint32_t {
    let mut tmp: uint32_t = 0 as uint32_t;
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < siz as ::core::ffi::c_int {
        tmp = tmp.wrapping_add(*in_0.offset(i as isize) as uint32_t);
        i = i.wrapping_add(1);
    }
    return tmp;
}
#[no_mangle]
pub unsafe extern "C" fn s_calc_checksum(
    mut out: *mut uint16_t,
    mut value: *const uint16_t,
) {
    let mut checksum: [uint16_t; 12] = [0; 12];
    let mut soft_em: [uint16_t; 12] = [0; 12];
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < 12 as ::core::ffi::c_int {
        checksum[i as usize] = 0 as uint16_t;
        i = i.wrapping_add(1);
    }
    let mut i_0: uint8_t = 0 as uint8_t;
    while (i_0 as ::core::ffi::c_int) < 12 as ::core::ffi::c_int {
        int_to_soft(soft_em.as_mut_ptr(), encode_matrix[i_0 as usize], 12 as uint8_t);
        if *value.offset(i_0 as isize) as ::core::ffi::c_int
            > 0x7fff as ::core::ffi::c_int
        {
            soft_XOR(
                checksum.as_mut_ptr(),
                checksum.as_mut_ptr(),
                soft_em.as_mut_ptr(),
                12 as uint8_t,
            );
        }
        i_0 = i_0.wrapping_add(1);
    }
    memcpy(
        out as *mut uint8_t as *mut ::core::ffi::c_void,
        checksum.as_mut_ptr() as *mut uint8_t as *const ::core::ffi::c_void,
        (12 as ::core::ffi::c_int * 2 as ::core::ffi::c_int) as size_t,
    );
}
#[no_mangle]
pub unsafe extern "C" fn s_detect_errors(mut codeword: *const uint16_t) -> uint32_t {
    let mut data: [uint16_t; 12] = [0; 12];
    let mut parity: [uint16_t; 12] = [0; 12];
    let mut cksum: [uint16_t; 12] = [0; 12];
    let mut syndrome: [uint16_t; 12] = [0; 12];
    let mut weight: uint32_t = 0;
    memcpy(
        data.as_mut_ptr() as *mut uint8_t as *mut ::core::ffi::c_void,
        &*codeword.offset(12 as ::core::ffi::c_int as isize) as *const uint16_t
            as *mut uint8_t as *const ::core::ffi::c_void,
        (2 as ::core::ffi::c_int * 12 as ::core::ffi::c_int) as size_t,
    );
    memcpy(
        parity.as_mut_ptr() as *mut uint8_t as *mut ::core::ffi::c_void,
        &*codeword.offset(0 as ::core::ffi::c_int as isize) as *const uint16_t
            as *mut uint8_t as *const ::core::ffi::c_void,
        (2 as ::core::ffi::c_int * 12 as ::core::ffi::c_int) as size_t,
    );
    s_calc_checksum(cksum.as_mut_ptr(), data.as_mut_ptr());
    soft_XOR(
        syndrome.as_mut_ptr(),
        parity.as_mut_ptr(),
        cksum.as_mut_ptr(),
        12 as uint8_t,
    );
    weight = s_popcount(syndrome.as_mut_ptr(), 12 as uint8_t);
    if weight < (4 as ::core::ffi::c_int * 0xfffe as ::core::ffi::c_int) as uint32_t {
        return soft_to_int(syndrome.as_mut_ptr(), 12 as uint8_t) as uint32_t;
    }
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < 12 as ::core::ffi::c_int {
        let mut e: uint16_t = ((1 as ::core::ffi::c_int) << i as ::core::ffi::c_int)
            as uint16_t;
        let mut coded_error: uint16_t = encode_matrix[i as usize];
        let mut scoded_error: [uint16_t; 12] = [0; 12];
        let mut sc: [uint16_t; 12] = [0; 12];
        int_to_soft(scoded_error.as_mut_ptr(), coded_error, 12 as uint8_t);
        soft_XOR(
            sc.as_mut_ptr(),
            syndrome.as_mut_ptr(),
            scoded_error.as_mut_ptr(),
            12 as uint8_t,
        );
        weight = s_popcount(sc.as_mut_ptr(), 12 as uint8_t);
        if weight < (3 as ::core::ffi::c_int * 0xfffe as ::core::ffi::c_int) as uint32_t
        {
            let mut s: uint16_t = soft_to_int(syndrome.as_mut_ptr(), 12 as uint8_t);
            return ((e as ::core::ffi::c_int) << 12 as ::core::ffi::c_int
                | s as ::core::ffi::c_int ^ coded_error as ::core::ffi::c_int)
                as uint32_t;
        }
        i = i.wrapping_add(1);
    }
    let mut i_0: uint8_t = 0 as uint8_t;
    while (i_0 as ::core::ffi::c_int) < 11 as ::core::ffi::c_int {
        let mut j: uint8_t = (i_0 as ::core::ffi::c_int + 1 as ::core::ffi::c_int)
            as uint8_t;
        while (j as ::core::ffi::c_int) < 12 as ::core::ffi::c_int {
            let mut e_0: uint16_t = ((1 as ::core::ffi::c_int)
                << i_0 as ::core::ffi::c_int
                | (1 as ::core::ffi::c_int) << j as ::core::ffi::c_int) as uint16_t;
            let mut coded_error_0: uint16_t = (encode_matrix[i_0 as usize]
                as ::core::ffi::c_int ^ encode_matrix[j as usize] as ::core::ffi::c_int)
                as uint16_t;
            let mut scoded_error_0: [uint16_t; 12] = [0; 12];
            let mut sc_0: [uint16_t; 12] = [0; 12];
            int_to_soft(scoded_error_0.as_mut_ptr(), coded_error_0, 12 as uint8_t);
            soft_XOR(
                sc_0.as_mut_ptr(),
                syndrome.as_mut_ptr(),
                scoded_error_0.as_mut_ptr(),
                12 as uint8_t,
            );
            weight = s_popcount(sc_0.as_mut_ptr(), 12 as uint8_t);
            if weight
                < (2 as ::core::ffi::c_int * 0xffff as ::core::ffi::c_int) as uint32_t
            {
                let mut s_0: uint16_t = soft_to_int(
                    syndrome.as_mut_ptr(),
                    12 as uint8_t,
                );
                return ((e_0 as ::core::ffi::c_int) << 12 as ::core::ffi::c_int
                    | s_0 as ::core::ffi::c_int ^ coded_error_0 as ::core::ffi::c_int)
                    as uint32_t;
            }
            j = j.wrapping_add(1);
        }
        i_0 = i_0.wrapping_add(1);
    }
    let mut inv_syndrome: [uint16_t; 12] = [
        0 as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
        0 as ::core::ffi::c_int as uint16_t,
    ];
    let mut dm: [uint16_t; 12] = [0; 12];
    let mut i_1: uint8_t = 0 as uint8_t;
    while (i_1 as ::core::ffi::c_int) < 12 as ::core::ffi::c_int {
        if syndrome[i_1 as usize] as ::core::ffi::c_int > 0x7fff as ::core::ffi::c_int {
            int_to_soft(dm.as_mut_ptr(), decode_matrix[i_1 as usize], 12 as uint8_t);
            soft_XOR(
                inv_syndrome.as_mut_ptr(),
                inv_syndrome.as_mut_ptr(),
                dm.as_mut_ptr(),
                12 as uint8_t,
            );
        }
        i_1 = i_1.wrapping_add(1);
    }
    weight = s_popcount(inv_syndrome.as_mut_ptr(), 12 as uint8_t);
    if weight < (4 as ::core::ffi::c_int * 0xffff as ::core::ffi::c_int) as uint32_t {
        return ((soft_to_int(inv_syndrome.as_mut_ptr(), 12 as uint8_t)
            as ::core::ffi::c_int) << 12 as ::core::ffi::c_int) as uint32_t;
    }
    let mut i_2: uint8_t = 0 as uint8_t;
    while (i_2 as ::core::ffi::c_int) < 12 as ::core::ffi::c_int {
        let mut e_1: uint16_t = ((1 as ::core::ffi::c_int) << i_2 as ::core::ffi::c_int)
            as uint16_t;
        let mut coding_error: uint16_t = decode_matrix[i_2 as usize];
        let mut ce: [uint16_t; 12] = [0; 12];
        let mut tmp: [uint16_t; 12] = [0; 12];
        int_to_soft(ce.as_mut_ptr(), coding_error, 12 as uint8_t);
        soft_XOR(
            tmp.as_mut_ptr(),
            inv_syndrome.as_mut_ptr(),
            ce.as_mut_ptr(),
            12 as uint8_t,
        );
        weight = s_popcount(tmp.as_mut_ptr(), 12 as uint8_t);
        if weight
            < (3 as ::core::ffi::c_int
                * (0xffff as ::core::ffi::c_int + 2 as ::core::ffi::c_int)) as uint32_t
        {
            return ((soft_to_int(inv_syndrome.as_mut_ptr(), 12 as uint8_t)
                as ::core::ffi::c_int ^ coding_error as ::core::ffi::c_int)
                << 12 as ::core::ffi::c_int | e_1 as ::core::ffi::c_int) as uint32_t;
        }
        i_2 = i_2.wrapping_add(1);
    }
    return 0xffffffff as uint32_t;
}
#[no_mangle]
pub unsafe extern "C" fn golay24_sdecode(mut codeword: *const uint16_t) -> uint16_t {
    let mut cw: [uint16_t; 24] = [0; 24];
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < 24 as ::core::ffi::c_int {
        cw[i as usize] = *codeword
            .offset((23 as ::core::ffi::c_int - i as ::core::ffi::c_int) as isize);
        i = i.wrapping_add(1);
    }
    let mut errors: uint32_t = s_detect_errors(cw.as_mut_ptr());
    if errors == 0xffffffff as uint32_t {
        return 0xffff as uint16_t;
    }
    return (((soft_to_int(
        &mut *cw.as_mut_ptr().offset(0 as ::core::ffi::c_int as isize),
        16 as uint8_t,
    ) as ::core::ffi::c_int
        | (soft_to_int(
            &mut *cw.as_mut_ptr().offset(16 as ::core::ffi::c_int as isize),
            8 as uint8_t,
        ) as ::core::ffi::c_int) << 16 as ::core::ffi::c_int) as uint32_t ^ errors)
        >> 12 as ::core::ffi::c_int & 0xfff as uint32_t) as uint16_t;
}
#[no_mangle]
pub unsafe extern "C" fn decode_LICH(mut outp: *mut uint8_t, mut inp: *const uint16_t) {
    let mut tmp: uint16_t = 0;
    memset(outp as *mut ::core::ffi::c_void, 0 as ::core::ffi::c_int, 6 as size_t);
    tmp = golay24_sdecode(&*inp.offset(0 as ::core::ffi::c_int as isize));
    *outp.offset(0 as ::core::ffi::c_int as isize) = (tmp as ::core::ffi::c_int
        >> 4 as ::core::ffi::c_int & 0xff as ::core::ffi::c_int) as uint8_t;
    let ref mut fresh0 = *outp.offset(1 as ::core::ffi::c_int as isize);
    *fresh0 = (*fresh0 as ::core::ffi::c_int
        | (tmp as ::core::ffi::c_int & 0xf as ::core::ffi::c_int)
            << 4 as ::core::ffi::c_int) as uint8_t;
    tmp = golay24_sdecode(
        &*inp.offset((1 as ::core::ffi::c_int * 24 as ::core::ffi::c_int) as isize),
    );
    let ref mut fresh1 = *outp.offset(1 as ::core::ffi::c_int as isize);
    *fresh1 = (*fresh1 as ::core::ffi::c_int
        | tmp as ::core::ffi::c_int >> 8 as ::core::ffi::c_int
            & 0xf as ::core::ffi::c_int) as uint8_t;
    *outp.offset(2 as ::core::ffi::c_int as isize) = (tmp as ::core::ffi::c_int
        & 0xff as ::core::ffi::c_int) as uint8_t;
    tmp = golay24_sdecode(
        &*inp.offset((2 as ::core::ffi::c_int * 24 as ::core::ffi::c_int) as isize),
    );
    *outp.offset(3 as ::core::ffi::c_int as isize) = (tmp as ::core::ffi::c_int
        >> 4 as ::core::ffi::c_int & 0xff as ::core::ffi::c_int) as uint8_t;
    let ref mut fresh2 = *outp.offset(4 as ::core::ffi::c_int as isize);
    *fresh2 = (*fresh2 as ::core::ffi::c_int
        | (tmp as ::core::ffi::c_int & 0xf as ::core::ffi::c_int)
            << 4 as ::core::ffi::c_int) as uint8_t;
    tmp = golay24_sdecode(
        &*inp.offset((3 as ::core::ffi::c_int * 24 as ::core::ffi::c_int) as isize),
    );
    let ref mut fresh3 = *outp.offset(4 as ::core::ffi::c_int as isize);
    *fresh3 = (*fresh3 as ::core::ffi::c_int
        | tmp as ::core::ffi::c_int >> 8 as ::core::ffi::c_int
            & 0xf as ::core::ffi::c_int) as uint8_t;
    *outp.offset(5 as ::core::ffi::c_int as isize) = (tmp as ::core::ffi::c_int
        & 0xff as ::core::ffi::c_int) as uint8_t;
}
#[no_mangle]
pub unsafe extern "C" fn encode_LICH(mut outp: *mut uint8_t, mut inp: *const uint8_t) {
    let mut val: uint32_t = 0;
    val = golay24_encode(
        ((*inp.offset(0 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
            << 4 as ::core::ffi::c_int
            | *inp.offset(1 as ::core::ffi::c_int as isize) as ::core::ffi::c_int
                >> 4 as ::core::ffi::c_int) as uint16_t,
    );
    *outp.offset(0 as ::core::ffi::c_int as isize) = (val >> 16 as ::core::ffi::c_int
        & 0xff as uint32_t) as uint8_t;
    *outp.offset(1 as ::core::ffi::c_int as isize) = (val >> 8 as ::core::ffi::c_int
        & 0xff as uint32_t) as uint8_t;
    *outp.offset(2 as ::core::ffi::c_int as isize) = (val >> 0 as ::core::ffi::c_int
        & 0xff as uint32_t) as uint8_t;
    val = golay24_encode(
        ((*inp.offset(1 as ::core::ffi::c_int as isize) as ::core::ffi::c_int
            & 0xf as ::core::ffi::c_int) << 8 as ::core::ffi::c_int
            | *inp.offset(2 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
            as uint16_t,
    );
    *outp.offset(3 as ::core::ffi::c_int as isize) = (val >> 16 as ::core::ffi::c_int
        & 0xff as uint32_t) as uint8_t;
    *outp.offset(4 as ::core::ffi::c_int as isize) = (val >> 8 as ::core::ffi::c_int
        & 0xff as uint32_t) as uint8_t;
    *outp.offset(5 as ::core::ffi::c_int as isize) = (val >> 0 as ::core::ffi::c_int
        & 0xff as uint32_t) as uint8_t;
    val = golay24_encode(
        ((*inp.offset(3 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
            << 4 as ::core::ffi::c_int
            | *inp.offset(4 as ::core::ffi::c_int as isize) as ::core::ffi::c_int
                >> 4 as ::core::ffi::c_int) as uint16_t,
    );
    *outp.offset(6 as ::core::ffi::c_int as isize) = (val >> 16 as ::core::ffi::c_int
        & 0xff as uint32_t) as uint8_t;
    *outp.offset(7 as ::core::ffi::c_int as isize) = (val >> 8 as ::core::ffi::c_int
        & 0xff as uint32_t) as uint8_t;
    *outp.offset(8 as ::core::ffi::c_int as isize) = (val >> 0 as ::core::ffi::c_int
        & 0xff as uint32_t) as uint8_t;
    val = golay24_encode(
        ((*inp.offset(4 as ::core::ffi::c_int as isize) as ::core::ffi::c_int
            & 0xf as ::core::ffi::c_int) << 8 as ::core::ffi::c_int
            | *inp.offset(5 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
            as uint16_t,
    );
    *outp.offset(9 as ::core::ffi::c_int as isize) = (val >> 16 as ::core::ffi::c_int
        & 0xff as uint32_t) as uint8_t;
    *outp.offset(10 as ::core::ffi::c_int as isize) = (val >> 8 as ::core::ffi::c_int
        & 0xff as uint32_t) as uint8_t;
    *outp.offset(11 as ::core::ffi::c_int as isize) = (val >> 0 as ::core::ffi::c_int
        & 0xff as uint32_t) as uint8_t;
}
#[no_mangle]
pub unsafe extern "C" fn q_abs_diff(v1: uint16_t, v2: uint16_t) -> uint16_t {
    if v2 as ::core::ffi::c_int > v1 as ::core::ffi::c_int {
        return (v2 as ::core::ffi::c_int - v1 as ::core::ffi::c_int) as uint16_t;
    }
    return (v1 as ::core::ffi::c_int - v2 as ::core::ffi::c_int) as uint16_t;
}
#[no_mangle]
pub unsafe extern "C" fn eucl_norm(
    mut in1: *const ::core::ffi::c_float,
    mut in2: *const int8_t,
    n: uint8_t,
) -> ::core::ffi::c_float {
    let mut tmp: ::core::ffi::c_float = 0.0f32;
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < n as ::core::ffi::c_int {
        tmp
            += (*in1.offset(i as isize)
                - *in2.offset(i as isize) as ::core::ffi::c_float)
                * (*in1.offset(i as isize)
                    - *in2.offset(i as isize) as ::core::ffi::c_float);
        i = i.wrapping_add(1);
    }
    return sqrtf(tmp);
}
#[no_mangle]
pub unsafe extern "C" fn int_to_soft(
    mut out: *mut uint16_t,
    in_0: uint16_t,
    len: uint8_t,
) {
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < len as ::core::ffi::c_int {
        if in_0 as ::core::ffi::c_int >> i as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int != 0
        {
            *out.offset(i as isize) = 0xffff as uint16_t;
        } else {
            *out.offset(i as isize) = 0 as uint16_t;
        };
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn soft_to_int(
    mut in_0: *const uint16_t,
    len: uint8_t,
) -> uint16_t {
    let mut tmp: uint16_t = 0 as uint16_t;
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < len as ::core::ffi::c_int {
        if *in_0.offset(i as isize) as ::core::ffi::c_uint
            > 0x7fff as ::core::ffi::c_uint
        {
            tmp = (tmp as ::core::ffi::c_int
                | (1 as ::core::ffi::c_int) << i as ::core::ffi::c_int) as uint16_t;
        }
        i = i.wrapping_add(1);
    }
    return tmp;
}
#[no_mangle]
pub unsafe extern "C" fn add16(a: uint16_t, b: uint16_t) -> uint16_t {
    let mut r: uint32_t = (a as uint32_t).wrapping_add(b as uint32_t);
    return (if r <= 0xffff as uint32_t { r } else { 0xffff as uint32_t }) as uint16_t;
}
#[no_mangle]
pub unsafe extern "C" fn sub16(a: uint16_t, b: uint16_t) -> uint16_t {
    if a as ::core::ffi::c_int >= b as ::core::ffi::c_int {
        return (a as ::core::ffi::c_int - b as ::core::ffi::c_int) as uint16_t
    } else {
        return 0 as uint16_t
    };
}
#[no_mangle]
pub unsafe extern "C" fn div16(a: uint16_t, b: uint16_t) -> uint16_t {
    let mut aa: uint32_t = (a as uint32_t) << 16 as ::core::ffi::c_int;
    let mut r: uint32_t = aa.wrapping_div(b as uint32_t);
    return (if r <= 0xffff as uint32_t { r } else { 0xffff as uint32_t }) as uint16_t;
}
#[no_mangle]
pub unsafe extern "C" fn mul16(a: uint16_t, b: uint16_t) -> uint16_t {
    return ((a as uint32_t).wrapping_mul(b as uint32_t) >> 16 as ::core::ffi::c_int)
        as uint16_t;
}
#[no_mangle]
pub unsafe extern "C" fn soft_bit_XOR(a: uint16_t, b: uint16_t) -> uint16_t {
    return add16(
        mul16(a, sub16(0xffff as uint16_t, b)),
        mul16(b, sub16(0xffff as uint16_t, a)),
    );
}
#[no_mangle]
pub unsafe extern "C" fn soft_bit_NOT(a: uint16_t) -> uint16_t {
    return (0xffff as ::core::ffi::c_uint).wrapping_sub(a as ::core::ffi::c_uint)
        as uint16_t;
}
#[no_mangle]
pub unsafe extern "C" fn soft_XOR(
    mut out: *mut uint16_t,
    mut a: *const uint16_t,
    mut b: *const uint16_t,
    len: uint8_t,
) {
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < len as ::core::ffi::c_int {
        *out.offset(i as isize) = soft_bit_XOR(
            *a.offset(i as isize),
            *b.offset(i as isize),
        );
        i = i.wrapping_add(1);
    }
}
