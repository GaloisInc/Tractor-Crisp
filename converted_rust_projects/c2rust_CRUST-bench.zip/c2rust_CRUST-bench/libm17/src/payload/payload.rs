#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn sprintf(
        _: *mut ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
}
pub type __darwin_size_t = usize;
pub type int8_t = i8;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint64_t = u64;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct lsf_t {
    pub dst: [uint8_t; 6],
    pub src: [uint8_t; 6],
    pub type_0: [uint8_t; 2],
    pub meta: [uint8_t; 14],
    pub crc: [uint8_t; 2],
}
pub const U40_9: ::core::ffi::c_ulong = 262144000000000 as ::core::ffi::c_ulong;
pub const U40_9_8: ::core::ffi::c_ulong = 268697600000000 as ::core::ffi::c_ulong;
#[no_mangle]
pub unsafe extern "C" fn decode_callsign_value(mut outp: *mut uint8_t, inp: uint64_t) {
    let mut encoded: uint64_t = inp;
    let mut start: uint8_t = 0 as uint8_t;
    if encoded >= U40_9 as uint64_t {
        if encoded == 0xffffffffffff as uint64_t {
            sprintf(
                outp as *mut ::core::ffi::c_char,
                b"@ALL\0" as *const u8 as *const ::core::ffi::c_char,
            );
            return;
        } else if encoded <= U40_9_8 as uint64_t {
            start = 1 as uint8_t;
            encoded = encoded.wrapping_sub(U40_9 as uint64_t);
            *outp.offset(0 as ::core::ffi::c_int as isize) = '#' as i32 as uint8_t;
        } else {
            return
        }
    }
    let mut i: uint8_t = start;
    while encoded > 0 as uint64_t {
        *outp.offset(i as isize) = ::core::mem::transmute::<
            [u8; 41],
            [::core::ffi::c_char; 41],
        >(
            *b" ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-/.\0",
        )[encoded.wrapping_rem(40 as uint64_t) as usize] as uint8_t;
        encoded = encoded.wrapping_div(40 as uint64_t);
        i = i.wrapping_add(1);
    }
    *outp.offset(i as isize) = 0 as uint8_t;
}
#[no_mangle]
pub unsafe extern "C" fn decode_callsign_bytes(
    mut outp: *mut uint8_t,
    mut inp: *const uint8_t,
) {
    let mut encoded: uint64_t = 0 as uint64_t;
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < 6 as ::core::ffi::c_int {
        encoded
            |= (*inp.offset((5 as ::core::ffi::c_int - i as ::core::ffi::c_int) as isize)
                as uint64_t) << 8 as ::core::ffi::c_int * i as ::core::ffi::c_int;
        i = i.wrapping_add(1);
    }
    decode_callsign_value(outp, encoded);
}
#[no_mangle]
pub unsafe extern "C" fn encode_callsign_value(
    mut out: *mut uint64_t,
    mut inp: *const uint8_t,
) -> int8_t {
    if strlen(inp as *const ::core::ffi::c_char) > 9 as size_t {
        return -(1 as ::core::ffi::c_int) as int8_t;
    }
    let charMap: [uint8_t; 40] = ::core::mem::transmute::<
        [u8; 40],
        [uint8_t; 40],
    >(*b" ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-/.");
    let mut tmp: uint64_t = 0 as uint64_t;
    let mut start: uint8_t = 0 as uint8_t;
    if strcmp(
        inp as *const ::core::ffi::c_char,
        b"@ALL\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
    {
        *out = 0xffffffffffff as uint64_t;
        return 0 as int8_t;
    }
    if *inp.offset(0 as ::core::ffi::c_int as isize) as ::core::ffi::c_int == '#' as i32
    {
        start = 1 as uint8_t;
    }
    let mut i: int8_t = strlen(inp as *const ::core::ffi::c_char)
        .wrapping_sub(1 as size_t) as int8_t;
    while i as ::core::ffi::c_int >= start as ::core::ffi::c_int {
        let mut j: uint8_t = 0 as uint8_t;
        while (j as ::core::ffi::c_int) < 40 as ::core::ffi::c_int {
            if *inp.offset(i as isize) as ::core::ffi::c_int
                == charMap[j as usize] as ::core::ffi::c_int
            {
                tmp = tmp.wrapping_mul(40 as uint64_t).wrapping_add(j as uint64_t);
                break;
            } else {
                j = j.wrapping_add(1);
            }
        }
        i -= 1;
    }
    if start != 0 {
        tmp = tmp.wrapping_add(U40_9 as uint64_t);
    }
    *out = tmp;
    return 0 as int8_t;
}
#[no_mangle]
pub unsafe extern "C" fn encode_callsign_bytes(
    mut out: *mut uint8_t,
    mut inp: *const uint8_t,
) -> int8_t {
    let mut tmp: uint64_t = 0 as uint64_t;
    if encode_callsign_value(&mut tmp, inp) != 0 {
        return -(1 as ::core::ffi::c_int) as int8_t;
    }
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < 6 as ::core::ffi::c_int {
        *out.offset((5 as ::core::ffi::c_int - i as ::core::ffi::c_int) as isize) = (tmp
            >> 8 as ::core::ffi::c_int * i as ::core::ffi::c_int & 0xff as uint64_t)
            as uint8_t;
        i = i.wrapping_add(1);
    }
    return 0 as int8_t;
}
#[no_mangle]
pub static mut M17_CRC_POLY: uint16_t = 0x5935 as uint16_t;
#[no_mangle]
pub unsafe extern "C" fn CRC_M17(mut in_0: *const uint8_t, len: uint16_t) -> uint16_t {
    let mut crc: uint32_t = 0xffff as uint32_t;
    let mut i: uint16_t = 0 as uint16_t;
    while (i as ::core::ffi::c_int) < len as ::core::ffi::c_int {
        crc
            ^= ((*in_0.offset(i as isize) as ::core::ffi::c_int)
                << 8 as ::core::ffi::c_int) as uint32_t;
        let mut j: uint8_t = 0 as uint8_t;
        while (j as ::core::ffi::c_int) < 8 as ::core::ffi::c_int {
            crc <<= 1 as ::core::ffi::c_int;
            if crc & 0x10000 as uint32_t != 0 {
                crc = (crc ^ M17_CRC_POLY as uint32_t) & 0xffff as uint32_t;
            }
            j = j.wrapping_add(1);
        }
        i = i.wrapping_add(1);
    }
    return (crc & 0xffff as uint32_t) as uint16_t;
}
#[no_mangle]
pub unsafe extern "C" fn LSF_CRC(mut in_0: *const lsf_t) -> uint16_t {
    let mut d: [uint8_t; 28] = [0; 28];
    memcpy(
        &mut *d.as_mut_ptr().offset(0 as ::core::ffi::c_int as isize) as *mut uint8_t
            as *mut ::core::ffi::c_void,
        (*in_0).dst.as_ptr() as *const ::core::ffi::c_void,
        6 as size_t,
    );
    memcpy(
        &mut *d.as_mut_ptr().offset(6 as ::core::ffi::c_int as isize) as *mut uint8_t
            as *mut ::core::ffi::c_void,
        (*in_0).src.as_ptr() as *const ::core::ffi::c_void,
        6 as size_t,
    );
    memcpy(
        &mut *d.as_mut_ptr().offset(12 as ::core::ffi::c_int as isize) as *mut uint8_t
            as *mut ::core::ffi::c_void,
        (*in_0).type_0.as_ptr() as *const ::core::ffi::c_void,
        2 as size_t,
    );
    memcpy(
        &mut *d.as_mut_ptr().offset(14 as ::core::ffi::c_int as isize) as *mut uint8_t
            as *mut ::core::ffi::c_void,
        (*in_0).meta.as_ptr() as *const ::core::ffi::c_void,
        14 as size_t,
    );
    return CRC_M17(d.as_mut_ptr(), 28 as uint16_t);
}
#[no_mangle]
pub unsafe extern "C" fn extract_LICH(
    mut outp: *mut uint8_t,
    cnt: uint8_t,
    mut inp: *const lsf_t,
) {
    match cnt as ::core::ffi::c_int {
        0 => {
            *outp.offset(0 as ::core::ffi::c_int as isize) = (*inp)
                .dst[0 as ::core::ffi::c_int as usize];
            *outp.offset(1 as ::core::ffi::c_int as isize) = (*inp)
                .dst[1 as ::core::ffi::c_int as usize];
            *outp.offset(2 as ::core::ffi::c_int as isize) = (*inp)
                .dst[2 as ::core::ffi::c_int as usize];
            *outp.offset(3 as ::core::ffi::c_int as isize) = (*inp)
                .dst[3 as ::core::ffi::c_int as usize];
            *outp.offset(4 as ::core::ffi::c_int as isize) = (*inp)
                .dst[4 as ::core::ffi::c_int as usize];
        }
        1 => {
            *outp.offset(0 as ::core::ffi::c_int as isize) = (*inp)
                .dst[5 as ::core::ffi::c_int as usize];
            *outp.offset(1 as ::core::ffi::c_int as isize) = (*inp)
                .src[0 as ::core::ffi::c_int as usize];
            *outp.offset(2 as ::core::ffi::c_int as isize) = (*inp)
                .src[1 as ::core::ffi::c_int as usize];
            *outp.offset(3 as ::core::ffi::c_int as isize) = (*inp)
                .src[2 as ::core::ffi::c_int as usize];
            *outp.offset(4 as ::core::ffi::c_int as isize) = (*inp)
                .src[3 as ::core::ffi::c_int as usize];
        }
        2 => {
            *outp.offset(0 as ::core::ffi::c_int as isize) = (*inp)
                .src[4 as ::core::ffi::c_int as usize];
            *outp.offset(1 as ::core::ffi::c_int as isize) = (*inp)
                .src[5 as ::core::ffi::c_int as usize];
            *outp.offset(2 as ::core::ffi::c_int as isize) = (*inp)
                .type_0[0 as ::core::ffi::c_int as usize];
            *outp.offset(3 as ::core::ffi::c_int as isize) = (*inp)
                .type_0[1 as ::core::ffi::c_int as usize];
            *outp.offset(4 as ::core::ffi::c_int as isize) = (*inp)
                .meta[0 as ::core::ffi::c_int as usize];
        }
        3 => {
            *outp.offset(0 as ::core::ffi::c_int as isize) = (*inp)
                .meta[1 as ::core::ffi::c_int as usize];
            *outp.offset(1 as ::core::ffi::c_int as isize) = (*inp)
                .meta[2 as ::core::ffi::c_int as usize];
            *outp.offset(2 as ::core::ffi::c_int as isize) = (*inp)
                .meta[3 as ::core::ffi::c_int as usize];
            *outp.offset(3 as ::core::ffi::c_int as isize) = (*inp)
                .meta[4 as ::core::ffi::c_int as usize];
            *outp.offset(4 as ::core::ffi::c_int as isize) = (*inp)
                .meta[5 as ::core::ffi::c_int as usize];
        }
        4 => {
            *outp.offset(0 as ::core::ffi::c_int as isize) = (*inp)
                .meta[6 as ::core::ffi::c_int as usize];
            *outp.offset(1 as ::core::ffi::c_int as isize) = (*inp)
                .meta[7 as ::core::ffi::c_int as usize];
            *outp.offset(2 as ::core::ffi::c_int as isize) = (*inp)
                .meta[8 as ::core::ffi::c_int as usize];
            *outp.offset(3 as ::core::ffi::c_int as isize) = (*inp)
                .meta[9 as ::core::ffi::c_int as usize];
            *outp.offset(4 as ::core::ffi::c_int as isize) = (*inp)
                .meta[10 as ::core::ffi::c_int as usize];
        }
        5 => {
            *outp.offset(0 as ::core::ffi::c_int as isize) = (*inp)
                .meta[11 as ::core::ffi::c_int as usize];
            *outp.offset(1 as ::core::ffi::c_int as isize) = (*inp)
                .meta[12 as ::core::ffi::c_int as usize];
            *outp.offset(2 as ::core::ffi::c_int as isize) = (*inp)
                .meta[13 as ::core::ffi::c_int as usize];
            *outp.offset(3 as ::core::ffi::c_int as isize) = (*inp)
                .crc[0 as ::core::ffi::c_int as usize];
            *outp.offset(4 as ::core::ffi::c_int as isize) = (*inp)
                .crc[1 as ::core::ffi::c_int as usize];
        }
        _ => {}
    }
    *outp.offset(5 as ::core::ffi::c_int as isize) = ((cnt as ::core::ffi::c_int)
        << 5 as ::core::ffi::c_int) as uint8_t;
}
#[no_mangle]
pub unsafe extern "C" fn unpack_LICH(mut out: *mut uint8_t, mut in_0: *const uint8_t) {
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < 12 as ::core::ffi::c_int {
        let mut j: uint8_t = 0 as uint8_t;
        while (j as ::core::ffi::c_int) < 8 as ::core::ffi::c_int {
            *out
                .offset(
                    (i as ::core::ffi::c_int * 8 as ::core::ffi::c_int
                        + j as ::core::ffi::c_int) as isize,
                ) = (*in_0.offset(i as isize) as ::core::ffi::c_int
                >> 7 as ::core::ffi::c_int - j as ::core::ffi::c_int
                & 1 as ::core::ffi::c_int) as uint8_t;
            j = j.wrapping_add(1);
        }
        i = i.wrapping_add(1);
    }
}
