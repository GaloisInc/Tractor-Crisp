#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn soft_bit_NOT(a: uint16_t) -> uint16_t;
    static symbol_list: [int8_t; 4];
}
pub type int8_t = i8;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub const SYM_PER_PLD: ::core::ffi::c_int = 184 as ::core::ffi::c_int;
#[no_mangle]
pub static mut intrl_seq: [uint16_t; 368] = [
    0 as ::core::ffi::c_int as uint16_t,
    137 as ::core::ffi::c_int as uint16_t,
    90 as ::core::ffi::c_int as uint16_t,
    227 as ::core::ffi::c_int as uint16_t,
    180 as ::core::ffi::c_int as uint16_t,
    317 as ::core::ffi::c_int as uint16_t,
    270 as ::core::ffi::c_int as uint16_t,
    39 as ::core::ffi::c_int as uint16_t,
    360 as ::core::ffi::c_int as uint16_t,
    129 as ::core::ffi::c_int as uint16_t,
    82 as ::core::ffi::c_int as uint16_t,
    219 as ::core::ffi::c_int as uint16_t,
    172 as ::core::ffi::c_int as uint16_t,
    309 as ::core::ffi::c_int as uint16_t,
    262 as ::core::ffi::c_int as uint16_t,
    31 as ::core::ffi::c_int as uint16_t,
    352 as ::core::ffi::c_int as uint16_t,
    121 as ::core::ffi::c_int as uint16_t,
    74 as ::core::ffi::c_int as uint16_t,
    211 as ::core::ffi::c_int as uint16_t,
    164 as ::core::ffi::c_int as uint16_t,
    301 as ::core::ffi::c_int as uint16_t,
    254 as ::core::ffi::c_int as uint16_t,
    23 as ::core::ffi::c_int as uint16_t,
    344 as ::core::ffi::c_int as uint16_t,
    113 as ::core::ffi::c_int as uint16_t,
    66 as ::core::ffi::c_int as uint16_t,
    203 as ::core::ffi::c_int as uint16_t,
    156 as ::core::ffi::c_int as uint16_t,
    293 as ::core::ffi::c_int as uint16_t,
    246 as ::core::ffi::c_int as uint16_t,
    15 as ::core::ffi::c_int as uint16_t,
    336 as ::core::ffi::c_int as uint16_t,
    105 as ::core::ffi::c_int as uint16_t,
    58 as ::core::ffi::c_int as uint16_t,
    195 as ::core::ffi::c_int as uint16_t,
    148 as ::core::ffi::c_int as uint16_t,
    285 as ::core::ffi::c_int as uint16_t,
    238 as ::core::ffi::c_int as uint16_t,
    7 as ::core::ffi::c_int as uint16_t,
    328 as ::core::ffi::c_int as uint16_t,
    97 as ::core::ffi::c_int as uint16_t,
    50 as ::core::ffi::c_int as uint16_t,
    187 as ::core::ffi::c_int as uint16_t,
    140 as ::core::ffi::c_int as uint16_t,
    277 as ::core::ffi::c_int as uint16_t,
    230 as ::core::ffi::c_int as uint16_t,
    367 as ::core::ffi::c_int as uint16_t,
    320 as ::core::ffi::c_int as uint16_t,
    89 as ::core::ffi::c_int as uint16_t,
    42 as ::core::ffi::c_int as uint16_t,
    179 as ::core::ffi::c_int as uint16_t,
    132 as ::core::ffi::c_int as uint16_t,
    269 as ::core::ffi::c_int as uint16_t,
    222 as ::core::ffi::c_int as uint16_t,
    359 as ::core::ffi::c_int as uint16_t,
    312 as ::core::ffi::c_int as uint16_t,
    81 as ::core::ffi::c_int as uint16_t,
    34 as ::core::ffi::c_int as uint16_t,
    171 as ::core::ffi::c_int as uint16_t,
    124 as ::core::ffi::c_int as uint16_t,
    261 as ::core::ffi::c_int as uint16_t,
    214 as ::core::ffi::c_int as uint16_t,
    351 as ::core::ffi::c_int as uint16_t,
    304 as ::core::ffi::c_int as uint16_t,
    73 as ::core::ffi::c_int as uint16_t,
    26 as ::core::ffi::c_int as uint16_t,
    163 as ::core::ffi::c_int as uint16_t,
    116 as ::core::ffi::c_int as uint16_t,
    253 as ::core::ffi::c_int as uint16_t,
    206 as ::core::ffi::c_int as uint16_t,
    343 as ::core::ffi::c_int as uint16_t,
    296 as ::core::ffi::c_int as uint16_t,
    65 as ::core::ffi::c_int as uint16_t,
    18 as ::core::ffi::c_int as uint16_t,
    155 as ::core::ffi::c_int as uint16_t,
    108 as ::core::ffi::c_int as uint16_t,
    245 as ::core::ffi::c_int as uint16_t,
    198 as ::core::ffi::c_int as uint16_t,
    335 as ::core::ffi::c_int as uint16_t,
    288 as ::core::ffi::c_int as uint16_t,
    57 as ::core::ffi::c_int as uint16_t,
    10 as ::core::ffi::c_int as uint16_t,
    147 as ::core::ffi::c_int as uint16_t,
    100 as ::core::ffi::c_int as uint16_t,
    237 as ::core::ffi::c_int as uint16_t,
    190 as ::core::ffi::c_int as uint16_t,
    327 as ::core::ffi::c_int as uint16_t,
    280 as ::core::ffi::c_int as uint16_t,
    49 as ::core::ffi::c_int as uint16_t,
    2 as ::core::ffi::c_int as uint16_t,
    139 as ::core::ffi::c_int as uint16_t,
    92 as ::core::ffi::c_int as uint16_t,
    229 as ::core::ffi::c_int as uint16_t,
    182 as ::core::ffi::c_int as uint16_t,
    319 as ::core::ffi::c_int as uint16_t,
    272 as ::core::ffi::c_int as uint16_t,
    41 as ::core::ffi::c_int as uint16_t,
    362 as ::core::ffi::c_int as uint16_t,
    131 as ::core::ffi::c_int as uint16_t,
    84 as ::core::ffi::c_int as uint16_t,
    221 as ::core::ffi::c_int as uint16_t,
    174 as ::core::ffi::c_int as uint16_t,
    311 as ::core::ffi::c_int as uint16_t,
    264 as ::core::ffi::c_int as uint16_t,
    33 as ::core::ffi::c_int as uint16_t,
    354 as ::core::ffi::c_int as uint16_t,
    123 as ::core::ffi::c_int as uint16_t,
    76 as ::core::ffi::c_int as uint16_t,
    213 as ::core::ffi::c_int as uint16_t,
    166 as ::core::ffi::c_int as uint16_t,
    303 as ::core::ffi::c_int as uint16_t,
    256 as ::core::ffi::c_int as uint16_t,
    25 as ::core::ffi::c_int as uint16_t,
    346 as ::core::ffi::c_int as uint16_t,
    115 as ::core::ffi::c_int as uint16_t,
    68 as ::core::ffi::c_int as uint16_t,
    205 as ::core::ffi::c_int as uint16_t,
    158 as ::core::ffi::c_int as uint16_t,
    295 as ::core::ffi::c_int as uint16_t,
    248 as ::core::ffi::c_int as uint16_t,
    17 as ::core::ffi::c_int as uint16_t,
    338 as ::core::ffi::c_int as uint16_t,
    107 as ::core::ffi::c_int as uint16_t,
    60 as ::core::ffi::c_int as uint16_t,
    197 as ::core::ffi::c_int as uint16_t,
    150 as ::core::ffi::c_int as uint16_t,
    287 as ::core::ffi::c_int as uint16_t,
    240 as ::core::ffi::c_int as uint16_t,
    9 as ::core::ffi::c_int as uint16_t,
    330 as ::core::ffi::c_int as uint16_t,
    99 as ::core::ffi::c_int as uint16_t,
    52 as ::core::ffi::c_int as uint16_t,
    189 as ::core::ffi::c_int as uint16_t,
    142 as ::core::ffi::c_int as uint16_t,
    279 as ::core::ffi::c_int as uint16_t,
    232 as ::core::ffi::c_int as uint16_t,
    1 as ::core::ffi::c_int as uint16_t,
    322 as ::core::ffi::c_int as uint16_t,
    91 as ::core::ffi::c_int as uint16_t,
    44 as ::core::ffi::c_int as uint16_t,
    181 as ::core::ffi::c_int as uint16_t,
    134 as ::core::ffi::c_int as uint16_t,
    271 as ::core::ffi::c_int as uint16_t,
    224 as ::core::ffi::c_int as uint16_t,
    361 as ::core::ffi::c_int as uint16_t,
    314 as ::core::ffi::c_int as uint16_t,
    83 as ::core::ffi::c_int as uint16_t,
    36 as ::core::ffi::c_int as uint16_t,
    173 as ::core::ffi::c_int as uint16_t,
    126 as ::core::ffi::c_int as uint16_t,
    263 as ::core::ffi::c_int as uint16_t,
    216 as ::core::ffi::c_int as uint16_t,
    353 as ::core::ffi::c_int as uint16_t,
    306 as ::core::ffi::c_int as uint16_t,
    75 as ::core::ffi::c_int as uint16_t,
    28 as ::core::ffi::c_int as uint16_t,
    165 as ::core::ffi::c_int as uint16_t,
    118 as ::core::ffi::c_int as uint16_t,
    255 as ::core::ffi::c_int as uint16_t,
    208 as ::core::ffi::c_int as uint16_t,
    345 as ::core::ffi::c_int as uint16_t,
    298 as ::core::ffi::c_int as uint16_t,
    67 as ::core::ffi::c_int as uint16_t,
    20 as ::core::ffi::c_int as uint16_t,
    157 as ::core::ffi::c_int as uint16_t,
    110 as ::core::ffi::c_int as uint16_t,
    247 as ::core::ffi::c_int as uint16_t,
    200 as ::core::ffi::c_int as uint16_t,
    337 as ::core::ffi::c_int as uint16_t,
    290 as ::core::ffi::c_int as uint16_t,
    59 as ::core::ffi::c_int as uint16_t,
    12 as ::core::ffi::c_int as uint16_t,
    149 as ::core::ffi::c_int as uint16_t,
    102 as ::core::ffi::c_int as uint16_t,
    239 as ::core::ffi::c_int as uint16_t,
    192 as ::core::ffi::c_int as uint16_t,
    329 as ::core::ffi::c_int as uint16_t,
    282 as ::core::ffi::c_int as uint16_t,
    51 as ::core::ffi::c_int as uint16_t,
    4 as ::core::ffi::c_int as uint16_t,
    141 as ::core::ffi::c_int as uint16_t,
    94 as ::core::ffi::c_int as uint16_t,
    231 as ::core::ffi::c_int as uint16_t,
    184 as ::core::ffi::c_int as uint16_t,
    321 as ::core::ffi::c_int as uint16_t,
    274 as ::core::ffi::c_int as uint16_t,
    43 as ::core::ffi::c_int as uint16_t,
    364 as ::core::ffi::c_int as uint16_t,
    133 as ::core::ffi::c_int as uint16_t,
    86 as ::core::ffi::c_int as uint16_t,
    223 as ::core::ffi::c_int as uint16_t,
    176 as ::core::ffi::c_int as uint16_t,
    313 as ::core::ffi::c_int as uint16_t,
    266 as ::core::ffi::c_int as uint16_t,
    35 as ::core::ffi::c_int as uint16_t,
    356 as ::core::ffi::c_int as uint16_t,
    125 as ::core::ffi::c_int as uint16_t,
    78 as ::core::ffi::c_int as uint16_t,
    215 as ::core::ffi::c_int as uint16_t,
    168 as ::core::ffi::c_int as uint16_t,
    305 as ::core::ffi::c_int as uint16_t,
    258 as ::core::ffi::c_int as uint16_t,
    27 as ::core::ffi::c_int as uint16_t,
    348 as ::core::ffi::c_int as uint16_t,
    117 as ::core::ffi::c_int as uint16_t,
    70 as ::core::ffi::c_int as uint16_t,
    207 as ::core::ffi::c_int as uint16_t,
    160 as ::core::ffi::c_int as uint16_t,
    297 as ::core::ffi::c_int as uint16_t,
    250 as ::core::ffi::c_int as uint16_t,
    19 as ::core::ffi::c_int as uint16_t,
    340 as ::core::ffi::c_int as uint16_t,
    109 as ::core::ffi::c_int as uint16_t,
    62 as ::core::ffi::c_int as uint16_t,
    199 as ::core::ffi::c_int as uint16_t,
    152 as ::core::ffi::c_int as uint16_t,
    289 as ::core::ffi::c_int as uint16_t,
    242 as ::core::ffi::c_int as uint16_t,
    11 as ::core::ffi::c_int as uint16_t,
    332 as ::core::ffi::c_int as uint16_t,
    101 as ::core::ffi::c_int as uint16_t,
    54 as ::core::ffi::c_int as uint16_t,
    191 as ::core::ffi::c_int as uint16_t,
    144 as ::core::ffi::c_int as uint16_t,
    281 as ::core::ffi::c_int as uint16_t,
    234 as ::core::ffi::c_int as uint16_t,
    3 as ::core::ffi::c_int as uint16_t,
    324 as ::core::ffi::c_int as uint16_t,
    93 as ::core::ffi::c_int as uint16_t,
    46 as ::core::ffi::c_int as uint16_t,
    183 as ::core::ffi::c_int as uint16_t,
    136 as ::core::ffi::c_int as uint16_t,
    273 as ::core::ffi::c_int as uint16_t,
    226 as ::core::ffi::c_int as uint16_t,
    363 as ::core::ffi::c_int as uint16_t,
    316 as ::core::ffi::c_int as uint16_t,
    85 as ::core::ffi::c_int as uint16_t,
    38 as ::core::ffi::c_int as uint16_t,
    175 as ::core::ffi::c_int as uint16_t,
    128 as ::core::ffi::c_int as uint16_t,
    265 as ::core::ffi::c_int as uint16_t,
    218 as ::core::ffi::c_int as uint16_t,
    355 as ::core::ffi::c_int as uint16_t,
    308 as ::core::ffi::c_int as uint16_t,
    77 as ::core::ffi::c_int as uint16_t,
    30 as ::core::ffi::c_int as uint16_t,
    167 as ::core::ffi::c_int as uint16_t,
    120 as ::core::ffi::c_int as uint16_t,
    257 as ::core::ffi::c_int as uint16_t,
    210 as ::core::ffi::c_int as uint16_t,
    347 as ::core::ffi::c_int as uint16_t,
    300 as ::core::ffi::c_int as uint16_t,
    69 as ::core::ffi::c_int as uint16_t,
    22 as ::core::ffi::c_int as uint16_t,
    159 as ::core::ffi::c_int as uint16_t,
    112 as ::core::ffi::c_int as uint16_t,
    249 as ::core::ffi::c_int as uint16_t,
    202 as ::core::ffi::c_int as uint16_t,
    339 as ::core::ffi::c_int as uint16_t,
    292 as ::core::ffi::c_int as uint16_t,
    61 as ::core::ffi::c_int as uint16_t,
    14 as ::core::ffi::c_int as uint16_t,
    151 as ::core::ffi::c_int as uint16_t,
    104 as ::core::ffi::c_int as uint16_t,
    241 as ::core::ffi::c_int as uint16_t,
    194 as ::core::ffi::c_int as uint16_t,
    331 as ::core::ffi::c_int as uint16_t,
    284 as ::core::ffi::c_int as uint16_t,
    53 as ::core::ffi::c_int as uint16_t,
    6 as ::core::ffi::c_int as uint16_t,
    143 as ::core::ffi::c_int as uint16_t,
    96 as ::core::ffi::c_int as uint16_t,
    233 as ::core::ffi::c_int as uint16_t,
    186 as ::core::ffi::c_int as uint16_t,
    323 as ::core::ffi::c_int as uint16_t,
    276 as ::core::ffi::c_int as uint16_t,
    45 as ::core::ffi::c_int as uint16_t,
    366 as ::core::ffi::c_int as uint16_t,
    135 as ::core::ffi::c_int as uint16_t,
    88 as ::core::ffi::c_int as uint16_t,
    225 as ::core::ffi::c_int as uint16_t,
    178 as ::core::ffi::c_int as uint16_t,
    315 as ::core::ffi::c_int as uint16_t,
    268 as ::core::ffi::c_int as uint16_t,
    37 as ::core::ffi::c_int as uint16_t,
    358 as ::core::ffi::c_int as uint16_t,
    127 as ::core::ffi::c_int as uint16_t,
    80 as ::core::ffi::c_int as uint16_t,
    217 as ::core::ffi::c_int as uint16_t,
    170 as ::core::ffi::c_int as uint16_t,
    307 as ::core::ffi::c_int as uint16_t,
    260 as ::core::ffi::c_int as uint16_t,
    29 as ::core::ffi::c_int as uint16_t,
    350 as ::core::ffi::c_int as uint16_t,
    119 as ::core::ffi::c_int as uint16_t,
    72 as ::core::ffi::c_int as uint16_t,
    209 as ::core::ffi::c_int as uint16_t,
    162 as ::core::ffi::c_int as uint16_t,
    299 as ::core::ffi::c_int as uint16_t,
    252 as ::core::ffi::c_int as uint16_t,
    21 as ::core::ffi::c_int as uint16_t,
    342 as ::core::ffi::c_int as uint16_t,
    111 as ::core::ffi::c_int as uint16_t,
    64 as ::core::ffi::c_int as uint16_t,
    201 as ::core::ffi::c_int as uint16_t,
    154 as ::core::ffi::c_int as uint16_t,
    291 as ::core::ffi::c_int as uint16_t,
    244 as ::core::ffi::c_int as uint16_t,
    13 as ::core::ffi::c_int as uint16_t,
    334 as ::core::ffi::c_int as uint16_t,
    103 as ::core::ffi::c_int as uint16_t,
    56 as ::core::ffi::c_int as uint16_t,
    193 as ::core::ffi::c_int as uint16_t,
    146 as ::core::ffi::c_int as uint16_t,
    283 as ::core::ffi::c_int as uint16_t,
    236 as ::core::ffi::c_int as uint16_t,
    5 as ::core::ffi::c_int as uint16_t,
    326 as ::core::ffi::c_int as uint16_t,
    95 as ::core::ffi::c_int as uint16_t,
    48 as ::core::ffi::c_int as uint16_t,
    185 as ::core::ffi::c_int as uint16_t,
    138 as ::core::ffi::c_int as uint16_t,
    275 as ::core::ffi::c_int as uint16_t,
    228 as ::core::ffi::c_int as uint16_t,
    365 as ::core::ffi::c_int as uint16_t,
    318 as ::core::ffi::c_int as uint16_t,
    87 as ::core::ffi::c_int as uint16_t,
    40 as ::core::ffi::c_int as uint16_t,
    177 as ::core::ffi::c_int as uint16_t,
    130 as ::core::ffi::c_int as uint16_t,
    267 as ::core::ffi::c_int as uint16_t,
    220 as ::core::ffi::c_int as uint16_t,
    357 as ::core::ffi::c_int as uint16_t,
    310 as ::core::ffi::c_int as uint16_t,
    79 as ::core::ffi::c_int as uint16_t,
    32 as ::core::ffi::c_int as uint16_t,
    169 as ::core::ffi::c_int as uint16_t,
    122 as ::core::ffi::c_int as uint16_t,
    259 as ::core::ffi::c_int as uint16_t,
    212 as ::core::ffi::c_int as uint16_t,
    349 as ::core::ffi::c_int as uint16_t,
    302 as ::core::ffi::c_int as uint16_t,
    71 as ::core::ffi::c_int as uint16_t,
    24 as ::core::ffi::c_int as uint16_t,
    161 as ::core::ffi::c_int as uint16_t,
    114 as ::core::ffi::c_int as uint16_t,
    251 as ::core::ffi::c_int as uint16_t,
    204 as ::core::ffi::c_int as uint16_t,
    341 as ::core::ffi::c_int as uint16_t,
    294 as ::core::ffi::c_int as uint16_t,
    63 as ::core::ffi::c_int as uint16_t,
    16 as ::core::ffi::c_int as uint16_t,
    153 as ::core::ffi::c_int as uint16_t,
    106 as ::core::ffi::c_int as uint16_t,
    243 as ::core::ffi::c_int as uint16_t,
    196 as ::core::ffi::c_int as uint16_t,
    333 as ::core::ffi::c_int as uint16_t,
    286 as ::core::ffi::c_int as uint16_t,
    55 as ::core::ffi::c_int as uint16_t,
    8 as ::core::ffi::c_int as uint16_t,
    145 as ::core::ffi::c_int as uint16_t,
    98 as ::core::ffi::c_int as uint16_t,
    235 as ::core::ffi::c_int as uint16_t,
    188 as ::core::ffi::c_int as uint16_t,
    325 as ::core::ffi::c_int as uint16_t,
    278 as ::core::ffi::c_int as uint16_t,
    47 as ::core::ffi::c_int as uint16_t,
];
#[no_mangle]
pub unsafe extern "C" fn reorder_bits(mut outp: *mut uint8_t, mut inp: *const uint8_t) {
    let mut i: uint16_t = 0 as uint16_t;
    while (i as ::core::ffi::c_int) < SYM_PER_PLD * 2 as ::core::ffi::c_int {
        *outp.offset(i as isize) = *inp.offset(intrl_seq[i as usize] as isize);
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn reorder_soft_bits(
    mut outp: *mut uint16_t,
    mut inp: *const uint16_t,
) {
    let mut i: uint16_t = 0 as uint16_t;
    while (i as ::core::ffi::c_int) < SYM_PER_PLD * 2 as ::core::ffi::c_int {
        *outp.offset(i as isize) = *inp.offset(intrl_seq[i as usize] as isize);
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub static mut rand_seq: [uint8_t; 46] = [
    0xd6 as ::core::ffi::c_int as uint8_t,
    0xb5 as ::core::ffi::c_int as uint8_t,
    0xe2 as ::core::ffi::c_int as uint8_t,
    0x30 as ::core::ffi::c_int as uint8_t,
    0x82 as ::core::ffi::c_int as uint8_t,
    0xff as ::core::ffi::c_int as uint8_t,
    0x84 as ::core::ffi::c_int as uint8_t,
    0x62 as ::core::ffi::c_int as uint8_t,
    0xba as ::core::ffi::c_int as uint8_t,
    0x4e as ::core::ffi::c_int as uint8_t,
    0x96 as ::core::ffi::c_int as uint8_t,
    0x90 as ::core::ffi::c_int as uint8_t,
    0xd8 as ::core::ffi::c_int as uint8_t,
    0x98 as ::core::ffi::c_int as uint8_t,
    0xdd as ::core::ffi::c_int as uint8_t,
    0x5d as ::core::ffi::c_int as uint8_t,
    0xc as ::core::ffi::c_int as uint8_t,
    0xc8 as ::core::ffi::c_int as uint8_t,
    0x52 as ::core::ffi::c_int as uint8_t,
    0x43 as ::core::ffi::c_int as uint8_t,
    0x91 as ::core::ffi::c_int as uint8_t,
    0x1d as ::core::ffi::c_int as uint8_t,
    0xf8 as ::core::ffi::c_int as uint8_t,
    0x6e as ::core::ffi::c_int as uint8_t,
    0x68 as ::core::ffi::c_int as uint8_t,
    0x2f as ::core::ffi::c_int as uint8_t,
    0x35 as ::core::ffi::c_int as uint8_t,
    0xda as ::core::ffi::c_int as uint8_t,
    0x14 as ::core::ffi::c_int as uint8_t,
    0xea as ::core::ffi::c_int as uint8_t,
    0xcd as ::core::ffi::c_int as uint8_t,
    0x76 as ::core::ffi::c_int as uint8_t,
    0x19 as ::core::ffi::c_int as uint8_t,
    0x8d as ::core::ffi::c_int as uint8_t,
    0xd5 as ::core::ffi::c_int as uint8_t,
    0x80 as ::core::ffi::c_int as uint8_t,
    0xd1 as ::core::ffi::c_int as uint8_t,
    0x33 as ::core::ffi::c_int as uint8_t,
    0x87 as ::core::ffi::c_int as uint8_t,
    0x13 as ::core::ffi::c_int as uint8_t,
    0x57 as ::core::ffi::c_int as uint8_t,
    0x18 as ::core::ffi::c_int as uint8_t,
    0x2d as ::core::ffi::c_int as uint8_t,
    0x29 as ::core::ffi::c_int as uint8_t,
    0x78 as ::core::ffi::c_int as uint8_t,
    0xc3 as ::core::ffi::c_int as uint8_t,
];
#[no_mangle]
pub unsafe extern "C" fn randomize_bits(mut inp: *mut uint8_t) {
    let mut i: uint16_t = 0 as uint16_t;
    while (i as ::core::ffi::c_int) < SYM_PER_PLD * 2 as ::core::ffi::c_int {
        if rand_seq[(i as ::core::ffi::c_int / 8 as ::core::ffi::c_int) as usize]
            as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int
                - i as ::core::ffi::c_int % 8 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int != 0
        {
            if *inp.offset(i as isize) != 0 {
                *inp.offset(i as isize) = 0 as uint8_t;
            } else {
                *inp.offset(i as isize) = 1 as uint8_t;
            }
        }
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn randomize_soft_bits(mut inp: *mut uint16_t) {
    let mut i: uint16_t = 0 as uint16_t;
    while (i as ::core::ffi::c_int) < SYM_PER_PLD * 2 as ::core::ffi::c_int {
        if rand_seq[(i as ::core::ffi::c_int / 8 as ::core::ffi::c_int) as usize]
            as ::core::ffi::c_int
            >> 7 as ::core::ffi::c_int
                - i as ::core::ffi::c_int % 8 as ::core::ffi::c_int
            & 1 as ::core::ffi::c_int != 0
        {
            *inp.offset(i as isize) = soft_bit_NOT(*inp.offset(i as isize));
        }
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn slice_symbols(
    mut out: *mut uint16_t,
    mut inp: *const ::core::ffi::c_float,
) {
    let mut i: uint8_t = 0 as uint8_t;
    while (i as ::core::ffi::c_int) < SYM_PER_PLD {
        if *inp.offset(i as isize)
            >= symbol_list[3 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
                as ::core::ffi::c_float
        {
            *out
                .offset(
                    (i as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                        + 1 as ::core::ffi::c_int) as isize,
                ) = 0xffff as uint16_t;
        } else if *inp.offset(i as isize)
            >= symbol_list[2 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
                as ::core::ffi::c_float
        {
            *out
                .offset(
                    (i as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                        + 1 as ::core::ffi::c_int) as isize,
                ) = (-(0xffff as ::core::ffi::c_int as ::core::ffi::c_float)
                / (symbol_list[3 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
                    - symbol_list[2 as ::core::ffi::c_int as usize]
                        as ::core::ffi::c_int) as ::core::ffi::c_float
                * symbol_list[2 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
                    as ::core::ffi::c_float
                + *inp.offset(i as isize)
                    * 0xffff as ::core::ffi::c_int as ::core::ffi::c_float
                    / (symbol_list[3 as ::core::ffi::c_int as usize]
                        as ::core::ffi::c_int
                        - symbol_list[2 as ::core::ffi::c_int as usize]
                            as ::core::ffi::c_int) as ::core::ffi::c_float) as uint16_t;
        } else if *inp.offset(i as isize)
            >= symbol_list[1 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
                as ::core::ffi::c_float
        {
            *out
                .offset(
                    (i as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                        + 1 as ::core::ffi::c_int) as isize,
                ) = 0 as uint16_t;
        } else if *inp.offset(i as isize)
            >= symbol_list[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
                as ::core::ffi::c_float
        {
            *out
                .offset(
                    (i as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                        + 1 as ::core::ffi::c_int) as isize,
                ) = (0xffff as ::core::ffi::c_int as ::core::ffi::c_float
                / (symbol_list[1 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
                    - symbol_list[0 as ::core::ffi::c_int as usize]
                        as ::core::ffi::c_int) as ::core::ffi::c_float
                * symbol_list[1 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
                    as ::core::ffi::c_float
                - *inp.offset(i as isize)
                    * 0xffff as ::core::ffi::c_int as ::core::ffi::c_float
                    / (symbol_list[1 as ::core::ffi::c_int as usize]
                        as ::core::ffi::c_int
                        - symbol_list[0 as ::core::ffi::c_int as usize]
                            as ::core::ffi::c_int) as ::core::ffi::c_float) as uint16_t;
        } else {
            *out
                .offset(
                    (i as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                        + 1 as ::core::ffi::c_int) as isize,
                ) = 0xffff as uint16_t;
        }
        if *inp.offset(i as isize)
            >= symbol_list[2 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
                as ::core::ffi::c_float
        {
            *out.offset((i as ::core::ffi::c_int * 2 as ::core::ffi::c_int) as isize) = 0
                as uint16_t;
        } else if *inp.offset(i as isize)
            >= symbol_list[1 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
                as ::core::ffi::c_float
        {
            *out.offset((i as ::core::ffi::c_int * 2 as ::core::ffi::c_int) as isize) = (0x7fff
                as ::core::ffi::c_int as ::core::ffi::c_float
                - *inp.offset(i as isize)
                    * 0xffff as ::core::ffi::c_int as ::core::ffi::c_float
                    / (symbol_list[2 as ::core::ffi::c_int as usize]
                        as ::core::ffi::c_int
                        - symbol_list[1 as ::core::ffi::c_int as usize]
                            as ::core::ffi::c_int) as ::core::ffi::c_float) as uint16_t;
        } else {
            *out.offset((i as ::core::ffi::c_int * 2 as ::core::ffi::c_int) as isize) = 0xffff
                as uint16_t;
        }
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub static mut SYNC_LSF: uint16_t = 0x55f7 as uint16_t;
#[no_mangle]
pub static mut SYNC_STR: uint16_t = 0xff5d as uint16_t;
#[no_mangle]
pub static mut SYNC_PKT: uint16_t = 0x75ff as uint16_t;
#[no_mangle]
pub static mut SYNC_BER: uint16_t = 0xdf55 as uint16_t;
#[no_mangle]
pub static mut EOT_MRKR: uint16_t = 0x555d as uint16_t;
