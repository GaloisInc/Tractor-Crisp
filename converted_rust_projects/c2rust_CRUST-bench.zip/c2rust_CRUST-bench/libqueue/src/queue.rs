#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
}
pub type __darwin_size_t = usize;
pub type u_int32_t = ::core::ffi::c_uint;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct queue_node_t {
    pub value: *mut ::core::ffi::c_void,
    pub next: *mut queue_node_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct queue_t {
    pub size: u_int32_t,
    pub head: *mut queue_node_t,
    pub tail: *mut queue_node_t,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn queue_new(mut queue: *mut queue_t) {
    (*queue).head = 0 as *mut queue_node_t;
    (*queue).tail = 0 as *mut queue_node_t;
    (*queue).size = 0 as u_int32_t;
}
#[no_mangle]
pub unsafe extern "C" fn queue_empty(mut queue: *mut queue_t) -> bool {
    return (*queue).size == 0 as u_int32_t;
}
#[no_mangle]
pub unsafe extern "C" fn queue_push(
    mut queue: *mut queue_t,
    mut value: *mut ::core::ffi::c_void,
) {
    let mut new_node: *mut queue_node_t = malloc(
        ::core::mem::size_of::<queue_node_t>() as size_t,
    ) as *mut queue_node_t;
    (*new_node).value = value;
    (*new_node).next = 0 as *mut queue_node_t;
    if queue_empty(queue) {
        (*queue).tail = new_node;
        (*queue).head = new_node;
    } else {
        (*(*queue).tail).next = new_node as *mut queue_node_t;
        (*queue).tail = new_node;
    }
    (*queue).size = (*queue).size.wrapping_add(1);
}
#[no_mangle]
pub unsafe extern "C" fn queue_pop(mut queue: *mut queue_t) -> *mut ::core::ffi::c_void {
    if queue.is_null() || queue_empty(queue) as ::core::ffi::c_int != 0 {
        return NULL;
    }
    let mut elem: *mut queue_node_t = (*queue).head;
    (*queue).head = (*(*queue).head).next as *mut queue_node_t;
    let mut value: *mut ::core::ffi::c_void = (*elem).value;
    if (*queue).size == 1 as u_int32_t {
        (*queue).tail = 0 as *mut queue_node_t;
    }
    (*queue).size = (*queue).size.wrapping_sub(1);
    free(elem as *mut ::core::ffi::c_void);
    return value;
}
#[no_mangle]
pub unsafe extern "C" fn queue_front(
    mut queue: *mut queue_t,
) -> *mut ::core::ffi::c_void {
    if queue.is_null() {
        return NULL;
    }
    if queue_empty(queue) {
        return NULL;
    }
    return (*(*queue).head).value;
}
#[no_mangle]
pub unsafe extern "C" fn queue_back(
    mut queue: *mut queue_t,
) -> *mut ::core::ffi::c_void {
    if queue.is_null() {
        return NULL;
    }
    if queue_empty(queue) {
        return NULL;
    }
    return (*(*queue).tail).value;
}
#[no_mangle]
pub unsafe extern "C" fn queue_free(mut queue: *mut queue_t) {
    let mut temp: *mut queue_node_t = (*queue).head;
    let mut temp2: *mut queue_node_t = 0 as *mut queue_node_t;
    while !temp.is_null() {
        temp2 = temp;
        temp = (*temp).next as *mut queue_node_t;
        free(temp2 as *mut ::core::ffi::c_void);
    }
}
