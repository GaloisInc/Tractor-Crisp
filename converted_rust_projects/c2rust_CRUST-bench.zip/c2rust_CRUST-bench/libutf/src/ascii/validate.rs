#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint64_t = u64;
pub type ascii_t = ::core::ffi::c_uchar;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn ascii_validate(
    mut data: *const ascii_t,
    mut len: size_t,
) -> bool {
    let mut pos: uint64_t = 0 as uint64_t;
    while pos.wrapping_add(16 as uint64_t) <= len as uint64_t {
        let mut v1: uint64_t = 0;
        memcpy(
            &mut v1 as *mut uint64_t as *mut ::core::ffi::c_void,
            data.offset(pos as isize) as *const ::core::ffi::c_void,
            ::core::mem::size_of::<uint64_t>() as size_t,
        );
        let mut v2: uint64_t = 0;
        memcpy(
            &mut v2 as *mut uint64_t as *mut ::core::ffi::c_void,
            data
                .offset(pos as isize)
                .offset(::core::mem::size_of::<uint64_t>() as usize as isize)
                as *const ::core::ffi::c_void,
            ::core::mem::size_of::<uint64_t>() as size_t,
        );
        let mut v: uint64_t = v1 | v2;
        if v & 0x8080808080808080 as uint64_t != 0 as uint64_t {
            return false_0 != 0;
        }
        pos = pos.wrapping_add(16 as uint64_t);
    }
    while pos < len as uint64_t {
        if *data.offset(pos as isize) as ::core::ffi::c_int
            >= 0o200 as ::core::ffi::c_int
        {
            return false_0 != 0;
        }
        pos = pos.wrapping_add(1);
    }
    return true_0 != 0;
}
