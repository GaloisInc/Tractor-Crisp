#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint_least16_t = uint16_t;
pub type utf16_t = uint_least16_t;
pub type latin1_t = ::core::ffi::c_uchar;
pub const utf_be: utf_endianness_t = 1;
pub type utf_endianness_t = ::core::ffi::c_uint;
pub const utf_le: utf_endianness_t = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed {
    pub u8_0: [uint8_t; 2],
    pub u16_0: uint16_t,
}
#[inline]
unsafe extern "C" fn utf_endianness() -> utf_endianness_t {
    let byte_order: C2RustUnnamed = C2RustUnnamed {
        u8_0: [1 as ::core::ffi::c_int as uint8_t, 0 as ::core::ffi::c_int as uint8_t],
    };
    return (if byte_order.u16_0 as ::core::ffi::c_int == 1 as ::core::ffi::c_int {
        utf_le as ::core::ffi::c_int
    } else {
        utf_be as ::core::ffi::c_int
    }) as utf_endianness_t;
}
#[inline]
unsafe extern "C" fn utf_is_be() -> bool {
    return utf_endianness() as ::core::ffi::c_uint
        == utf_be as ::core::ffi::c_int as ::core::ffi::c_uint;
}
#[inline]
unsafe extern "C" fn utf_swap_uint16(mut n: uint16_t) -> uint16_t {
    return ((n as ::core::ffi::c_int & 0xff as ::core::ffi::c_int)
        << 8 as ::core::ffi::c_int
        | (n as ::core::ffi::c_int & 0xff00 as ::core::ffi::c_int)
            >> 8 as ::core::ffi::c_int) as uint16_t;
}
#[no_mangle]
pub unsafe extern "C" fn utf16le_convert_to_latin1(
    mut data: *const utf16_t,
    mut len: size_t,
    mut result: *mut latin1_t,
) -> size_t {
    let mut pos: size_t = 0 as size_t;
    let mut word: uint16_t = 0;
    let mut overflow: uint16_t = 0 as uint16_t;
    let mut start: *mut latin1_t = result;
    while pos < len {
        word = (if utf_is_be() as ::core::ffi::c_int != 0 {
            utf_swap_uint16(*data.offset(pos as isize)) as ::core::ffi::c_int
        } else {
            *data.offset(pos as isize) as ::core::ffi::c_int
        }) as uint16_t;
        overflow = (overflow as ::core::ffi::c_int | word as ::core::ffi::c_int)
            as uint16_t;
        let fresh0 = result;
        result = result.offset(1);
        *fresh0 = (word as ::core::ffi::c_int & 0xff as ::core::ffi::c_int) as latin1_t;
        pos = pos.wrapping_add(1);
    }
    if overflow as ::core::ffi::c_int & 0xff00 as ::core::ffi::c_int != 0 {
        return 0 as size_t;
    }
    return result.offset_from(start) as ::core::ffi::c_long as size_t;
}
