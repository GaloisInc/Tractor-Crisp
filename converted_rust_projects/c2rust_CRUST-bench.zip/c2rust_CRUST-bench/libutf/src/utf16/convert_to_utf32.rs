#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint_least16_t = uint16_t;
pub type uint_least32_t = uint32_t;
pub type utf16_t = uint_least16_t;
pub type utf32_t = uint_least32_t;
pub const utf_be: utf_endianness_t = 1;
pub type utf_endianness_t = ::core::ffi::c_uint;
pub const utf_le: utf_endianness_t = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed {
    pub u8_0: [uint8_t; 2],
    pub u16_0: uint16_t,
}
#[inline]
unsafe extern "C" fn utf_endianness() -> utf_endianness_t {
    let byte_order: C2RustUnnamed = C2RustUnnamed {
        u8_0: [1 as ::core::ffi::c_int as uint8_t, 0 as ::core::ffi::c_int as uint8_t],
    };
    return (if byte_order.u16_0 as ::core::ffi::c_int == 1 as ::core::ffi::c_int {
        utf_le as ::core::ffi::c_int
    } else {
        utf_be as ::core::ffi::c_int
    }) as utf_endianness_t;
}
#[inline]
unsafe extern "C" fn utf_is_be() -> bool {
    return utf_endianness() as ::core::ffi::c_uint
        == utf_be as ::core::ffi::c_int as ::core::ffi::c_uint;
}
#[inline]
unsafe extern "C" fn utf_swap_uint16(mut n: uint16_t) -> uint16_t {
    return ((n as ::core::ffi::c_int & 0xff as ::core::ffi::c_int)
        << 8 as ::core::ffi::c_int
        | (n as ::core::ffi::c_int & 0xff00 as ::core::ffi::c_int)
            >> 8 as ::core::ffi::c_int) as uint16_t;
}
#[no_mangle]
pub unsafe extern "C" fn utf16le_convert_to_utf32(
    mut data: *const utf16_t,
    mut len: size_t,
    mut result: *mut utf32_t,
) -> size_t {
    let mut pos: size_t = 0 as size_t;
    let mut word: uint16_t = 0;
    let mut diff: uint16_t = 0;
    let mut start: *mut utf32_t = result;
    while pos < len {
        word = (if utf_is_be() as ::core::ffi::c_int != 0 {
            utf_swap_uint16(*data.offset(pos as isize)) as ::core::ffi::c_int
        } else {
            *data.offset(pos as isize) as ::core::ffi::c_int
        }) as uint16_t;
        if word as ::core::ffi::c_int & 0xf800 as ::core::ffi::c_int
            != 0xd800 as ::core::ffi::c_int
        {
            let fresh0 = result;
            result = result.offset(1);
            *fresh0 = word as utf32_t;
            pos = pos.wrapping_add(1);
        } else {
            diff = (word as ::core::ffi::c_int - 0xd800 as ::core::ffi::c_int)
                as uint16_t;
            if diff as ::core::ffi::c_int > 0x3ff as ::core::ffi::c_int {
                return 0 as size_t;
            }
            if pos.wrapping_add(1 as size_t) >= len {
                return 0 as size_t;
            }
            word = (if utf_is_be() as ::core::ffi::c_int != 0 {
                utf_swap_uint16(*data.offset(pos.wrapping_add(1 as size_t) as isize))
                    as ::core::ffi::c_int
            } else {
                *data.offset(pos.wrapping_add(1 as size_t) as isize)
                    as ::core::ffi::c_int
            }) as uint16_t;
            let mut value: uint32_t = (((diff as ::core::ffi::c_int)
                << 10 as ::core::ffi::c_int)
                + (word as ::core::ffi::c_int - 0xdc00 as ::core::ffi::c_int)
                + 0x10000 as ::core::ffi::c_int) as uint32_t;
            diff = (word as ::core::ffi::c_int - 0xdc00 as ::core::ffi::c_int)
                as uint16_t;
            if diff as ::core::ffi::c_int > 0x3ff as ::core::ffi::c_int {
                return 0 as size_t;
            }
            let fresh1 = result;
            result = result.offset(1);
            *fresh1 = value as utf32_t;
            pos = pos.wrapping_add(2 as size_t);
        }
    }
    return result.offset_from(start) as ::core::ffi::c_long as size_t;
}
