#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uint_least16_t = uint16_t;
pub type utf8_t = ::core::ffi::c_uchar;
pub type utf16_t = uint_least16_t;
pub const utf_be: utf_endianness_t = 1;
pub type utf_endianness_t = ::core::ffi::c_uint;
pub const utf_le: utf_endianness_t = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed {
    pub u8_0: [uint8_t; 2],
    pub u16_0: uint16_t,
}
#[inline]
unsafe extern "C" fn utf_endianness() -> utf_endianness_t {
    let byte_order: C2RustUnnamed = C2RustUnnamed {
        u8_0: [1 as ::core::ffi::c_int as uint8_t, 0 as ::core::ffi::c_int as uint8_t],
    };
    return (if byte_order.u16_0 as ::core::ffi::c_int == 1 as ::core::ffi::c_int {
        utf_le as ::core::ffi::c_int
    } else {
        utf_be as ::core::ffi::c_int
    }) as utf_endianness_t;
}
#[inline]
unsafe extern "C" fn utf_is_be() -> bool {
    return utf_endianness() as ::core::ffi::c_uint
        == utf_be as ::core::ffi::c_int as ::core::ffi::c_uint;
}
#[inline]
unsafe extern "C" fn utf_swap_uint16(mut n: uint16_t) -> uint16_t {
    return ((n as ::core::ffi::c_int & 0xff as ::core::ffi::c_int)
        << 8 as ::core::ffi::c_int
        | (n as ::core::ffi::c_int & 0xff00 as ::core::ffi::c_int)
            >> 8 as ::core::ffi::c_int) as uint16_t;
}
#[no_mangle]
pub unsafe extern "C" fn utf16le_convert_to_utf8(
    mut data: *const utf16_t,
    mut len: size_t,
    mut result: *mut utf8_t,
) -> size_t {
    let mut pos: size_t = 0 as size_t;
    let mut word: uint16_t = 0;
    let mut diff: uint16_t = 0;
    let mut start: *mut utf8_t = result;
    while pos < len {
        if pos.wrapping_add(4 as size_t) <= len {
            let mut v: uint64_t = 0;
            memcpy(
                &mut v as *mut uint64_t as *mut ::core::ffi::c_void,
                data.offset(pos as isize) as *const ::core::ffi::c_void,
                ::core::mem::size_of::<uint64_t>() as size_t,
            );
            if utf_is_be() {
                v = v >> 8 as ::core::ffi::c_int
                    | v << 64 as ::core::ffi::c_int - 8 as ::core::ffi::c_int;
            }
            if v & 0xff80ff80ff80ff80 as uint64_t == 0 as uint64_t {
                let mut final_pos: size_t = pos.wrapping_add(4 as size_t);
                while pos < final_pos {
                    let fresh0 = result;
                    result = result.offset(1);
                    *fresh0 = (if utf_is_be() as ::core::ffi::c_int != 0 {
                        utf_swap_uint16(*data.offset(pos as isize)) as ::core::ffi::c_int
                    } else {
                        *data.offset(pos as isize) as ::core::ffi::c_int
                    }) as utf8_t;
                    pos = pos.wrapping_add(1);
                }
                continue;
            }
        }
        word = (if utf_is_be() as ::core::ffi::c_int != 0 {
            utf_swap_uint16(*data.offset(pos as isize)) as ::core::ffi::c_int
        } else {
            *data.offset(pos as isize) as ::core::ffi::c_int
        }) as uint16_t;
        if word as ::core::ffi::c_int & 0xff80 as ::core::ffi::c_int
            == 0 as ::core::ffi::c_int
        {
            let fresh1 = result;
            result = result.offset(1);
            *fresh1 = word as utf8_t;
            pos = pos.wrapping_add(1);
        } else if word as ::core::ffi::c_int & 0xf800 as ::core::ffi::c_int
            == 0 as ::core::ffi::c_int
        {
            let fresh2 = result;
            result = result.offset(1);
            *fresh2 = (word as ::core::ffi::c_int >> 6 as ::core::ffi::c_int
                | 0o300 as ::core::ffi::c_int) as utf8_t;
            let fresh3 = result;
            result = result.offset(1);
            *fresh3 = (word as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int
                | 0o200 as ::core::ffi::c_int) as utf8_t;
            pos = pos.wrapping_add(1);
        } else if word as ::core::ffi::c_int & 0xf800 as ::core::ffi::c_int
            != 0xd800 as ::core::ffi::c_int
        {
            let fresh4 = result;
            result = result.offset(1);
            *fresh4 = (word as ::core::ffi::c_int >> 12 as ::core::ffi::c_int
                | 0o340 as ::core::ffi::c_int) as utf8_t;
            let fresh5 = result;
            result = result.offset(1);
            *fresh5 = (word as ::core::ffi::c_int >> 6 as ::core::ffi::c_int
                & 0o77 as ::core::ffi::c_int | 0o200 as ::core::ffi::c_int) as utf8_t;
            let fresh6 = result;
            result = result.offset(1);
            *fresh6 = (word as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int
                | 0o200 as ::core::ffi::c_int) as utf8_t;
            pos = pos.wrapping_add(1);
        } else {
            diff = (word as ::core::ffi::c_int - 0xd800 as ::core::ffi::c_int)
                as uint16_t;
            if pos.wrapping_add(1 as size_t) >= len {
                return 0 as size_t;
            }
            word = (if utf_is_be() as ::core::ffi::c_int != 0 {
                utf_swap_uint16(*data.offset(pos.wrapping_add(1 as size_t) as isize))
                    as ::core::ffi::c_int
            } else {
                *data.offset(pos.wrapping_add(1 as size_t) as isize)
                    as ::core::ffi::c_int
            }) as uint16_t;
            let mut value: uint32_t = (((diff as ::core::ffi::c_int)
                << 10 as ::core::ffi::c_int)
                + (word as ::core::ffi::c_int - 0xdc00 as ::core::ffi::c_int)
                + 0x10000 as ::core::ffi::c_int) as uint32_t;
            let fresh7 = result;
            result = result.offset(1);
            *fresh7 = (value >> 18 as ::core::ffi::c_int | 0o360 as uint32_t) as utf8_t;
            let fresh8 = result;
            result = result.offset(1);
            *fresh8 = (value >> 12 as ::core::ffi::c_int & 0o77 as uint32_t
                | 0o200 as uint32_t) as utf8_t;
            let fresh9 = result;
            result = result.offset(1);
            *fresh9 = (value >> 6 as ::core::ffi::c_int & 0o77 as uint32_t
                | 0o200 as uint32_t) as utf8_t;
            let fresh10 = result;
            result = result.offset(1);
            *fresh10 = (value & 0o77 as uint32_t | 0o200 as uint32_t) as utf8_t;
            pos = pos.wrapping_add(2 as size_t);
        }
    }
    return result.offset_from(start) as ::core::ffi::c_long as size_t;
}
