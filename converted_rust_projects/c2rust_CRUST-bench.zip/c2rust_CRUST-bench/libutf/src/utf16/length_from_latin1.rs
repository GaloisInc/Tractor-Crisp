#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type utf8_t = ::core::ffi::c_uchar;
pub type latin1_t = ::core::ffi::c_uchar;
#[no_mangle]
pub unsafe extern "C" fn utf16_length_from_latin1(
    mut data: *const utf8_t,
    mut len: size_t,
) -> size_t {
    return len;
}
