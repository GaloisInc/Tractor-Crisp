#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint32_t = u32;
pub type uint_least32_t = uint32_t;
pub type utf32_t = uint_least32_t;
#[no_mangle]
pub unsafe extern "C" fn utf16_length_from_utf32(
    mut data: *const utf32_t,
    mut len: size_t,
) -> size_t {
    let mut counter: size_t = 0 as size_t;
    let mut i: size_t = 0 as size_t;
    while i < len {
        counter = counter.wrapping_add(1);
        counter = counter
            .wrapping_add(
                (*data.offset(i as isize) > 0xffff as utf32_t) as ::core::ffi::c_int
                    as size_t,
            );
        i = i.wrapping_add(1);
    }
    return counter;
}
