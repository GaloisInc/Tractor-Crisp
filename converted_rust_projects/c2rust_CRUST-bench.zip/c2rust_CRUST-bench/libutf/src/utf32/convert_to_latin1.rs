#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint32_t = u32;
pub type uint_least32_t = uint32_t;
pub type utf32_t = uint_least32_t;
pub type latin1_t = ::core::ffi::c_uchar;
#[no_mangle]
pub unsafe extern "C" fn utf32_convert_to_latin1(
    mut data: *const utf32_t,
    mut len: size_t,
    mut result: *mut latin1_t,
) -> size_t {
    let mut pos: size_t = 0 as size_t;
    let mut word: uint32_t = 0;
    let mut overflow: uint32_t = 0 as uint32_t;
    let mut start: *mut latin1_t = result;
    while pos < len {
        word = *data.offset(pos as isize) as uint32_t;
        overflow |= word;
        let fresh0 = result;
        result = result.offset(1);
        *fresh0 = (word & 0xff as uint32_t) as latin1_t;
        pos = pos.wrapping_add(1);
    }
    if overflow & 0xffffff00 as uint32_t != 0 {
        return 0 as size_t;
    }
    return result.offset_from(start) as ::core::ffi::c_long as size_t;
}
