#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint_least16_t = uint16_t;
pub type uint_least32_t = uint32_t;
pub type utf16_t = uint_least16_t;
pub type utf32_t = uint_least32_t;
pub const utf_be: utf_endianness_t = 1;
pub type utf_endianness_t = ::core::ffi::c_uint;
pub const utf_le: utf_endianness_t = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed {
    pub u8_0: [uint8_t; 2],
    pub u16_0: uint16_t,
}
#[inline]
unsafe extern "C" fn utf_endianness() -> utf_endianness_t {
    let byte_order: C2RustUnnamed = C2RustUnnamed {
        u8_0: [1 as ::core::ffi::c_int as uint8_t, 0 as ::core::ffi::c_int as uint8_t],
    };
    return (if byte_order.u16_0 as ::core::ffi::c_int == 1 as ::core::ffi::c_int {
        utf_le as ::core::ffi::c_int
    } else {
        utf_be as ::core::ffi::c_int
    }) as utf_endianness_t;
}
#[inline]
unsafe extern "C" fn utf_is_be() -> bool {
    return utf_endianness() as ::core::ffi::c_uint
        == utf_be as ::core::ffi::c_int as ::core::ffi::c_uint;
}
#[inline]
unsafe extern "C" fn utf_swap_uint16(mut n: uint16_t) -> uint16_t {
    return ((n as ::core::ffi::c_int & 0xff as ::core::ffi::c_int)
        << 8 as ::core::ffi::c_int
        | (n as ::core::ffi::c_int & 0xff00 as ::core::ffi::c_int)
            >> 8 as ::core::ffi::c_int) as uint16_t;
}
#[no_mangle]
pub unsafe extern "C" fn utf32_convert_to_utf16le(
    mut data: *const utf32_t,
    mut len: size_t,
    mut result: *mut utf16_t,
) -> size_t {
    let mut pos: size_t = 0 as size_t;
    let mut word: uint32_t = 0;
    let mut start: *mut utf16_t = result;
    while pos < len {
        word = *data.offset(pos as isize) as uint32_t;
        if word & 0xffff0000 as uint32_t == 0 as uint32_t {
            if word >= 0xd800 as uint32_t && word <= 0xdfff as uint32_t {
                return 0 as size_t;
            }
            let fresh0 = result;
            result = result.offset(1);
            *fresh0 = (if utf_is_be() as ::core::ffi::c_int != 0 {
                utf_swap_uint16(*data.offset(pos as isize) as uint16_t) as utf32_t
            } else {
                *data.offset(pos as isize)
            }) as utf16_t;
        } else {
            if word > 0x10ffff as uint32_t {
                return 0 as size_t;
            }
            word = word.wrapping_sub(0x10000 as uint32_t);
            let mut high_surrogate: uint16_t = (0xd800 as uint32_t)
                .wrapping_add(word >> 10 as ::core::ffi::c_int) as uint16_t;
            let mut low_surrogate: uint16_t = (0xdc00 as uint32_t)
                .wrapping_add(word & 0x3ff as uint32_t) as uint16_t;
            if utf_is_be() {
                high_surrogate = utf_swap_uint16(high_surrogate);
                low_surrogate = utf_swap_uint16(low_surrogate);
            }
            let fresh1 = result;
            result = result.offset(1);
            *fresh1 = high_surrogate as utf16_t;
            let fresh2 = result;
            result = result.offset(1);
            *fresh2 = low_surrogate as utf16_t;
        }
        pos = pos.wrapping_add(1);
    }
    return result.offset_from(start) as ::core::ffi::c_long as size_t;
}
