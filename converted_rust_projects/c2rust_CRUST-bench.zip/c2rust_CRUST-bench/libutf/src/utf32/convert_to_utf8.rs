#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uint_least32_t = uint32_t;
pub type utf8_t = ::core::ffi::c_uchar;
pub type utf32_t = uint_least32_t;
#[no_mangle]
pub unsafe extern "C" fn utf32_convert_to_utf8(
    mut data: *const utf32_t,
    mut len: size_t,
    mut result: *mut utf8_t,
) -> size_t {
    let mut pos: size_t = 0 as size_t;
    let mut word: uint32_t = 0;
    let mut start: *mut utf8_t = result;
    while pos < len {
        if pos.wrapping_add(2 as size_t) <= len {
            let mut v: uint64_t = 0;
            memcpy(
                &mut v as *mut uint64_t as *mut ::core::ffi::c_void,
                data.offset(pos as isize) as *const ::core::ffi::c_void,
                ::core::mem::size_of::<uint64_t>() as size_t,
            );
            if v & 0xffffff80ffffff80 as uint64_t == 0 as uint64_t {
                let fresh0 = result;
                result = result.offset(1);
                *fresh0 = *data.offset(pos as isize) as utf8_t;
                let fresh1 = result;
                result = result.offset(1);
                *fresh1 = *data.offset(pos.wrapping_add(1 as size_t) as isize) as utf8_t;
                pos = pos.wrapping_add(2 as size_t);
                continue;
            }
        }
        word = *data.offset(pos as isize) as uint32_t;
        if word & 0xffffff80 as uint32_t == 0 as uint32_t {
            let fresh2 = result;
            result = result.offset(1);
            *fresh2 = word as utf8_t;
            pos = pos.wrapping_add(1);
        } else if word & 0xfffff800 as uint32_t == 0 as uint32_t {
            let fresh3 = result;
            result = result.offset(1);
            *fresh3 = (word >> 6 as ::core::ffi::c_int | 0o300 as uint32_t) as utf8_t;
            let fresh4 = result;
            result = result.offset(1);
            *fresh4 = (word & 0o77 as uint32_t | 0o200 as uint32_t) as utf8_t;
            pos = pos.wrapping_add(1);
        } else if word & 0xffff0000 as uint32_t == 0 as uint32_t {
            if word >= 0xd800 as uint32_t && word <= 0xdfff as uint32_t {
                return 0 as size_t;
            }
            let fresh5 = result;
            result = result.offset(1);
            *fresh5 = (word >> 12 as ::core::ffi::c_int | 0o340 as uint32_t) as utf8_t;
            let fresh6 = result;
            result = result.offset(1);
            *fresh6 = (word >> 6 as ::core::ffi::c_int & 0o77 as uint32_t
                | 0o200 as uint32_t) as utf8_t;
            let fresh7 = result;
            result = result.offset(1);
            *fresh7 = (word & 0o77 as uint32_t | 0o200 as uint32_t) as utf8_t;
            pos = pos.wrapping_add(1);
        } else {
            if word > 0x10ffff as uint32_t {
                return 0 as size_t;
            }
            let fresh8 = result;
            result = result.offset(1);
            *fresh8 = (word >> 18 as ::core::ffi::c_int | 0o360 as uint32_t) as utf8_t;
            let fresh9 = result;
            result = result.offset(1);
            *fresh9 = (word >> 12 as ::core::ffi::c_int & 0o77 as uint32_t
                | 0o200 as uint32_t) as utf8_t;
            let fresh10 = result;
            result = result.offset(1);
            *fresh10 = (word >> 6 as ::core::ffi::c_int & 0o77 as uint32_t
                | 0o200 as uint32_t) as utf8_t;
            let fresh11 = result;
            result = result.offset(1);
            *fresh11 = (word & 0o77 as uint32_t | 0o200 as uint32_t) as utf8_t;
            pos = pos.wrapping_add(1);
        }
    }
    return result.offset_from(start) as ::core::ffi::c_long as size_t;
}
