#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
pub type __darwin_size_t = usize;
pub type int8_t = i8;
pub type size_t = __darwin_size_t;
pub type utf8_t = ::core::ffi::c_uchar;
#[no_mangle]
pub unsafe extern "C" fn utf32_length_from_utf8(
    mut data: *const utf8_t,
    mut len: size_t,
) -> size_t {
    let mut counter: size_t = 0 as size_t;
    let mut i: size_t = 0 as size_t;
    while i < len {
        if *data.offset(i as isize) as int8_t as ::core::ffi::c_int
            > -(65 as ::core::ffi::c_int)
        {
            counter = counter.wrapping_add(1);
        }
        i = i.wrapping_add(1);
    }
    return counter;
}
