#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uint_least32_t = uint32_t;
pub type utf32_t = uint_least32_t;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn utf32_validate(
    mut data: *const utf32_t,
    mut len: size_t,
) -> bool {
    let mut pos: uint64_t = 0 as uint64_t;
    let mut word: uint32_t = 0;
    while pos < len as uint64_t {
        word = *data.offset(pos as isize) as uint32_t;
        if word > 0x10ffff as uint32_t
            || word >= 0xd800 as uint32_t && word <= 0xdfff as uint32_t
        {
            return false_0 != 0;
        }
        pos = pos.wrapping_add(1);
    }
    return true_0 != 0;
}
