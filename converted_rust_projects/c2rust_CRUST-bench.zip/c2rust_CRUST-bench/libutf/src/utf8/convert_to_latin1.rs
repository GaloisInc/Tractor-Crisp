#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type utf8_t = ::core::ffi::c_uchar;
pub type latin1_t = ::core::ffi::c_uchar;
#[no_mangle]
pub unsafe extern "C" fn utf8_convert_to_latin1(
    mut data: *const utf8_t,
    mut len: size_t,
    mut result: *mut latin1_t,
) -> size_t {
    let mut pos: size_t = 0 as size_t;
    let mut start: *mut latin1_t = result;
    while pos < len {
        if pos.wrapping_add(16 as size_t) <= len {
            let mut v1: uint64_t = 0;
            memcpy(
                &mut v1 as *mut uint64_t as *mut ::core::ffi::c_void,
                data.offset(pos as isize) as *const ::core::ffi::c_void,
                ::core::mem::size_of::<uint64_t>() as size_t,
            );
            let mut v2: uint64_t = 0;
            memcpy(
                &mut v2 as *mut uint64_t as *mut ::core::ffi::c_void,
                data
                    .offset(pos as isize)
                    .offset(::core::mem::size_of::<uint64_t>() as usize as isize)
                    as *const ::core::ffi::c_void,
                ::core::mem::size_of::<uint64_t>() as size_t,
            );
            let mut v: uint64_t = v1 | v2;
            if v & 0x8080808080808080 as uint64_t == 0 as uint64_t {
                let mut final_pos: size_t = pos.wrapping_add(16 as size_t);
                while pos < final_pos {
                    let fresh0 = result;
                    result = result.offset(1);
                    *fresh0 = *data.offset(pos as isize) as latin1_t;
                    pos = pos.wrapping_add(1);
                }
                continue;
            }
        }
        let mut leading_byte: uint8_t = *data.offset(pos as isize);
        if (leading_byte as ::core::ffi::c_int) < 0o200 as ::core::ffi::c_int {
            let fresh1 = result;
            result = result.offset(1);
            *fresh1 = leading_byte as latin1_t;
            pos = pos.wrapping_add(1);
        } else if leading_byte as ::core::ffi::c_int & 0o340 as ::core::ffi::c_int
            == 0o300 as ::core::ffi::c_int
        {
            if pos.wrapping_add(1 as size_t) >= len {
                return 0 as size_t;
            }
            if *data.offset(pos.wrapping_add(1 as size_t) as isize) as ::core::ffi::c_int
                & 0o300 as ::core::ffi::c_int != 0o200 as ::core::ffi::c_int
            {
                return 0 as size_t;
            }
            let mut code_point: uint32_t = ((leading_byte as ::core::ffi::c_int
                & 0o37 as ::core::ffi::c_int) << 6 as ::core::ffi::c_int
                | *data.offset(pos.wrapping_add(1 as size_t) as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int) as uint32_t;
            if code_point < 0x80 as uint32_t || (0xff as uint32_t) < code_point {
                return 0 as size_t;
            }
            let fresh2 = result;
            result = result.offset(1);
            *fresh2 = code_point as latin1_t;
            pos = pos.wrapping_add(2 as size_t);
        } else {
            return 0 as size_t
        }
    }
    return result.offset_from(start) as ::core::ffi::c_long as size_t;
}
