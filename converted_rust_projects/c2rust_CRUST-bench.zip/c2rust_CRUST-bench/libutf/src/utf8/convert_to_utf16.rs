#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uint_least16_t = uint16_t;
pub type utf8_t = ::core::ffi::c_uchar;
pub type utf16_t = uint_least16_t;
pub const utf_be: utf_endianness_t = 1;
pub type utf_endianness_t = ::core::ffi::c_uint;
pub const utf_le: utf_endianness_t = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed {
    pub u8_0: [uint8_t; 2],
    pub u16_0: uint16_t,
}
#[inline]
unsafe extern "C" fn utf_endianness() -> utf_endianness_t {
    let byte_order: C2RustUnnamed = C2RustUnnamed {
        u8_0: [1 as ::core::ffi::c_int as uint8_t, 0 as ::core::ffi::c_int as uint8_t],
    };
    return (if byte_order.u16_0 as ::core::ffi::c_int == 1 as ::core::ffi::c_int {
        utf_le as ::core::ffi::c_int
    } else {
        utf_be as ::core::ffi::c_int
    }) as utf_endianness_t;
}
#[inline]
unsafe extern "C" fn utf_is_be() -> bool {
    return utf_endianness() as ::core::ffi::c_uint
        == utf_be as ::core::ffi::c_int as ::core::ffi::c_uint;
}
#[inline]
unsafe extern "C" fn utf_swap_uint16(mut n: uint16_t) -> uint16_t {
    return ((n as ::core::ffi::c_int & 0xff as ::core::ffi::c_int)
        << 8 as ::core::ffi::c_int
        | (n as ::core::ffi::c_int & 0xff00 as ::core::ffi::c_int)
            >> 8 as ::core::ffi::c_int) as uint16_t;
}
#[no_mangle]
pub unsafe extern "C" fn utf8_convert_to_utf16le(
    mut data: *const utf8_t,
    mut len: size_t,
    mut result: *mut utf16_t,
) -> size_t {
    let mut pos: size_t = 0 as size_t;
    let mut start: *mut utf16_t = result;
    while pos < len {
        if pos.wrapping_add(8 as size_t) <= len {
            let mut v: uint64_t = 0;
            memcpy(
                &mut v as *mut uint64_t as *mut ::core::ffi::c_void,
                data.offset(pos as isize) as *const ::core::ffi::c_void,
                ::core::mem::size_of::<uint64_t>() as size_t,
            );
            if v & 0x8080808080808080 as uint64_t == 0 as uint64_t {
                let mut final_pos: size_t = pos.wrapping_add(8 as size_t);
                while pos < final_pos {
                    let fresh0 = result;
                    result = result.offset(1);
                    *fresh0 = (if utf_is_be() as ::core::ffi::c_int != 0 {
                        utf_swap_uint16(*data.offset(pos as isize) as uint16_t)
                            as ::core::ffi::c_int
                    } else {
                        *data.offset(pos as isize) as ::core::ffi::c_int
                    }) as utf16_t;
                    pos = pos.wrapping_add(1);
                }
                continue;
            }
        }
        let mut leading_byte: uint8_t = *data.offset(pos as isize);
        if (leading_byte as ::core::ffi::c_int) < 0o200 as ::core::ffi::c_int {
            let fresh1 = result;
            result = result.offset(1);
            *fresh1 = (if utf_is_be() as ::core::ffi::c_int != 0 {
                utf_swap_uint16(leading_byte as uint16_t) as ::core::ffi::c_int
            } else {
                leading_byte as ::core::ffi::c_int
            }) as utf16_t;
            pos = pos.wrapping_add(1);
        } else if leading_byte as ::core::ffi::c_int & 0o340 as ::core::ffi::c_int
            == 0o300 as ::core::ffi::c_int
        {
            if pos.wrapping_add(1 as size_t) >= len {
                break;
            }
            let mut code_point: uint16_t = ((leading_byte as ::core::ffi::c_int
                & 0o37 as ::core::ffi::c_int) << 6 as ::core::ffi::c_int
                | *data.offset(pos.wrapping_add(1 as size_t) as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int) as uint16_t;
            if utf_is_be() {
                code_point = utf_swap_uint16(code_point);
            }
            let fresh2 = result;
            result = result.offset(1);
            *fresh2 = code_point as utf16_t;
            pos = pos.wrapping_add(2 as size_t);
        } else if leading_byte as ::core::ffi::c_int & 0o360 as ::core::ffi::c_int
            == 0o340 as ::core::ffi::c_int
        {
            if pos.wrapping_add(2 as size_t) >= len {
                break;
            }
            let mut code_point_0: uint16_t = ((leading_byte as ::core::ffi::c_int
                & 0o17 as ::core::ffi::c_int) << 12 as ::core::ffi::c_int
                | (*data.offset(pos.wrapping_add(1 as size_t) as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int)
                    << 6 as ::core::ffi::c_int
                | *data.offset(pos.wrapping_add(2 as size_t) as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int) as uint16_t;
            if utf_is_be() {
                code_point_0 = utf_swap_uint16(code_point_0);
            }
            let fresh3 = result;
            result = result.offset(1);
            *fresh3 = code_point_0 as utf16_t;
            pos = pos.wrapping_add(3 as size_t);
        } else if leading_byte as ::core::ffi::c_int & 0o370 as ::core::ffi::c_int
            == 0o360 as ::core::ffi::c_int
        {
            if pos.wrapping_add(3 as size_t) >= len {
                break;
            }
            let mut code_point_1: uint32_t = ((leading_byte as ::core::ffi::c_int
                & 0o7 as ::core::ffi::c_int) << 18 as ::core::ffi::c_int
                | (*data.offset(pos.wrapping_add(1 as size_t) as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int)
                    << 12 as ::core::ffi::c_int
                | (*data.offset(pos.wrapping_add(2 as size_t) as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int)
                    << 6 as ::core::ffi::c_int
                | *data.offset(pos.wrapping_add(3 as size_t) as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int) as uint32_t;
            code_point_1 = code_point_1.wrapping_sub(0x10000 as uint32_t);
            let mut high_surrogate: uint16_t = (0xd800 as uint32_t)
                .wrapping_add(code_point_1 >> 10 as ::core::ffi::c_int) as uint16_t;
            let mut low_surrogate: uint16_t = (0xdc00 as uint32_t)
                .wrapping_add(code_point_1 & 0x3ff as uint32_t) as uint16_t;
            if utf_is_be() {
                high_surrogate = utf_swap_uint16(high_surrogate);
                low_surrogate = utf_swap_uint16(low_surrogate);
            }
            let fresh4 = result;
            result = result.offset(1);
            *fresh4 = high_surrogate as utf16_t;
            let fresh5 = result;
            result = result.offset(1);
            *fresh5 = low_surrogate as utf16_t;
            pos = pos.wrapping_add(4 as size_t);
        } else {
            return 0 as size_t
        }
    }
    return result.offset_from(start) as ::core::ffi::c_long as size_t;
}
