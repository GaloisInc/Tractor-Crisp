#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type latin1_t = ::core::ffi::c_uchar;
#[no_mangle]
pub unsafe extern "C" fn utf8_length_from_latin1(
    mut data: *const latin1_t,
    mut len: size_t,
) -> size_t {
    let mut counter: size_t = len;
    let mut i: size_t = 0 as size_t;
    while i < len {
        counter = counter
            .wrapping_add(
                (*data.offset(i as isize) as ::core::ffi::c_int
                    >> 7 as ::core::ffi::c_int) as size_t,
            );
        i = i.wrapping_add(1);
    }
    return counter;
}
