#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint_least16_t = uint16_t;
pub type utf16_t = uint_least16_t;
pub const utf_be: utf_endianness_t = 1;
pub type utf_endianness_t = ::core::ffi::c_uint;
pub const utf_le: utf_endianness_t = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed {
    pub u8_0: [uint8_t; 2],
    pub u16_0: uint16_t,
}
#[inline]
unsafe extern "C" fn utf_endianness() -> utf_endianness_t {
    let byte_order: C2RustUnnamed = C2RustUnnamed {
        u8_0: [1 as ::core::ffi::c_int as uint8_t, 0 as ::core::ffi::c_int as uint8_t],
    };
    return (if byte_order.u16_0 as ::core::ffi::c_int == 1 as ::core::ffi::c_int {
        utf_le as ::core::ffi::c_int
    } else {
        utf_be as ::core::ffi::c_int
    }) as utf_endianness_t;
}
#[inline]
unsafe extern "C" fn utf_is_be() -> bool {
    return utf_endianness() as ::core::ffi::c_uint
        == utf_be as ::core::ffi::c_int as ::core::ffi::c_uint;
}
#[inline]
unsafe extern "C" fn utf_swap_uint16(mut n: uint16_t) -> uint16_t {
    return ((n as ::core::ffi::c_int & 0xff as ::core::ffi::c_int)
        << 8 as ::core::ffi::c_int
        | (n as ::core::ffi::c_int & 0xff00 as ::core::ffi::c_int)
            >> 8 as ::core::ffi::c_int) as uint16_t;
}
#[no_mangle]
pub unsafe extern "C" fn utf8_length_from_utf16le(
    mut data: *const utf16_t,
    mut len: size_t,
) -> size_t {
    let mut counter: size_t = 0 as size_t;
    let mut word: uint16_t = 0;
    let mut i: size_t = 0 as size_t;
    while i < len {
        word = (if utf_is_be() as ::core::ffi::c_int != 0 {
            utf_swap_uint16(*data.offset(i as isize)) as ::core::ffi::c_int
        } else {
            *data.offset(i as isize) as ::core::ffi::c_int
        }) as uint16_t;
        if word as ::core::ffi::c_int <= 0x7f as ::core::ffi::c_int {
            counter = counter.wrapping_add(1);
        } else if word as ::core::ffi::c_int <= 0x7ff as ::core::ffi::c_int {
            counter = counter.wrapping_add(2 as size_t);
        } else if word as ::core::ffi::c_int <= 0xd7ff as ::core::ffi::c_int
            || word as ::core::ffi::c_int >= 0xe000 as ::core::ffi::c_int
        {
            counter = counter.wrapping_add(3 as size_t);
        } else {
            counter = counter.wrapping_add(2 as size_t);
        }
        i = i.wrapping_add(1);
    }
    return counter;
}
