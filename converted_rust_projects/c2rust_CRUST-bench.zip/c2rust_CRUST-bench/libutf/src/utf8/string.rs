#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn realloc(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memmove(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strncmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> ::core::ffi::c_int;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type utf8_t = ::core::ffi::c_uchar;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct utf8_string_s {
    pub data: *mut utf8_t,
    pub len: size_t,
    pub c2rust_unnamed: C2RustUnnamed,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub union C2RustUnnamed {
    pub cap: size_t,
    pub buf: [utf8_t; 8],
}
pub type utf8_string_t = utf8_string_s;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct utf8_string_view_s {
    pub data: *const utf8_t,
    pub len: size_t,
}
pub type utf8_string_view_t = utf8_string_view_s;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[inline]
unsafe extern "C" fn utf8_string_init(mut string: *mut utf8_string_t) {
    (*string).data = (*string).c2rust_unnamed.buf.as_mut_ptr();
    (*string).len = 0 as size_t;
}
#[inline]
unsafe extern "C" fn utf8_string_view_init(
    mut data: *const utf8_t,
    mut len: size_t,
) -> utf8_string_view_t {
    let mut view: utf8_string_view_t = {
        let mut init = utf8_string_view_s {
            data: data,
            len: len,
        };
        init
    };
    return view;
}
#[inline]
unsafe extern "C" fn utf8_string_destroy(mut string: *mut utf8_string_t) {
    if (*string).data != (*string).c2rust_unnamed.buf.as_mut_ptr() {
        free((*string).data as *mut ::core::ffi::c_void);
    }
}
#[inline]
unsafe extern "C" fn utf8_string_reserve(
    mut string: *mut utf8_string_t,
    mut len: size_t,
) -> ::core::ffi::c_int {
    let mut cap: size_t = if (*string).data == (*string).c2rust_unnamed.buf.as_mut_ptr()
    {
        ::core::mem::size_of::<[utf8_t; 8]>() as size_t
    } else {
        (*string).c2rust_unnamed.cap
    };
    if len <= cap {
        return 0 as ::core::ffi::c_int;
    }
    len = len.wrapping_sub(1);
    len |= len >> 1 as ::core::ffi::c_int;
    len |= len >> 2 as ::core::ffi::c_int;
    len |= len >> 4 as ::core::ffi::c_int;
    len |= len >> 8 as ::core::ffi::c_int;
    len |= len >> 16 as ::core::ffi::c_int;
    if ::core::mem::size_of::<size_t>() as usize == 8 as usize {
        len |= len >> 32 as ::core::ffi::c_int;
    }
    len = len.wrapping_add(1);
    cap = len;
    let mut data: *mut utf8_t = 0 as *mut utf8_t;
    if (*string).data == (*string).c2rust_unnamed.buf.as_mut_ptr() {
        data = malloc(cap) as *mut utf8_t;
        memcpy(
            data as *mut ::core::ffi::c_void,
            (*string).data as *const ::core::ffi::c_void,
            (*string).len,
        );
    } else {
        data = realloc((*string).data as *mut ::core::ffi::c_void, cap) as *mut utf8_t;
    }
    if data.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    (*string).data = data;
    (*string).c2rust_unnamed.cap = cap;
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_shrink_to_fit(
    mut string: *mut utf8_string_t,
) -> ::core::ffi::c_int {
    if (*string).data == (*string).c2rust_unnamed.buf.as_mut_ptr() {
        return 0 as ::core::ffi::c_int;
    }
    let mut cap: size_t = (*string).len;
    if cap <= ::core::mem::size_of::<[utf8_t; 8]>() as usize {
        memcpy(
            (*string).c2rust_unnamed.buf.as_mut_ptr() as *mut ::core::ffi::c_void,
            (*string).data as *const ::core::ffi::c_void,
            cap,
        );
        free((*string).data as *mut ::core::ffi::c_void);
        (*string).data = (*string).c2rust_unnamed.buf.as_mut_ptr();
    } else {
        let mut data: *mut utf8_t = realloc(
            (*string).data as *mut ::core::ffi::c_void,
            cap,
        ) as *mut utf8_t;
        if data.is_null() {
            return -(1 as ::core::ffi::c_int);
        }
        (*string).data = data;
        (*string).c2rust_unnamed.cap = cap;
    }
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_view(
    mut string: *const utf8_string_t,
) -> utf8_string_view_t {
    return utf8_string_view_init((*string).data, (*string).len);
}
#[inline]
unsafe extern "C" fn utf8_string_clear(mut string: *mut utf8_string_t) {
    (*string).len = 0 as size_t;
}
#[inline]
unsafe extern "C" fn utf8_string_empty(mut string: *const utf8_string_t) -> bool {
    return (*string).len == 0 as size_t;
}
#[inline]
unsafe extern "C" fn utf8_string_view_empty(view: utf8_string_view_t) -> bool {
    return view.len == 0 as size_t;
}
#[inline]
unsafe extern "C" fn utf8_string_copy(
    mut string: *const utf8_string_t,
    mut result: *mut utf8_string_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    err = utf8_string_reserve(result, (*string).len);
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    memcpy(
        (*result).data as *mut ::core::ffi::c_void,
        (*string).data as *const ::core::ffi::c_void,
        (*string).len,
    );
    (*result).len = (*string).len;
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_view_copy(
    view: utf8_string_view_t,
    mut result: *mut utf8_string_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    err = utf8_string_reserve(result, view.len);
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    memcpy(
        (*result).data as *mut ::core::ffi::c_void,
        view.data as *const ::core::ffi::c_void,
        view.len,
    );
    (*result).len = view.len;
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_append(
    mut string: *mut utf8_string_t,
    mut other: *const utf8_string_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    err = utf8_string_reserve(string, (*string).len.wrapping_add((*other).len));
    if err < 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    memcpy(
        &mut *(*string).data.offset((*string).len as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        (*other).data as *const ::core::ffi::c_void,
        (*other).len,
    );
    (*string).len = (*string).len.wrapping_add((*other).len);
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_append_view(
    mut string: *mut utf8_string_t,
    view: utf8_string_view_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    err = utf8_string_reserve(string, (*string).len.wrapping_add(view.len));
    if err < 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    memcpy(
        &mut *(*string).data.offset((*string).len as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        view.data as *const ::core::ffi::c_void,
        view.len,
    );
    (*string).len = (*string).len.wrapping_add(view.len);
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_append_character(
    mut string: *mut utf8_string_t,
    mut c: utf8_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    err = utf8_string_reserve(string, (*string).len.wrapping_add(1 as size_t));
    if err < 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    *(*string).data.offset((*string).len as isize) = c;
    (*string).len = (*string).len.wrapping_add(1 as size_t);
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_append_literal(
    mut string: *mut utf8_string_t,
    mut literal: *const utf8_t,
    mut n: size_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    if n == -(1 as ::core::ffi::c_int) as size_t {
        n = strlen(literal as *const ::core::ffi::c_char);
    }
    err = utf8_string_reserve(string, (*string).len.wrapping_add(n));
    if err < 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    memcpy(
        &mut *(*string).data.offset((*string).len as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        literal as *const ::core::ffi::c_void,
        n,
    );
    (*string).len = (*string).len.wrapping_add(n);
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_prepend(
    mut string: *mut utf8_string_t,
    mut other: *const utf8_string_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    err = utf8_string_reserve(string, (*string).len.wrapping_add((*other).len));
    if err < 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    memmove(
        &mut *(*string).data.offset((*other).len as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        (*string).data as *const ::core::ffi::c_void,
        (*string).len,
    );
    memcpy(
        (*string).data as *mut ::core::ffi::c_void,
        (*other).data as *const ::core::ffi::c_void,
        (*other).len,
    );
    (*string).len = (*string).len.wrapping_add((*other).len);
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_prepend_view(
    mut string: *mut utf8_string_t,
    view: utf8_string_view_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    err = utf8_string_reserve(string, (*string).len.wrapping_add(view.len));
    if err < 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    memmove(
        &mut *(*string).data.offset(view.len as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        (*string).data as *const ::core::ffi::c_void,
        (*string).len,
    );
    memcpy(
        (*string).data as *mut ::core::ffi::c_void,
        view.data as *const ::core::ffi::c_void,
        view.len,
    );
    (*string).len = (*string).len.wrapping_add(view.len);
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_prepend_character(
    mut string: *mut utf8_string_t,
    mut c: utf8_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    err = utf8_string_reserve(string, (*string).len.wrapping_add(1 as size_t));
    if err < 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    memmove(
        &mut *(*string).data.offset(1 as ::core::ffi::c_int as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        (*string).data as *const ::core::ffi::c_void,
        (*string).len,
    );
    *(*string).data.offset(0 as ::core::ffi::c_int as isize) = c;
    (*string).len = (*string).len.wrapping_add(1 as size_t);
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_prepend_literal(
    mut string: *mut utf8_string_t,
    mut literal: *const utf8_t,
    mut n: size_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    if n == -(1 as ::core::ffi::c_int) as size_t {
        n = strlen(literal as *const ::core::ffi::c_char);
    }
    err = utf8_string_reserve(string, (*string).len.wrapping_add(n));
    if err < 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    memmove(
        &mut *(*string).data.offset(n as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        (*string).data as *const ::core::ffi::c_void,
        (*string).len,
    );
    memcpy(
        (*string).data as *mut ::core::ffi::c_void,
        literal as *const ::core::ffi::c_void,
        n,
    );
    (*string).len = (*string).len.wrapping_add(n);
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_insert(
    mut string: *mut utf8_string_t,
    mut pos: size_t,
    mut other: *const utf8_string_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    if pos > (*string).len {
        return -(1 as ::core::ffi::c_int);
    }
    let mut inserted_len: size_t = (*string).len.wrapping_add((*other).len);
    err = utf8_string_reserve(string, inserted_len);
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    memmove(
        &mut *(*string).data.offset(pos.wrapping_add((*other).len) as isize)
            as *mut utf8_t as *mut ::core::ffi::c_void,
        &mut *(*string).data.offset(pos as isize) as *mut utf8_t
            as *const ::core::ffi::c_void,
        (*string).len.wrapping_sub(pos),
    );
    memcpy(
        &mut *(*string).data.offset(pos as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        (*other).data as *const ::core::ffi::c_void,
        (*other).len,
    );
    (*string).len = inserted_len;
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_insert_view(
    mut string: *mut utf8_string_t,
    mut pos: size_t,
    other: utf8_string_view_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    if pos > (*string).len {
        return -(1 as ::core::ffi::c_int);
    }
    let mut inserted_len: size_t = (*string).len.wrapping_add(other.len);
    err = utf8_string_reserve(string, inserted_len);
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    memmove(
        &mut *(*string).data.offset(pos.wrapping_add(other.len) as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        &mut *(*string).data.offset(pos as isize) as *mut utf8_t
            as *const ::core::ffi::c_void,
        (*string).len.wrapping_sub(pos),
    );
    memcpy(
        &mut *(*string).data.offset(pos as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        other.data as *const ::core::ffi::c_void,
        other.len,
    );
    (*string).len = inserted_len;
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_insert_character(
    mut string: *mut utf8_string_t,
    mut pos: size_t,
    mut c: utf8_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    if pos > (*string).len {
        return -(1 as ::core::ffi::c_int);
    }
    let mut inserted_len: size_t = (*string).len.wrapping_add(1 as size_t);
    err = utf8_string_reserve(string, inserted_len);
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    memmove(
        &mut *(*string).data.offset(pos.wrapping_add(1 as size_t) as isize)
            as *mut utf8_t as *mut ::core::ffi::c_void,
        &mut *(*string).data.offset(pos as isize) as *mut utf8_t
            as *const ::core::ffi::c_void,
        (*string).len.wrapping_sub(pos),
    );
    *(*string).data.offset(pos as isize) = c;
    (*string).len = inserted_len;
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_insert_literal(
    mut string: *mut utf8_string_t,
    mut pos: size_t,
    mut literal: *const utf8_t,
    mut n: size_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    if pos > (*string).len {
        return -(1 as ::core::ffi::c_int);
    }
    if n == -(1 as ::core::ffi::c_int) as size_t {
        n = strlen(literal as *const ::core::ffi::c_char);
    }
    let mut inserted_len: size_t = (*string).len.wrapping_add(n);
    err = utf8_string_reserve(string, inserted_len);
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    memmove(
        &mut *(*string).data.offset(pos.wrapping_add(n) as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        &mut *(*string).data.offset(pos as isize) as *mut utf8_t
            as *const ::core::ffi::c_void,
        (*string).len.wrapping_sub(pos),
    );
    memcpy(
        &mut *(*string).data.offset(pos as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        literal as *const ::core::ffi::c_void,
        n,
    );
    (*string).len = inserted_len;
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_replace(
    mut string: *mut utf8_string_t,
    mut pos: size_t,
    mut len: size_t,
    mut replacement: *const utf8_string_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    if pos > (*string).len {
        return -(1 as ::core::ffi::c_int);
    }
    if pos.wrapping_add(len) > (*string).len {
        len = (*string).len.wrapping_sub(pos);
    }
    let mut replaced_len: size_t = (*string)
        .len
        .wrapping_add((*replacement).len)
        .wrapping_sub(len);
    err = utf8_string_reserve(string, replaced_len);
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    memmove(
        &mut *(*string).data.offset(pos.wrapping_add((*replacement).len) as isize)
            as *mut utf8_t as *mut ::core::ffi::c_void,
        &mut *(*string).data.offset(pos.wrapping_add(len) as isize) as *mut utf8_t
            as *const ::core::ffi::c_void,
        (*string).len.wrapping_sub(pos).wrapping_sub(len),
    );
    memcpy(
        &mut *(*string).data.offset(pos as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        (*replacement).data as *const ::core::ffi::c_void,
        (*replacement).len,
    );
    (*string).len = replaced_len;
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_replace_view(
    mut string: *mut utf8_string_t,
    mut pos: size_t,
    mut len: size_t,
    replacement: utf8_string_view_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    if pos > (*string).len {
        return -(1 as ::core::ffi::c_int);
    }
    if pos.wrapping_add(len) > (*string).len {
        len = (*string).len.wrapping_sub(pos);
    }
    let mut replaced_len: size_t = (*string)
        .len
        .wrapping_add(replacement.len)
        .wrapping_sub(len);
    err = utf8_string_reserve(string, replaced_len);
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    memmove(
        &mut *(*string).data.offset(pos.wrapping_add(replacement.len) as isize)
            as *mut utf8_t as *mut ::core::ffi::c_void,
        &mut *(*string).data.offset(pos.wrapping_add(len) as isize) as *mut utf8_t
            as *const ::core::ffi::c_void,
        (*string).len.wrapping_sub(pos).wrapping_sub(len),
    );
    memcpy(
        &mut *(*string).data.offset(pos as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        replacement.data as *const ::core::ffi::c_void,
        replacement.len,
    );
    (*string).len = replaced_len;
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_replace_character(
    mut string: *mut utf8_string_t,
    mut pos: size_t,
    mut len: size_t,
    mut c: utf8_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    if pos > (*string).len {
        return -(1 as ::core::ffi::c_int);
    }
    let mut replaced_len: size_t = (*string)
        .len
        .wrapping_add(1 as size_t)
        .wrapping_sub(len);
    err = utf8_string_reserve(string, replaced_len);
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    memmove(
        &mut *(*string).data.offset(pos.wrapping_add(1 as size_t) as isize)
            as *mut utf8_t as *mut ::core::ffi::c_void,
        &mut *(*string).data.offset(pos.wrapping_add(len) as isize) as *mut utf8_t
            as *const ::core::ffi::c_void,
        (*string).len.wrapping_sub(pos).wrapping_sub(len),
    );
    *(*string).data.offset(pos as isize) = c;
    (*string).len = replaced_len;
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_replace_literal(
    mut string: *mut utf8_string_t,
    mut pos: size_t,
    mut len: size_t,
    mut literal: *const utf8_t,
    mut n: size_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    if pos > (*string).len {
        return -(1 as ::core::ffi::c_int);
    }
    if pos.wrapping_add(len) > (*string).len {
        len = (*string).len.wrapping_sub(pos);
    }
    if n == -(1 as ::core::ffi::c_int) as size_t {
        n = strlen(literal as *const ::core::ffi::c_char);
    }
    let mut replaced_len: size_t = (*string).len.wrapping_add(n).wrapping_sub(len);
    err = utf8_string_reserve(string, replaced_len);
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    memmove(
        &mut *(*string).data.offset(pos.wrapping_add(n) as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        &mut *(*string).data.offset(pos.wrapping_add(len) as isize) as *mut utf8_t
            as *const ::core::ffi::c_void,
        (*string).len.wrapping_sub(pos).wrapping_sub(len),
    );
    memcpy(
        &mut *(*string).data.offset(pos as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        literal as *const ::core::ffi::c_void,
        n,
    );
    (*string).len = replaced_len;
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_erase(
    mut string: *mut utf8_string_t,
    mut pos: size_t,
    mut len: size_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    if pos > (*string).len {
        return -(1 as ::core::ffi::c_int);
    }
    if pos.wrapping_add(len) > (*string).len {
        len = (*string).len.wrapping_sub(pos);
    }
    memmove(
        &mut *(*string).data.offset(pos as isize) as *mut utf8_t
            as *mut ::core::ffi::c_void,
        &mut *(*string).data.offset(pos.wrapping_add(len) as isize) as *mut utf8_t
            as *const ::core::ffi::c_void,
        (*string).len.wrapping_sub(pos).wrapping_sub(len),
    );
    (*string).len = (*string).len.wrapping_sub(len);
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_concat(
    mut string: *const utf8_string_t,
    mut other: *const utf8_string_t,
    mut result: *mut utf8_string_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    utf8_string_init(result);
    err = utf8_string_reserve(result, (*string).len.wrapping_add((*other).len));
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    err = utf8_string_append(result, string);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"utf8_string_concat\0")
                .as_ptr(),
            b"string.h\0" as *const u8 as *const ::core::ffi::c_char,
            478 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    err = utf8_string_append(result, other);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"utf8_string_concat\0")
                .as_ptr(),
            b"string.h\0" as *const u8 as *const ::core::ffi::c_char,
            481 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_view_concat(
    view: utf8_string_view_t,
    mut other: *const utf8_string_t,
    mut result: *mut utf8_string_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    utf8_string_init(result);
    err = utf8_string_reserve(result, view.len.wrapping_add((*other).len));
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    err = utf8_string_append_view(result, view);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"utf8_string_view_concat\0")
                .as_ptr(),
            b"string.h\0" as *const u8 as *const ::core::ffi::c_char,
            496 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    err = utf8_string_append(result, other);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"utf8_string_view_concat\0")
                .as_ptr(),
            b"string.h\0" as *const u8 as *const ::core::ffi::c_char,
            499 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_concat_view(
    mut string: *const utf8_string_t,
    other: utf8_string_view_t,
    mut result: *mut utf8_string_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    utf8_string_init(result);
    err = utf8_string_reserve(result, (*string).len.wrapping_add(other.len));
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    err = utf8_string_append(result, string);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"utf8_string_concat_view\0")
                .as_ptr(),
            b"string.h\0" as *const u8 as *const ::core::ffi::c_char,
            514 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    err = utf8_string_append_view(result, other);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"utf8_string_concat_view\0")
                .as_ptr(),
            b"string.h\0" as *const u8 as *const ::core::ffi::c_char,
            517 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_view_concat_view(
    view: utf8_string_view_t,
    other: utf8_string_view_t,
    mut result: *mut utf8_string_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    utf8_string_init(result);
    err = utf8_string_reserve(result, view.len.wrapping_add(other.len));
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    err = utf8_string_append_view(result, view);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 29],
                [::core::ffi::c_char; 29],
            >(*b"utf8_string_view_concat_view\0")
                .as_ptr(),
            b"string.h\0" as *const u8 as *const ::core::ffi::c_char,
            532 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    err = utf8_string_append_view(result, other);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 29],
                [::core::ffi::c_char; 29],
            >(*b"utf8_string_view_concat_view\0")
                .as_ptr(),
            b"string.h\0" as *const u8 as *const ::core::ffi::c_char,
            535 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_concat_character(
    mut string: *const utf8_string_t,
    mut c: utf8_t,
    mut result: *mut utf8_string_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    utf8_string_init(result);
    err = utf8_string_reserve(result, (*string).len.wrapping_add(1 as size_t));
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    err = utf8_string_append(result, string);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 29],
                [::core::ffi::c_char; 29],
            >(*b"utf8_string_concat_character\0")
                .as_ptr(),
            b"string.h\0" as *const u8 as *const ::core::ffi::c_char,
            550 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    err = utf8_string_append_character(result, c);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 29],
                [::core::ffi::c_char; 29],
            >(*b"utf8_string_concat_character\0")
                .as_ptr(),
            b"string.h\0" as *const u8 as *const ::core::ffi::c_char,
            553 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_view_concat_character(
    view: utf8_string_view_t,
    mut c: utf8_t,
    mut result: *mut utf8_string_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    utf8_string_init(result);
    err = utf8_string_reserve(result, view.len.wrapping_add(1 as size_t));
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    err = utf8_string_append_view(result, view);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 34],
                [::core::ffi::c_char; 34],
            >(*b"utf8_string_view_concat_character\0")
                .as_ptr(),
            b"string.h\0" as *const u8 as *const ::core::ffi::c_char,
            568 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    err = utf8_string_append_character(result, c);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 34],
                [::core::ffi::c_char; 34],
            >(*b"utf8_string_view_concat_character\0")
                .as_ptr(),
            b"string.h\0" as *const u8 as *const ::core::ffi::c_char,
            571 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_concat_literal(
    mut string: *const utf8_string_t,
    mut literal: *const utf8_t,
    mut n: size_t,
    mut result: *mut utf8_string_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    utf8_string_init(result);
    err = utf8_string_reserve(result, (*string).len.wrapping_add(n));
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    err = utf8_string_append(result, string);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 27],
                [::core::ffi::c_char; 27],
            >(*b"utf8_string_concat_literal\0")
                .as_ptr(),
            b"string.h\0" as *const u8 as *const ::core::ffi::c_char,
            586 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    err = utf8_string_append_literal(result, literal, n);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 27],
                [::core::ffi::c_char; 27],
            >(*b"utf8_string_concat_literal\0")
                .as_ptr(),
            b"string.h\0" as *const u8 as *const ::core::ffi::c_char,
            589 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_view_concat_literal(
    view: utf8_string_view_t,
    mut literal: *const utf8_t,
    mut n: size_t,
    mut result: *mut utf8_string_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    utf8_string_init(result);
    err = utf8_string_reserve(result, view.len.wrapping_add(n));
    if err < 0 as ::core::ffi::c_int {
        return err;
    }
    err = utf8_string_append_view(result, view);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 32],
                [::core::ffi::c_char; 32],
            >(*b"utf8_string_view_concat_literal\0")
                .as_ptr(),
            b"string.h\0" as *const u8 as *const ::core::ffi::c_char,
            604 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    err = utf8_string_append_literal(result, literal, n);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 32],
                [::core::ffi::c_char; 32],
            >(*b"utf8_string_view_concat_literal\0")
                .as_ptr(),
            b"string.h\0" as *const u8 as *const ::core::ffi::c_char,
            607 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_compare(
    mut string: *const utf8_string_t,
    mut other: *const utf8_string_t,
) -> ::core::ffi::c_int {
    let mut a_len: size_t = (*string).len;
    let mut b_len: size_t = (*other).len;
    let mut result: ::core::ffi::c_int = strncmp(
        (*string).data as *const ::core::ffi::c_char,
        (*other).data as *const ::core::ffi::c_char,
        if a_len < b_len { a_len } else { b_len },
    );
    if result == 0 as ::core::ffi::c_int {
        return if a_len < b_len {
            -(1 as ::core::ffi::c_int)
        } else if a_len > b_len {
            1 as ::core::ffi::c_int
        } else {
            0 as ::core::ffi::c_int
        };
    }
    return result;
}
#[inline]
unsafe extern "C" fn utf8_string_view_compare(
    view: utf8_string_view_t,
    other: utf8_string_view_t,
) -> ::core::ffi::c_int {
    let mut a_len: size_t = view.len;
    let mut b_len: size_t = other.len;
    let mut result: ::core::ffi::c_int = strncmp(
        view.data as *const ::core::ffi::c_char,
        other.data as *const ::core::ffi::c_char,
        if a_len < b_len { a_len } else { b_len },
    );
    if result == 0 as ::core::ffi::c_int {
        return if a_len < b_len {
            -(1 as ::core::ffi::c_int)
        } else if a_len > b_len {
            1 as ::core::ffi::c_int
        } else {
            0 as ::core::ffi::c_int
        };
    }
    return result;
}
#[inline]
unsafe extern "C" fn utf8_string_compare_literal(
    mut string: *const utf8_string_t,
    mut literal: *const utf8_t,
    mut n: size_t,
) -> ::core::ffi::c_int {
    if n == -(1 as ::core::ffi::c_int) as size_t {
        n = strlen(literal as *const ::core::ffi::c_char);
    }
    let mut a_len: size_t = (*string).len;
    let mut b_len: size_t = n;
    let mut result: ::core::ffi::c_int = strncmp(
        (*string).data as *const ::core::ffi::c_char,
        literal as *const ::core::ffi::c_char,
        if a_len < b_len { a_len } else { b_len },
    );
    if result == 0 as ::core::ffi::c_int {
        return if a_len < b_len {
            -(1 as ::core::ffi::c_int)
        } else if a_len > b_len {
            1 as ::core::ffi::c_int
        } else {
            0 as ::core::ffi::c_int
        };
    }
    return result;
}
#[inline]
unsafe extern "C" fn utf8_string_view_compare_literal(
    view: utf8_string_view_t,
    mut literal: *const utf8_t,
    mut n: size_t,
) -> ::core::ffi::c_int {
    if n == -(1 as ::core::ffi::c_int) as size_t {
        n = strlen(literal as *const ::core::ffi::c_char);
    }
    let mut a_len: size_t = view.len;
    let mut b_len: size_t = n;
    let mut result: ::core::ffi::c_int = strncmp(
        view.data as *const ::core::ffi::c_char,
        literal as *const ::core::ffi::c_char,
        if a_len < b_len { a_len } else { b_len },
    );
    if result == 0 as ::core::ffi::c_int {
        return if a_len < b_len {
            -(1 as ::core::ffi::c_int)
        } else if a_len > b_len {
            1 as ::core::ffi::c_int
        } else {
            0 as ::core::ffi::c_int
        };
    }
    return result;
}
#[inline]
unsafe extern "C" fn utf8_string_substring(
    mut string: *const utf8_string_t,
    mut start: size_t,
    mut end: size_t,
) -> utf8_string_view_t {
    if end == -(1 as ::core::ffi::c_int) as size_t || end > (*string).len {
        end = (*string).len;
    }
    if start > end {
        start = end;
    }
    return utf8_string_view_init(
        &mut *(*string).data.offset(start as isize),
        end.wrapping_sub(start),
    );
}
#[inline]
unsafe extern "C" fn utf8_string_view_substring(
    view: utf8_string_view_t,
    mut start: size_t,
    mut end: size_t,
) -> utf8_string_view_t {
    if end == -(1 as ::core::ffi::c_int) as size_t || end > view.len {
        end = view.len;
    }
    if start > end {
        start = end;
    }
    return utf8_string_view_init(
        &*view.data.offset(start as isize),
        end.wrapping_sub(start),
    );
}
#[inline]
unsafe extern "C" fn utf8_string_substring_copy(
    mut string: *const utf8_string_t,
    mut start: size_t,
    mut end: size_t,
    mut result: *mut utf8_string_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    if end == -(1 as ::core::ffi::c_int) as size_t || end > (*string).len {
        end = (*string).len;
    }
    if start > end {
        start = end;
    }
    utf8_string_init(result);
    let mut len: size_t = end.wrapping_sub(start);
    err = utf8_string_reserve(result, len);
    if err < 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    memcpy(
        (*result).data as *mut ::core::ffi::c_void,
        &mut *(*string).data.offset(start as isize) as *mut utf8_t
            as *const ::core::ffi::c_void,
        len,
    );
    (*result).len = len;
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_view_substring_copy(
    view: utf8_string_view_t,
    mut start: size_t,
    mut end: size_t,
    mut result: *mut utf8_string_t,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    if end == -(1 as ::core::ffi::c_int) as size_t || end > view.len {
        end = view.len;
    }
    if start > end {
        start = end;
    }
    let mut len: size_t = end.wrapping_sub(start);
    err = utf8_string_reserve(result, len);
    if err < 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    memcpy(
        (*result).data as *mut ::core::ffi::c_void,
        &*view.data.offset(start as isize) as *const utf8_t
            as *const ::core::ffi::c_void,
        len,
    );
    (*result).len = len;
    return 0 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn utf8_string_index_of_character(
    mut string: *const utf8_string_t,
    mut pos: size_t,
    mut c: utf8_t,
) -> size_t {
    let mut i: size_t = pos;
    let mut n: size_t = (*string).len;
    while i < n {
        if *(*string).data.offset(i as isize) as ::core::ffi::c_int
            == c as ::core::ffi::c_int
        {
            return i;
        }
        i = i.wrapping_add(1);
    }
    return -(1 as ::core::ffi::c_int) as size_t;
}
#[inline]
unsafe extern "C" fn utf8_string_view_index_of_character(
    view: utf8_string_view_t,
    mut pos: size_t,
    mut c: utf8_t,
) -> size_t {
    let mut i: size_t = pos;
    let mut n: size_t = view.len;
    while i < n {
        if *view.data.offset(i as isize) as ::core::ffi::c_int == c as ::core::ffi::c_int
        {
            return i;
        }
        i = i.wrapping_add(1);
    }
    return -(1 as ::core::ffi::c_int) as size_t;
}
#[inline]
unsafe extern "C" fn utf8_string_last_index_of_character(
    mut string: *const utf8_string_t,
    mut pos: size_t,
    mut c: utf8_t,
) -> size_t {
    if pos == -(1 as ::core::ffi::c_int) as size_t {
        pos = (*string).len.wrapping_sub(1 as size_t);
    } else if pos >= (*string).len {
        return -(1 as ::core::ffi::c_int) as size_t
    }
    let mut i: size_t = pos;
    while i <= pos {
        if *(*string).data.offset(i as isize) as ::core::ffi::c_int
            == c as ::core::ffi::c_int
        {
            return i;
        }
        i = i.wrapping_sub(1);
    }
    return -(1 as ::core::ffi::c_int) as size_t;
}
#[inline]
unsafe extern "C" fn utf8_string_view_last_index_of_character(
    view: utf8_string_view_t,
    mut pos: size_t,
    mut c: utf8_t,
) -> size_t {
    if pos == -(1 as ::core::ffi::c_int) as size_t {
        pos = view.len.wrapping_sub(1 as size_t);
    } else if pos >= view.len {
        return -(1 as ::core::ffi::c_int) as size_t
    }
    let mut i: size_t = pos;
    while i <= pos {
        if *view.data.offset(i as isize) as ::core::ffi::c_int == c as ::core::ffi::c_int
        {
            return i;
        }
        i = i.wrapping_sub(1);
    }
    return -(1 as ::core::ffi::c_int) as size_t;
}
