#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type utf8_t = ::core::ffi::c_uchar;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn utf8_validate(
    mut data: *const utf8_t,
    mut len: size_t,
) -> bool {
    let mut pos: uint64_t = 0 as uint64_t;
    let mut word: uint8_t = 0;
    while pos < len as uint64_t {
        let mut next_pos: uint64_t = pos.wrapping_add(16 as uint64_t);
        if next_pos <= len as uint64_t {
            let mut v1: uint64_t = 0;
            memcpy(
                &mut v1 as *mut uint64_t as *mut ::core::ffi::c_void,
                data.offset(pos as isize) as *const ::core::ffi::c_void,
                ::core::mem::size_of::<uint64_t>() as size_t,
            );
            let mut v2: uint64_t = 0;
            memcpy(
                &mut v2 as *mut uint64_t as *mut ::core::ffi::c_void,
                data
                    .offset(pos as isize)
                    .offset(::core::mem::size_of::<uint64_t>() as usize as isize)
                    as *const ::core::ffi::c_void,
                ::core::mem::size_of::<uint64_t>() as size_t,
            );
            let mut v: uint64_t = v1 | v2;
            if v & 0x8080808080808080 as uint64_t == 0 as uint64_t {
                pos = next_pos;
                continue;
            }
        }
        word = *data.offset(pos as isize) as uint8_t;
        while (word as ::core::ffi::c_int) < 0o200 as ::core::ffi::c_int {
            pos = pos.wrapping_add(1);
            if pos == len as uint64_t {
                return true_0 != 0;
            }
            word = *data.offset(pos as isize) as uint8_t;
        }
        if word as ::core::ffi::c_int & 0o340 as ::core::ffi::c_int
            == 0o300 as ::core::ffi::c_int
        {
            next_pos = pos.wrapping_add(2 as uint64_t);
            if next_pos > len as uint64_t {
                return false_0 != 0;
            }
            if *data.offset(pos.wrapping_add(1 as uint64_t) as isize)
                as ::core::ffi::c_int & 0o300 as ::core::ffi::c_int
                != 0o200 as ::core::ffi::c_int
            {
                return false_0 != 0;
            }
            let mut code_point: uint32_t = ((word as ::core::ffi::c_int
                & 0o37 as ::core::ffi::c_int) << 6 as ::core::ffi::c_int
                | *data.offset(pos.wrapping_add(1 as uint64_t) as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int) as uint32_t;
            if code_point < 0x80 as uint32_t || (0x7ff as uint32_t) < code_point {
                return false_0 != 0;
            }
        } else if word as ::core::ffi::c_int & 0o360 as ::core::ffi::c_int
            == 0o340 as ::core::ffi::c_int
        {
            next_pos = pos.wrapping_add(3 as uint64_t);
            if next_pos > len as uint64_t {
                return false_0 != 0;
            }
            if *data.offset(pos.wrapping_add(1 as uint64_t) as isize)
                as ::core::ffi::c_int & 0o300 as ::core::ffi::c_int
                != 0o200 as ::core::ffi::c_int
            {
                return false_0 != 0;
            }
            if *data.offset(pos.wrapping_add(2 as uint64_t) as isize)
                as ::core::ffi::c_int & 0o300 as ::core::ffi::c_int
                != 0o200 as ::core::ffi::c_int
            {
                return false_0 != 0;
            }
            let mut code_point_0: uint32_t = ((word as ::core::ffi::c_int
                & 0o17 as ::core::ffi::c_int) << 12 as ::core::ffi::c_int
                | (*data.offset(pos.wrapping_add(1 as uint64_t) as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int)
                    << 6 as ::core::ffi::c_int
                | *data.offset(pos.wrapping_add(2 as uint64_t) as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int) as uint32_t;
            if code_point_0 < 0x800 as uint32_t || (0xffff as uint32_t) < code_point_0
                || (0xd7ff as uint32_t) < code_point_0
                    && code_point_0 < 0xe000 as uint32_t
            {
                return false_0 != 0;
            }
        } else if word as ::core::ffi::c_int & 0o370 as ::core::ffi::c_int
            == 0o360 as ::core::ffi::c_int
        {
            next_pos = pos.wrapping_add(4 as uint64_t);
            if next_pos > len as uint64_t {
                return false_0 != 0;
            }
            if *data.offset(pos.wrapping_add(1 as uint64_t) as isize)
                as ::core::ffi::c_int & 0o300 as ::core::ffi::c_int
                != 0o200 as ::core::ffi::c_int
            {
                return false_0 != 0;
            }
            if *data.offset(pos.wrapping_add(2 as uint64_t) as isize)
                as ::core::ffi::c_int & 0o300 as ::core::ffi::c_int
                != 0o200 as ::core::ffi::c_int
            {
                return false_0 != 0;
            }
            if *data.offset(pos.wrapping_add(3 as uint64_t) as isize)
                as ::core::ffi::c_int & 0o300 as ::core::ffi::c_int
                != 0o200 as ::core::ffi::c_int
            {
                return false_0 != 0;
            }
            let mut code_point_1: uint32_t = ((word as ::core::ffi::c_int
                & 0o7 as ::core::ffi::c_int) << 18 as ::core::ffi::c_int
                | (*data.offset(pos.wrapping_add(1 as uint64_t) as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int)
                    << 12 as ::core::ffi::c_int
                | (*data.offset(pos.wrapping_add(2 as uint64_t) as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int)
                    << 6 as ::core::ffi::c_int
                | *data.offset(pos.wrapping_add(3 as uint64_t) as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int) as uint32_t;
            if code_point_1 <= 0xffff as uint32_t
                || (0x10ffff as uint32_t) < code_point_1
            {
                return false_0 != 0;
            }
        } else {
            return false_0 != 0
        }
        pos = next_pos;
    }
    return true_0 != 0;
}
