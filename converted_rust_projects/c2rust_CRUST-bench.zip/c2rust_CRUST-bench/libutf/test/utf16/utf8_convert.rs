#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn memcmp(
        __s1: *const ::core::ffi::c_void,
        __s2: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> ::core::ffi::c_int;
    fn utf16le_convert_to_utf8(
        data: *const utf16_t,
        len: size_t,
        result: *mut utf8_t,
    ) -> size_t;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint16_t = u16;
pub type uint_least16_t = uint16_t;
pub type utf8_t = ::core::ffi::c_uchar;
pub type utf16_t = uint_least16_t;
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut result: [utf8_t; 3] = [0; 3];
    if !(utf16le_convert_to_utf8(
        b"a\0b\0c\0\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        3 as size_t,
        result.as_mut_ptr(),
    ) == 3 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf8-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            16 as ::core::ffi::c_int,
            b"utf16le_convert_to_utf8((utf16_t *) \"\\x61\\x00\\x62\\x00\\x63\\x00\", 3, result) == 3\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        b"abc\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        result.as_mut_ptr() as *const ::core::ffi::c_void,
        3 as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf8-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            16 as ::core::ffi::c_int,
            b"memcmp(\"abc\", result, 3) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut result_0: [utf8_t; 6] = [0; 6];
    if !(utf16le_convert_to_utf8(
        b"\xB1\x03\xB2\x03\xB3\x03\0" as *const u8 as *const ::core::ffi::c_char
            as *mut utf16_t,
        3 as size_t,
        result_0.as_mut_ptr(),
    ) == 6 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf8-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            19 as ::core::ffi::c_int,
            b"utf16le_convert_to_utf8((utf16_t *) \"\\xb1\\x03\\xb2\\x03\\xb3\\x03\", 3, result) == 6\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        b"\xCE\xB1\xCE\xB2\xCE\xB3\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        result_0.as_mut_ptr() as *const ::core::ffi::c_void,
        6 as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf8-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            19 as ::core::ffi::c_int,
            b"memcmp(\"\\xce\\xb1\\xce\\xb2\\xce\\xb3\", result, 6) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut result_1: [utf8_t; 9] = [0; 9];
    if !(utf16le_convert_to_utf8(
        b"Ng\xF3\x97-N\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        3 as size_t,
        result_1.as_mut_ptr(),
    ) == 9 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf8-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            22 as ::core::ffi::c_int,
            b"utf16le_convert_to_utf8((utf16_t *) \"\\x4e\\x67\\xf3\\x97\\x2d\\x4e\", 3, result) == 9\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        b"\xE6\x9D\x8E\xE9\x9F\xB3\xE4\xB8\xAD\0" as *const u8
            as *const ::core::ffi::c_char as *const ::core::ffi::c_void,
        result_1.as_mut_ptr() as *const ::core::ffi::c_void,
        9 as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf8-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            22 as ::core::ffi::c_int,
            b"memcmp(\"\\xe6\\x9d\\x8e\\xe9\\x9f\\xb3\\xe4\\xb8\\xad\", result, 9) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut result_2: [utf8_t; 6] = [0; 6];
    if !(utf16le_convert_to_utf8(
        b"a\0\xB1\x03Ng\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        3 as size_t,
        result_2.as_mut_ptr(),
    ) == 6 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf8-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            25 as ::core::ffi::c_int,
            b"utf16le_convert_to_utf8((utf16_t *) \"\\x61\\x00\\xb1\\x03\\x4e\\x67\", 3, result) == 6\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        b"a\xCE\xB1\xE6\x9D\x8E\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        result_2.as_mut_ptr() as *const ::core::ffi::c_void,
        6 as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf8-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            25 as ::core::ffi::c_int,
            b"memcmp(\"a\\xce\\xb1\\xe6\\x9d\\x8e\", result, 6) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut result_3: [utf8_t; 4] = [0; 4];
    if !(utf16le_convert_to_utf8(
        b"\0\xD87\xDC\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        2 as size_t,
        result_3.as_mut_ptr(),
    ) == 4 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf8-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            28 as ::core::ffi::c_int,
            b"utf16le_convert_to_utf8((utf16_t *) \"\\x00\\xd8\\x37\\xdc\", 2, result) == 4\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        b"\xF0\x90\x80\xB7\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        result_3.as_mut_ptr() as *const ::core::ffi::c_void,
        4 as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf8-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            28 as ::core::ffi::c_int,
            b"memcmp(\"\\xf0\\x90\\x80\\xb7\", result, 4) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    return 0;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
