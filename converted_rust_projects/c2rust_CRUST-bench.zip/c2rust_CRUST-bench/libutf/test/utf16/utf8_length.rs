#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn utf8_length_from_utf16le(data: *const utf16_t, len: size_t) -> size_t;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint16_t = u16;
pub type uint_least16_t = uint16_t;
pub type utf16_t = uint_least16_t;
unsafe fn main_0() -> ::core::ffi::c_int {
    if !(utf8_length_from_utf16le(
        b"A\0\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        1 as size_t,
    ) == 1 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf8-length.c\0" as *const u8 as *const ::core::ffi::c_char,
            13 as ::core::ffi::c_int,
            b"utf8_length_from_utf16le((utf16_t *) \"\\x41\\x00\", 1) == 1\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(utf8_length_from_utf16le(
        b"\xA9\x03\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        1 as size_t,
    ) == 2 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf8-length.c\0" as *const u8 as *const ::core::ffi::c_char,
            16 as ::core::ffi::c_int,
            b"utf8_length_from_utf16le((utf16_t *) \"\\xa9\\x03\", 1) == 2\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(utf8_length_from_utf16le(
        b"\x03&\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        1 as size_t,
    ) == 3 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf8-length.c\0" as *const u8 as *const ::core::ffi::c_char,
            19 as ::core::ffi::c_int,
            b"utf8_length_from_utf16le((utf16_t *) \"\\x03\\x26\", 1) == 3\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(utf8_length_from_utf16le(
        b"-N\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        1 as size_t,
    ) == 3 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf8-length.c\0" as *const u8 as *const ::core::ffi::c_char,
            22 as ::core::ffi::c_int,
            b"utf8_length_from_utf16le((utf16_t *) \"\\x2d\\x4e\", 1) == 3\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(utf8_length_from_utf16le(
        b"=\xD8\x02\xDE\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        2 as size_t,
    ) == 4 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf8-length.c\0" as *const u8 as *const ::core::ffi::c_char,
            25 as ::core::ffi::c_int,
            b"utf8_length_from_utf16le((utf16_t *) \"\\x3d\\xd8\\x02\\xde\", 2) == 4\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(utf8_length_from_utf16le(
        b"A\0\xA9\x03\x03&-N=\xD8\x02\xDE\0" as *const u8 as *const ::core::ffi::c_char
            as *mut utf16_t,
        6 as size_t,
    ) == 13 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf8-length.c\0" as *const u8 as *const ::core::ffi::c_char,
            28 as ::core::ffi::c_int,
            b"utf8_length_from_utf16le((utf16_t *) \"\\x41\\x00\\xa9\\x03\\x03\\x26\\x2d\\x4e\\x3d\\xd8\\x02\\xde\", 6) == 13\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return 0;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
