#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn utf16le_validate(data: *const utf16_t, len: size_t) -> bool;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint16_t = u16;
pub type uint_least16_t = uint16_t;
pub type utf16_t = uint_least16_t;
unsafe fn main_0() -> ::core::ffi::c_int {
    if !utf16le_validate(
        b"a\0\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        1 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate.c\0" as *const u8 as *const ::core::ffi::c_char,
            13 as ::core::ffi::c_int,
            b"utf16le_validate((utf16_t *) \"\\x61\\x00\", 1)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !utf16le_validate(
        b"H\0e\0l\0l\0o\0\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        5 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate.c\0" as *const u8 as *const ::core::ffi::c_char,
            16 as ::core::ffi::c_int,
            b"utf16le_validate((utf16_t *) \"\\x48\\x00\\x65\\x00\\x6c\\x00\\x6c\\x00\\x6f\\x00\", 5)\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !utf16le_validate(
        b"\xE8\0\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        1 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate.c\0" as *const u8 as *const ::core::ffi::c_char,
            19 as ::core::ffi::c_int,
            b"utf16le_validate((utf16_t *) \"\\xe8\\x00\", 1)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !utf16le_validate(
        b"\xE8\0\xE9\0\xEA\0\xEB\0\0" as *const u8 as *const ::core::ffi::c_char
            as *mut utf16_t,
        4 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate.c\0" as *const u8 as *const ::core::ffi::c_char,
            22 as ::core::ffi::c_int,
            b"utf16le_validate((utf16_t *) \"\\xe8\\x00\\xe9\\x00\\xea\\x00\\xeb\\x00\", 4)\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !utf16le_validate(
        b"\x01\xD87\xDC\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        2 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate.c\0" as *const u8 as *const ::core::ffi::c_char,
            25 as ::core::ffi::c_int,
            b"utf16le_validate((utf16_t *) \"\\x01\\xd8\\x37\\xdc\", 2)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !utf16le_validate(
        b"\x01\xD87\xDC?\xD8\x1F\xDC\0" as *const u8 as *const ::core::ffi::c_char
            as *mut utf16_t,
        4 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate.c\0" as *const u8 as *const ::core::ffi::c_char,
            28 as ::core::ffi::c_int,
            b"utf16le_validate((utf16_t *) \"\\x01\\xd8\\x37\\xdc\\x3f\\xd8\\x1f\\xdc\", 4)\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !utf16le_validate(
        b"H\0e\0l\0l\0o\0\x01\xD87\xDC\0" as *const u8 as *const ::core::ffi::c_char
            as *mut utf16_t,
        7 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate.c\0" as *const u8 as *const ::core::ffi::c_char,
            31 as ::core::ffi::c_int,
            b"utf16le_validate((utf16_t *) \"\\x48\\x00\\x65\\x00\\x6c\\x00\\x6c\\x00\\x6f\\x00\\x01\\xd8\\x37\\xdc\", 7)\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return 0;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
