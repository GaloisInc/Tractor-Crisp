#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn utf16le_validate(data: *const utf16_t, len: size_t) -> bool;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint16_t = u16;
pub type uint_least16_t = uint16_t;
pub type utf16_t = uint_least16_t;
unsafe fn main_0() -> ::core::ffi::c_int {
    if utf16le_validate(
        b"\x01\xD8\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        1 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            13 as ::core::ffi::c_int,
            b"!utf16le_validate((utf16_t *) \"\\x01\\xd8\", 1)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf16le_validate(
        b"7\xDC\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        1 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            16 as ::core::ffi::c_int,
            b"!utf16le_validate((utf16_t *) \"\\x37\\xdc\", 1)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf16le_validate(
        b"\x01\xD8\x02\xD8\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        2 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            19 as ::core::ffi::c_int,
            b"!utf16le_validate((utf16_t *) \"\\x01\\xd8\\x02\\xd8\", 2)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf16le_validate(
        b"7\xDC8\xDC\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        2 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            22 as ::core::ffi::c_int,
            b"!utf16le_validate((utf16_t *) \"\\x37\\xdc\\x38\\xdc\", 2)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf16le_validate(
        b"7\xDC\x01\xD8\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        2 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            37 as ::core::ffi::c_int,
            b"!utf16le_validate((utf16_t *) \"\\x37\\xdc\\x01\\xd8\", 2)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf16le_validate(
        b"\x01\xD8\x02\xD87\xDC\0" as *const u8 as *const ::core::ffi::c_char
            as *mut utf16_t,
        3 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            40 as ::core::ffi::c_int,
            b"!utf16le_validate((utf16_t *) \"\\x01\\xd8\\x02\\xd8\\x37\\xdc\", 3)\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if utf16le_validate(
        b"\x01\xD87\xDC8\xDC\0" as *const u8 as *const ::core::ffi::c_char
            as *mut utf16_t,
        3 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            43 as ::core::ffi::c_int,
            b"!utf16le_validate((utf16_t *) \"\\x01\\xd8\\x37\\xdc\\x38\\xdc\", 3)\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if utf16le_validate(
        b"\x01\xD8\x02\xD8\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        2 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            46 as ::core::ffi::c_int,
            b"!utf16le_validate((utf16_t *) \"\\x01\\xd8\\x02\\xd8\", 2)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf16le_validate(
        b"7\xDC8\xDC\0" as *const u8 as *const ::core::ffi::c_char as *mut utf16_t,
        2 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            49 as ::core::ffi::c_int,
            b"!utf16le_validate((utf16_t *) \"\\x37\\xdc\\x38\\xdc\", 2)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    return 0;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
