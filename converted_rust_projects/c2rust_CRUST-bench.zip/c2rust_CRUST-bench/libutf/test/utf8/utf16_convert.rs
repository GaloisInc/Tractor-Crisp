#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn memcmp(
        __s1: *const ::core::ffi::c_void,
        __s2: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> ::core::ffi::c_int;
    fn utf8_convert_to_utf16le(
        data: *const utf8_t,
        len: size_t,
        result: *mut utf16_t,
    ) -> size_t;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint16_t = u16;
pub type uint_least16_t = uint16_t;
pub type utf8_t = ::core::ffi::c_uchar;
pub type utf16_t = uint_least16_t;
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut result: [utf16_t; 1] = [0; 1];
    if !(utf8_convert_to_utf16le(
        b"A\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        1 as size_t,
        result.as_mut_ptr(),
    ) == 1 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            16 as ::core::ffi::c_int,
            b"utf8_convert_to_utf16le((utf8_t *) \"\\x41\", 1, result) == 1\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        b"A\0\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        result.as_mut_ptr() as *const ::core::ffi::c_void,
        1 as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            16 as ::core::ffi::c_int,
            b"memcmp(\"\\x41\\x00\", result, 1) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut result_0: [utf16_t; 1] = [0; 1];
    if !(utf8_convert_to_utf16le(
        b"\xCE\xA9\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        2 as size_t,
        result_0.as_mut_ptr(),
    ) == 1 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            19 as ::core::ffi::c_int,
            b"utf8_convert_to_utf16le((utf8_t *) \"\\xce\\xa9\", 2, result) == 1\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        b"\xA9\x03\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        result_0.as_mut_ptr() as *const ::core::ffi::c_void,
        1 as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            19 as ::core::ffi::c_int,
            b"memcmp(\"\\xa9\\x03\", result, 1) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut result_1: [utf16_t; 1] = [0; 1];
    if !(utf8_convert_to_utf16le(
        b"\xE2\x98\x83\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        3 as size_t,
        result_1.as_mut_ptr(),
    ) == 1 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            22 as ::core::ffi::c_int,
            b"utf8_convert_to_utf16le((utf8_t *) \"\\xe2\\x98\\x83\", 3, result) == 1\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        b"\x03&\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        result_1.as_mut_ptr() as *const ::core::ffi::c_void,
        1 as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            22 as ::core::ffi::c_int,
            b"memcmp(\"\\x03\\x26\", result, 1) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut result_2: [utf16_t; 1] = [0; 1];
    if !(utf8_convert_to_utf16le(
        b"\xE4\xB8\xAD\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        3 as size_t,
        result_2.as_mut_ptr(),
    ) == 1 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            25 as ::core::ffi::c_int,
            b"utf8_convert_to_utf16le((utf8_t *) \"\\xe4\\xb8\\xad\", 3, result) == 1\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        b"-N\0" as *const u8 as *const ::core::ffi::c_char as *const ::core::ffi::c_void,
        result_2.as_mut_ptr() as *const ::core::ffi::c_void,
        1 as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            25 as ::core::ffi::c_int,
            b"memcmp(\"\\x2d\\x4e\", result, 1) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut result_3: [utf16_t; 2] = [0; 2];
    if !(utf8_convert_to_utf16le(
        b"\xF0\x9F\x98\x82\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        4 as size_t,
        result_3.as_mut_ptr(),
    ) == 2 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            28 as ::core::ffi::c_int,
            b"utf8_convert_to_utf16le((utf8_t *) \"\\xf0\\x9f\\x98\\x82\", 4, result) == 2\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        b"=\xD8\x02\xDE\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        result_3.as_mut_ptr() as *const ::core::ffi::c_void,
        2 as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            28 as ::core::ffi::c_int,
            b"memcmp(\"\\x3d\\xd8\\x02\\xde\", result, 2) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut result_4: [utf16_t; 6] = [0; 6];
    if !(utf8_convert_to_utf16le(
        b"A\xCE\xA9\xE2\x98\x83\xE4\xB8\xAD\xF0\x9F\x98\x82\0" as *const u8
            as *const ::core::ffi::c_char as *mut utf8_t,
        13 as size_t,
        result_4.as_mut_ptr(),
    ) == 6 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            31 as ::core::ffi::c_int,
            b"utf8_convert_to_utf16le((utf8_t *) \"\\x41\\xce\\xa9\\xe2\\x98\\x83\\xe4\\xb8\\xad\\xf0\\x9f\\x98\\x82\", 13, result) == 6\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(memcmp(
        b"A\0\xA9\x03\x03&-N=\xD8\x02\xDE\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        result_4.as_mut_ptr() as *const ::core::ffi::c_void,
        6 as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-convert.c\0" as *const u8 as *const ::core::ffi::c_char,
            31 as ::core::ffi::c_int,
            b"memcmp(\"\\x41\\x00\\xa9\\x03\\x03\\x26\\x2d\\x4e\\x3d\\xd8\\x02\\xde\", result, 6) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return 0;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
