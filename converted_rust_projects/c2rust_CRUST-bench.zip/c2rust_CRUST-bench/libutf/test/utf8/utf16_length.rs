#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn utf16_length_from_utf8(data: *const utf8_t, len: size_t) -> size_t;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type utf8_t = ::core::ffi::c_uchar;
unsafe fn main_0() -> ::core::ffi::c_int {
    if !(utf16_length_from_utf8(
        b"A\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        1 as size_t,
    ) == 1 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-length.c\0" as *const u8 as *const ::core::ffi::c_char,
            13 as ::core::ffi::c_int,
            b"utf16_length_from_utf8((utf8_t *) \"\\x41\", 1) == 1\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(utf16_length_from_utf8(
        b"\xCE\xA9\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        2 as size_t,
    ) == 1 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-length.c\0" as *const u8 as *const ::core::ffi::c_char,
            16 as ::core::ffi::c_int,
            b"utf16_length_from_utf8((utf8_t *) \"\\xce\\xa9\", 2) == 1\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(utf16_length_from_utf8(
        b"\xE2\x98\x83\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        3 as size_t,
    ) == 1 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-length.c\0" as *const u8 as *const ::core::ffi::c_char,
            19 as ::core::ffi::c_int,
            b"utf16_length_from_utf8((utf8_t *) \"\\xe2\\x98\\x83\", 3) == 1\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(utf16_length_from_utf8(
        b"\xE4\xB8\xAD\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        3 as size_t,
    ) == 1 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-length.c\0" as *const u8 as *const ::core::ffi::c_char,
            22 as ::core::ffi::c_int,
            b"utf16_length_from_utf8((utf8_t *) \"\\xe4\\xb8\\xad\", 3) == 1\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(utf16_length_from_utf8(
        b"\xF0\x9F\x98\x82\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        4 as size_t,
    ) == 2 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-length.c\0" as *const u8 as *const ::core::ffi::c_char,
            25 as ::core::ffi::c_int,
            b"utf16_length_from_utf8((utf8_t *) \"\\xf0\\x9f\\x98\\x82\", 4) == 2\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(utf16_length_from_utf8(
        b"A\xCE\xA9\xE2\x98\x83\xE4\xB8\xAD\xF0\x9F\x98\x82\0" as *const u8
            as *const ::core::ffi::c_char as *mut utf8_t,
        13 as size_t,
    ) == 6 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"utf16-length.c\0" as *const u8 as *const ::core::ffi::c_char,
            28 as ::core::ffi::c_int,
            b"utf16_length_from_utf8((utf8_t *) \"\\x41\\xce\\xa9\\xe2\\x98\\x83\\xe4\\xb8\\xad\\xf0\\x9f\\x98\\x82\", 13) == 6\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return 0;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
