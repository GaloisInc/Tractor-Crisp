#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn utf8_validate(data: *const utf8_t, len: size_t) -> bool;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type utf8_t = ::core::ffi::c_uchar;
unsafe fn main_0() -> ::core::ffi::c_int {
    if !utf8_validate(
        b"a\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        1 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate.c\0" as *const u8 as *const ::core::ffi::c_char,
            12 as ::core::ffi::c_int,
            b"utf8_validate((utf8_t *) \"a\", 1)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !utf8_validate(
        b"Hello, World!\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        13 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate.c\0" as *const u8 as *const ::core::ffi::c_char,
            13 as ::core::ffi::c_int,
            b"utf8_validate((utf8_t *) \"Hello, World!\", 13)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !utf8_validate(
        b"\xC3\xA9\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        2 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate.c\0" as *const u8 as *const ::core::ffi::c_char,
            14 as ::core::ffi::c_int,
            b"utf8_validate((utf8_t *) \"\\xc3\\xa9\", 2)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !utf8_validate(
        b"\xC3\xA9\xC3\xA8\xC3\xAA\xC3\xAB\xC3\xAF\0" as *const u8
            as *const ::core::ffi::c_char as *mut utf8_t,
        10 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate.c\0" as *const u8 as *const ::core::ffi::c_char,
            15 as ::core::ffi::c_int,
            b"utf8_validate((utf8_t *) \"\\xc3\\xa9\\xc3\\xa8\\xc3\\xaa\\xc3\\xab\\xc3\\xaf\", 10)\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !utf8_validate(
        b"\xE2\x82\xAC\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        3 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate.c\0" as *const u8 as *const ::core::ffi::c_char,
            16 as ::core::ffi::c_int,
            b"utf8_validate((utf8_t *) \"\\xe2\\x82\\xac\", 3)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !utf8_validate(
        b"\xE2\x82\xAC\xE2\x89\xA1\xE2\x9C\x93\0" as *const u8
            as *const ::core::ffi::c_char as *mut utf8_t,
        9 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate.c\0" as *const u8 as *const ::core::ffi::c_char,
            17 as ::core::ffi::c_int,
            b"utf8_validate((utf8_t *) \"\\xe2\\x82\\xac\\xe2\\x89\\xa1\\xe2\\x9c\\x93\", 9)\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !utf8_validate(
        b"\xF0\x9F\x98\x80\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        4 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate.c\0" as *const u8 as *const ::core::ffi::c_char,
            18 as ::core::ffi::c_int,
            b"utf8_validate((utf8_t *) \"\\xf0\\x9f\\x98\\x80\", 4)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !utf8_validate(
        b"\xF0\x9F\x98\x80\xF0\x9F\x98\x81\xF0\x9F\x98\x82\0" as *const u8
            as *const ::core::ffi::c_char as *mut utf8_t,
        12 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate.c\0" as *const u8 as *const ::core::ffi::c_char,
            19 as ::core::ffi::c_int,
            b"utf8_validate((utf8_t *) \"\\xf0\\x9f\\x98\\x80\\xf0\\x9f\\x98\\x81\\xf0\\x9f\\x98\\x82\", 12)\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !utf8_validate(
        b"a \xC3\xA9 \xE2\x82\xAC \xF0\x9F\x98\x80\0" as *const u8
            as *const ::core::ffi::c_char as *mut utf8_t,
        13 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate.c\0" as *const u8 as *const ::core::ffi::c_char,
            20 as ::core::ffi::c_int,
            b"utf8_validate((utf8_t *) \"a \\xc3\\xa9 \\xe2\\x82\\xac \\xf0\\x9f\\x98\\x80\", 13)\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return 0;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
