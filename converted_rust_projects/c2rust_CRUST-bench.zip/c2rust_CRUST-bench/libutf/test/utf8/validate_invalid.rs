#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn utf8_validate(data: *const utf8_t, len: size_t) -> bool;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type utf8_t = ::core::ffi::c_uchar;
unsafe fn main_0() -> ::core::ffi::c_int {
    if utf8_validate(
        b"\x80\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        1 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            12 as ::core::ffi::c_int,
            b"!utf8_validate((utf8_t *) \"\\x80\", 1)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf8_validate(
        b"\xC3\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        1 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            13 as ::core::ffi::c_int,
            b"!utf8_validate((utf8_t *) \"\\xc3\", 1)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf8_validate(
        b"\xC0\x80\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        2 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            14 as ::core::ffi::c_int,
            b"!utf8_validate((utf8_t *) \"\\xc0\\x80\", 2)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf8_validate(
        b"\xC3\xA9\xA8\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        3 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            15 as ::core::ffi::c_int,
            b"!utf8_validate((utf8_t *) \"\\xc3\\xa9\\xa8\", 3)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf8_validate(
        b"\x80\x80\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        2 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            16 as ::core::ffi::c_int,
            b"!utf8_validate((utf8_t *) \"\\x80\\x80\", 2)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf8_validate(
        b"\xFE\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        1 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            17 as ::core::ffi::c_int,
            b"!utf8_validate((utf8_t *) \"\\xfe\", 1)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf8_validate(
        b"\xE2\x82\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        2 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            18 as ::core::ffi::c_int,
            b"!utf8_validate((utf8_t *) \"\\xe2\\x82\", 2)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf8_validate(
        b"\xF4\x90\x80\x80\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        4 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            19 as ::core::ffi::c_int,
            b"!utf8_validate((utf8_t *) \"\\xf4\\x90\\x80\\x80\", 4)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf8_validate(
        b"\xED\xA0\x80\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        3 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            20 as ::core::ffi::c_int,
            b"!utf8_validate((utf8_t *) \"\\xed\\xa0\\x80\", 3)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf8_validate(
        b"\xED\xBF\xBF\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        3 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            21 as ::core::ffi::c_int,
            b"!utf8_validate((utf8_t *) \"\\xed\\xbf\\xbf\", 3)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf8_validate(
        b"\xE2\x82\xC0\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        3 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            22 as ::core::ffi::c_int,
            b"!utf8_validate((utf8_t *) \"\\xe2\\x82\\xc0\", 3)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf8_validate(
        b"\x80\xC2\0" as *const u8 as *const ::core::ffi::c_char as *mut utf8_t,
        2 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            23 as ::core::ffi::c_int,
            b"!utf8_validate((utf8_t *) \"\\x80\\xc2\", 2)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf8_validate(
        b"\xF8\x88\x88\x88\x88\0" as *const u8 as *const ::core::ffi::c_char
            as *mut utf8_t,
        5 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            24 as ::core::ffi::c_int,
            b"!utf8_validate((utf8_t *) \"\\xf8\\x88\\x88\\x88\\x88\", 5)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if utf8_validate(
        b"\xFC\x84\x84\x84\x84\x84\0" as *const u8 as *const ::core::ffi::c_char
            as *mut utf8_t,
        6 as size_t,
    ) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"validate-invalid.c\0" as *const u8 as *const ::core::ffi::c_char,
            25 as ::core::ffi::c_int,
            b"!utf8_validate((utf8_t *) \"\\xfc\\x84\\x84\\x84\\x84\\x84\", 6)\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return 0;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
