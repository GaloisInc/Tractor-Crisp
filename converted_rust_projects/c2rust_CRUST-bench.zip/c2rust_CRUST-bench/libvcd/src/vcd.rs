#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types, linkage)]
extern "C" {
    pub type __sFILEX;
    static mut _DefaultRuneLocale: _RuneLocale;
    fn __maskrune(_: __darwin_ct_rune_t, _: ::core::ffi::c_ulong) -> ::core::ffi::c_int;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn fgetc(_: *mut FILE) -> ::core::ffi::c_int;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn fscanf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn sscanf(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn ungetc(_: ::core::ffi::c_int, _: *mut FILE) -> ::core::ffi::c_int;
    fn calloc(__count: size_t, __size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn strchr(
        __s: *const ::core::ffi::c_char,
        __c: ::core::ffi::c_int,
    ) -> *mut ::core::ffi::c_char;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strncpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> *mut ::core::ffi::c_char;
}
pub type __uint32_t = u32;
pub type __int64_t = i64;
pub type __darwin_ct_rune_t = ::core::ffi::c_int;
pub type __darwin_size_t = usize;
pub type __darwin_wchar_t = ::libc::wchar_t;
pub type __darwin_rune_t = __darwin_wchar_t;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneEntry {
    pub __min: __darwin_rune_t,
    pub __max: __darwin_rune_t,
    pub __map: __darwin_rune_t,
    pub __types: *mut __uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneRange {
    pub __nranges: ::core::ffi::c_int,
    pub __ranges: *mut _RuneEntry,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneCharClass {
    pub __name: [::core::ffi::c_char; 14],
    pub __mask: __uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneLocale {
    pub __magic: [::core::ffi::c_char; 8],
    pub __encoding: [::core::ffi::c_char; 32],
    pub __sgetrune: Option<
        unsafe extern "C" fn(
            *const ::core::ffi::c_char,
            __darwin_size_t,
            *mut *const ::core::ffi::c_char,
        ) -> __darwin_rune_t,
    >,
    pub __sputrune: Option<
        unsafe extern "C" fn(
            __darwin_rune_t,
            *mut ::core::ffi::c_char,
            __darwin_size_t,
            *mut *mut ::core::ffi::c_char,
        ) -> ::core::ffi::c_int,
    >,
    pub __invalid_rune: __darwin_rune_t,
    pub __runetype: [__uint32_t; 256],
    pub __maplower: [__darwin_rune_t; 256],
    pub __mapupper: [__darwin_rune_t; 256],
    pub __runetype_ext: _RuneRange,
    pub __maplower_ext: _RuneRange,
    pub __mapupper_ext: _RuneRange,
    pub __variable: *mut ::core::ffi::c_void,
    pub __variable_len: ::core::ffi::c_int,
    pub __ncharclasses: ::core::ffi::c_int,
    pub __charclasses: *mut _RuneCharClass,
}
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type uint32_t = u32;
pub type timestamp_t = uint32_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct value_change_t {
    pub timestamp: timestamp_t,
    pub value: [::core::ffi::c_char; 64],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct signal_t {
    pub name: [::core::ffi::c_char; 32],
    pub size: size_t,
    pub value_changes: [value_change_t; 4096],
    pub changes_count: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct timescale_t {
    pub unit: [::core::ffi::c_char; 8],
    pub scale: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct vcd_t {
    pub signals_count: size_t,
    pub signals: [signal_t; 32],
    pub date: [::core::ffi::c_char; 64],
    pub version: [::core::ffi::c_char; 64],
    pub timescale: timescale_t,
}
pub type state_t = ::core::ffi::c_uint;
pub const INSIDE_INNER_MODULES: state_t = 2;
pub const INSIDE_TOP_MODULE: state_t = 1;
pub const BEFORE_MODULE_DEFINITIONS: state_t = 0;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const _CTYPE_S: ::core::ffi::c_long = 0x4000 as ::core::ffi::c_long;
#[inline]
unsafe extern "C" fn isascii(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return (_c & !(0x7f as ::core::ffi::c_int) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn __istype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> ::core::ffi::c_int {
    return if isascii(_c as ::core::ffi::c_int) != 0 {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    } else {
        (__maskrune(_c, _f) != 0) as ::core::ffi::c_int
    };
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isspace(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_S as ::core::ffi::c_ulong);
}
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const EOF: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
pub const VCD_SIGNAL_COUNT: ::core::ffi::c_int = 32 as ::core::ffi::c_int;
pub const VCD_SIGNAL_SIZE: ::core::ffi::c_int = 64 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn vcd_read_from_path(
    mut path: *mut ::core::ffi::c_char,
) -> *mut vcd_t {
    let mut file: *mut FILE = fopen(
        path,
        b"r\0" as *const u8 as *const ::core::ffi::c_char,
    ) as *mut FILE;
    if file.is_null() {
        return 0 as *mut vcd_t;
    }
    let mut vcd: *mut vcd_t = new_vcd();
    let mut current_timestamp: timestamp_t = 0 as timestamp_t;
    let mut state: state_t = BEFORE_MODULE_DEFINITIONS;
    let mut character: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    loop {
        character = fgetc(file);
        if !(character != EOF) {
            break;
        }
        if character == '$' as i32 {
            let mut successful: bool = parse_instruction(file, vcd, &mut state);
            if successful {
                continue;
            }
        } else if character == '#' as i32 {
            let mut successful_0: bool = parse_timestamp(file, &mut current_timestamp);
            if successful_0 {
                continue;
            }
        } else if !strchr(
                b"-0123456789zZxXbU\0" as *const u8 as *const ::core::ffi::c_char,
                character,
            )
            .is_null()
        {
            ungetc(character, file);
            let mut successful_1: bool = parse_assignment(file, vcd, current_timestamp);
            if successful_1 {
                continue;
            }
        } else if isspace(character) != 0 {
            continue;
        }
        fclose(file);
        free(vcd as *mut ::core::ffi::c_void);
        return 0 as *mut vcd_t;
    }
    fclose(file);
    return vcd;
}
#[no_mangle]
pub unsafe extern "C" fn vcd_get_signal_by_name(
    mut vcd: *mut vcd_t,
    mut signal_name: *const ::core::ffi::c_char,
) -> *mut signal_t {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while (i as size_t) < (*vcd).signals_count {
        if strcmp(
            (*(*vcd).signals.as_mut_ptr().offset(i as isize)).name.as_mut_ptr(),
            signal_name,
        ) == 0 as ::core::ffi::c_int
        {
            return &mut *(*vcd).signals.as_mut_ptr().offset(i as isize) as *mut signal_t;
        }
        i += 1;
    }
    return 0 as *mut signal_t;
}
#[no_mangle]
pub unsafe extern "C" fn vcd_signal_get_value_at_timestamp(
    mut signal: *mut signal_t,
    mut timestamp: timestamp_t,
) -> *mut ::core::ffi::c_char {
    let mut previous_value: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while (i as size_t) < (*signal).changes_count {
        let mut value_change: *mut value_change_t = &mut *(*signal)
            .value_changes
            .as_mut_ptr()
            .offset(i as isize) as *mut value_change_t;
        if timestamp < (*value_change).timestamp {
            break;
        }
        previous_value = (*value_change).value.as_mut_ptr();
        i += 1;
    }
    return previous_value;
}
unsafe extern "C" fn new_vcd() -> *mut vcd_t {
    return calloc(1 as size_t, ::core::mem::size_of::<vcd_t>() as size_t) as *mut vcd_t;
}
unsafe extern "C" fn parse_instruction(
    mut file: *mut FILE,
    mut vcd: *mut vcd_t,
    mut state: *mut state_t,
) -> bool {
    let mut instruction: [::core::ffi::c_char; 512] = [0; 512];
    if fscanf(
        file,
        b"%s\0" as *const u8 as *const ::core::ffi::c_char,
        instruction.as_mut_ptr(),
    ) != 1 as ::core::ffi::c_int
    {
        return false_0 != 0;
    }
    if strcmp(
        instruction.as_mut_ptr(),
        b"end\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
        || strcmp(
            instruction.as_mut_ptr(),
            b"dumpvars\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        || strcmp(
            instruction.as_mut_ptr(),
            b"dumpall\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
    {
        return true_0 != 0;
    }
    if strcmp(
        instruction.as_mut_ptr(),
        b"scope\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
    {
        match *state as ::core::ffi::c_uint {
            0 => {
                *state = INSIDE_TOP_MODULE;
            }
            1 => {
                *state = INSIDE_INNER_MODULES;
            }
            _ => {}
        }
        fscanf(file, b"\n%*[^$]\0" as *const u8 as *const ::core::ffi::c_char);
        return true_0 != 0;
    }
    if strcmp(
        instruction.as_mut_ptr(),
        b"scope\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
        || strcmp(
            instruction.as_mut_ptr(),
            b"upscope\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        || strcmp(
            instruction.as_mut_ptr(),
            b"enddefinitions\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
        || strcmp(
            instruction.as_mut_ptr(),
            b"comment\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int
    {
        fscanf(file, b"\n%*[^$]\0" as *const u8 as *const ::core::ffi::c_char);
        return true_0 != 0;
    }
    if strcmp(
        instruction.as_mut_ptr(),
        b"var\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
    {
        if *state as ::core::ffi::c_uint
            == INSIDE_INNER_MODULES as ::core::ffi::c_int as ::core::ffi::c_uint
        {
            fscanf(file, b" %*[^\n]\n\0" as *const u8 as *const ::core::ffi::c_char);
            return true_0 != 0;
        }
        let mut signal: *mut signal_t = &mut *(*vcd)
            .signals
            .as_mut_ptr()
            .offset((*vcd).signals_count as isize) as *mut signal_t;
        (*vcd).signals_count = (*vcd).signals_count.wrapping_add(1 as size_t);
        let mut signal_id: [::core::ffi::c_char; 32] = [0; 32];
        fscanf(
            file,
            b" %*s %zu %[^ ] %[^ $]%*[^$]\0" as *const u8 as *const ::core::ffi::c_char,
            &mut (*signal).size as *mut size_t,
            signal_id.as_mut_ptr(),
            (*signal).name.as_mut_ptr(),
        );
        let mut index: ::core::ffi::c_int = get_signal_index(signal_id.as_mut_ptr());
        if (*vcd).signals[index as usize].size != 0 as size_t {
            return true_0 != 0;
        }
        return true_0 != 0;
    }
    if strcmp(
        instruction.as_mut_ptr(),
        b"date\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
    {
        fscanf(
            file,
            b"\n%[^$\n]\0" as *const u8 as *const ::core::ffi::c_char,
            (*vcd).date.as_mut_ptr(),
        );
        return true_0 != 0;
    }
    if strcmp(
        instruction.as_mut_ptr(),
        b"version\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
    {
        fscanf(
            file,
            b"\n%[^$\n]\0" as *const u8 as *const ::core::ffi::c_char,
            (*vcd).version.as_mut_ptr(),
        );
        return true_0 != 0;
    }
    if strcmp(
        instruction.as_mut_ptr(),
        b"timescale\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int
    {
        fscanf(
            file,
            b"\n\t%zu%[^$\n]\0" as *const u8 as *const ::core::ffi::c_char,
            &mut (*vcd).timescale.scale as *mut size_t,
            (*vcd).timescale.unit.as_mut_ptr(),
        );
        return true_0 != 0;
    }
    return false_0 != 0;
}
unsafe extern "C" fn parse_timestamp(
    mut file: *mut FILE,
    mut timestamp: *mut timestamp_t,
) -> bool {
    let mut successful: bool = fscanf(
        file,
        b"%u\0" as *const u8 as *const ::core::ffi::c_char,
        timestamp,
    ) == 1 as ::core::ffi::c_int;
    return successful;
}
unsafe extern "C" fn parse_assignment(
    mut file: *mut FILE,
    mut vcd: *mut vcd_t,
    mut timestamp: timestamp_t,
) -> bool {
    let mut buffer: [::core::ffi::c_char; 512] = [0; 512];
    let mut value: [::core::ffi::c_char; 64] = [0; 64];
    let mut signal_id: [::core::ffi::c_char; 32] = [0; 32];
    fscanf(
        file,
        b"%[^\n]\0" as *const u8 as *const ::core::ffi::c_char,
        buffer.as_mut_ptr(),
    );
    let mut is_vector: bool = strchr(
            b"01xXzZ\0" as *const u8 as *const ::core::ffi::c_char,
            buffer[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_int,
        )
        .is_null();
    let mut assignment_format_string: *mut ::core::ffi::c_char = (if is_vector
        as ::core::ffi::c_int != 0
    {
        b"%[^ ] %[^\n]\0" as *const u8 as *const ::core::ffi::c_char
    } else {
        b"%1s%[^\n]\0" as *const u8 as *const ::core::ffi::c_char
    }) as *mut ::core::ffi::c_char;
    if sscanf(
        buffer.as_mut_ptr(),
        assignment_format_string,
        value.as_mut_ptr(),
        signal_id.as_mut_ptr(),
    ) != 2 as ::core::ffi::c_int
    {
        return false_0 != 0;
    }
    if strlen(signal_id.as_mut_ptr()) > 1 as size_t {
        return true_0 != 0;
    }
    let mut index: size_t = get_signal_index(signal_id.as_mut_ptr()) as size_t;
    if index == -(1 as ::core::ffi::c_int) as size_t || index >= (*vcd).signals_count {
        return true_0 != 0;
    }
    let mut changes_count: size_t = (*vcd).signals[index as usize].changes_count;
    (*vcd).signals[index as usize].value_changes[changes_count as usize].timestamp = timestamp;
    strncpy(
        (*(*(*vcd).signals.as_mut_ptr().offset(index as isize))
            .value_changes
            .as_mut_ptr()
            .offset(changes_count as isize))
            .value
            .as_mut_ptr(),
        value.as_mut_ptr(),
        VCD_SIGNAL_SIZE as size_t,
    );
    (*vcd).signals[index as usize].changes_count = (*vcd)
        .signals[index as usize]
        .changes_count
        .wrapping_add(1 as size_t);
    return true_0 != 0;
}
unsafe extern "C" fn get_signal_index(
    mut string: *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut id: ::core::ffi::c_int = *string as ::core::ffi::c_int - '!' as i32;
    if id >= VCD_SIGNAL_COUNT {
        return -(1 as ::core::ffi::c_int);
    }
    return id;
}
