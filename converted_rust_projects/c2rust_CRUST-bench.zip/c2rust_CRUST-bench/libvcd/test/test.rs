#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn free(_: *mut ::core::ffi::c_void);
    fn exit(_: ::core::ffi::c_int) -> !;
    fn strtol(
        __str: *const ::core::ffi::c_char,
        __endptr: *mut *mut ::core::ffi::c_char,
        __base: ::core::ffi::c_int,
    ) -> ::core::ffi::c_long;
    fn vcd_read_from_path(path: *mut ::core::ffi::c_char) -> *mut vcd_t;
    fn vcd_get_signal_by_name(
        vcd: *mut vcd_t,
        signal_name: *const ::core::ffi::c_char,
    ) -> *mut signal_t;
    fn vcd_signal_get_value_at_timestamp(
        signal: *mut signal_t,
        timestamp: timestamp_t,
    ) -> *mut ::core::ffi::c_char;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type uint32_t = u32;
pub type timestamp_t = uint32_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct value_change_t {
    pub timestamp: timestamp_t,
    pub value: [::core::ffi::c_char; 64],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct signal_t {
    pub name: [::core::ffi::c_char; 32],
    pub size: size_t,
    pub value_changes: [value_change_t; 4096],
    pub changes_count: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct timescale_t {
    pub unit: [::core::ffi::c_char; 8],
    pub scale: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct vcd_t {
    pub signals_count: size_t,
    pub signals: [signal_t; 32],
    pub date: [::core::ffi::c_char; 64],
    pub version: [::core::ffi::c_char; 64],
    pub timescale: timescale_t,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const EXIT_FAILURE: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn print_vcd(mut vcd: *mut vcd_t) {
    printf(
        b"{\n\tdate=\"%s\",\n\tversion=\"%s\",\n\ttimescale= {\n\t\tunit=\"%s\",\n\t\tscale=\"%zu\"\n\t},\n\tsignal= {\n\0"
            as *const u8 as *const ::core::ffi::c_char,
        (*vcd).date.as_mut_ptr(),
        (*vcd).version.as_mut_ptr(),
        (*vcd).timescale.unit.as_mut_ptr(),
        (*vcd).timescale.scale,
    );
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while (i as size_t) < (*vcd).signals_count {
        printf(
            b"\t\t%s= {\n\t\t\tsize=%zu,\n\t\t\tchanges= {\n\0" as *const u8
                as *const ::core::ffi::c_char,
            (*(*vcd).signals.as_mut_ptr().offset(i as isize)).name.as_mut_ptr(),
            (*vcd).signals[i as usize].size,
        );
        let mut j: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while (j as size_t) < (*vcd).signals[i as usize].changes_count {
            printf(
                b"\t\t\t\t{\n\t\t\t\t\ttimestamp=%u,\n\t\t\t\t\tvalue=%s\n\t\t\t\t},\n\0"
                    as *const u8 as *const ::core::ffi::c_char,
                (*vcd).signals[i as usize].value_changes[j as usize].timestamp,
                (*(*(*vcd).signals.as_mut_ptr().offset(i as isize))
                    .value_changes
                    .as_mut_ptr()
                    .offset(j as isize))
                    .value
                    .as_mut_ptr(),
            );
            j += 1;
        }
        printf(b"\t\t\t},\n\t\t},\n\0" as *const u8 as *const ::core::ffi::c_char);
        i += 1;
    }
    printf(b"\t}\n}\n\0" as *const u8 as *const ::core::ffi::c_char);
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    if argc % 2 as ::core::ffi::c_int == 1 as ::core::ffi::c_int {
        fprintf(
            __stderrp,
            b"Usage: test <vcd-file> [signal-name timestamp] ...\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        exit(EXIT_FAILURE);
    }
    let mut vcd: *mut vcd_t = vcd_read_from_path(
        *argv.offset(1 as ::core::ffi::c_int as isize),
    );
    if vcd.is_null() {
        fprintf(
            __stderrp,
            b"Could not read the VCD\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut i: ::core::ffi::c_int = 2 as ::core::ffi::c_int;
    while i < argc {
        let mut signal_name: *mut ::core::ffi::c_char = *argv.offset(i as isize);
        let mut signal: *mut signal_t = vcd_get_signal_by_name(vcd, signal_name);
        let mut timestamp: timestamp_t = strtol(
            *argv.offset((i + 1 as ::core::ffi::c_int) as isize),
            0 as *mut *mut ::core::ffi::c_char,
            0 as ::core::ffi::c_int,
        ) as timestamp_t;
        printf(
            b"%s at %u equals %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            *argv.offset(i as isize),
            timestamp,
            vcd_signal_get_value_at_timestamp(signal, timestamp),
        );
        i += 2 as ::core::ffi::c_int;
    }
    free(vcd as *mut ::core::ffi::c_void);
    return 0;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
