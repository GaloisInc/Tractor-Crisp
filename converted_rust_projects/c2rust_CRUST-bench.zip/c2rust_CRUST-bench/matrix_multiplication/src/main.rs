#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn clock_gettime(__clock_id: clockid_t, __tp: *mut timespec) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn generate_matrix(
        matrix: *mut *mut *mut ::core::ffi::c_float,
        x: ::core::ffi::c_int,
        y: ::core::ffi::c_int,
        random: bool,
    ) -> ::core::ffi::c_int;
    fn free_matrix(
        matrix: *mut *mut *mut ::core::ffi::c_float,
        x: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn multiply(
        m1: *mut *mut ::core::ffi::c_float,
        m2: *mut *mut ::core::ffi::c_float,
        r: *mut *mut ::core::ffi::c_float,
        x1: ::core::ffi::c_int,
        y1: ::core::ffi::c_int,
        x2: ::core::ffi::c_int,
        y2: ::core::ffi::c_int,
        method: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
}
pub type __darwin_time_t = ::core::ffi::c_long;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct timespec {
    pub tv_sec: __darwin_time_t,
    pub tv_nsec: ::core::ffi::c_long,
}
pub type clockid_t = ::core::ffi::c_uint;
pub const _CLOCK_THREAD_CPUTIME_ID: clockid_t = 16;
pub const _CLOCK_PROCESS_CPUTIME_ID: clockid_t = 12;
pub const _CLOCK_UPTIME_RAW_APPROX: clockid_t = 9;
pub const _CLOCK_UPTIME_RAW: clockid_t = 8;
pub const _CLOCK_MONOTONIC_RAW_APPROX: clockid_t = 5;
pub const _CLOCK_MONOTONIC_RAW: clockid_t = 4;
pub const _CLOCK_MONOTONIC: clockid_t = 6;
pub const _CLOCK_REALTIME: clockid_t = 0;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn test_one(
    mut x1: ::core::ffi::c_int,
    mut y1: ::core::ffi::c_int,
    mut x2: ::core::ffi::c_int,
    mut y2: ::core::ffi::c_int,
    mut method: ::core::ffi::c_int,
    mut test_name: *mut ::core::ffi::c_char,
    mut time_taken: *mut ::core::ffi::c_long,
) -> ::core::ffi::c_int {
    let mut matrix1: *mut *mut ::core::ffi::c_float = 0
        as *mut *mut ::core::ffi::c_float;
    let mut matrix2: *mut *mut ::core::ffi::c_float = 0
        as *mut *mut ::core::ffi::c_float;
    let mut result: *mut *mut ::core::ffi::c_float = 0 as *mut *mut ::core::ffi::c_float;
    generate_matrix(&mut matrix1, x1, y1, true_0 != 0);
    generate_matrix(&mut matrix2, x2, y2, true_0 != 0);
    generate_matrix(&mut result, x1, y2, true_0 != 0);
    let mut lastSentTime: timespec = timespec { tv_sec: 0, tv_nsec: 0 };
    let mut sentTime: timespec = timespec { tv_sec: 0, tv_nsec: 0 };
    clock_gettime(_CLOCK_REALTIME, &mut lastSentTime);
    multiply(matrix1, matrix2, result, x1, y1, x2, y2, method);
    clock_gettime(_CLOCK_REALTIME, &mut sentTime);
    let mut time: ::core::ffi::c_long = (sentTime.tv_sec - lastSentTime.tv_sec)
        * 1000000000 as ::core::ffi::c_long;
    time += sentTime.tv_nsec - lastSentTime.tv_nsec;
    *time_taken += time;
    free_matrix(&mut matrix1, x1);
    free_matrix(&mut matrix2, x2);
    free_matrix(&mut result, x1);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn test_more(
    mut x1: ::core::ffi::c_int,
    mut y1: ::core::ffi::c_int,
    mut x2: ::core::ffi::c_int,
    mut y2: ::core::ffi::c_int,
    mut method: ::core::ffi::c_int,
    mut test_name: *mut ::core::ffi::c_char,
    mut times: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut time_taken: ::core::ffi::c_long = 0 as ::core::ffi::c_long;
    let mut lastSentTime: timespec = timespec { tv_sec: 0, tv_nsec: 0 };
    let mut sentTime: timespec = timespec { tv_sec: 0, tv_nsec: 0 };
    clock_gettime(_CLOCK_REALTIME, &mut lastSentTime);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < times {
        test_one(x1, y1, x2, y2, method, test_name, &mut time_taken);
        i += 1;
    }
    clock_gettime(_CLOCK_REALTIME, &mut sentTime);
    let mut time: ::core::ffi::c_long = (sentTime.tv_sec - lastSentTime.tv_sec)
        * 1000000000 as ::core::ffi::c_long;
    time += sentTime.tv_nsec - lastSentTime.tv_nsec;
    time /= 1000000 as ::core::ffi::c_long;
    printf(
        b"method: %d total consume: %ld ms\n\0" as *const u8
            as *const ::core::ffi::c_char,
        method,
        time,
    );
    printf(
        b"method: %d total time_taken only multiply: %ld ms\n================\n\0"
            as *const u8 as *const ::core::ffi::c_char,
        method,
        time_taken / 1000000 as ::core::ffi::c_long,
    );
    return 0 as ::core::ffi::c_int;
}
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut test_name: *mut ::core::ffi::c_char = b"method: 1\0" as *const u8
        as *const ::core::ffi::c_char as *mut ::core::ffi::c_char;
    let mut x1: ::core::ffi::c_int = 128 as ::core::ffi::c_int;
    let mut x2: ::core::ffi::c_int = 128 as ::core::ffi::c_int;
    let mut y1: ::core::ffi::c_int = 128 as ::core::ffi::c_int;
    let mut y2: ::core::ffi::c_int = 128 as ::core::ffi::c_int;
    let mut times: ::core::ffi::c_int = 1000 as ::core::ffi::c_int;
    let mut method: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    test_more(x1, y1, x2, y2, method, test_name, times);
    method = 2 as ::core::ffi::c_int;
    test_name = b"method: 2\0" as *const u8 as *const ::core::ffi::c_char
        as *mut ::core::ffi::c_char;
    test_more(x1, y1, x2, y2, method, test_name, times);
    method = 3 as ::core::ffi::c_int;
    test_name = b"method: 3\0" as *const u8 as *const ::core::ffi::c_char
        as *mut ::core::ffi::c_char;
    test_more(x1, y1, x2, y2, method, test_name, times);
    return 0;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
