#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn memcmp(
        __s1: *const ::core::ffi::c_void,
        __s2: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> ::core::ffi::c_int;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type int32_t = i32;
pub type uint8_t = u8;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type cbmt_cmp_fn = Option<
    unsafe extern "C" fn(
        *const ::core::ffi::c_void,
        *const ::core::ffi::c_void,
    ) -> ::core::ffi::c_int,
>;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct cbmt_buffer {
    pub data: *mut ::core::ffi::c_void,
    pub capacity: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct cbmt_node {
    pub bytes: [uint8_t; 4],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct cbmt_indices {
    pub values: *mut uint32_t,
    pub length: size_t,
    pub capacity: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct cbmt_proof {
    pub indices: cbmt_indices,
    pub lemmas: *mut cbmt_node,
    pub lemmas_length: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct cbmt_tree {
    pub nodes: *mut cbmt_node,
    pub length: size_t,
    pub capacity: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct cbmt_leaves {
    pub nodes: *mut cbmt_node,
    pub length: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct cbmt_queue {
    pub buffer: cbmt_buffer,
    pub width: size_t,
    pub length: size_t,
    pub capacity: size_t,
    pub tail: size_t,
    pub head: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct cbmt_node_pair {
    pub index: uint32_t,
    pub node: cbmt_node,
}
pub type cbmt_node_merge_fn = Option<
    unsafe extern "C" fn(
        *mut ::core::ffi::c_void,
        *mut cbmt_node,
        *mut cbmt_node,
    ) -> cbmt_node,
>;
pub type blake2b_constant = ::core::ffi::c_uint;
pub const BLAKE2B_PERSONALBYTES: blake2b_constant = 16;
pub const BLAKE2B_SALTBYTES: blake2b_constant = 16;
pub const BLAKE2B_KEYBYTES: blake2b_constant = 64;
pub const BLAKE2B_OUTBYTES: blake2b_constant = 64;
pub const BLAKE2B_BLOCKBYTES: blake2b_constant = 128;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct blake2b_state__ {
    pub h: [uint64_t; 8],
    pub t: [uint64_t; 2],
    pub f: [uint64_t; 2],
    pub buf: [uint8_t; 128],
    pub buflen: size_t,
    pub outlen: size_t,
    pub last_node: uint8_t,
}
pub type blake2b_state = blake2b_state__;
#[derive(Copy, Clone)]
#[repr(C, packed)]
pub struct blake2b_param__ {
    pub digest_length: uint8_t,
    pub key_length: uint8_t,
    pub fanout: uint8_t,
    pub depth: uint8_t,
    pub leaf_length: uint32_t,
    pub node_offset: uint32_t,
    pub xof_length: uint32_t,
    pub node_depth: uint8_t,
    pub inner_length: uint8_t,
    pub reserved: [uint8_t; 14],
    pub salt: [uint8_t; 16],
    pub personal: [uint8_t; 16],
}
pub type blake2b_param = blake2b_param__;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const CBMT_NODE_SIZE: ::core::ffi::c_int = 4 as ::core::ffi::c_int;
pub const CBMT_ERROR_OVER_CAPACITY: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
pub const CBMT_ERROR_QUEUE_EMPTY: ::core::ffi::c_int = -(2 as ::core::ffi::c_int);
pub const CBMT_ERROR_PROOF_ROOT: ::core::ffi::c_int = -(3 as ::core::ffi::c_int);
pub const CBMT_ERROR_BUILD_PROOF: ::core::ffi::c_int = -(4 as ::core::ffi::c_int);
pub const CBMT_ERROR_INVALID_CAPACITY: ::core::ffi::c_int = -(5 as ::core::ffi::c_int);
pub const CBMT_ERROR_VERIFY_FAILED: ::core::ffi::c_int = -(6 as ::core::ffi::c_int);
pub const CBMT_FATAL_BUILD_PROOF: ::core::ffi::c_int = -(99 as ::core::ffi::c_int);
#[no_mangle]
pub unsafe extern "C" fn cbmt_universal_swap(
    mut left: *mut ::core::ffi::c_void,
    mut right: *mut ::core::ffi::c_void,
    mut width: size_t,
) {
    let mut tmp: [uint8_t; 128] = [0; 128];
    let mut length: size_t = 0;
    while width != 0 {
        length = (if (::core::mem::size_of::<[uint8_t; 128]>() as usize) < width {
            ::core::mem::size_of::<[uint8_t; 128]>() as usize
        } else {
            width as usize
        }) as size_t;
        memcpy(tmp.as_mut_ptr() as *mut ::core::ffi::c_void, left, length);
        memcpy(left, right, length);
        memcpy(right, tmp.as_mut_ptr() as *const ::core::ffi::c_void, length);
        left = left.offset(length as isize);
        right = right.offset(length as isize);
        width = width.wrapping_sub(length);
    }
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_simple_bubble_sort(
    mut base: *mut ::core::ffi::c_void,
    mut length: size_t,
    mut width: size_t,
    mut cmp: cbmt_cmp_fn,
) {
    let mut i: size_t = 0 as size_t;
    while i < length.wrapping_sub(1 as size_t) {
        let mut j: size_t = i.wrapping_add(1 as size_t);
        while j < length {
            let mut left: *mut ::core::ffi::c_void = base
                .offset(i.wrapping_mul(width) as isize);
            let mut right: *mut ::core::ffi::c_void = base
                .offset(j.wrapping_mul(width) as isize);
            if cmp.expect("non-null function pointer")(left, right)
                > 0 as ::core::ffi::c_int
            {
                cbmt_universal_swap(left, right, width);
            }
            j = j.wrapping_add(1);
        }
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_uint32_reverse_cmp(
    mut void_left: *const ::core::ffi::c_void,
    mut void_right: *const ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    let left: uint32_t = *(void_left as *const uint32_t);
    let right: uint32_t = *(void_right as *const uint32_t);
    return right.wrapping_sub(left) as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_buffer_init(
    mut buffer: *mut cbmt_buffer,
    mut data: *mut ::core::ffi::c_void,
    mut capacity: size_t,
) {
    (*buffer).data = data;
    (*buffer).capacity = capacity;
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_leaves_init(
    mut leaves: *mut cbmt_leaves,
    mut nodes: *mut cbmt_node,
    mut length: size_t,
) {
    (*leaves).length = length;
    (*leaves).nodes = nodes;
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_indices_init(
    mut indices: *mut cbmt_indices,
    mut values: *mut uint32_t,
    mut length: size_t,
    mut capacity: size_t,
) {
    (*indices).values = values;
    (*indices).length = length;
    (*indices).capacity = capacity;
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_queue_init(
    mut queue: *mut cbmt_queue,
    mut buffer: cbmt_buffer,
    mut width: size_t,
    mut capacity: size_t,
) -> ::core::ffi::c_int {
    if capacity.wrapping_mul(width) > buffer.capacity {
        return CBMT_ERROR_OVER_CAPACITY;
    }
    if buffer.capacity.wrapping_rem(width) != 0 as size_t {
        return CBMT_ERROR_INVALID_CAPACITY;
    }
    (*queue).buffer = buffer;
    (*queue).capacity = capacity;
    (*queue).width = width;
    (*queue).length = 0 as size_t;
    (*queue).head = 0 as size_t;
    (*queue).tail = 0 as size_t;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_queue_push_back(
    mut queue: *mut cbmt_queue,
    mut item: *mut ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    if (*queue).length >= (*queue).capacity {
        return CBMT_ERROR_OVER_CAPACITY;
    }
    let mut head: *mut ::core::ffi::c_void = (*queue)
        .buffer
        .data
        .offset((*queue).head.wrapping_mul((*queue).width) as isize);
    memcpy(head, item, (*queue).width);
    (*queue).head = (*queue)
        .head
        .wrapping_add(1 as size_t)
        .wrapping_rem((*queue).capacity);
    (*queue).length = (*queue).length.wrapping_add(1 as size_t);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_queue_push_front(
    mut queue: *mut cbmt_queue,
    mut item: *mut ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    if (*queue).length >= (*queue).capacity {
        return CBMT_ERROR_OVER_CAPACITY;
    }
    (*queue).tail = (*queue)
        .tail
        .wrapping_add((*queue).capacity)
        .wrapping_sub(1 as size_t)
        .wrapping_rem((*queue).capacity);
    let mut tail: *mut ::core::ffi::c_void = (*queue)
        .buffer
        .data
        .offset((*queue).tail.wrapping_mul((*queue).width) as isize);
    memcpy(tail, item, (*queue).width);
    (*queue).length = (*queue).length.wrapping_add(1 as size_t);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_queue_pop_front(
    mut queue: *mut cbmt_queue,
    mut item: *mut ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    if (*queue).length == 0 as size_t {
        return CBMT_ERROR_QUEUE_EMPTY;
    }
    let mut current_tail: *mut ::core::ffi::c_void = (*queue)
        .buffer
        .data
        .offset((*queue).tail.wrapping_mul((*queue).width) as isize);
    memcpy(item, current_tail, (*queue).width);
    (*queue).tail = (*queue)
        .tail
        .wrapping_add(1 as size_t)
        .wrapping_rem((*queue).capacity);
    (*queue).length = (*queue).length.wrapping_sub(1 as size_t);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_queue_front(
    mut queue: *mut cbmt_queue,
) -> *mut ::core::ffi::c_void {
    if (*queue).length == 0 as size_t {
        return NULL;
    }
    return (*queue)
        .buffer
        .data
        .offset((*queue).tail.wrapping_mul((*queue).width) as isize);
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_node_copy(
    mut dest: *mut cbmt_node,
    mut src: *mut cbmt_node,
) {
    memcpy(
        (*dest).bytes.as_mut_ptr() as *mut ::core::ffi::c_void,
        (*src).bytes.as_mut_ptr() as *const ::core::ffi::c_void,
        CBMT_NODE_SIZE as size_t,
    );
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_node_cmp(
    mut void_left: *const ::core::ffi::c_void,
    mut void_right: *const ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    let mut left: *const cbmt_node = void_left as *const cbmt_node;
    let mut right: *const cbmt_node = void_right as *const cbmt_node;
    let mut left_value: int32_t = *((*left).bytes.as_ptr() as *mut int32_t);
    let mut right_value: int32_t = *((*right).bytes.as_ptr() as *mut int32_t);
    return left_value as ::core::ffi::c_int - right_value as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_node_pair_reverse_cmp(
    mut void_left: *const ::core::ffi::c_void,
    mut void_right: *const ::core::ffi::c_void,
) -> ::core::ffi::c_int {
    let mut left: *const cbmt_node_pair = void_left as *const cbmt_node_pair;
    let mut right: *const cbmt_node_pair = void_right as *const cbmt_node_pair;
    return (*right).index.wrapping_sub((*left).index) as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_tree_build_proof(
    mut proof: *mut cbmt_proof,
    mut tree: *mut cbmt_tree,
    mut leaf_indices: *mut cbmt_indices,
    mut indices_buffer: cbmt_buffer,
    mut lemmas_buffer: cbmt_buffer,
) -> ::core::ffi::c_int {
    if (*leaf_indices).length.wrapping_mul(::core::mem::size_of::<uint32_t>() as size_t)
        > indices_buffer.capacity
    {
        return CBMT_ERROR_OVER_CAPACITY;
    }
    if (*tree).length == 0 as size_t || (*leaf_indices).length == 0 as size_t {
        return CBMT_ERROR_BUILD_PROOF;
    }
    let mut ret: ::core::ffi::c_int = 0;
    let leaves_count: uint32_t = ((*tree).length >> 1 as ::core::ffi::c_int)
        .wrapping_add(1 as size_t) as uint32_t;
    let mut queue: cbmt_queue = cbmt_queue {
        buffer: cbmt_buffer {
            data: 0 as *mut ::core::ffi::c_void,
            capacity: 0,
        },
        width: 0,
        length: 0,
        capacity: 0,
        tail: 0,
        head: 0,
    };
    ret = cbmt_queue_init(
        &mut queue,
        indices_buffer,
        ::core::mem::size_of::<uint32_t>() as size_t,
        indices_buffer
            .capacity
            .wrapping_div(::core::mem::size_of::<uint32_t>() as size_t),
    );
    if ret != 0 as ::core::ffi::c_int {
        return ret;
    }
    let mut i: size_t = 0 as size_t;
    while i < (*leaf_indices).length {
        let mut value: uint32_t = (*(*leaf_indices).values.offset(i as isize))
            .wrapping_add(leaves_count.wrapping_sub(1 as uint32_t));
        ret = cbmt_queue_push_back(
            &mut queue,
            &mut value as *mut uint32_t as *mut ::core::ffi::c_void,
        );
        if ret != 0 as ::core::ffi::c_int {
            return ret;
        }
        i = i.wrapping_add(1);
    }
    cbmt_simple_bubble_sort(
        queue.buffer.data,
        (*leaf_indices).length,
        ::core::mem::size_of::<uint32_t>() as size_t,
        Some(
            cbmt_uint32_reverse_cmp
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                    *const ::core::ffi::c_void,
                ) -> ::core::ffi::c_int,
        ),
    );
    let mut first_value: uint32_t = *(cbmt_queue_front(&mut queue) as *mut uint32_t);
    if first_value
        >= (leaves_count << 1 as ::core::ffi::c_int).wrapping_sub(1 as uint32_t)
    {
        return CBMT_ERROR_BUILD_PROOF;
    }
    (*proof).lemmas = lemmas_buffer.data as *mut cbmt_node;
    (*proof).lemmas_length = 0 as size_t;
    let mut index: uint32_t = 0;
    while queue.length > 0 as size_t {
        ret = cbmt_queue_pop_front(
            &mut queue,
            &mut index as *mut uint32_t as *mut ::core::ffi::c_void,
        );
        if ret != 0 as ::core::ffi::c_int {
            return ret;
        }
        if index == 0 as uint32_t {
            if queue.length != 0 as size_t {
                return CBMT_FATAL_BUILD_PROOF;
            }
            break;
        } else {
            let mut sibling: uint32_t = if index == 0 as uint32_t {
                0 as uint32_t
            } else {
                (index.wrapping_add(1 as uint32_t) ^ 1 as uint32_t)
                    .wrapping_sub(1 as uint32_t)
            };
            let mut front: *mut uint32_t = cbmt_queue_front(&mut queue) as *mut uint32_t;
            if !front.is_null() && *front == sibling {
                let mut tmp: uint32_t = 0;
                ret = cbmt_queue_pop_front(
                    &mut queue,
                    &mut tmp as *mut uint32_t as *mut ::core::ffi::c_void,
                );
                if ret != 0 as ::core::ffi::c_int {
                    return ret;
                }
            } else {
                let mut dest_lemma: *mut cbmt_node = (*proof)
                    .lemmas
                    .offset((*proof).lemmas_length as isize);
                let mut src_lemma: *mut cbmt_node = (*tree)
                    .nodes
                    .offset(sibling as isize);
                cbmt_node_copy(dest_lemma, src_lemma);
                (*proof).lemmas_length = (*proof)
                    .lemmas_length
                    .wrapping_add(1 as size_t);
            }
            let mut parent: uint32_t = if index == 0 as uint32_t {
                0 as uint32_t
            } else {
                index.wrapping_sub(1 as uint32_t) >> 1 as ::core::ffi::c_int
            };
            if parent != 0 as uint32_t {
                ret = cbmt_queue_push_back(
                    &mut queue,
                    &mut parent as *mut uint32_t as *mut ::core::ffi::c_void,
                );
                if ret != 0 as ::core::ffi::c_int {
                    return ret;
                }
            }
        }
    }
    let mut indices: cbmt_indices = cbmt_indices {
        values: 0 as *mut uint32_t,
        length: 0,
        capacity: 0,
    };
    indices.values = indices_buffer.data as *mut uint32_t;
    indices.length = (*leaf_indices).length;
    indices.capacity = indices_buffer
        .capacity
        .wrapping_div(::core::mem::size_of::<uint32_t>() as size_t);
    let mut i_0: size_t = 0 as size_t;
    while i_0 < indices.length {
        *indices.values.offset(i_0 as isize) = (*(*leaf_indices)
            .values
            .offset(i_0 as isize))
            .wrapping_add(leaves_count.wrapping_sub(1 as uint32_t));
        i_0 = i_0.wrapping_add(1);
    }
    let mut i_1: size_t = 0 as size_t;
    while i_1 < indices.length.wrapping_sub(1 as size_t) {
        let mut j: size_t = i_1.wrapping_add(1 as size_t);
        while j < indices.length {
            let mut left_index: uint32_t = *indices.values.offset(i_1 as isize);
            let mut right_index: uint32_t = *indices.values.offset(j as isize);
            let mut order: ::core::ffi::c_int = cbmt_node_cmp(
                (*tree).nodes.offset(left_index as isize) as *const ::core::ffi::c_void,
                (*tree).nodes.offset(right_index as isize) as *const ::core::ffi::c_void,
            );
            if order > 0 as ::core::ffi::c_int {
                *indices.values.offset(i_1 as isize) = right_index;
                *indices.values.offset(j as isize) = left_index;
            }
            j = j.wrapping_add(1);
        }
        i_1 = i_1.wrapping_add(1);
    }
    (*proof).indices = indices;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_tree_root(mut tree: *mut cbmt_tree) -> cbmt_node {
    let mut node: cbmt_node = cbmt_node { bytes: [0; 4] };
    if (*tree).length == 0 as size_t {
        memset(
            node.bytes.as_mut_ptr() as *mut ::core::ffi::c_void,
            0 as ::core::ffi::c_int,
            CBMT_NODE_SIZE as size_t,
        );
    } else {
        cbmt_node_copy(&mut node, (*tree).nodes);
    }
    return node;
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_proof_root(
    mut proof: *mut cbmt_proof,
    mut root: *mut cbmt_node,
    mut leaves: *mut cbmt_leaves,
    mut merge: cbmt_node_merge_fn,
    mut merge_ctx: *mut ::core::ffi::c_void,
    mut nodes_buffer: cbmt_buffer,
    mut pairs_buffer: cbmt_buffer,
) -> ::core::ffi::c_int {
    if (*leaves).length.wrapping_mul(::core::mem::size_of::<cbmt_node>() as size_t)
        > nodes_buffer.capacity
    {
        return CBMT_ERROR_OVER_CAPACITY;
    }
    if (*leaves).length.wrapping_mul(::core::mem::size_of::<cbmt_node_pair>() as size_t)
        > pairs_buffer.capacity
    {
        return CBMT_ERROR_OVER_CAPACITY;
    }
    if (*leaves).length != (*proof).indices.length || (*leaves).length == 0 as size_t {
        return CBMT_ERROR_PROOF_ROOT;
    }
    let mut leaves_clone: cbmt_leaves = cbmt_leaves {
        nodes: 0 as *mut cbmt_node,
        length: 0,
    };
    leaves_clone.nodes = nodes_buffer.data as *mut cbmt_node;
    leaves_clone.length = (*leaves).length;
    let mut i: size_t = 0 as size_t;
    while i < (*leaves).length {
        cbmt_node_copy(
            leaves_clone.nodes.offset(i as isize),
            (*leaves).nodes.offset(i as isize),
        );
        i = i.wrapping_add(1);
    }
    cbmt_simple_bubble_sort(
        leaves_clone.nodes as *mut ::core::ffi::c_void,
        leaves_clone.length,
        ::core::mem::size_of::<cbmt_node>() as size_t,
        Some(
            cbmt_node_cmp
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                    *const ::core::ffi::c_void,
                ) -> ::core::ffi::c_int,
        ),
    );
    let mut ret: ::core::ffi::c_int = 0;
    let mut queue: cbmt_queue = cbmt_queue {
        buffer: cbmt_buffer {
            data: 0 as *mut ::core::ffi::c_void,
            capacity: 0,
        },
        width: 0,
        length: 0,
        capacity: 0,
        tail: 0,
        head: 0,
    };
    ret = cbmt_queue_init(
        &mut queue,
        pairs_buffer,
        ::core::mem::size_of::<cbmt_node_pair>() as size_t,
        (*leaves).length,
    );
    if ret != 0 as ::core::ffi::c_int {
        return ret;
    }
    let mut i_0: size_t = 0 as size_t;
    while i_0 < (*leaves).length {
        let mut pair: cbmt_node_pair = cbmt_node_pair {
            index: 0,
            node: cbmt_node { bytes: [0; 4] },
        };
        pair.index = *(*proof).indices.values.offset(i_0 as isize);
        cbmt_node_copy(&mut pair.node, leaves_clone.nodes.offset(i_0 as isize));
        ret = cbmt_queue_push_back(
            &mut queue,
            &mut pair as *mut cbmt_node_pair as *mut ::core::ffi::c_void,
        );
        if ret != 0 as ::core::ffi::c_int {
            return ret;
        }
        i_0 = i_0.wrapping_add(1);
    }
    cbmt_simple_bubble_sort(
        queue.buffer.data,
        queue.length,
        ::core::mem::size_of::<cbmt_node_pair>() as size_t,
        Some(
            cbmt_node_pair_reverse_cmp
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                    *const ::core::ffi::c_void,
                ) -> ::core::ffi::c_int,
        ),
    );
    let mut lemmas_offset: size_t = 0 as size_t;
    let mut pair_current: cbmt_node_pair = cbmt_node_pair {
        index: 0,
        node: cbmt_node { bytes: [0; 4] },
    };
    let mut pair_sibling: cbmt_node_pair = cbmt_node_pair {
        index: 0,
        node: cbmt_node { bytes: [0; 4] },
    };
    let mut index: uint32_t = 0;
    let mut node: *mut cbmt_node = 0 as *mut cbmt_node;
    while queue.length > 0 as size_t {
        ret = cbmt_queue_pop_front(
            &mut queue,
            &mut pair_current as *mut cbmt_node_pair as *mut ::core::ffi::c_void,
        );
        if ret != 0 as ::core::ffi::c_int {
            return ret;
        }
        index = pair_current.index;
        node = &mut pair_current.node;
        if index == 0 as uint32_t {
            if (*proof).lemmas_length == lemmas_offset && queue.length == 0 as size_t {
                cbmt_node_copy(root, node);
                return 0 as ::core::ffi::c_int;
            } else {
                return CBMT_ERROR_PROOF_ROOT
            }
        }
        let mut pair_front: *mut cbmt_node_pair = cbmt_queue_front(&mut queue)
            as *mut cbmt_node_pair;
        let mut sibling: *mut cbmt_node = 0 as *mut cbmt_node;
        if !pair_front.is_null()
            && (*pair_front).index
                == (if index == 0 as uint32_t {
                    0 as uint32_t
                } else {
                    (index.wrapping_add(1 as uint32_t) ^ 1 as uint32_t)
                        .wrapping_sub(1 as uint32_t)
                })
        {
            ret = cbmt_queue_pop_front(
                &mut queue,
                &mut pair_sibling as *mut cbmt_node_pair as *mut ::core::ffi::c_void,
            );
            if ret != 0 as ::core::ffi::c_int {
                return ret;
            }
            sibling = &mut pair_sibling.node;
        } else if lemmas_offset < (*proof).lemmas_length {
            sibling = (*proof).lemmas.offset(lemmas_offset as isize);
            lemmas_offset = lemmas_offset.wrapping_add(1 as size_t);
        }
        if !sibling.is_null() {
            let mut parent: cbmt_node = if index & 1 as uint32_t == 1 as uint32_t {
                merge.expect("non-null function pointer")(merge_ctx, node, sibling)
            } else {
                merge.expect("non-null function pointer")(merge_ctx, sibling, node)
            };
            let mut pair_parent: cbmt_node_pair = cbmt_node_pair {
                index: 0,
                node: cbmt_node { bytes: [0; 4] },
            };
            pair_parent.index = if index == 0 as uint32_t {
                0 as uint32_t
            } else {
                index.wrapping_sub(1 as uint32_t) >> 1 as ::core::ffi::c_int
            };
            pair_parent.node = parent;
            ret = cbmt_queue_push_back(
                &mut queue,
                &mut pair_parent as *mut cbmt_node_pair as *mut ::core::ffi::c_void,
            );
            if ret != 0 as ::core::ffi::c_int {
                return ret;
            }
        }
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_proof_verify(
    mut proof: *mut cbmt_proof,
    mut root: *mut cbmt_node,
    mut leaves: *mut cbmt_leaves,
    mut merge: cbmt_node_merge_fn,
    mut merge_ctx: *mut ::core::ffi::c_void,
    mut nodes_buffer: cbmt_buffer,
    mut pairs_buffer: cbmt_buffer,
) -> ::core::ffi::c_int {
    let mut target_root: cbmt_node = cbmt_node { bytes: [0; 4] };
    let mut ret: ::core::ffi::c_int = cbmt_proof_root(
        proof,
        &mut target_root,
        leaves,
        merge,
        merge_ctx,
        nodes_buffer,
        pairs_buffer,
    );
    if ret != 0 as ::core::ffi::c_int {
        return ret;
    }
    if memcmp(
        target_root.bytes.as_mut_ptr() as *const ::core::ffi::c_void,
        (*root).bytes.as_mut_ptr() as *const ::core::ffi::c_void,
        CBMT_NODE_SIZE as size_t,
    ) != 0 as ::core::ffi::c_int
    {
        return CBMT_ERROR_VERIFY_FAILED;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_build_merkle_root(
    mut root: *mut cbmt_node,
    mut leaves: *mut cbmt_leaves,
    mut merge: cbmt_node_merge_fn,
    mut merge_ctx: *mut ::core::ffi::c_void,
    mut nodes_buffer: cbmt_buffer,
) -> ::core::ffi::c_int {
    let mut length: size_t = (*leaves).length;
    if length == 0 as size_t {
        memset(
            (*root).bytes.as_mut_ptr() as *mut ::core::ffi::c_void,
            0 as ::core::ffi::c_int,
            CBMT_NODE_SIZE as size_t,
        );
        return 0 as ::core::ffi::c_int;
    }
    let mut capacity: size_t = length.wrapping_add(1 as size_t)
        >> 1 as ::core::ffi::c_int;
    if capacity > nodes_buffer.capacity {
        return CBMT_ERROR_OVER_CAPACITY;
    }
    let mut ret: ::core::ffi::c_int = 0;
    let mut queue: cbmt_queue = cbmt_queue {
        buffer: cbmt_buffer {
            data: 0 as *mut ::core::ffi::c_void,
            capacity: 0,
        },
        width: 0,
        length: 0,
        capacity: 0,
        tail: 0,
        head: 0,
    };
    ret = cbmt_queue_init(
        &mut queue,
        nodes_buffer,
        ::core::mem::size_of::<cbmt_node>() as size_t,
        capacity,
    );
    if ret != 0 as ::core::ffi::c_int {
        return ret;
    }
    let mut i: ::core::ffi::c_int = length.wrapping_sub(1 as size_t)
        as ::core::ffi::c_int;
    while i > 0 as ::core::ffi::c_int {
        let mut left: *mut cbmt_node = (*leaves)
            .nodes
            .offset(i as isize)
            .offset(-(1 as ::core::ffi::c_int as isize));
        let mut right: *mut cbmt_node = (*leaves).nodes.offset(i as isize);
        let mut merged: cbmt_node = merge
            .expect("non-null function pointer")(merge_ctx, left, right);
        ret = cbmt_queue_push_back(
            &mut queue,
            &mut merged as *mut cbmt_node as *mut ::core::ffi::c_void,
        );
        if ret != 0 as ::core::ffi::c_int {
            return ret;
        }
        i -= 2 as ::core::ffi::c_int;
    }
    if length.wrapping_rem(2 as size_t) == 1 as size_t {
        ret = cbmt_queue_push_front(
            &mut queue,
            (*leaves).nodes as *mut ::core::ffi::c_void,
        );
        if ret != 0 as ::core::ffi::c_int {
            return ret;
        }
    }
    while queue.length > 1 as size_t {
        let mut left_0: cbmt_node = cbmt_node { bytes: [0; 4] };
        let mut right_0: cbmt_node = cbmt_node { bytes: [0; 4] };
        ret = cbmt_queue_pop_front(
            &mut queue,
            &mut right_0 as *mut cbmt_node as *mut ::core::ffi::c_void,
        );
        if ret != 0 as ::core::ffi::c_int {
            return ret;
        }
        ret = cbmt_queue_pop_front(
            &mut queue,
            &mut left_0 as *mut cbmt_node as *mut ::core::ffi::c_void,
        );
        if ret != 0 as ::core::ffi::c_int {
            return ret;
        }
        let mut merged_0: cbmt_node = merge
            .expect("non-null function pointer")(merge_ctx, &mut left_0, &mut right_0);
        ret = cbmt_queue_push_back(
            &mut queue,
            &mut merged_0 as *mut cbmt_node as *mut ::core::ffi::c_void,
        );
        if ret != 0 as ::core::ffi::c_int {
            return ret;
        }
    }
    ret = cbmt_queue_pop_front(&mut queue, root as *mut ::core::ffi::c_void);
    if ret != 0 as ::core::ffi::c_int {
        return ret;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_build_merkle_tree(
    mut tree: *mut cbmt_tree,
    mut leaves: *mut cbmt_leaves,
    mut merge: cbmt_node_merge_fn,
    mut merge_ctx: *mut ::core::ffi::c_void,
    mut nodes_buffer: cbmt_buffer,
) -> ::core::ffi::c_int {
    (*tree).nodes = nodes_buffer.data as *mut cbmt_node;
    (*tree).capacity = nodes_buffer
        .capacity
        .wrapping_div(::core::mem::size_of::<cbmt_node>() as size_t);
    if (*leaves).length > 0 as size_t {
        let mut length: size_t = (*leaves)
            .length
            .wrapping_mul(2 as size_t)
            .wrapping_sub(1 as size_t);
        if length > (*tree).capacity {
            return CBMT_ERROR_OVER_CAPACITY;
        }
        (*tree).length = length;
        let mut offset: size_t = (*leaves).length.wrapping_sub(1 as size_t);
        let mut i: size_t = 0 as size_t;
        while i < (*leaves).length {
            let mut dest_node: *mut cbmt_node = (*tree)
                .nodes
                .offset(offset as isize)
                .offset(i as isize);
            let mut src_node: *mut cbmt_node = (*leaves).nodes.offset(i as isize);
            cbmt_node_copy(dest_node, src_node);
            i = i.wrapping_add(1);
        }
        let mut i_0: size_t = 0 as size_t;
        while i_0 < (*leaves).length.wrapping_sub(1 as size_t) {
            let mut rev_idx: size_t = (*leaves)
                .length
                .wrapping_sub(2 as size_t)
                .wrapping_sub(i_0);
            let mut target_node: *mut cbmt_node = (*tree).nodes.offset(rev_idx as isize);
            let mut left: *mut cbmt_node = (*tree)
                .nodes
                .offset(
                    (rev_idx << 1 as ::core::ffi::c_int).wrapping_add(1 as size_t)
                        as isize,
                );
            let mut right: *mut cbmt_node = (*tree)
                .nodes
                .offset(
                    (rev_idx << 1 as ::core::ffi::c_int).wrapping_add(2 as size_t)
                        as isize,
                );
            *target_node = merge
                .expect("non-null function pointer")(merge_ctx, left, right);
            i_0 = i_0.wrapping_add(1);
        }
    } else {
        (*tree).length = 0 as size_t;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn cbmt_build_merkle_proof(
    mut proof: *mut cbmt_proof,
    mut leaves: *mut cbmt_leaves,
    mut leaf_indices: *mut cbmt_indices,
    mut merge: cbmt_node_merge_fn,
    mut merge_ctx: *mut ::core::ffi::c_void,
    mut nodes_buffer: cbmt_buffer,
    mut indices_buffer: cbmt_buffer,
    mut lemmas_buffer: cbmt_buffer,
) -> ::core::ffi::c_int {
    let mut tree: cbmt_tree = cbmt_tree {
        nodes: 0 as *mut cbmt_node,
        length: 0,
        capacity: 0,
    };
    let mut ret: ::core::ffi::c_int = cbmt_build_merkle_tree(
        &mut tree,
        leaves,
        merge,
        merge_ctx,
        nodes_buffer,
    );
    if ret != 0 as ::core::ffi::c_int {
        return ret
    } else {
        return cbmt_tree_build_proof(
            proof,
            &mut tree,
            leaf_indices,
            indices_buffer,
            lemmas_buffer,
        )
    };
}
#[inline]
unsafe extern "C" fn load64(mut src: *const ::core::ffi::c_void) -> uint64_t {
    let mut p: *const uint8_t = src as *const uint8_t;
    return (*p.offset(0 as ::core::ffi::c_int as isize) as uint64_t)
        << 0 as ::core::ffi::c_int
        | (*p.offset(1 as ::core::ffi::c_int as isize) as uint64_t)
            << 8 as ::core::ffi::c_int
        | (*p.offset(2 as ::core::ffi::c_int as isize) as uint64_t)
            << 16 as ::core::ffi::c_int
        | (*p.offset(3 as ::core::ffi::c_int as isize) as uint64_t)
            << 24 as ::core::ffi::c_int
        | (*p.offset(4 as ::core::ffi::c_int as isize) as uint64_t)
            << 32 as ::core::ffi::c_int
        | (*p.offset(5 as ::core::ffi::c_int as isize) as uint64_t)
            << 40 as ::core::ffi::c_int
        | (*p.offset(6 as ::core::ffi::c_int as isize) as uint64_t)
            << 48 as ::core::ffi::c_int
        | (*p.offset(7 as ::core::ffi::c_int as isize) as uint64_t)
            << 56 as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn store32(mut dst: *mut ::core::ffi::c_void, mut w: uint32_t) {
    let mut p: *mut uint8_t = dst as *mut uint8_t;
    *p.offset(0 as ::core::ffi::c_int as isize) = (w >> 0 as ::core::ffi::c_int)
        as uint8_t;
    *p.offset(1 as ::core::ffi::c_int as isize) = (w >> 8 as ::core::ffi::c_int)
        as uint8_t;
    *p.offset(2 as ::core::ffi::c_int as isize) = (w >> 16 as ::core::ffi::c_int)
        as uint8_t;
    *p.offset(3 as ::core::ffi::c_int as isize) = (w >> 24 as ::core::ffi::c_int)
        as uint8_t;
}
#[inline]
unsafe extern "C" fn store64(mut dst: *mut ::core::ffi::c_void, mut w: uint64_t) {
    let mut p: *mut uint8_t = dst as *mut uint8_t;
    *p.offset(0 as ::core::ffi::c_int as isize) = (w >> 0 as ::core::ffi::c_int)
        as uint8_t;
    *p.offset(1 as ::core::ffi::c_int as isize) = (w >> 8 as ::core::ffi::c_int)
        as uint8_t;
    *p.offset(2 as ::core::ffi::c_int as isize) = (w >> 16 as ::core::ffi::c_int)
        as uint8_t;
    *p.offset(3 as ::core::ffi::c_int as isize) = (w >> 24 as ::core::ffi::c_int)
        as uint8_t;
    *p.offset(4 as ::core::ffi::c_int as isize) = (w >> 32 as ::core::ffi::c_int)
        as uint8_t;
    *p.offset(5 as ::core::ffi::c_int as isize) = (w >> 40 as ::core::ffi::c_int)
        as uint8_t;
    *p.offset(6 as ::core::ffi::c_int as isize) = (w >> 48 as ::core::ffi::c_int)
        as uint8_t;
    *p.offset(7 as ::core::ffi::c_int as isize) = (w >> 56 as ::core::ffi::c_int)
        as uint8_t;
}
#[inline]
unsafe extern "C" fn rotr64(w: uint64_t, c: ::core::ffi::c_uint) -> uint64_t {
    return w >> c | w << (64 as ::core::ffi::c_uint).wrapping_sub(c);
}
#[inline]
unsafe extern "C" fn secure_zero_memory(mut v: *mut ::core::ffi::c_void, mut n: size_t) {
    static mut memset_v: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            ::core::ffi::c_int,
            size_t,
        ) -> *mut ::core::ffi::c_void,
    > = Some(
        memset
            as unsafe extern "C" fn(
                *mut ::core::ffi::c_void,
                ::core::ffi::c_int,
                size_t,
            ) -> *mut ::core::ffi::c_void,
    );
    memset_v.expect("non-null function pointer")(v, 0 as ::core::ffi::c_int, n);
}
static mut blake2b_IV: [uint64_t; 8] = [
    0x6a09e667f3bcc908 as ::core::ffi::c_ulonglong,
    0xbb67ae8584caa73b as ::core::ffi::c_ulonglong,
    0x3c6ef372fe94f82b as ::core::ffi::c_ulonglong,
    0xa54ff53a5f1d36f1 as ::core::ffi::c_ulonglong,
    0x510e527fade682d1 as ::core::ffi::c_ulonglong,
    0x9b05688c2b3e6c1f as ::core::ffi::c_ulonglong,
    0x1f83d9abfb41bd6b as ::core::ffi::c_ulonglong,
    0x5be0cd19137e2179 as ::core::ffi::c_ulonglong,
];
static mut blake2b_sigma: [[uint8_t; 16]; 12] = [
    [
        0 as ::core::ffi::c_int as uint8_t,
        1 as ::core::ffi::c_int as uint8_t,
        2 as ::core::ffi::c_int as uint8_t,
        3 as ::core::ffi::c_int as uint8_t,
        4 as ::core::ffi::c_int as uint8_t,
        5 as ::core::ffi::c_int as uint8_t,
        6 as ::core::ffi::c_int as uint8_t,
        7 as ::core::ffi::c_int as uint8_t,
        8 as ::core::ffi::c_int as uint8_t,
        9 as ::core::ffi::c_int as uint8_t,
        10 as ::core::ffi::c_int as uint8_t,
        11 as ::core::ffi::c_int as uint8_t,
        12 as ::core::ffi::c_int as uint8_t,
        13 as ::core::ffi::c_int as uint8_t,
        14 as ::core::ffi::c_int as uint8_t,
        15 as ::core::ffi::c_int as uint8_t,
    ],
    [
        14 as ::core::ffi::c_int as uint8_t,
        10 as ::core::ffi::c_int as uint8_t,
        4 as ::core::ffi::c_int as uint8_t,
        8 as ::core::ffi::c_int as uint8_t,
        9 as ::core::ffi::c_int as uint8_t,
        15 as ::core::ffi::c_int as uint8_t,
        13 as ::core::ffi::c_int as uint8_t,
        6 as ::core::ffi::c_int as uint8_t,
        1 as ::core::ffi::c_int as uint8_t,
        12 as ::core::ffi::c_int as uint8_t,
        0 as ::core::ffi::c_int as uint8_t,
        2 as ::core::ffi::c_int as uint8_t,
        11 as ::core::ffi::c_int as uint8_t,
        7 as ::core::ffi::c_int as uint8_t,
        5 as ::core::ffi::c_int as uint8_t,
        3 as ::core::ffi::c_int as uint8_t,
    ],
    [
        11 as ::core::ffi::c_int as uint8_t,
        8 as ::core::ffi::c_int as uint8_t,
        12 as ::core::ffi::c_int as uint8_t,
        0 as ::core::ffi::c_int as uint8_t,
        5 as ::core::ffi::c_int as uint8_t,
        2 as ::core::ffi::c_int as uint8_t,
        15 as ::core::ffi::c_int as uint8_t,
        13 as ::core::ffi::c_int as uint8_t,
        10 as ::core::ffi::c_int as uint8_t,
        14 as ::core::ffi::c_int as uint8_t,
        3 as ::core::ffi::c_int as uint8_t,
        6 as ::core::ffi::c_int as uint8_t,
        7 as ::core::ffi::c_int as uint8_t,
        1 as ::core::ffi::c_int as uint8_t,
        9 as ::core::ffi::c_int as uint8_t,
        4 as ::core::ffi::c_int as uint8_t,
    ],
    [
        7 as ::core::ffi::c_int as uint8_t,
        9 as ::core::ffi::c_int as uint8_t,
        3 as ::core::ffi::c_int as uint8_t,
        1 as ::core::ffi::c_int as uint8_t,
        13 as ::core::ffi::c_int as uint8_t,
        12 as ::core::ffi::c_int as uint8_t,
        11 as ::core::ffi::c_int as uint8_t,
        14 as ::core::ffi::c_int as uint8_t,
        2 as ::core::ffi::c_int as uint8_t,
        6 as ::core::ffi::c_int as uint8_t,
        5 as ::core::ffi::c_int as uint8_t,
        10 as ::core::ffi::c_int as uint8_t,
        4 as ::core::ffi::c_int as uint8_t,
        0 as ::core::ffi::c_int as uint8_t,
        15 as ::core::ffi::c_int as uint8_t,
        8 as ::core::ffi::c_int as uint8_t,
    ],
    [
        9 as ::core::ffi::c_int as uint8_t,
        0 as ::core::ffi::c_int as uint8_t,
        5 as ::core::ffi::c_int as uint8_t,
        7 as ::core::ffi::c_int as uint8_t,
        2 as ::core::ffi::c_int as uint8_t,
        4 as ::core::ffi::c_int as uint8_t,
        10 as ::core::ffi::c_int as uint8_t,
        15 as ::core::ffi::c_int as uint8_t,
        14 as ::core::ffi::c_int as uint8_t,
        1 as ::core::ffi::c_int as uint8_t,
        11 as ::core::ffi::c_int as uint8_t,
        12 as ::core::ffi::c_int as uint8_t,
        6 as ::core::ffi::c_int as uint8_t,
        8 as ::core::ffi::c_int as uint8_t,
        3 as ::core::ffi::c_int as uint8_t,
        13 as ::core::ffi::c_int as uint8_t,
    ],
    [
        2 as ::core::ffi::c_int as uint8_t,
        12 as ::core::ffi::c_int as uint8_t,
        6 as ::core::ffi::c_int as uint8_t,
        10 as ::core::ffi::c_int as uint8_t,
        0 as ::core::ffi::c_int as uint8_t,
        11 as ::core::ffi::c_int as uint8_t,
        8 as ::core::ffi::c_int as uint8_t,
        3 as ::core::ffi::c_int as uint8_t,
        4 as ::core::ffi::c_int as uint8_t,
        13 as ::core::ffi::c_int as uint8_t,
        7 as ::core::ffi::c_int as uint8_t,
        5 as ::core::ffi::c_int as uint8_t,
        15 as ::core::ffi::c_int as uint8_t,
        14 as ::core::ffi::c_int as uint8_t,
        1 as ::core::ffi::c_int as uint8_t,
        9 as ::core::ffi::c_int as uint8_t,
    ],
    [
        12 as ::core::ffi::c_int as uint8_t,
        5 as ::core::ffi::c_int as uint8_t,
        1 as ::core::ffi::c_int as uint8_t,
        15 as ::core::ffi::c_int as uint8_t,
        14 as ::core::ffi::c_int as uint8_t,
        13 as ::core::ffi::c_int as uint8_t,
        4 as ::core::ffi::c_int as uint8_t,
        10 as ::core::ffi::c_int as uint8_t,
        0 as ::core::ffi::c_int as uint8_t,
        7 as ::core::ffi::c_int as uint8_t,
        6 as ::core::ffi::c_int as uint8_t,
        3 as ::core::ffi::c_int as uint8_t,
        9 as ::core::ffi::c_int as uint8_t,
        2 as ::core::ffi::c_int as uint8_t,
        8 as ::core::ffi::c_int as uint8_t,
        11 as ::core::ffi::c_int as uint8_t,
    ],
    [
        13 as ::core::ffi::c_int as uint8_t,
        11 as ::core::ffi::c_int as uint8_t,
        7 as ::core::ffi::c_int as uint8_t,
        14 as ::core::ffi::c_int as uint8_t,
        12 as ::core::ffi::c_int as uint8_t,
        1 as ::core::ffi::c_int as uint8_t,
        3 as ::core::ffi::c_int as uint8_t,
        9 as ::core::ffi::c_int as uint8_t,
        5 as ::core::ffi::c_int as uint8_t,
        0 as ::core::ffi::c_int as uint8_t,
        15 as ::core::ffi::c_int as uint8_t,
        4 as ::core::ffi::c_int as uint8_t,
        8 as ::core::ffi::c_int as uint8_t,
        6 as ::core::ffi::c_int as uint8_t,
        2 as ::core::ffi::c_int as uint8_t,
        10 as ::core::ffi::c_int as uint8_t,
    ],
    [
        6 as ::core::ffi::c_int as uint8_t,
        15 as ::core::ffi::c_int as uint8_t,
        14 as ::core::ffi::c_int as uint8_t,
        9 as ::core::ffi::c_int as uint8_t,
        11 as ::core::ffi::c_int as uint8_t,
        3 as ::core::ffi::c_int as uint8_t,
        0 as ::core::ffi::c_int as uint8_t,
        8 as ::core::ffi::c_int as uint8_t,
        12 as ::core::ffi::c_int as uint8_t,
        2 as ::core::ffi::c_int as uint8_t,
        13 as ::core::ffi::c_int as uint8_t,
        7 as ::core::ffi::c_int as uint8_t,
        1 as ::core::ffi::c_int as uint8_t,
        4 as ::core::ffi::c_int as uint8_t,
        10 as ::core::ffi::c_int as uint8_t,
        5 as ::core::ffi::c_int as uint8_t,
    ],
    [
        10 as ::core::ffi::c_int as uint8_t,
        2 as ::core::ffi::c_int as uint8_t,
        8 as ::core::ffi::c_int as uint8_t,
        4 as ::core::ffi::c_int as uint8_t,
        7 as ::core::ffi::c_int as uint8_t,
        6 as ::core::ffi::c_int as uint8_t,
        1 as ::core::ffi::c_int as uint8_t,
        5 as ::core::ffi::c_int as uint8_t,
        15 as ::core::ffi::c_int as uint8_t,
        11 as ::core::ffi::c_int as uint8_t,
        9 as ::core::ffi::c_int as uint8_t,
        14 as ::core::ffi::c_int as uint8_t,
        3 as ::core::ffi::c_int as uint8_t,
        12 as ::core::ffi::c_int as uint8_t,
        13 as ::core::ffi::c_int as uint8_t,
        0 as ::core::ffi::c_int as uint8_t,
    ],
    [
        0 as ::core::ffi::c_int as uint8_t,
        1 as ::core::ffi::c_int as uint8_t,
        2 as ::core::ffi::c_int as uint8_t,
        3 as ::core::ffi::c_int as uint8_t,
        4 as ::core::ffi::c_int as uint8_t,
        5 as ::core::ffi::c_int as uint8_t,
        6 as ::core::ffi::c_int as uint8_t,
        7 as ::core::ffi::c_int as uint8_t,
        8 as ::core::ffi::c_int as uint8_t,
        9 as ::core::ffi::c_int as uint8_t,
        10 as ::core::ffi::c_int as uint8_t,
        11 as ::core::ffi::c_int as uint8_t,
        12 as ::core::ffi::c_int as uint8_t,
        13 as ::core::ffi::c_int as uint8_t,
        14 as ::core::ffi::c_int as uint8_t,
        15 as ::core::ffi::c_int as uint8_t,
    ],
    [
        14 as ::core::ffi::c_int as uint8_t,
        10 as ::core::ffi::c_int as uint8_t,
        4 as ::core::ffi::c_int as uint8_t,
        8 as ::core::ffi::c_int as uint8_t,
        9 as ::core::ffi::c_int as uint8_t,
        15 as ::core::ffi::c_int as uint8_t,
        13 as ::core::ffi::c_int as uint8_t,
        6 as ::core::ffi::c_int as uint8_t,
        1 as ::core::ffi::c_int as uint8_t,
        12 as ::core::ffi::c_int as uint8_t,
        0 as ::core::ffi::c_int as uint8_t,
        2 as ::core::ffi::c_int as uint8_t,
        11 as ::core::ffi::c_int as uint8_t,
        7 as ::core::ffi::c_int as uint8_t,
        5 as ::core::ffi::c_int as uint8_t,
        3 as ::core::ffi::c_int as uint8_t,
    ],
];
unsafe extern "C" fn blake2b_set_lastnode(mut S: *mut blake2b_state) {
    (*S).f[1 as ::core::ffi::c_int as usize] = -(1 as ::core::ffi::c_int) as uint64_t;
}
unsafe extern "C" fn blake2b_is_lastblock(
    mut S: *const blake2b_state,
) -> ::core::ffi::c_int {
    return ((*S).f[0 as ::core::ffi::c_int as usize] != 0 as uint64_t)
        as ::core::ffi::c_int;
}
unsafe extern "C" fn blake2b_set_lastblock(mut S: *mut blake2b_state) {
    if (*S).last_node != 0 {
        blake2b_set_lastnode(S);
    }
    (*S).f[0 as ::core::ffi::c_int as usize] = -(1 as ::core::ffi::c_int) as uint64_t;
}
unsafe extern "C" fn blake2b_increment_counter(
    mut S: *mut blake2b_state,
    inc: uint64_t,
) {
    (*S).t[0 as ::core::ffi::c_int as usize] = (*S)
        .t[0 as ::core::ffi::c_int as usize]
        .wrapping_add(inc);
    (*S).t[1 as ::core::ffi::c_int as usize] = (*S)
        .t[1 as ::core::ffi::c_int as usize]
        .wrapping_add(
            ((*S).t[0 as ::core::ffi::c_int as usize] < inc) as ::core::ffi::c_int
                as uint64_t,
        );
}
unsafe extern "C" fn blake2b_init0(mut S: *mut blake2b_state) {
    let mut i: size_t = 0;
    memset(
        S as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<blake2b_state>() as size_t,
    );
    i = 0 as size_t;
    while i < 8 as size_t {
        (*S).h[i as usize] = blake2b_IV[i as usize];
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn blake2b_init_param(
    mut S: *mut blake2b_state,
    mut P: *const blake2b_param,
) -> ::core::ffi::c_int {
    let mut p: *const uint8_t = P as *const uint8_t;
    let mut i: size_t = 0;
    blake2b_init0(S);
    i = 0 as size_t;
    while i < 8 as size_t {
        (*S).h[i as usize]
            ^= load64(
                p
                    .offset(
                        (::core::mem::size_of::<uint64_t>() as usize)
                            .wrapping_mul(i as usize) as isize,
                    ) as *const ::core::ffi::c_void,
            );
        i = i.wrapping_add(1);
    }
    (*S).outlen = (*P).digest_length as size_t;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub static mut DEFAULT_PERSONAL: *const ::core::ffi::c_char = b"ckb-default-hash\0"
    as *const u8 as *const ::core::ffi::c_char;
#[no_mangle]
pub unsafe extern "C" fn blake2b_init(
    mut S: *mut blake2b_state,
    mut outlen: size_t,
) -> ::core::ffi::c_int {
    let mut P: [blake2b_param; 1] = [blake2b_param__ {
        digest_length: 0,
        key_length: 0,
        fanout: 0,
        depth: 0,
        leaf_length: 0,
        node_offset: 0,
        xof_length: 0,
        node_depth: 0,
        inner_length: 0,
        reserved: [0; 14],
        salt: [0; 16],
        personal: [0; 16],
    }; 1];
    if outlen == 0 || outlen > BLAKE2B_OUTBYTES as ::core::ffi::c_int as size_t {
        return -(1 as ::core::ffi::c_int);
    }
    (*P.as_mut_ptr()).digest_length = outlen as uint8_t;
    (*P.as_mut_ptr()).key_length = 0 as uint8_t;
    (*P.as_mut_ptr()).fanout = 1 as uint8_t;
    (*P.as_mut_ptr()).depth = 1 as uint8_t;
    store32(
        &mut (*P.as_mut_ptr()).leaf_length as *mut uint32_t as *mut ::core::ffi::c_void,
        0 as uint32_t,
    );
    store32(
        &mut (*P.as_mut_ptr()).node_offset as *mut uint32_t as *mut ::core::ffi::c_void,
        0 as uint32_t,
    );
    store32(
        &mut (*P.as_mut_ptr()).xof_length as *mut uint32_t as *mut ::core::ffi::c_void,
        0 as uint32_t,
    );
    (*P.as_mut_ptr()).node_depth = 0 as uint8_t;
    (*P.as_mut_ptr()).inner_length = 0 as uint8_t;
    memset(
        (*P.as_mut_ptr()).reserved.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<[uint8_t; 14]>() as size_t,
    );
    memset(
        (*P.as_mut_ptr()).salt.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<[uint8_t; 16]>() as size_t,
    );
    memset(
        (*P.as_mut_ptr()).personal.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<[uint8_t; 16]>() as size_t,
    );
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < BLAKE2B_PERSONALBYTES as ::core::ffi::c_int {
        (*P.as_mut_ptr()).personal[i as usize] = *DEFAULT_PERSONAL.offset(i as isize)
            as uint8_t;
        i += 1;
    }
    return blake2b_init_param(S, P.as_mut_ptr());
}
#[no_mangle]
pub unsafe extern "C" fn blake2b_init_key(
    mut S: *mut blake2b_state,
    mut outlen: size_t,
    mut key: *const ::core::ffi::c_void,
    mut keylen: size_t,
) -> ::core::ffi::c_int {
    let mut P: [blake2b_param; 1] = [blake2b_param__ {
        digest_length: 0,
        key_length: 0,
        fanout: 0,
        depth: 0,
        leaf_length: 0,
        node_offset: 0,
        xof_length: 0,
        node_depth: 0,
        inner_length: 0,
        reserved: [0; 14],
        salt: [0; 16],
        personal: [0; 16],
    }; 1];
    if outlen == 0 || outlen > BLAKE2B_OUTBYTES as ::core::ffi::c_int as size_t {
        return -(1 as ::core::ffi::c_int);
    }
    if key.is_null() || keylen == 0
        || keylen > BLAKE2B_KEYBYTES as ::core::ffi::c_int as size_t
    {
        return -(1 as ::core::ffi::c_int);
    }
    (*P.as_mut_ptr()).digest_length = outlen as uint8_t;
    (*P.as_mut_ptr()).key_length = keylen as uint8_t;
    (*P.as_mut_ptr()).fanout = 1 as uint8_t;
    (*P.as_mut_ptr()).depth = 1 as uint8_t;
    store32(
        &mut (*P.as_mut_ptr()).leaf_length as *mut uint32_t as *mut ::core::ffi::c_void,
        0 as uint32_t,
    );
    store32(
        &mut (*P.as_mut_ptr()).node_offset as *mut uint32_t as *mut ::core::ffi::c_void,
        0 as uint32_t,
    );
    store32(
        &mut (*P.as_mut_ptr()).xof_length as *mut uint32_t as *mut ::core::ffi::c_void,
        0 as uint32_t,
    );
    (*P.as_mut_ptr()).node_depth = 0 as uint8_t;
    (*P.as_mut_ptr()).inner_length = 0 as uint8_t;
    memset(
        (*P.as_mut_ptr()).reserved.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<[uint8_t; 14]>() as size_t,
    );
    memset(
        (*P.as_mut_ptr()).salt.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<[uint8_t; 16]>() as size_t,
    );
    memset(
        (*P.as_mut_ptr()).personal.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<[uint8_t; 16]>() as size_t,
    );
    if blake2b_init_param(S, P.as_mut_ptr()) < 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    let mut block: [uint8_t; 128] = [0; 128];
    memset(
        block.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        BLAKE2B_BLOCKBYTES as ::core::ffi::c_int as size_t,
    );
    memcpy(block.as_mut_ptr() as *mut ::core::ffi::c_void, key, keylen);
    blake2b_update(
        S,
        block.as_mut_ptr() as *const ::core::ffi::c_void,
        BLAKE2B_BLOCKBYTES as ::core::ffi::c_int as size_t,
    );
    secure_zero_memory(
        block.as_mut_ptr() as *mut ::core::ffi::c_void,
        BLAKE2B_BLOCKBYTES as ::core::ffi::c_int as size_t,
    );
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn blake2b_compress(
    mut S: *mut blake2b_state,
    mut block: *const uint8_t,
) {
    let mut m: [uint64_t; 16] = [0; 16];
    let mut v: [uint64_t; 16] = [0; 16];
    let mut i: size_t = 0;
    i = 0 as size_t;
    while i < 16 as size_t {
        m[i as usize] = load64(
            block
                .offset(
                    i.wrapping_mul(::core::mem::size_of::<uint64_t>() as size_t) as isize,
                ) as *const ::core::ffi::c_void,
        );
        i = i.wrapping_add(1);
    }
    i = 0 as size_t;
    while i < 8 as size_t {
        v[i as usize] = (*S).h[i as usize];
        i = i.wrapping_add(1);
    }
    v[8 as ::core::ffi::c_int as usize] = blake2b_IV[0 as ::core::ffi::c_int as usize];
    v[9 as ::core::ffi::c_int as usize] = blake2b_IV[1 as ::core::ffi::c_int as usize];
    v[10 as ::core::ffi::c_int as usize] = blake2b_IV[2 as ::core::ffi::c_int as usize];
    v[11 as ::core::ffi::c_int as usize] = blake2b_IV[3 as ::core::ffi::c_int as usize];
    v[12 as ::core::ffi::c_int as usize] = blake2b_IV[4 as ::core::ffi::c_int as usize]
        ^ (*S).t[0 as ::core::ffi::c_int as usize];
    v[13 as ::core::ffi::c_int as usize] = blake2b_IV[5 as ::core::ffi::c_int as usize]
        ^ (*S).t[1 as ::core::ffi::c_int as usize];
    v[14 as ::core::ffi::c_int as usize] = blake2b_IV[6 as ::core::ffi::c_int as usize]
        ^ (*S).f[0 as ::core::ffi::c_int as usize];
    v[15 as ::core::ffi::c_int as usize] = blake2b_IV[7 as ::core::ffi::c_int as usize]
        ^ (*S).f[1 as ::core::ffi::c_int as usize];
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[0 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[0 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[0 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[0 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[0 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[0 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[0 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[0 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[0 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[0 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[0 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[0 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[0 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[0 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[0 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[0 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[1 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[1 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[1 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[1 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[1 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[1 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[1 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[1 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[1 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[1 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[1 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[1 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[1 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[1 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[1 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[1 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[2 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[2 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[2 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[2 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[2 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[2 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[2 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[2 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[2 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[2 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[2 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[2 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[2 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[2 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[2 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[2 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[3 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[3 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[3 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[3 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[3 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[3 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[3 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[3 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[3 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[3 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[3 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[3 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[3 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[3 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[3 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[3 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[4 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[4 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[4 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[4 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[4 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[4 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[4 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[4 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[4 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[4 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[4 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[4 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[4 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[4 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[4 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[4 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[5 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[5 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[5 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[5 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[5 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[5 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[5 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[5 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[5 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[5 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[5 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[5 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[5 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[5 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[5 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[5 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[6 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[6 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[6 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[6 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[6 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[6 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[6 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[6 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[6 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[6 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[6 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[6 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[6 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[6 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[6 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[6 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[7 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[7 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[7 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[7 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[7 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[7 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[7 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[7 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[7 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[7 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[7 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[7 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[7 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[7 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[7 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[7 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[8 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[8 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[8 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[8 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[8 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[8 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[8 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[8 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[8 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[8 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[8 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[8 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[8 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[8 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[8 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[8 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[9 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[9 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[9 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[9 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[9 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[9 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[9 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[9 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[9 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[9 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[9 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[9 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[9 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[9 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[9 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[9 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[10 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[10 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[10 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[10 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[10 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[10 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[10 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[10 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[10 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[10 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[10 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[10 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[10 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[10 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[10 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[10 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[11 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[11 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 0 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[11 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[11 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 1 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[11 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[11 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[11 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[11 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[11 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[0 as ::core::ffi::c_int as usize] = v[0 as ::core::ffi::c_int as usize]
        .wrapping_add(v[5 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[11 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[15 as ::core::ffi::c_int as usize] = rotr64(
        v[15 as ::core::ffi::c_int as usize] ^ v[0 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[10 as ::core::ffi::c_int as usize] = v[10 as ::core::ffi::c_int as usize]
        .wrapping_add(v[15 as ::core::ffi::c_int as usize]);
    v[5 as ::core::ffi::c_int as usize] = rotr64(
        v[5 as ::core::ffi::c_int as usize] ^ v[10 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[11 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[1 as ::core::ffi::c_int as usize] = v[1 as ::core::ffi::c_int as usize]
        .wrapping_add(v[6 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[11 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 5 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[12 as ::core::ffi::c_int as usize] = rotr64(
        v[12 as ::core::ffi::c_int as usize] ^ v[1 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[11 as ::core::ffi::c_int as usize] = v[11 as ::core::ffi::c_int as usize]
        .wrapping_add(v[12 as ::core::ffi::c_int as usize]);
    v[6 as ::core::ffi::c_int as usize] = rotr64(
        v[6 as ::core::ffi::c_int as usize] ^ v[11 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[11 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[2 as ::core::ffi::c_int as usize] = v[2 as ::core::ffi::c_int as usize]
        .wrapping_add(v[7 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[11 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 6 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[13 as ::core::ffi::c_int as usize] = rotr64(
        v[13 as ::core::ffi::c_int as usize] ^ v[2 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[8 as ::core::ffi::c_int as usize] = v[8 as ::core::ffi::c_int as usize]
        .wrapping_add(v[13 as ::core::ffi::c_int as usize]);
    v[7 as ::core::ffi::c_int as usize] = rotr64(
        v[7 as ::core::ffi::c_int as usize] ^ v[8 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[11 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 0 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        32 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        24 as ::core::ffi::c_uint,
    );
    v[3 as ::core::ffi::c_int as usize] = v[3 as ::core::ffi::c_int as usize]
        .wrapping_add(v[4 as ::core::ffi::c_int as usize])
        .wrapping_add(
            m[blake2b_sigma[11 as ::core::ffi::c_int
                as usize][(2 as ::core::ffi::c_int * 7 as ::core::ffi::c_int
                + 1 as ::core::ffi::c_int) as usize] as usize],
        );
    v[14 as ::core::ffi::c_int as usize] = rotr64(
        v[14 as ::core::ffi::c_int as usize] ^ v[3 as ::core::ffi::c_int as usize],
        16 as ::core::ffi::c_uint,
    );
    v[9 as ::core::ffi::c_int as usize] = v[9 as ::core::ffi::c_int as usize]
        .wrapping_add(v[14 as ::core::ffi::c_int as usize]);
    v[4 as ::core::ffi::c_int as usize] = rotr64(
        v[4 as ::core::ffi::c_int as usize] ^ v[9 as ::core::ffi::c_int as usize],
        63 as ::core::ffi::c_uint,
    );
    i = 0 as size_t;
    while i < 8 as size_t {
        (*S).h[i as usize] = (*S).h[i as usize] ^ v[i as usize]
            ^ v[i.wrapping_add(8 as size_t) as usize];
        i = i.wrapping_add(1);
    }
}
#[no_mangle]
pub unsafe extern "C" fn blake2b_update(
    mut S: *mut blake2b_state,
    mut pin: *const ::core::ffi::c_void,
    mut inlen: size_t,
) -> ::core::ffi::c_int {
    let mut in_0: *const ::core::ffi::c_uchar = pin as *const ::core::ffi::c_uchar;
    if inlen > 0 as size_t {
        let mut left: size_t = (*S).buflen;
        let mut fill: size_t = (BLAKE2B_BLOCKBYTES as ::core::ffi::c_int as size_t)
            .wrapping_sub(left);
        if inlen > fill {
            (*S).buflen = 0 as size_t;
            memcpy(
                (*S).buf.as_mut_ptr().offset(left as isize) as *mut ::core::ffi::c_void,
                in_0 as *const ::core::ffi::c_void,
                fill,
            );
            blake2b_increment_counter(
                S,
                BLAKE2B_BLOCKBYTES as ::core::ffi::c_int as uint64_t,
            );
            blake2b_compress(S, (*S).buf.as_mut_ptr() as *const uint8_t);
            in_0 = in_0.offset(fill as isize);
            inlen = inlen.wrapping_sub(fill);
            while inlen > BLAKE2B_BLOCKBYTES as ::core::ffi::c_int as size_t {
                blake2b_increment_counter(
                    S,
                    BLAKE2B_BLOCKBYTES as ::core::ffi::c_int as uint64_t,
                );
                blake2b_compress(S, in_0 as *const uint8_t);
                in_0 = in_0.offset(BLAKE2B_BLOCKBYTES as ::core::ffi::c_int as isize);
                inlen = inlen
                    .wrapping_sub(BLAKE2B_BLOCKBYTES as ::core::ffi::c_int as size_t);
            }
        }
        memcpy(
            (*S).buf.as_mut_ptr().offset((*S).buflen as isize)
                as *mut ::core::ffi::c_void,
            in_0 as *const ::core::ffi::c_void,
            inlen,
        );
        (*S).buflen = (*S).buflen.wrapping_add(inlen);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn blake2b_final(
    mut S: *mut blake2b_state,
    mut out: *mut ::core::ffi::c_void,
    mut outlen: size_t,
) -> ::core::ffi::c_int {
    let mut buffer: [uint8_t; 64] = [
        0 as ::core::ffi::c_int as uint8_t,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    let mut i: size_t = 0;
    if out.is_null() || outlen < (*S).outlen {
        return -(1 as ::core::ffi::c_int);
    }
    if blake2b_is_lastblock(S) != 0 {
        return -(1 as ::core::ffi::c_int);
    }
    blake2b_increment_counter(S, (*S).buflen as uint64_t);
    blake2b_set_lastblock(S);
    memset(
        (*S).buf.as_mut_ptr().offset((*S).buflen as isize) as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        (BLAKE2B_BLOCKBYTES as ::core::ffi::c_int as size_t).wrapping_sub((*S).buflen),
    );
    blake2b_compress(S, (*S).buf.as_mut_ptr() as *const uint8_t);
    i = 0 as size_t;
    while i < 8 as size_t {
        store64(
            buffer
                .as_mut_ptr()
                .offset(
                    (::core::mem::size_of::<uint64_t>() as usize)
                        .wrapping_mul(i as usize) as isize,
                ) as *mut ::core::ffi::c_void,
            (*S).h[i as usize],
        );
        i = i.wrapping_add(1);
    }
    memcpy(out, buffer.as_mut_ptr() as *const ::core::ffi::c_void, (*S).outlen);
    secure_zero_memory(
        buffer.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[uint8_t; 64]>() as size_t,
    );
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn blake2b(
    mut out: *mut ::core::ffi::c_void,
    mut outlen: size_t,
    mut in_0: *const ::core::ffi::c_void,
    mut inlen: size_t,
    mut key: *const ::core::ffi::c_void,
    mut keylen: size_t,
) -> ::core::ffi::c_int {
    let mut S: [blake2b_state; 1] = [blake2b_state__ {
        h: [0; 8],
        t: [0; 2],
        f: [0; 2],
        buf: [0; 128],
        buflen: 0,
        outlen: 0,
        last_node: 0,
    }; 1];
    if in_0.is_null() && inlen > 0 as size_t {
        return -(1 as ::core::ffi::c_int);
    }
    if out.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    if key.is_null() && keylen > 0 as size_t {
        return -(1 as ::core::ffi::c_int);
    }
    if outlen == 0 || outlen > BLAKE2B_OUTBYTES as ::core::ffi::c_int as size_t {
        return -(1 as ::core::ffi::c_int);
    }
    if keylen > BLAKE2B_KEYBYTES as ::core::ffi::c_int as size_t {
        return -(1 as ::core::ffi::c_int);
    }
    if keylen > 0 as size_t {
        if blake2b_init_key(S.as_mut_ptr(), outlen, key, keylen)
            < 0 as ::core::ffi::c_int
        {
            return -(1 as ::core::ffi::c_int);
        }
    } else if blake2b_init(S.as_mut_ptr(), outlen) < 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int)
    }
    blake2b_update(
        S.as_mut_ptr(),
        in_0 as *const uint8_t as *const ::core::ffi::c_void,
        inlen,
    );
    blake2b_final(S.as_mut_ptr(), out, outlen);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn blake2(
    mut out: *mut ::core::ffi::c_void,
    mut outlen: size_t,
    mut in_0: *const ::core::ffi::c_void,
    mut inlen: size_t,
    mut key: *const ::core::ffi::c_void,
    mut keylen: size_t,
) -> ::core::ffi::c_int {
    return blake2b(out, outlen, in_0, inlen, key, keylen);
}
#[no_mangle]
pub unsafe extern "C" fn node_merge(
    mut merge_ctx: *mut ::core::ffi::c_void,
    mut left: *mut cbmt_node,
    mut right: *mut cbmt_node,
) -> cbmt_node {
    let mut ret: cbmt_node = cbmt_node { bytes: [0; 4] };
    let mut left_value: int32_t = *((*left).bytes.as_mut_ptr() as *mut int32_t);
    let mut right_value: int32_t = *((*right).bytes.as_mut_ptr() as *mut int32_t);
    let mut value: int32_t = right_value - left_value;
    memcpy(
        ret.bytes.as_mut_ptr() as *mut ::core::ffi::c_void,
        &mut value as *mut int32_t as *const ::core::ffi::c_void,
        4 as size_t,
    );
    return ret;
}
#[no_mangle]
pub unsafe extern "C" fn int32_to_node(mut value: int32_t) -> cbmt_node {
    let mut node: cbmt_node = cbmt_node { bytes: [0; 4] };
    memcpy(
        node.bytes.as_mut_ptr() as *mut ::core::ffi::c_void,
        &mut value as *mut int32_t as *const ::core::ffi::c_void,
        ::core::mem::size_of::<int32_t>() as size_t,
    );
    return node;
}
#[no_mangle]
pub unsafe extern "C" fn node_to_int32(mut node: cbmt_node) -> int32_t {
    return *(node.bytes.as_mut_ptr() as *mut int32_t);
}
unsafe fn main_0() -> ::core::ffi::c_int {
    test_build_empty();
    test_build_five();
    test_build_root_directly_2leaves();
    test_build_root_directly();
    test_rebuild_proof();
    test_build_proof();
    return 0;
}
#[no_mangle]
pub unsafe extern "C" fn test_build_empty() {
    let mut nodes: [cbmt_node; 1024] = [cbmt_node { bytes: [0; 4] }; 1024];
    let mut leaf_nodes: [cbmt_node; 256] = [cbmt_node { bytes: [0; 4] }; 256];
    let mut nodes_buffer: cbmt_buffer = cbmt_buffer {
        data: 0 as *mut ::core::ffi::c_void,
        capacity: 0,
    };
    cbmt_buffer_init(
        &mut nodes_buffer,
        nodes.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[cbmt_node; 1024]>() as size_t,
    );
    let mut ret: ::core::ffi::c_int = 0;
    let mut tree: cbmt_tree = cbmt_tree {
        nodes: 0 as *mut cbmt_node,
        length: 0,
        capacity: 0,
    };
    let mut leaves: cbmt_leaves = cbmt_leaves {
        nodes: 0 as *mut cbmt_node,
        length: 0,
    };
    cbmt_leaves_init(&mut leaves, leaf_nodes.as_mut_ptr(), 0 as size_t);
    ret = cbmt_build_merkle_tree(
        &mut tree,
        &mut leaves,
        Some(
            node_merge
                as unsafe extern "C" fn(
                    *mut ::core::ffi::c_void,
                    *mut cbmt_node,
                    *mut cbmt_node,
                ) -> cbmt_node,
        ),
        NULL,
        nodes_buffer,
    );
    if !(ret == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 17],
                [::core::ffi::c_char; 17],
            >(*b"test_build_empty\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            68 as ::core::ffi::c_int,
            b"ret == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(node_to_int32(cbmt_tree_root(&mut tree)) == 0 as int32_t) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 17],
                [::core::ffi::c_char; 17],
            >(*b"test_build_empty\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            69 as ::core::ffi::c_int,
            b"node_to_int32(cbmt_tree_root(&tree)) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_build_five() {
    let mut nodes: [cbmt_node; 1024] = [cbmt_node { bytes: [0; 4] }; 1024];
    let mut leaf_nodes: [cbmt_node; 256] = [cbmt_node { bytes: [0; 4] }; 256];
    let mut nodes_buffer: cbmt_buffer = cbmt_buffer {
        data: 0 as *mut ::core::ffi::c_void,
        capacity: 0,
    };
    cbmt_buffer_init(
        &mut nodes_buffer,
        nodes.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[cbmt_node; 1024]>() as size_t,
    );
    let mut ret: ::core::ffi::c_int = 0;
    let mut tree: cbmt_tree = cbmt_tree {
        nodes: 0 as *mut cbmt_node,
        length: 0,
        capacity: 0,
    };
    let mut leaves: cbmt_leaves = cbmt_leaves {
        nodes: 0 as *mut cbmt_node,
        length: 0,
    };
    leaf_nodes[0 as ::core::ffi::c_int as usize] = int32_to_node(2 as int32_t);
    leaf_nodes[1 as ::core::ffi::c_int as usize] = int32_to_node(3 as int32_t);
    leaf_nodes[2 as ::core::ffi::c_int as usize] = int32_to_node(5 as int32_t);
    leaf_nodes[3 as ::core::ffi::c_int as usize] = int32_to_node(7 as int32_t);
    leaf_nodes[4 as ::core::ffi::c_int as usize] = int32_to_node(11 as int32_t);
    cbmt_leaves_init(&mut leaves, leaf_nodes.as_mut_ptr(), 5 as size_t);
    ret = cbmt_build_merkle_tree(
        &mut tree,
        &mut leaves,
        Some(
            node_merge
                as unsafe extern "C" fn(
                    *mut ::core::ffi::c_void,
                    *mut cbmt_node,
                    *mut cbmt_node,
                ) -> cbmt_node,
        ),
        NULL,
        nodes_buffer,
    );
    if !(ret == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_build_five\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            90 as ::core::ffi::c_int,
            b"ret == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut i: size_t = 0 as size_t;
    while i < tree.length {
        printf(
            b"tree.nodes[%ld]: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
            i,
            node_to_int32(*tree.nodes.offset(i as isize)),
        );
        i = i.wrapping_add(1);
    }
    if !(node_to_int32(*tree.nodes.offset(0 as ::core::ffi::c_int as isize))
        == 4 as int32_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_build_five\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            95 as ::core::ffi::c_int,
            b"node_to_int32(tree.nodes[0]) == 4\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(node_to_int32(*tree.nodes.offset(1 as ::core::ffi::c_int as isize))
        == -(2 as int32_t)) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_build_five\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            96 as ::core::ffi::c_int,
            b"node_to_int32(tree.nodes[1]) == -2\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(node_to_int32(*tree.nodes.offset(2 as ::core::ffi::c_int as isize))
        == 2 as int32_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_build_five\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            97 as ::core::ffi::c_int,
            b"node_to_int32(tree.nodes[2]) == 2\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(node_to_int32(*tree.nodes.offset(3 as ::core::ffi::c_int as isize))
        == 4 as int32_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_build_five\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            98 as ::core::ffi::c_int,
            b"node_to_int32(tree.nodes[3]) == 4\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(node_to_int32(*tree.nodes.offset(4 as ::core::ffi::c_int as isize))
        == 2 as int32_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_build_five\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            100 as ::core::ffi::c_int,
            b"node_to_int32(tree.nodes[4]) == 2\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(node_to_int32(*tree.nodes.offset(5 as ::core::ffi::c_int as isize))
        == 3 as int32_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_build_five\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            101 as ::core::ffi::c_int,
            b"node_to_int32(tree.nodes[5]) == 3\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(node_to_int32(*tree.nodes.offset(6 as ::core::ffi::c_int as isize))
        == 5 as int32_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_build_five\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            102 as ::core::ffi::c_int,
            b"node_to_int32(tree.nodes[6]) == 5\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(node_to_int32(*tree.nodes.offset(7 as ::core::ffi::c_int as isize))
        == 7 as int32_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_build_five\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            103 as ::core::ffi::c_int,
            b"node_to_int32(tree.nodes[7]) == 7\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(node_to_int32(*tree.nodes.offset(8 as ::core::ffi::c_int as isize))
        == 11 as int32_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"test_build_five\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            104 as ::core::ffi::c_int,
            b"node_to_int32(tree.nodes[8]) == 11\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_build_root_directly_2leaves() {
    let mut nodes: [cbmt_node; 1024] = [cbmt_node { bytes: [0; 4] }; 1024];
    let mut leaf_nodes: [cbmt_node; 256] = [cbmt_node { bytes: [0; 4] }; 256];
    let mut nodes_buffer: cbmt_buffer = cbmt_buffer {
        data: 0 as *mut ::core::ffi::c_void,
        capacity: 0,
    };
    cbmt_buffer_init(
        &mut nodes_buffer,
        nodes.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[cbmt_node; 1024]>() as size_t,
    );
    let mut ret: ::core::ffi::c_int = 0;
    let mut tree: cbmt_tree = cbmt_tree {
        nodes: 0 as *mut cbmt_node,
        length: 0,
        capacity: 0,
    };
    let mut leaves: cbmt_leaves = cbmt_leaves {
        nodes: 0 as *mut cbmt_node,
        length: 0,
    };
    leaf_nodes[0 as ::core::ffi::c_int as usize] = int32_to_node(2 as int32_t);
    leaf_nodes[1 as ::core::ffi::c_int as usize] = int32_to_node(3 as int32_t);
    cbmt_leaves_init(&mut leaves, leaf_nodes.as_mut_ptr(), 2 as size_t);
    let mut root: cbmt_node = cbmt_node { bytes: [0; 4] };
    ret = cbmt_build_merkle_root(
        &mut root,
        &mut leaves,
        Some(
            node_merge
                as unsafe extern "C" fn(
                    *mut ::core::ffi::c_void,
                    *mut cbmt_node,
                    *mut cbmt_node,
                ) -> cbmt_node,
        ),
        NULL,
        nodes_buffer,
    );
    if !(ret == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 33],
                [::core::ffi::c_char; 33],
            >(*b"test_build_root_directly_2leaves\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            124 as ::core::ffi::c_int,
            b"ret == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"root: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        node_to_int32(root),
    );
    if !(node_to_int32(root) == 1 as int32_t) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 33],
                [::core::ffi::c_char; 33],
            >(*b"test_build_root_directly_2leaves\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            126 as ::core::ffi::c_int,
            b"node_to_int32(root) == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_build_root_directly() {
    let mut nodes: [cbmt_node; 1024] = [cbmt_node { bytes: [0; 4] }; 1024];
    let mut leaf_nodes: [cbmt_node; 256] = [cbmt_node { bytes: [0; 4] }; 256];
    let mut nodes_buffer: cbmt_buffer = cbmt_buffer {
        data: 0 as *mut ::core::ffi::c_void,
        capacity: 0,
    };
    cbmt_buffer_init(
        &mut nodes_buffer,
        nodes.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[cbmt_node; 1024]>() as size_t,
    );
    let mut ret: ::core::ffi::c_int = 0;
    let mut tree: cbmt_tree = cbmt_tree {
        nodes: 0 as *mut cbmt_node,
        length: 0,
        capacity: 0,
    };
    let mut leaves: cbmt_leaves = cbmt_leaves {
        nodes: 0 as *mut cbmt_node,
        length: 0,
    };
    leaf_nodes[0 as ::core::ffi::c_int as usize] = int32_to_node(2 as int32_t);
    leaf_nodes[1 as ::core::ffi::c_int as usize] = int32_to_node(3 as int32_t);
    leaf_nodes[2 as ::core::ffi::c_int as usize] = int32_to_node(5 as int32_t);
    leaf_nodes[3 as ::core::ffi::c_int as usize] = int32_to_node(7 as int32_t);
    leaf_nodes[4 as ::core::ffi::c_int as usize] = int32_to_node(11 as int32_t);
    cbmt_leaves_init(&mut leaves, leaf_nodes.as_mut_ptr(), 5 as size_t);
    let mut root: cbmt_node = cbmt_node { bytes: [0; 4] };
    ret = cbmt_build_merkle_root(
        &mut root,
        &mut leaves,
        Some(
            node_merge
                as unsafe extern "C" fn(
                    *mut ::core::ffi::c_void,
                    *mut cbmt_node,
                    *mut cbmt_node,
                ) -> cbmt_node,
        ),
        NULL,
        nodes_buffer,
    );
    if !(ret == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_build_root_directly\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            147 as ::core::ffi::c_int,
            b"ret == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"root: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        node_to_int32(root),
    );
    if !(node_to_int32(root) == 4 as int32_t) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_build_root_directly\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            149 as ::core::ffi::c_int,
            b"node_to_int32(root) == 4\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_rebuild_proof() {
    let mut nodes: [cbmt_node; 1024] = [cbmt_node { bytes: [0; 4] }; 1024];
    let mut leaf_nodes: [cbmt_node; 256] = [cbmt_node { bytes: [0; 4] }; 256];
    let mut nodes_buffer: cbmt_buffer = cbmt_buffer {
        data: 0 as *mut ::core::ffi::c_void,
        capacity: 0,
    };
    cbmt_buffer_init(
        &mut nodes_buffer,
        nodes.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[cbmt_node; 1024]>() as size_t,
    );
    let mut ret: ::core::ffi::c_int = 0;
    let mut tree: cbmt_tree = cbmt_tree {
        nodes: 0 as *mut cbmt_node,
        length: 0,
        capacity: 0,
    };
    let mut leaves: cbmt_leaves = cbmt_leaves {
        nodes: 0 as *mut cbmt_node,
        length: 0,
    };
    leaf_nodes[0 as ::core::ffi::c_int as usize] = int32_to_node(2 as int32_t);
    leaf_nodes[1 as ::core::ffi::c_int as usize] = int32_to_node(3 as int32_t);
    leaf_nodes[2 as ::core::ffi::c_int as usize] = int32_to_node(5 as int32_t);
    leaf_nodes[3 as ::core::ffi::c_int as usize] = int32_to_node(7 as int32_t);
    leaf_nodes[4 as ::core::ffi::c_int as usize] = int32_to_node(11 as int32_t);
    cbmt_leaves_init(&mut leaves, leaf_nodes.as_mut_ptr(), 5 as size_t);
    ret = cbmt_build_merkle_tree(
        &mut tree,
        &mut leaves,
        Some(
            node_merge
                as unsafe extern "C" fn(
                    *mut ::core::ffi::c_void,
                    *mut cbmt_node,
                    *mut cbmt_node,
                ) -> cbmt_node,
        ),
        NULL,
        nodes_buffer,
    );
    if !(ret == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_rebuild_proof\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            169 as ::core::ffi::c_int,
            b"ret == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut root: cbmt_node = cbmt_tree_root(&mut tree);
    let mut proof: cbmt_proof = cbmt_proof {
        indices: cbmt_indices {
            values: 0 as *mut uint32_t,
            length: 0,
            capacity: 0,
        },
        lemmas: 0 as *mut cbmt_node,
        lemmas_length: 0,
    };
    let mut leaf_index_values: [uint32_t; 2] = [
        0 as ::core::ffi::c_int as uint32_t,
        3 as ::core::ffi::c_int as uint32_t,
    ];
    let mut leaf_indices: cbmt_indices = cbmt_indices {
        values: 0 as *mut uint32_t,
        length: 0,
        capacity: 0,
    };
    cbmt_indices_init(
        &mut leaf_indices,
        leaf_index_values.as_mut_ptr(),
        2 as size_t,
        2 as size_t,
    );
    let mut leaf_values_data: [uint32_t; 256] = [0; 256];
    let mut lemmas_nodes: [cbmt_node; 256] = [cbmt_node { bytes: [0; 4] }; 256];
    let mut indices_buffer: cbmt_buffer = cbmt_buffer {
        data: 0 as *mut ::core::ffi::c_void,
        capacity: 0,
    };
    let mut lemmas_buffer: cbmt_buffer = cbmt_buffer {
        data: 0 as *mut ::core::ffi::c_void,
        capacity: 0,
    };
    cbmt_buffer_init(
        &mut indices_buffer,
        leaf_values_data.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[uint32_t; 256]>() as size_t,
    );
    cbmt_buffer_init(
        &mut lemmas_buffer,
        lemmas_nodes.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[cbmt_node; 256]>() as size_t,
    );
    ret = cbmt_tree_build_proof(
        &mut proof,
        &mut tree,
        &mut leaf_indices,
        indices_buffer,
        lemmas_buffer,
    );
    if !(ret == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_rebuild_proof\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            184 as ::core::ffi::c_int,
            b"ret == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"proof.indices.length=%ld, proof.lemmas_length=%ld\n\0" as *const u8
            as *const ::core::ffi::c_char,
        proof.indices.length,
        proof.lemmas_length,
    );
    if !(proof.indices.length == 2 as size_t) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_rebuild_proof\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            188 as ::core::ffi::c_int,
            b"proof.indices.length == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(*proof.indices.values.offset(0 as ::core::ffi::c_int as isize) == 4 as uint32_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_rebuild_proof\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            189 as ::core::ffi::c_int,
            b"proof.indices.values[0] == 4\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(*proof.indices.values.offset(1 as ::core::ffi::c_int as isize) == 7 as uint32_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_rebuild_proof\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            190 as ::core::ffi::c_int,
            b"proof.indices.values[1] == 7\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(proof.lemmas_length == 2 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_rebuild_proof\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            191 as ::core::ffi::c_int,
            b"proof.lemmas_length == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(node_to_int32(*proof.lemmas.offset(0 as ::core::ffi::c_int as isize))
        == 11 as int32_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_rebuild_proof\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            192 as ::core::ffi::c_int,
            b"node_to_int32(proof.lemmas[0]) == 11\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(node_to_int32(*proof.lemmas.offset(1 as ::core::ffi::c_int as isize))
        == 2 as int32_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_rebuild_proof\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            193 as ::core::ffi::c_int,
            b"node_to_int32(proof.lemmas[1]) == 2\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut needed_nodes: [cbmt_node; 256] = [cbmt_node { bytes: [0; 4] }; 256];
    let mut needed_leaves: cbmt_leaves = cbmt_leaves {
        nodes: 0 as *mut cbmt_node,
        length: 0,
    };
    cbmt_leaves_init(&mut needed_leaves, needed_nodes.as_mut_ptr(), leaf_indices.length);
    let mut i: size_t = 0 as size_t;
    while i < needed_leaves.length {
        *needed_leaves.nodes.offset(i as isize) = *tree
            .nodes
            .offset(*proof.indices.values.offset(i as isize) as isize);
        printf(
            b"[needed] index=%d, node=%d\n\0" as *const u8 as *const ::core::ffi::c_char,
            *proof.indices.values.offset(i as isize),
            node_to_int32(
                *tree.nodes.offset(*proof.indices.values.offset(i as isize) as isize),
            ),
        );
        i = i.wrapping_add(1);
    }
    let mut nodes2: [cbmt_node; 1024] = [cbmt_node { bytes: [0; 4] }; 1024];
    let mut pairs: [cbmt_node_pair; 1024] = [cbmt_node_pair {
        index: 0,
        node: cbmt_node { bytes: [0; 4] },
    }; 1024];
    let mut nodes_buffer2: cbmt_buffer = cbmt_buffer {
        data: 0 as *mut ::core::ffi::c_void,
        capacity: 0,
    };
    let mut pairs_buffer: cbmt_buffer = cbmt_buffer {
        data: 0 as *mut ::core::ffi::c_void,
        capacity: 0,
    };
    cbmt_buffer_init(
        &mut nodes_buffer2,
        nodes2.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[cbmt_node; 1024]>() as size_t,
    );
    cbmt_buffer_init(
        &mut pairs_buffer,
        pairs.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<[cbmt_node_pair; 1024]>() as size_t,
    );
    ret = cbmt_proof_verify(
        &mut proof,
        &mut root,
        &mut needed_leaves,
        Some(
            node_merge
                as unsafe extern "C" fn(
                    *mut ::core::ffi::c_void,
                    *mut cbmt_node,
                    *mut cbmt_node,
                ) -> cbmt_node,
        ),
        NULL,
        nodes_buffer2,
        pairs_buffer,
    );
    if !(ret == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_rebuild_proof\0")
                .as_ptr(),
            b"test_merkle_tree.c\0" as *const u8 as *const ::core::ffi::c_char,
            212 as ::core::ffi::c_int,
            b"ret == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_build_proof() {}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
