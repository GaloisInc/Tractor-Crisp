#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn murmurhash(_: *const ::core::ffi::c_char, _: uint32_t, _: uint32_t) -> uint32_t;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint32_t = u32;
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut seed: uint32_t = 0 as uint32_t;
    let mut key: *const ::core::ffi::c_char = b"kinkajou\0" as *const u8
        as *const ::core::ffi::c_char;
    let mut hash: uint32_t = murmurhash(key, strlen(key) as uint32_t, seed);
    printf(
        b"murmurhash(%s) = 0x%x\n\0" as *const u8 as *const ::core::ffi::c_char,
        key,
        hash,
    );
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
