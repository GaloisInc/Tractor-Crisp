#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stdinp: *mut FILE;
    static mut __stderrp: *mut FILE;
    fn ferror(_: *mut FILE) -> ::core::ffi::c_int;
    fn fgets(
        _: *mut ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *mut FILE,
    ) -> *mut ::core::ffi::c_char;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn realloc(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn atoi(_: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
    fn strcat(
        __s1: *mut ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strncmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> ::core::ffi::c_int;
    fn isatty(_: ::core::ffi::c_int) -> ::core::ffi::c_int;
    fn murmurhash(_: *const ::core::ffi::c_char, _: uint32_t, _: uint32_t) -> uint32_t;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type uint32_t = u32;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const MURMURHASH_VERSION: [::core::ffi::c_char; 6] = unsafe {
    ::core::mem::transmute::<[u8; 6], [::core::ffi::c_char; 6]>(*b"0.2.0\0")
};
unsafe extern "C" fn usage() {
    fprintf(
        __stderrp,
        b"usage: murmur [-hV] [options]\n\0" as *const u8 as *const ::core::ffi::c_char,
    );
}
unsafe extern "C" fn help() {
    fprintf(__stderrp, b"\noptions:\n\0" as *const u8 as *const ::core::ffi::c_char);
    fprintf(
        __stderrp,
        b"\n  --seed=[seed]  hash seed (optional)\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    fprintf(__stderrp, b"\n\0" as *const u8 as *const ::core::ffi::c_char);
}
unsafe extern "C" fn read_stdin() -> *mut ::core::ffi::c_char {
    let mut bsize: size_t = 1024 as size_t;
    let mut size: size_t = 1 as size_t;
    let vla = bsize as usize;
    let mut buf: Vec<::core::ffi::c_char> = ::std::vec::from_elem(0, vla);
    let mut res: *mut ::core::ffi::c_char = malloc(
        (::core::mem::size_of::<::core::ffi::c_char>() as size_t).wrapping_mul(bsize),
    ) as *mut ::core::ffi::c_char;
    let mut tmp: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    if res.is_null() {
        return 0 as *mut ::core::ffi::c_char;
    }
    *res.offset(0 as ::core::ffi::c_int as isize) = '\0' as i32 as ::core::ffi::c_char;
    if !fgets(buf.as_mut_ptr(), bsize as ::core::ffi::c_int, __stdinp).is_null() {
        tmp = res;
        size = size.wrapping_add(strlen(buf.as_mut_ptr()));
        res = realloc(res as *mut ::core::ffi::c_void, size) as *mut ::core::ffi::c_char;
        if res.is_null() {
            free(tmp as *mut ::core::ffi::c_void);
            return 0 as *mut ::core::ffi::c_char;
        }
        strcat(res, buf.as_mut_ptr());
        return res;
    }
    free(res as *mut ::core::ffi::c_void);
    return 0 as *mut ::core::ffi::c_char;
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut buf: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut key: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut seed: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut h: uint32_t = 0 as uint32_t;
    let mut opt: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let fresh0 = argv;
    argv = argv.offset(1);
    opt = *fresh0;
    loop {
        let fresh1 = argv;
        argv = argv.offset(1);
        opt = *fresh1;
        if opt.is_null() {
            break;
        }
        let fresh2 = opt;
        opt = opt.offset(1);
        if '-' as i32 == *fresh2 as ::core::ffi::c_int {
            let fresh3 = opt;
            opt = opt.offset(1);
            match *fresh3 as ::core::ffi::c_int {
                104 => {
                    usage();
                    help();
                    return 0 as ::core::ffi::c_int;
                }
                86 => {
                    fprintf(
                        __stderrp,
                        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
                        MURMURHASH_VERSION.as_ptr(),
                    );
                    return 0 as ::core::ffi::c_int;
                }
                45 => {
                    if 0 as ::core::ffi::c_int
                        == strncmp(
                            opt,
                            b"seed\0" as *const u8 as *const ::core::ffi::c_char,
                            strlen(b"seed\0" as *const u8 as *const ::core::ffi::c_char),
                        )
                    {
                        let mut len: size_t = strlen(
                                b"seed\0" as *const u8 as *const ::core::ffi::c_char,
                            )
                            .wrapping_add(1 as size_t);
                        let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                        while (i as size_t) < len {
                            *opt += 1;
                            i += 1;
                        }
                        seed = opt;
                    }
                }
                _ => {
                    *opt -= 1;
                    fprintf(
                        __stderrp,
                        b"unknown option: `%s'\n\0" as *const u8
                            as *const ::core::ffi::c_char,
                        opt,
                    );
                    usage();
                    return 1 as ::core::ffi::c_int;
                }
            }
        }
    }
    if seed.is_null() {
        seed = b"0\0" as *const u8 as *const ::core::ffi::c_char
            as *mut ::core::ffi::c_char;
    }
    if 1 as ::core::ffi::c_int == isatty(0 as ::core::ffi::c_int) {
        return 1 as ::core::ffi::c_int
    } else if ferror(__stdinp) != 0 {
        return 1 as ::core::ffi::c_int
    } else {
        buf = read_stdin();
        if buf.is_null() {
            return 1 as ::core::ffi::c_int
        } else if 0 as size_t == strlen(buf) {
            buf = b"\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
        h = murmurhash(buf, strlen(buf) as uint32_t, atoi(seed) as uint32_t);
        printf(b"%u\n\0" as *const u8 as *const ::core::ffi::c_char, h);
        loop {
            key = read_stdin();
            if key.is_null() {
                break;
            }
            if 0 as size_t == strlen(buf) {
                buf = b"\0" as *const u8 as *const ::core::ffi::c_char
                    as *mut ::core::ffi::c_char;
            }
            h = murmurhash(buf, strlen(buf) as uint32_t, atoi(seed) as uint32_t);
            printf(b"%du\n\0" as *const u8 as *const ::core::ffi::c_char, h);
            if key.is_null() {
                break;
            }
        }
    }
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
