#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
pub type uint8_t = u8;
pub type uint32_t = u32;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn murmurhash(
    mut key: *const ::core::ffi::c_char,
    mut len: uint32_t,
    mut seed: uint32_t,
) -> uint32_t {
    let mut c1: uint32_t = 0xcc9e2d51 as uint32_t;
    let mut c2: uint32_t = 0x1b873593 as uint32_t;
    let mut r1: uint32_t = 15 as uint32_t;
    let mut r2: uint32_t = 13 as uint32_t;
    let mut m: uint32_t = 5 as uint32_t;
    let mut n: uint32_t = 0xe6546b64 as uint32_t;
    let mut h: uint32_t = 0 as uint32_t;
    let mut k: uint32_t = 0 as uint32_t;
    let mut d: *mut uint8_t = key as *mut uint8_t;
    let mut chunks: *const uint32_t = 0 as *const uint32_t;
    let mut tail: *const uint8_t = 0 as *const uint8_t;
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut l: ::core::ffi::c_int = len.wrapping_div(4 as uint32_t)
        as ::core::ffi::c_int;
    h = seed;
    chunks = d.offset((l * 4 as ::core::ffi::c_int) as isize) as *const uint32_t;
    tail = d.offset((l * 4 as ::core::ffi::c_int) as isize) as *const uint8_t;
    i = -l;
    while i != 0 as ::core::ffi::c_int {
        k = *chunks.offset(i as isize);
        k = k.wrapping_mul(c1);
        k = k << r1 | k >> (32 as uint32_t).wrapping_sub(r1);
        k = k.wrapping_mul(c2);
        h ^= k;
        h = h << r2 | h >> (32 as uint32_t).wrapping_sub(r2);
        h = h.wrapping_mul(m).wrapping_add(n);
        i += 1;
    }
    k = 0 as uint32_t;
    let mut current_block_20: u64;
    match len & 3 as uint32_t {
        3 => {
            k
                ^= ((*tail.offset(2 as ::core::ffi::c_int as isize)
                    as ::core::ffi::c_int) << 16 as ::core::ffi::c_int) as uint32_t;
            current_block_20 = 18339754909849842829;
        }
        2 => {
            current_block_20 = 18339754909849842829;
        }
        1 => {
            current_block_20 = 16691858185047013170;
        }
        _ => {
            current_block_20 = 5601891728916014340;
        }
    }
    match current_block_20 {
        18339754909849842829 => {
            k
                ^= ((*tail.offset(1 as ::core::ffi::c_int as isize)
                    as ::core::ffi::c_int) << 8 as ::core::ffi::c_int) as uint32_t;
            current_block_20 = 16691858185047013170;
        }
        _ => {}
    }
    match current_block_20 {
        16691858185047013170 => {
            k ^= *tail.offset(0 as ::core::ffi::c_int as isize) as uint32_t;
            k = k.wrapping_mul(c1);
            k = k << r1 | k >> (32 as uint32_t).wrapping_sub(r1);
            k = k.wrapping_mul(c2);
            h ^= k;
        }
        _ => {}
    }
    h ^= len;
    h ^= h >> 16 as ::core::ffi::c_int;
    h = (h as ::core::ffi::c_uint).wrapping_mul(0x85ebca6b as ::core::ffi::c_uint)
        as uint32_t as uint32_t;
    h ^= h >> 13 as ::core::ffi::c_int;
    h = (h as ::core::ffi::c_uint).wrapping_mul(0xc2b2ae35 as ::core::ffi::c_uint)
        as uint32_t as uint32_t;
    h ^= h >> 16 as ::core::ffi::c_int;
    return h;
}
