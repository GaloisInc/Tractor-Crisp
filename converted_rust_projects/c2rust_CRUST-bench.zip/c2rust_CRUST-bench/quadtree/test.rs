#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn puts(_: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
    fn free(_: *mut ::core::ffi::c_void);
    fn quadtree_point_new(
        x: ::core::ffi::c_double,
        y: ::core::ffi::c_double,
    ) -> *mut quadtree_point_t;
    fn quadtree_point_free(point: *mut quadtree_point_t);
    fn quadtree_bounds_new() -> *mut quadtree_bounds_t;
    fn quadtree_bounds_extend(
        bounds: *mut quadtree_bounds_t,
        x: ::core::ffi::c_double,
        y: ::core::ffi::c_double,
    );
    fn quadtree_bounds_free(bounds: *mut quadtree_bounds_t);
    fn quadtree_node_new() -> *mut quadtree_node_t;
    fn quadtree_node_ispointer(node: *mut quadtree_node_t) -> ::core::ffi::c_int;
    fn quadtree_node_isempty(node: *mut quadtree_node_t) -> ::core::ffi::c_int;
    fn quadtree_node_isleaf(node: *mut quadtree_node_t) -> ::core::ffi::c_int;
    fn quadtree_new(
        minx: ::core::ffi::c_double,
        miny: ::core::ffi::c_double,
        maxx: ::core::ffi::c_double,
        maxy: ::core::ffi::c_double,
    ) -> *mut quadtree_t;
    fn quadtree_free(tree: *mut quadtree_t);
    fn quadtree_search(
        tree: *mut quadtree_t,
        x: ::core::ffi::c_double,
        y: ::core::ffi::c_double,
    ) -> *mut quadtree_point_t;
    fn quadtree_insert(
        tree: *mut quadtree_t,
        x: ::core::ffi::c_double,
        y: ::core::ffi::c_double,
        key: *mut ::core::ffi::c_void,
    ) -> ::core::ffi::c_int;
    fn quadtree_walk(
        root: *mut quadtree_node_t,
        descent_0: Option<unsafe extern "C" fn(*mut quadtree_node_t) -> ()>,
        ascent_0: Option<unsafe extern "C" fn(*mut quadtree_node_t) -> ()>,
    );
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct quadtree_point {
    pub x: ::core::ffi::c_double,
    pub y: ::core::ffi::c_double,
}
pub type quadtree_point_t = quadtree_point;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct quadtree_bounds {
    pub nw: *mut quadtree_point_t,
    pub se: *mut quadtree_point_t,
    pub width: ::core::ffi::c_double,
    pub height: ::core::ffi::c_double,
}
pub type quadtree_bounds_t = quadtree_bounds;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct quadtree_node {
    pub ne: *mut quadtree_node,
    pub nw: *mut quadtree_node,
    pub se: *mut quadtree_node,
    pub sw: *mut quadtree_node,
    pub bounds: *mut quadtree_bounds_t,
    pub point: *mut quadtree_point_t,
    pub key: *mut ::core::ffi::c_void,
}
pub type quadtree_node_t = quadtree_node;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct quadtree {
    pub root: *mut quadtree_node_t,
    pub key_free: Option<unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ()>,
    pub length: ::core::ffi::c_uint,
}
pub type quadtree_t = quadtree;
#[no_mangle]
pub unsafe extern "C" fn descent(mut node: *mut quadtree_node_t) {}
#[no_mangle]
pub unsafe extern "C" fn ascent(mut node: *mut quadtree_node_t) {}
unsafe extern "C" fn test_node() {
    let mut node: *mut quadtree_node_t = quadtree_node_new();
    if (quadtree_node_isleaf(node) != 0) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_node\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            20 as ::core::ffi::c_int,
            b"!quadtree_node_isleaf(node)\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if (quadtree_node_isempty(node) == 0) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_node\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            21 as ::core::ffi::c_int,
            b"quadtree_node_isempty(node)\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if (quadtree_node_ispointer(node) != 0) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_node\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            22 as ::core::ffi::c_int,
            b"!quadtree_node_ispointer(node)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    free(node as *mut ::core::ffi::c_void);
}
unsafe extern "C" fn test_bounds() {
    let mut bounds: *mut quadtree_bounds_t = quadtree_bounds_new();
    if bounds.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"test_bounds\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            30 as ::core::ffi::c_int,
            b"bounds\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*bounds).nw).x == ::core::f32::INFINITY as ::core::ffi::c_double)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"test_bounds\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            31 as ::core::ffi::c_int,
            b"bounds->nw->x == INFINITY\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*bounds).se).x == -::core::f32::INFINITY as ::core::ffi::c_double)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"test_bounds\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            32 as ::core::ffi::c_int,
            b"bounds->se->x == -INFINITY\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    quadtree_bounds_extend(bounds, 5.0f64, 5.0f64);
    if !((*(*bounds).nw).x == 5.0f64) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"test_bounds\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            35 as ::core::ffi::c_int,
            b"bounds->nw->x == 5.0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*bounds).se).x == 5.0f64) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"test_bounds\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            36 as ::core::ffi::c_int,
            b"bounds->se->x == 5.0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    quadtree_bounds_extend(bounds, 10.0f64, 10.0f64);
    if !((*(*bounds).nw).y == 10.0f64) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"test_bounds\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            39 as ::core::ffi::c_int,
            b"bounds->nw->y == 10.0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*bounds).nw).y == 10.0f64) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"test_bounds\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            40 as ::core::ffi::c_int,
            b"bounds->nw->y == 10.0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*bounds).se).y == 5.0f64) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"test_bounds\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            41 as ::core::ffi::c_int,
            b"bounds->se->y == 5.0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*bounds).se).y == 5.0f64) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"test_bounds\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            42 as ::core::ffi::c_int,
            b"bounds->se->y == 5.0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*bounds).width == 5.0f64) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"test_bounds\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            44 as ::core::ffi::c_int,
            b"bounds->width == 5.0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*bounds).height == 5.0f64) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"test_bounds\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            45 as ::core::ffi::c_int,
            b"bounds->height == 5.0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    quadtree_bounds_free(bounds);
}
unsafe extern "C" fn test_tree() {
    let mut val: ::core::ffi::c_int = 10 as ::core::ffi::c_int;
    let mut tree: *mut quadtree_t = quadtree_new(
        1 as ::core::ffi::c_int as ::core::ffi::c_double,
        1 as ::core::ffi::c_int as ::core::ffi::c_double,
        10 as ::core::ffi::c_int as ::core::ffi::c_double,
        10 as ::core::ffi::c_int as ::core::ffi::c_double,
    );
    if !((*(*(*(*tree).root).bounds).nw).x
        == 1 as ::core::ffi::c_int as ::core::ffi::c_double) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            56 as ::core::ffi::c_int,
            b"tree->root->bounds->nw->x == 1\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*(*(*tree).root).bounds).nw).y == 10.0f64) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            57 as ::core::ffi::c_int,
            b"tree->root->bounds->nw->y == 10.0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*(*(*tree).root).bounds).se).x == 10.0f64) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            58 as ::core::ffi::c_int,
            b"tree->root->bounds->se->x == 10.0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*(*(*tree).root).bounds).se).y
        == 1 as ::core::ffi::c_int as ::core::ffi::c_double) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            59 as ::core::ffi::c_int,
            b"tree->root->bounds->se->y == 1\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(quadtree_insert(
        tree,
        0 as ::core::ffi::c_int as ::core::ffi::c_double,
        0 as ::core::ffi::c_int as ::core::ffi::c_double,
        &mut val as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            62 as ::core::ffi::c_int,
            b"quadtree_insert(tree, 0, 0, &val) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(quadtree_insert(
        tree,
        110.0f64,
        110.0f64,
        &mut val as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            63 as ::core::ffi::c_int,
            b"quadtree_insert(tree, 110.0, 110.0, &val) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(quadtree_insert(
        tree,
        8.0f64,
        2.0f64,
        &mut val as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
    ) != 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            65 as ::core::ffi::c_int,
            b"quadtree_insert(tree, 8.0, 2.0, &val) != 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tree).length == 1 as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            66 as ::core::ffi::c_int,
            b"tree->length == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*(*tree).root).point).x == 8.0f64) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            67 as ::core::ffi::c_int,
            b"tree->root->point->x == 8.0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*(*tree).root).point).y == 2.0f64) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            68 as ::core::ffi::c_int,
            b"tree->root->point->y == 2.0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(quadtree_insert(
        tree,
        0.0f64,
        1.0f64,
        &mut val as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            70 as ::core::ffi::c_int,
            b"quadtree_insert(tree, 0.0, 1.0, &val) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(quadtree_insert(
        tree,
        2.0f64,
        3.0f64,
        &mut val as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
    ) == 1 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            71 as ::core::ffi::c_int,
            b"quadtree_insert(tree, 2.0, 3.0, &val) == 1\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(quadtree_insert(
        tree,
        2.0f64,
        3.0f64,
        &mut val as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
    ) == 2 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            72 as ::core::ffi::c_int,
            b"quadtree_insert(tree, 2.0, 3.0, &val) == 2\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tree).length == 2 as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            73 as ::core::ffi::c_int,
            b"tree->length == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(*(*tree).root).point.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            74 as ::core::ffi::c_int,
            b"tree->root->point == NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(quadtree_insert(
        tree,
        3.0f64,
        1.1f64,
        &mut val as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
    ) == 1 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            76 as ::core::ffi::c_int,
            b"quadtree_insert(tree, 3.0, 1.1, &val) == 1\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tree).length == 3 as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            77 as ::core::ffi::c_int,
            b"tree->length == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*quadtree_search(tree, 3.0f64, 1.1f64)).x == 3.0f64) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_tree\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            78 as ::core::ffi::c_int,
            b"quadtree_search(tree, 3.0, 1.1)->x == 3.0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    quadtree_walk(
        (*tree).root,
        Some(ascent as unsafe extern "C" fn(*mut quadtree_node_t) -> ()),
        Some(descent as unsafe extern "C" fn(*mut quadtree_node_t) -> ()),
    );
    quadtree_free(tree);
}
unsafe extern "C" fn test_points() {
    let mut point: *mut quadtree_point_t = quadtree_point_new(
        5 as ::core::ffi::c_int as ::core::ffi::c_double,
        6 as ::core::ffi::c_int as ::core::ffi::c_double,
    );
    if !((*point).x == 5 as ::core::ffi::c_int as ::core::ffi::c_double)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"test_points\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            86 as ::core::ffi::c_int,
            b"point->x == 5\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*point).y == 6 as ::core::ffi::c_int as ::core::ffi::c_double)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"test_points\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            87 as ::core::ffi::c_int,
            b"point->y == 6\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    quadtree_point_free(point);
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    printf(b"\x1B[33mtree\x1B[0m \0" as *const u8 as *const ::core::ffi::c_char);
    test_tree();
    puts(b"\x1B[1;32m\xE2\x9C\x93\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"\x1B[33mnode\x1B[0m \0" as *const u8 as *const ::core::ffi::c_char);
    test_node();
    puts(b"\x1B[1;32m\xE2\x9C\x93\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"\x1B[33mbounds\x1B[0m \0" as *const u8 as *const ::core::ffi::c_char);
    test_bounds();
    puts(b"\x1B[1;32m\xE2\x9C\x93\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"\x1B[33mpoints\x1B[0m \0" as *const u8 as *const ::core::ffi::c_char);
    test_points();
    puts(b"\x1B[1;32m\xE2\x9C\x93\x1B[0m\0" as *const u8 as *const ::core::ffi::c_char);
    return 0;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *const ::core::ffi::c_char,
            ) as i32,
        )
    }
}
