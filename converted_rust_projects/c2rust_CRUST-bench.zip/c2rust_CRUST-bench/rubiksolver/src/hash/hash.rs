#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type bool_0 = ::core::ffi::c_uint;
pub const true_0: bool_0 = 1;
pub const false_0: bool_0 = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct bucket_element_struct {
    pub element: *mut ::core::ffi::c_void,
    pub next: *mut bucket_element_struct,
}
pub type bucket_element_t = *mut bucket_element_struct;
pub type bucket_t = bucket_element_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct hash_struct {
    pub buckets: *mut bucket_t,
    pub hash_function: Option<
        unsafe extern "C" fn(*const ::core::ffi::c_void) -> ::core::ffi::c_uint,
    >,
    pub max_key: ::core::ffi::c_uint,
}
pub type hash_t = *mut hash_struct;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn hash_init(
    mut max_key: ::core::ffi::c_uint,
    mut hash_function: Option<
        unsafe extern "C" fn(*const ::core::ffi::c_void) -> ::core::ffi::c_uint,
    >,
) -> hash_t {
    let mut hash: hash_t = malloc(::core::mem::size_of::<hash_struct>() as size_t)
        as hash_t;
    (*hash).buckets = malloc(
        (::core::mem::size_of::<bucket_t>() as size_t)
            .wrapping_mul(max_key.wrapping_add(1 as ::core::ffi::c_uint) as size_t),
    ) as *mut bucket_t;
    memset(
        (*hash).buckets as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        (::core::mem::size_of::<bucket_t>() as size_t)
            .wrapping_mul(max_key.wrapping_add(1 as ::core::ffi::c_uint) as size_t),
    );
    (*hash).hash_function = hash_function;
    (*hash).max_key = max_key;
    return hash;
}
#[no_mangle]
pub unsafe extern "C" fn hash_free(mut hash: hash_t) {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i as ::core::ffi::c_uint <= (*hash).max_key {
        let mut curr: bucket_element_t = 0 as *mut bucket_element_struct;
        let mut painted: bucket_element_t = 0 as *mut bucket_element_struct;
        curr = *(*hash).buckets.offset(i as isize) as bucket_element_t;
        while !curr.is_null() {
            painted = curr;
            curr = (*curr).next as bucket_element_t;
            free(painted as *mut ::core::ffi::c_void);
        }
        i += 1;
    }
    free((*hash).buckets as *mut ::core::ffi::c_void);
    free(hash as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn hash_insert(
    mut hash: hash_t,
    mut element: *const ::core::ffi::c_void,
) -> bool_0 {
    if hash.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"hash_insert\0")
                .as_ptr(),
            b"hash.c\0" as *const u8 as *const ::core::ffi::c_char,
            37 as ::core::ffi::c_int,
            b"hash != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut ix: ::core::ffi::c_uint = (*hash)
        .hash_function
        .expect("non-null function pointer")(element);
    if !(ix <= (*hash).max_key) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"hash_insert\0")
                .as_ptr(),
            b"hash.c\0" as *const u8 as *const ::core::ffi::c_char,
            39 as ::core::ffi::c_int,
            b"ix <= hash->max_key\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut new_elem: bucket_element_t = 0 as *mut bucket_element_struct;
    let mut parent: bucket_element_t = 0 as *mut bucket_element_struct;
    if (*(*hash).buckets.offset(ix as isize)).is_null() {
        let ref mut fresh0 = *(*hash).buckets.offset(ix as isize);
        *fresh0 = malloc(::core::mem::size_of::<bucket_element_struct>() as size_t)
            as bucket_t;
        new_elem = *(*hash).buckets.offset(ix as isize) as bucket_element_t;
    } else {
        parent = *(*hash).buckets.offset(ix as isize) as bucket_element_t;
        while !(*parent).next.is_null() {
            parent = (*parent).next as bucket_element_t;
        }
        (*parent).next = malloc(
            ::core::mem::size_of::<bucket_element_struct>() as size_t,
        ) as bucket_element_t as *mut bucket_element_struct;
        new_elem = (*parent).next as bucket_element_t;
    }
    (*new_elem).element = element as *mut ::core::ffi::c_void;
    (*new_elem).next = 0 as *mut bucket_element_struct;
    return true_0;
}
#[no_mangle]
pub unsafe extern "C" fn hash_element_exists(
    hash: hash_t,
    mut element: *const ::core::ffi::c_void,
    mut compare_equal: Option<
        unsafe extern "C" fn(
            *const ::core::ffi::c_void,
            *const ::core::ffi::c_void,
        ) -> bool_0,
    >,
) -> bool_0 {
    if hash.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"hash_element_exists\0")
                .as_ptr(),
            b"hash.c\0" as *const u8 as *const ::core::ffi::c_char,
            63 as ::core::ffi::c_int,
            b"hash != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut ix: ::core::ffi::c_int = (*hash)
        .hash_function
        .expect("non-null function pointer")(element) as ::core::ffi::c_int;
    if !(ix as ::core::ffi::c_uint <= (*hash).max_key) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"hash_element_exists\0")
                .as_ptr(),
            b"hash.c\0" as *const u8 as *const ::core::ffi::c_char,
            65 as ::core::ffi::c_int,
            b"ix <= hash->max_key\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut curr: bucket_element_t = *(*hash).buckets.offset(ix as isize);
    if curr as ::core::ffi::c_uint == 0x3 as ::core::ffi::c_uint {
        printf(b"Target acquired\n\0" as *const u8 as *const ::core::ffi::c_char);
    }
    while !curr.is_null() {
        if compare_equal.expect("non-null function pointer")((*curr).element, element)
            as u64 != 0
        {
            return true_0;
        }
        curr = (*curr).next as bucket_element_t;
    }
    return false_0;
}
#[no_mangle]
pub unsafe extern "C" fn hash_delete(
    mut hash: hash_t,
    mut element: *const ::core::ffi::c_void,
    mut compare_equal: Option<
        unsafe extern "C" fn(
            *const ::core::ffi::c_void,
            *const ::core::ffi::c_void,
        ) -> bool_0,
    >,
) -> bool_0 {
    if hash.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"hash_delete\0")
                .as_ptr(),
            b"hash.c\0" as *const u8 as *const ::core::ffi::c_char,
            82 as ::core::ffi::c_int,
            b"hash != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut ix: ::core::ffi::c_int = (*hash)
        .hash_function
        .expect("non-null function pointer")(element) as ::core::ffi::c_int;
    if !(ix as ::core::ffi::c_uint <= (*hash).max_key) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"hash_delete\0")
                .as_ptr(),
            b"hash.c\0" as *const u8 as *const ::core::ffi::c_char,
            84 as ::core::ffi::c_int,
            b"ix <= hash->max_key\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut curr: bucket_element_t = *(*hash).buckets.offset(ix as isize);
    if !curr.is_null() {
        if compare_equal.expect("non-null function pointer")((*curr).element, element)
            as u64 != 0
        {
            if (*curr).next.is_null() {
                let ref mut fresh1 = *(*hash).buckets.offset(ix as isize);
                *fresh1 = 0 as bucket_t;
            } else {
                let ref mut fresh2 = *(*hash).buckets.offset(ix as isize);
                *fresh2 = (*curr).next as bucket_t;
            }
            free(curr as *mut ::core::ffi::c_void);
            return true_0;
        }
    } else {
        return false_0
    }
    while !curr.is_null() && !(*curr).next.is_null() {
        if compare_equal
            .expect("non-null function pointer")((*(*curr).next).element, element) as u64
            != 0
        {
            let mut del: bucket_element_t = (*curr).next as bucket_element_t;
            (*curr).next = (*del).next;
            free(del as *mut ::core::ffi::c_void);
            return true_0;
        }
        curr = (*curr).next as bucket_element_t;
    }
    return false_0;
}
