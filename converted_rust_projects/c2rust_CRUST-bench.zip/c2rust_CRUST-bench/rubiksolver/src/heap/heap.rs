#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type bool_0 = ::core::ffi::c_uint;
pub const true_0: bool_0 = 1;
pub const false_0: bool_0 = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct heap_struct {
    pub head: *mut *mut ::core::ffi::c_void,
    pub capacity: ::core::ffi::c_int,
    pub last: ::core::ffi::c_int,
    pub is_smaller: Option<
        unsafe extern "C" fn(
            *const ::core::ffi::c_void,
            *const ::core::ffi::c_void,
        ) -> bool_0,
    >,
}
pub type heap_t = *mut heap_struct;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const GROW_FACTOR: ::core::ffi::c_float = 1.5f32;
#[no_mangle]
pub unsafe extern "C" fn heap_init(
    mut init_size: ::core::ffi::c_int,
    mut is_smaller: Option<
        unsafe extern "C" fn(
            *const ::core::ffi::c_void,
            *const ::core::ffi::c_void,
        ) -> bool_0,
    >,
) -> heap_t {
    let mut heap: heap_t = malloc(::core::mem::size_of::<heap_struct>() as size_t)
        as heap_t;
    (*heap).head = malloc(
        (init_size as size_t)
            .wrapping_mul(::core::mem::size_of::<*mut ::core::ffi::c_void>() as size_t),
    ) as *mut *mut ::core::ffi::c_void;
    memset(
        (*heap).head as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        (init_size as size_t)
            .wrapping_mul(::core::mem::size_of::<*mut ::core::ffi::c_void>() as size_t),
    );
    (*heap).capacity = init_size;
    (*heap).last = -(1 as ::core::ffi::c_int);
    (*heap).is_smaller = is_smaller;
    return heap;
}
#[no_mangle]
pub unsafe extern "C" fn heap_free(mut heap: heap_t) {
    free((*heap).head as *mut ::core::ffi::c_void);
    free(heap as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn heap_grow(mut heap: heap_t) -> bool_0 {
    if heap.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"heap_grow\0")
                .as_ptr(),
            b"heap.c\0" as *const u8 as *const ::core::ffi::c_char,
            38 as ::core::ffi::c_int,
            b"heap != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut tmp: *mut *mut ::core::ffi::c_void = malloc(
        ((*heap).capacity as ::core::ffi::c_float * GROW_FACTOR
            * ::core::mem::size_of::<*mut ::core::ffi::c_void>() as ::core::ffi::c_float)
            as size_t,
    ) as *mut *mut ::core::ffi::c_void;
    memset(
        tmp as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ((*heap).capacity as ::core::ffi::c_float * GROW_FACTOR
            * ::core::mem::size_of::<*mut ::core::ffi::c_void>() as ::core::ffi::c_float)
            as size_t,
    );
    memcpy(
        tmp as *mut ::core::ffi::c_void,
        (*heap).head as *const ::core::ffi::c_void,
        ((*heap).capacity as size_t)
            .wrapping_mul(::core::mem::size_of::<*mut ::core::ffi::c_void>() as size_t),
    );
    if !tmp.is_null() {
        free((*heap).head as *mut ::core::ffi::c_void);
        (*heap).head = tmp;
        (*heap).capacity = ((*heap).capacity as ::core::ffi::c_float * GROW_FACTOR)
            as ::core::ffi::c_int;
        return true_0;
    } else {
        return false_0
    };
}
#[no_mangle]
pub unsafe extern "C" fn heap_insert(
    mut heap: heap_t,
    mut element: *const ::core::ffi::c_void,
) -> bool_0 {
    if heap.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"heap_insert\0")
                .as_ptr(),
            b"heap.c\0" as *const u8 as *const ::core::ffi::c_char,
            59 as ::core::ffi::c_int,
            b"heap != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut parent: ::core::ffi::c_int = 0;
    let mut son: ::core::ffi::c_int = (*heap).last + 1 as ::core::ffi::c_int;
    if (*heap).capacity <= son {
        if heap_grow(heap) as u64 == 0 {
            return false_0;
        }
    }
    let ref mut fresh0 = *(*heap).head.offset(son as isize);
    *fresh0 = element as *mut ::core::ffi::c_void;
    parent = (son - 1 as ::core::ffi::c_int) / 2 as ::core::ffi::c_int;
    while parent >= 0 as ::core::ffi::c_int
        && (*heap)
            .is_smaller
            .expect(
                "non-null function pointer",
            )(*(*heap).head.offset(son as isize), *(*heap).head.offset(parent as isize))
            as ::core::ffi::c_uint != 0
    {
        let mut tmp: *mut ::core::ffi::c_void = *(*heap).head.offset(parent as isize);
        let ref mut fresh1 = *(*heap).head.offset(parent as isize);
        *fresh1 = *(*heap).head.offset(son as isize);
        let ref mut fresh2 = *(*heap).head.offset(son as isize);
        *fresh2 = tmp;
        son = parent;
        parent = (son - 1 as ::core::ffi::c_int) / 2 as ::core::ffi::c_int;
    }
    (*heap).last += 1 as ::core::ffi::c_int;
    return true_0;
}
#[no_mangle]
pub unsafe extern "C" fn heap_delete_min(mut heap: heap_t) -> *mut ::core::ffi::c_void {
    if (*heap).head.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"heap_delete_min\0")
                .as_ptr(),
            b"heap.c\0" as *const u8 as *const ::core::ffi::c_char,
            84 as ::core::ffi::c_int,
            b"heap->head != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut min: *mut ::core::ffi::c_void = NULL;
    let mut parent: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut son1: ::core::ffi::c_int = 0;
    let mut son2: ::core::ffi::c_int = 0;
    let mut son: ::core::ffi::c_int = 0;
    min = *(*heap).head.offset(parent as isize);
    let ref mut fresh3 = *(*heap).head.offset(parent as isize);
    *fresh3 = *(*heap).head.offset((*heap).last as isize);
    let ref mut fresh4 = *(*heap).head.offset((*heap).last as isize);
    *fresh4 = NULL;
    (*heap).last -= 1 as ::core::ffi::c_int;
    loop {
        son1 = 2 as ::core::ffi::c_int * parent + 1 as ::core::ffi::c_int;
        son2 = 2 as ::core::ffi::c_int * parent + 2 as ::core::ffi::c_int;
        if !(son1 <= (*heap).last) {
            break;
        }
        if son2 <= (*heap).last {
            son = if (*heap)
                .is_smaller
                .expect(
                    "non-null function pointer",
                )(
                *(*heap).head.offset(son1 as isize),
                *(*heap).head.offset(son2 as isize),
            ) as ::core::ffi::c_uint != 0
            {
                son1
            } else {
                son2
            };
        } else {
            son = son1;
        }
        if (*heap)
            .is_smaller
            .expect(
                "non-null function pointer",
            )(*(*heap).head.offset(son as isize), *(*heap).head.offset(parent as isize))
            as u64 != 0
        {
            let mut tmp: *mut ::core::ffi::c_void = *(*heap)
                .head
                .offset(parent as isize);
            let ref mut fresh5 = *(*heap).head.offset(parent as isize);
            *fresh5 = *(*heap).head.offset(son as isize);
            let ref mut fresh6 = *(*heap).head.offset(son as isize);
            *fresh6 = tmp;
        }
        parent = son;
    }
    return min;
}
#[no_mangle]
pub unsafe extern "C" fn heap_is_empty(heap: heap_t) -> bool_0 {
    if heap.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"heap_is_empty\0")
                .as_ptr(),
            b"heap.c\0" as *const u8 as *const ::core::ffi::c_char,
            114 as ::core::ffi::c_int,
            b"heap != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return ((*heap).last == -(1 as ::core::ffi::c_int)) as ::core::ffi::c_int as bool_0;
}
#[no_mangle]
pub unsafe extern "C" fn heap_find_min(heap: heap_t) -> *mut ::core::ffi::c_void {
    if (*heap).head.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"heap_find_min\0")
                .as_ptr(),
            b"heap.c\0" as *const u8 as *const ::core::ffi::c_char,
            120 as ::core::ffi::c_int,
            b"heap->head != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    return *(*heap).head.offset(0 as ::core::ffi::c_int as isize);
}
