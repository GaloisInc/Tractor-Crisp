#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type bool_0 = ::core::ffi::c_uint;
pub const true_0: bool_0 = 1;
pub const false_0: bool_0 = 0;
pub type color = ::core::ffi::c_uint;
pub const WHITE: color = 5;
pub const YELLOW: color = 4;
pub const ORANGE: color = 3;
pub const BLUE: color = 2;
pub const GREEN: color = 1;
pub const RED: color = 0;
pub type rotation = ::core::ffi::c_uint;
pub const CCW: rotation = 1;
pub const CW: rotation = 0;
pub type cube_t = *mut *mut color;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct ecube_struct {
    pub cube: cube_t,
    pub entropy: ::core::ffi::c_int,
    pub hash: ::core::ffi::c_int,
}
pub type ecube_t = *mut ecube_struct;
static mut top: [color; 6] = [GREEN, BLUE, RED, WHITE, ORANGE, YELLOW];
static mut color_code: [::core::ffi::c_char; 6] = [
    'R' as i32 as ::core::ffi::c_char,
    'G' as i32 as ::core::ffi::c_char,
    'B' as i32 as ::core::ffi::c_char,
    'O' as i32 as ::core::ffi::c_char,
    'Y' as i32 as ::core::ffi::c_char,
    'W' as i32 as ::core::ffi::c_char,
];
unsafe extern "C" fn adjacent_left(
    mut rotating_face: color,
    mut around: color,
) -> color {
    let mut l_around: color = (around as ::core::ffi::c_uint)
        .wrapping_add(5 as ::core::ffi::c_uint)
        .wrapping_rem(6 as ::core::ffi::c_uint) as color;
    if l_around as ::core::ffi::c_uint
        == (rotating_face as ::core::ffi::c_uint)
            .wrapping_add(3 as ::core::ffi::c_uint)
            .wrapping_rem(6 as ::core::ffi::c_uint)
        || l_around as ::core::ffi::c_uint == rotating_face as ::core::ffi::c_uint
    {
        return (l_around as ::core::ffi::c_uint)
            .wrapping_add(5 as ::core::ffi::c_uint)
            .wrapping_rem(6 as ::core::ffi::c_uint) as color;
    }
    return l_around;
}
unsafe extern "C" fn adjacent_right(
    mut rotating_face: color,
    mut around: color,
) -> color {
    let mut r_around: color = (around as ::core::ffi::c_uint)
        .wrapping_add(1 as ::core::ffi::c_uint)
        .wrapping_rem(6 as ::core::ffi::c_uint) as color;
    if r_around as ::core::ffi::c_uint
        == (rotating_face as ::core::ffi::c_uint)
            .wrapping_add(3 as ::core::ffi::c_uint)
            .wrapping_rem(6 as ::core::ffi::c_uint)
        || r_around as ::core::ffi::c_uint == rotating_face as ::core::ffi::c_uint
    {
        return (r_around as ::core::ffi::c_uint)
            .wrapping_add(1 as ::core::ffi::c_uint)
            .wrapping_rem(6 as ::core::ffi::c_uint) as color;
    }
    return r_around;
}
unsafe extern "C" fn adjacent_cw(mut rotating_face: color, mut around: color) -> color {
    if !(around as ::core::ffi::c_uint
        != (rotating_face as ::core::ffi::c_uint)
            .wrapping_add(3 as ::core::ffi::c_uint)
            .wrapping_rem(6 as ::core::ffi::c_uint)) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"adjacent_cw\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            29 as ::core::ffi::c_int,
            b"around != REAR(rotating_face)\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if (rotating_face as ::core::ffi::c_uint).wrapping_rem(2 as ::core::ffi::c_uint)
        == 1 as ::core::ffi::c_uint
    {
        return adjacent_right(rotating_face, around);
    }
    return adjacent_left(rotating_face, around);
}
unsafe extern "C" fn adjacent_ccw(mut rotating_face: color, mut around: color) -> color {
    if !(around as ::core::ffi::c_uint
        != (rotating_face as ::core::ffi::c_uint)
            .wrapping_add(3 as ::core::ffi::c_uint)
            .wrapping_rem(6 as ::core::ffi::c_uint)) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 13],
                [::core::ffi::c_char; 13],
            >(*b"adjacent_ccw\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            39 as ::core::ffi::c_int,
            b"around != REAR(rotating_face)\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if (rotating_face as ::core::ffi::c_uint).wrapping_rem(2 as ::core::ffi::c_uint)
        == 1 as ::core::ffi::c_uint
    {
        return adjacent_left(rotating_face, around);
    }
    return adjacent_right(rotating_face, around);
}
#[no_mangle]
pub unsafe extern "C" fn populate_initial() -> cube_t {
    let mut cube: cube_t = malloc(
        (::core::mem::size_of::<*mut color>() as size_t).wrapping_mul(6 as size_t),
    ) as cube_t;
    let mut face: color = RED;
    while face as ::core::ffi::c_uint
        <= WHITE as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        let ref mut fresh0 = *cube.offset(face as isize);
        *fresh0 = malloc(
            (::core::mem::size_of::<color>() as size_t).wrapping_mul(8 as size_t),
        ) as *mut color;
        let mut pos: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while pos < 8 as ::core::ffi::c_int {
            *(*cube.offset(face as isize)).offset(pos as isize) = face;
            pos += 1;
        }
        face += 1;
    }
    return cube;
}
#[no_mangle]
pub unsafe extern "C" fn populate_specific(mut data: *const [color; 8]) -> cube_t {
    let mut cube: cube_t = malloc(
        (::core::mem::size_of::<*mut color>() as size_t).wrapping_mul(6 as size_t),
    ) as cube_t;
    let mut face: color = RED;
    while face as ::core::ffi::c_uint
        <= WHITE as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        let ref mut fresh1 = *cube.offset(face as isize);
        *fresh1 = malloc(
            (::core::mem::size_of::<color>() as size_t).wrapping_mul(8 as size_t),
        ) as *mut color;
        let mut pos: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while pos < 8 as ::core::ffi::c_int {
            *(*cube.offset(face as isize)).offset(pos as isize) = (*data
                .offset(face as isize))[pos as usize];
            pos += 1;
        }
        face += 1;
    }
    return cube;
}
#[no_mangle]
pub unsafe extern "C" fn cube_free(mut cube: cube_t) {
    let mut face: color = RED;
    while face as ::core::ffi::c_uint
        <= WHITE as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        free(*cube.offset(face as isize) as *mut ::core::ffi::c_void);
        face += 1;
    }
    free(cube as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn cube_hash(cube: cube_t) -> ::core::ffi::c_uint {
    let mut hash: ::core::ffi::c_uint = 0 as ::core::ffi::c_uint;
    let mut face: color = RED;
    while face as ::core::ffi::c_uint
        <= WHITE as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        let mut pos: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while pos < 4 as ::core::ffi::c_int {
            if *(*cube.offset(face as isize))
                .offset((2 as ::core::ffi::c_int * pos) as isize) as ::core::ffi::c_uint
                != face as ::core::ffi::c_uint
                || *(*cube.offset(face as isize))
                    .offset(
                        (2 as ::core::ffi::c_int * pos + 1 as ::core::ffi::c_int)
                            as isize,
                    ) as ::core::ffi::c_uint != face as ::core::ffi::c_uint
            {
                hash = hash.wrapping_add(1);
            }
            hash = hash << 1 as ::core::ffi::c_int;
            pos += 1;
        }
        face += 1;
    }
    return hash;
}
#[no_mangle]
pub unsafe extern "C" fn ecube_init(mut cube: cube_t) -> ecube_t {
    let mut ecube: ecube_t = malloc(::core::mem::size_of::<ecube_struct>() as size_t)
        as ecube_t;
    (*ecube).cube = cube;
    (*ecube).entropy = find_entropy(cube);
    (*ecube).hash = cube_hash(cube) as ::core::ffi::c_int;
    return ecube;
}
#[no_mangle]
pub unsafe extern "C" fn cube_clone(mut cube: cube_t) -> cube_t {
    let mut new_cube: cube_t = malloc(
        (::core::mem::size_of::<*mut color>() as size_t).wrapping_mul(6 as size_t),
    ) as cube_t;
    let mut face: color = RED;
    while face as ::core::ffi::c_uint
        <= WHITE as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        let ref mut fresh2 = *new_cube.offset(face as isize);
        *fresh2 = malloc(
            (::core::mem::size_of::<color>() as size_t).wrapping_mul(8 as size_t),
        ) as *mut color;
        let mut pos: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while pos < 8 as ::core::ffi::c_int {
            *(*new_cube.offset(face as isize)).offset(pos as isize) = *(*cube
                .offset(face as isize))
                .offset(pos as isize);
            pos += 1;
        }
        face += 1;
    }
    return new_cube;
}
#[no_mangle]
pub unsafe extern "C" fn new_cube_rotate_face(
    cube: cube_t,
    mut face: color,
    mut direction: rotation,
) -> cube_t {
    let mut new_cube: cube_t = cube_clone(cube);
    rotate_face(new_cube, face, direction);
    return new_cube;
}
#[no_mangle]
pub unsafe extern "C" fn rotate_face(
    mut cube: cube_t,
    mut face: color,
    mut direction: rotation,
) {
    if cube.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 12],
                [::core::ffi::c_char; 12],
            >(*b"rotate_face\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            133 as ::core::ffi::c_int,
            b"cube != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut g: color = top[face as usize];
    let mut w: color = adjacent_cw(face, g);
    let mut y: color = adjacent_cw(face, w);
    let mut b: color = adjacent_cw(face, y);
    let mut temp: color = RED;
    if direction as ::core::ffi::c_uint
        == CW as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        let mut tmp: color = *(*cube.offset(g as isize))
            .offset(0 as ::core::ffi::c_int as isize);
        *(*cube.offset(g as isize)).offset(0 as ::core::ffi::c_int as isize) = *(*cube
            .offset(w as isize))
            .offset(4 as ::core::ffi::c_int as isize);
        *(*cube.offset(w as isize)).offset(4 as ::core::ffi::c_int as isize) = tmp;
        let mut tmp_0: color = *(*cube.offset(g as isize))
            .offset(7 as ::core::ffi::c_int as isize);
        *(*cube.offset(g as isize)).offset(7 as ::core::ffi::c_int as isize) = *(*cube
            .offset(w as isize))
            .offset(3 as ::core::ffi::c_int as isize);
        *(*cube.offset(w as isize)).offset(3 as ::core::ffi::c_int as isize) = tmp_0;
        let mut tmp_1: color = *(*cube.offset(g as isize))
            .offset(6 as ::core::ffi::c_int as isize);
        *(*cube.offset(g as isize)).offset(6 as ::core::ffi::c_int as isize) = *(*cube
            .offset(w as isize))
            .offset(2 as ::core::ffi::c_int as isize);
        *(*cube.offset(w as isize)).offset(2 as ::core::ffi::c_int as isize) = tmp_1;
        let mut tmp_2: color = *(*cube.offset(b as isize))
            .offset(2 as ::core::ffi::c_int as isize);
        *(*cube.offset(b as isize)).offset(2 as ::core::ffi::c_int as isize) = *(*cube
            .offset(g as isize))
            .offset(0 as ::core::ffi::c_int as isize);
        *(*cube.offset(g as isize)).offset(0 as ::core::ffi::c_int as isize) = tmp_2;
        let mut tmp_3: color = *(*cube.offset(b as isize))
            .offset(1 as ::core::ffi::c_int as isize);
        *(*cube.offset(b as isize)).offset(1 as ::core::ffi::c_int as isize) = *(*cube
            .offset(g as isize))
            .offset(7 as ::core::ffi::c_int as isize);
        *(*cube.offset(g as isize)).offset(7 as ::core::ffi::c_int as isize) = tmp_3;
        let mut tmp_4: color = *(*cube.offset(b as isize))
            .offset(0 as ::core::ffi::c_int as isize);
        *(*cube.offset(b as isize)).offset(0 as ::core::ffi::c_int as isize) = *(*cube
            .offset(g as isize))
            .offset(6 as ::core::ffi::c_int as isize);
        *(*cube.offset(g as isize)).offset(6 as ::core::ffi::c_int as isize) = tmp_4;
        let mut tmp_5: color = *(*cube.offset(y as isize))
            .offset(6 as ::core::ffi::c_int as isize);
        *(*cube.offset(y as isize)).offset(6 as ::core::ffi::c_int as isize) = *(*cube
            .offset(b as isize))
            .offset(2 as ::core::ffi::c_int as isize);
        *(*cube.offset(b as isize)).offset(2 as ::core::ffi::c_int as isize) = tmp_5;
        let mut tmp_6: color = *(*cube.offset(y as isize))
            .offset(5 as ::core::ffi::c_int as isize);
        *(*cube.offset(y as isize)).offset(5 as ::core::ffi::c_int as isize) = *(*cube
            .offset(b as isize))
            .offset(1 as ::core::ffi::c_int as isize);
        *(*cube.offset(b as isize)).offset(1 as ::core::ffi::c_int as isize) = tmp_6;
        let mut tmp_7: color = *(*cube.offset(y as isize))
            .offset(4 as ::core::ffi::c_int as isize);
        *(*cube.offset(y as isize)).offset(4 as ::core::ffi::c_int as isize) = *(*cube
            .offset(b as isize))
            .offset(0 as ::core::ffi::c_int as isize);
        *(*cube.offset(b as isize)).offset(0 as ::core::ffi::c_int as isize) = tmp_7;
        temp = *(*cube.offset(face as isize)).offset(0 as ::core::ffi::c_int as isize);
        *(*cube.offset(face as isize)).offset(0 as ::core::ffi::c_int as isize) = *(*cube
            .offset(face as isize))
            .offset(6 as ::core::ffi::c_int as isize);
        *(*cube.offset(face as isize)).offset(6 as ::core::ffi::c_int as isize) = *(*cube
            .offset(face as isize))
            .offset(4 as ::core::ffi::c_int as isize);
        *(*cube.offset(face as isize)).offset(4 as ::core::ffi::c_int as isize) = *(*cube
            .offset(face as isize))
            .offset(2 as ::core::ffi::c_int as isize);
        *(*cube.offset(face as isize)).offset(2 as ::core::ffi::c_int as isize) = temp;
        temp = *(*cube.offset(face as isize)).offset(1 as ::core::ffi::c_int as isize);
        *(*cube.offset(face as isize)).offset(1 as ::core::ffi::c_int as isize) = *(*cube
            .offset(face as isize))
            .offset(7 as ::core::ffi::c_int as isize);
        *(*cube.offset(face as isize)).offset(7 as ::core::ffi::c_int as isize) = *(*cube
            .offset(face as isize))
            .offset(5 as ::core::ffi::c_int as isize);
        *(*cube.offset(face as isize)).offset(5 as ::core::ffi::c_int as isize) = *(*cube
            .offset(face as isize))
            .offset(3 as ::core::ffi::c_int as isize);
        *(*cube.offset(face as isize)).offset(3 as ::core::ffi::c_int as isize) = temp;
    } else {
        let mut tmp_8: color = *(*cube.offset(g as isize))
            .offset(0 as ::core::ffi::c_int as isize);
        *(*cube.offset(g as isize)).offset(0 as ::core::ffi::c_int as isize) = *(*cube
            .offset(b as isize))
            .offset(2 as ::core::ffi::c_int as isize);
        *(*cube.offset(b as isize)).offset(2 as ::core::ffi::c_int as isize) = tmp_8;
        let mut tmp_9: color = *(*cube.offset(g as isize))
            .offset(7 as ::core::ffi::c_int as isize);
        *(*cube.offset(g as isize)).offset(7 as ::core::ffi::c_int as isize) = *(*cube
            .offset(b as isize))
            .offset(1 as ::core::ffi::c_int as isize);
        *(*cube.offset(b as isize)).offset(1 as ::core::ffi::c_int as isize) = tmp_9;
        let mut tmp_10: color = *(*cube.offset(g as isize))
            .offset(6 as ::core::ffi::c_int as isize);
        *(*cube.offset(g as isize)).offset(6 as ::core::ffi::c_int as isize) = *(*cube
            .offset(b as isize))
            .offset(0 as ::core::ffi::c_int as isize);
        *(*cube.offset(b as isize)).offset(0 as ::core::ffi::c_int as isize) = tmp_10;
        let mut tmp_11: color = *(*cube.offset(w as isize))
            .offset(4 as ::core::ffi::c_int as isize);
        *(*cube.offset(w as isize)).offset(4 as ::core::ffi::c_int as isize) = *(*cube
            .offset(g as isize))
            .offset(0 as ::core::ffi::c_int as isize);
        *(*cube.offset(g as isize)).offset(0 as ::core::ffi::c_int as isize) = tmp_11;
        let mut tmp_12: color = *(*cube.offset(w as isize))
            .offset(3 as ::core::ffi::c_int as isize);
        *(*cube.offset(w as isize)).offset(3 as ::core::ffi::c_int as isize) = *(*cube
            .offset(g as isize))
            .offset(7 as ::core::ffi::c_int as isize);
        *(*cube.offset(g as isize)).offset(7 as ::core::ffi::c_int as isize) = tmp_12;
        let mut tmp_13: color = *(*cube.offset(w as isize))
            .offset(2 as ::core::ffi::c_int as isize);
        *(*cube.offset(w as isize)).offset(2 as ::core::ffi::c_int as isize) = *(*cube
            .offset(g as isize))
            .offset(6 as ::core::ffi::c_int as isize);
        *(*cube.offset(g as isize)).offset(6 as ::core::ffi::c_int as isize) = tmp_13;
        let mut tmp_14: color = *(*cube.offset(y as isize))
            .offset(6 as ::core::ffi::c_int as isize);
        *(*cube.offset(y as isize)).offset(6 as ::core::ffi::c_int as isize) = *(*cube
            .offset(w as isize))
            .offset(4 as ::core::ffi::c_int as isize);
        *(*cube.offset(w as isize)).offset(4 as ::core::ffi::c_int as isize) = tmp_14;
        let mut tmp_15: color = *(*cube.offset(y as isize))
            .offset(5 as ::core::ffi::c_int as isize);
        *(*cube.offset(y as isize)).offset(5 as ::core::ffi::c_int as isize) = *(*cube
            .offset(w as isize))
            .offset(3 as ::core::ffi::c_int as isize);
        *(*cube.offset(w as isize)).offset(3 as ::core::ffi::c_int as isize) = tmp_15;
        let mut tmp_16: color = *(*cube.offset(y as isize))
            .offset(4 as ::core::ffi::c_int as isize);
        *(*cube.offset(y as isize)).offset(4 as ::core::ffi::c_int as isize) = *(*cube
            .offset(w as isize))
            .offset(2 as ::core::ffi::c_int as isize);
        *(*cube.offset(w as isize)).offset(2 as ::core::ffi::c_int as isize) = tmp_16;
        temp = *(*cube.offset(face as isize)).offset(0 as ::core::ffi::c_int as isize);
        *(*cube.offset(face as isize)).offset(0 as ::core::ffi::c_int as isize) = *(*cube
            .offset(face as isize))
            .offset(2 as ::core::ffi::c_int as isize);
        *(*cube.offset(face as isize)).offset(2 as ::core::ffi::c_int as isize) = *(*cube
            .offset(face as isize))
            .offset(4 as ::core::ffi::c_int as isize);
        *(*cube.offset(face as isize)).offset(4 as ::core::ffi::c_int as isize) = *(*cube
            .offset(face as isize))
            .offset(6 as ::core::ffi::c_int as isize);
        *(*cube.offset(face as isize)).offset(6 as ::core::ffi::c_int as isize) = temp;
        temp = *(*cube.offset(face as isize)).offset(1 as ::core::ffi::c_int as isize);
        *(*cube.offset(face as isize)).offset(1 as ::core::ffi::c_int as isize) = *(*cube
            .offset(face as isize))
            .offset(3 as ::core::ffi::c_int as isize);
        *(*cube.offset(face as isize)).offset(3 as ::core::ffi::c_int as isize) = *(*cube
            .offset(face as isize))
            .offset(5 as ::core::ffi::c_int as isize);
        *(*cube.offset(face as isize)).offset(5 as ::core::ffi::c_int as isize) = *(*cube
            .offset(face as isize))
            .offset(7 as ::core::ffi::c_int as isize);
        *(*cube.offset(face as isize)).offset(7 as ::core::ffi::c_int as isize) = temp;
    };
}
#[no_mangle]
pub unsafe extern "C" fn print_cube(cube: cube_t) {
    let mut face: color = RED;
    while face as ::core::ffi::c_uint
        <= WHITE as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        printf(
            b"%c %c %c\n%c %c %c\n%c %c %c\n\0" as *const u8
                as *const ::core::ffi::c_char,
            color_code[*(*cube.offset(face as isize))
                .offset(0 as ::core::ffi::c_int as isize) as usize]
                as ::core::ffi::c_int,
            color_code[*(*cube.offset(face as isize))
                .offset(1 as ::core::ffi::c_int as isize) as usize]
                as ::core::ffi::c_int,
            color_code[*(*cube.offset(face as isize))
                .offset(2 as ::core::ffi::c_int as isize) as usize]
                as ::core::ffi::c_int,
            color_code[*(*cube.offset(face as isize))
                .offset(7 as ::core::ffi::c_int as isize) as usize]
                as ::core::ffi::c_int,
            color_code[face as usize] as ::core::ffi::c_int,
            color_code[*(*cube.offset(face as isize))
                .offset(3 as ::core::ffi::c_int as isize) as usize]
                as ::core::ffi::c_int,
            color_code[*(*cube.offset(face as isize))
                .offset(6 as ::core::ffi::c_int as isize) as usize]
                as ::core::ffi::c_int,
            color_code[*(*cube.offset(face as isize))
                .offset(5 as ::core::ffi::c_int as isize) as usize]
                as ::core::ffi::c_int,
            color_code[*(*cube.offset(face as isize))
                .offset(4 as ::core::ffi::c_int as isize) as usize] as ::core::ffi::c_int,
        );
        printf(b"-----\n\0" as *const u8 as *const ::core::ffi::c_char);
        face += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn cube_compare_equal(cube1: cube_t, cube2: cube_t) -> bool_0 {
    let mut face: color = RED;
    while face as ::core::ffi::c_uint
        <= WHITE as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        let mut pos: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while pos < 8 as ::core::ffi::c_int {
            if *(*cube1.offset(face as isize)).offset(pos as isize)
                as ::core::ffi::c_uint
                != *(*cube2.offset(face as isize)).offset(pos as isize)
                    as ::core::ffi::c_uint
            {
                return false_0;
            }
            pos += 1;
        }
        face += 1;
    }
    return true_0;
}
#[no_mangle]
pub unsafe extern "C" fn find_entropy(cube: cube_t) -> ::core::ffi::c_int {
    let mut count: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut face: color = RED;
    while face as ::core::ffi::c_uint
        <= WHITE as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        let mut pos: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while pos < 8 as ::core::ffi::c_int {
            if *(*cube.offset(face as isize)).offset(pos as isize) as ::core::ffi::c_uint
                != face as ::core::ffi::c_uint
            {
                count += 1;
            }
            pos += 1;
        }
        face += 1;
    }
    return count;
}
#[no_mangle]
pub unsafe extern "C" fn test_adj_functions() {
    printf(b"Testing adjacent_cw...\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_cw(RED, YELLOW) == BLUE\0" as *const u8 as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        273 as ::core::ffi::c_int,
    );
    if !(adjacent_cw(RED, YELLOW) as ::core::ffi::c_uint
        == BLUE as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            273 as ::core::ffi::c_int,
            b"adjacent_cw(RED, YELLOW) == BLUE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_cw(RED, BLUE) == GREEN\0" as *const u8 as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        274 as ::core::ffi::c_int,
    );
    if !(adjacent_cw(RED, BLUE) as ::core::ffi::c_uint
        == GREEN as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            274 as ::core::ffi::c_int,
            b"adjacent_cw(RED, BLUE) == GREEN\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_cw(RED, WHITE) == YELLOW\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        275 as ::core::ffi::c_int,
    );
    if !(adjacent_cw(RED, WHITE) as ::core::ffi::c_uint
        == YELLOW as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            275 as ::core::ffi::c_int,
            b"adjacent_cw(RED, WHITE) == YELLOW\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_cw(RED, GREEN) == WHITE\0" as *const u8 as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        276 as ::core::ffi::c_int,
    );
    if !(adjacent_cw(RED, GREEN) as ::core::ffi::c_uint
        == WHITE as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            276 as ::core::ffi::c_int,
            b"adjacent_cw(RED, GREEN) == WHITE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_cw(GREEN, RED) == BLUE\0" as *const u8 as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        277 as ::core::ffi::c_int,
    );
    if !(adjacent_cw(GREEN, RED) as ::core::ffi::c_uint
        == BLUE as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            277 as ::core::ffi::c_int,
            b"adjacent_cw(GREEN, RED) == BLUE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_cw(GREEN, WHITE) == RED\0" as *const u8 as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        278 as ::core::ffi::c_int,
    );
    if !(adjacent_cw(GREEN, WHITE) as ::core::ffi::c_uint
        == RED as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            278 as ::core::ffi::c_int,
            b"adjacent_cw(GREEN, WHITE) == RED\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_cw(GREEN, ORANGE) == WHITE\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        279 as ::core::ffi::c_int,
    );
    if !(adjacent_cw(GREEN, ORANGE) as ::core::ffi::c_uint
        == WHITE as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            279 as ::core::ffi::c_int,
            b"adjacent_cw(GREEN, ORANGE) == WHITE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_cw(GREEN, BLUE) == ORANGE\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        280 as ::core::ffi::c_int,
    );
    if !(adjacent_cw(GREEN, BLUE) as ::core::ffi::c_uint
        == ORANGE as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            280 as ::core::ffi::c_int,
            b"adjacent_cw(GREEN, BLUE) == ORANGE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_cw(WHITE, ORANGE) == YELLOW\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        281 as ::core::ffi::c_int,
    );
    if !(adjacent_cw(WHITE, ORANGE) as ::core::ffi::c_uint
        == YELLOW as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            281 as ::core::ffi::c_int,
            b"adjacent_cw(WHITE, ORANGE) == YELLOW\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_cw(WHITE, GREEN) == ORANGE\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        282 as ::core::ffi::c_int,
    );
    if !(adjacent_cw(WHITE, GREEN) as ::core::ffi::c_uint
        == ORANGE as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            282 as ::core::ffi::c_int,
            b"adjacent_cw(WHITE, GREEN) == ORANGE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_cw(YELLOW, WHITE) == ORANGE\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        283 as ::core::ffi::c_int,
    );
    if !(adjacent_cw(YELLOW, WHITE) as ::core::ffi::c_uint
        == ORANGE as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            283 as ::core::ffi::c_int,
            b"adjacent_cw(YELLOW, WHITE) == ORANGE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_cw(YELLOW, RED) == WHITE\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        284 as ::core::ffi::c_int,
    );
    if !(adjacent_cw(YELLOW, RED) as ::core::ffi::c_uint
        == WHITE as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            284 as ::core::ffi::c_int,
            b"adjacent_cw(YELLOW, RED) == WHITE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"Testing adjacent_ccw...\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_ccw(RED, BLUE) == YELLOW\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        287 as ::core::ffi::c_int,
    );
    if !(adjacent_ccw(RED, BLUE) as ::core::ffi::c_uint
        == YELLOW as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            287 as ::core::ffi::c_int,
            b"adjacent_ccw(RED, BLUE) == YELLOW\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_ccw(RED, GREEN == BLUE)\0" as *const u8 as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        288 as ::core::ffi::c_int,
    );
    if (adjacent_ccw(
        RED,
        (GREEN as ::core::ffi::c_int == BLUE as ::core::ffi::c_int) as ::core::ffi::c_int
            as color,
    ) as u64 == 0) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            288 as ::core::ffi::c_int,
            b"adjacent_ccw(RED, GREEN == BLUE)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_ccw(RED, YELLOW) == WHITE\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        289 as ::core::ffi::c_int,
    );
    if !(adjacent_ccw(RED, YELLOW) as ::core::ffi::c_uint
        == WHITE as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            289 as ::core::ffi::c_int,
            b"adjacent_ccw(RED, YELLOW) == WHITE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_ccw(RED, WHITE) == GREEN\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        290 as ::core::ffi::c_int,
    );
    if !(adjacent_ccw(RED, WHITE) as ::core::ffi::c_uint
        == GREEN as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            290 as ::core::ffi::c_int,
            b"adjacent_ccw(RED, WHITE) == GREEN\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_ccw(GREEN, BLUE) == RED\0" as *const u8 as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        291 as ::core::ffi::c_int,
    );
    if !(adjacent_ccw(GREEN, BLUE) as ::core::ffi::c_uint
        == RED as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            291 as ::core::ffi::c_int,
            b"adjacent_ccw(GREEN, BLUE) == RED\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_ccw(GREEN, RED) == WHITE\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        292 as ::core::ffi::c_int,
    );
    if !(adjacent_ccw(GREEN, RED) as ::core::ffi::c_uint
        == WHITE as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            292 as ::core::ffi::c_int,
            b"adjacent_ccw(GREEN, RED) == WHITE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_ccw(GREEN, WHITE) == ORANGE\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        293 as ::core::ffi::c_int,
    );
    if !(adjacent_ccw(GREEN, WHITE) as ::core::ffi::c_uint
        == ORANGE as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            293 as ::core::ffi::c_int,
            b"adjacent_ccw(GREEN, WHITE) == ORANGE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_ccw(GREEN, ORANGE) == BLUE\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        294 as ::core::ffi::c_int,
    );
    if !(adjacent_ccw(GREEN, ORANGE) as ::core::ffi::c_uint
        == BLUE as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            294 as ::core::ffi::c_int,
            b"adjacent_ccw(GREEN, ORANGE) == BLUE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_ccw(WHITE, YELLOW) == ORANGE\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        295 as ::core::ffi::c_int,
    );
    if !(adjacent_ccw(WHITE, YELLOW) as ::core::ffi::c_uint
        == ORANGE as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            295 as ::core::ffi::c_int,
            b"adjacent_ccw(WHITE, YELLOW) == ORANGE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_ccw(WHITE, ORANGE) == GREEN\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        296 as ::core::ffi::c_int,
    );
    if !(adjacent_ccw(WHITE, ORANGE) as ::core::ffi::c_uint
        == GREEN as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            296 as ::core::ffi::c_int,
            b"adjacent_ccw(WHITE, ORANGE) == GREEN\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_ccw(YELLOW, ORANGE) == WHITE\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        297 as ::core::ffi::c_int,
    );
    if !(adjacent_ccw(YELLOW, ORANGE) as ::core::ffi::c_uint
        == WHITE as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            297 as ::core::ffi::c_int,
            b"adjacent_ccw(YELLOW, ORANGE) == WHITE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"adjacent_ccw(YELLOW, WHITE) == RED\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
        298 as ::core::ffi::c_int,
    );
    if !(adjacent_ccw(YELLOW, WHITE) as ::core::ffi::c_uint
        == RED as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_adj_functions\0")
                .as_ptr(),
            b"rubik_model.c\0" as *const u8 as *const ::core::ffi::c_char,
            298 as ::core::ffi::c_int,
            b"adjacent_ccw(YELLOW, WHITE) == RED\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
}
