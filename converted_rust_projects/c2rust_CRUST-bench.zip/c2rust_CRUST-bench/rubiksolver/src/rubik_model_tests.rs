#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn populate_specific(cube_data: *const [color; 8]) -> cube_t;
    fn rotate_face(cube: cube_t, face: color, direction: rotation);
    fn cube_compare_equal(cube1: cube_t, cube2: cube_t) -> bool_0;
    fn find_entropy(cube: cube_t) -> ::core::ffi::c_int;
    fn test_adj_functions();
    fn cube_free(cube: cube_t);
}
pub type bool_0 = ::core::ffi::c_uint;
pub const true_0: bool_0 = 1;
pub const false_0: bool_0 = 0;
pub type color = ::core::ffi::c_uint;
pub const WHITE: color = 5;
pub const YELLOW: color = 4;
pub const ORANGE: color = 3;
pub const BLUE: color = 2;
pub const GREEN: color = 1;
pub const RED: color = 0;
pub type rotation = ::core::ffi::c_uint;
pub const CCW: rotation = 1;
pub const CW: rotation = 0;
pub type cube_t = *mut *mut color;
unsafe fn main_0() -> ::core::ffi::c_int {
    printf(b"Running rubik_model tests\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"Testing REAR...\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"REAR(RED) == ORANGE\0" as *const u8 as *const ::core::ffi::c_char,
        b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
        12 as ::core::ffi::c_int,
    );
    if !((RED as ::core::ffi::c_int + 3 as ::core::ffi::c_int) % 6 as ::core::ffi::c_int
        == ORANGE as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
            12 as ::core::ffi::c_int,
            b"((RED + 3) % 6) == ORANGE\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"REAR(GREEN) == YELLOW\0" as *const u8 as *const ::core::ffi::c_char,
        b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
        13 as ::core::ffi::c_int,
    );
    if !((GREEN as ::core::ffi::c_int + 3 as ::core::ffi::c_int)
        % 6 as ::core::ffi::c_int == YELLOW as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
            13 as ::core::ffi::c_int,
            b"((GREEN + 3) % 6) == YELLOW\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"REAR(BLUE) == WHITE\0" as *const u8 as *const ::core::ffi::c_char,
        b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
        14 as ::core::ffi::c_int,
    );
    if !((BLUE as ::core::ffi::c_int + 3 as ::core::ffi::c_int) % 6 as ::core::ffi::c_int
        == WHITE as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
            14 as ::core::ffi::c_int,
            b"((BLUE + 3) % 6) == WHITE\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"REAR(REAR(RED)) == RED\0" as *const u8 as *const ::core::ffi::c_char,
        b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
        15 as ::core::ffi::c_int,
    );
    if !(((RED as ::core::ffi::c_int + 3 as ::core::ffi::c_int) % 6 as ::core::ffi::c_int
        + 3 as ::core::ffi::c_int) % 6 as ::core::ffi::c_int
        == RED as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
            15 as ::core::ffi::c_int,
            b"((((RED + 3) % 6) + 3) % 6) == RED\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"REAR(REAR(GREEN)) == GREEN\0" as *const u8 as *const ::core::ffi::c_char,
        b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
        16 as ::core::ffi::c_int,
    );
    if !(((GREEN as ::core::ffi::c_int + 3 as ::core::ffi::c_int)
        % 6 as ::core::ffi::c_int + 3 as ::core::ffi::c_int) % 6 as ::core::ffi::c_int
        == GREEN as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
            16 as ::core::ffi::c_int,
            b"((((GREEN + 3) % 6) + 3) % 6) == GREEN\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"REAR(REAR(BLUE)) == BLUE\0" as *const u8 as *const ::core::ffi::c_char,
        b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
        17 as ::core::ffi::c_int,
    );
    if !(((BLUE as ::core::ffi::c_int + 3 as ::core::ffi::c_int)
        % 6 as ::core::ffi::c_int + 3 as ::core::ffi::c_int) % 6 as ::core::ffi::c_int
        == BLUE as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
            17 as ::core::ffi::c_int,
            b"((((BLUE + 3) % 6) + 3) % 6) == BLUE\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    test_adj_functions();
    printf(
        b"Testing cube_compare_equal...\n\0" as *const u8 as *const ::core::ffi::c_char,
    );
    let test_cube_data: [[color; 8]; 6] = [
        [RED, RED, RED, RED, RED, RED, RED, RED],
        [GREEN, YELLOW, BLUE, ORANGE, ORANGE, YELLOW, GREEN, GREEN],
        [BLUE, BLUE, BLUE, ORANGE, ORANGE, GREEN, ORANGE, BLUE],
        [WHITE, WHITE, WHITE, GREEN, GREEN, WHITE, YELLOW, BLUE],
        [ORANGE, GREEN, BLUE, YELLOW, YELLOW, YELLOW, YELLOW, BLUE],
        [YELLOW, ORANGE, WHITE, WHITE, WHITE, WHITE, GREEN, ORANGE],
    ];
    let mut test_cube: cube_t = populate_specific(test_cube_data.as_ptr());
    let mut original: cube_t = populate_specific(test_cube_data.as_ptr());
    let output1_data: [[color; 8]; 6] = [
        [RED, RED, RED, RED, BLUE, ORANGE, ORANGE, RED],
        [GREEN, YELLOW, BLUE, ORANGE, ORANGE, YELLOW, GREEN, GREEN],
        [BLUE, BLUE, YELLOW, BLUE, WHITE, GREEN, ORANGE, BLUE],
        [WHITE, WHITE, WHITE, GREEN, GREEN, WHITE, YELLOW, ORANGE],
        [YELLOW, BLUE, ORANGE, GREEN, BLUE, YELLOW, YELLOW, YELLOW],
        [RED, RED, RED, WHITE, WHITE, WHITE, GREEN, ORANGE],
    ];
    let mut output1: cube_t = populate_specific(output1_data.as_ptr());
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"cube_compare_equal(test_cube, original)\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
        44 as ::core::ffi::c_int,
    );
    if (cube_compare_equal(test_cube, original) as u64 == 0) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
            44 as ::core::ffi::c_int,
            b"cube_compare_equal(test_cube, original)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"!cube_compare_equal(test_cube, output1)\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
        45 as ::core::ffi::c_int,
    );
    if (cube_compare_equal(test_cube, output1) as u64 != 0) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
            45 as ::core::ffi::c_int,
            b"!cube_compare_equal(test_cube, output1)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"Testing SWAP_COLOR...\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut r: color = RED;
    let mut g: color = GREEN;
    let mut tmp: color = r;
    r = g;
    g = tmp;
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"r == GREEN && g == RED\0" as *const u8 as *const ::core::ffi::c_char,
        b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
        50 as ::core::ffi::c_int,
    );
    if !(r as ::core::ffi::c_uint == GREEN as ::core::ffi::c_int as ::core::ffi::c_uint
        && g as ::core::ffi::c_uint == RED as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
            50 as ::core::ffi::c_int,
            b"r == GREEN && g == RED\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut tmp_0: color = r;
    r = g;
    g = tmp_0;
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"r == RED && g == GREEN\0" as *const u8 as *const ::core::ffi::c_char,
        b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
        52 as ::core::ffi::c_int,
    );
    if !(r as ::core::ffi::c_uint == RED as ::core::ffi::c_int as ::core::ffi::c_uint
        && g as ::core::ffi::c_uint
            == GREEN as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
            52 as ::core::ffi::c_int,
            b"r == RED && g == GREEN\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"Testing rotate_face...\n\0" as *const u8 as *const ::core::ffi::c_char);
    rotate_face(test_cube, YELLOW, CW);
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"cube_compare_equal(test_cube, output1)\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
        56 as ::core::ffi::c_int,
    );
    if (cube_compare_equal(test_cube, output1) as u64 == 0) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
            56 as ::core::ffi::c_int,
            b"cube_compare_equal(test_cube, output1)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    rotate_face(test_cube, YELLOW, CCW);
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"cube_compare_equal(test_cube, original)\0" as *const u8
            as *const ::core::ffi::c_char,
        b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
        58 as ::core::ffi::c_int,
    );
    if (cube_compare_equal(test_cube, original) as u64 == 0) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
            58 as ::core::ffi::c_int,
            b"cube_compare_equal(test_cube, original)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    printf(b"Testing find_entropy...\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(
        b"asserting %s at %s:%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"find_entropy(original) == 25\0" as *const u8 as *const ::core::ffi::c_char,
        b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
        61 as ::core::ffi::c_int,
    );
    if !(find_entropy(original) == 25 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"main\0")
                .as_ptr(),
            b"rubik_model_tests.c\0" as *const u8 as *const ::core::ffi::c_char,
            61 as ::core::ffi::c_int,
            b"find_entropy(original) == 25\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    cube_free(test_cube);
    cube_free(original);
    cube_free(output1);
    printf(
        b"rubik_model tests finished successfully\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
