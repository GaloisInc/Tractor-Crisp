#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type heap_struct;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn exit(_: ::core::ffi::c_int) -> !;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn populate_specific(cube_data: *const [color; 8]) -> cube_t;
    fn ecube_init(cube: cube_t) -> ecube_t;
    fn new_cube_rotate_face(cube: cube_t, face: color, direction: rotation) -> cube_t;
    fn cube_compare_equal(cube1: cube_t, cube2: cube_t) -> bool_0;
    fn heap_init(
        init_size: ::core::ffi::c_int,
        is_smaller: Option<
            unsafe extern "C" fn(
                *const ::core::ffi::c_void,
                *const ::core::ffi::c_void,
            ) -> bool_0,
        >,
    ) -> heap_t;
    fn heap_insert(heap: heap_t, element: *const ::core::ffi::c_void) -> bool_0;
    fn heap_delete_min(heap: heap_t) -> *mut ::core::ffi::c_void;
    fn heap_is_empty(heap: heap_t) -> bool_0;
    fn hash_init(
        max_key: ::core::ffi::c_uint,
        hash_function_0: Option<
            unsafe extern "C" fn(*const ::core::ffi::c_void) -> ::core::ffi::c_uint,
        >,
    ) -> hash_t;
    fn hash_insert(hash: hash_t, element: *const ::core::ffi::c_void) -> bool_0;
    fn hash_element_exists(
        hash: hash_t,
        element: *const ::core::ffi::c_void,
        compare_equal: Option<
            unsafe extern "C" fn(
                *const ::core::ffi::c_void,
                *const ::core::ffi::c_void,
            ) -> bool_0,
        >,
    ) -> bool_0;
    fn hash_delete(
        hash: hash_t,
        element: *const ::core::ffi::c_void,
        compare_equal: Option<
            unsafe extern "C" fn(
                *const ::core::ffi::c_void,
                *const ::core::ffi::c_void,
            ) -> bool_0,
        >,
    ) -> bool_0;
}
pub type bool_0 = ::core::ffi::c_uint;
pub const true_0: bool_0 = 1;
pub const false_0: bool_0 = 0;
pub type color = ::core::ffi::c_uint;
pub const WHITE: color = 5;
pub const YELLOW: color = 4;
pub const ORANGE: color = 3;
pub const BLUE: color = 2;
pub const GREEN: color = 1;
pub const RED: color = 0;
pub type rotation = ::core::ffi::c_uint;
pub const CCW: rotation = 1;
pub const CW: rotation = 0;
pub type cube_t = *mut *mut color;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct ecube_struct {
    pub cube: cube_t,
    pub entropy: ::core::ffi::c_int,
    pub hash: ::core::ffi::c_int,
}
pub type ecube_t = *mut ecube_struct;
pub type heap_t = *mut heap_struct;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct bucket_element_struct {
    pub element: *mut ::core::ffi::c_void,
    pub next: *mut bucket_element_struct,
}
pub type bucket_element_t = *mut bucket_element_struct;
pub type bucket_t = bucket_element_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct hash_struct {
    pub buckets: *mut bucket_t,
    pub hash_function: Option<
        unsafe extern "C" fn(*const ::core::ffi::c_void) -> ::core::ffi::c_uint,
    >,
    pub max_key: ::core::ffi::c_uint,
}
pub type hash_t = *mut hash_struct;
#[no_mangle]
pub unsafe extern "C" fn is_better(
    mut ec1: *const ::core::ffi::c_void,
    mut ec2: *const ::core::ffi::c_void,
) -> bool_0 {
    let mut ecube1: ecube_t = ec1 as ecube_t;
    let mut ecube2: ecube_t = ec2 as ecube_t;
    if (*ecube1).entropy < (*ecube2).entropy { return true_0 } else { return false_0 };
}
#[no_mangle]
pub unsafe extern "C" fn hash_function(
    mut element: *const ::core::ffi::c_void,
) -> ::core::ffi::c_uint {
    let mut ecube: ecube_t = element as ecube_t;
    return (*ecube).hash as ::core::ffi::c_uint;
}
#[no_mangle]
pub unsafe extern "C" fn ecube_compare_equal(
    mut ec1: *const ::core::ffi::c_void,
    mut ec2: *const ::core::ffi::c_void,
) -> bool_0 {
    let mut ecube1: ecube_t = ec1 as ecube_t;
    let mut ecube2: ecube_t = ec2 as ecube_t;
    if !(!ecube1.is_null() && !ecube2.is_null()) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"ecube_compare_equal\0")
                .as_ptr(),
            b"solve_rubik.c\0" as *const u8 as *const ::core::ffi::c_char,
            29 as ::core::ffi::c_int,
            b"ecube1 != NULL && ecube2 != NULL\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if (*ecube1).entropy != (*ecube2).entropy {
        return false_0;
    }
    return cube_compare_equal(
        (*ecube1).cube as *mut ::core::ffi::c_void as cube_t,
        (*ecube2).cube as *mut ::core::ffi::c_void as cube_t,
    );
}
unsafe fn main_0() -> ::core::ffi::c_int {
    let cube_data: [[color; 8]; 6] = [
        [RED, RED, RED, RED, RED, RED, RED, RED],
        [GREEN, YELLOW, BLUE, ORANGE, ORANGE, YELLOW, GREEN, GREEN],
        [BLUE, BLUE, BLUE, ORANGE, ORANGE, GREEN, ORANGE, BLUE],
        [WHITE, WHITE, WHITE, GREEN, GREEN, WHITE, YELLOW, BLUE],
        [ORANGE, GREEN, BLUE, YELLOW, YELLOW, YELLOW, YELLOW, BLUE],
        [YELLOW, ORANGE, WHITE, WHITE, WHITE, WHITE, GREEN, ORANGE],
    ];
    let mut count_explored: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut count_unexplored: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    let mut cube: cube_t = populate_specific(cube_data.as_ptr());
    let mut ecube: ecube_t = ecube_init(cube);
    let mut unexplored_hash: hash_t = hash_init(
        33554432 as ::core::ffi::c_uint,
        Some(
            hash_function
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                ) -> ::core::ffi::c_uint,
        ),
    );
    let mut unexplored: heap_t = heap_init(
        5000 as ::core::ffi::c_int,
        Some(
            is_better
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                    *const ::core::ffi::c_void,
                ) -> bool_0,
        ),
    );
    heap_insert(unexplored, ecube as *const ::core::ffi::c_void);
    hash_insert(unexplored_hash, ecube as *const ::core::ffi::c_void);
    let mut explored_hash: hash_t = hash_init(
        33554432 as ::core::ffi::c_uint,
        Some(
            hash_function
                as unsafe extern "C" fn(
                    *const ::core::ffi::c_void,
                ) -> ::core::ffi::c_uint,
        ),
    );
    while heap_is_empty(unexplored) as u64 == 0 {
        printf(
            b"Unexplored nodes = %6d\n\0" as *const u8 as *const ::core::ffi::c_char,
            count_unexplored,
        );
        let mut x: ecube_t = heap_delete_min(unexplored) as ecube_t;
        hash_delete(
            unexplored_hash,
            x as *const ::core::ffi::c_void,
            Some(
                ecube_compare_equal
                    as unsafe extern "C" fn(
                        *const ::core::ffi::c_void,
                        *const ::core::ffi::c_void,
                    ) -> bool_0,
            ),
        );
        count_unexplored -= 1;
        printf(
            b"Entropy of x: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
            (*x).entropy,
        );
        if (*x).entropy == 0 as ::core::ffi::c_int {
            printf(b"Found goal.\n\0" as *const u8 as *const ::core::ffi::c_char);
            exit(0 as ::core::ffi::c_int);
        }
        hash_insert(explored_hash, x as *const ::core::ffi::c_void);
        count_explored += 1;
        printf(
            b"Explored nodes = %6d\n\0" as *const u8 as *const ::core::ffi::c_char,
            count_explored,
        );
        let mut face: color = RED;
        while face as ::core::ffi::c_uint <= 5 as ::core::ffi::c_uint {
            let mut dir: rotation = CW;
            while dir as ::core::ffi::c_uint <= 1 as ::core::ffi::c_uint {
                let mut new_cube: cube_t = new_cube_rotate_face((*x).cube, face, dir);
                let mut y: ecube_t = ecube_init(new_cube);
                if !(hash_element_exists(
                    explored_hash,
                    y as *const ::core::ffi::c_void,
                    Some(
                        ecube_compare_equal
                            as unsafe extern "C" fn(
                                *const ::core::ffi::c_void,
                                *const ::core::ffi::c_void,
                            ) -> bool_0,
                    ),
                ) as u64 != 0)
                {
                    if hash_element_exists(
                        unexplored_hash,
                        y as *const ::core::ffi::c_void,
                        Some(
                            ecube_compare_equal
                                as unsafe extern "C" fn(
                                    *const ::core::ffi::c_void,
                                    *const ::core::ffi::c_void,
                                ) -> bool_0,
                        ),
                    ) as u64 == 0
                    {
                        heap_insert(unexplored, y as *const ::core::ffi::c_void);
                        hash_insert(unexplored_hash, y as *const ::core::ffi::c_void);
                        count_unexplored += 1;
                    }
                }
                dir += 1;
            }
            face += 1;
        }
    }
    return 0;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
