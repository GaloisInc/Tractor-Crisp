#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn strdup(__s1: *const ::core::ffi::c_char) -> *mut ::core::ffi::c_char;
}
pub type TokenType = ::core::ffi::c_uint;
pub const TOKEN_DIS: TokenType = 8;
pub const TOKEN_EOF: TokenType = 7;
pub const TOKEN_LET: TokenType = 6;
pub const TOKEN_SEMICOLON: TokenType = 5;
pub const TOKEN_MINUS: TokenType = 4;
pub const TOKEN_PLUS: TokenType = 3;
pub const TOKEN_ASSIGN: TokenType = 2;
pub const TOKEN_IDENTIFIER: TokenType = 1;
pub const TOKEN_INT: TokenType = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct ASTNode {
    pub type_0: TokenType,
    pub left: *mut ASTNode,
    pub right: *mut ASTNode,
    pub value: *mut ::core::ffi::c_char,
}
pub type size_t = __darwin_size_t;
pub type __darwin_size_t = usize;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn new_ast_node(
    mut type_0: TokenType,
    mut value: *const ::core::ffi::c_char,
) -> *mut ASTNode {
    let mut node: *mut ASTNode = malloc(::core::mem::size_of::<ASTNode>() as size_t)
        as *mut ASTNode;
    (*node).type_0 = type_0;
    (*node).left = 0 as *mut ASTNode;
    (*node).right = 0 as *mut ASTNode;
    if !value.is_null() {
        (*node).value = strdup(value);
    } else {
        (*node).value = 0 as *mut ::core::ffi::c_char;
    }
    return node;
}
#[no_mangle]
pub unsafe extern "C" fn free_ast_node(mut node: *mut ASTNode) {
    if !(*node).left.is_null() {
        free_ast_node((*node).left as *mut ASTNode);
    }
    if !(*node).right.is_null() {
        free_ast_node((*node).right as *mut ASTNode);
    }
    if !(*node).value.is_null() {
        free((*node).value as *mut ::core::ffi::c_void);
    }
    free(node as *mut ::core::ffi::c_void);
}
