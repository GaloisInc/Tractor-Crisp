#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn new_instruction(
        opcode: OpCode,
        operand: *const ::core::ffi::c_char,
    ) -> *mut Instruction;
    fn tokenize(source: *const ::core::ffi::c_char) -> *mut Token;
    fn parse(tokens: *mut Token) -> *mut *mut ASTNode;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
}
pub type TokenType = ::core::ffi::c_uint;
pub const TOKEN_DIS: TokenType = 8;
pub const TOKEN_EOF: TokenType = 7;
pub const TOKEN_LET: TokenType = 6;
pub const TOKEN_SEMICOLON: TokenType = 5;
pub const TOKEN_MINUS: TokenType = 4;
pub const TOKEN_PLUS: TokenType = 3;
pub const TOKEN_ASSIGN: TokenType = 2;
pub const TOKEN_IDENTIFIER: TokenType = 1;
pub const TOKEN_INT: TokenType = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Token {
    pub type_0: TokenType,
    pub value: *mut ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct ASTNode {
    pub type_0: TokenType,
    pub left: *mut ASTNode,
    pub right: *mut ASTNode,
    pub value: *mut ::core::ffi::c_char,
}
pub type OpCode = ::core::ffi::c_uint;
pub const STK_DIS: OpCode = 5;
pub const BINARY_SUB: OpCode = 4;
pub const BINARY_ADD: OpCode = 3;
pub const STORE_NAME: OpCode = 2;
pub const LOAD_NAME: OpCode = 1;
pub const LOAD_CONST: OpCode = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Instruction {
    pub opcode: OpCode,
    pub operand: *mut ::core::ffi::c_char,
}
pub type size_t = __darwin_size_t;
pub type __darwin_size_t = usize;
pub const MAX_STATEMENT: ::core::ffi::c_int = 100 as ::core::ffi::c_int;
pub const MAX_INSTR_IN_STATEMENT: ::core::ffi::c_int = 100 as ::core::ffi::c_int;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn emit(
    mut instructions: *mut Instruction,
    mut count: *mut ::core::ffi::c_int,
    mut opcode: OpCode,
    mut operand: *const ::core::ffi::c_char,
) {
    *instructions.offset(*count as isize) = *new_instruction(opcode, operand);
    *count += 1;
}
#[no_mangle]
pub unsafe extern "C" fn compile_expression(
    mut node: *mut ASTNode,
    mut instructions: *mut Instruction,
    mut count: *mut ::core::ffi::c_int,
) {
    if (*node).type_0 as ::core::ffi::c_uint
        == TOKEN_INT as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        emit(instructions, count, LOAD_CONST, (*node).value);
    } else if (*node).type_0 as ::core::ffi::c_uint
        == TOKEN_IDENTIFIER as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        emit(instructions, count, LOAD_NAME, (*node).value);
    } else if (*node).type_0 as ::core::ffi::c_uint
        == TOKEN_PLUS as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        compile_expression((*node).left as *mut ASTNode, instructions, count);
        compile_expression((*node).right as *mut ASTNode, instructions, count);
        emit(instructions, count, BINARY_ADD, 0 as *const ::core::ffi::c_char);
    } else if (*node).type_0 as ::core::ffi::c_uint
        == TOKEN_MINUS as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        compile_expression((*node).left as *mut ASTNode, instructions, count);
        compile_expression((*node).right as *mut ASTNode, instructions, count);
        emit(instructions, count, BINARY_SUB, 0 as *const ::core::ffi::c_char);
    }
}
#[no_mangle]
pub unsafe extern "C" fn compile_statement(
    mut ast: *mut ASTNode,
    mut instr_count: *mut ::core::ffi::c_int,
) -> *mut Instruction {
    let mut instructions: *mut Instruction = malloc(
        (::core::mem::size_of::<Instruction>() as size_t)
            .wrapping_mul(MAX_INSTR_IN_STATEMENT as size_t),
    ) as *mut Instruction;
    *instr_count = 0 as ::core::ffi::c_int;
    if (*ast).type_0 as ::core::ffi::c_uint
        == TOKEN_LET as ::core::ffi::c_int as ::core::ffi::c_uint
        || (*ast).type_0 as ::core::ffi::c_uint
            == TOKEN_ASSIGN as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        compile_expression((*ast).left as *mut ASTNode, instructions, instr_count);
        emit(instructions, instr_count, STORE_NAME, (*ast).value);
    } else if (*ast).type_0 as ::core::ffi::c_uint
        == TOKEN_DIS as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        compile_expression((*ast).left as *mut ASTNode, instructions, instr_count);
        emit(instructions, instr_count, STK_DIS, (*ast).value);
    }
    return instructions;
}
#[no_mangle]
pub unsafe extern "C" fn compile_asts(
    mut asts: *mut *mut ASTNode,
    mut total_instr_count: *mut ::core::ffi::c_int,
) -> *mut Instruction {
    *total_instr_count = 0 as ::core::ffi::c_int;
    let mut instr_of_all: *mut *mut Instruction = malloc(
        (::core::mem::size_of::<Instruction>() as size_t)
            .wrapping_mul(MAX_INSTR_IN_STATEMENT as size_t)
            .wrapping_mul(MAX_STATEMENT as size_t),
    ) as *mut *mut Instruction;
    let mut instr_count_of_all: *mut ::core::ffi::c_int = malloc(
        (::core::mem::size_of::<::core::ffi::c_int>() as size_t)
            .wrapping_mul(MAX_STATEMENT as size_t),
    ) as *mut ::core::ffi::c_int;
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while !(*asts.offset(i as isize)).is_null() {
        let ref mut fresh0 = *instr_of_all.offset(i as isize);
        *fresh0 = compile_statement(
            *asts.offset(i as isize),
            &mut *instr_count_of_all.offset(i as isize),
        );
        i += 1;
    }
    let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while !(*asts.offset(i_0 as isize)).is_null() {
        *total_instr_count += *instr_count_of_all.offset(i_0 as isize);
        i_0 += 1;
    }
    let mut all_instr: *mut Instruction = malloc(
        (::core::mem::size_of::<Instruction>() as size_t)
            .wrapping_mul(*total_instr_count as size_t),
    ) as *mut Instruction;
    memcpy(
        all_instr as *mut ::core::ffi::c_void,
        *instr_of_all.offset(0 as ::core::ffi::c_int as isize)
            as *const ::core::ffi::c_void,
        (::core::mem::size_of::<Instruction>() as size_t)
            .wrapping_mul(
                *instr_count_of_all.offset(0 as ::core::ffi::c_int as isize) as size_t,
            ),
    );
    let mut copied_count: ::core::ffi::c_int = *instr_count_of_all
        .offset(0 as ::core::ffi::c_int as isize);
    let mut i_1: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    while !(*asts.offset(i_1 as isize)).is_null() {
        memcpy(
            &mut *all_instr.offset(copied_count as isize) as *mut Instruction
                as *mut ::core::ffi::c_void,
            *instr_of_all.offset(i_1 as isize) as *const ::core::ffi::c_void,
            (::core::mem::size_of::<Instruction>() as size_t)
                .wrapping_mul(*instr_count_of_all.offset(i_1 as isize) as size_t),
        );
        copied_count += *instr_count_of_all.offset(i_1 as isize);
        i_1 += 1;
    }
    return all_instr;
}
#[no_mangle]
pub unsafe extern "C" fn compile(
    mut source: *const ::core::ffi::c_char,
    mut instr_count: *mut ::core::ffi::c_int,
) -> *mut Instruction {
    let mut tokens: *mut Token = tokenize(source);
    let mut ast_nodes: *mut *mut ASTNode = parse(tokens);
    let mut instructions: *mut Instruction = compile_asts(ast_nodes, instr_count);
    return instructions;
}
