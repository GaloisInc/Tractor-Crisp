#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types, linkage)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn exit(_: ::core::ffi::c_int) -> !;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strdup(__s1: *const ::core::ffi::c_char) -> *mut ::core::ffi::c_char;
    fn strndup(
        __s1: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> *mut ::core::ffi::c_char;
    static mut _DefaultRuneLocale: _RuneLocale;
    fn __maskrune(_: __darwin_ct_rune_t, _: ::core::ffi::c_ulong) -> ::core::ffi::c_int;
}
pub type TokenType = ::core::ffi::c_uint;
pub const TOKEN_DIS: TokenType = 8;
pub const TOKEN_EOF: TokenType = 7;
pub const TOKEN_LET: TokenType = 6;
pub const TOKEN_SEMICOLON: TokenType = 5;
pub const TOKEN_MINUS: TokenType = 4;
pub const TOKEN_PLUS: TokenType = 3;
pub const TOKEN_ASSIGN: TokenType = 2;
pub const TOKEN_IDENTIFIER: TokenType = 1;
pub const TOKEN_INT: TokenType = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Token {
    pub type_0: TokenType,
    pub value: *mut ::core::ffi::c_char,
}
pub type size_t = __darwin_size_t;
pub type __darwin_size_t = usize;
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type fpos_t = __darwin_off_t;
pub type __darwin_off_t = __int64_t;
pub type __int64_t = i64;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
pub type __darwin_ct_rune_t = ::core::ffi::c_int;
pub type __uint32_t = u32;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneLocale {
    pub __magic: [::core::ffi::c_char; 8],
    pub __encoding: [::core::ffi::c_char; 32],
    pub __sgetrune: Option<
        unsafe extern "C" fn(
            *const ::core::ffi::c_char,
            __darwin_size_t,
            *mut *const ::core::ffi::c_char,
        ) -> __darwin_rune_t,
    >,
    pub __sputrune: Option<
        unsafe extern "C" fn(
            __darwin_rune_t,
            *mut ::core::ffi::c_char,
            __darwin_size_t,
            *mut *mut ::core::ffi::c_char,
        ) -> ::core::ffi::c_int,
    >,
    pub __invalid_rune: __darwin_rune_t,
    pub __runetype: [__uint32_t; 256],
    pub __maplower: [__darwin_rune_t; 256],
    pub __mapupper: [__darwin_rune_t; 256],
    pub __runetype_ext: _RuneRange,
    pub __maplower_ext: _RuneRange,
    pub __mapupper_ext: _RuneRange,
    pub __variable: *mut ::core::ffi::c_void,
    pub __variable_len: ::core::ffi::c_int,
    pub __ncharclasses: ::core::ffi::c_int,
    pub __charclasses: *mut _RuneCharClass,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneCharClass {
    pub __name: [::core::ffi::c_char; 14],
    pub __mask: __uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneRange {
    pub __nranges: ::core::ffi::c_int,
    pub __ranges: *mut _RuneEntry,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneEntry {
    pub __min: __darwin_rune_t,
    pub __max: __darwin_rune_t,
    pub __map: __darwin_rune_t,
    pub __types: *mut __uint32_t,
}
pub type __darwin_rune_t = __darwin_wchar_t;
pub type __darwin_wchar_t = ::libc::wchar_t;
pub const MAX_TOKEN: ::core::ffi::c_int = 200 as ::core::ffi::c_int;
pub const _CACHED_RUNES: ::core::ffi::c_int = (1 as ::core::ffi::c_int)
    << 8 as ::core::ffi::c_int;
pub const _CTYPE_A: ::core::ffi::c_long = 0x100 as ::core::ffi::c_long;
pub const _CTYPE_D: ::core::ffi::c_long = 0x400 as ::core::ffi::c_long;
pub const _CTYPE_S: ::core::ffi::c_long = 0x4000 as ::core::ffi::c_long;
#[inline]
unsafe extern "C" fn isascii(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return (_c & !(0x7f as ::core::ffi::c_int) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn __istype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> ::core::ffi::c_int {
    return if isascii(_c as ::core::ffi::c_int) != 0 {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    } else {
        (__maskrune(_c, _f) != 0) as ::core::ffi::c_int
    };
}
#[inline]
unsafe extern "C" fn __isctype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> __darwin_ct_rune_t {
    return if _c < 0 as ::core::ffi::c_int || _c >= _CACHED_RUNES {
        0 as __darwin_ct_rune_t
    } else {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    };
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isalpha(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_A as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isdigit(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __isctype(_c as __darwin_ct_rune_t, _CTYPE_D as ::core::ffi::c_ulong)
        as ::core::ffi::c_int;
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isspace(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_S as ::core::ffi::c_ulong);
}
#[no_mangle]
pub unsafe extern "C" fn new_token(
    mut type_0: TokenType,
    mut value: *const ::core::ffi::c_char,
) -> *mut Token {
    let mut token: *mut Token = malloc(::core::mem::size_of::<Token>() as size_t)
        as *mut Token;
    (*token).type_0 = type_0;
    (*token).value = strdup(value);
    return token;
}
#[no_mangle]
pub unsafe extern "C" fn free_token(mut token: *mut Token) {
    free((*token).value as *mut ::core::ffi::c_void);
    free(token as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn tokenize(mut source: *const ::core::ffi::c_char) -> *mut Token {
    let mut tokens: *mut Token = malloc(
        (::core::mem::size_of::<Token>() as size_t).wrapping_mul(MAX_TOKEN as size_t),
    ) as *mut Token;
    let mut pos: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut len: ::core::ffi::c_int = strlen(source) as ::core::ffi::c_int;
    let mut index: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while pos < len {
        if isspace(*source.offset(pos as isize) as ::core::ffi::c_int) != 0 {
            pos += 1;
        } else if isdigit(*source.offset(pos as isize) as ::core::ffi::c_int) != 0 {
            let mut start: ::core::ffi::c_int = pos;
            while isdigit(*source.offset(pos as isize) as ::core::ffi::c_int) != 0 {
                pos += 1;
            }
            let mut num: *mut ::core::ffi::c_char = strndup(
                &*source.offset(start as isize),
                (pos - start) as size_t,
            );
            *tokens.offset(index as isize) = *new_token(TOKEN_INT, num);
            index += 1;
            free(num as *mut ::core::ffi::c_void);
        } else if isalpha(*source.offset(pos as isize) as ::core::ffi::c_int) != 0 {
            let mut start_0: ::core::ffi::c_int = pos;
            while isalpha(*source.offset(pos as isize) as ::core::ffi::c_int) != 0 {
                pos += 1;
            }
            let mut indent: *mut ::core::ffi::c_char = strndup(
                &*source.offset(start_0 as isize),
                (pos - start_0) as size_t,
            );
            if strcmp(indent, b"let\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
            {
                *tokens.offset(index as isize) = *new_token(TOKEN_LET, indent);
                index += 1;
            } else if strcmp(indent, b"dis\0" as *const u8 as *const ::core::ffi::c_char)
                == 0 as ::core::ffi::c_int
            {
                *tokens.offset(index as isize) = *new_token(TOKEN_DIS, indent);
                index += 1;
            } else {
                *tokens.offset(index as isize) = *new_token(TOKEN_IDENTIFIER, indent);
                index += 1;
            }
            free(indent as *mut ::core::ffi::c_void);
        } else {
            match *source.offset(pos as isize) as ::core::ffi::c_int {
                43 => {
                    *tokens.offset(index as isize) = *new_token(
                        TOKEN_PLUS,
                        b"+\0" as *const u8 as *const ::core::ffi::c_char,
                    );
                    index += 1;
                }
                45 => {
                    *tokens.offset(index as isize) = *new_token(
                        TOKEN_MINUS,
                        b"-\0" as *const u8 as *const ::core::ffi::c_char,
                    );
                    index += 1;
                }
                59 => {
                    *tokens.offset(index as isize) = *new_token(
                        TOKEN_SEMICOLON,
                        b";\0" as *const u8 as *const ::core::ffi::c_char,
                    );
                    index += 1;
                }
                61 => {
                    *tokens.offset(index as isize) = *new_token(
                        TOKEN_ASSIGN,
                        b"=\0" as *const u8 as *const ::core::ffi::c_char,
                    );
                    index += 1;
                }
                _ => {
                    fprintf(
                        __stderrp,
                        b"SyntaxError: unexpected character %c\n\0" as *const u8
                            as *const ::core::ffi::c_char,
                        *source.offset(pos as isize) as ::core::ffi::c_int,
                    );
                    exit(1 as ::core::ffi::c_int);
                }
            }
            pos += 1;
        }
    }
    *tokens.offset(index as isize) = *new_token(
        TOKEN_EOF,
        b"\0" as *const u8 as *const ::core::ffi::c_char,
    );
    return tokens;
}
