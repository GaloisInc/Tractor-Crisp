#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn tokenize(source: *const ::core::ffi::c_char) -> *mut Token;
    fn parse(tokens: *mut Token) -> *mut *mut ASTNode;
    fn eval(
        frame: *mut Frame,
        instructions: *mut Instruction,
        instr_count: ::core::ffi::c_int,
    );
    fn init_frame() -> *mut Frame;
    fn free_frame(frame: *mut Frame);
    fn compile_asts(
        asts: *mut *mut ASTNode,
        instr_count: *mut ::core::ffi::c_int,
    ) -> *mut Instruction;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn getchar() -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn show_opcode(instruction: *mut Instruction, instr_count: ::core::ffi::c_int);
    fn show_tokens(tokens: *mut Token);
    fn print_asts(asts: *mut *mut ASTNode);
    fn read_file(source_path: *const ::core::ffi::c_char) -> *mut ::core::ffi::c_char;
    fn free(_: *mut ::core::ffi::c_void);
    fn exit(_: ::core::ffi::c_int) -> !;
}
pub type TokenType = ::core::ffi::c_uint;
pub const TOKEN_DIS: TokenType = 8;
pub const TOKEN_EOF: TokenType = 7;
pub const TOKEN_LET: TokenType = 6;
pub const TOKEN_SEMICOLON: TokenType = 5;
pub const TOKEN_MINUS: TokenType = 4;
pub const TOKEN_PLUS: TokenType = 3;
pub const TOKEN_ASSIGN: TokenType = 2;
pub const TOKEN_IDENTIFIER: TokenType = 1;
pub const TOKEN_INT: TokenType = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Token {
    pub type_0: TokenType,
    pub value: *mut ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct ASTNode {
    pub type_0: TokenType,
    pub left: *mut ASTNode,
    pub right: *mut ASTNode,
    pub value: *mut ::core::ffi::c_char,
}
pub type OpCode = ::core::ffi::c_uint;
pub const STK_DIS: OpCode = 5;
pub const BINARY_SUB: OpCode = 4;
pub const BINARY_ADD: OpCode = 3;
pub const STORE_NAME: OpCode = 2;
pub const LOAD_NAME: OpCode = 1;
pub const LOAD_CONST: OpCode = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Instruction {
    pub opcode: OpCode,
    pub operand: *mut ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Frame {
    pub stack: [::core::ffi::c_int; 200],
    pub sp: ::core::ffi::c_int,
    pub variables: [::core::ffi::c_int; 100],
    pub var_names: [*mut ::core::ffi::c_char; 100],
    pub var_count: ::core::ffi::c_int,
}
pub type __int64_t = i64;
pub type __darwin_off_t = __int64_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub const DEBUG: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    if argc != 2 as ::core::ffi::c_int {
        fprintf(
            __stderrp,
            b"Take one argument: Path of source code.\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        exit(-(1 as ::core::ffi::c_int));
    }
    let mut source_path: *const ::core::ffi::c_char = *argv
        .offset(1 as ::core::ffi::c_int as isize);
    let mut source: *mut ::core::ffi::c_char = read_file(source_path);
    let mut token: *mut Token = tokenize(source);
    let mut asts: *mut *mut ASTNode = parse(token);
    let mut number: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut instr: *mut Instruction = compile_asts(asts, &mut number);
    let mut frame: *mut Frame = init_frame();
    eval(frame, instr, number);
    free_frame(frame);
    free(source as *mut ::core::ffi::c_void);
    printf(b"Press any key to exit...\0" as *const u8 as *const ::core::ffi::c_char);
    getchar();
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
