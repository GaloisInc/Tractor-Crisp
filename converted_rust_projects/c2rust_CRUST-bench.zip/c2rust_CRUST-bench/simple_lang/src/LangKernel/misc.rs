#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    pub type dirent;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn exit(_: ::core::ffi::c_int) -> !;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn fgetc(_: *mut FILE) -> ::core::ffi::c_int;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn perror(_: *const ::core::ffi::c_char);
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type TokenType = ::core::ffi::c_uint;
pub const TOKEN_DIS: TokenType = 8;
pub const TOKEN_EOF: TokenType = 7;
pub const TOKEN_LET: TokenType = 6;
pub const TOKEN_SEMICOLON: TokenType = 5;
pub const TOKEN_MINUS: TokenType = 4;
pub const TOKEN_PLUS: TokenType = 3;
pub const TOKEN_ASSIGN: TokenType = 2;
pub const TOKEN_IDENTIFIER: TokenType = 1;
pub const TOKEN_INT: TokenType = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Token {
    pub type_0: TokenType,
    pub value: *mut ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct ASTNode {
    pub type_0: TokenType,
    pub left: *mut ASTNode,
    pub right: *mut ASTNode,
    pub value: *mut ::core::ffi::c_char,
}
pub type OpCode = ::core::ffi::c_uint;
pub const STK_DIS: OpCode = 5;
pub const BINARY_SUB: OpCode = 4;
pub const BINARY_ADD: OpCode = 3;
pub const STORE_NAME: OpCode = 2;
pub const LOAD_NAME: OpCode = 1;
pub const LOAD_CONST: OpCode = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Instruction {
    pub opcode: OpCode,
    pub operand: *mut ::core::ffi::c_char,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const EOF: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
pub const MAX_SOURCE_LENGTH: ::core::ffi::c_int = 2000 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn get_opcode_name(
    mut opcode: OpCode,
) -> *mut ::core::ffi::c_char {
    match opcode as ::core::ffi::c_uint {
        0 => {
            return b"LOAD_CONST\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
        1 => {
            return b"LOAD_NAME\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
        2 => {
            return b"STORE_NAME\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
        4 => {
            return b"BINARY_SUB\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
        3 => {
            return b"BINARY_ADD\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
        5 => {
            return b"STK_DIS\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
        _ => {
            return b"UNKNOWN_OPCODE\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn get_token_type_name(
    mut tokenType: TokenType,
) -> *mut ::core::ffi::c_char {
    match tokenType as ::core::ffi::c_uint {
        0 => {
            return b"TOKEN_INT\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
        1 => {
            return b"TOKEN_IDENTIFIER\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
        2 => {
            return b"TOKEN_ASSIGN\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
        3 => {
            return b"TOKEN_PLUS\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
        4 => {
            return b"TOKEN_MINUS\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
        5 => {
            return b"TOKEN_SEMICOLON\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
        6 => {
            return b"TOKEN_LET\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
        7 => {
            return b"TOKEN_EOF\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
        8 => {
            return b"TOKEN_DIS\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
        _ => {
            return b"UNKNOWN_TOKEN\0" as *const u8 as *const ::core::ffi::c_char
                as *mut ::core::ffi::c_char;
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn show_opcode(
    mut instruction: *mut Instruction,
    mut instr_count: ::core::ffi::c_int,
) {
    printf(b"bytecode:\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < instr_count {
        if !(*instruction.offset(i as isize)).operand.is_null() {
            printf(
                b"%-15s \t (%s)\n\0" as *const u8 as *const ::core::ffi::c_char,
                get_opcode_name((*instruction.offset(i as isize)).opcode),
                (*instruction.offset(i as isize)).operand,
            );
        } else {
            printf(
                b"%-15s \t *\n\0" as *const u8 as *const ::core::ffi::c_char,
                get_opcode_name((*instruction.offset(i as isize)).opcode),
            );
        }
        i += 1;
    }
    printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
}
#[no_mangle]
pub unsafe extern "C" fn show_tokens(mut tokens: *mut Token) {
    printf(b"tokens:\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while (*tokens.offset(i as isize)).type_0 as ::core::ffi::c_uint
        != TOKEN_EOF as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        printf(
            b"%-15s \t (%s)\n\0" as *const u8 as *const ::core::ffi::c_char,
            get_token_type_name((*tokens.offset(i as isize)).type_0),
            (*tokens.offset(i as isize)).value,
        );
        i += 1;
    }
    printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
}
#[no_mangle]
pub unsafe extern "C" fn print_ast(
    mut node: *mut ASTNode,
    mut level: ::core::ffi::c_int,
) {
    if node.is_null() {
        return;
    }
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < level {
        printf(b"  \0" as *const u8 as *const ::core::ffi::c_char);
        i += 1;
    }
    match (*node).type_0 as ::core::ffi::c_uint {
        0 => {
            printf(
                b"INT: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                (*node).value,
            );
        }
        1 => {
            printf(
                b"IDENTIFIER: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                (*node).value,
            );
        }
        2 => {
            printf(
                b"ASSIGN: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                (*node).value,
            );
        }
        6 => {
            printf(
                b"LET: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                (*node).value,
            );
        }
        3 => {
            printf(b"PLUS\n\0" as *const u8 as *const ::core::ffi::c_char);
        }
        4 => {
            printf(b"MINUS\n\0" as *const u8 as *const ::core::ffi::c_char);
        }
        8 => {
            printf(b"DISPLAY\n\0" as *const u8 as *const ::core::ffi::c_char);
        }
        _ => {
            printf(b"UNKNOWN\n\0" as *const u8 as *const ::core::ffi::c_char);
        }
    }
    if !(*node).left.is_null() {
        print_ast((*node).left as *mut ASTNode, level + 1 as ::core::ffi::c_int);
    }
    if !(*node).right.is_null() {
        print_ast((*node).right as *mut ASTNode, level + 1 as ::core::ffi::c_int);
    }
}
#[no_mangle]
pub unsafe extern "C" fn print_asts(mut asts: *mut *mut ASTNode) {
    printf(b"AST:\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while !(*asts.offset(i as isize)).is_null() {
        print_ast(*asts.offset(i as isize), 0 as ::core::ffi::c_int);
        printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
        i += 1;
    }
    printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
}
#[no_mangle]
pub unsafe extern "C" fn read_file(
    mut source_path: *const ::core::ffi::c_char,
) -> *mut ::core::ffi::c_char {
    let mut entry: *mut dirent = 0 as *mut dirent;
    let mut source: *mut ::core::ffi::c_char = malloc(
        (::core::mem::size_of::<::core::ffi::c_char>() as size_t)
            .wrapping_mul(MAX_SOURCE_LENGTH as size_t),
    ) as *mut ::core::ffi::c_char;
    let mut file: *mut FILE = fopen(
        source_path,
        b"r\0" as *const u8 as *const ::core::ffi::c_char,
    ) as *mut FILE;
    if file.is_null() {
        perror(b"Could not open file\0" as *const u8 as *const ::core::ffi::c_char);
        exit(-(1 as ::core::ffi::c_int));
    }
    let mut pos: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut ch: ::core::ffi::c_char = 0;
    loop {
        ch = fgetc(file) as ::core::ffi::c_char;
        if !(ch as ::core::ffi::c_int != EOF) {
            break;
        }
        memcpy(
            &mut *source.offset(pos as isize) as *mut ::core::ffi::c_char
                as *mut ::core::ffi::c_void,
            &mut ch as *mut ::core::ffi::c_char as *const ::core::ffi::c_void,
            ::core::mem::size_of::<::core::ffi::c_char>() as size_t,
        );
        pos += 1;
    }
    *source.offset(pos as isize) = '\0' as i32 as ::core::ffi::c_char;
    fclose(file);
    return source;
}
