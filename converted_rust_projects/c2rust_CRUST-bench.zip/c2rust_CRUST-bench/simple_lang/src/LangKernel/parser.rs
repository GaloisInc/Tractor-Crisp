#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn new_ast_node(
        type_0: TokenType,
        value: *const ::core::ffi::c_char,
    ) -> *mut ASTNode;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn exit(_: ::core::ffi::c_int) -> !;
}
pub type TokenType = ::core::ffi::c_uint;
pub const TOKEN_DIS: TokenType = 8;
pub const TOKEN_EOF: TokenType = 7;
pub const TOKEN_LET: TokenType = 6;
pub const TOKEN_SEMICOLON: TokenType = 5;
pub const TOKEN_MINUS: TokenType = 4;
pub const TOKEN_PLUS: TokenType = 3;
pub const TOKEN_ASSIGN: TokenType = 2;
pub const TOKEN_IDENTIFIER: TokenType = 1;
pub const TOKEN_INT: TokenType = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Token {
    pub type_0: TokenType,
    pub value: *mut ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct ASTNode {
    pub type_0: TokenType,
    pub left: *mut ASTNode,
    pub right: *mut ASTNode,
    pub value: *mut ::core::ffi::c_char,
}
pub type size_t = __darwin_size_t;
pub type __darwin_size_t = usize;
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type fpos_t = __darwin_off_t;
pub type __darwin_off_t = __int64_t;
pub type __int64_t = i64;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
pub const MAX_STATEMENT: ::core::ffi::c_int = 100 as ::core::ffi::c_int;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
static mut tokens: *mut Token = 0 as *const Token as *mut Token;
static mut pos: ::core::ffi::c_int = 0;
#[no_mangle]
pub unsafe extern "C" fn lookahead() -> *mut Token {
    return &mut *tokens.offset(pos as isize) as *mut Token;
}
#[no_mangle]
pub unsafe extern "C" fn consume() -> *mut Token {
    let fresh3 = pos;
    pos = pos + 1;
    return &mut *tokens.offset(fresh3 as isize) as *mut Token;
}
#[no_mangle]
pub unsafe extern "C" fn parse_primary() -> *mut ASTNode {
    let mut token: *mut Token = consume();
    if (*token).type_0 as ::core::ffi::c_uint
        == TOKEN_INT as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        return new_ast_node(TOKEN_INT, (*token).value)
    } else if (*token).type_0 as ::core::ffi::c_uint
        == TOKEN_IDENTIFIER as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        return new_ast_node(TOKEN_IDENTIFIER, (*token).value)
    } else {
        fprintf(
            __stderrp,
            b"Unexpected token in primary expression: %s\n\0" as *const u8
                as *const ::core::ffi::c_char,
            (*token).value,
        );
        exit(1 as ::core::ffi::c_int);
    };
}
#[no_mangle]
pub unsafe extern "C" fn parse_expression() -> *mut ASTNode {
    let mut left: *mut ASTNode = parse_primary();
    let mut token: *mut Token = lookahead();
    while (*token).type_0 as ::core::ffi::c_uint
        == TOKEN_PLUS as ::core::ffi::c_int as ::core::ffi::c_uint
        || (*token).type_0 as ::core::ffi::c_uint
            == TOKEN_MINUS as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        token = consume();
        let mut right: *mut ASTNode = parse_primary();
        let mut node: *mut ASTNode = new_ast_node((*token).type_0, (*token).value);
        (*node).left = left as *mut ASTNode;
        (*node).right = right as *mut ASTNode;
        left = node;
        token = lookahead();
    }
    return left;
}
#[no_mangle]
pub unsafe extern "C" fn parse_statement() -> *mut ASTNode {
    let mut token: *mut Token = consume();
    if (*token).type_0 as ::core::ffi::c_uint
        == TOKEN_LET as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        let mut identifier: *mut Token = consume();
        if (*identifier).type_0 as ::core::ffi::c_uint
            != TOKEN_IDENTIFIER as ::core::ffi::c_int as ::core::ffi::c_uint
        {
            fprintf(
                __stderrp,
                b"Expected identifier after 'let'\n\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
            exit(1 as ::core::ffi::c_int);
        }
        if (*consume()).type_0 as ::core::ffi::c_uint
            != TOKEN_ASSIGN as ::core::ffi::c_int as ::core::ffi::c_uint
        {
            fprintf(
                __stderrp,
                b"Expected '=' after identifier\n\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
            exit(1 as ::core::ffi::c_int);
        }
        let mut expr: *mut ASTNode = parse_expression();
        if (*consume()).type_0 as ::core::ffi::c_uint
            != TOKEN_SEMICOLON as ::core::ffi::c_int as ::core::ffi::c_uint
        {
            fprintf(
                __stderrp,
                b"Expected ';' at end of statement\n\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
            exit(1 as ::core::ffi::c_int);
        }
        let mut node: *mut ASTNode = new_ast_node(TOKEN_LET, (*identifier).value);
        (*node).left = expr as *mut ASTNode;
        return node;
    } else if (*token).type_0 as ::core::ffi::c_uint
        == TOKEN_IDENTIFIER as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        let mut identifier_0: *mut Token = token;
        if (*consume()).type_0 as ::core::ffi::c_uint
            != TOKEN_ASSIGN as ::core::ffi::c_int as ::core::ffi::c_uint
        {
            fprintf(
                __stderrp,
                b"Expected '=' after identifier\n\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
            exit(1 as ::core::ffi::c_int);
        }
        let mut expr_0: *mut ASTNode = parse_expression();
        if (*consume()).type_0 as ::core::ffi::c_uint
            != TOKEN_SEMICOLON as ::core::ffi::c_int as ::core::ffi::c_uint
        {
            fprintf(
                __stderrp,
                b"Expected ';' at end of statement\n\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
            exit(1 as ::core::ffi::c_int);
        }
        let mut node_0: *mut ASTNode = new_ast_node(TOKEN_ASSIGN, (*identifier_0).value);
        (*node_0).left = expr_0 as *mut ASTNode;
        return node_0;
    } else if (*token).type_0 as ::core::ffi::c_uint
        == TOKEN_DIS as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        let mut expr_1: *mut ASTNode = parse_expression();
        let mut node_1: *mut ASTNode = new_ast_node(
            TOKEN_DIS,
            0 as *const ::core::ffi::c_char,
        );
        if (*consume()).type_0 as ::core::ffi::c_uint
            != TOKEN_SEMICOLON as ::core::ffi::c_int as ::core::ffi::c_uint
        {
            fprintf(
                __stderrp,
                b"Expected ';' at end of statement\n\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
            exit(1 as ::core::ffi::c_int);
        }
        (*node_1).left = expr_1 as *mut ASTNode;
        return node_1;
    } else {
        fprintf(
            __stderrp,
            b"Unexpected token: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            (*token).value,
        );
        exit(1 as ::core::ffi::c_int);
    };
}
#[no_mangle]
pub unsafe extern "C" fn parse(mut tokens_array: *mut Token) -> *mut *mut ASTNode {
    tokens = tokens_array;
    pos = 0 as ::core::ffi::c_int;
    let mut ast_nodes: *mut *mut ASTNode = malloc(
        (::core::mem::size_of::<*mut ASTNode>() as size_t)
            .wrapping_mul(MAX_STATEMENT as size_t),
    ) as *mut *mut ASTNode;
    let mut count: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while (*tokens.offset(pos as isize)).type_0 as ::core::ffi::c_uint
        != TOKEN_EOF as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        let fresh0 = count;
        count = count + 1;
        let ref mut fresh1 = *ast_nodes.offset(fresh0 as isize);
        *fresh1 = parse_statement();
    }
    let ref mut fresh2 = *ast_nodes.offset(count as isize);
    *fresh2 = 0 as *mut ASTNode;
    return ast_nodes;
}
