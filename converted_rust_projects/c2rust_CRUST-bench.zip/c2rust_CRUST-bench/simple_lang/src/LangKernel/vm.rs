#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn atoi(_: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strdup(__s1: *const ::core::ffi::c_char) -> *mut ::core::ffi::c_char;
}
pub type OpCode = ::core::ffi::c_uint;
pub const STK_DIS: OpCode = 5;
pub const BINARY_SUB: OpCode = 4;
pub const BINARY_ADD: OpCode = 3;
pub const STORE_NAME: OpCode = 2;
pub const LOAD_NAME: OpCode = 1;
pub const LOAD_CONST: OpCode = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Instruction {
    pub opcode: OpCode,
    pub operand: *mut ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Frame {
    pub stack: [::core::ffi::c_int; 200],
    pub sp: ::core::ffi::c_int,
    pub variables: [::core::ffi::c_int; 100],
    pub var_names: [*mut ::core::ffi::c_char; 100],
    pub var_count: ::core::ffi::c_int,
}
pub type size_t = __darwin_size_t;
pub type __darwin_size_t = usize;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn new_instruction(
    mut opcode: OpCode,
    mut operand: *const ::core::ffi::c_char,
) -> *mut Instruction {
    let mut instruction: *mut Instruction = malloc(
        ::core::mem::size_of::<Instruction>() as size_t,
    ) as *mut Instruction;
    (*instruction).opcode = opcode;
    if !operand.is_null() {
        (*instruction).operand = strdup(operand);
    } else {
        (*instruction).operand = 0 as *mut ::core::ffi::c_char;
    }
    return instruction;
}
#[no_mangle]
pub unsafe extern "C" fn free_instruction(mut instruction: *mut Instruction) {
    free(instruction as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn init_frame() -> *mut Frame {
    let mut frame: *mut Frame = malloc(::core::mem::size_of::<Frame>() as size_t)
        as *mut Frame;
    (*frame).sp = 0 as ::core::ffi::c_int;
    (*frame).var_count = 0 as ::core::ffi::c_int;
    return frame;
}
#[no_mangle]
pub unsafe extern "C" fn free_frame(mut frame: *mut Frame) {
    free(frame as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn eval(
    mut frame: *mut Frame,
    mut instructions: *mut Instruction,
    mut instr_count: ::core::ffi::c_int,
) {
    let mut pc: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while pc < instr_count {
        let mut instr: Instruction = *instructions.offset(pc as isize);
        match instr.opcode as ::core::ffi::c_uint {
            0 => {
                (*frame).sp += 1;
                (*frame).stack[(*frame).sp as usize] = atoi(instr.operand);
            }
            1 => {
                let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                while i < (*frame).var_count {
                    if strcmp((*frame).var_names[i as usize], instr.operand)
                        == 0 as ::core::ffi::c_int
                    {
                        (*frame).sp += 1;
                        (*frame).stack[(*frame).sp as usize] = (*frame)
                            .variables[i as usize];
                        break;
                    } else {
                        i += 1;
                    }
                }
            }
            2 => {
                let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                while i_0 < (*frame).var_count {
                    if strcmp((*frame).var_names[i_0 as usize], instr.operand)
                        == 0 as ::core::ffi::c_int
                    {
                        let fresh0 = (*frame).sp;
                        (*frame).sp = (*frame).sp - 1;
                        (*frame).variables[i_0 as usize] = (*frame)
                            .stack[fresh0 as usize];
                        break;
                    } else {
                        i_0 += 1;
                    }
                }
                if (*frame).var_count == 0 as ::core::ffi::c_int
                    || strcmp(
                        (*frame)
                            .var_names[((*frame).var_count - 1 as ::core::ffi::c_int)
                            as usize],
                        instr.operand,
                    ) != 0 as ::core::ffi::c_int
                {
                    (*frame).var_names[(*frame).var_count as usize] = strdup(
                        instr.operand,
                    );
                    let fresh1 = (*frame).sp;
                    (*frame).sp = (*frame).sp - 1;
                    (*frame).variables[(*frame).var_count as usize] = (*frame)
                        .stack[fresh1 as usize];
                    (*frame).var_count += 1;
                }
            }
            3 => {
                (*frame).stack[((*frame).sp - 1 as ::core::ffi::c_int) as usize] = (*frame)
                    .stack[((*frame).sp - 1 as ::core::ffi::c_int) as usize]
                    + (*frame).stack[(*frame).sp as usize];
                (*frame).sp -= 1;
            }
            4 => {
                (*frame).stack[((*frame).sp - 1 as ::core::ffi::c_int) as usize] = (*frame)
                    .stack[((*frame).sp - 1 as ::core::ffi::c_int) as usize]
                    - (*frame).stack[(*frame).sp as usize];
                (*frame).sp -= 1;
            }
            5 => {
                printf(
                    b"%d\n\0" as *const u8 as *const ::core::ffi::c_char,
                    (*frame).stack[(*frame).sp as usize],
                );
            }
            _ => {}
        }
        pc += 1;
    }
    free(instructions as *mut ::core::ffi::c_void);
}
