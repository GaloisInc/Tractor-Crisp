#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn free_instruction(instruction: *mut Instruction);
    fn compile(
        source: *const ::core::ffi::c_char,
        instr_count: *mut ::core::ffi::c_int,
    ) -> *mut Instruction;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
}
pub type OpCode = ::core::ffi::c_uint;
pub const STK_DIS: OpCode = 5;
pub const BINARY_SUB: OpCode = 4;
pub const BINARY_ADD: OpCode = 3;
pub const STORE_NAME: OpCode = 2;
pub const LOAD_NAME: OpCode = 1;
pub const LOAD_CONST: OpCode = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Instruction {
    pub opcode: OpCode,
    pub operand: *mut ::core::ffi::c_char,
}
#[no_mangle]
pub unsafe extern "C" fn test_compiler() {
    let mut source: *const ::core::ffi::c_char = b"let x = 5 + 3 - 2; dis x;\0"
        as *const u8 as *const ::core::ffi::c_char;
    let mut instr_num: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut instr: *mut Instruction = compile(source, &mut instr_num);
    if !((*instr.offset(0 as ::core::ffi::c_int as isize)).opcode as ::core::ffi::c_uint
        == LOAD_CONST as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_compiler\0")
                .as_ptr(),
            b"test_compiler.c\0" as *const u8 as *const ::core::ffi::c_char,
            12 as ::core::ffi::c_int,
            b"instr[0].opcode == LOAD_CONST\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strcmp(
        (*instr.offset(0 as ::core::ffi::c_int as isize)).operand,
        b"5\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_compiler\0")
                .as_ptr(),
            b"test_compiler.c\0" as *const u8 as *const ::core::ffi::c_char,
            13 as ::core::ffi::c_int,
            b"strcmp(instr[0].operand,\"5\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*instr.offset(1 as ::core::ffi::c_int as isize)).opcode as ::core::ffi::c_uint
        == LOAD_CONST as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_compiler\0")
                .as_ptr(),
            b"test_compiler.c\0" as *const u8 as *const ::core::ffi::c_char,
            15 as ::core::ffi::c_int,
            b"instr[1].opcode == LOAD_CONST\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strcmp(
        (*instr.offset(1 as ::core::ffi::c_int as isize)).operand,
        b"3\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_compiler\0")
                .as_ptr(),
            b"test_compiler.c\0" as *const u8 as *const ::core::ffi::c_char,
            16 as ::core::ffi::c_int,
            b"strcmp(instr[1].operand,\"3\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*instr.offset(2 as ::core::ffi::c_int as isize)).opcode as ::core::ffi::c_uint
        == BINARY_ADD as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_compiler\0")
                .as_ptr(),
            b"test_compiler.c\0" as *const u8 as *const ::core::ffi::c_char,
            18 as ::core::ffi::c_int,
            b"instr[2].opcode == BINARY_ADD\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*instr.offset(3 as ::core::ffi::c_int as isize)).opcode as ::core::ffi::c_uint
        == LOAD_CONST as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_compiler\0")
                .as_ptr(),
            b"test_compiler.c\0" as *const u8 as *const ::core::ffi::c_char,
            20 as ::core::ffi::c_int,
            b"instr[3].opcode == LOAD_CONST\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strcmp(
        (*instr.offset(3 as ::core::ffi::c_int as isize)).operand,
        b"2\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_compiler\0")
                .as_ptr(),
            b"test_compiler.c\0" as *const u8 as *const ::core::ffi::c_char,
            21 as ::core::ffi::c_int,
            b"strcmp(instr[3].operand, \"2\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*instr.offset(4 as ::core::ffi::c_int as isize)).opcode as ::core::ffi::c_uint
        == BINARY_SUB as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_compiler\0")
                .as_ptr(),
            b"test_compiler.c\0" as *const u8 as *const ::core::ffi::c_char,
            23 as ::core::ffi::c_int,
            b"instr[4].opcode == BINARY_SUB\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*instr.offset(5 as ::core::ffi::c_int as isize)).opcode as ::core::ffi::c_uint
        == STORE_NAME as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_compiler\0")
                .as_ptr(),
            b"test_compiler.c\0" as *const u8 as *const ::core::ffi::c_char,
            25 as ::core::ffi::c_int,
            b"instr[5].opcode == STORE_NAME\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strcmp(
        (*instr.offset(5 as ::core::ffi::c_int as isize)).operand,
        b"x\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_compiler\0")
                .as_ptr(),
            b"test_compiler.c\0" as *const u8 as *const ::core::ffi::c_char,
            26 as ::core::ffi::c_int,
            b"strcmp(instr[5].operand,\"x\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*instr.offset(6 as ::core::ffi::c_int as isize)).opcode as ::core::ffi::c_uint
        == LOAD_NAME as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_compiler\0")
                .as_ptr(),
            b"test_compiler.c\0" as *const u8 as *const ::core::ffi::c_char,
            28 as ::core::ffi::c_int,
            b"instr[6].opcode == LOAD_NAME\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strcmp(
        (*instr.offset(6 as ::core::ffi::c_int as isize)).operand,
        b"x\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_compiler\0")
                .as_ptr(),
            b"test_compiler.c\0" as *const u8 as *const ::core::ffi::c_char,
            29 as ::core::ffi::c_int,
            b"strcmp(instr[6].operand,\"x\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*instr.offset(7 as ::core::ffi::c_int as isize)).opcode as ::core::ffi::c_uint
        == STK_DIS as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_compiler\0")
                .as_ptr(),
            b"test_compiler.c\0" as *const u8 as *const ::core::ffi::c_char,
            31 as ::core::ffi::c_int,
            b"instr[7].opcode == STK_DIS\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    free_instruction(instr);
}
unsafe fn main_0() -> ::core::ffi::c_int {
    test_compiler();
    printf(b"All Tests passed!\n\0" as *const u8 as *const ::core::ffi::c_char);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
