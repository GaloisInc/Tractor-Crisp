#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn tokenize(source: *const ::core::ffi::c_char) -> *mut Token;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn free(_: *mut ::core::ffi::c_void);
}
pub type TokenType = ::core::ffi::c_uint;
pub const TOKEN_DIS: TokenType = 8;
pub const TOKEN_EOF: TokenType = 7;
pub const TOKEN_LET: TokenType = 6;
pub const TOKEN_SEMICOLON: TokenType = 5;
pub const TOKEN_MINUS: TokenType = 4;
pub const TOKEN_PLUS: TokenType = 3;
pub const TOKEN_ASSIGN: TokenType = 2;
pub const TOKEN_IDENTIFIER: TokenType = 1;
pub const TOKEN_INT: TokenType = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Token {
    pub type_0: TokenType,
    pub value: *mut ::core::ffi::c_char,
}
#[no_mangle]
pub unsafe extern "C" fn test_tokenize() {
    let mut source: *const ::core::ffi::c_char = b"let x = 5 + 3 - 2; dis x;\0"
        as *const u8 as *const ::core::ffi::c_char;
    let mut tokens: *mut Token = tokenize(source);
    if !((*tokens.offset(0 as ::core::ffi::c_int as isize)).type_0 as ::core::ffi::c_uint
        == TOKEN_LET as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_tokenize\0")
                .as_ptr(),
            b"test_lexer.c\0" as *const u8 as *const ::core::ffi::c_char,
            10 as ::core::ffi::c_int,
            b"tokens[0].type == TOKEN_LET\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tokens.offset(1 as ::core::ffi::c_int as isize)).type_0 as ::core::ffi::c_uint
        == TOKEN_IDENTIFIER as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_tokenize\0")
                .as_ptr(),
            b"test_lexer.c\0" as *const u8 as *const ::core::ffi::c_char,
            11 as ::core::ffi::c_int,
            b"tokens[1].type == TOKEN_IDENTIFIER\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tokens.offset(2 as ::core::ffi::c_int as isize)).type_0 as ::core::ffi::c_uint
        == TOKEN_ASSIGN as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_tokenize\0")
                .as_ptr(),
            b"test_lexer.c\0" as *const u8 as *const ::core::ffi::c_char,
            12 as ::core::ffi::c_int,
            b"tokens[2].type == TOKEN_ASSIGN\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tokens.offset(3 as ::core::ffi::c_int as isize)).type_0 as ::core::ffi::c_uint
        == TOKEN_INT as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_tokenize\0")
                .as_ptr(),
            b"test_lexer.c\0" as *const u8 as *const ::core::ffi::c_char,
            13 as ::core::ffi::c_int,
            b"tokens[3].type == TOKEN_INT\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tokens.offset(4 as ::core::ffi::c_int as isize)).type_0 as ::core::ffi::c_uint
        == TOKEN_PLUS as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_tokenize\0")
                .as_ptr(),
            b"test_lexer.c\0" as *const u8 as *const ::core::ffi::c_char,
            14 as ::core::ffi::c_int,
            b"tokens[4].type == TOKEN_PLUS\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tokens.offset(5 as ::core::ffi::c_int as isize)).type_0 as ::core::ffi::c_uint
        == TOKEN_INT as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_tokenize\0")
                .as_ptr(),
            b"test_lexer.c\0" as *const u8 as *const ::core::ffi::c_char,
            15 as ::core::ffi::c_int,
            b"tokens[5].type == TOKEN_INT\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tokens.offset(6 as ::core::ffi::c_int as isize)).type_0 as ::core::ffi::c_uint
        == TOKEN_MINUS as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_tokenize\0")
                .as_ptr(),
            b"test_lexer.c\0" as *const u8 as *const ::core::ffi::c_char,
            16 as ::core::ffi::c_int,
            b"tokens[6].type == TOKEN_MINUS\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tokens.offset(7 as ::core::ffi::c_int as isize)).type_0 as ::core::ffi::c_uint
        == TOKEN_INT as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_tokenize\0")
                .as_ptr(),
            b"test_lexer.c\0" as *const u8 as *const ::core::ffi::c_char,
            17 as ::core::ffi::c_int,
            b"tokens[7].type == TOKEN_INT\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tokens.offset(8 as ::core::ffi::c_int as isize)).type_0 as ::core::ffi::c_uint
        == TOKEN_SEMICOLON as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_tokenize\0")
                .as_ptr(),
            b"test_lexer.c\0" as *const u8 as *const ::core::ffi::c_char,
            18 as ::core::ffi::c_int,
            b"tokens[8].type == TOKEN_SEMICOLON\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tokens.offset(9 as ::core::ffi::c_int as isize)).type_0 as ::core::ffi::c_uint
        == TOKEN_DIS as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_tokenize\0")
                .as_ptr(),
            b"test_lexer.c\0" as *const u8 as *const ::core::ffi::c_char,
            19 as ::core::ffi::c_int,
            b"tokens[9].type == TOKEN_DIS\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tokens.offset(10 as ::core::ffi::c_int as isize)).type_0
        as ::core::ffi::c_uint
        == TOKEN_IDENTIFIER as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_tokenize\0")
                .as_ptr(),
            b"test_lexer.c\0" as *const u8 as *const ::core::ffi::c_char,
            20 as ::core::ffi::c_int,
            b"tokens[10].type == TOKEN_IDENTIFIER\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tokens.offset(11 as ::core::ffi::c_int as isize)).type_0
        as ::core::ffi::c_uint
        == TOKEN_SEMICOLON as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_tokenize\0")
                .as_ptr(),
            b"test_lexer.c\0" as *const u8 as *const ::core::ffi::c_char,
            21 as ::core::ffi::c_int,
            b"tokens[11].type == TOKEN_SEMICOLON\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tokens.offset(12 as ::core::ffi::c_int as isize)).type_0
        as ::core::ffi::c_uint == TOKEN_EOF as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"test_tokenize\0")
                .as_ptr(),
            b"test_lexer.c\0" as *const u8 as *const ::core::ffi::c_char,
            22 as ::core::ffi::c_int,
            b"tokens[12].type == TOKEN_EOF\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    free(tokens as *mut ::core::ffi::c_void);
}
unsafe fn main_0() -> ::core::ffi::c_int {
    test_tokenize();
    printf(b"All Tests passed!\n\0" as *const u8 as *const ::core::ffi::c_char);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
