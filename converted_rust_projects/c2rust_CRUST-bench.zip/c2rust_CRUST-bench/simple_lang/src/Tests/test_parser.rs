#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn tokenize(source: *const ::core::ffi::c_char) -> *mut Token;
    fn free_ast_node(node: *mut ASTNode);
    fn parse(tokens: *mut Token) -> *mut *mut ASTNode;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn free(_: *mut ::core::ffi::c_void);
}
pub type TokenType = ::core::ffi::c_uint;
pub const TOKEN_DIS: TokenType = 8;
pub const TOKEN_EOF: TokenType = 7;
pub const TOKEN_LET: TokenType = 6;
pub const TOKEN_SEMICOLON: TokenType = 5;
pub const TOKEN_MINUS: TokenType = 4;
pub const TOKEN_PLUS: TokenType = 3;
pub const TOKEN_ASSIGN: TokenType = 2;
pub const TOKEN_IDENTIFIER: TokenType = 1;
pub const TOKEN_INT: TokenType = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Token {
    pub type_0: TokenType,
    pub value: *mut ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct ASTNode {
    pub type_0: TokenType,
    pub left: *mut ASTNode,
    pub right: *mut ASTNode,
    pub value: *mut ::core::ffi::c_char,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn test_parse() {
    let mut source: *const ::core::ffi::c_char = b"let x = 5 + 3 - 2; let y = x + 1; dis x + 1;\0"
        as *const u8 as *const ::core::ffi::c_char;
    let mut tokens: *mut Token = tokenize(source);
    let mut ast_nodes: *mut *mut ASTNode = parse(tokens);
    if !((**ast_nodes.offset(0 as ::core::ffi::c_int as isize)).type_0
        as ::core::ffi::c_uint == TOKEN_LET as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"test_parse\0")
                .as_ptr(),
            b"test_parser.c\0" as *const u8 as *const ::core::ffi::c_char,
            16 as ::core::ffi::c_int,
            b"ast_nodes[0]->type == TOKEN_LET\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(**ast_nodes.offset(0 as ::core::ffi::c_int as isize)).left).type_0
        as ::core::ffi::c_uint
        == TOKEN_MINUS as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"test_parse\0")
                .as_ptr(),
            b"test_parser.c\0" as *const u8 as *const ::core::ffi::c_char,
            17 as ::core::ffi::c_int,
            b"ast_nodes[0]->left->type == TOKEN_MINUS\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*(**ast_nodes.offset(0 as ::core::ffi::c_int as isize)).left).left).type_0
        as ::core::ffi::c_uint
        == TOKEN_PLUS as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"test_parse\0")
                .as_ptr(),
            b"test_parser.c\0" as *const u8 as *const ::core::ffi::c_char,
            18 as ::core::ffi::c_int,
            b"ast_nodes[0]->left->left->type == TOKEN_PLUS\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*(*(**ast_nodes.offset(0 as ::core::ffi::c_int as isize)).left).left).left)
        .type_0 as ::core::ffi::c_uint
        == TOKEN_INT as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"test_parse\0")
                .as_ptr(),
            b"test_parser.c\0" as *const u8 as *const ::core::ffi::c_char,
            19 as ::core::ffi::c_int,
            b"ast_nodes[0]->left->left->left->type == TOKEN_INT\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*(*(**ast_nodes.offset(0 as ::core::ffi::c_int as isize)).left).left).right)
        .type_0 as ::core::ffi::c_uint
        == TOKEN_INT as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"test_parse\0")
                .as_ptr(),
            b"test_parser.c\0" as *const u8 as *const ::core::ffi::c_char,
            20 as ::core::ffi::c_int,
            b"ast_nodes[0]->left->left->right->type == TOKEN_INT\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*(**ast_nodes.offset(0 as ::core::ffi::c_int as isize)).left).right).type_0
        as ::core::ffi::c_uint == TOKEN_INT as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"test_parse\0")
                .as_ptr(),
            b"test_parser.c\0" as *const u8 as *const ::core::ffi::c_char,
            21 as ::core::ffi::c_int,
            b"ast_nodes[0]->left->right->type == TOKEN_INT\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((**ast_nodes.offset(1 as ::core::ffi::c_int as isize)).type_0
        as ::core::ffi::c_uint == TOKEN_LET as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"test_parse\0")
                .as_ptr(),
            b"test_parser.c\0" as *const u8 as *const ::core::ffi::c_char,
            23 as ::core::ffi::c_int,
            b"ast_nodes[1]->type == TOKEN_LET\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(**ast_nodes.offset(1 as ::core::ffi::c_int as isize)).left).type_0
        as ::core::ffi::c_uint
        == TOKEN_PLUS as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"test_parse\0")
                .as_ptr(),
            b"test_parser.c\0" as *const u8 as *const ::core::ffi::c_char,
            24 as ::core::ffi::c_int,
            b"ast_nodes[1]->left->type == TOKEN_PLUS\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*(**ast_nodes.offset(1 as ::core::ffi::c_int as isize)).left).left).type_0
        as ::core::ffi::c_uint
        == TOKEN_IDENTIFIER as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"test_parse\0")
                .as_ptr(),
            b"test_parser.c\0" as *const u8 as *const ::core::ffi::c_char,
            25 as ::core::ffi::c_int,
            b"ast_nodes[1]->left->left->type == TOKEN_IDENTIFIER\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*(**ast_nodes.offset(1 as ::core::ffi::c_int as isize)).left).right).type_0
        as ::core::ffi::c_uint == TOKEN_INT as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"test_parse\0")
                .as_ptr(),
            b"test_parser.c\0" as *const u8 as *const ::core::ffi::c_char,
            26 as ::core::ffi::c_int,
            b"ast_nodes[1]->left->right->type == TOKEN_INT\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((**ast_nodes.offset(2 as ::core::ffi::c_int as isize)).type_0
        as ::core::ffi::c_uint == TOKEN_DIS as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"test_parse\0")
                .as_ptr(),
            b"test_parser.c\0" as *const u8 as *const ::core::ffi::c_char,
            28 as ::core::ffi::c_int,
            b"ast_nodes[2]->type == TOKEN_DIS\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(**ast_nodes.offset(2 as ::core::ffi::c_int as isize)).left).type_0
        as ::core::ffi::c_uint
        == TOKEN_PLUS as ::core::ffi::c_int as ::core::ffi::c_uint) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"test_parse\0")
                .as_ptr(),
            b"test_parser.c\0" as *const u8 as *const ::core::ffi::c_char,
            29 as ::core::ffi::c_int,
            b"ast_nodes[2]->left->type == TOKEN_PLUS\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*(**ast_nodes.offset(2 as ::core::ffi::c_int as isize)).left).left).type_0
        as ::core::ffi::c_uint
        == TOKEN_IDENTIFIER as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"test_parse\0")
                .as_ptr(),
            b"test_parser.c\0" as *const u8 as *const ::core::ffi::c_char,
            30 as ::core::ffi::c_int,
            b"ast_nodes[2]->left->left->type == TOKEN_IDENTIFIER\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*(*(**ast_nodes.offset(2 as ::core::ffi::c_int as isize)).left).right).type_0
        as ::core::ffi::c_uint == TOKEN_INT as ::core::ffi::c_int as ::core::ffi::c_uint)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 11],
                [::core::ffi::c_char; 11],
            >(*b"test_parse\0")
                .as_ptr(),
            b"test_parser.c\0" as *const u8 as *const ::core::ffi::c_char,
            31 as ::core::ffi::c_int,
            b"ast_nodes[2]->left->right->type == TOKEN_INT\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while !(*ast_nodes.offset(i as isize)).is_null() {
        free_ast_node(*ast_nodes.offset(i as isize));
        i += 1;
    }
    free(ast_nodes as *mut ::core::ffi::c_void);
    free(tokens as *mut ::core::ffi::c_void);
}
unsafe fn main_0() -> ::core::ffi::c_int {
    test_parse();
    printf(b"All Tests passed!\n\0" as *const u8 as *const ::core::ffi::c_char);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
