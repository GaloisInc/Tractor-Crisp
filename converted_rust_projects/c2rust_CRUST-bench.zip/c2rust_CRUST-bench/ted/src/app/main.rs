#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn basename(_: *mut ::core::ffi::c_char) -> *mut ::core::ffi::c_char;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn fputs(_: *const ::core::ffi::c_char, _: *mut FILE) -> ::core::ffi::c_int;
    fn perror(_: *const ::core::ffi::c_char);
    fn sprintf(
        _: *mut ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn sscanf(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn snprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn atexit(_: Option<unsafe extern "C" fn() -> ()>) -> ::core::ffi::c_int;
    fn exit(_: ::core::ffi::c_int) -> !;
    fn read(_: ::core::ffi::c_int, _: *mut ::core::ffi::c_void, _: size_t) -> ssize_t;
    fn write(
        __fd: ::core::ffi::c_int,
        __buf: *const ::core::ffi::c_void,
        __nbyte: size_t,
    ) -> ssize_t;
    fn tcgetattr(_: ::core::ffi::c_int, _: *mut termios) -> ::core::ffi::c_int;
    fn tcsetattr(
        _: ::core::ffi::c_int,
        _: ::core::ffi::c_int,
        _: *const termios,
    ) -> ::core::ffi::c_int;
    fn ioctl(_: ::core::ffi::c_int, _: ::core::ffi::c_ulong, ...) -> ::core::ffi::c_int;
    fn DestroyTextBuffer(instance: *mut TextBuffer);
    fn TextBufferMoveCursor(
        instance: *mut TextBuffer,
        row: ::core::ffi::c_int,
        col: ::core::ffi::c_int,
    );
    fn TextBufferInsert(
        instance: *mut TextBuffer,
        ch: ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn TextBufferBackspace(instance: *mut TextBuffer) -> ::core::ffi::c_int;
    fn TextBufferNewLine(instance: *mut TextBuffer) -> ::core::ffi::c_int;
    fn TextBufferGetLine(
        instance: *mut TextBuffer,
        row: ::core::ffi::c_int,
    ) -> *mut ::core::ffi::c_char;
    fn CreateTextBufferFromFile(fp: *mut FILE) -> *mut TextBuffer;
}
pub type __uint32_t = u32;
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_ssize_t = isize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type ssize_t = __darwin_ssize_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type tcflag_t = ::core::ffi::c_ulong;
pub type cc_t = ::core::ffi::c_uchar;
pub type speed_t = ::core::ffi::c_ulong;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct termios {
    pub c_iflag: tcflag_t,
    pub c_oflag: tcflag_t,
    pub c_cflag: tcflag_t,
    pub c_lflag: tcflag_t,
    pub c_cc: [cc_t; 20],
    pub c_ispeed: speed_t,
    pub c_ospeed: speed_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct winsize {
    pub ws_row: ::core::ffi::c_ushort,
    pub ws_col: ::core::ffi::c_ushort,
    pub ws_xpixel: ::core::ffi::c_ushort,
    pub ws_ypixel: ::core::ffi::c_ushort,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct GapBuffer {
    pub buffer: *mut ::core::ffi::c_char,
    pub str_len: ::core::ffi::c_int,
    pub gap_len: ::core::ffi::c_int,
    pub gap_loc: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct TextBuffer {
    pub lines: *mut *mut GapBuffer,
    pub lines_capacity: ::core::ffi::c_int,
    pub cursorRow: ::core::ffi::c_int,
    pub cursorCol: ::core::ffi::c_int,
    pub cursorColMoved: ::core::ffi::c_int,
    pub last_line_loc: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct VirtualScreen {
    pub buffer: *mut ::core::ffi::c_char,
    pub buf_pos: ::core::ffi::c_int,
    pub len: ::core::ffi::c_int,
    pub cursor: Cursor,
    pub width: ::core::ffi::c_int,
    pub height: ::core::ffi::c_int,
    pub render_start_line: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Cursor {
    pub x: ::core::ffi::c_int,
    pub y: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct EditorState {
    pub orig_termios: termios,
    pub file_name: *mut ::core::ffi::c_char,
    pub file_path: *mut ::core::ffi::c_char,
    pub flushed: bool,
    pub current_buffer: *mut TextBuffer,
    pub screen: VirtualScreen,
}
pub type specialKeys = ::core::ffi::c_uint;
pub const DEL_KEY: specialKeys = 1008;
pub const END_KEY: specialKeys = 1007;
pub const HOME_KEY: specialKeys = 1006;
pub const PAGE_DOWN: specialKeys = 1005;
pub const PAGE_UP: specialKeys = 1004;
pub const ARROW_RIGHT: specialKeys = 1003;
pub const ARROW_LEFT: specialKeys = 1002;
pub const ARROW_DOWN: specialKeys = 1001;
pub const ARROW_UP: specialKeys = 1000;
pub const BACKSPACE: specialKeys = 127;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const STDIN_FILENO: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const STDOUT_FILENO: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const VMIN: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
pub const VTIME: ::core::ffi::c_int = 17 as ::core::ffi::c_int;
pub const BRKINT: ::core::ffi::c_int = 0x2 as ::core::ffi::c_int;
pub const INPCK: ::core::ffi::c_int = 0x10 as ::core::ffi::c_int;
pub const ICRNL: ::core::ffi::c_int = 0x100 as ::core::ffi::c_int;
pub const IXON: ::core::ffi::c_int = 0x200 as ::core::ffi::c_int;
pub const OPOST: ::core::ffi::c_int = 0x1 as ::core::ffi::c_int;
pub const CS8: ::core::ffi::c_int = 0x300 as ::core::ffi::c_int;
pub const ECHO: ::core::ffi::c_int = 0x8 as ::core::ffi::c_int;
pub const ISIG: ::core::ffi::c_int = 0x80 as ::core::ffi::c_int;
pub const ICANON: ::core::ffi::c_int = 0x100 as ::core::ffi::c_int;
pub const IEXTEN: ::core::ffi::c_int = 0x400 as ::core::ffi::c_int;
pub const TCSAFLUSH: ::core::ffi::c_int = 2 as ::core::ffi::c_int;
pub const IOCPARM_MASK: ::core::ffi::c_int = 0x1fff as ::core::ffi::c_int;
pub const TIOCGWINSZ: usize = 0x40000000 as ::core::ffi::c_int as __uint32_t as usize
    | (::core::mem::size_of::<winsize>() as usize & IOCPARM_MASK as usize)
        << 16 as ::core::ffi::c_int | (('t' as i32) << 8 as ::core::ffi::c_int) as usize
    | 104 as usize;
pub const EAGAIN: ::core::ffi::c_int = 35 as ::core::ffi::c_int;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const MEM_ERROR: ::core::ffi::c_int = 128 as ::core::ffi::c_int;
pub const ESC: ::core::ffi::c_int = '\u{1b}' as i32;
pub const INVERT_COLOUR: [::core::ffi::c_char; 5] = unsafe {
    ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"\x1B[7m\0")
};
pub const INVERT_COLOUR_SIZE: ::core::ffi::c_int = 4 as ::core::ffi::c_int;
pub const RESET_STYLE_COLOUR: [::core::ffi::c_char; 5] = unsafe {
    ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"\x1B[0m\0")
};
#[no_mangle]
pub unsafe extern "C" fn required_screen_rows(
    mut line_length: ::core::ffi::c_int,
    mut screen_width: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    if line_length == 0 as ::core::ffi::c_int {
        return 1 as ::core::ffi::c_int
    } else {
        return line_length / screen_width
            + (line_length % screen_width > 0 as ::core::ffi::c_int)
                as ::core::ffi::c_int
    };
}
#[no_mangle]
pub unsafe extern "C" fn move_cursor_in_view(
    mut buffer: *mut TextBuffer,
    mut screen: *mut VirtualScreen,
) {
    let mut buffer_cursor: Cursor = {
        let mut init = Cursor {
            x: (*buffer).cursorRow,
            y: (*buffer).cursorCol,
        };
        init
    };
    let mut cumul_req_rows: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut cur_line_required_rows: ::core::ffi::c_int = 0;
    let mut cur_line: ::core::ffi::c_int = (*screen).render_start_line;
    if buffer_cursor.x < (*screen).render_start_line {
        (*screen).render_start_line = buffer_cursor.x;
    } else {
        while cur_line <= (*buffer).last_line_loc {
            cur_line_required_rows = required_screen_rows(
                (**(*buffer).lines.offset(cur_line as isize)).str_len,
                (*screen).width,
            );
            if cur_line_required_rows + cumul_req_rows
                > (*screen).height - 1 as ::core::ffi::c_int
            {
                cur_line -= 1;
                break;
            } else {
                cumul_req_rows += cur_line_required_rows;
                cur_line += 1;
            }
        }
        if buffer_cursor.x > cur_line {
            let mut rows_required: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
            while cur_line <= buffer_cursor.x {
                rows_required
                    += required_screen_rows(
                        (**(*buffer).lines.offset(cur_line as isize)).str_len,
                        (*screen).width,
                    );
                cur_line += 1;
            }
            while rows_required > 0 as ::core::ffi::c_int {
                rows_required
                    -= required_screen_rows(
                        (**(*buffer).lines.offset((*screen).render_start_line as isize))
                            .str_len,
                        (*screen).width,
                    );
                (*screen).render_start_line += 1;
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn draw_editor_window(
    mut buffer: *mut TextBuffer,
    mut screen: *mut VirtualScreen,
) {
    let mut line: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut cur_line: ::core::ffi::c_int = (*screen).render_start_line;
    let mut lines_written: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut screen_cols: ::core::ffi::c_int = 0;
    while cur_line <= (*buffer).last_line_loc
        && lines_written < (*screen).height - 1 as ::core::ffi::c_int
    {
        screen_cols = (*screen).width;
        line = TextBufferGetLine(buffer, cur_line);
        if line.is_null() {
            panic(
                b"draw editor cant get text of current line in buffer\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        }
        if strlen(line) > screen_cols as size_t {
            let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
            let mut len_to_write: ::core::ffi::c_int = 0;
            loop {
                len_to_write = (if (screen_cols as size_t)
                    < strlen(&mut *line.offset(i as isize))
                {
                    screen_cols as size_t
                } else {
                    strlen(&mut *line.offset(i as isize))
                }) as ::core::ffi::c_int;
                screen_append(&mut *line.offset(i as isize), len_to_write);
                screen_append(
                    b"\r\n\0" as *const u8 as *const ::core::ffi::c_char,
                    2 as ::core::ffi::c_int,
                );
                screen_append(
                    b"\x1B[K\0" as *const u8 as *const ::core::ffi::c_char,
                    3 as ::core::ffi::c_int,
                );
                i += len_to_write;
                lines_written += 1;
                if lines_written == (*screen).height - 2 as ::core::ffi::c_int {
                    break;
                }
                if !((i as size_t) < strlen(line).wrapping_sub(1 as size_t)) {
                    break;
                }
            }
        } else {
            screen_append(line, strlen(line) as ::core::ffi::c_int);
            screen_append(
                b"\r\n\0" as *const u8 as *const ::core::ffi::c_char,
                2 as ::core::ffi::c_int,
            );
            lines_written += 1;
        }
        free(line as *mut ::core::ffi::c_void);
        cur_line += 1;
    }
    while lines_written < (*screen).height - 2 as ::core::ffi::c_int {
        screen_append(
            b"\r\n\0" as *const u8 as *const ::core::ffi::c_char,
            2 as ::core::ffi::c_int,
        );
        lines_written += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn set_virtual_cursor_position(
    mut buffer: *mut TextBuffer,
    mut screen: *mut VirtualScreen,
) {
    let mut current_line: ::core::ffi::c_int = (*screen).render_start_line;
    let mut virtual_cursor_row: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    let mut required_rows: ::core::ffi::c_int = 0;
    while current_line != (*buffer).cursorRow {
        required_rows = required_screen_rows(
            (**(*buffer).lines.offset(current_line as isize)).str_len,
            (*screen).width,
        );
        virtual_cursor_row += required_rows;
        current_line += 1;
    }
    virtual_cursor_row += (*buffer).cursorCol / (*screen).width;
    (*screen).cursor.x = virtual_cursor_row;
    (*screen).cursor.y = (*buffer).cursorCol % (*screen).width + 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub static mut editor_state: EditorState = EditorState {
    orig_termios: termios {
        c_iflag: 0,
        c_oflag: 0,
        c_cflag: 0,
        c_lflag: 0,
        c_cc: [0; 20],
        c_ispeed: 0,
        c_ospeed: 0,
    },
    file_name: 0 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    file_path: 0 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
    flushed: false,
    current_buffer: 0 as *const TextBuffer as *mut TextBuffer,
    screen: VirtualScreen {
        buffer: 0 as *const ::core::ffi::c_char as *mut ::core::ffi::c_char,
        buf_pos: 0,
        len: 0,
        cursor: Cursor { x: 0, y: 0 },
        width: 0,
        height: 0,
        render_start_line: 0,
    },
};
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    initialize(argc, argv);
    loop {
        draw_screen();
        render_screen();
        process_keypress();
    };
}
#[no_mangle]
pub unsafe extern "C" fn initialize(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) {
    if argc >= 2 as ::core::ffi::c_int {
        editor_state.file_path = *argv.offset(1 as ::core::ffi::c_int as isize);
    } else {
        editor_state.file_path = b"Empty Buffer\0" as *const u8
            as *const ::core::ffi::c_char as *mut ::core::ffi::c_char;
    }
    editor_state.file_name = basename(editor_state.file_path);
    load_file_and_initialize_buffer();
    enableRawMode();
    set_window_size();
    editor_state.screen.len = ((editor_state.screen.height * editor_state.screen.width)
        as usize)
        .wrapping_mul(::core::mem::size_of::<::core::ffi::c_char>() as usize)
        .wrapping_mul(2 as usize) as ::core::ffi::c_int;
    editor_state.screen.buffer = malloc(editor_state.screen.len as size_t)
        as *mut ::core::ffi::c_char;
    editor_state.screen.buf_pos = 0 as ::core::ffi::c_int;
    editor_state.screen.render_start_line = 0 as ::core::ffi::c_int;
    editor_state.flushed = true_0 != 0;
}
#[no_mangle]
pub unsafe extern "C" fn load_file_and_initialize_buffer() -> ::core::ffi::c_int {
    let mut fp: *mut FILE = fopen(
        editor_state.file_path,
        b"r\0" as *const u8 as *const ::core::ffi::c_char,
    ) as *mut FILE;
    editor_state.current_buffer = CreateTextBufferFromFile(fp);
    if editor_state.current_buffer.is_null() {
        return MEM_ERROR;
    }
    if fp.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    fclose(fp);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn cleanup() {
    write(
        STDOUT_FILENO,
        b"\x1B[2J\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        4 as size_t,
    );
    write(
        STDOUT_FILENO,
        b"\x1B[H\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        3 as size_t,
    );
    free(editor_state.screen.buffer as *mut ::core::ffi::c_void);
    DestroyTextBuffer(editor_state.current_buffer);
}
#[no_mangle]
pub unsafe extern "C" fn panic(mut message: *const ::core::ffi::c_char) {
    write(
        STDOUT_FILENO,
        b"\x1B[2J\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        4 as size_t,
    );
    write(
        STDOUT_FILENO,
        b"\x1B[H\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        3 as size_t,
    );
    write(
        STDOUT_FILENO,
        b"\x1B[?25h\0" as *const u8 as *const ::core::ffi::c_char
            as *const ::core::ffi::c_void,
        6 as size_t,
    );
    perror(message);
    exit(1 as ::core::ffi::c_int);
}
#[no_mangle]
pub unsafe extern "C" fn set_window_size() {
    let mut ws: winsize = winsize {
        ws_row: 0,
        ws_col: 0,
        ws_xpixel: 0,
        ws_ypixel: 0,
    };
    if ioctl(STDOUT_FILENO, TIOCGWINSZ as ::core::ffi::c_ulong, &mut ws as *mut winsize)
        == -(1 as ::core::ffi::c_int)
        || ws.ws_col as ::core::ffi::c_int == 0 as ::core::ffi::c_int
    {
        if write(
            STDOUT_FILENO,
            b"\x1B[999C\x1B[999B\0" as *const u8 as *const ::core::ffi::c_char
                as *const ::core::ffi::c_void,
            12 as size_t,
        ) != 12 as ssize_t
        {
            panic(
                b"Failed to get window size\0" as *const u8 as *const ::core::ffi::c_char,
            );
        }
        let mut buf: [::core::ffi::c_char; 32] = [0; 32];
        let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while (i as usize) < ::core::mem::size_of::<[::core::ffi::c_char; 32]>() as usize
        {
            if read(
                STDIN_FILENO,
                &mut *buf.as_mut_ptr().offset(i as isize) as *mut ::core::ffi::c_char
                    as *mut ::core::ffi::c_void,
                1 as size_t,
            ) != 1 as ssize_t
            {
                panic(
                    b"Failed to get window size\0" as *const u8
                        as *const ::core::ffi::c_char,
                );
            }
            if buf[i as usize] as ::core::ffi::c_int == 'R' as i32 {
                buf[(i + 1 as ::core::ffi::c_int) as usize] = '\0' as i32
                    as ::core::ffi::c_char;
                break;
            } else {
                i += 1;
            }
        }
        if sscanf(
            buf.as_mut_ptr(),
            b"%d;%d\0" as *const u8 as *const ::core::ffi::c_char,
            &mut editor_state.screen.height as *mut ::core::ffi::c_int,
            &mut editor_state.screen.width as *mut ::core::ffi::c_int,
        ) != 2 as ::core::ffi::c_int
        {
            panic(
                b"Failed to get windows size\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        }
    } else {
        editor_state.screen.height = ws.ws_row as ::core::ffi::c_int;
        editor_state.screen.width = ws.ws_col as ::core::ffi::c_int;
    };
}
#[no_mangle]
pub unsafe extern "C" fn disableRawMode() {
    if tcsetattr(STDIN_FILENO, TCSAFLUSH, &mut editor_state.orig_termios)
        == -(1 as ::core::ffi::c_int)
    {
        panic(b"tcsetattr\0" as *const u8 as *const ::core::ffi::c_char);
    }
}
#[no_mangle]
pub unsafe extern "C" fn enableRawMode() {
    if tcgetattr(STDIN_FILENO, &mut editor_state.orig_termios)
        == -(1 as ::core::ffi::c_int)
    {
        panic(b"tcgetattr\0" as *const u8 as *const ::core::ffi::c_char);
    }
    atexit(
        ::core::mem::transmute::<
            Option<unsafe extern "C" fn() -> ()>,
            Option<unsafe extern "C" fn() -> ()>,
        >(
            Some(
                ::core::mem::transmute::<
                    unsafe extern "C" fn() -> (),
                    unsafe extern "C" fn() -> (),
                >(disableRawMode),
            ),
        ),
    );
    let mut raw: termios = editor_state.orig_termios;
    raw.c_lflag &= !(ECHO | ICANON | ISIG | IEXTEN) as tcflag_t;
    raw.c_iflag &= !(ICRNL | IXON | BRKINT | INPCK) as tcflag_t;
    raw.c_oflag &= !(0x1 as ::core::ffi::c_int) as tcflag_t;
    raw.c_cflag |= 0x300 as tcflag_t;
    raw.c_cc[VMIN as usize] = 0 as cc_t;
    raw.c_cc[VTIME as usize] = 1 as cc_t;
    if tcsetattr(STDIN_FILENO, TCSAFLUSH, &mut raw) == -(1 as ::core::ffi::c_int) {
        panic(b"tcsetattr\0" as *const u8 as *const ::core::ffi::c_char);
    }
}
#[no_mangle]
pub unsafe extern "C" fn screen_append(
    mut str: *const ::core::ffi::c_char,
    mut size: ::core::ffi::c_int,
) {
    if !editor_state.screen.buffer.is_null()
        && editor_state.screen.len - editor_state.screen.buf_pos > size
    {
        memcpy(
            editor_state.screen.buffer.offset(editor_state.screen.buf_pos as isize)
                as *mut ::core::ffi::c_void,
            str as *const ::core::ffi::c_void,
            size as size_t,
        );
        editor_state.screen.buf_pos += size;
    }
}
#[no_mangle]
pub unsafe extern "C" fn render_screen() {
    write(
        STDOUT_FILENO,
        editor_state.screen.buffer as *const ::core::ffi::c_void,
        strlen(editor_state.screen.buffer),
    );
}
#[no_mangle]
pub unsafe extern "C" fn draw_screen() {
    editor_state.screen.buf_pos = 0 as ::core::ffi::c_int;
    screen_append(
        b"\x1B[?25l\0" as *const u8 as *const ::core::ffi::c_char,
        6 as ::core::ffi::c_int,
    );
    screen_append(
        b"\x1B[2J\0" as *const u8 as *const ::core::ffi::c_char,
        4 as ::core::ffi::c_int,
    );
    screen_append(
        b"\x1B[H\0" as *const u8 as *const ::core::ffi::c_char,
        3 as ::core::ffi::c_int,
    );
    move_cursor_in_view(editor_state.current_buffer, &mut editor_state.screen);
    draw_editor_window(editor_state.current_buffer, &mut editor_state.screen);
    draw_status_line(editor_state.screen.width);
    set_virtual_cursor_position(editor_state.current_buffer, &mut editor_state.screen);
    let mut row: ::core::ffi::c_int = editor_state.screen.cursor.x;
    let mut col: ::core::ffi::c_int = editor_state.screen.cursor.y;
    let mut buf: [::core::ffi::c_char; 32] = [0; 32];
    sprintf(
        buf.as_mut_ptr(),
        b"\x1B[%d;%dH\0" as *const u8 as *const ::core::ffi::c_char,
        row,
        col,
    );
    screen_append(buf.as_mut_ptr(), strlen(buf.as_mut_ptr()) as ::core::ffi::c_int);
    screen_append(
        b"\x1B[?25h\0" as *const u8 as *const ::core::ffi::c_char,
        6 as ::core::ffi::c_int,
    );
    screen_append(
        b"\0\0" as *const u8 as *const ::core::ffi::c_char,
        1 as ::core::ffi::c_int,
    );
}
#[no_mangle]
pub unsafe extern "C" fn draw_status_line(mut line_size: ::core::ffi::c_int) {
    let commands: [::core::ffi::c_char; 24] = ::core::mem::transmute::<
        [u8; 24],
        [::core::ffi::c_char; 24],
    >(*b"Ctrl+Q-quit Ctrl+S-Save\0");
    let mut commands_len: ::core::ffi::c_uint = (::core::mem::size_of::<
        [::core::ffi::c_char; 24],
    >() as usize)
        .wrapping_sub(1 as usize) as ::core::ffi::c_uint;
    let modified: [::core::ffi::c_char; 8] = ::core::mem::transmute::<
        [u8; 8],
        [::core::ffi::c_char; 8],
    >(*b"changed\0");
    let mut modified_len: ::core::ffi::c_int = (::core::mem::size_of::<
        [::core::ffi::c_char; 8],
    >() as usize)
        .wrapping_sub(1 as usize) as ::core::ffi::c_int;
    let mut file_cursor_space: ::core::ffi::c_int = (line_size as ::core::ffi::c_uint)
        .wrapping_sub(commands_len.wrapping_add(modified_len as ::core::ffi::c_uint))
        as ::core::ffi::c_int;
    let mut cur_col_digits: ::core::ffi::c_int = snprintf(
        0 as *mut ::core::ffi::c_char,
        0 as size_t,
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        (*editor_state.current_buffer).cursorCol,
    );
    let mut cur_row_digits: ::core::ffi::c_int = snprintf(
        0 as *mut ::core::ffi::c_char,
        0 as size_t,
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        (*editor_state.current_buffer).cursorRow,
    );
    let mut f_name_space: ::core::ffi::c_int = file_cursor_space
        - (cur_col_digits + cur_row_digits + 5 as ::core::ffi::c_int);
    let mut file_name_size: ::core::ffi::c_int = strlen(editor_state.file_name)
        as ::core::ffi::c_int;
    let mut cursor_info_buffer_size: ::core::ffi::c_int = file_cursor_space
        - f_name_space;
    let vla = cursor_info_buffer_size as usize;
    let mut cursor_info_buffer: Vec<::core::ffi::c_char> = ::std::vec::from_elem(0, vla);
    screen_append(INVERT_COLOUR.as_ptr(), INVERT_COLOUR_SIZE);
    if file_name_size > f_name_space {
        screen_append(editor_state.file_name, f_name_space - 4 as ::core::ffi::c_int);
        screen_append(
            b"... \0" as *const u8 as *const ::core::ffi::c_char,
            4 as ::core::ffi::c_int,
        );
    } else {
        screen_append(editor_state.file_name, file_name_size);
    }
    sprintf(
        cursor_info_buffer.as_mut_ptr(),
        b" | %d,%d \0" as *const u8 as *const ::core::ffi::c_char,
        (*editor_state.current_buffer).cursorRow,
        (*editor_state.current_buffer).cursorCol,
    );
    screen_append(
        cursor_info_buffer.as_mut_ptr(),
        strlen(cursor_info_buffer.as_mut_ptr()) as ::core::ffi::c_int,
    );
    if !editor_state.flushed {
        screen_append(modified.as_ptr(), modified_len);
    } else {
        memset(
            editor_state.screen.buffer.offset(editor_state.screen.buf_pos as isize)
                as *mut ::core::ffi::c_void,
            ' ' as i32,
            modified_len as size_t,
        );
        editor_state.screen.buf_pos += modified_len;
    }
    memset(
        editor_state.screen.buffer.offset(editor_state.screen.buf_pos as isize)
            as *mut ::core::ffi::c_void,
        ' ' as i32,
        (f_name_space - file_name_size) as size_t,
    );
    editor_state.screen.buf_pos += f_name_space - file_name_size;
    screen_append(commands.as_ptr(), commands_len as ::core::ffi::c_int);
    screen_append(RESET_STYLE_COLOUR.as_ptr(), INVERT_COLOUR_SIZE);
}
#[no_mangle]
pub unsafe extern "C" fn flush_buffer_to_file() -> ::core::ffi::c_int {
    let mut fp: *mut FILE = fopen(
        editor_state.file_path,
        b"w\0" as *const u8 as *const ::core::ffi::c_char,
    ) as *mut FILE;
    let mut line: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    if fp.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i <= (*editor_state.current_buffer).last_line_loc {
        line = TextBufferGetLine(editor_state.current_buffer, i);
        if line.is_null() {
            fclose(fp);
            return -(2 as ::core::ffi::c_int);
        }
        if (fputs(line, fp) as size_t) < strlen(line) {
            fclose(fp);
            return -(2 as ::core::ffi::c_int);
        }
        i += 1;
    }
    fclose(fp);
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn read_char() -> ::core::ffi::c_int {
    let mut c: ::core::ffi::c_char = 0;
    let mut err: ssize_t = 0;
    loop {
        err = read(
            STDIN_FILENO,
            &mut c as *mut ::core::ffi::c_char as *mut ::core::ffi::c_void,
            1 as size_t,
        );
        if !(err != 1 as ssize_t) {
            break;
        }
        if err == EAGAIN as ssize_t {
            panic(
                b"read_char: read() returned EAGAIN\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        }
    }
    if c as ::core::ffi::c_int == ESC {
        let mut seq: [::core::ffi::c_char; 3] = [0; 3];
        if read(
            STDIN_FILENO,
            &mut *seq.as_mut_ptr().offset(0 as ::core::ffi::c_int as isize)
                as *mut ::core::ffi::c_char as *mut ::core::ffi::c_void,
            1 as size_t,
        ) != 1 as ssize_t
        {
            return ESC;
        }
        if read(
            STDIN_FILENO,
            &mut *seq.as_mut_ptr().offset(1 as ::core::ffi::c_int as isize)
                as *mut ::core::ffi::c_char as *mut ::core::ffi::c_void,
            1 as size_t,
        ) != 1 as ssize_t
        {
            return ESC;
        }
        if seq[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_int == '[' as i32 {
            if seq[1 as ::core::ffi::c_int as usize] as ::core::ffi::c_int >= '0' as i32
                && seq[1 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
                    <= '9' as i32
            {
                if read(
                    STDIN_FILENO,
                    &mut *seq.as_mut_ptr().offset(2 as ::core::ffi::c_int as isize)
                        as *mut ::core::ffi::c_char as *mut ::core::ffi::c_void,
                    1 as size_t,
                ) != 1 as ssize_t
                {
                    return ESC;
                }
                if seq[2 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
                    == '~' as i32
                {
                    match seq[2 as ::core::ffi::c_int as usize] as ::core::ffi::c_int {
                        49 => return HOME_KEY as ::core::ffi::c_int,
                        51 => return DEL_KEY as ::core::ffi::c_int,
                        52 => return END_KEY as ::core::ffi::c_int,
                        53 => return PAGE_UP as ::core::ffi::c_int,
                        54 => return PAGE_DOWN as ::core::ffi::c_int,
                        55 => return HOME_KEY as ::core::ffi::c_int,
                        56 => return END_KEY as ::core::ffi::c_int,
                        _ => {}
                    }
                }
            } else {
                match seq[1 as ::core::ffi::c_int as usize] as ::core::ffi::c_int {
                    65 => return ARROW_UP as ::core::ffi::c_int,
                    66 => return ARROW_DOWN as ::core::ffi::c_int,
                    67 => return ARROW_RIGHT as ::core::ffi::c_int,
                    68 => return ARROW_LEFT as ::core::ffi::c_int,
                    72 => return HOME_KEY as ::core::ffi::c_int,
                    70 => return END_KEY as ::core::ffi::c_int,
                    _ => {}
                }
            }
        } else if seq[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
            == 'O' as i32
        {
            match seq[1 as ::core::ffi::c_int as usize] as ::core::ffi::c_int {
                72 => return HOME_KEY as ::core::ffi::c_int,
                70 => return END_KEY as ::core::ffi::c_int,
                _ => {}
            }
        }
        return ESC;
    } else {
        return c as ::core::ffi::c_int
    };
}
#[no_mangle]
pub unsafe extern "C" fn process_keypress() {
    let mut c: ::core::ffi::c_int = read_char();
    let mut err: ::core::ffi::c_int = 0;
    match c {
        13 => {
            TextBufferNewLine(editor_state.current_buffer);
        }
        1000 => {
            up_arrow();
        }
        1001 => {
            down_arrow();
        }
        1002 => {
            left_arrow();
        }
        1003 => {
            right_arrow();
        }
        1004 | 1005 | 1006 | 1007 | 1008 | 12 | 27 => {}
        19 => {
            err = flush_buffer_to_file();
            editor_state.flushed = true_0 != 0;
        }
        17 => {
            cleanup();
            exit(0 as ::core::ffi::c_int);
        }
        127 | 8 => {
            TextBufferBackspace(editor_state.current_buffer);
            editor_state.flushed = false_0 != 0;
        }
        _ => {
            TextBufferInsert(editor_state.current_buffer, c as ::core::ffi::c_char);
            editor_state.flushed = false_0 != 0;
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn up_arrow() {
    let mut col: ::core::ffi::c_int = (*editor_state.current_buffer).cursorCol;
    let mut row: ::core::ffi::c_int = (*editor_state.current_buffer).cursorRow;
    if row > 0 as ::core::ffi::c_int {
        row -= 1;
        TextBufferMoveCursor(editor_state.current_buffer, row, col);
    }
}
#[no_mangle]
pub unsafe extern "C" fn down_arrow() {
    let mut col: ::core::ffi::c_int = (*editor_state.current_buffer).cursorCol;
    let mut row: ::core::ffi::c_int = (*editor_state.current_buffer).cursorRow;
    if row < (*editor_state.current_buffer).last_line_loc {
        row += 1;
        TextBufferMoveCursor(editor_state.current_buffer, row, col);
    }
}
#[no_mangle]
pub unsafe extern "C" fn left_arrow() {
    let mut row: ::core::ffi::c_int = (*editor_state.current_buffer).cursorRow;
    let mut col: ::core::ffi::c_int = (*editor_state.current_buffer).cursorCol
        - 1 as ::core::ffi::c_int;
    TextBufferMoveCursor(editor_state.current_buffer, row, col);
}
#[no_mangle]
pub unsafe extern "C" fn right_arrow() {
    let mut row: ::core::ffi::c_int = (*editor_state.current_buffer).cursorRow;
    let mut col: ::core::ffi::c_int = (*editor_state.current_buffer).cursorCol
        + 1 as ::core::ffi::c_int;
    TextBufferMoveCursor(editor_state.current_buffer, row, col);
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
