#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn CreateGapBuffer(capacity: ::core::ffi::c_int) -> *mut GapBuffer;
    fn DestroyGapBuffer(instance: *mut GapBuffer);
    fn GapBufferInsertChar(
        instance: *mut GapBuffer,
        ch: ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn GapBufferBackSpace(instance: *mut GapBuffer);
    fn GapBufferMoveGap(
        instance: *mut GapBuffer,
        location: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn GapBufferGetString(instance: *mut GapBuffer) -> *mut ::core::ffi::c_char;
    fn GapBufferSplit(instance: *mut GapBuffer) -> *mut GapBuffer;
    fn CreateGapBufferFromString(
        str: *mut ::core::ffi::c_char,
        gap_len: ::core::ffi::c_int,
    ) -> *mut GapBuffer;
    fn getline(
        __linep: *mut *mut ::core::ffi::c_char,
        __linecapp: *mut size_t,
        __stream: *mut FILE,
    ) -> ssize_t;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn realloc(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memmove(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct GapBuffer {
    pub buffer: *mut ::core::ffi::c_char,
    pub str_len: ::core::ffi::c_int,
    pub gap_len: ::core::ffi::c_int,
    pub gap_loc: ::core::ffi::c_int,
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_ssize_t = isize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type ssize_t = __darwin_ssize_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct TextBuffer {
    pub lines: *mut *mut GapBuffer,
    pub lines_capacity: ::core::ffi::c_int,
    pub cursorRow: ::core::ffi::c_int,
    pub cursorCol: ::core::ffi::c_int,
    pub cursorColMoved: ::core::ffi::c_int,
    pub last_line_loc: ::core::ffi::c_int,
}
pub const MEM_ERROR: ::core::ffi::c_int = 128 as ::core::ffi::c_int;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const DEFAULT_CAPACITY: ::core::ffi::c_int = 100 as ::core::ffi::c_int;
pub const DEFAULT_GAP_BUF_CAP: ::core::ffi::c_int = 100 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn CreateTextBuffer(
    mut num_lines: ::core::ffi::c_int,
    mut line_size: ::core::ffi::c_int,
) -> *mut TextBuffer {
    let mut textBuffer: *mut TextBuffer = malloc(
        ::core::mem::size_of::<TextBuffer>() as size_t,
    ) as *mut TextBuffer;
    if textBuffer.is_null() {
        return 0 as *mut TextBuffer;
    }
    (*textBuffer).lines = malloc(
        (::core::mem::size_of::<*mut GapBuffer>() as size_t)
            .wrapping_mul(num_lines as size_t),
    ) as *mut *mut GapBuffer;
    if (*textBuffer).lines.is_null() {
        return 0 as *mut TextBuffer;
    }
    let ref mut fresh0 = *(*textBuffer).lines.offset(0 as ::core::ffi::c_int as isize);
    *fresh0 = CreateGapBuffer(line_size);
    if (*(*textBuffer).lines.offset(0 as ::core::ffi::c_int as isize)).is_null() {
        return 0 as *mut TextBuffer;
    }
    let mut i: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    while i < num_lines {
        let ref mut fresh1 = *(*textBuffer).lines.offset(i as isize);
        *fresh1 = 0 as *mut GapBuffer;
        i += 1;
    }
    (*textBuffer).lines_capacity = num_lines;
    (*textBuffer).cursorRow = 0 as ::core::ffi::c_int;
    (*textBuffer).cursorCol = 0 as ::core::ffi::c_int;
    (*textBuffer).cursorColMoved = 0 as ::core::ffi::c_int;
    (*textBuffer).last_line_loc = 0 as ::core::ffi::c_int;
    return textBuffer;
}
#[no_mangle]
pub unsafe extern "C" fn DestroyTextBuffer(mut instance: *mut TextBuffer) {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*instance).lines_capacity {
        if (*(*instance).lines.offset(i as isize)).is_null() {
            break;
        }
        DestroyGapBuffer(*(*instance).lines.offset(i as isize));
        i += 1;
    }
    free((*instance).lines as *mut ::core::ffi::c_void);
    free(instance as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn TextBufferMoveCursor(
    mut instance: *mut TextBuffer,
    mut row: ::core::ffi::c_int,
    mut col: ::core::ffi::c_int,
) {
    if row > (*instance).last_line_loc {
        row = (*instance).last_line_loc;
    }
    if row < 0 as ::core::ffi::c_int {
        row = 0 as ::core::ffi::c_int;
    }
    (*instance).cursorRow = row;
    if col > (**(*instance).lines.offset(row as isize)).str_len {
        col = (**(*instance).lines.offset(row as isize)).str_len;
    }
    if col < 0 as ::core::ffi::c_int {
        col = 0 as ::core::ffi::c_int;
    }
    if (*instance).cursorCol != col {
        (*instance).cursorColMoved = 1 as ::core::ffi::c_int;
    }
    (*instance).cursorCol = col;
}
#[no_mangle]
pub unsafe extern "C" fn TextBufferInsert(
    mut instance: *mut TextBuffer,
    mut ch: ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    if (*instance).cursorColMoved != 0 {
        err = GapBufferMoveGap(
            *(*instance).lines.offset((*instance).cursorRow as isize),
            (*instance).cursorCol,
        );
        if err != 0 as ::core::ffi::c_int {
            return err;
        }
        (*instance).cursorColMoved = 0 as ::core::ffi::c_int;
    }
    err = GapBufferInsertChar(
        *(*instance).lines.offset((*instance).cursorRow as isize),
        ch,
    );
    if err != 0 as ::core::ffi::c_int {
        return err;
    }
    (*instance).cursorCol = (**(*instance).lines.offset((*instance).cursorRow as isize))
        .gap_loc;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn TextBufferBackspace(
    mut instance: *mut TextBuffer,
) -> ::core::ffi::c_int {
    let mut err: ::core::ffi::c_int = 0;
    if (*instance).cursorColMoved != 0 {
        err = GapBufferMoveGap(
            *(*instance).lines.offset((*instance).cursorRow as isize),
            (*instance).cursorCol,
        );
        if err != 0 as ::core::ffi::c_int {
            return err;
        }
        (*instance).cursorColMoved = 0 as ::core::ffi::c_int;
    }
    GapBufferBackSpace(*(*instance).lines.offset((*instance).cursorRow as isize));
    (*instance).cursorCol = (**(*instance).lines.offset((*instance).cursorRow as isize))
        .gap_loc;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn TextBufferNewLine(
    mut instance: *mut TextBuffer,
) -> ::core::ffi::c_int {
    let mut errno: ::core::ffi::c_int = 0;
    if (*instance).cursorColMoved != 0 {
        errno = GapBufferMoveGap(
            *(*instance).lines.offset((*instance).cursorRow as isize),
            (*instance).cursorCol,
        );
        if errno != 0 as ::core::ffi::c_int {
            return errno;
        }
        (*instance).cursorColMoved = 0 as ::core::ffi::c_int;
    }
    let mut newline: *mut GapBuffer = GapBufferSplit(
        *(*instance).lines.offset((*instance).cursorRow as isize),
    );
    if newline.is_null() {
        return MEM_ERROR;
    }
    if (*instance).last_line_loc == (*instance).lines_capacity - 1 as ::core::ffi::c_int
    {
        let mut new_lines: *mut *mut GapBuffer = realloc(
            (*instance).lines as *mut ::core::ffi::c_void,
            (::core::mem::size_of::<*mut GapBuffer>() as size_t)
                .wrapping_mul(
                    ((*instance).lines_capacity * 2 as ::core::ffi::c_int) as size_t,
                ),
        ) as *mut *mut GapBuffer;
        if new_lines.is_null() {
            return MEM_ERROR;
        }
        (*instance).lines = new_lines;
        (*instance).lines_capacity *= 2 as ::core::ffi::c_int;
    }
    memmove(
        (*instance)
            .lines
            .offset((*instance).cursorRow as isize)
            .offset(2 as ::core::ffi::c_int as isize) as *mut ::core::ffi::c_void,
        (*instance)
            .lines
            .offset((*instance).cursorRow as isize)
            .offset(1 as ::core::ffi::c_int as isize) as *const ::core::ffi::c_void,
        (::core::mem::size_of::<*mut GapBuffer>() as size_t)
            .wrapping_mul(((*instance).last_line_loc - (*instance).cursorRow) as size_t),
    );
    let ref mut fresh2 = *(*instance)
        .lines
        .offset(((*instance).cursorRow + 1 as ::core::ffi::c_int) as isize);
    *fresh2 = newline;
    (*instance).last_line_loc += 1;
    (*instance).cursorRow += 1;
    (*instance).cursorCol = (*newline).gap_loc;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn TextBufferGetLine(
    mut instance: *mut TextBuffer,
    mut row: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_char {
    if row > (*instance).last_line_loc {
        return 0 as *mut ::core::ffi::c_char;
    }
    if row < 0 as ::core::ffi::c_int {
        return 0 as *mut ::core::ffi::c_char;
    }
    return GapBufferGetString(*(*instance).lines.offset(row as isize));
}
#[no_mangle]
pub unsafe extern "C" fn CreateTextBufferFromFile(mut fp: *mut FILE) -> *mut TextBuffer {
    let mut new_tbuffer: *mut TextBuffer = CreateTextBuffer(
        DEFAULT_CAPACITY,
        DEFAULT_GAP_BUF_CAP,
    );
    if new_tbuffer.is_null() {
        return 0 as *mut TextBuffer;
    }
    if fp.is_null() {
        return new_tbuffer;
    }
    DestroyGapBuffer(
        *(*new_tbuffer).lines.offset((*new_tbuffer).last_line_loc as isize),
    );
    (*new_tbuffer).last_line_loc = -(1 as ::core::ffi::c_int);
    let mut line: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut len: size_t = 0 as size_t;
    let mut read: size_t = 0;
    let mut line_gap_size: ::core::ffi::c_int = 0;
    loop {
        read = getline(&mut line, &mut len, fp) as size_t;
        if !(read != -(1 as ::core::ffi::c_int) as size_t) {
            break;
        }
        if *line.offset(read.wrapping_sub(1 as size_t) as isize) as ::core::ffi::c_int
            == '\n' as i32
        {
            *line.offset(read.wrapping_sub(1 as size_t) as isize) = '\0' as i32
                as ::core::ffi::c_char;
        }
        if (*new_tbuffer).last_line_loc
            == (*new_tbuffer).lines_capacity - 1 as ::core::ffi::c_int
        {
            (*new_tbuffer).lines = realloc(
                (*new_tbuffer).lines as *mut ::core::ffi::c_void,
                (::core::mem::size_of::<*mut GapBuffer>() as size_t)
                    .wrapping_mul((*new_tbuffer).lines_capacity as size_t)
                    .wrapping_mul(2 as size_t),
            ) as *mut *mut GapBuffer;
            if (*new_tbuffer).lines.is_null() {
                DestroyTextBuffer(new_tbuffer);
                return 0 as *mut TextBuffer;
            }
            (*new_tbuffer).lines_capacity = (*new_tbuffer).lines_capacity
                * 2 as ::core::ffi::c_int;
        }
        line_gap_size = (if read.wrapping_mul(2 as size_t)
            < DEFAULT_GAP_BUF_CAP as size_t
        {
            DEFAULT_GAP_BUF_CAP as size_t
        } else {
            read.wrapping_mul(2 as size_t)
        }) as ::core::ffi::c_int;
        let ref mut fresh3 = *(*new_tbuffer)
            .lines
            .offset(((*new_tbuffer).last_line_loc + 1 as ::core::ffi::c_int) as isize);
        *fresh3 = CreateGapBufferFromString(line, line_gap_size);
        if (*(*new_tbuffer)
            .lines
            .offset(((*new_tbuffer).last_line_loc + 1 as ::core::ffi::c_int) as isize))
            .is_null()
        {
            DestroyTextBuffer(new_tbuffer);
            return 0 as *mut TextBuffer;
        }
        (*new_tbuffer).last_line_loc += 1;
    }
    free(line as *mut ::core::ffi::c_void);
    return new_tbuffer;
}
