#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct GapBuffer {
    pub buffer: *mut ::core::ffi::c_char,
    pub str_len: ::core::ffi::c_int,
    pub gap_len: ::core::ffi::c_int,
    pub gap_loc: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const MEM_ERROR: ::core::ffi::c_int = 128 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn resizeBuffer(
    mut instance: *mut GapBuffer,
    mut new_capacity: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut buffer_size: ::core::ffi::c_int = (*instance).str_len + (*instance).gap_len;
    if new_capacity < buffer_size {
        new_capacity = buffer_size;
    }
    let mut gap_size: ::core::ffi::c_int = (*instance).gap_len
        + (new_capacity - buffer_size);
    let mut new_buffer: *mut ::core::ffi::c_char = malloc(
        (::core::mem::size_of::<::core::ffi::c_char>() as size_t)
            .wrapping_mul(new_capacity as size_t),
    ) as *mut ::core::ffi::c_char;
    if new_buffer.is_null() {
        return MEM_ERROR;
    }
    memcpy(
        new_buffer as *mut ::core::ffi::c_void,
        (*instance).buffer as *const ::core::ffi::c_void,
        (::core::mem::size_of::<::core::ffi::c_char>() as size_t)
            .wrapping_mul((*instance).gap_loc as size_t),
    );
    memcpy(
        new_buffer.offset((*instance).gap_loc as isize).offset(gap_size as isize)
            as *mut ::core::ffi::c_void,
        (*instance)
            .buffer
            .offset((*instance).gap_loc as isize)
            .offset((*instance).gap_len as isize) as *const ::core::ffi::c_void,
        ((*instance).str_len - (*instance).gap_loc) as size_t,
    );
    free((*instance).buffer as *mut ::core::ffi::c_void);
    (*instance).buffer = new_buffer;
    (*instance).gap_len = gap_size;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn CreateGapBuffer(
    mut capacity: ::core::ffi::c_int,
) -> *mut GapBuffer {
    let mut gap_buffer: *mut GapBuffer = malloc(
        ::core::mem::size_of::<GapBuffer>() as size_t,
    ) as *mut GapBuffer;
    if gap_buffer.is_null() {
        return 0 as *mut GapBuffer;
    }
    (*gap_buffer).buffer = malloc(
        (::core::mem::size_of::<::core::ffi::c_char>() as size_t)
            .wrapping_mul(capacity as size_t),
    ) as *mut ::core::ffi::c_char;
    if (*gap_buffer).buffer.is_null() {
        free(gap_buffer as *mut ::core::ffi::c_void);
        return 0 as *mut GapBuffer;
    }
    (*gap_buffer).gap_loc = 0 as ::core::ffi::c_int;
    (*gap_buffer).gap_len = capacity;
    (*gap_buffer).str_len = 0 as ::core::ffi::c_int;
    return gap_buffer;
}
#[no_mangle]
pub unsafe extern "C" fn DestroyGapBuffer(mut instance: *mut GapBuffer) {
    free((*instance).buffer as *mut ::core::ffi::c_void);
    free(instance as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn GapBufferInsertChar(
    mut instance: *mut GapBuffer,
    mut ch: ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut errno: ::core::ffi::c_int = 0;
    if (*instance).gap_len <= 1 as ::core::ffi::c_int {
        let mut current_cap: ::core::ffi::c_int = (*instance).gap_len
            + (*instance).str_len;
        errno = resizeBuffer(instance, current_cap * 2 as ::core::ffi::c_int);
        if errno != 0 as ::core::ffi::c_int {
            return errno;
        }
    }
    *(*instance).buffer.offset((*instance).gap_loc as isize) = ch;
    (*instance).str_len += 1;
    (*instance).gap_loc += 1;
    (*instance).gap_len -= 1;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn GapBufferBackSpace(mut instance: *mut GapBuffer) {
    if (*instance).gap_loc > 0 as ::core::ffi::c_int {
        (*instance).gap_loc -= 1;
        (*instance).gap_len += 1;
        (*instance).str_len -= 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn GapBufferMoveGap(
    mut instance: *mut GapBuffer,
    mut location: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    if location > (*instance).str_len {
        location = (*instance).str_len;
    }
    if location < 0 as ::core::ffi::c_int {
        location = 0 as ::core::ffi::c_int;
    }
    let mut capacity: ::core::ffi::c_int = (*instance).gap_len + (*instance).str_len;
    let mut new_buffer: *mut ::core::ffi::c_char = malloc(
        (::core::mem::size_of::<::core::ffi::c_char>() as size_t)
            .wrapping_mul(capacity as size_t),
    ) as *mut ::core::ffi::c_char;
    if new_buffer.is_null() {
        return MEM_ERROR;
    }
    if location < (*instance).gap_loc {
        memcpy(
            new_buffer as *mut ::core::ffi::c_void,
            (*instance).buffer as *const ::core::ffi::c_void,
            (::core::mem::size_of::<::core::ffi::c_char>() as size_t)
                .wrapping_mul(location as size_t),
        );
        memcpy(
            new_buffer.offset(location as isize).offset((*instance).gap_len as isize)
                as *mut ::core::ffi::c_void,
            (*instance).buffer.offset(location as isize) as *const ::core::ffi::c_void,
            (::core::mem::size_of::<::core::ffi::c_char>() as size_t)
                .wrapping_mul(((*instance).gap_loc - location) as size_t),
        );
        memcpy(
            new_buffer
                .offset(location as isize)
                .offset((*instance).gap_len as isize)
                .offset(((*instance).gap_loc - location) as isize)
                as *mut ::core::ffi::c_void,
            (*instance)
                .buffer
                .offset((*instance).gap_loc as isize)
                .offset((*instance).gap_len as isize) as *const ::core::ffi::c_void,
            (::core::mem::size_of::<::core::ffi::c_char>() as size_t)
                .wrapping_mul((*instance).str_len as size_t)
                .wrapping_sub((*instance).gap_loc as size_t),
        );
    } else {
        memcpy(
            new_buffer as *mut ::core::ffi::c_void,
            (*instance).buffer as *const ::core::ffi::c_void,
            (::core::mem::size_of::<::core::ffi::c_char>() as size_t)
                .wrapping_mul((*instance).gap_loc as size_t),
        );
        memcpy(
            new_buffer.offset((*instance).gap_loc as isize) as *mut ::core::ffi::c_void,
            (*instance)
                .buffer
                .offset((*instance).gap_loc as isize)
                .offset((*instance).gap_len as isize) as *const ::core::ffi::c_void,
            (::core::mem::size_of::<::core::ffi::c_char>() as size_t)
                .wrapping_mul((location - (*instance).gap_loc) as size_t),
        );
        memcpy(
            new_buffer.offset(location as isize).offset((*instance).gap_len as isize)
                as *mut ::core::ffi::c_void,
            (*instance)
                .buffer
                .offset((*instance).gap_loc as isize)
                .offset((*instance).gap_len as isize)
                .offset((location - (*instance).gap_loc) as isize)
                as *const ::core::ffi::c_void,
            (::core::mem::size_of::<::core::ffi::c_char>() as size_t)
                .wrapping_mul((*instance).str_len as size_t)
                .wrapping_sub(location as size_t),
        );
    }
    free((*instance).buffer as *mut ::core::ffi::c_void);
    (*instance).buffer = new_buffer;
    (*instance).gap_loc = location;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn GapBufferGetString(
    mut instance: *mut GapBuffer,
) -> *mut ::core::ffi::c_char {
    let mut buffer: *mut ::core::ffi::c_char = malloc(
        (1 as size_t)
            .wrapping_add(
                (::core::mem::size_of::<::core::ffi::c_char>() as size_t)
                    .wrapping_mul((*instance).str_len as size_t),
            ),
    ) as *mut ::core::ffi::c_char;
    if buffer.is_null() {
        return 0 as *mut ::core::ffi::c_char;
    }
    memcpy(
        buffer as *mut ::core::ffi::c_void,
        (*instance).buffer as *const ::core::ffi::c_void,
        (*instance).gap_loc as size_t,
    );
    memcpy(
        buffer.offset((*instance).gap_loc as isize) as *mut ::core::ffi::c_void,
        (*instance)
            .buffer
            .offset((*instance).gap_loc as isize)
            .offset((*instance).gap_len as isize) as *const ::core::ffi::c_void,
        ((*instance).str_len - (*instance).gap_loc) as size_t,
    );
    *buffer.offset((*instance).str_len as isize) = '\0' as i32 as ::core::ffi::c_char;
    return buffer;
}
#[no_mangle]
pub unsafe extern "C" fn GapBufferSplit(mut instance: *mut GapBuffer) -> *mut GapBuffer {
    let mut capacity: ::core::ffi::c_int = (*instance).gap_len + (*instance).str_len;
    let mut second_half_of_str_len: ::core::ffi::c_int = (*instance).str_len
        - (*instance).gap_loc;
    let mut new_gap_buffer: *mut GapBuffer = CreateGapBuffer(capacity);
    if new_gap_buffer.is_null() {
        return 0 as *mut GapBuffer;
    }
    memcpy(
        (*new_gap_buffer).buffer.offset((capacity - second_half_of_str_len) as isize)
            as *mut ::core::ffi::c_void,
        (*instance)
            .buffer
            .offset((*instance).gap_loc as isize)
            .offset((*instance).gap_len as isize) as *const ::core::ffi::c_void,
        second_half_of_str_len as size_t,
    );
    (*new_gap_buffer).str_len = second_half_of_str_len;
    (*new_gap_buffer).gap_loc = 0 as ::core::ffi::c_int;
    (*new_gap_buffer).gap_len = capacity - second_half_of_str_len;
    (*instance).str_len = (*instance).gap_loc;
    (*instance).gap_len = capacity - (*instance).str_len;
    return new_gap_buffer;
}
#[no_mangle]
pub unsafe extern "C" fn CreateGapBufferFromString(
    mut str: *mut ::core::ffi::c_char,
    mut gap_len: ::core::ffi::c_int,
) -> *mut GapBuffer {
    let mut s_len: ::core::ffi::c_int = strlen(str) as ::core::ffi::c_int;
    let mut capacity: ::core::ffi::c_int = s_len + gap_len;
    let mut new_buffer: *mut GapBuffer = 0 as *mut GapBuffer;
    if str.is_null() || s_len == 0 as ::core::ffi::c_int {
        return CreateGapBuffer(gap_len)
    } else {
        new_buffer = CreateGapBuffer(capacity);
        if new_buffer.is_null() {
            return 0 as *mut GapBuffer;
        }
        memcpy(
            (*new_buffer).buffer as *mut ::core::ffi::c_void,
            str as *const ::core::ffi::c_void,
            s_len as size_t,
        );
        (*new_buffer).str_len = s_len;
        (*new_buffer).gap_loc = s_len;
        (*new_buffer).gap_len = gap_len;
        return new_buffer;
    };
}
#[no_mangle]
pub unsafe extern "C" fn GapBufferCharAt(
    mut instance: *mut GapBuffer,
    mut i: ::core::ffi::c_int,
) -> ::core::ffi::c_char {
    if instance.is_null() || (*instance).str_len == 0 as ::core::ffi::c_int
        || i < 0 as ::core::ffi::c_int || i >= (*instance).str_len
    {
        return '\0' as i32 as ::core::ffi::c_char;
    }
    if i < (*instance).gap_loc {
        return *(*instance).buffer.offset(i as isize)
    } else {
        return *(*instance).buffer.offset((i + (*instance).gap_len) as isize)
    };
}
