#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn free(_: *mut ::core::ffi::c_void);
    fn exit(_: ::core::ffi::c_int) -> !;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn CreateGapBuffer(capacity: ::core::ffi::c_int) -> *mut GapBuffer;
    fn DestroyGapBuffer(instance: *mut GapBuffer);
    fn GapBufferInsertChar(
        instance: *mut GapBuffer,
        ch: ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn GapBufferBackSpace(instance: *mut GapBuffer);
    fn GapBufferMoveGap(
        instance: *mut GapBuffer,
        location: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn GapBufferGetString(instance: *mut GapBuffer) -> *mut ::core::ffi::c_char;
    fn GapBufferSplit(instance: *mut GapBuffer) -> *mut GapBuffer;
    fn CreateGapBufferFromString(
        str: *mut ::core::ffi::c_char,
        gap_len: ::core::ffi::c_int,
    ) -> *mut GapBuffer;
    fn CreateTextBuffer(
        lines: ::core::ffi::c_int,
        line_size: ::core::ffi::c_int,
    ) -> *mut TextBuffer;
    fn DestroyTextBuffer(instance: *mut TextBuffer);
    fn TextBufferMoveCursor(
        instance: *mut TextBuffer,
        row: ::core::ffi::c_int,
        col: ::core::ffi::c_int,
    );
    fn TextBufferInsert(
        instance: *mut TextBuffer,
        ch: ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn TextBufferBackspace(instance: *mut TextBuffer) -> ::core::ffi::c_int;
    fn TextBufferNewLine(instance: *mut TextBuffer) -> ::core::ffi::c_int;
    fn TextBufferGetLine(
        instance: *mut TextBuffer,
        row: ::core::ffi::c_int,
    ) -> *mut ::core::ffi::c_char;
    fn CreateTextBufferFromFile(fp: *mut FILE) -> *mut TextBuffer;
}
pub type __int64_t = i64;
pub type __darwin_off_t = __int64_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct GapBuffer {
    pub buffer: *mut ::core::ffi::c_char,
    pub str_len: ::core::ffi::c_int,
    pub gap_len: ::core::ffi::c_int,
    pub gap_loc: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct TextBuffer {
    pub lines: *mut *mut GapBuffer,
    pub lines_capacity: ::core::ffi::c_int,
    pub cursorRow: ::core::ffi::c_int,
    pub cursorCol: ::core::ffi::c_int,
    pub cursorColMoved: ::core::ffi::c_int,
    pub last_line_loc: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub static mut test_fp: *mut FILE = 0 as *const FILE as *mut FILE;
#[no_mangle]
pub static mut test_file_path: [::core::ffi::c_char; 19] = unsafe {
    ::core::mem::transmute::<
        [u8; 19],
        [::core::ffi::c_char; 19],
    >(*b"tests/runtests.txt\0")
};
unsafe fn main_0() -> ::core::ffi::c_int {
    test_fp = fopen(
        test_file_path.as_mut_ptr(),
        b"r\0" as *const u8 as *const ::core::ffi::c_char,
    ) as *mut FILE;
    if test_fp.is_null() {
        printf(
            b"Error: Failed to open test file. Please run the test in the project directory.\n'tests/runtests.c' must be valid in the working directory\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
        exit(1 as ::core::ffi::c_int);
    }
    TestGapBuffer();
    TestTextBuffer();
    printf(b"All tests passed!\n\0" as *const u8 as *const ::core::ffi::c_char);
    return 0;
}
#[no_mangle]
pub unsafe extern "C" fn string_comp_assert(
    mut str1: *mut ::core::ffi::c_char,
    mut str2: *const ::core::ffi::c_char,
) {
    if str1.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"string_comp_assert\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            44 as ::core::ffi::c_int,
            b"str1 != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if str2.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"string_comp_assert\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            45 as ::core::ffi::c_int,
            b"str2 != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strcmp(str1, str2) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"string_comp_assert\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            46 as ::core::ffi::c_int,
            b"strcmp(str1, str2) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    free(str1 as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn TestGapBuffer() {
    printf(b"\n\nTesting GapBuffer\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut buffer: *mut GapBuffer = CreateGapBuffer(20 as ::core::ffi::c_int);
    if buffer.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"TestGapBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            54 as ::core::ffi::c_int,
            b"buffer != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut string_holder: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut string_holder2: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut err: ::core::ffi::c_int = 0;
    let sample1: [::core::ffi::c_char; 1] = ::core::mem::transmute::<
        [u8; 1],
        [::core::ffi::c_char; 1],
    >(*b"\0");
    let sample2: [::core::ffi::c_char; 2] = ::core::mem::transmute::<
        [u8; 2],
        [::core::ffi::c_char; 2],
    >(*b"a\0");
    let sample3: [::core::ffi::c_char; 12] = ::core::mem::transmute::<
        [u8; 12],
        [::core::ffi::c_char; 12],
    >(*b"aaaaaaaaaaa\0");
    let sample4: [::core::ffi::c_char; 22] = ::core::mem::transmute::<
        [u8; 22],
        [::core::ffi::c_char; 22],
    >(*b"aaaaaaaaaaaaaaaaaaaaa\0");
    let sample5: [::core::ffi::c_char; 21] = ::core::mem::transmute::<
        [u8; 21],
        [::core::ffi::c_char; 21],
    >(*b"aaaaaaaaaaaaaaaaaaaa\0");
    let sample6: [::core::ffi::c_char; 24] = ::core::mem::transmute::<
        [u8; 24],
        [::core::ffi::c_char; 24],
    >(*b"aaabbbaaaaaaaaaaaaaaaaa\0");
    let sample7: [::core::ffi::c_char; 27] = ::core::mem::transmute::<
        [u8; 27],
        [::core::ffi::c_char; 27],
    >(*b"cccaaabbbaaaaaaaaaaaaaaaaa\0");
    let sample8: [::core::ffi::c_char; 30] = ::core::mem::transmute::<
        [u8; 30],
        [::core::ffi::c_char; 30],
    >(*b"cccaaabbbaaaaaaaaaaaaaaaaaddd\0");
    let sample9: [::core::ffi::c_char; 7] = ::core::mem::transmute::<
        [u8; 7],
        [::core::ffi::c_char; 7],
    >(*b"cccaaa\0");
    let sample10: [::core::ffi::c_char; 24] = ::core::mem::transmute::<
        [u8; 24],
        [::core::ffi::c_char; 24],
    >(*b"bbbaaaaaaaaaaaaaaaaaddd\0");
    let sample11: [::core::ffi::c_char; 8] = ::core::mem::transmute::<
        [u8; 8],
        [::core::ffi::c_char; 8],
    >(*b"cccaaax\0");
    let sample12: [::core::ffi::c_char; 25] = ::core::mem::transmute::<
        [u8; 25],
        [::core::ffi::c_char; 25],
    >(*b"ybbbaaaaaaaaaaaaaaaaaddd\0");
    let sample13: [::core::ffi::c_char; 26] = ::core::mem::transmute::<
        [u8; 26],
        [::core::ffi::c_char; 26],
    >(*b"ybbbaaaaaaaaaaaaaaaaadddp\0");
    printf(b"Test 1, empty string\n\0" as *const u8 as *const ::core::ffi::c_char);
    string_holder = GapBufferGetString(buffer);
    string_comp_assert(string_holder, sample1.as_ptr());
    printf(b"Test 2 insert char\n\0" as *const u8 as *const ::core::ffi::c_char);
    err = GapBufferInsertChar(buffer, 'a' as i32 as ::core::ffi::c_char);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"TestGapBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            82 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    string_holder = GapBufferGetString(buffer);
    string_comp_assert(string_holder, sample2.as_ptr());
    printf(b"Test 2.1 insert char\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < 10 as ::core::ffi::c_int {
        err = GapBufferInsertChar(buffer, 'a' as i32 as ::core::ffi::c_char);
        if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
            != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 14],
                    [::core::ffi::c_char; 14],
                >(*b"TestGapBuffer\0")
                    .as_ptr(),
                b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
                90 as ::core::ffi::c_int,
                b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        i += 1;
    }
    string_holder = GapBufferGetString(buffer);
    string_comp_assert(string_holder, sample3.as_ptr());
    printf(
        b"Test 2.2 insert char (resize) \n\0" as *const u8 as *const ::core::ffi::c_char,
    );
    let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_0 < 10 as ::core::ffi::c_int {
        err = GapBufferInsertChar(buffer, 'a' as i32 as ::core::ffi::c_char);
        if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
            != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 14],
                    [::core::ffi::c_char; 14],
                >(*b"TestGapBuffer\0")
                    .as_ptr(),
                b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
                99 as ::core::ffi::c_int,
                b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        i_0 += 1;
    }
    string_holder = GapBufferGetString(buffer);
    string_comp_assert(string_holder, sample4.as_ptr());
    printf(b"Test 3 Backspace \n\0" as *const u8 as *const ::core::ffi::c_char);
    GapBufferBackSpace(buffer);
    string_holder = GapBufferGetString(buffer);
    string_comp_assert(string_holder, sample5.as_ptr());
    printf(
        b"Test 4 GapBufferMoveGap, TextBufferInsert and Backspace \n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    err = GapBufferMoveGap(buffer, 3 as ::core::ffi::c_int);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"TestGapBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            114 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut i_1: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_1 < 3 as ::core::ffi::c_int {
        err = GapBufferInsertChar(buffer, 'b' as i32 as ::core::ffi::c_char);
        if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
            != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 14],
                    [::core::ffi::c_char; 14],
                >(*b"TestGapBuffer\0")
                    .as_ptr(),
                b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
                118 as ::core::ffi::c_int,
                b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        i_1 += 1;
    }
    string_holder = GapBufferGetString(buffer);
    string_comp_assert(string_holder, sample6.as_ptr());
    printf(
        b"Test 4.1 GapBufferMoveGap, TextBufferInsert and Backspace \n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    err = GapBufferMoveGap(buffer, 0 as ::core::ffi::c_int);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"TestGapBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            127 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut i_2: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_2 < 3 as ::core::ffi::c_int {
        err = GapBufferInsertChar(buffer, 'c' as i32 as ::core::ffi::c_char);
        if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
            != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 14],
                    [::core::ffi::c_char; 14],
                >(*b"TestGapBuffer\0")
                    .as_ptr(),
                b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
                131 as ::core::ffi::c_int,
                b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        i_2 += 1;
    }
    string_holder = GapBufferGetString(buffer);
    string_comp_assert(string_holder, sample7.as_ptr());
    printf(
        b"Test 4.2 GapBufferMoveGap, TextBufferInsert and Backspace \n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    err = GapBufferMoveGap(buffer, (*buffer).str_len);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"TestGapBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            140 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut i_3: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_3 < 3 as ::core::ffi::c_int {
        err = GapBufferInsertChar(buffer, 'd' as i32 as ::core::ffi::c_char);
        if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
            != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 14],
                    [::core::ffi::c_char; 14],
                >(*b"TestGapBuffer\0")
                    .as_ptr(),
                b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
                144 as ::core::ffi::c_int,
                b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        i_3 += 1;
    }
    string_holder = GapBufferGetString(buffer);
    string_comp_assert(string_holder, sample8.as_ptr());
    printf(b"Test 5 Split\n\0" as *const u8 as *const ::core::ffi::c_char);
    err = GapBufferMoveGap(buffer, 6 as ::core::ffi::c_int);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"TestGapBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            152 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut buffer2: *mut GapBuffer = GapBufferSplit(buffer);
    if buffer2.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"TestGapBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            155 as ::core::ffi::c_int,
            b"buffer2 != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    string_holder = GapBufferGetString(buffer);
    string_holder2 = GapBufferGetString(buffer2);
    string_comp_assert(string_holder, sample9.as_ptr());
    string_comp_assert(string_holder2, sample10.as_ptr());
    printf(b"Test 5.1 Split\n\0" as *const u8 as *const ::core::ffi::c_char);
    err = GapBufferInsertChar(buffer, 'x' as i32 as ::core::ffi::c_char);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"TestGapBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            165 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    string_holder = GapBufferGetString(buffer);
    string_comp_assert(string_holder, sample11.as_ptr());
    printf(b"Test 5.2 Split\n\0" as *const u8 as *const ::core::ffi::c_char);
    err = GapBufferInsertChar(buffer2, 'y' as i32 as ::core::ffi::c_char);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"TestGapBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            173 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    string_holder = GapBufferGetString(buffer2);
    string_comp_assert(string_holder, sample12.as_ptr());
    printf(b"Test 6 Create From string\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut buffer3: *mut GapBuffer = CreateGapBufferFromString(
        sample12.as_ptr() as *mut ::core::ffi::c_char,
        10 as ::core::ffi::c_int,
    );
    if buffer.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"TestGapBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            182 as ::core::ffi::c_int,
            b"buffer != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    string_holder = GapBufferGetString(buffer3);
    string_comp_assert(string_holder, sample12.as_ptr());
    printf(
        b"Test 6.1 Create From string\n\0" as *const u8 as *const ::core::ffi::c_char,
    );
    err = GapBufferInsertChar(buffer3, 'p' as i32 as ::core::ffi::c_char);
    if !(err == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 14],
                [::core::ffi::c_char; 14],
            >(*b"TestGapBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            190 as ::core::ffi::c_int,
            b"err == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    string_holder = GapBufferGetString(buffer3);
    string_comp_assert(string_holder, sample13.as_ptr());
    printf(b"Test 7 Backspace\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut i_4: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_4 < 7 as ::core::ffi::c_int {
        GapBufferBackSpace(buffer);
        i_4 += 1;
    }
    string_holder = GapBufferGetString(buffer);
    string_comp_assert(string_holder, sample1.as_ptr());
    printf(b"Cleanup...\n\0" as *const u8 as *const ::core::ffi::c_char);
    DestroyGapBuffer(buffer);
    DestroyGapBuffer(buffer2);
    DestroyGapBuffer(buffer3);
    printf(b"GapBuffer Tests Passed.\0" as *const u8 as *const ::core::ffi::c_char);
}
#[no_mangle]
pub unsafe extern "C" fn TestTextBuffer() {
    printf(b"\n\nTesting TextBuffer\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut texBuffer: *mut TextBuffer = CreateTextBuffer(
        10 as ::core::ffi::c_int,
        20 as ::core::ffi::c_int,
    );
    if texBuffer.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 15],
                [::core::ffi::c_char; 15],
            >(*b"TestTextBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            221 as ::core::ffi::c_int,
            b"texBuffer != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut errno: ::core::ffi::c_int = 0;
    let mut string_holder: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let sample1: [::core::ffi::c_char; 1] = ::core::mem::transmute::<
        [u8; 1],
        [::core::ffi::c_char; 1],
    >(*b"\0");
    let sample2: [::core::ffi::c_char; 2] = ::core::mem::transmute::<
        [u8; 2],
        [::core::ffi::c_char; 2],
    >(*b"a\0");
    let sample3: [::core::ffi::c_char; 12] = ::core::mem::transmute::<
        [u8; 12],
        [::core::ffi::c_char; 12],
    >(*b"aaaaaaaaaaa\0");
    let sample4: [::core::ffi::c_char; 11] = ::core::mem::transmute::<
        [u8; 11],
        [::core::ffi::c_char; 11],
    >(*b"aaaaaaaaaa\0");
    let sample5: [::core::ffi::c_char; 10] = ::core::mem::transmute::<
        [u8; 10],
        [::core::ffi::c_char; 10],
    >(*b"aaaaaaaaa\0");
    printf(b"Test 1, empty string\n\0" as *const u8 as *const ::core::ffi::c_char);
    string_holder = TextBufferGetLine(texBuffer, (*texBuffer).cursorRow);
    string_comp_assert(string_holder, sample1.as_ptr());
    printf(b"Test 2 insert char\n\0" as *const u8 as *const ::core::ffi::c_char);
    errno = TextBufferInsert(texBuffer, 'a' as i32 as ::core::ffi::c_char);
    if !(errno == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 15],
                [::core::ffi::c_char; 15],
            >(*b"TestTextBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            240 as ::core::ffi::c_int,
            b"errno == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    string_holder = TextBufferGetLine(texBuffer, (*texBuffer).cursorRow);
    string_comp_assert(string_holder, sample2.as_ptr());
    printf(b"Test 2.1 insert char\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < 10 as ::core::ffi::c_int {
        errno = TextBufferInsert(texBuffer, 'a' as i32 as ::core::ffi::c_char);
        if !(errno == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
            as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 15],
                    [::core::ffi::c_char; 15],
                >(*b"TestTextBuffer\0")
                    .as_ptr(),
                b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
                248 as ::core::ffi::c_int,
                b"errno == 0\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        i += 1;
    }
    string_holder = TextBufferGetLine(texBuffer, (*texBuffer).cursorRow);
    string_comp_assert(string_holder, sample3.as_ptr());
    printf(b"Test 3 Backspace \n\0" as *const u8 as *const ::core::ffi::c_char);
    TextBufferBackspace(texBuffer);
    string_holder = TextBufferGetLine(texBuffer, (*texBuffer).cursorRow);
    string_comp_assert(string_holder, sample4.as_ptr());
    printf(b"Test 4 MoveCursor, Newline\n\0" as *const u8 as *const ::core::ffi::c_char);
    TextBufferMoveCursor(
        texBuffer,
        (*texBuffer).cursorRow,
        (*texBuffer).cursorCol - 1 as ::core::ffi::c_int,
    );
    errno = TextBufferNewLine(texBuffer);
    if !(errno == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 15],
                [::core::ffi::c_char; 15],
            >(*b"TestTextBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            262 as ::core::ffi::c_int,
            b"errno == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    string_holder = TextBufferGetLine(texBuffer, (*texBuffer).cursorRow);
    string_comp_assert(string_holder, sample2.as_ptr());
    string_holder = TextBufferGetLine(
        texBuffer,
        (*texBuffer).cursorRow - 1 as ::core::ffi::c_int,
    );
    string_comp_assert(string_holder, sample5.as_ptr());
    printf(b"Test 5 Create from file\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut textBuffer2: *mut TextBuffer = CreateTextBufferFromFile(test_fp);
    if textBuffer2.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 15],
                [::core::ffi::c_char; 15],
            >(*b"TestTextBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            273 as ::core::ffi::c_int,
            b"textBuffer2 != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*textBuffer2).cursorRow == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 15],
                [::core::ffi::c_char; 15],
            >(*b"TestTextBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            274 as ::core::ffi::c_int,
            b"textBuffer2->cursorRow == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*textBuffer2).cursorCol == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 15],
                [::core::ffi::c_char; 15],
            >(*b"TestTextBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            275 as ::core::ffi::c_int,
            b"textBuffer2->cursorCol == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*textBuffer2).last_line_loc == 2 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 15],
                [::core::ffi::c_char; 15],
            >(*b"TestTextBuffer\0")
                .as_ptr(),
            b"runtests.c\0" as *const u8 as *const ::core::ffi::c_char,
            276 as ::core::ffi::c_int,
            b"textBuffer2->last_line_loc == 2\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    string_holder = TextBufferGetLine(textBuffer2, 0 as ::core::ffi::c_int);
    string_comp_assert(string_holder, sample3.as_ptr());
    string_holder = TextBufferGetLine(textBuffer2, 1 as ::core::ffi::c_int);
    string_comp_assert(string_holder, sample4.as_ptr());
    string_holder = TextBufferGetLine(textBuffer2, 2 as ::core::ffi::c_int);
    string_comp_assert(string_holder, sample5.as_ptr());
    printf(b"Cleanup...\n\0" as *const u8 as *const ::core::ffi::c_char);
    DestroyTextBuffer(texBuffer);
    printf(b"TextBuffer Tests Passed.\n\0" as *const u8 as *const ::core::ffi::c_char);
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
