#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn time(_: *mut time_t) -> time_t;
    fn totp(key: *const uint8_t, time_0: uint64_t) -> ::core::ffi::c_int;
    fn from_base32(
        s: *const ::core::ffi::c_char,
        buf: *mut uint8_t,
        cap: size_t,
    ) -> size_t;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_time_t = ::core::ffi::c_long;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type uint8_t = u8;
pub type uint64_t = u64;
pub type time_t = __darwin_time_t;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut seed: *const ::core::ffi::c_char = 0 as *const ::core::ffi::c_char;
    let mut key: [uint8_t; 64] = [0; 64];
    if argc != 2 as ::core::ffi::c_int {
        fprintf(
            __stderrp,
            b"usage: totp [seed in base32]\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 64 as ::core::ffi::c_int;
    }
    seed = *argv.offset(1 as ::core::ffi::c_int as isize);
    memset(
        key.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<[uint8_t; 64]>() as size_t,
    );
    if from_base32(
        seed,
        key.as_mut_ptr(),
        ::core::mem::size_of::<[uint8_t; 64]>() as size_t,
    ) == 0
    {
        fprintf(
            __stderrp,
            b"invalid seed\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 64 as ::core::ffi::c_int;
    }
    printf(
        b"%06d\n\0" as *const u8 as *const ::core::ffi::c_char,
        totp(key.as_mut_ptr() as *const uint8_t, time(0 as *mut time_t) as uint64_t),
    );
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
