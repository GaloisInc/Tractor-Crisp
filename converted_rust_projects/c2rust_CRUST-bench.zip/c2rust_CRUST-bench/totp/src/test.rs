#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn snprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strncmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> ::core::ffi::c_int;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn sha1(
        buf: *mut uint8_t,
        len: size_t,
        cap: size_t,
        hash: *mut uint8_t,
    ) -> ::core::ffi::c_int;
    fn hmac_sha1(
        key: *const uint8_t,
        data: *const uint8_t,
        len: size_t,
        hash: *mut uint8_t,
    ) -> ::core::ffi::c_int;
    fn hotp(key: *const uint8_t, counter: uint64_t) -> ::core::ffi::c_int;
    fn from_base32(
        s: *const ::core::ffi::c_char,
        buf: *mut uint8_t,
        cap: size_t,
    ) -> size_t;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
pub type uint32_t = u32;
pub type uint64_t = u64;
#[inline]
unsafe extern "C" fn unpack32(mut x: uint32_t, mut a: *mut uint8_t) {
    *a.offset(0 as ::core::ffi::c_int as isize) = (x >> 24 as ::core::ffi::c_int)
        as uint8_t;
    *a.offset(1 as ::core::ffi::c_int as isize) = (x >> 16 as ::core::ffi::c_int)
        as uint8_t;
    *a.offset(2 as ::core::ffi::c_int as isize) = (x >> 8 as ::core::ffi::c_int)
        as uint8_t;
    *a.offset(3 as ::core::ffi::c_int as isize) = x as uint8_t;
}
#[inline]
unsafe extern "C" fn unpack64(mut x: uint64_t, mut a: *mut uint8_t) {
    unpack32(
        (x >> 32 as ::core::ffi::c_int) as uint32_t,
        &mut *a.offset(0 as ::core::ffi::c_int as isize),
    );
    unpack32(x as uint32_t, &mut *a.offset(4 as ::core::ffi::c_int as isize));
}
#[inline]
unsafe extern "C" fn pack32(mut a: *const uint8_t) -> uint32_t {
    return ((*a.offset(0 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
        << 24 as ::core::ffi::c_int
        | (*a.offset(1 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
            << 16 as ::core::ffi::c_int
        | (*a.offset(2 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
            << 8 as ::core::ffi::c_int
        | *a.offset(3 as ::core::ffi::c_int as isize) as ::core::ffi::c_int) as uint32_t;
}
unsafe extern "C" fn to_hex(
    mut a: *const uint8_t,
    mut len: size_t,
    mut buf: *mut ::core::ffi::c_char,
) {
    let mut i: size_t = 0;
    i = 0 as size_t;
    while i < len {
        *buf.offset(i.wrapping_mul(2 as size_t) as isize) = ::core::mem::transmute::<
            [u8; 17],
            [::core::ffi::c_char; 17],
        >(
            *b"0123456789abcdef\0",
        )[(*a.offset(i as isize) as ::core::ffi::c_int >> 4 as ::core::ffi::c_int)
            as usize];
        *buf.offset(i.wrapping_mul(2 as size_t).wrapping_add(1 as size_t) as isize) = ::core::mem::transmute::<
            [u8; 17],
            [::core::ffi::c_char; 17],
        >(
            *b"0123456789abcdef\0",
        )[(*a.offset(i as isize) as ::core::ffi::c_int & 0xf as ::core::ffi::c_int)
            as usize];
        i = i.wrapping_add(1);
    }
    *buf.offset(len.wrapping_mul(2 as size_t) as isize) = '\0' as i32
        as ::core::ffi::c_char;
}
unsafe extern "C" fn test_pack() {
    let mut a: [uint8_t; 8] = [0; 8];
    unpack32(0x12345678 as uint32_t, a.as_mut_ptr());
    if !(a[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
        == 0x12 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_pack\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            26 as ::core::ffi::c_int,
            b"a[0] == 0x12\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(a[1 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
        == 0x34 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_pack\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            27 as ::core::ffi::c_int,
            b"a[1] == 0x34\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(a[2 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
        == 0x56 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_pack\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            28 as ::core::ffi::c_int,
            b"a[2] == 0x56\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(a[3 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
        == 0x78 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_pack\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            29 as ::core::ffi::c_int,
            b"a[3] == 0x78\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    unpack64(0x123456789abcdef0 as uint64_t, a.as_mut_ptr());
    if !(a[0 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
        == 0x12 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_pack\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            32 as ::core::ffi::c_int,
            b"a[0] == 0x12\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(a[1 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
        == 0x34 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_pack\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            33 as ::core::ffi::c_int,
            b"a[1] == 0x34\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(a[2 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
        == 0x56 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_pack\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            34 as ::core::ffi::c_int,
            b"a[2] == 0x56\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(a[3 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
        == 0x78 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_pack\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            35 as ::core::ffi::c_int,
            b"a[3] == 0x78\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(a[4 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
        == 0x9a as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_pack\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            36 as ::core::ffi::c_int,
            b"a[4] == 0x9A\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(a[5 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
        == 0xbc as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_pack\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            37 as ::core::ffi::c_int,
            b"a[5] == 0xBC\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(a[6 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
        == 0xde as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_pack\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            38 as ::core::ffi::c_int,
            b"a[6] == 0xDE\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(a[7 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
        == 0xf0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_pack\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            39 as ::core::ffi::c_int,
            b"a[7] == 0xF0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(pack32(a.as_mut_ptr() as *const uint8_t) == 0x12345678 as uint32_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_pack\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            41 as ::core::ffi::c_int,
            b"pack32(a) == 0x12345678\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
unsafe extern "C" fn test_sha1() {
    let mut buf: [uint8_t; 512] = [0; 512];
    let mut hash: [uint8_t; 20] = [0; 20];
    let mut str: [::core::ffi::c_char; 41] = [0; 41];
    buf[0 as ::core::ffi::c_int as usize] = 0 as uint8_t;
    sha1(
        buf.as_mut_ptr(),
        0 as size_t,
        ::core::mem::size_of::<[uint8_t; 512]>() as size_t,
        hash.as_mut_ptr(),
    );
    to_hex(hash.as_mut_ptr(), 20 as size_t, str.as_mut_ptr());
    if (strcmp(
        str.as_mut_ptr(),
        b"da39a3ee5e6b4b0d3255bfef95601890afd80709\0" as *const u8
            as *const ::core::ffi::c_char,
    ) != 0) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_sha1\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            54 as ::core::ffi::c_int,
            b"!strcmp(str, \"da39a3ee5e6b4b0d3255bfef95601890afd80709\")\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    snprintf(
        buf.as_mut_ptr() as *mut ::core::ffi::c_char,
        ::core::mem::size_of::<[uint8_t; 512]>() as size_t,
        b"%s\0" as *const u8 as *const ::core::ffi::c_char,
        b"abc\0" as *const u8 as *const ::core::ffi::c_char,
    );
    sha1(
        buf.as_mut_ptr(),
        strlen(buf.as_mut_ptr() as *mut ::core::ffi::c_char),
        ::core::mem::size_of::<[uint8_t; 512]>() as size_t,
        hash.as_mut_ptr(),
    );
    to_hex(hash.as_mut_ptr(), 20 as size_t, str.as_mut_ptr());
    if (strcmp(
        str.as_mut_ptr(),
        b"a9993e364706816aba3e25717850c26c9cd0d89d\0" as *const u8
            as *const ::core::ffi::c_char,
    ) != 0) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_sha1\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            60 as ::core::ffi::c_int,
            b"!strcmp(str, \"a9993e364706816aba3e25717850c26c9cd0d89d\")\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    snprintf(
        buf.as_mut_ptr() as *mut ::core::ffi::c_char,
        ::core::mem::size_of::<[uint8_t; 512]>() as size_t,
        b"%s\0" as *const u8 as *const ::core::ffi::c_char,
        b"The quick brown fox jumps over the lazy dog\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    sha1(
        buf.as_mut_ptr(),
        strlen(buf.as_mut_ptr() as *mut ::core::ffi::c_char),
        ::core::mem::size_of::<[uint8_t; 512]>() as size_t,
        hash.as_mut_ptr(),
    );
    to_hex(hash.as_mut_ptr(), 20 as size_t, str.as_mut_ptr());
    if (strcmp(
        str.as_mut_ptr(),
        b"2fd4e1c67a2d28fced849ee1bb76e7391b93eb12\0" as *const u8
            as *const ::core::ffi::c_char,
    ) != 0) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_sha1\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            67 as ::core::ffi::c_int,
            b"!strcmp(str, \"2fd4e1c67a2d28fced849ee1bb76e7391b93eb12\")\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
}
unsafe extern "C" fn test_hmac_sha1() {
    let mut key: [uint8_t; 64] = [0; 64];
    let mut text: [uint8_t; 64] = [0; 64];
    let mut hash: [uint8_t; 20] = [0; 20];
    let mut str: [::core::ffi::c_char; 41] = [0; 41];
    let mut i: size_t = 0;
    memset(
        key.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<[uint8_t; 64]>() as size_t,
    );
    memset(
        text.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<[uint8_t; 64]>() as size_t,
    );
    i = 0 as size_t;
    while i < 20 as size_t {
        key[i as usize] = 0xaa as uint8_t;
        i = i.wrapping_add(1);
    }
    i = 0 as size_t;
    while i < 50 as size_t {
        text[i as usize] = 0xdd as uint8_t;
        i = i.wrapping_add(1);
    }
    hmac_sha1(
        key.as_mut_ptr() as *const uint8_t,
        text.as_mut_ptr(),
        50 as size_t,
        hash.as_mut_ptr(),
    );
    to_hex(hash.as_mut_ptr(), 20 as size_t, str.as_mut_ptr());
    if (strcmp(
        str.as_mut_ptr(),
        b"125d7342b9ac11cd91a39af48aa17b4f63f175d3\0" as *const u8
            as *const ::core::ffi::c_char,
    ) != 0) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 15],
                [::core::ffi::c_char; 15],
            >(*b"test_hmac_sha1\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            86 as ::core::ffi::c_int,
            b"!strcmp(str, \"125d7342b9ac11cd91a39af48aa17b4f63f175d3\")\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
}
unsafe extern "C" fn test_hotp() {
    static mut secret: [uint8_t; 64] = [
        0x31 as ::core::ffi::c_int as uint8_t,
        0x32 as ::core::ffi::c_int as uint8_t,
        0x33 as ::core::ffi::c_int as uint8_t,
        0x34 as ::core::ffi::c_int as uint8_t,
        0x35 as ::core::ffi::c_int as uint8_t,
        0x36 as ::core::ffi::c_int as uint8_t,
        0x37 as ::core::ffi::c_int as uint8_t,
        0x38 as ::core::ffi::c_int as uint8_t,
        0x39 as ::core::ffi::c_int as uint8_t,
        0x30 as ::core::ffi::c_int as uint8_t,
        0x31 as ::core::ffi::c_int as uint8_t,
        0x32 as ::core::ffi::c_int as uint8_t,
        0x33 as ::core::ffi::c_int as uint8_t,
        0x34 as ::core::ffi::c_int as uint8_t,
        0x35 as ::core::ffi::c_int as uint8_t,
        0x36 as ::core::ffi::c_int as uint8_t,
        0x37 as ::core::ffi::c_int as uint8_t,
        0x38 as ::core::ffi::c_int as uint8_t,
        0x39 as ::core::ffi::c_int as uint8_t,
        0x30 as ::core::ffi::c_int as uint8_t,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
    ];
    if !(hotp(secret.as_ptr(), 0 as uint64_t) == 755224 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_hotp\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            98 as ::core::ffi::c_int,
            b"hotp(secret, 0) == 755224\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(hotp(secret.as_ptr(), 1 as uint64_t) == 287082 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_hotp\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            99 as ::core::ffi::c_int,
            b"hotp(secret, 1) == 287082\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(hotp(secret.as_ptr(), 2 as uint64_t) == 359152 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 10],
                [::core::ffi::c_char; 10],
            >(*b"test_hotp\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            100 as ::core::ffi::c_int,
            b"hotp(secret, 2) == 359152\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
unsafe extern "C" fn test_from_base32() {
    let mut buf: [uint8_t; 10] = [0; 10];
    if !(from_base32(
        b"MZxw6===\0" as *const u8 as *const ::core::ffi::c_char,
        buf.as_mut_ptr(),
        ::core::mem::size_of::<[uint8_t; 10]>() as size_t,
    ) == 3 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 17],
                [::core::ffi::c_char; 17],
            >(*b"test_from_base32\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            108 as ::core::ffi::c_int,
            b"from_base32(\"MZxw6===\", buf, sizeof(buf)) == 3\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(from_base32(
        b"MZxw6YQ=\0" as *const u8 as *const ::core::ffi::c_char,
        buf.as_mut_ptr(),
        ::core::mem::size_of::<[uint8_t; 10]>() as size_t,
    ) == 4 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 17],
                [::core::ffi::c_char; 17],
            >(*b"test_from_base32\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            109 as ::core::ffi::c_int,
            b"from_base32(\"MZxw6YQ=\", buf, sizeof(buf)) == 4\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(from_base32(
        b"MZxw6YTB\0" as *const u8 as *const ::core::ffi::c_char,
        buf.as_mut_ptr(),
        ::core::mem::size_of::<[uint8_t; 10]>() as size_t,
    ) == 5 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 17],
                [::core::ffi::c_char; 17],
            >(*b"test_from_base32\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            110 as ::core::ffi::c_int,
            b"from_base32(\"MZxw6YTB\", buf, sizeof(buf)) == 5\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(from_base32(
        b"MZxw6YTBOI======\0" as *const u8 as *const ::core::ffi::c_char,
        buf.as_mut_ptr(),
        ::core::mem::size_of::<[uint8_t; 10]>() as size_t,
    ) == 6 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 17],
                [::core::ffi::c_char; 17],
            >(*b"test_from_base32\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            111 as ::core::ffi::c_int,
            b"from_base32(\"MZxw6YTBOI======\", buf, sizeof(buf)) == 6\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if (strncmp(
        b"foobar\0" as *const u8 as *const ::core::ffi::c_char,
        buf.as_mut_ptr() as *mut ::core::ffi::c_char,
        6 as size_t,
    ) != 0) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 17],
                [::core::ffi::c_char; 17],
            >(*b"test_from_base32\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            113 as ::core::ffi::c_int,
            b"!strncmp(\"foobar\", (char *)buf, 6)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
}
unsafe fn main_0() -> ::core::ffi::c_int {
    test_pack();
    test_sha1();
    test_hmac_sha1();
    test_hotp();
    test_from_base32();
    printf(b"All tests passed.\n\0" as *const u8 as *const ::core::ffi::c_char);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
