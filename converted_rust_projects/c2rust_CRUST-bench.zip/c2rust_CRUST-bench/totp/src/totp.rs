#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type C2RustUnnamed = ::core::ffi::c_uint;
pub const TOTP_EBOUNDS: C2RustUnnamed = 1;
pub const TOTP_OK: C2RustUnnamed = 0;
pub const UINTPTR_MAX: ::core::ffi::c_ulong = 18446744073709551615
    as ::core::ffi::c_ulong;
pub const SIZE_MAX: ::core::ffi::c_ulong = UINTPTR_MAX;
#[inline]
unsafe extern "C" fn unpack32(mut x: uint32_t, mut a: *mut uint8_t) {
    *a.offset(0 as ::core::ffi::c_int as isize) = (x >> 24 as ::core::ffi::c_int)
        as uint8_t;
    *a.offset(1 as ::core::ffi::c_int as isize) = (x >> 16 as ::core::ffi::c_int)
        as uint8_t;
    *a.offset(2 as ::core::ffi::c_int as isize) = (x >> 8 as ::core::ffi::c_int)
        as uint8_t;
    *a.offset(3 as ::core::ffi::c_int as isize) = x as uint8_t;
}
#[inline]
unsafe extern "C" fn unpack64(mut x: uint64_t, mut a: *mut uint8_t) {
    unpack32(
        (x >> 32 as ::core::ffi::c_int) as uint32_t,
        &mut *a.offset(0 as ::core::ffi::c_int as isize),
    );
    unpack32(x as uint32_t, &mut *a.offset(4 as ::core::ffi::c_int as isize));
}
#[inline]
unsafe extern "C" fn pack32(mut a: *const uint8_t) -> uint32_t {
    return ((*a.offset(0 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
        << 24 as ::core::ffi::c_int
        | (*a.offset(1 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
            << 16 as ::core::ffi::c_int
        | (*a.offset(2 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
            << 8 as ::core::ffi::c_int
        | *a.offset(3 as ::core::ffi::c_int as isize) as ::core::ffi::c_int) as uint32_t;
}
#[inline]
unsafe extern "C" fn rotl(mut x: uint32_t, mut n: ::core::ffi::c_int) -> uint32_t {
    return x << n | x >> 32 as ::core::ffi::c_int - n;
}
#[no_mangle]
pub unsafe extern "C" fn sha1(
    mut buf: *mut uint8_t,
    mut len: size_t,
    mut cap: size_t,
    mut hash: *mut uint8_t,
) -> ::core::ffi::c_int {
    static mut k: [uint32_t; 4] = [
        0x5a827999 as ::core::ffi::c_int as uint32_t,
        0x6ed9eba1 as ::core::ffi::c_int as uint32_t,
        0x8f1bbcdc as ::core::ffi::c_uint,
        0xca62c1d6 as ::core::ffi::c_uint,
    ];
    let mut new_len: size_t = 0;
    let mut i: size_t = 0;
    let mut t: size_t = 0;
    let mut h: [uint32_t; 5] = [0; 5];
    let mut w: [uint32_t; 80] = [0; 80];
    let mut a: uint32_t = 0;
    let mut b: uint32_t = 0;
    let mut c: uint32_t = 0;
    let mut d: uint32_t = 0;
    let mut e: uint32_t = 0;
    let mut f: uint32_t = 0;
    let mut T: uint32_t = 0;
    if len > (SIZE_MAX as size_t).wrapping_sub(9 as size_t).wrapping_sub(63 as size_t) {
        return TOTP_EBOUNDS as ::core::ffi::c_int;
    }
    new_len = len
        .wrapping_add(9 as size_t)
        .wrapping_add(63 as size_t)
        .wrapping_div(64 as size_t)
        .wrapping_mul(64 as size_t);
    if new_len > cap {
        return TOTP_EBOUNDS as ::core::ffi::c_int;
    }
    memset(
        buf.offset(len as isize) as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        new_len.wrapping_sub(len),
    );
    *buf.offset(len as isize) = ((1 as ::core::ffi::c_int) << 7 as ::core::ffi::c_int)
        as uint8_t;
    unpack64(
        len.wrapping_mul(8 as size_t) as uint64_t,
        &mut *buf.offset(new_len.wrapping_sub(8 as size_t) as isize),
    );
    h[0 as ::core::ffi::c_int as usize] = 0x67452301 as uint32_t;
    h[1 as ::core::ffi::c_int as usize] = 0xefcdab89 as ::core::ffi::c_uint as uint32_t;
    h[2 as ::core::ffi::c_int as usize] = 0x98badcfe as ::core::ffi::c_uint as uint32_t;
    h[3 as ::core::ffi::c_int as usize] = 0x10325476 as uint32_t;
    h[4 as ::core::ffi::c_int as usize] = 0xc3d2e1f0 as ::core::ffi::c_uint as uint32_t;
    i = 0 as size_t;
    while i < new_len.wrapping_div(64 as size_t) {
        t = 0 as size_t;
        while t < 16 as size_t {
            w[t as usize] = pack32(
                &mut *buf
                    .offset(
                        i
                            .wrapping_mul(64 as size_t)
                            .wrapping_add(t.wrapping_mul(4 as size_t)) as isize,
                    ) as *mut uint8_t as *const uint8_t,
            );
            t = t.wrapping_add(1);
        }
        while t < 80 as size_t {
            w[t as usize] = rotl(
                w[t.wrapping_sub(3 as size_t) as usize]
                    ^ w[t.wrapping_sub(8 as size_t) as usize]
                    ^ w[t.wrapping_sub(14 as size_t) as usize]
                    ^ w[t.wrapping_sub(16 as size_t) as usize],
                1 as ::core::ffi::c_int,
            );
            t = t.wrapping_add(1);
        }
        a = h[0 as ::core::ffi::c_int as usize];
        b = h[1 as ::core::ffi::c_int as usize];
        c = h[2 as ::core::ffi::c_int as usize];
        d = h[3 as ::core::ffi::c_int as usize];
        e = h[4 as ::core::ffi::c_int as usize];
        t = 0 as size_t;
        while t < 80 as size_t {
            f = if t < 20 as size_t {
                b & c ^ !b & d
            } else if t < 40 as size_t {
                b ^ c ^ d
            } else if t < 60 as size_t {
                b & c ^ b & d ^ c & d
            } else {
                b ^ c ^ d
            };
            T = rotl(a, 5 as ::core::ffi::c_int)
                .wrapping_add(f)
                .wrapping_add(e)
                .wrapping_add(k[t.wrapping_div(20 as size_t) as usize])
                .wrapping_add(w[t as usize]);
            e = d;
            d = c;
            c = rotl(b, 30 as ::core::ffi::c_int);
            b = a;
            a = T;
            t = t.wrapping_add(1);
        }
        h[0 as ::core::ffi::c_int as usize] = h[0 as ::core::ffi::c_int as usize]
            .wrapping_add(a);
        h[1 as ::core::ffi::c_int as usize] = h[1 as ::core::ffi::c_int as usize]
            .wrapping_add(b);
        h[2 as ::core::ffi::c_int as usize] = h[2 as ::core::ffi::c_int as usize]
            .wrapping_add(c);
        h[3 as ::core::ffi::c_int as usize] = h[3 as ::core::ffi::c_int as usize]
            .wrapping_add(d);
        h[4 as ::core::ffi::c_int as usize] = h[4 as ::core::ffi::c_int as usize]
            .wrapping_add(e);
        i = i.wrapping_add(1);
    }
    i = 0 as size_t;
    while i < 5 as size_t {
        unpack32(h[i as usize], &mut *hash.offset(i.wrapping_mul(4 as size_t) as isize));
        i = i.wrapping_add(1);
    }
    return TOTP_OK as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn hmac_sha1(
    mut key: *const uint8_t,
    mut data: *const uint8_t,
    mut len: size_t,
    mut hash: *mut uint8_t,
) -> ::core::ffi::c_int {
    let mut buf: [uint8_t; 196] = [0; 196];
    let mut i: size_t = 0;
    if len > 64 as size_t {
        return TOTP_EBOUNDS as ::core::ffi::c_int;
    }
    i = 0 as size_t;
    while i < 64 as size_t {
        buf[i as usize] = (*key.offset(i as isize) as ::core::ffi::c_int
            ^ 0x36 as ::core::ffi::c_int) as uint8_t;
        i = i.wrapping_add(1);
    }
    memcpy(
        &mut *buf.as_mut_ptr().offset(64 as ::core::ffi::c_int as isize) as *mut uint8_t
            as *mut ::core::ffi::c_void,
        data as *const ::core::ffi::c_void,
        len,
    );
    sha1(
        buf.as_mut_ptr(),
        (64 as size_t).wrapping_add(len),
        ::core::mem::size_of::<[uint8_t; 196]>() as size_t,
        hash,
    );
    i = 0 as size_t;
    while i < 64 as size_t {
        buf[i as usize] = (*key.offset(i as isize) as ::core::ffi::c_int
            ^ 0x5c as ::core::ffi::c_int) as uint8_t;
        i = i.wrapping_add(1);
    }
    memcpy(
        &mut *buf.as_mut_ptr().offset(64 as ::core::ffi::c_int as isize) as *mut uint8_t
            as *mut ::core::ffi::c_void,
        hash as *const ::core::ffi::c_void,
        20 as size_t,
    );
    sha1(
        buf.as_mut_ptr(),
        (64 as ::core::ffi::c_int + 20 as ::core::ffi::c_int) as size_t,
        ::core::mem::size_of::<[uint8_t; 196]>() as size_t,
        hash,
    );
    return TOTP_OK as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn hotp(
    mut key: *const uint8_t,
    mut counter: uint64_t,
) -> ::core::ffi::c_int {
    let mut data: [uint8_t; 8] = [0; 8];
    let mut hash: [uint8_t; 20] = [0; 20];
    let mut trunc: uint32_t = 0;
    unpack64(counter, data.as_mut_ptr());
    hmac_sha1(key, data.as_mut_ptr(), 8 as size_t, hash.as_mut_ptr());
    trunc = pack32(
        &mut *hash
            .as_mut_ptr()
            .offset(
                (*hash.as_mut_ptr().offset(19 as ::core::ffi::c_int as isize)
                    as ::core::ffi::c_int & 0xf as ::core::ffi::c_int) as isize,
            ) as *mut uint8_t as *const uint8_t,
    ) & 0x7fffffff as uint32_t;
    return trunc.wrapping_rem(1000000 as uint32_t) as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn totp(
    mut key: *const uint8_t,
    mut time: uint64_t,
) -> ::core::ffi::c_int {
    return hotp(key, time.wrapping_div(30 as uint64_t));
}
#[no_mangle]
pub unsafe extern "C" fn from_base32(
    mut s: *const ::core::ffi::c_char,
    mut buf: *mut uint8_t,
    mut cap: size_t,
) -> size_t {
    let mut i: size_t = 0;
    let mut j: size_t = 0;
    let mut v: [uint8_t; 8] = [0; 8];
    let mut c: ::core::ffi::c_char = 0;
    if strlen(s).wrapping_rem(8 as size_t) != 0 {
        return 0 as size_t;
    }
    if cap
        < strlen(s)
            .wrapping_add(1 as size_t)
            .wrapping_div(8 as size_t)
            .wrapping_mul(5 as size_t)
    {
        return 0 as size_t;
    }
    i = 0 as size_t;
    while *s.offset(i.wrapping_mul(8 as size_t) as isize) != 0 {
        j = 0 as size_t;
        while j < 8 as size_t {
            c = *s.offset(i.wrapping_mul(8 as size_t).wrapping_add(j) as isize);
            if c as ::core::ffi::c_int == '=' as i32 {
                v[j as usize] = 0 as uint8_t;
            } else if c as ::core::ffi::c_int >= 'A' as i32
                && c as ::core::ffi::c_int <= 'Z' as i32
            {
                v[j as usize] = (c as ::core::ffi::c_int - 'A' as i32) as uint8_t;
            } else if c as ::core::ffi::c_int >= 'a' as i32
                && c as ::core::ffi::c_int <= 'z' as i32
            {
                v[j as usize] = (c as ::core::ffi::c_int - 'a' as i32) as uint8_t;
            } else if c as ::core::ffi::c_int >= '2' as i32
                && c as ::core::ffi::c_int <= '7' as i32
            {
                v[j as usize] = (c as ::core::ffi::c_int - '2' as i32
                    + 26 as ::core::ffi::c_int) as uint8_t;
            } else {
                return 0 as size_t
            }
            j = j.wrapping_add(1);
        }
        *buf.offset(i.wrapping_mul(5 as size_t) as isize) = ((v[0 as ::core::ffi::c_int
            as usize] as ::core::ffi::c_int) << 3 as ::core::ffi::c_int
            | v[1 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
                >> 2 as ::core::ffi::c_int) as uint8_t;
        *buf.offset(i.wrapping_mul(5 as size_t).wrapping_add(1 as size_t) as isize) = ((v[1
            as ::core::ffi::c_int as usize] as ::core::ffi::c_int)
            << 6 as ::core::ffi::c_int
            | (v[2 as ::core::ffi::c_int as usize] as ::core::ffi::c_int)
                << 1 as ::core::ffi::c_int
            | v[3 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
                >> 4 as ::core::ffi::c_int) as uint8_t;
        *buf.offset(i.wrapping_mul(5 as size_t).wrapping_add(2 as size_t) as isize) = ((v[3
            as ::core::ffi::c_int as usize] as ::core::ffi::c_int)
            << 4 as ::core::ffi::c_int
            | v[4 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
                >> 1 as ::core::ffi::c_int) as uint8_t;
        *buf.offset(i.wrapping_mul(5 as size_t).wrapping_add(3 as size_t) as isize) = ((v[4
            as ::core::ffi::c_int as usize] as ::core::ffi::c_int)
            << 7 as ::core::ffi::c_int
            | (v[5 as ::core::ffi::c_int as usize] as ::core::ffi::c_int)
                << 2 as ::core::ffi::c_int
            | v[6 as ::core::ffi::c_int as usize] as ::core::ffi::c_int
                >> 3 as ::core::ffi::c_int) as uint8_t;
        *buf.offset(i.wrapping_mul(5 as size_t).wrapping_add(4 as size_t) as isize) = ((v[6
            as ::core::ffi::c_int as usize] as ::core::ffi::c_int)
            << 5 as ::core::ffi::c_int
            | v[7 as ::core::ffi::c_int as usize] as ::core::ffi::c_int) as uint8_t;
        if *s.offset(i.wrapping_mul(8 as size_t).wrapping_add(2 as size_t) as isize)
            as ::core::ffi::c_int == '=' as i32
        {
            return i.wrapping_mul(5 as size_t).wrapping_add(1 as size_t);
        }
        if *s.offset(i.wrapping_mul(8 as size_t).wrapping_add(4 as size_t) as isize)
            as ::core::ffi::c_int == '=' as i32
        {
            return i.wrapping_mul(5 as size_t).wrapping_add(2 as size_t);
        }
        if *s.offset(i.wrapping_mul(8 as size_t).wrapping_add(5 as size_t) as isize)
            as ::core::ffi::c_int == '=' as i32
        {
            return i.wrapping_mul(5 as size_t).wrapping_add(3 as size_t);
        }
        if *s.offset(i.wrapping_mul(8 as size_t).wrapping_add(7 as size_t) as isize)
            as ::core::ffi::c_int == '=' as i32
        {
            return i.wrapping_mul(5 as size_t).wrapping_add(4 as size_t);
        }
        i = i.wrapping_add(1);
    }
    return i.wrapping_mul(5 as size_t);
}
