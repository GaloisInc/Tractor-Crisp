#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
pub type uint32_t = u32;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct utf8_validity {
    pub valid: bool,
    pub valid_upto: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct utf8_string {
    pub str_0: *const ::core::ffi::c_char,
    pub byte_len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct owned_utf8_string {
    pub str_0: *mut ::core::ffi::c_char,
    pub byte_len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct utf8_char_iter {
    pub str_0: *const ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct utf8_char {
    pub str_0: *const ::core::ffi::c_char,
    pub byte_len: uint8_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct utf8_char_validity {
    pub valid: bool,
    pub next_offset: size_t,
}
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn validate_utf8_char(
    mut str: *const ::core::ffi::c_char,
    mut offset: size_t,
) -> utf8_char_validity {
    if *str.offset(offset as isize) as uint8_t as ::core::ffi::c_int
        & 0o200 as ::core::ffi::c_int == 0 as ::core::ffi::c_int
    {
        return {
            let mut init = utf8_char_validity {
                valid: true_0 != 0,
                next_offset: offset.wrapping_add(1 as size_t),
            };
            init
        };
    }
    if *str.offset(offset.wrapping_add(0 as size_t) as isize) as uint8_t
        as ::core::ffi::c_int & 0o340 as ::core::ffi::c_int
        == 0o300 as ::core::ffi::c_int
        && *str.offset(offset.wrapping_add(1 as size_t) as isize) as uint8_t
            as ::core::ffi::c_int & 0o300 as ::core::ffi::c_int
            == 0o200 as ::core::ffi::c_int
    {
        if (*str.offset(offset as isize) as uint8_t as ::core::ffi::c_int
            & 0o37 as ::core::ffi::c_int) < 0o2 as ::core::ffi::c_int
        {
            return {
                let mut init = utf8_char_validity {
                    valid: false_0 != 0,
                    next_offset: offset,
                };
                init
            };
        }
        return {
            let mut init = utf8_char_validity {
                valid: true_0 != 0,
                next_offset: offset.wrapping_add(2 as size_t),
            };
            init
        };
    }
    if *str.offset(offset.wrapping_add(0 as size_t) as isize) as uint8_t
        as ::core::ffi::c_int & 0o360 as ::core::ffi::c_int
        == 0o340 as ::core::ffi::c_int
        && *str.offset(offset.wrapping_add(1 as size_t) as isize) as uint8_t
            as ::core::ffi::c_int & 0o300 as ::core::ffi::c_int
            == 0o200 as ::core::ffi::c_int
        && *str.offset(offset.wrapping_add(2 as size_t) as isize) as uint8_t
            as ::core::ffi::c_int & 0o300 as ::core::ffi::c_int
            == 0o200 as ::core::ffi::c_int
    {
        if *str.offset(offset.wrapping_add(0 as size_t) as isize) as uint8_t
            as ::core::ffi::c_int & 0o17 as ::core::ffi::c_int == 0 as ::core::ffi::c_int
            && (*str.offset(offset.wrapping_add(1 as size_t) as isize) as uint8_t
                as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int)
                < 0o40 as ::core::ffi::c_int
        {
            return {
                let mut init = utf8_char_validity {
                    valid: false_0 != 0,
                    next_offset: offset,
                };
                init
            };
        }
        if *str.offset(offset.wrapping_add(0 as size_t) as isize) as uint8_t
            as ::core::ffi::c_int == 0o355 as ::core::ffi::c_int
            && *str.offset(offset.wrapping_add(1 as size_t) as isize) as uint8_t
                as ::core::ffi::c_int >= 0o240 as ::core::ffi::c_int
            && *str.offset(offset.wrapping_add(1 as size_t) as isize) as uint8_t
                as ::core::ffi::c_int <= 0o277 as ::core::ffi::c_int
        {
            return {
                let mut init = utf8_char_validity {
                    valid: false_0 != 0,
                    next_offset: offset,
                };
                init
            };
        }
        return {
            let mut init = utf8_char_validity {
                valid: true_0 != 0,
                next_offset: offset.wrapping_add(3 as size_t),
            };
            init
        };
    }
    if *str.offset(offset.wrapping_add(0 as size_t) as isize) as uint8_t
        as ::core::ffi::c_int & 0o370 as ::core::ffi::c_int
        == 0o360 as ::core::ffi::c_int
        && *str.offset(offset.wrapping_add(1 as size_t) as isize) as uint8_t
            as ::core::ffi::c_int & 0o300 as ::core::ffi::c_int
            == 0o200 as ::core::ffi::c_int
        && *str.offset(offset.wrapping_add(2 as size_t) as isize) as uint8_t
            as ::core::ffi::c_int & 0o300 as ::core::ffi::c_int
            == 0o200 as ::core::ffi::c_int
        && *str.offset(offset.wrapping_add(3 as size_t) as isize) as uint8_t
            as ::core::ffi::c_int & 0o300 as ::core::ffi::c_int
            == 0o200 as ::core::ffi::c_int
    {
        if *str.offset(offset.wrapping_add(0 as size_t) as isize) as uint8_t
            as ::core::ffi::c_int & 0o7 as ::core::ffi::c_int == 0 as ::core::ffi::c_int
            && (*str.offset(offset.wrapping_add(1 as size_t) as isize) as uint8_t
                as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int)
                < 0o20 as ::core::ffi::c_int
        {
            return {
                let mut init = utf8_char_validity {
                    valid: false_0 != 0,
                    next_offset: offset,
                };
                init
            };
        }
        return {
            let mut init = utf8_char_validity {
                valid: true_0 != 0,
                next_offset: offset.wrapping_add(4 as size_t),
            };
            init
        };
    }
    return {
        let mut init = utf8_char_validity {
            valid: false_0 != 0,
            next_offset: offset,
        };
        init
    };
}
#[no_mangle]
pub unsafe extern "C" fn validate_utf8(
    mut str: *const ::core::ffi::c_char,
) -> utf8_validity {
    if str.is_null() {
        return {
            let mut init = utf8_validity {
                valid: false_0 != 0,
                valid_upto: 0 as size_t,
            };
            init
        };
    }
    let mut offset: size_t = 0 as size_t;
    let mut char_validity: utf8_char_validity = utf8_char_validity {
        valid: false,
        next_offset: 0,
    };
    while *str.offset(offset as isize) as ::core::ffi::c_int != '\0' as i32 {
        char_validity = validate_utf8_char(str, offset);
        if char_validity.valid {
            offset = char_validity.next_offset;
        } else {
            return {
                let mut init = utf8_validity {
                    valid: false_0 != 0,
                    valid_upto: offset,
                };
                init
            }
        }
    }
    return {
        let mut init = utf8_validity {
            valid: true_0 != 0,
            valid_upto: offset,
        };
        init
    };
}
#[no_mangle]
pub unsafe extern "C" fn make_utf8_string(
    mut str: *const ::core::ffi::c_char,
) -> utf8_string {
    let mut validity: utf8_validity = validate_utf8(str);
    if validity.valid {
        return {
            let mut init = utf8_string {
                str_0: str,
                byte_len: validity.valid_upto,
            };
            init
        };
    }
    return {
        let mut init = utf8_string {
            str_0: 0 as *const ::core::ffi::c_char,
            byte_len: 0 as size_t,
        };
        init
    };
}
#[no_mangle]
pub unsafe extern "C" fn make_utf8_string_lossy(
    mut str: *const ::core::ffi::c_char,
) -> owned_utf8_string {
    if str.is_null() {
        return {
            let mut init = owned_utf8_string {
                str_0: 0 as *mut ::core::ffi::c_char,
                byte_len: 0 as size_t,
            };
            init
        };
    }
    let mut len: size_t = strlen(str);
    let mut worst_case_size: size_t = len
        .wrapping_mul(3 as size_t)
        .wrapping_add(1 as size_t);
    let mut buffer: *mut ::core::ffi::c_char = malloc(worst_case_size)
        as *mut ::core::ffi::c_char;
    if buffer.is_null() {
        return {
            let mut init = owned_utf8_string {
                str_0: 0 as *mut ::core::ffi::c_char,
                byte_len: 0 as size_t,
            };
            init
        };
    }
    let mut buffer_offset: size_t = 0 as size_t;
    let mut offset: size_t = 0 as size_t;
    let mut char_validity: utf8_char_validity = utf8_char_validity {
        valid: false,
        next_offset: 0,
    };
    while offset < len {
        char_validity = validate_utf8_char(str, offset);
        if char_validity.valid {
            let mut char_len: size_t = char_validity.next_offset.wrapping_sub(offset);
            memcpy(
                buffer.offset(buffer_offset as isize) as *mut ::core::ffi::c_void,
                str.offset(offset as isize) as *const ::core::ffi::c_void,
                char_len,
            );
            buffer_offset = buffer_offset.wrapping_add(char_len);
            offset = char_validity.next_offset;
        } else {
            let fresh0 = buffer_offset;
            buffer_offset = buffer_offset.wrapping_add(1);
            *buffer.offset(fresh0 as isize) = 0xef as ::core::ffi::c_char;
            let fresh1 = buffer_offset;
            buffer_offset = buffer_offset.wrapping_add(1);
            *buffer.offset(fresh1 as isize) = 0xbf as ::core::ffi::c_char;
            let fresh2 = buffer_offset;
            buffer_offset = buffer_offset.wrapping_add(1);
            *buffer.offset(fresh2 as isize) = 0xbd as ::core::ffi::c_char;
            offset = offset.wrapping_add(1);
        }
    }
    *buffer.offset(buffer_offset as isize) = '\0' as i32 as ::core::ffi::c_char;
    return {
        let mut init = owned_utf8_string {
            str_0: buffer,
            byte_len: buffer_offset,
        };
        init
    };
}
#[no_mangle]
pub unsafe extern "C" fn as_utf8_string(
    mut owned_str: *const owned_utf8_string,
) -> utf8_string {
    return {
        let mut init = utf8_string {
            str_0: (*owned_str).str_0,
            byte_len: (*owned_str).byte_len,
        };
        init
    };
}
#[no_mangle]
pub unsafe extern "C" fn free_owned_utf8_string(mut owned_str: *mut owned_utf8_string) {
    if !(*owned_str).str_0.is_null() {
        free((*owned_str).str_0 as *mut ::core::ffi::c_void);
        (*owned_str).str_0 = 0 as *mut ::core::ffi::c_char;
        (*owned_str).byte_len = 0 as size_t;
    }
}
#[no_mangle]
pub unsafe extern "C" fn make_utf8_char_iter(mut ustr: utf8_string) -> utf8_char_iter {
    return {
        let mut init = utf8_char_iter {
            str_0: ustr.str_0,
        };
        init
    };
}
#[no_mangle]
pub unsafe extern "C" fn is_utf8_char_boundary(
    mut str: *const ::core::ffi::c_char,
) -> bool {
    return *str as uint8_t as ::core::ffi::c_int <= 0o177 as ::core::ffi::c_int
        || *str as uint8_t as ::core::ffi::c_int >= 0o300 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn slice_utf8_string(
    mut ustr: utf8_string,
    mut start_byte_index: size_t,
    mut byte_len: size_t,
) -> utf8_string {
    if start_byte_index > ustr.byte_len {
        start_byte_index = ustr.byte_len;
    }
    let mut excl_end_byte_index: size_t = start_byte_index.wrapping_add(byte_len);
    if excl_end_byte_index > ustr.byte_len {
        excl_end_byte_index = ustr.byte_len;
    }
    if is_utf8_char_boundary(ustr.str_0.offset(start_byte_index as isize))
        as ::core::ffi::c_int != 0
        && is_utf8_char_boundary(ustr.str_0.offset(excl_end_byte_index as isize))
            as ::core::ffi::c_int != 0
    {
        return {
            let mut init = utf8_string {
                str_0: ustr.str_0.offset(start_byte_index as isize),
                byte_len: excl_end_byte_index.wrapping_sub(start_byte_index),
            };
            init
        };
    }
    return {
        let mut init = utf8_string {
            str_0: 0 as *const ::core::ffi::c_char,
            byte_len: 0 as size_t,
        };
        init
    };
}
#[no_mangle]
pub unsafe extern "C" fn next_utf8_char(mut iter: *mut utf8_char_iter) -> utf8_char {
    if *(*iter).str_0 as ::core::ffi::c_int == '\0' as i32 {
        return {
            let mut init = utf8_char {
                str_0: (*iter).str_0,
                byte_len: 0 as uint8_t,
            };
            init
        };
    }
    let mut curr_boundary: *const ::core::ffi::c_char = (*iter).str_0;
    (*iter).str_0 = (*iter).str_0.offset(1);
    let mut byte_len: uint8_t = 1 as uint8_t;
    while !is_utf8_char_boundary((*iter).str_0) {
        (*iter).str_0 = (*iter).str_0.offset(1);
        byte_len = byte_len.wrapping_add(1);
    }
    return {
        let mut init = utf8_char {
            str_0: curr_boundary,
            byte_len: byte_len,
        };
        init
    };
}
#[no_mangle]
pub unsafe extern "C" fn nth_utf8_char(
    mut ustr: utf8_string,
    mut char_index: size_t,
) -> utf8_char {
    let mut iter: utf8_char_iter = make_utf8_char_iter(ustr);
    let mut ch: utf8_char = utf8_char {
        str_0: 0 as *const ::core::ffi::c_char,
        byte_len: 0,
    };
    loop {
        ch = next_utf8_char(&mut iter);
        if !(ch.byte_len as ::core::ffi::c_int != 0 as ::core::ffi::c_int
            && {
                let fresh3 = char_index;
                char_index = char_index.wrapping_sub(1);
                fresh3 != 0 as size_t
            })
        {
            break;
        }
    }
    if ch.byte_len as ::core::ffi::c_int == 0 as ::core::ffi::c_int {
        return {
            let mut init = utf8_char {
                str_0: 0 as *const ::core::ffi::c_char,
                byte_len: 0 as uint8_t,
            };
            init
        };
    }
    return ch;
}
#[no_mangle]
pub unsafe extern "C" fn utf8_char_count(mut ustr: utf8_string) -> size_t {
    let mut iter: utf8_char_iter = make_utf8_char_iter(ustr);
    let mut count: size_t = 0 as size_t;
    while next_utf8_char(&mut iter).byte_len as ::core::ffi::c_int
        > 0 as ::core::ffi::c_int
    {
        count = count.wrapping_add(1);
    }
    return count;
}
#[no_mangle]
pub unsafe extern "C" fn unicode_code_point(mut uchar: utf8_char) -> uint32_t {
    match uchar.byte_len as ::core::ffi::c_int {
        1 => {
            return (*uchar.str_0.offset(0 as ::core::ffi::c_int as isize)
                as ::core::ffi::c_int & 0o177 as ::core::ffi::c_int) as uint32_t;
        }
        2 => {
            return ((*uchar.str_0.offset(0 as ::core::ffi::c_int as isize)
                as ::core::ffi::c_int & 0o37 as ::core::ffi::c_int)
                << 6 as ::core::ffi::c_int
                | *uchar.str_0.offset(1 as ::core::ffi::c_int as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int) as uint32_t;
        }
        3 => {
            return ((*uchar.str_0.offset(0 as ::core::ffi::c_int as isize)
                as ::core::ffi::c_int & 0o17 as ::core::ffi::c_int)
                << 12 as ::core::ffi::c_int
                | (*uchar.str_0.offset(1 as ::core::ffi::c_int as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int)
                    << 6 as ::core::ffi::c_int
                | *uchar.str_0.offset(2 as ::core::ffi::c_int as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int) as uint32_t;
        }
        4 => {
            return ((*uchar.str_0.offset(0 as ::core::ffi::c_int as isize)
                as ::core::ffi::c_int & 0o7 as ::core::ffi::c_int)
                << 18 as ::core::ffi::c_int
                | (*uchar.str_0.offset(1 as ::core::ffi::c_int as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int)
                    << 12 as ::core::ffi::c_int
                | (*uchar.str_0.offset(2 as ::core::ffi::c_int as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int)
                    << 6 as ::core::ffi::c_int
                | *uchar.str_0.offset(3 as ::core::ffi::c_int as isize)
                    as ::core::ffi::c_int & 0o77 as ::core::ffi::c_int) as uint32_t;
        }
        _ => {}
    }
    return 0 as uint32_t;
}
