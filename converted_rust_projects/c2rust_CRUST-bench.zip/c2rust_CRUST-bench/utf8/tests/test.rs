#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn validate_utf8(str: *const ::core::ffi::c_char) -> utf8_validity;
    fn make_utf8_string(str: *const ::core::ffi::c_char) -> utf8_string;
    fn make_utf8_string_lossy(str: *const ::core::ffi::c_char) -> owned_utf8_string;
    fn free_owned_utf8_string(owned_str: *mut owned_utf8_string);
    fn slice_utf8_string(
        ustr: utf8_string,
        byte_index: size_t,
        byte_len: size_t,
    ) -> utf8_string;
    fn make_utf8_char_iter(ustr: utf8_string) -> utf8_char_iter;
    fn next_utf8_char(iter: *mut utf8_char_iter) -> utf8_char;
    fn nth_utf8_char(ustr: utf8_string, char_index: size_t) -> utf8_char;
    fn utf8_char_count(ustr: utf8_string) -> size_t;
    fn is_utf8_char_boundary(str: *const ::core::ffi::c_char) -> bool;
    fn unicode_code_point(uchar: utf8_char) -> uint32_t;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strncmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> ::core::ffi::c_int;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint8_t = u8;
pub type uint32_t = u32;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct utf8_validity {
    pub valid: bool,
    pub valid_upto: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct utf8_string {
    pub str_0: *const ::core::ffi::c_char,
    pub byte_len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct owned_utf8_string {
    pub str_0: *mut ::core::ffi::c_char,
    pub byte_len: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct utf8_char_iter {
    pub str_0: *const ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct utf8_char {
    pub str_0: *const ::core::ffi::c_char,
    pub byte_len: uint8_t,
}
#[no_mangle]
pub unsafe extern "C" fn test_validate_utf8_ok() {
    let mut validity: utf8_validity = validate_utf8(
        b"Hello \xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    if !(validity.valid as ::core::ffi::c_int == 1 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_validate_utf8_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            14 as ::core::ffi::c_int,
            b"validity.valid == true\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(validity.valid_upto
        == (5 as ::core::ffi::c_int + 1 as ::core::ffi::c_int
            + 12 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
            + 1 as ::core::ffi::c_int + 5 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
            + 1 as ::core::ffi::c_int
            + 2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int) as size_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_validate_utf8_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            15 as ::core::ffi::c_int,
            b"validity.valid_upto == 5 + 1 + 12 * 2 + 1 + 5 * 3 + 1 + 2 * 4\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_validate_utf8_boundary_ok() {
    let mut validity: utf8_validity = utf8_validity {
        valid: false,
        valid_upto: 0,
    };
    validity = validate_utf8(b"\x7F\0" as *const u8 as *const ::core::ffi::c_char);
    if !validity.valid as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_validate_utf8_boundary_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            23 as ::core::ffi::c_int,
            b"validity.valid\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(validity.valid_upto == 1 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_validate_utf8_boundary_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            24 as ::core::ffi::c_int,
            b"validity.valid_upto == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    validity = validate_utf8(b"\xC2\x80\0" as *const u8 as *const ::core::ffi::c_char);
    if !validity.valid as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_validate_utf8_boundary_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            28 as ::core::ffi::c_int,
            b"validity.valid\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(validity.valid_upto == 2 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_validate_utf8_boundary_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            29 as ::core::ffi::c_int,
            b"validity.valid_upto == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    validity = validate_utf8(b"\xDF\xBF\0" as *const u8 as *const ::core::ffi::c_char);
    if !validity.valid as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_validate_utf8_boundary_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            33 as ::core::ffi::c_int,
            b"validity.valid\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(validity.valid_upto == 2 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_validate_utf8_boundary_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            34 as ::core::ffi::c_int,
            b"validity.valid_upto == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    validity = validate_utf8(
        b"\xE0\xA0\x80\0" as *const u8 as *const ::core::ffi::c_char,
    );
    if !validity.valid as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_validate_utf8_boundary_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            38 as ::core::ffi::c_int,
            b"validity.valid\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(validity.valid_upto == 3 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_validate_utf8_boundary_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            39 as ::core::ffi::c_int,
            b"validity.valid_upto == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    validity = validate_utf8(
        b"\xEF\xBF\xBF\0" as *const u8 as *const ::core::ffi::c_char,
    );
    if !validity.valid as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_validate_utf8_boundary_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            43 as ::core::ffi::c_int,
            b"validity.valid\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(validity.valid_upto == 3 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_validate_utf8_boundary_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            44 as ::core::ffi::c_int,
            b"validity.valid_upto == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    validity = validate_utf8(
        b"\xF0\x90\x80\x80\0" as *const u8 as *const ::core::ffi::c_char,
    );
    if !validity.valid as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_validate_utf8_boundary_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            48 as ::core::ffi::c_int,
            b"validity.valid\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(validity.valid_upto == 4 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_validate_utf8_boundary_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            49 as ::core::ffi::c_int,
            b"validity.valid_upto == 4\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    validity = validate_utf8(
        b"\xF7\xBF\xBF\xBF\0" as *const u8 as *const ::core::ffi::c_char,
    );
    if !validity.valid as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_validate_utf8_boundary_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            53 as ::core::ffi::c_int,
            b"validity.valid\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(validity.valid_upto == 4 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_validate_utf8_boundary_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            54 as ::core::ffi::c_int,
            b"validity.valid_upto == 4\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_surrogate_rejection() {
    let mut validity: utf8_validity = utf8_validity {
        valid: false,
        valid_upto: 0,
    };
    validity = validate_utf8(
        b"\xED\xA0\x80\0" as *const u8 as *const ::core::ffi::c_char,
    );
    if !(validity.valid as ::core::ffi::c_int == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_surrogate_rejection\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            61 as ::core::ffi::c_int,
            b"validity.valid == false\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(validity.valid_upto == 0 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_surrogate_rejection\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            62 as ::core::ffi::c_int,
            b"validity.valid_upto == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    validity = validate_utf8(
        b"\xED\xAC\x80\0" as *const u8 as *const ::core::ffi::c_char,
    );
    if !(validity.valid as ::core::ffi::c_int == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_surrogate_rejection\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            65 as ::core::ffi::c_int,
            b"validity.valid == false\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(validity.valid_upto == 0 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_surrogate_rejection\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            66 as ::core::ffi::c_int,
            b"validity.valid_upto == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    validity = validate_utf8(
        b"\xED\xA0\x8C\0" as *const u8 as *const ::core::ffi::c_char,
    );
    if !(validity.valid as ::core::ffi::c_int == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_surrogate_rejection\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            69 as ::core::ffi::c_int,
            b"validity.valid == false\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(validity.valid_upto == 0 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_surrogate_rejection\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            70 as ::core::ffi::c_int,
            b"validity.valid_upto == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    validity = validate_utf8(
        b"\xED\xBF\xBF\0" as *const u8 as *const ::core::ffi::c_char,
    );
    if !(validity.valid as ::core::ffi::c_int == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_surrogate_rejection\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            73 as ::core::ffi::c_int,
            b"validity.valid == false\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(validity.valid_upto == 0 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_surrogate_rejection\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            74 as ::core::ffi::c_int,
            b"validity.valid_upto == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_validate_utf8_err() {
    let mut validity: utf8_validity = validate_utf8(
        b"Hello \xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5\xC0\xC0 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    if !(validity.valid as ::core::ffi::c_int == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_validate_utf8_err\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            79 as ::core::ffi::c_int,
            b"validity.valid == false\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(validity.valid_upto
        == (5 as ::core::ffi::c_int + 1 as ::core::ffi::c_int
            + 12 as ::core::ffi::c_int * 2 as ::core::ffi::c_int) as size_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_validate_utf8_err\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            80 as ::core::ffi::c_int,
            b"validity.valid_upto == 5 + 1 + 12 * 2\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn assert_overlong_encodings(
    mut actual: utf8_char,
    mut overlong: utf8_char,
) {
    if !(unicode_code_point(actual) == unicode_code_point(overlong))
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 26],
                [::core::ffi::c_char; 26],
            >(*b"assert_overlong_encodings\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            84 as ::core::ffi::c_int,
            b"unicode_code_point(actual) == unicode_code_point(overlong)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut validity: utf8_validity = utf8_validity {
        valid: false,
        valid_upto: 0,
    };
    validity = validate_utf8(actual.str_0);
    if !(validity.valid as ::core::ffi::c_int == 1 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 26],
                [::core::ffi::c_char; 26],
            >(*b"assert_overlong_encodings\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            89 as ::core::ffi::c_int,
            b"validity.valid == true\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(validity.valid_upto == actual.byte_len as size_t) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 26],
                [::core::ffi::c_char; 26],
            >(*b"assert_overlong_encodings\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            90 as ::core::ffi::c_int,
            b"validity.valid_upto == actual.byte_len\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    validity = validate_utf8(overlong.str_0);
    if !(validity.valid as ::core::ffi::c_int == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 26],
                [::core::ffi::c_char; 26],
            >(*b"assert_overlong_encodings\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            93 as ::core::ffi::c_int,
            b"validity.valid == false\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(validity.valid_upto == 0 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 26],
                [::core::ffi::c_char; 26],
            >(*b"assert_overlong_encodings\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            94 as ::core::ffi::c_int,
            b"validity.valid_upto == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_validate_utf8_overlong_encoding_err() {
    assert_overlong_encodings(
        {
            let mut init = utf8_char {
                str_0: b"H\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 1 as uint8_t,
            };
            init
        },
        {
            let mut init = utf8_char {
                str_0: b"\xC1\x88\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 2 as uint8_t,
            };
            init
        },
    );
    assert_overlong_encodings(
        {
            let mut init = utf8_char {
                str_0: b"H\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 1 as uint8_t,
            };
            init
        },
        {
            let mut init = utf8_char {
                str_0: b"\xE0\x81\x88\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 3 as uint8_t,
            };
            init
        },
    );
    assert_overlong_encodings(
        {
            let mut init = utf8_char {
                str_0: b"H\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 1 as uint8_t,
            };
            init
        },
        {
            let mut init = utf8_char {
                str_0: b"\xF0\x80\x81\x88\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 4 as uint8_t,
            };
            init
        },
    );
    assert_overlong_encodings(
        {
            let mut init = utf8_char {
                str_0: b"\xD0\xB4\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 2 as uint8_t,
            };
            init
        },
        {
            let mut init = utf8_char {
                str_0: b"\xE0\x90\xB4\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 3 as uint8_t,
            };
            init
        },
    );
    assert_overlong_encodings(
        {
            let mut init = utf8_char {
                str_0: b"\xD0\xB4\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 2 as uint8_t,
            };
            init
        },
        {
            let mut init = utf8_char {
                str_0: b"\xF0\x80\x90\xB4\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 4 as uint8_t,
            };
            init
        },
    );
    assert_overlong_encodings(
        {
            let mut init = utf8_char {
                str_0: b"\xE3\x81\x93\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 3 as uint8_t,
            };
            init
        },
        {
            let mut init = utf8_char {
                str_0: b"\xF0\x83\x81\x93\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 4 as uint8_t,
            };
            init
        },
    );
    assert_overlong_encodings(
        {
            let mut init = utf8_char {
                str_0: b"\x7F\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 1 as uint8_t,
            };
            init
        },
        {
            let mut init = utf8_char {
                str_0: b"\xC1\xBF\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 2 as uint8_t,
            };
            init
        },
    );
    assert_overlong_encodings(
        {
            let mut init = utf8_char {
                str_0: b"\xDF\xBF\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 2 as uint8_t,
            };
            init
        },
        {
            let mut init = utf8_char {
                str_0: b"\xE0\x9F\xBF\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 3 as uint8_t,
            };
            init
        },
    );
    assert_overlong_encodings(
        {
            let mut init = utf8_char {
                str_0: b"\xEF\xBF\xBF\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 3 as uint8_t,
            };
            init
        },
        {
            let mut init = utf8_char {
                str_0: b"\xF0\x8F\xBF\xBF\0" as *const u8 as *const ::core::ffi::c_char,
                byte_len: 4 as uint8_t,
            };
            init
        },
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_make_utf8_string_ok() {
    let mut str: *const ::core::ffi::c_char = b"Hello \xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\0"
        as *const u8 as *const ::core::ffi::c_char;
    let mut ustr: utf8_string = make_utf8_string(str);
    if !(ustr.byte_len
        == (5 as ::core::ffi::c_int + 1 as ::core::ffi::c_int
            + 12 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
            + 1 as ::core::ffi::c_int + 5 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
            + 1 as ::core::ffi::c_int
            + 2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int) as size_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_make_utf8_string_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            116 as ::core::ffi::c_int,
            b"ustr.byte_len == 5 + 1 + 12 * 2 + 1 + 5 * 3 + 1 + 2 * 4\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strcmp(ustr.str_0, str) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_make_utf8_string_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            117 as ::core::ffi::c_int,
            b"strcmp(ustr.str, str) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_make_utf8_string_err() {
    let mut ustr: utf8_string = make_utf8_string(
        b"Hello \xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5\xC0\xC0 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    if !ustr.str_0.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 26],
                [::core::ffi::c_char; 26],
            >(*b"test_make_utf8_string_err\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            122 as ::core::ffi::c_int,
            b"ustr.str == NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(ustr.byte_len == 0 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 26],
                [::core::ffi::c_char; 26],
            >(*b"test_make_utf8_string_err\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            123 as ::core::ffi::c_int,
            b"ustr.byte_len == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_make_utf8_string_lossy_ok() {
    let mut str: *const ::core::ffi::c_char = b"Hello \xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\0"
        as *const u8 as *const ::core::ffi::c_char;
    let mut owned_ustr: owned_utf8_string = make_utf8_string_lossy(str);
    if !(owned_ustr.byte_len
        == (5 as ::core::ffi::c_int + 1 as ::core::ffi::c_int
            + 12 as ::core::ffi::c_int * 2 as ::core::ffi::c_int
            + 1 as ::core::ffi::c_int + 5 as ::core::ffi::c_int * 3 as ::core::ffi::c_int
            + 1 as ::core::ffi::c_int
            + 2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int) as size_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_make_utf8_string_lossy_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            129 as ::core::ffi::c_int,
            b"owned_ustr.byte_len == 5 + 1 + 12 * 2 + 1 + 5 * 3 + 1 + 2 * 4\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strcmp(owned_ustr.str_0, str) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_make_utf8_string_lossy_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            130 as ::core::ffi::c_int,
            b"strcmp(owned_ustr.str, str) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    free_owned_utf8_string(&mut owned_ustr);
}
#[no_mangle]
pub unsafe extern "C" fn test_make_utf8_string_lossy_invalid_sequence() {
    let mut str: *const ::core::ffi::c_char = b"\xC0He\xC0llo \xD0\x97\xD0\xB4\xD1\x80\xC0\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5\xC0\xC0 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xC0\xC0\xC0\xC0\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xC0\xF0\x9F\x98\x81\xC0\0"
        as *const u8 as *const ::core::ffi::c_char;
    let mut expected: *const ::core::ffi::c_char = b"\xEF\xBF\xBDHe\xEF\xBF\xBDllo \xD0\x97\xD0\xB4\xD1\x80\xEF\xBF\xBD\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5\xEF\xBF\xBD\xEF\xBF\xBD \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xEF\xBF\xBD\xEF\xBF\xBD\xEF\xBF\xBD\xEF\xBF\xBD\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xEF\xBF\xBD\xF0\x9F\x98\x81\xEF\xBF\xBD\0"
        as *const u8 as *const ::core::ffi::c_char;
    let mut owned_ustr: owned_utf8_string = make_utf8_string_lossy(str);
    if !(owned_ustr.byte_len == strlen(expected)) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 45],
                [::core::ffi::c_char; 45],
            >(*b"test_make_utf8_string_lossy_invalid_sequence\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            140 as ::core::ffi::c_int,
            b"owned_ustr.byte_len == strlen(expected)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strcmp(owned_ustr.str_0, expected) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 45],
                [::core::ffi::c_char; 45],
            >(*b"test_make_utf8_string_lossy_invalid_sequence\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            141 as ::core::ffi::c_int,
            b"strcmp(owned_ustr.str, expected) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    free_owned_utf8_string(&mut owned_ustr);
}
#[no_mangle]
pub unsafe extern "C" fn test_make_utf8_string_lossy_completely_invalid() {
    let mut str: *const ::core::ffi::c_char = b"\xC0\xC0\xC0\xC0\0" as *const u8
        as *const ::core::ffi::c_char;
    let mut expected: *const ::core::ffi::c_char = b"\xEF\xBF\xBD\xEF\xBF\xBD\xEF\xBF\xBD\xEF\xBF\xBD\0"
        as *const u8 as *const ::core::ffi::c_char;
    let mut owned_ustr: owned_utf8_string = make_utf8_string_lossy(str);
    if !(owned_ustr.byte_len == strlen(expected)) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 47],
                [::core::ffi::c_char; 47],
            >(*b"test_make_utf8_string_lossy_completely_invalid\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            151 as ::core::ffi::c_int,
            b"owned_ustr.byte_len == strlen(expected)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strcmp(owned_ustr.str_0, expected) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 47],
                [::core::ffi::c_char; 47],
            >(*b"test_make_utf8_string_lossy_completely_invalid\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            152 as ::core::ffi::c_int,
            b"strcmp(owned_ustr.str, expected) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    free_owned_utf8_string(&mut owned_ustr);
}
#[no_mangle]
pub unsafe extern "C" fn test_make_utf8_string_slice_ok() {
    let mut str: utf8_string = make_utf8_string(
        b"Hello \xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    let mut slice: utf8_string = slice_utf8_string(str, 6 as size_t, 24 as size_t);
    if !(slice.byte_len
        == (12 as ::core::ffi::c_int * 2 as ::core::ffi::c_int) as size_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_make_utf8_string_slice_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            159 as ::core::ffi::c_int,
            b"slice.byte_len == 12 * 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strncmp(
        slice.str_0,
        b"\xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5\0"
            as *const u8 as *const ::core::ffi::c_char,
        slice.byte_len,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 31],
                [::core::ffi::c_char; 31],
            >(*b"test_make_utf8_string_slice_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            160 as ::core::ffi::c_int,
            b"strncmp(slice.str, \"\xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5\", slice.byte_len) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_make_utf8_string_slice_start_out_of_bounds_ok() {
    let mut str: utf8_string = make_utf8_string(
        b"Hello \xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    let mut slice: utf8_string = slice_utf8_string(str, 1000 as size_t, 1 as size_t);
    if !(slice.byte_len == 0 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 51],
                [::core::ffi::c_char; 51],
            >(*b"test_make_utf8_string_slice_start_out_of_bounds_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            166 as ::core::ffi::c_int,
            b"slice.byte_len == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strcmp(slice.str_0, b"\0" as *const u8 as *const ::core::ffi::c_char)
        == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 51],
                [::core::ffi::c_char; 51],
            >(*b"test_make_utf8_string_slice_start_out_of_bounds_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            167 as ::core::ffi::c_int,
            b"strcmp(slice.str, \"\") == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_make_utf8_string_slice_end_out_of_bounds_ok() {
    let mut str: utf8_string = make_utf8_string(
        b"Hello \xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    let mut slice: utf8_string = slice_utf8_string(str, 6 as size_t, 1000 as size_t);
    if !(slice.byte_len
        == (12 as ::core::ffi::c_int * 2 as ::core::ffi::c_int + 1 as ::core::ffi::c_int
            + 5 as ::core::ffi::c_int * 3 as ::core::ffi::c_int + 1 as ::core::ffi::c_int
            + 2 as ::core::ffi::c_int * 4 as ::core::ffi::c_int) as size_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 49],
                [::core::ffi::c_char; 49],
            >(*b"test_make_utf8_string_slice_end_out_of_bounds_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            173 as ::core::ffi::c_int,
            b"slice.byte_len == 12 * 2 + 1 + 5 * 3 + 1 + 2 * 4\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strncmp(
        slice.str_0,
        b"\xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\0"
            as *const u8 as *const ::core::ffi::c_char,
        slice.byte_len,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 49],
                [::core::ffi::c_char; 49],
            >(*b"test_make_utf8_string_slice_end_out_of_bounds_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            174 as ::core::ffi::c_int,
            b"strncmp(slice.str, \"\xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\", slice.byte_len) == 0\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_make_utf8_string_slice_start_non_boundary_err() {
    let mut str: utf8_string = make_utf8_string(
        b"Hello \xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    let mut slice: utf8_string = slice_utf8_string(str, 7 as size_t, 3 as size_t);
    if !slice.str_0.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 51],
                [::core::ffi::c_char; 51],
            >(*b"test_make_utf8_string_slice_start_non_boundary_err\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            180 as ::core::ffi::c_int,
            b"slice.str == NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(slice.byte_len == 0 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 51],
                [::core::ffi::c_char; 51],
            >(*b"test_make_utf8_string_slice_start_non_boundary_err\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            181 as ::core::ffi::c_int,
            b"slice.byte_len == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_make_utf8_string_slice_end_non_boundary_err() {
    let mut str: utf8_string = make_utf8_string(
        b"Hello \xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    let mut slice: utf8_string = slice_utf8_string(str, 6 as size_t, 3 as size_t);
    if !slice.str_0.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 49],
                [::core::ffi::c_char; 49],
            >(*b"test_make_utf8_string_slice_end_non_boundary_err\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            187 as ::core::ffi::c_int,
            b"slice.str == NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(slice.byte_len == 0 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 49],
                [::core::ffi::c_char; 49],
            >(*b"test_make_utf8_string_slice_end_non_boundary_err\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            188 as ::core::ffi::c_int,
            b"slice.byte_len == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_utf8_char_iter() {
    let mut str: utf8_string = make_utf8_string(
        b"H\xD0\xB4\xE3\x81\x93\xF0\x9F\x98\x81\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut iter: utf8_char_iter = make_utf8_char_iter(str);
    let mut ch: utf8_char = utf8_char {
        str_0: 0 as *const ::core::ffi::c_char,
        byte_len: 0,
    };
    ch = next_utf8_char(&mut iter);
    if !(ch.byte_len as ::core::ffi::c_int == 1 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_utf8_char_iter\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            198 as ::core::ffi::c_int,
            b"ch.byte_len == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strncmp(
        ch.str_0,
        b"H\0" as *const u8 as *const ::core::ffi::c_char,
        ch.byte_len as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_utf8_char_iter\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            199 as ::core::ffi::c_int,
            b"strncmp(ch.str, \"H\", ch.byte_len) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    ch = next_utf8_char(&mut iter);
    if !(ch.byte_len as ::core::ffi::c_int == 2 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_utf8_char_iter\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            202 as ::core::ffi::c_int,
            b"ch.byte_len == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strncmp(
        ch.str_0,
        b"\xD0\xB4\0" as *const u8 as *const ::core::ffi::c_char,
        ch.byte_len as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_utf8_char_iter\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            203 as ::core::ffi::c_int,
            b"strncmp(ch.str, \"\xD0\xB4\", ch.byte_len) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    ch = next_utf8_char(&mut iter);
    if !(ch.byte_len as ::core::ffi::c_int == 3 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_utf8_char_iter\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            206 as ::core::ffi::c_int,
            b"ch.byte_len == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strncmp(
        ch.str_0,
        b"\xE3\x81\x93\0" as *const u8 as *const ::core::ffi::c_char,
        ch.byte_len as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_utf8_char_iter\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            207 as ::core::ffi::c_int,
            b"strncmp(ch.str, \"\xE3\x81\x93\", ch.byte_len) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    ch = next_utf8_char(&mut iter);
    if !(ch.byte_len as ::core::ffi::c_int == 4 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_utf8_char_iter\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            210 as ::core::ffi::c_int,
            b"ch.byte_len == 4\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strncmp(
        ch.str_0,
        b"\xF0\x9F\x98\x81\0" as *const u8 as *const ::core::ffi::c_char,
        ch.byte_len as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_utf8_char_iter\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            211 as ::core::ffi::c_int,
            b"strncmp(ch.str, \"\xF0\x9F\x98\x81\", ch.byte_len) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    ch = next_utf8_char(&mut iter);
    if !(ch.byte_len as ::core::ffi::c_int == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_utf8_char_iter\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            215 as ::core::ffi::c_int,
            b"ch.byte_len == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strcmp(ch.str_0, b"\0" as *const u8 as *const ::core::ffi::c_char)
        == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_utf8_char_iter\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            216 as ::core::ffi::c_int,
            b"strcmp(ch.str, \"\") == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    ch = next_utf8_char(&mut iter);
    if !(ch.byte_len as ::core::ffi::c_int == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_utf8_char_iter\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            219 as ::core::ffi::c_int,
            b"ch.byte_len == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strcmp(ch.str_0, b"\0" as *const u8 as *const ::core::ffi::c_char)
        == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_utf8_char_iter\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            220 as ::core::ffi::c_int,
            b"strcmp(ch.str, \"\") == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_utf8_char_count_zero() {
    let mut ustr: utf8_string = make_utf8_string(
        b"\0" as *const u8 as *const ::core::ffi::c_char,
    );
    let mut count: size_t = utf8_char_count(ustr);
    if !(count == 0 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 26],
                [::core::ffi::c_char; 26],
            >(*b"test_utf8_char_count_zero\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            226 as ::core::ffi::c_int,
            b"count == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_utf8_char_count() {
    let mut ustr: utf8_string = make_utf8_string(
        b"Hello \xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    let mut count: size_t = utf8_char_count(ustr);
    if !(count
        == (5 as ::core::ffi::c_int + 1 as ::core::ffi::c_int + 12 as ::core::ffi::c_int
            + 1 as ::core::ffi::c_int + 5 as ::core::ffi::c_int + 1 as ::core::ffi::c_int
            + 2 as ::core::ffi::c_int) as size_t) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 21],
                [::core::ffi::c_char; 21],
            >(*b"test_utf8_char_count\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            232 as ::core::ffi::c_int,
            b"count == 5 + 1 + 12 + 1 + 5 + 1 + 2\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_is_utf8_char_boundary() {
    let mut str: *const ::core::ffi::c_char = b"H\xD0\xB4\xE3\x81\x93\xF0\x9F\x98\x81\0"
        as *const u8 as *const ::core::ffi::c_char;
    if !is_utf8_char_boundary(str) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 27],
                [::core::ffi::c_char; 27],
            >(*b"test_is_utf8_char_boundary\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            237 as ::core::ffi::c_int,
            b"is_utf8_char_boundary(str)\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    str = str.offset(1);
    if !is_utf8_char_boundary(str) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 27],
                [::core::ffi::c_char; 27],
            >(*b"test_is_utf8_char_boundary\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            239 as ::core::ffi::c_int,
            b"is_utf8_char_boundary(++str)\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    str = str.offset(1);
    if is_utf8_char_boundary(str) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 27],
                [::core::ffi::c_char; 27],
            >(*b"test_is_utf8_char_boundary\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            240 as ::core::ffi::c_int,
            b"!is_utf8_char_boundary(++str)\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    str = str.offset(1);
    if !is_utf8_char_boundary(str) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 27],
                [::core::ffi::c_char; 27],
            >(*b"test_is_utf8_char_boundary\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            242 as ::core::ffi::c_int,
            b"is_utf8_char_boundary(++str)\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    str = str.offset(1);
    if is_utf8_char_boundary(str) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 27],
                [::core::ffi::c_char; 27],
            >(*b"test_is_utf8_char_boundary\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            243 as ::core::ffi::c_int,
            b"!is_utf8_char_boundary(++str)\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    str = str.offset(1);
    if is_utf8_char_boundary(str) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 27],
                [::core::ffi::c_char; 27],
            >(*b"test_is_utf8_char_boundary\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            244 as ::core::ffi::c_int,
            b"!is_utf8_char_boundary(++str)\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    str = str.offset(1);
    if !is_utf8_char_boundary(str) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 27],
                [::core::ffi::c_char; 27],
            >(*b"test_is_utf8_char_boundary\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            246 as ::core::ffi::c_int,
            b"is_utf8_char_boundary(++str)\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    str = str.offset(1);
    if is_utf8_char_boundary(str) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 27],
                [::core::ffi::c_char; 27],
            >(*b"test_is_utf8_char_boundary\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            247 as ::core::ffi::c_int,
            b"!is_utf8_char_boundary(++str)\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    str = str.offset(1);
    if is_utf8_char_boundary(str) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 27],
                [::core::ffi::c_char; 27],
            >(*b"test_is_utf8_char_boundary\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            248 as ::core::ffi::c_int,
            b"!is_utf8_char_boundary(++str)\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    str = str.offset(1);
    if is_utf8_char_boundary(str) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 27],
                [::core::ffi::c_char; 27],
            >(*b"test_is_utf8_char_boundary\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            249 as ::core::ffi::c_int,
            b"!is_utf8_char_boundary(++str)\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    str = str.offset(1);
    if !(strcmp(str, b"\0" as *const u8 as *const ::core::ffi::c_char)
        == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 27],
                [::core::ffi::c_char; 27],
            >(*b"test_is_utf8_char_boundary\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            251 as ::core::ffi::c_int,
            b"strcmp(++str, \"\") == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_nth_utf8_char_valid_index_ok() {
    let mut ustr: utf8_string = make_utf8_string(
        b"Hello \xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    let mut ch: utf8_char = nth_utf8_char(ustr, 20 as size_t);
    if !(ch.byte_len as ::core::ffi::c_int == 3 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 34],
                [::core::ffi::c_char; 34],
            >(*b"test_nth_utf8_char_valid_index_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            257 as ::core::ffi::c_int,
            b"ch.byte_len == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strncmp(
        ch.str_0,
        b"\xE3\x82\x93\0" as *const u8 as *const ::core::ffi::c_char,
        ch.byte_len as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 34],
                [::core::ffi::c_char; 34],
            >(*b"test_nth_utf8_char_valid_index_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            258 as ::core::ffi::c_int,
            b"strncmp(ch.str, \"\xE3\x82\x93\", ch.byte_len) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_nth_utf8_char_first_index_ok() {
    let mut ustr: utf8_string = make_utf8_string(
        b"Hello \xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    let mut ch: utf8_char = nth_utf8_char(ustr, 0 as size_t);
    if !(ch.byte_len as ::core::ffi::c_int == 1 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 34],
                [::core::ffi::c_char; 34],
            >(*b"test_nth_utf8_char_first_index_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            264 as ::core::ffi::c_int,
            b"ch.byte_len == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(*ch.str_0 as ::core::ffi::c_int == 'H' as i32) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 34],
                [::core::ffi::c_char; 34],
            >(*b"test_nth_utf8_char_first_index_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            265 as ::core::ffi::c_int,
            b"*ch.str == 'H'\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_nth_utf8_char_last_index_ok() {
    let mut ustr: utf8_string = make_utf8_string(
        b"Hello \xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    let mut ch: utf8_char = nth_utf8_char(ustr, 26 as size_t);
    if !(ch.byte_len as ::core::ffi::c_int == 4 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 33],
                [::core::ffi::c_char; 33],
            >(*b"test_nth_utf8_char_last_index_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            271 as ::core::ffi::c_int,
            b"ch.byte_len == 4\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strncmp(
        ch.str_0,
        b"\xF0\x9F\x98\x81\0" as *const u8 as *const ::core::ffi::c_char,
        ch.byte_len as size_t,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 33],
                [::core::ffi::c_char; 33],
            >(*b"test_nth_utf8_char_last_index_ok\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            272 as ::core::ffi::c_int,
            b"strncmp(ch.str, \"\xF0\x9F\x98\x81\", ch.byte_len) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_nth_utf8_char_invalid_index_err() {
    let mut ustr: utf8_string = make_utf8_string(
        b"Hello \xD0\x97\xD0\xB4\xD1\x80\xD0\xB0\xD0\xB2\xD1\x81\xD1\x82\xD0\xB2\xD1\x83\xD0\xB9\xD1\x82\xD0\xB5 \xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB\xE3\x81\xA1\xE3\x81\xAF \xF0\x9F\x9A\xA9\xF0\x9F\x98\x81\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    let mut ch: utf8_char = nth_utf8_char(ustr, 100 as size_t);
    if !ch.str_0.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 37],
                [::core::ffi::c_char; 37],
            >(*b"test_nth_utf8_char_invalid_index_err\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            278 as ::core::ffi::c_int,
            b"ch.str == NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(ch.byte_len as ::core::ffi::c_int == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 37],
                [::core::ffi::c_char; 37],
            >(*b"test_nth_utf8_char_invalid_index_err\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            279 as ::core::ffi::c_int,
            b"ch.byte_len == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_nth_utf8_char_empty_string_err() {
    let mut ustr: utf8_string = make_utf8_string(
        b"\0" as *const u8 as *const ::core::ffi::c_char,
    );
    let mut ch: utf8_char = nth_utf8_char(ustr, 0 as size_t);
    if !ch.str_0.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 36],
                [::core::ffi::c_char; 36],
            >(*b"test_nth_utf8_char_empty_string_err\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            285 as ::core::ffi::c_int,
            b"ch.str == NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(ch.byte_len as ::core::ffi::c_int == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 36],
                [::core::ffi::c_char; 36],
            >(*b"test_nth_utf8_char_empty_string_err\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            286 as ::core::ffi::c_int,
            b"ch.byte_len == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub unsafe extern "C" fn test_unicode_code_point() {
    let mut ustr: utf8_string = make_utf8_string(
        b"H\xD0\xB4\xE3\x81\x93\xF0\x9F\x98\x81\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut iter: utf8_char_iter = make_utf8_char_iter(ustr);
    if !(unicode_code_point(next_utf8_char(&mut iter)) == 72 as uint32_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"test_unicode_code_point\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            293 as ::core::ffi::c_int,
            b"unicode_code_point(next_utf8_char(&iter)) == 72\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(unicode_code_point(next_utf8_char(&mut iter)) == 1076 as uint32_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"test_unicode_code_point\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            294 as ::core::ffi::c_int,
            b"unicode_code_point(next_utf8_char(&iter)) == 1076\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(unicode_code_point(next_utf8_char(&mut iter)) == 12371 as uint32_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"test_unicode_code_point\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            295 as ::core::ffi::c_int,
            b"unicode_code_point(next_utf8_char(&iter)) == 12371\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(unicode_code_point(next_utf8_char(&mut iter)) == 128513 as uint32_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"test_unicode_code_point\0")
                .as_ptr(),
            b"test.c\0" as *const u8 as *const ::core::ffi::c_char,
            296 as ::core::ffi::c_int,
            b"unicode_code_point(next_utf8_char(&iter)) == 128513\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
}
#[no_mangle]
pub static mut ntests: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
unsafe fn main_0() -> ::core::ffi::c_int {
    test_validate_utf8_ok();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_validate_utf8_ok\0" as *const u8 as *const ::core::ffi::c_char,
    );
    test_validate_utf8_boundary_ok();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_validate_utf8_boundary_ok\0" as *const u8 as *const ::core::ffi::c_char,
    );
    test_surrogate_rejection();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_surrogate_rejection\0" as *const u8 as *const ::core::ffi::c_char,
    );
    test_validate_utf8_err();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_validate_utf8_err\0" as *const u8 as *const ::core::ffi::c_char,
    );
    test_validate_utf8_overlong_encoding_err();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_validate_utf8_overlong_encoding_err\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    test_make_utf8_string_ok();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_make_utf8_string_ok\0" as *const u8 as *const ::core::ffi::c_char,
    );
    test_make_utf8_string_err();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_make_utf8_string_err\0" as *const u8 as *const ::core::ffi::c_char,
    );
    test_make_utf8_string_lossy_ok();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_make_utf8_string_lossy_ok\0" as *const u8 as *const ::core::ffi::c_char,
    );
    test_make_utf8_string_lossy_invalid_sequence();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_make_utf8_string_lossy_invalid_sequence\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    test_make_utf8_string_lossy_completely_invalid();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_make_utf8_string_lossy_completely_invalid\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    test_make_utf8_string_slice_ok();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_make_utf8_string_slice_ok\0" as *const u8 as *const ::core::ffi::c_char,
    );
    test_make_utf8_string_slice_start_out_of_bounds_ok();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_make_utf8_string_slice_start_out_of_bounds_ok\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    test_make_utf8_string_slice_end_out_of_bounds_ok();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_make_utf8_string_slice_end_out_of_bounds_ok\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    test_make_utf8_string_slice_start_non_boundary_err();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_make_utf8_string_slice_start_non_boundary_err\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    test_make_utf8_string_slice_end_non_boundary_err();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_make_utf8_string_slice_end_non_boundary_err\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    test_utf8_char_iter();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_utf8_char_iter\0" as *const u8 as *const ::core::ffi::c_char,
    );
    test_utf8_char_count_zero();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_utf8_char_count_zero\0" as *const u8 as *const ::core::ffi::c_char,
    );
    test_utf8_char_count();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_utf8_char_count\0" as *const u8 as *const ::core::ffi::c_char,
    );
    test_is_utf8_char_boundary();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_is_utf8_char_boundary\0" as *const u8 as *const ::core::ffi::c_char,
    );
    test_nth_utf8_char_valid_index_ok();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_nth_utf8_char_valid_index_ok\0" as *const u8 as *const ::core::ffi::c_char,
    );
    test_nth_utf8_char_first_index_ok();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_nth_utf8_char_first_index_ok\0" as *const u8 as *const ::core::ffi::c_char,
    );
    test_nth_utf8_char_last_index_ok();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_nth_utf8_char_last_index_ok\0" as *const u8 as *const ::core::ffi::c_char,
    );
    test_nth_utf8_char_invalid_index_err();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_nth_utf8_char_invalid_index_err\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    test_nth_utf8_char_empty_string_err();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_nth_utf8_char_empty_string_err\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    test_unicode_code_point();
    ntests += 1;
    printf(
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        b"test_unicode_code_point\0" as *const u8 as *const ::core::ffi::c_char,
    );
    printf(
        b"\n** %d tests passed **\n\0" as *const u8 as *const ::core::ffi::c_char,
        ntests,
    );
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
