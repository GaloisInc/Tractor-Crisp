#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn static_sum(
    mut update: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    static mut sum: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    sum += update;
    return sum;
}
#[no_mangle]
pub unsafe extern "C" fn driver(mut stride: ::core::ffi::c_int) {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < 10 as ::core::ffi::c_int {
        printf(
            b"%d\n\0" as *const u8 as *const ::core::ffi::c_char,
            static_sum(i * stride),
        );
        i += 1;
    }
}
