#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn driver(mut x: ::core::ffi::c_int) {
    let mut y: ::core::ffi::c_int = 2 as ::core::ffi::c_int * x;
    y += 300 as ::core::ffi::c_int;
    printf(b"%d\n\0" as *const u8 as *const ::core::ffi::c_char, y);
}
