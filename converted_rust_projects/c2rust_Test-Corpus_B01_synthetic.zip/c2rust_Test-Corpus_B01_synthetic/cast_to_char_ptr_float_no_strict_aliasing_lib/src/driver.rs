#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type size_t = __darwin_size_t;
pub type __darwin_size_t = usize;
unsafe extern "C" fn print_hex(
    mut p: *mut ::core::ffi::c_uchar,
    mut len: ::core::ffi::c_int,
) {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < len {
        printf(
            b"%02x\0" as *const u8 as *const ::core::ffi::c_char,
            *p.offset(i as isize) as ::core::ffi::c_int,
        );
        i += 1;
    }
    printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
}
#[no_mangle]
pub unsafe extern "C" fn driver(mut x: ::core::ffi::c_float) {
    let mut raw: [::core::ffi::c_char; 4] = [0; 4];
    memcpy(
        raw.as_mut_ptr() as *mut ::core::ffi::c_void,
        &mut x as *mut ::core::ffi::c_float as *const ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_float>() as size_t,
    );
    print_hex(
        raw.as_mut_ptr() as *mut ::core::ffi::c_uchar,
        ::core::mem::size_of::<[::core::ffi::c_char; 4]>() as ::core::ffi::c_int,
    );
}
