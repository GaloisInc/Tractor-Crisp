#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn scanf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct house_t {
    pub floors: ::core::ffi::c_int,
    pub bedrooms: ::core::ffi::c_int,
    pub bathrooms: ::core::ffi::c_double,
}
unsafe extern "C" fn print_hex(
    mut p: *mut ::core::ffi::c_uchar,
    mut len: ::core::ffi::c_int,
) {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < len {
        printf(
            b"%02x\0" as *const u8 as *const ::core::ffi::c_char,
            *p.offset(i as isize) as ::core::ffi::c_int,
        );
        i += 1;
    }
    printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
}
#[no_mangle]
pub unsafe extern "C" fn driver(mut floors: ::core::ffi::c_int) {
    let mut house: house_t = {
        let mut init = house_t {
            floors: 0 as ::core::ffi::c_int,
            bedrooms: 0,
            bathrooms: 0.,
        };
        init
    };
    house.floors = floors;
    house.bedrooms = 3 as ::core::ffi::c_int;
    house.bathrooms = 2.0f64;
    let mut raw: [::core::ffi::c_char; 16] = [0; 16];
    memcpy(
        raw.as_mut_ptr() as *mut ::core::ffi::c_void,
        &mut house as *mut house_t as *const ::core::ffi::c_void,
        ::core::mem::size_of::<house_t>() as size_t,
    );
    print_hex(
        &mut raw as *mut [::core::ffi::c_char; 16] as *mut ::core::ffi::c_uchar,
        ::core::mem::size_of::<[::core::ffi::c_char; 16]>() as ::core::ffi::c_int,
    );
}
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut x: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    scanf(
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut x as *mut ::core::ffi::c_int,
    );
    driver(x);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
