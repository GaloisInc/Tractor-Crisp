#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn scanf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
}
unsafe extern "C" fn foo(mut x: ::core::ffi::c_int, mut y: ::core::ffi::c_int) {
    let mut current_block_6: u64;
    while x > 0 as ::core::ffi::c_int || y > 0 as ::core::ffi::c_int {
        printf(b"loop\n\0" as *const u8 as *const ::core::ffi::c_char);
        if x == 1 as ::core::ffi::c_int && y == 4 as ::core::ffi::c_int {
            current_block_6 = 9673376535656171254;
        } else {
            current_block_6 = 15665974401893126668;
        }
        loop {
            match current_block_6 {
                15665974401893126668 => {
                    if x > 0 as ::core::ffi::c_int {
                        printf(b"x\n\0" as *const u8 as *const ::core::ffi::c_char);
                        x -= 1;
                    }
                    current_block_6 = 9673376535656171254;
                }
                _ => {
                    if y == 0 as ::core::ffi::c_int {
                        break;
                    }
                    printf(b"y\n\0" as *const u8 as *const ::core::ffi::c_char);
                    y -= 1;
                    if x < 3 as ::core::ffi::c_int {
                        current_block_6 = 15665974401893126668;
                    } else {
                        break;
                    }
                }
            }
        }
    }
}
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut x: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut y: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    scanf(
        b"%d %d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut x as *mut ::core::ffi::c_int,
        &mut y as *mut ::core::ffi::c_int,
    );
    foo(x, y);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
