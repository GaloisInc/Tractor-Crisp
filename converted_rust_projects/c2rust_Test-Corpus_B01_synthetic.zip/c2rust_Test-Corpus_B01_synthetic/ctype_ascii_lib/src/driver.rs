#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(linkage)]
extern "C" {
    static mut _DefaultRuneLocale: _RuneLocale;
    fn __maskrune(_: __darwin_ct_rune_t, _: ::core::ffi::c_ulong) -> ::core::ffi::c_int;
    fn __toupper(_: __darwin_ct_rune_t) -> __darwin_ct_rune_t;
    fn __tolower(_: __darwin_ct_rune_t) -> __darwin_ct_rune_t;
    fn setlocale(
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
}
pub type __darwin_ct_rune_t = ::core::ffi::c_int;
pub type __uint32_t = u32;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneLocale {
    pub __magic: [::core::ffi::c_char; 8],
    pub __encoding: [::core::ffi::c_char; 32],
    pub __sgetrune: Option<
        unsafe extern "C" fn(
            *const ::core::ffi::c_char,
            __darwin_size_t,
            *mut *const ::core::ffi::c_char,
        ) -> __darwin_rune_t,
    >,
    pub __sputrune: Option<
        unsafe extern "C" fn(
            __darwin_rune_t,
            *mut ::core::ffi::c_char,
            __darwin_size_t,
            *mut *mut ::core::ffi::c_char,
        ) -> ::core::ffi::c_int,
    >,
    pub __invalid_rune: __darwin_rune_t,
    pub __runetype: [__uint32_t; 256],
    pub __maplower: [__darwin_rune_t; 256],
    pub __mapupper: [__darwin_rune_t; 256],
    pub __runetype_ext: _RuneRange,
    pub __maplower_ext: _RuneRange,
    pub __mapupper_ext: _RuneRange,
    pub __variable: *mut ::core::ffi::c_void,
    pub __variable_len: ::core::ffi::c_int,
    pub __ncharclasses: ::core::ffi::c_int,
    pub __charclasses: *mut _RuneCharClass,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneCharClass {
    pub __name: [::core::ffi::c_char; 14],
    pub __mask: __uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneRange {
    pub __nranges: ::core::ffi::c_int,
    pub __ranges: *mut _RuneEntry,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneEntry {
    pub __min: __darwin_rune_t,
    pub __max: __darwin_rune_t,
    pub __map: __darwin_rune_t,
    pub __types: *mut __uint32_t,
}
pub type __darwin_rune_t = __darwin_wchar_t;
pub type __darwin_wchar_t = ::libc::wchar_t;
pub type __darwin_size_t = usize;
pub const _CACHED_RUNES: ::core::ffi::c_int = (1 as ::core::ffi::c_int)
    << 8 as ::core::ffi::c_int;
pub const _CTYPE_A: ::core::ffi::c_long = 0x100 as ::core::ffi::c_long;
pub const _CTYPE_C: ::core::ffi::c_long = 0x200 as ::core::ffi::c_long;
pub const _CTYPE_D: ::core::ffi::c_long = 0x400 as ::core::ffi::c_long;
pub const _CTYPE_G: ::core::ffi::c_long = 0x800 as ::core::ffi::c_long;
pub const _CTYPE_L: ::core::ffi::c_long = 0x1000 as ::core::ffi::c_long;
pub const _CTYPE_P: ::core::ffi::c_long = 0x2000 as ::core::ffi::c_long;
pub const _CTYPE_S: ::core::ffi::c_long = 0x4000 as ::core::ffi::c_long;
pub const _CTYPE_U: ::core::ffi::c_long = 0x8000 as ::core::ffi::c_long;
pub const _CTYPE_X: ::core::ffi::c_long = 0x10000 as ::core::ffi::c_long;
pub const _CTYPE_B: ::core::ffi::c_long = 0x20000 as ::core::ffi::c_long;
pub const _CTYPE_R: ::core::ffi::c_long = 0x40000 as ::core::ffi::c_long;
#[inline]
unsafe extern "C" fn isascii(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return (_c & !(0x7f as ::core::ffi::c_int) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn __istype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> ::core::ffi::c_int {
    return if isascii(_c as ::core::ffi::c_int) != 0 {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    } else {
        (__maskrune(_c, _f) != 0) as ::core::ffi::c_int
    };
}
#[inline]
unsafe extern "C" fn __isctype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> __darwin_ct_rune_t {
    return if _c < 0 as ::core::ffi::c_int || _c >= _CACHED_RUNES {
        0 as __darwin_ct_rune_t
    } else {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    };
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isalnum(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(
        _c as __darwin_ct_rune_t,
        (_CTYPE_A | _CTYPE_D) as ::core::ffi::c_ulong,
    );
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isalpha(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_A as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isblank(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_B as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn iscntrl(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_C as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isdigit(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __isctype(_c as __darwin_ct_rune_t, _CTYPE_D as ::core::ffi::c_ulong)
        as ::core::ffi::c_int;
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isgraph(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_G as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn islower(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_L as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isprint(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_R as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn ispunct(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_P as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isspace(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_S as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isupper(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_U as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isxdigit(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __isctype(_c as __darwin_ct_rune_t, _CTYPE_X as ::core::ffi::c_ulong)
        as ::core::ffi::c_int;
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn tolower(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __tolower(_c as __darwin_ct_rune_t) as ::core::ffi::c_int;
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn toupper(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __toupper(_c as __darwin_ct_rune_t) as ::core::ffi::c_int;
}
pub const LC_ALL: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn driver(mut c: ::core::ffi::c_char) {
    setlocale(LC_ALL, b"C\0" as *const u8 as *const ::core::ffi::c_char);
    printf(
        b"alphanumeric: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        isalnum(c as ::core::ffi::c_int),
    );
    printf(
        b"alphabetic: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        isalpha(c as ::core::ffi::c_int),
    );
    printf(
        b"lowercase: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        islower(c as ::core::ffi::c_int),
    );
    printf(
        b"uppercase: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        isupper(c as ::core::ffi::c_int),
    );
    printf(
        b"digit: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        isdigit(c as ::core::ffi::c_int),
    );
    printf(
        b"hexadecimal: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        isxdigit(c as ::core::ffi::c_int),
    );
    printf(
        b"control: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        iscntrl(c as ::core::ffi::c_int),
    );
    printf(
        b"graphical: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        isgraph(c as ::core::ffi::c_int),
    );
    printf(
        b"space: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        isspace(c as ::core::ffi::c_int),
    );
    printf(
        b"blank: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        isblank(c as ::core::ffi::c_int),
    );
    printf(
        b"printing: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        isprint(c as ::core::ffi::c_int),
    );
    printf(
        b"punctuation: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        ispunct(c as ::core::ffi::c_int),
    );
    printf(
        b"to lower: %c\n\0" as *const u8 as *const ::core::ffi::c_char,
        tolower(c as ::core::ffi::c_int),
    );
    printf(
        b"to upper: %c\n\0" as *const u8 as *const ::core::ffi::c_char,
        toupper(c as ::core::ffi::c_int),
    );
}
