#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn strtod(
        _: *const ::core::ffi::c_char,
        _: *mut *mut ::core::ffi::c_char,
    ) -> ::core::ffi::c_double;
    fn pow(_: ::core::ffi::c_double, _: ::core::ffi::c_double) -> ::core::ffi::c_double;
    fn __error() -> *mut ::core::ffi::c_int;
}
pub type __int64_t = i64;
pub type __darwin_off_t = __int64_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub const EDOM: ::core::ffi::c_int = 33 as ::core::ffi::c_int;
pub const ERANGE: ::core::ffi::c_int = 34 as ::core::ffi::c_int;
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    if argc != 3 as ::core::ffi::c_int {
        fprintf(
            __stderrp,
            b"Usage: %s base exponent\n\0" as *const u8 as *const ::core::ffi::c_char,
            *argv.offset(0 as ::core::ffi::c_int as isize),
        );
        return 1 as ::core::ffi::c_int;
    }
    let mut endptr1: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut endptr2: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    *__error() = 0 as ::core::ffi::c_int;
    let mut base: ::core::ffi::c_double = strtod(
        *argv.offset(1 as ::core::ffi::c_int as isize),
        &mut endptr1,
    );
    if *__error() == ERANGE {
        fprintf(
            __stderrp,
            b"Range error while converting base '%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            *argv.offset(1 as ::core::ffi::c_int as isize),
        );
        return 1 as ::core::ffi::c_int;
    } else if *endptr1 as ::core::ffi::c_int != '\0' as i32 {
        fprintf(
            __stderrp,
            b"Invalid numeric input for base: '%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            *argv.offset(1 as ::core::ffi::c_int as isize),
        );
        return 1 as ::core::ffi::c_int;
    }
    *__error() = 0 as ::core::ffi::c_int;
    let mut exponent: ::core::ffi::c_double = strtod(
        *argv.offset(2 as ::core::ffi::c_int as isize),
        &mut endptr2,
    );
    if *__error() == ERANGE {
        fprintf(
            __stderrp,
            b"Range error while converting exponent '%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            *argv.offset(2 as ::core::ffi::c_int as isize),
        );
        return 1 as ::core::ffi::c_int;
    } else if *endptr2 as ::core::ffi::c_int != '\0' as i32 {
        fprintf(
            __stderrp,
            b"Invalid numeric input for exponent: '%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            *argv.offset(2 as ::core::ffi::c_int as isize),
        );
        return 1 as ::core::ffi::c_int;
    }
    *__error() = 0 as ::core::ffi::c_int;
    let mut result: ::core::ffi::c_double = pow(base, exponent);
    if *__error() == EDOM {
        fprintf(
            __stderrp,
            b"Domain error: pow(%.2f, %.2f) is undefined in the real number domain.\n\0"
                as *const u8 as *const ::core::ffi::c_char,
            base,
            exponent,
        );
        return 1 as ::core::ffi::c_int;
    } else if *__error() == ERANGE {
        fprintf(
            __stderrp,
            b"Range error: pow(%.2f, %.2f) caused overflow or underflow.\n\0"
                as *const u8 as *const ::core::ffi::c_char,
            base,
            exponent,
        );
        return 1 as ::core::ffi::c_int;
    }
    printf(b"Result: %.2f\n\0" as *const u8 as *const ::core::ffi::c_char, result);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
