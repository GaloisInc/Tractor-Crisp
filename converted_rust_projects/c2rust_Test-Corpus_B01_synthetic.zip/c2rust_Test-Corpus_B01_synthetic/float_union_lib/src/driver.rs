#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
}
pub type uint64_t = u64;
#[derive(Copy, Clone)]
#[repr(C)]
pub union raw_double_t {
    pub x: uint64_t,
    pub f: ::core::ffi::c_double,
}
#[no_mangle]
pub unsafe extern "C" fn driver(mut f: ::core::ffi::c_double) {
    let mut u: raw_double_t = raw_double_t { f: f };
    printf(b"%llx %a %.4f\n\0" as *const u8 as *const ::core::ffi::c_char, u.x, f, f);
}
