#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn rand() -> ::core::ffi::c_int;
    fn srand(_: ::core::ffi::c_uint);
    fn strtoul(
        __str: *const ::core::ffi::c_char,
        __endptr: *mut *mut ::core::ffi::c_char,
        __base: ::core::ffi::c_int,
    ) -> ::core::ffi::c_ulong;
    fn __error() -> *mut ::core::ffi::c_int;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub const UINT_MAX: ::core::ffi::c_uint = 0xffffffff as ::core::ffi::c_uint;
pub const ARRAY_SIZE: ::core::ffi::c_int = 256 as ::core::ffi::c_int
    * 1024 as ::core::ffi::c_int;
pub const ITERATIONS: ::core::ffi::c_int = 2000 as ::core::ffi::c_int;
#[no_mangle]
pub static mut array: [::core::ffi::c_int; 262144] = [0; 262144];
#[no_mangle]
pub unsafe extern "C" fn perform_expensive_operations() {
    let mut i: size_t = 0 as size_t;
    while i < ARRAY_SIZE as size_t {
        let mut x: ::core::ffi::c_int = array[i as usize];
        let mut j: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while j < 100 as ::core::ffi::c_int {
            x = x * 3 as ::core::ffi::c_int + 7 as ::core::ffi::c_int;
            x = x ^ x >> 3 as ::core::ffi::c_int;
            x = x - (x << 1 as ::core::ffi::c_int);
            x = x / 2 as ::core::ffi::c_int + x % 7 as ::core::ffi::c_int;
            j += 1;
        }
        array[i as usize] = x;
        i = i.wrapping_add(1);
    }
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    if argc != 2 as ::core::ffi::c_int {
        fprintf(
            __stderrp,
            b"Usage: %s <seed>\n\0" as *const u8 as *const ::core::ffi::c_char,
            *argv.offset(0 as ::core::ffi::c_int as isize),
        );
        return 1 as ::core::ffi::c_int;
    }
    *__error() = 0 as ::core::ffi::c_int;
    let mut endptr: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut temp_seed: ::core::ffi::c_ulong = strtoul(
        *argv.offset(1 as ::core::ffi::c_int as isize),
        &mut endptr,
        10 as ::core::ffi::c_int,
    );
    if *endptr as ::core::ffi::c_int != '\0' as i32
        || *__error() != 0 as ::core::ffi::c_int
        || temp_seed > UINT_MAX as ::core::ffi::c_ulong
    {
        fprintf(
            __stderrp,
            b"Invalid seed: '%s'\n\0" as *const u8 as *const ::core::ffi::c_char,
            *argv.offset(1 as ::core::ffi::c_int as isize),
        );
        return 1 as ::core::ffi::c_int;
    }
    let mut seed: ::core::ffi::c_uint = temp_seed as ::core::ffi::c_uint;
    srand(seed);
    let mut i: size_t = 0 as size_t;
    while i < ARRAY_SIZE as size_t {
        array[i as usize] = rand();
        i = i.wrapping_add(1);
    }
    let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_0 < ITERATIONS {
        perform_expensive_operations();
        i_0 += 1;
    }
    let mut xor_result: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut i_1: size_t = 0 as size_t;
    while i_1 < ARRAY_SIZE as size_t {
        xor_result ^= array[i_1 as usize];
        i_1 = i_1.wrapping_add(1);
    }
    printf(b"%d\n\0" as *const u8 as *const ::core::ffi::c_char, xor_result);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
