#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn sieve(mut val: ::core::ffi::c_int) {
    loop {
        printf(b"%d\n\0" as *const u8 as *const ::core::ffi::c_char, val);
        if val % 10 as ::core::ffi::c_int == 9 as ::core::ffi::c_int {
            break;
        }
        val += 1;
    };
}
