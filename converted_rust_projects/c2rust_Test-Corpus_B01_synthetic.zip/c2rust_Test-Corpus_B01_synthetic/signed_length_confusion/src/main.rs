#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stdinp: *mut FILE;
    fn fgets(
        _: *mut ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *mut FILE,
    ) -> *mut ::core::ffi::c_char;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn atoi(_: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strncpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> *mut ::core::ffi::c_char;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn printLine(mut line: *const ::core::ffi::c_char) {
    if !line.is_null() {
        printf(b"%s\n\0" as *const u8 as *const ::core::ffi::c_char, line);
    }
}
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut data: ::core::ffi::c_int = 0;
    data = -(1 as ::core::ffi::c_int);
    let mut inputBuffer: [::core::ffi::c_char; 14] = ::core::mem::transmute::<
        [u8; 14],
        [::core::ffi::c_char; 14],
    >(*b"\0\0\0\0\0\0\0\0\0\0\0\0\0\0");
    if !fgets(inputBuffer.as_mut_ptr(), 14 as ::core::ffi::c_int, __stdinp).is_null() {
        data = atoi(inputBuffer.as_mut_ptr());
    } else {
        printLine(b"fgets() failed.\0" as *const u8 as *const ::core::ffi::c_char);
    }
    let mut source: [::core::ffi::c_char; 100] = [0; 100];
    let mut dest: [::core::ffi::c_char; 100] = ::core::mem::transmute::<
        [u8; 100],
        [::core::ffi::c_char; 100],
    >(
        *b"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
    );
    memset(
        source.as_mut_ptr() as *mut ::core::ffi::c_void,
        'A' as i32,
        (100 as ::core::ffi::c_int - 1 as ::core::ffi::c_int) as size_t,
    );
    source[(100 as ::core::ffi::c_int - 1 as ::core::ffi::c_int) as usize] = '\0' as i32
        as ::core::ffi::c_char;
    if data < 100 as ::core::ffi::c_int {
        strncpy(dest.as_mut_ptr(), source.as_mut_ptr(), data as size_t);
        dest[data as usize] = '\0' as i32 as ::core::ffi::c_char;
    }
    printLine(dest.as_mut_ptr());
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
