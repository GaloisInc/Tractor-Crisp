#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strncpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> *mut ::core::ffi::c_char;
}
pub type size_t = __darwin_size_t;
pub type __darwin_size_t = usize;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn printLine(mut line: *const ::core::ffi::c_char) {
    if !line.is_null() {
        printf(b"%s\n\0" as *const u8 as *const ::core::ffi::c_char, line);
    }
}
#[no_mangle]
pub unsafe extern "C" fn driver(mut data: ::core::ffi::c_int) {
    let mut source: [::core::ffi::c_char; 100] = [0; 100];
    let mut dest: [::core::ffi::c_char; 100] = ::core::mem::transmute::<
        [u8; 100],
        [::core::ffi::c_char; 100],
    >(
        *b"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
    );
    memset(
        source.as_mut_ptr() as *mut ::core::ffi::c_void,
        'A' as i32,
        (100 as ::core::ffi::c_int - 1 as ::core::ffi::c_int) as size_t,
    );
    source[(100 as ::core::ffi::c_int - 1 as ::core::ffi::c_int) as usize] = '\0' as i32
        as ::core::ffi::c_char;
    if data < 100 as ::core::ffi::c_int {
        strncpy(dest.as_mut_ptr(), source.as_mut_ptr(), data as size_t);
        dest[data as usize] = '\0' as i32 as ::core::ffi::c_char;
    }
    printLine(dest.as_mut_ptr());
}
