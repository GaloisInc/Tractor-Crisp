#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stdinp: *mut FILE;
    fn fgets(
        _: *mut ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *mut FILE,
    ) -> *mut ::core::ffi::c_char;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn atoi(_: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
}
pub type __int64_t = i64;
pub type __darwin_off_t = __int64_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn printLine(mut line: *const ::core::ffi::c_char) {
    if !line.is_null() {
        printf(b"%s\n\0" as *const u8 as *const ::core::ffi::c_char, line);
    }
}
#[no_mangle]
pub unsafe extern "C" fn printIntLine(mut intNumber: ::core::ffi::c_int) {
    printf(b"%d\n\0" as *const u8 as *const ::core::ffi::c_char, intNumber);
}
#[no_mangle]
pub unsafe extern "C" fn bad() {
    let mut data: ::core::ffi::c_int = 0;
    data = -(1 as ::core::ffi::c_int);
    let mut inputBuffer: [::core::ffi::c_char; 14] = ::core::mem::transmute::<
        [u8; 14],
        [::core::ffi::c_char; 14],
    >(*b"\0\0\0\0\0\0\0\0\0\0\0\0\0\0");
    if !fgets(inputBuffer.as_mut_ptr(), 14 as ::core::ffi::c_int, __stdinp).is_null() {
        data = atoi(inputBuffer.as_mut_ptr());
    } else {
        printLine(b"fgets() failed.\0" as *const u8 as *const ::core::ffi::c_char);
    }
    let mut i: ::core::ffi::c_int = 0;
    let mut buffer: [::core::ffi::c_int; 10] = [0 as ::core::ffi::c_int; 10];
    if data >= 0 as ::core::ffi::c_int {
        buffer[data as usize] = 1 as ::core::ffi::c_int;
        i = 0 as ::core::ffi::c_int;
        while i < 10 as ::core::ffi::c_int {
            printIntLine(buffer[i as usize]);
            i += 1;
        }
    } else {
        printLine(
            b"ERROR: Array index is negative.\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
}
unsafe extern "C" fn goodG2B() {
    let mut data: ::core::ffi::c_int = 0;
    data = -(1 as ::core::ffi::c_int);
    data = 7 as ::core::ffi::c_int;
    let mut i: ::core::ffi::c_int = 0;
    let mut buffer: [::core::ffi::c_int; 10] = [0 as ::core::ffi::c_int; 10];
    if data >= 0 as ::core::ffi::c_int {
        buffer[data as usize] = 1 as ::core::ffi::c_int;
        i = 0 as ::core::ffi::c_int;
        while i < 10 as ::core::ffi::c_int {
            printIntLine(buffer[i as usize]);
            i += 1;
        }
    } else {
        printLine(
            b"ERROR: Array index is negative.\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
}
unsafe extern "C" fn goodB2G() {
    let mut data: ::core::ffi::c_int = 0;
    data = -(1 as ::core::ffi::c_int);
    let mut inputBuffer: [::core::ffi::c_char; 14] = ::core::mem::transmute::<
        [u8; 14],
        [::core::ffi::c_char; 14],
    >(*b"\0\0\0\0\0\0\0\0\0\0\0\0\0\0");
    if !fgets(inputBuffer.as_mut_ptr(), 14 as ::core::ffi::c_int, __stdinp).is_null() {
        data = atoi(inputBuffer.as_mut_ptr());
    } else {
        printLine(b"fgets() failed.\0" as *const u8 as *const ::core::ffi::c_char);
    }
    let mut i: ::core::ffi::c_int = 0;
    let mut buffer: [::core::ffi::c_int; 10] = [0 as ::core::ffi::c_int; 10];
    if data >= 0 as ::core::ffi::c_int && data < 10 as ::core::ffi::c_int {
        buffer[data as usize] = 1 as ::core::ffi::c_int;
        i = 0 as ::core::ffi::c_int;
        while i < 10 as ::core::ffi::c_int {
            printIntLine(buffer[i as usize]);
            i += 1;
        }
    } else {
        printLine(
            b"ERROR: Array index is out-of-bounds\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
}
#[no_mangle]
pub unsafe extern "C" fn good() {
    goodG2B();
    goodB2G();
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    printLine(b"Calling good()...\0" as *const u8 as *const ::core::ffi::c_char);
    good();
    printLine(b"Finished good()\0" as *const u8 as *const ::core::ffi::c_char);
    printLine(b"Calling bad()...\0" as *const u8 as *const ::core::ffi::c_char);
    bad();
    printLine(b"Finished bad()\0" as *const u8 as *const ::core::ffi::c_char);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
