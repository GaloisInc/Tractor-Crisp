#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn strtol(
        __str: *const ::core::ffi::c_char,
        __endptr: *mut *mut ::core::ffi::c_char,
        __base: ::core::ffi::c_int,
    ) -> ::core::ffi::c_long;
}
#[no_mangle]
pub unsafe extern "C" fn static_alias(
    mut outer: *mut ::core::ffi::c_int,
) -> *mut ::core::ffi::c_int {
    static mut inner: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    if *outer >= inner {
        inner += *outer;
        return &mut inner;
    } else {
        *outer += inner;
        return outer;
    };
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    if argc != 3 as ::core::ffi::c_int {
        printf(
            b"Error: should only be two (integer) arguments!\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    let mut end: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut initial_value: ::core::ffi::c_int = strtol(
        *argv.offset(1 as ::core::ffi::c_int as isize),
        &mut end,
        10 as ::core::ffi::c_int,
    ) as ::core::ffi::c_int;
    if end == *argv.offset(1 as ::core::ffi::c_int as isize) {
        printf(
            b"Error: first argument must be an integer!\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    let mut iterations: ::core::ffi::c_int = strtol(
        *argv.offset(2 as ::core::ffi::c_int as isize),
        &mut end,
        10 as ::core::ffi::c_int,
    ) as ::core::ffi::c_int;
    if end == *argv.offset(2 as ::core::ffi::c_int as isize) {
        printf(
            b"Error: second argument must be an integer!\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    let mut running_sum: *mut ::core::ffi::c_int = &mut initial_value;
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < iterations {
        running_sum = static_alias(running_sum);
        printf(b"%d\n\0" as *const u8 as *const ::core::ffi::c_char, *running_sum);
        i += 1;
    }
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
