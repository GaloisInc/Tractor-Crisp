#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn strcspn(
        __s: *const ::core::ffi::c_char,
        __charset: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_ulong;
}
#[no_mangle]
pub unsafe extern "C" fn driver(
    mut s1: *const ::core::ffi::c_char,
    mut s2: *const ::core::ffi::c_char,
) {
    printf(b"%zu\n\0" as *const u8 as *const ::core::ffi::c_char, strcspn(s1, s2));
}
