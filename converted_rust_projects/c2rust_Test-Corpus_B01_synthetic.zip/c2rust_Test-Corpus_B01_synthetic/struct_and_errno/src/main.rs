#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn __error() -> *mut ::core::ffi::c_int;
    static mut __stdinp: *mut FILE;
    fn fgets(
        _: *mut ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *mut FILE,
    ) -> *mut ::core::ffi::c_char;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn strtol(
        __str: *const ::core::ffi::c_char,
        __endptr: *mut *mut ::core::ffi::c_char,
        __base: ::core::ffi::c_int,
    ) -> ::core::ffi::c_long;
}
pub type __int64_t = i64;
pub type __darwin_off_t = __int64_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct house_t {
    pub floors: ::core::ffi::c_int,
    pub bedrooms: ::core::ffi::c_int,
    pub bathrooms: ::core::ffi::c_double,
}
pub const INT_MAX: ::core::ffi::c_int = 2147483647 as ::core::ffi::c_int;
pub const INT_MIN: ::core::ffi::c_int = -(2147483647 as ::core::ffi::c_int)
    - 1 as ::core::ffi::c_int;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
unsafe extern "C" fn add_floor(mut house: *mut house_t) {
    (*house).floors += 1;
}
unsafe extern "C" fn add_bedrooms(
    mut house: *mut house_t,
    mut extra_bedrooms: ::core::ffi::c_int,
) {
    (*house).bedrooms += extra_bedrooms;
}
unsafe extern "C" fn print_house(mut house: *mut house_t) {
    printf(
        b"The house has %d floors, %d bedrooms, and %.1f bathrooms\n\0" as *const u8
            as *const ::core::ffi::c_char,
        (*house).floors,
        (*house).bedrooms,
        (*house).bathrooms,
    );
}
#[no_mangle]
pub unsafe extern "C" fn run(
    mut the_house: *mut house_t,
    mut extra_bedrooms: ::core::ffi::c_int,
) {
    print_house(the_house);
    add_floor(the_house);
    print_house(the_house);
    (*the_house).bathrooms += 1.0f64;
    print_house(the_house);
    add_bedrooms(the_house, extra_bedrooms);
    print_house(the_house);
}
unsafe extern "C" fn parse_val(
    mut str: *const ::core::ffi::c_char,
    mut val: *mut ::core::ffi::c_int,
) -> bool {
    *__error() = 0 as ::core::ffi::c_int;
    let mut endp: *mut ::core::ffi::c_char = str as *mut ::core::ffi::c_char;
    let mut tmp: ::core::ffi::c_long = strtol(str, &mut endp, 10 as ::core::ffi::c_int);
    if endp != str as *mut ::core::ffi::c_char && *__error() == 0 as ::core::ffi::c_int
        && tmp >= INT_MIN as ::core::ffi::c_long && tmp <= INT_MAX as ::core::ffi::c_long
    {
        *val = tmp as ::core::ffi::c_int;
        return true_0 != 0;
    } else {
        return false_0 != 0
    };
}
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut in_0: [::core::ffi::c_char; 100] = ::core::mem::transmute::<
        [u8; 100],
        [::core::ffi::c_char; 100],
    >(
        *b"\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",
    );
    fgets(
        in_0.as_mut_ptr(),
        ::core::mem::size_of::<[::core::ffi::c_char; 100]>() as ::core::ffi::c_int,
        __stdinp,
    );
    let mut x: ::core::ffi::c_int = 0;
    if parse_val(in_0.as_mut_ptr(), &mut x) {
        let mut the_house: house_t = {
            let mut init = house_t {
                floors: 2 as ::core::ffi::c_int,
                bedrooms: 5 as ::core::ffi::c_int,
                bathrooms: 2.5f64,
            };
            init
        };
        run(&mut the_house, x);
        run(&mut the_house, x);
    } else {
        printf(b"An error occurred\n\0" as *const u8 as *const ::core::ffi::c_char);
    }
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
