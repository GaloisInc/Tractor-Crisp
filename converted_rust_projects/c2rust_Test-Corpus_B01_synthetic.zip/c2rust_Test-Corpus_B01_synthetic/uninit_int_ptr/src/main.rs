#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn scanf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn printIntPtrLine(mut intNumber: *const ::core::ffi::c_int) {
    printf(b"%d\n\0" as *const u8 as *const ::core::ffi::c_char, *intNumber);
}
#[no_mangle]
pub unsafe extern "C" fn bad() {
    let mut data: *mut ::core::ffi::c_int = 0 as *mut ::core::ffi::c_int;
    printIntPtrLine(data);
}
#[no_mangle]
pub unsafe extern "C" fn good() {
    let mut data: ::core::ffi::c_int = 0;
    data = 5 as ::core::ffi::c_int;
    let mut data_addr: *mut ::core::ffi::c_int = 0 as *mut ::core::ffi::c_int;
    data_addr = &mut data;
    printIntPtrLine(data_addr);
}
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut x: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    scanf(
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut x as *mut ::core::ffi::c_int,
    );
    if x != 0 {
        good();
    } else {
        bad();
    }
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
