#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn fseek(
        _: *mut FILE,
        _: ::core::ffi::c_long,
        _: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn fileno(_: *mut FILE) -> ::core::ffi::c_int;
    fn snprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn fstat(_: ::core::ffi::c_int, _: *mut stat) -> ::core::ffi::c_int;
    fn GetAlertData(flag: ::core::ffi::c_int, fp: *mut FILE) -> *mut alert_data;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strerror(__errnum: ::core::ffi::c_int) -> *mut ::core::ffi::c_char;
    fn strncpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> *mut ::core::ffi::c_char;
    fn select(
        _: ::core::ffi::c_int,
        _: *mut fd_set,
        _: *mut fd_set,
        _: *mut fd_set,
        _: *mut timeval,
    ) -> ::core::ffi::c_int;
    fn __error() -> *mut ::core::ffi::c_int;
}
pub type __uint16_t = u16;
pub type __int32_t = i32;
pub type __uint32_t = u32;
pub type __int64_t = i64;
pub type __uint64_t = u64;
pub type __darwin_size_t = usize;
pub type __darwin_time_t = ::core::ffi::c_long;
pub type __darwin_blkcnt_t = __int64_t;
pub type __darwin_blksize_t = __int32_t;
pub type __darwin_dev_t = __int32_t;
pub type __darwin_gid_t = __uint32_t;
pub type __darwin_ino64_t = __uint64_t;
pub type __darwin_mode_t = __uint16_t;
pub type __darwin_off_t = __int64_t;
pub type __darwin_suseconds_t = __int32_t;
pub type __darwin_uid_t = __uint32_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type off_t = __darwin_off_t;
pub type time_t = __darwin_time_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct timespec {
    pub tv_sec: __darwin_time_t,
    pub tv_nsec: ::core::ffi::c_long,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tm {
    pub tm_sec: ::core::ffi::c_int,
    pub tm_min: ::core::ffi::c_int,
    pub tm_hour: ::core::ffi::c_int,
    pub tm_mday: ::core::ffi::c_int,
    pub tm_mon: ::core::ffi::c_int,
    pub tm_year: ::core::ffi::c_int,
    pub tm_wday: ::core::ffi::c_int,
    pub tm_yday: ::core::ffi::c_int,
    pub tm_isdst: ::core::ffi::c_int,
    pub tm_gmtoff: ::core::ffi::c_long,
    pub tm_zone: *mut ::core::ffi::c_char,
}
pub type blkcnt_t = __darwin_blkcnt_t;
pub type blksize_t = __darwin_blksize_t;
pub type dev_t = __darwin_dev_t;
pub type mode_t = __darwin_mode_t;
pub type nlink_t = __uint16_t;
pub type uid_t = __darwin_uid_t;
pub type gid_t = __darwin_gid_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct stat {
    pub st_dev: dev_t,
    pub st_mode: mode_t,
    pub st_nlink: nlink_t,
    pub st_ino: __darwin_ino64_t,
    pub st_uid: uid_t,
    pub st_gid: gid_t,
    pub st_rdev: dev_t,
    pub st_atimespec: timespec,
    pub st_mtimespec: timespec,
    pub st_ctimespec: timespec,
    pub st_birthtimespec: timespec,
    pub st_size: off_t,
    pub st_blocks: blkcnt_t,
    pub st_blksize: blksize_t,
    pub st_flags: __uint32_t,
    pub st_gen: __uint32_t,
    pub st_lspare: __int32_t,
    pub st_qspare: [__int64_t; 2],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct file_queue {
    pub last_change: time_t,
    pub year: ::core::ffi::c_int,
    pub day: ::core::ffi::c_int,
    pub flags: ::core::ffi::c_int,
    pub mon: [::core::ffi::c_char; 4],
    pub file_name: [::core::ffi::c_char; 257],
    pub fp: *mut FILE,
    pub f_status: stat,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct alert_data {
    pub rule: ::core::ffi::c_uint,
    pub level: ::core::ffi::c_uint,
    pub alertid: *mut ::core::ffi::c_char,
    pub date: *mut ::core::ffi::c_char,
    pub location: *mut ::core::ffi::c_char,
    pub comment: *mut ::core::ffi::c_char,
    pub group: *mut ::core::ffi::c_char,
    pub srcip: *mut ::core::ffi::c_char,
    pub srcport: ::core::ffi::c_int,
    pub dstip: *mut ::core::ffi::c_char,
    pub dstport: ::core::ffi::c_int,
    pub user: *mut ::core::ffi::c_char,
    pub filename: *mut ::core::ffi::c_char,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct timeval {
    pub tv_sec: __darwin_time_t,
    pub tv_usec: __darwin_suseconds_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct fd_set {
    pub fds_bits: [__int32_t; 32],
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const SEEK_END: ::core::ffi::c_int = 2 as ::core::ffi::c_int;
pub const MAX_FQUEUE: ::core::ffi::c_int = 256 as ::core::ffi::c_int;
pub const FQ_TIMEOUT: ::core::ffi::c_int = 5 as ::core::ffi::c_int;
pub const ALERTS_DAILY: [::core::ffi::c_char; 11] = unsafe {
    ::core::mem::transmute::<[u8; 11], [::core::ffi::c_char; 11]>(*b"alerts.log\0")
};
pub const CRALERT_READ_ALL: ::core::ffi::c_int = 0x4 as ::core::ffi::c_int;
pub const CRALERT_FP_SET: ::core::ffi::c_int = 0x10 as ::core::ffi::c_int;
pub const FSTAT_ERROR: [::core::ffi::c_char; 72] = unsafe {
    ::core::mem::transmute::<
        [u8; 72],
        [::core::ffi::c_char; 72],
    >(*b"(1118): Could not retrieve information of file '%s' due to [(%d)-(%s)].\0")
};
pub const FSEEK_ERROR: [::core::ffi::c_char; 64] = unsafe {
    ::core::mem::transmute::<
        [u8; 64],
        [::core::ffi::c_char; 64],
    >(*b"(1116): Could not set position in file '%s' due to [(%d)-(%s)].\0")
};
#[no_mangle]
pub unsafe extern "C" fn merror(
    mut err_template: *const ::core::ffi::c_char,
    mut file_name: *const ::core::ffi::c_char,
    mut err: ::core::ffi::c_int,
    mut err_msg: *const ::core::ffi::c_char,
) {
    let mut buffer: [::core::ffi::c_char; 256] = [0; 256];
    snprintf(
        buffer.as_mut_ptr(),
        ::core::mem::size_of::<[::core::ffi::c_char; 256]>() as size_t,
        err_template,
        file_name,
        err,
        err_msg,
    );
    fprintf(
        __stderrp,
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        buffer.as_mut_ptr(),
    );
}
static mut s_month: [*const ::core::ffi::c_char; 12] = [
    b"Jan\0" as *const u8 as *const ::core::ffi::c_char,
    b"Feb\0" as *const u8 as *const ::core::ffi::c_char,
    b"Mar\0" as *const u8 as *const ::core::ffi::c_char,
    b"Apr\0" as *const u8 as *const ::core::ffi::c_char,
    b"May\0" as *const u8 as *const ::core::ffi::c_char,
    b"Jun\0" as *const u8 as *const ::core::ffi::c_char,
    b"Jul\0" as *const u8 as *const ::core::ffi::c_char,
    b"Aug\0" as *const u8 as *const ::core::ffi::c_char,
    b"Sep\0" as *const u8 as *const ::core::ffi::c_char,
    b"Oct\0" as *const u8 as *const ::core::ffi::c_char,
    b"Nov\0" as *const u8 as *const ::core::ffi::c_char,
    b"Dec\0" as *const u8 as *const ::core::ffi::c_char,
];
unsafe extern "C" fn file_sleep() {
    let mut fp_timeout: timeval = timeval { tv_sec: 0, tv_usec: 0 };
    fp_timeout.tv_sec = FQ_TIMEOUT as __darwin_time_t;
    fp_timeout.tv_usec = 0 as ::core::ffi::c_int as __darwin_suseconds_t;
    select(
        0 as ::core::ffi::c_int,
        0 as *mut fd_set,
        0 as *mut fd_set,
        0 as *mut fd_set,
        &mut fp_timeout,
    );
}
unsafe extern "C" fn GetFile_Queue(mut fileq: *mut file_queue) {
    (*fileq).file_name[0 as ::core::ffi::c_int as usize] = '\0' as i32
        as ::core::ffi::c_char;
    (*fileq).file_name[MAX_FQUEUE as usize] = '\0' as i32 as ::core::ffi::c_char;
    snprintf(
        (*fileq).file_name.as_mut_ptr(),
        MAX_FQUEUE as size_t,
        b"%s\0" as *const u8 as *const ::core::ffi::c_char,
        if (*fileq).flags & CRALERT_FP_SET != 0 {
            b"<stdin>\0" as *const u8 as *const ::core::ffi::c_char
        } else {
            ALERTS_DAILY.as_ptr()
        },
    );
}
unsafe extern "C" fn Handle_Queue(
    mut fileq: *mut file_queue,
    mut flags: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    if flags & CRALERT_FP_SET == 0 {
        if !(*fileq).fp.is_null() {
            fclose((*fileq).fp);
            (*fileq).fp = 0 as *mut FILE;
        }
        (*fileq).fp = fopen(
            (*fileq).file_name.as_mut_ptr(),
            b"r\0" as *const u8 as *const ::core::ffi::c_char,
        ) as *mut FILE;
        if (*fileq).fp.is_null() {
            return 0 as ::core::ffi::c_int;
        }
    }
    if flags & CRALERT_READ_ALL == 0 {
        if (*fileq).fp.is_null() {
            return 0 as ::core::ffi::c_int;
        }
        if fseek((*fileq).fp, 0 as ::core::ffi::c_long, SEEK_END)
            < 0 as ::core::ffi::c_int
        {
            merror(
                FSEEK_ERROR.as_ptr(),
                (*fileq).file_name.as_mut_ptr(),
                *__error(),
                strerror(*__error()),
            );
            fclose((*fileq).fp);
            (*fileq).fp = 0 as *mut FILE;
            return -(1 as ::core::ffi::c_int);
        }
    }
    if !(*fileq).fp.is_null() {
        if fstat(fileno((*fileq).fp), &mut (*fileq).f_status) < 0 as ::core::ffi::c_int {
            merror(
                FSTAT_ERROR.as_ptr(),
                (*fileq).file_name.as_mut_ptr(),
                *__error(),
                strerror(*__error()),
            );
            fclose((*fileq).fp);
            (*fileq).fp = 0 as *mut FILE;
            return -(1 as ::core::ffi::c_int);
        }
    }
    (*fileq).last_change = (*fileq).f_status.st_mtimespec.tv_sec as time_t;
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn Init_FileQueue(
    mut fileq: *mut file_queue,
    mut p: *const tm,
    mut flags: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    if flags & CRALERT_FP_SET == 0 {
        (*fileq).fp = 0 as *mut FILE;
    }
    (*fileq).last_change = 0 as time_t;
    (*fileq).flags = 0 as ::core::ffi::c_int;
    (*fileq).day = (*p).tm_mday;
    (*fileq).year = (*p).tm_year + 1900 as ::core::ffi::c_int;
    strncpy((*fileq).mon.as_mut_ptr(), s_month[(*p).tm_mon as usize], 3 as size_t);
    memset(
        (*fileq).file_name.as_mut_ptr() as *mut ::core::ffi::c_void,
        '\0' as i32,
        (MAX_FQUEUE + 1 as ::core::ffi::c_int) as size_t,
    );
    (*fileq).flags = flags;
    GetFile_Queue(fileq);
    if Handle_Queue(fileq, (*fileq).flags) < 0 as ::core::ffi::c_int {
        return -(1 as ::core::ffi::c_int);
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn Read_FileMon(
    mut fileq: *mut file_queue,
    mut p: *const tm,
    mut timeout: ::core::ffi::c_uint,
) -> *mut alert_data {
    let mut i: ::core::ffi::c_uint = 0 as ::core::ffi::c_uint;
    let mut al_data: *mut alert_data = 0 as *mut alert_data;
    if (*fileq).fp.is_null() {
        if Handle_Queue(fileq, 0 as ::core::ffi::c_int) != 1 as ::core::ffi::c_int {
            file_sleep();
            return 0 as *mut alert_data;
        }
    }
    if (*fileq).fp.is_null() {
        return 0 as *mut alert_data;
    }
    al_data = GetAlertData((*fileq).flags, (*fileq).fp);
    if !al_data.is_null() {
        return al_data;
    }
    (*fileq).day = (*p).tm_mday;
    (*fileq).year = (*p).tm_year + 1900 as ::core::ffi::c_int;
    strncpy((*fileq).mon.as_mut_ptr(), s_month[(*p).tm_mon as usize], 3 as size_t);
    GetFile_Queue(fileq);
    if Handle_Queue(fileq, 0 as ::core::ffi::c_int) != 1 as ::core::ffi::c_int {
        file_sleep();
        return 0 as *mut alert_data;
    }
    while i < timeout {
        al_data = GetAlertData((*fileq).flags, (*fileq).fp);
        if !al_data.is_null() {
            return al_data;
        }
        i = i.wrapping_add(1);
        file_sleep();
    }
    return 0 as *mut alert_data;
}
