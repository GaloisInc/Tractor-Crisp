#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn clearerr(_: *mut FILE);
    fn feof(_: *mut FILE) -> ::core::ffi::c_int;
    fn fgets(
        _: *mut ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *mut FILE,
    ) -> *mut ::core::ffi::c_char;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn fseek(
        _: *mut FILE,
        _: ::core::ffi::c_long,
        _: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn perror(_: *const ::core::ffi::c_char);
    fn calloc(__count: size_t, __size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn realloc(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn atoi(_: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
    fn exit(_: ::core::ffi::c_int) -> !;
    fn strchr(
        __s: *const ::core::ffi::c_char,
        __c: ::core::ffi::c_int,
    ) -> *mut ::core::ffi::c_char;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strncmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> ::core::ffi::c_int;
    fn strncpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> *mut ::core::ffi::c_char;
    fn strrchr(
        __s: *const ::core::ffi::c_char,
        __c: ::core::ffi::c_int,
    ) -> *mut ::core::ffi::c_char;
    fn strstr(
        __big: *const ::core::ffi::c_char,
        __little: *const ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
    fn strdup(__s1: *const ::core::ffi::c_char) -> *mut ::core::ffi::c_char;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct alert_data {
    pub rule: ::core::ffi::c_uint,
    pub level: ::core::ffi::c_uint,
    pub alertid: *mut ::core::ffi::c_char,
    pub date: *mut ::core::ffi::c_char,
    pub location: *mut ::core::ffi::c_char,
    pub comment: *mut ::core::ffi::c_char,
    pub group: *mut ::core::ffi::c_char,
    pub srcip: *mut ::core::ffi::c_char,
    pub srcport: ::core::ffi::c_int,
    pub dstip: *mut ::core::ffi::c_char,
    pub dstport: ::core::ffi::c_int,
    pub user: *mut ::core::ffi::c_char,
    pub filename: *mut ::core::ffi::c_char,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const SEEK_CUR: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const CRALERT_MAIL_SET: ::core::ffi::c_int = 0x1 as ::core::ffi::c_int;
pub const EXIT_FAILURE: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const OS_MAXSTR: ::core::ffi::c_int = 1024 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn os_calloc(
    mut num: size_t,
    mut size: size_t,
) -> *mut ::core::ffi::c_void {
    let mut out: *mut ::core::ffi::c_void = calloc(num, size);
    if out.is_null() {
        fprintf(
            __stderrp,
            b"Memory allocation failed in os_calloc\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        exit(EXIT_FAILURE);
    }
    return out;
}
#[no_mangle]
pub unsafe extern "C" fn os_realloc(
    mut ptr: *mut ::core::ffi::c_void,
    mut new_size: size_t,
) -> *mut ::core::ffi::c_void {
    let mut out: *mut ::core::ffi::c_void = realloc(ptr, new_size);
    if out.is_null() {
        fprintf(
            __stderrp,
            b"Memory allocation failed in os_realloc\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        exit(EXIT_FAILURE);
    }
    return out;
}
#[no_mangle]
pub unsafe extern "C" fn os_strdup(
    mut str: *const ::core::ffi::c_char,
) -> *mut ::core::ffi::c_char {
    if str.is_null() {
        fprintf(
            __stderrp,
            b"NULL string passed to os_strdup\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        exit(EXIT_FAILURE);
    }
    let mut dup: *mut ::core::ffi::c_char = strdup(str);
    if dup.is_null() {
        fprintf(
            __stderrp,
            b"Memory allocation failed in os_strdup\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        exit(EXIT_FAILURE);
    }
    return dup;
}
pub const ALERT_BEGIN: [::core::ffi::c_char; 9] = unsafe {
    ::core::mem::transmute::<[u8; 9], [::core::ffi::c_char; 9]>(*b"** Alert\0")
};
pub const ALERT_BEGIN_SZ: ::core::ffi::c_int = 8 as ::core::ffi::c_int;
pub const RULE_BEGIN: [::core::ffi::c_char; 7] = unsafe {
    ::core::mem::transmute::<[u8; 7], [::core::ffi::c_char; 7]>(*b"Rule: \0")
};
pub const RULE_BEGIN_SZ: ::core::ffi::c_int = 6 as ::core::ffi::c_int;
pub const SRCIP_BEGIN: [::core::ffi::c_char; 9] = unsafe {
    ::core::mem::transmute::<[u8; 9], [::core::ffi::c_char; 9]>(*b"Src IP: \0")
};
pub const SRCIP_BEGIN_SZ: ::core::ffi::c_int = 8 as ::core::ffi::c_int;
pub const SRCPORT_BEGIN: [::core::ffi::c_char; 11] = unsafe {
    ::core::mem::transmute::<[u8; 11], [::core::ffi::c_char; 11]>(*b"Src Port: \0")
};
pub const SRCPORT_BEGIN_SZ: ::core::ffi::c_int = 10 as ::core::ffi::c_int;
pub const DSTIP_BEGIN: [::core::ffi::c_char; 9] = unsafe {
    ::core::mem::transmute::<[u8; 9], [::core::ffi::c_char; 9]>(*b"Dst IP: \0")
};
pub const DSTIP_BEGIN_SZ: ::core::ffi::c_int = 8 as ::core::ffi::c_int;
pub const DSTPORT_BEGIN: [::core::ffi::c_char; 11] = unsafe {
    ::core::mem::transmute::<[u8; 11], [::core::ffi::c_char; 11]>(*b"Dst Port: \0")
};
pub const DSTPORT_BEGIN_SZ: ::core::ffi::c_int = 10 as ::core::ffi::c_int;
pub const USER_BEGIN: [::core::ffi::c_char; 7] = unsafe {
    ::core::mem::transmute::<[u8; 7], [::core::ffi::c_char; 7]>(*b"User: \0")
};
pub const USER_BEGIN_SZ: ::core::ffi::c_int = 6 as ::core::ffi::c_int;
pub const ALERT_MAIL: [::core::ffi::c_char; 5] = unsafe {
    ::core::mem::transmute::<[u8; 5], [::core::ffi::c_char; 5]>(*b"mail\0")
};
pub const ALERT_MAIL_SZ: ::core::ffi::c_int = 4 as ::core::ffi::c_int;
pub const LOG_LIMIT: ::core::ffi::c_int = 100 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn FreeAlertData(mut al_data: *mut alert_data) {
    let mut p: *mut *mut ::core::ffi::c_char = 0 as *mut *mut ::core::ffi::c_char;
    if !(*al_data).alertid.is_null() {
        free((*al_data).alertid as *mut ::core::ffi::c_void);
        (*al_data).alertid = 0 as *mut ::core::ffi::c_char;
    }
    if !(*al_data).date.is_null() {
        free((*al_data).date as *mut ::core::ffi::c_void);
        (*al_data).date = 0 as *mut ::core::ffi::c_char;
    }
    if !(*al_data).location.is_null() {
        free((*al_data).location as *mut ::core::ffi::c_void);
        (*al_data).location = 0 as *mut ::core::ffi::c_char;
    }
    if !(*al_data).comment.is_null() {
        free((*al_data).comment as *mut ::core::ffi::c_void);
        (*al_data).comment = 0 as *mut ::core::ffi::c_char;
    }
    if !(*al_data).group.is_null() {
        free((*al_data).group as *mut ::core::ffi::c_void);
        (*al_data).group = 0 as *mut ::core::ffi::c_char;
    }
    if !(*al_data).srcip.is_null() {
        free((*al_data).srcip as *mut ::core::ffi::c_void);
        (*al_data).srcip = 0 as *mut ::core::ffi::c_char;
    }
    if !(*al_data).dstip.is_null() {
        free((*al_data).dstip as *mut ::core::ffi::c_void);
        (*al_data).dstip = 0 as *mut ::core::ffi::c_char;
    }
    if !(*al_data).user.is_null() {
        free((*al_data).user as *mut ::core::ffi::c_void);
        (*al_data).user = 0 as *mut ::core::ffi::c_char;
    }
    if !(*al_data).filename.is_null() {
        free((*al_data).filename as *mut ::core::ffi::c_void);
        (*al_data).filename = 0 as *mut ::core::ffi::c_char;
    }
    free(al_data as *mut ::core::ffi::c_void);
    al_data = 0 as *mut alert_data;
}
#[no_mangle]
pub unsafe extern "C" fn GetAlertData(
    mut flag: ::core::ffi::c_int,
    mut fp: *mut FILE,
) -> *mut alert_data {
    let mut current_block: u64;
    let mut al_data: *mut alert_data = 0 as *mut alert_data;
    al_data = os_calloc(1 as size_t, ::core::mem::size_of::<alert_data>() as size_t)
        as *mut alert_data;
    let mut _r: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut issyscheck: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut log_size: size_t = 0 as size_t;
    let mut p: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut str: [::core::ffi::c_char; 1025] = [0; 1025];
    str[OS_MAXSTR as usize] = '\0' as i32 as ::core::ffi::c_char;
    loop {
        if fgets(str.as_mut_ptr(), OS_MAXSTR, fp).is_null() {
            current_block = 3567897568976182940;
            break;
        }
        if strncmp(ALERT_BEGIN.as_ptr(), str.as_mut_ptr(), ALERT_BEGIN_SZ as size_t)
            == 0 as ::core::ffi::c_int
        {
            let mut m: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
            let mut z: size_t = 0 as size_t;
            if _r == 2 as ::core::ffi::c_int {
                if !(fseek(
                    fp,
                    strlen(str.as_mut_ptr()).wrapping_neg() as ::core::ffi::c_long,
                    SEEK_CUR,
                ) != -(1 as ::core::ffi::c_int))
                {
                    current_block = 7145285859130133894;
                    break;
                }
                return al_data;
            } else {
                p = str
                    .as_mut_ptr()
                    .offset(ALERT_BEGIN_SZ as isize)
                    .offset(1 as ::core::ffi::c_int as isize);
                m = strstr(p, b":\0" as *const u8 as *const ::core::ffi::c_char);
                if m.is_null() {
                    continue;
                }
                z = strlen(p).wrapping_sub(strlen(m));
                (*al_data).alertid = os_realloc(
                    (*al_data).alertid as *mut ::core::ffi::c_void,
                    z
                        .wrapping_add(1 as size_t)
                        .wrapping_mul(
                            ::core::mem::size_of::<::core::ffi::c_char>() as size_t,
                        ),
                ) as *mut ::core::ffi::c_char;
                strncpy((*al_data).alertid, p, z);
                *(*al_data).alertid.offset(z as isize) = '\0' as i32
                    as ::core::ffi::c_char;
                p = strchr(p, ' ' as i32);
                if p.is_null() {
                    continue;
                }
                p = p.offset(1);
                if flag & CRALERT_MAIL_SET != 0
                    && strncmp(ALERT_MAIL.as_ptr(), p, ALERT_MAIL_SZ as size_t)
                        != 0 as ::core::ffi::c_int
                {
                    continue;
                }
                p = strchr(p, '-' as i32);
                if !p.is_null() {
                    p = p.offset(1);
                    while *p as ::core::ffi::c_int == ' ' as i32 {
                        p = p.offset(1);
                    }
                    if !(*al_data).group.is_null() {
                        free((*al_data).group as *mut ::core::ffi::c_void);
                        (*al_data).group = 0 as *mut ::core::ffi::c_char;
                    }
                    (*al_data).group = os_strdup(p);
                    p = strrchr((*al_data).group, '\n' as i32);
                    if !p.is_null() {
                        *p = '\0' as i32 as ::core::ffi::c_char;
                    }
                    if !(*al_data).group.is_null()
                        && !strstr(
                                (*al_data).group,
                                b"syscheck\0" as *const u8 as *const ::core::ffi::c_char,
                            )
                            .is_null()
                    {
                        issyscheck = 1 as ::core::ffi::c_int;
                    }
                }
                _r = 1 as ::core::ffi::c_int;
            }
        } else {
            if _r < 1 as ::core::ffi::c_int {
                continue;
            }
            if _r == 1 as ::core::ffi::c_int {
                p = strrchr(str.as_mut_ptr(), '\n' as i32);
                if !p.is_null() {
                    *p = '\0' as i32 as ::core::ffi::c_char;
                }
                p = strchr(str.as_mut_ptr(), ':' as i32);
                if !p.is_null() {
                    p = strchr(p, ' ' as i32);
                    if !p.is_null() {
                        *p = '\0' as i32 as ::core::ffi::c_char;
                        p = p.offset(1);
                    } else {
                        perror(
                            b"date of location not NULL\0" as *const u8
                                as *const ::core::ffi::c_char,
                        );
                        current_block = 7145285859130133894;
                        break;
                    }
                }
                if !(*al_data).date.is_null() || !(*al_data).location.is_null()
                    || p.is_null()
                {
                    perror(
                        b"date or location not NULL or p is NULL\0" as *const u8
                            as *const ::core::ffi::c_char,
                    );
                    current_block = 7145285859130133894;
                    break;
                } else {
                    (*al_data).date = os_strdup(str.as_mut_ptr());
                    (*al_data).location = os_strdup(p);
                    _r = 2 as ::core::ffi::c_int;
                    log_size = 0 as size_t;
                }
            } else {
                if !(_r == 2 as ::core::ffi::c_int) {
                    continue;
                }
                if strncmp(
                    RULE_BEGIN.as_ptr(),
                    str.as_mut_ptr(),
                    RULE_BEGIN_SZ as size_t,
                ) == 0 as ::core::ffi::c_int
                {
                    p = strrchr(str.as_mut_ptr(), '\n' as i32);
                    if !p.is_null() {
                        *p = '\0' as i32 as ::core::ffi::c_char;
                    }
                    p = str.as_mut_ptr().offset(RULE_BEGIN_SZ as isize);
                    (*al_data).rule = atoi(p) as ::core::ffi::c_uint;
                    p = strchr(p, ' ' as i32);
                    if !p.is_null() {
                        p = p.offset(1);
                        p = strchr(p, ' ' as i32);
                        if !p.is_null() {
                            p = p.offset(1);
                        }
                    }
                    if p.is_null() {
                        current_block = 7145285859130133894;
                        break;
                    }
                    (*al_data).level = atoi(p) as ::core::ffi::c_uint;
                    p = strchr(p, '\'' as i32);
                    if p.is_null() {
                        current_block = 7145285859130133894;
                        break;
                    }
                    p = p.offset(1);
                    if !(*al_data).comment.is_null() {
                        free((*al_data).comment as *mut ::core::ffi::c_void);
                        (*al_data).comment = 0 as *mut ::core::ffi::c_char;
                    }
                    (*al_data).comment = os_strdup(p);
                    p = strrchr((*al_data).comment, '\'' as i32);
                    if p.is_null() {
                        current_block = 7145285859130133894;
                        break;
                    }
                    *p = '\0' as i32 as ::core::ffi::c_char;
                } else if strncmp(
                    SRCIP_BEGIN.as_ptr(),
                    str.as_mut_ptr(),
                    SRCIP_BEGIN_SZ as size_t,
                ) == 0 as ::core::ffi::c_int
                {
                    p = strrchr(str.as_mut_ptr(), '\n' as i32);
                    if !p.is_null() {
                        *p = '\0' as i32 as ::core::ffi::c_char;
                    }
                    p = str.as_mut_ptr().offset(SRCIP_BEGIN_SZ as isize);
                    if !(*al_data).srcip.is_null() {
                        free((*al_data).srcip as *mut ::core::ffi::c_void);
                        (*al_data).srcip = 0 as *mut ::core::ffi::c_char;
                    }
                    (*al_data).srcip = os_strdup(p);
                } else if strncmp(
                    SRCPORT_BEGIN.as_ptr(),
                    str.as_mut_ptr(),
                    SRCPORT_BEGIN_SZ as size_t,
                ) == 0 as ::core::ffi::c_int
                {
                    p = strrchr(str.as_mut_ptr(), '\n' as i32);
                    if !p.is_null() {
                        *p = '\0' as i32 as ::core::ffi::c_char;
                    }
                    p = str.as_mut_ptr().offset(SRCPORT_BEGIN_SZ as isize);
                    (*al_data).srcport = atoi(p);
                } else if strncmp(
                    DSTIP_BEGIN.as_ptr(),
                    str.as_mut_ptr(),
                    DSTIP_BEGIN_SZ as size_t,
                ) == 0 as ::core::ffi::c_int
                {
                    p = strrchr(str.as_mut_ptr(), '\n' as i32);
                    if !p.is_null() {
                        *p = '\0' as i32 as ::core::ffi::c_char;
                    }
                    p = str.as_mut_ptr().offset(DSTIP_BEGIN_SZ as isize);
                    if !(*al_data).dstip.is_null() {
                        free((*al_data).dstip as *mut ::core::ffi::c_void);
                        (*al_data).dstip = 0 as *mut ::core::ffi::c_char;
                    }
                    (*al_data).dstip = os_strdup(p);
                } else if strncmp(
                    DSTPORT_BEGIN.as_ptr(),
                    str.as_mut_ptr(),
                    DSTPORT_BEGIN_SZ as size_t,
                ) == 0 as ::core::ffi::c_int
                {
                    p = strrchr(str.as_mut_ptr(), '\n' as i32);
                    if !p.is_null() {
                        *p = '\0' as i32 as ::core::ffi::c_char;
                    }
                    p = str.as_mut_ptr().offset(DSTPORT_BEGIN_SZ as isize);
                    (*al_data).dstport = atoi(p);
                } else if strncmp(
                    USER_BEGIN.as_ptr(),
                    str.as_mut_ptr(),
                    USER_BEGIN_SZ as size_t,
                ) == 0 as ::core::ffi::c_int
                {
                    p = strrchr(str.as_mut_ptr(), '\n' as i32);
                    if !p.is_null() {
                        *p = '\0' as i32 as ::core::ffi::c_char;
                    }
                    p = str.as_mut_ptr().offset(USER_BEGIN_SZ as isize);
                    if !(*al_data).user.is_null() {
                        free((*al_data).user as *mut ::core::ffi::c_void);
                        (*al_data).user = 0 as *mut ::core::ffi::c_char;
                    }
                    (*al_data).user = os_strdup(p);
                } else if log_size < LOG_LIMIT as size_t {
                    p = strrchr(str.as_mut_ptr(), '\n' as i32);
                    if !p.is_null() {
                        *p = '\0' as i32 as ::core::ffi::c_char;
                    }
                    if issyscheck == 1 as ::core::ffi::c_int {
                        if strncmp(
                            str.as_mut_ptr(),
                            b"Integrity checksum changed for: '\0" as *const u8
                                as *const ::core::ffi::c_char,
                            33 as size_t,
                        ) == 0 as ::core::ffi::c_int
                        {
                            (*al_data).filename = strdup(
                                str.as_mut_ptr().offset(33 as ::core::ffi::c_int as isize),
                            );
                            if !(*al_data).filename.is_null() {
                                *(*al_data)
                                    .filename
                                    .offset(
                                        strlen((*al_data).filename).wrapping_sub(1 as size_t)
                                            as isize,
                                    ) = '\0' as i32 as ::core::ffi::c_char;
                            }
                        }
                        issyscheck = 0 as ::core::ffi::c_int;
                    }
                }
            }
        }
    }
    match current_block {
        3567897568976182940 => {
            if feof(fp) != 0 && _r == 2 as ::core::ffi::c_int {
                return al_data;
            }
        }
        _ => {}
    }
    FreeAlertData(al_data);
    clearerr(fp);
    return 0 as *mut alert_data;
}
