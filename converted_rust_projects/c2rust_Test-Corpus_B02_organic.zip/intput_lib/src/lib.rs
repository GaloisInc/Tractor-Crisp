#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn memcmp(
        __s1: *const ::core::ffi::c_void,
        __s2: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> ::core::ffi::c_int;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memmove(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn free(_: *mut ::core::ffi::c_void);
    fn realloc(
        __ptr: *mut ::core::ffi::c_void,
        __size: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn sprintf(
        _: *mut ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct C2RustUnnamed {
    pub key: ::core::ffi::c_int,
    pub value: ::core::ffi::c_int,
}
pub type ptrdiff_t = __darwin_ptrdiff_t;
pub type __darwin_ptrdiff_t = isize;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct stbds_array_header {
    pub length: size_t,
    pub capacity: size_t,
    pub hash_table: *mut ::core::ffi::c_void,
    pub temp: ptrdiff_t,
}
pub type size_t = __darwin_size_t;
pub type __darwin_size_t = usize;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct stbds_hash_index {
    pub temp_key: *mut ::core::ffi::c_char,
    pub slot_count: size_t,
    pub used_count: size_t,
    pub used_count_threshold: size_t,
    pub used_count_shrink_threshold: size_t,
    pub tombstone_count: size_t,
    pub tombstone_count_threshold: size_t,
    pub seed: size_t,
    pub slot_count_log2: size_t,
    pub string: stbds_string_arena,
    pub storage: *mut stbds_hash_bucket,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct stbds_hash_bucket {
    pub hash: [size_t; 8],
    pub index: [ptrdiff_t; 8],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct stbds_string_arena {
    pub storage: *mut stbds_string_block,
    pub remaining: size_t,
    pub block: ::core::ffi::c_uchar,
    pub mode: ::core::ffi::c_uchar,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct stbds_string_block {
    pub next: *mut stbds_string_block,
    pub storage: [::core::ffi::c_char; 8],
}
pub const STBDS_SH_DEFAULT: C2RustUnnamed_0 = 1;
pub const STBDS_SH_ARENA: C2RustUnnamed_0 = 3;
pub const STBDS_SH_STRDUP: C2RustUnnamed_0 = 2;
pub type C2RustUnnamed_0 = ::core::ffi::c_uint;
pub const STBDS_SH_NONE: C2RustUnnamed_0 = 0;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const STBDS_HM_STRING: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn stbds_arrgrowf(
    mut a: *mut ::core::ffi::c_void,
    mut elemsize: size_t,
    mut addlen: size_t,
    mut min_cap: size_t,
) -> *mut ::core::ffi::c_void {
    let mut temp: stbds_array_header = {
        let mut init = stbds_array_header {
            length: 0 as size_t,
            capacity: 0,
            hash_table: 0 as *mut ::core::ffi::c_void,
            temp: 0,
        };
        init
    };
    let mut b: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
    let mut min_len: size_t = ((if !a.is_null() {
        (*(a as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize)))
            .length as ptrdiff_t
    } else {
        0 as ptrdiff_t
    }) as size_t)
        .wrapping_add(addlen);
    if min_len > min_cap {
        min_cap = min_len;
    }
    if min_cap
        <= (if !a.is_null() {
            (*(a as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize)))
                .capacity
        } else {
            0 as size_t
        })
    {
        return a;
    }
    if min_cap
        < (2 as size_t)
            .wrapping_mul(
                (if !a.is_null() {
                    (*(a as *mut stbds_array_header)
                        .offset(-(1 as ::core::ffi::c_int as isize)))
                        .capacity
                } else {
                    0 as size_t
                }),
            )
    {
        min_cap = (2 as size_t)
            .wrapping_mul(
                (if !a.is_null() {
                    (*(a as *mut stbds_array_header)
                        .offset(-(1 as ::core::ffi::c_int as isize)))
                        .capacity
                } else {
                    0 as size_t
                }),
            );
    } else if min_cap < 4 as size_t {
        min_cap = 4 as size_t;
    }
    b = realloc(
        (if !a.is_null() {
            (a as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize))
        } else {
            0 as *mut stbds_array_header
        }) as *mut ::core::ffi::c_void,
        elemsize
            .wrapping_mul(min_cap)
            .wrapping_add(::core::mem::size_of::<stbds_array_header>() as size_t),
    );
    b = (b as *mut ::core::ffi::c_char)
        .offset(::core::mem::size_of::<stbds_array_header>() as usize as isize)
        as *mut ::core::ffi::c_void;
    if a.is_null() {
        (*(b as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize)))
            .length = 0 as size_t;
        let ref mut fresh8 = (*(b as *mut stbds_array_header)
            .offset(-(1 as ::core::ffi::c_int as isize)))
            .hash_table;
        *fresh8 = 0 as *mut ::core::ffi::c_void;
        (*(b as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize)))
            .temp = 0 as ptrdiff_t;
    }
    (*(b as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize)))
        .capacity = min_cap;
    return b;
}
#[no_mangle]
pub unsafe extern "C" fn stbds_arrfreef(mut a: *mut ::core::ffi::c_void) {
    free(
        (a as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize))
            as *mut ::core::ffi::c_void,
    );
}
pub const STBDS_BUCKET_LENGTH: ::core::ffi::c_int = 8 as ::core::ffi::c_int;
pub const STBDS_BUCKET_MASK: ::core::ffi::c_int = STBDS_BUCKET_LENGTH
    - 1 as ::core::ffi::c_int;
pub const STBDS_INDEX_EMPTY: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
pub const STBDS_INDEX_DELETED: ::core::ffi::c_int = -(2 as ::core::ffi::c_int);
pub const STBDS_HASH_EMPTY: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
pub const STBDS_HASH_DELETED: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
static mut stbds_hash_seed: size_t = 0x31415926 as size_t;
#[no_mangle]
pub unsafe extern "C" fn stbds_rand_seed(mut seed: size_t) {
    stbds_hash_seed = seed;
}
pub const STBDS_SIZE_T_BITS: usize = (::core::mem::size_of::<size_t>() as usize)
    .wrapping_mul(8 as usize);
unsafe extern "C" fn stbds_probe_position(
    mut hash: size_t,
    mut slot_count: size_t,
    mut slot_log2: size_t,
) -> size_t {
    let mut pos: size_t = 0;
    pos = hash & slot_count.wrapping_sub(1 as size_t);
    return pos;
}
unsafe extern "C" fn stbds_log2(mut slot_count: size_t) -> size_t {
    let mut n: size_t = 0 as size_t;
    while slot_count > 1 as size_t {
        slot_count >>= 1 as ::core::ffi::c_int;
        n = n.wrapping_add(1);
    }
    return n;
}
unsafe extern "C" fn stbds_make_hash_index(
    mut slot_count: size_t,
    mut ot: *mut stbds_hash_index,
) -> *mut stbds_hash_index {
    let mut t: *mut stbds_hash_index = 0 as *mut stbds_hash_index;
    t = realloc(
        0 as *mut ::core::ffi::c_void,
        (slot_count
            >> (if 8 as ::core::ffi::c_int == 8 as ::core::ffi::c_int {
                3 as ::core::ffi::c_int
            } else {
                2 as ::core::ffi::c_int
            }))
            .wrapping_mul(::core::mem::size_of::<stbds_hash_bucket>() as size_t)
            .wrapping_add(::core::mem::size_of::<stbds_hash_index>() as size_t)
            .wrapping_add(64 as size_t)
            .wrapping_sub(1 as size_t),
    ) as *mut stbds_hash_index;
    (*t).storage = ((t.offset(1 as ::core::ffi::c_int as isize) as size_t)
        .wrapping_add(64 as size_t)
        .wrapping_sub(1 as size_t)
        & !(64 as ::core::ffi::c_int - 1 as ::core::ffi::c_int) as size_t)
        as *mut stbds_hash_bucket;
    (*t).slot_count = slot_count;
    (*t).slot_count_log2 = stbds_log2(slot_count);
    (*t).tombstone_count = 0 as size_t;
    (*t).used_count = 0 as size_t;
    (*t).used_count_threshold = slot_count
        .wrapping_sub(slot_count >> 2 as ::core::ffi::c_int);
    (*t).tombstone_count_threshold = (slot_count >> 3 as ::core::ffi::c_int)
        .wrapping_add(slot_count >> 4 as ::core::ffi::c_int);
    (*t).used_count_shrink_threshold = slot_count >> 2 as ::core::ffi::c_int;
    if slot_count <= STBDS_BUCKET_LENGTH as size_t {
        (*t).used_count_shrink_threshold = 0 as size_t;
    }
    if !((*t).used_count_threshold.wrapping_add((*t).tombstone_count_threshold)
        < (*t).slot_count) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"stbds_make_hash_index\0")
                .as_ptr(),
            b"lib.c\0" as *const u8 as *const ::core::ffi::c_char,
            401 as ::core::ffi::c_int,
            b"t->used_count_threshold + t->tombstone_count_threshold < t->slot_count\0"
                as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !ot.is_null() {
        (*t).string = (*ot).string;
        (*t).seed = (*ot).seed;
    } else {
        let mut a: size_t = 0;
        let mut b: size_t = 0;
        let mut temp: size_t = 0;
        memset(
            &mut (*t).string as *mut stbds_string_arena as *mut ::core::ffi::c_void,
            0 as ::core::ffi::c_int,
            ::core::mem::size_of::<stbds_string_arena>() as size_t,
        );
        (*t).seed = stbds_hash_seed;
        temp = (0x87b0b0fd as ::core::ffi::c_uint ^ 2147001325 as ::core::ffi::c_uint)
            as size_t;
        temp <<= 16 as ::core::ffi::c_int;
        temp <<= 16 as ::core::ffi::c_int;
        temp >>= 16 as ::core::ffi::c_int;
        temp >>= 16 as ::core::ffi::c_int;
        a = 0x27bb2ee6 as size_t;
        a <<= 16 as ::core::ffi::c_int;
        a <<= 16 as ::core::ffi::c_int;
        a ^= temp ^ 2147001325 as size_t;
        temp = (0xb504f32d as ::core::ffi::c_uint ^ 715136305 as ::core::ffi::c_uint)
            as size_t;
        temp <<= 16 as ::core::ffi::c_int;
        temp <<= 16 as ::core::ffi::c_int;
        temp >>= 16 as ::core::ffi::c_int;
        temp >>= 16 as ::core::ffi::c_int;
        b = 0 as size_t;
        b <<= 16 as ::core::ffi::c_int;
        b <<= 16 as ::core::ffi::c_int;
        b ^= temp ^ 715136305 as size_t;
        stbds_hash_seed = stbds_hash_seed.wrapping_mul(a).wrapping_add(b);
    }
    let mut i: size_t = 0;
    let mut j: size_t = 0;
    i = 0 as size_t;
    while i
        < slot_count
            >> (if STBDS_BUCKET_LENGTH == 8 as ::core::ffi::c_int {
                3 as ::core::ffi::c_int
            } else {
                2 as ::core::ffi::c_int
            })
    {
        let mut b_0: *mut stbds_hash_bucket = &mut *(*t).storage.offset(i as isize)
            as *mut stbds_hash_bucket;
        j = 0 as size_t;
        while j < STBDS_BUCKET_LENGTH as size_t {
            (*b_0).hash[j as usize] = STBDS_HASH_EMPTY as size_t;
            j = j.wrapping_add(1);
        }
        j = 0 as size_t;
        while j < STBDS_BUCKET_LENGTH as size_t {
            (*b_0).index[j as usize] = STBDS_INDEX_EMPTY as ptrdiff_t;
            j = j.wrapping_add(1);
        }
        i = i.wrapping_add(1);
    }
    if !ot.is_null() {
        let mut i_0: size_t = 0;
        let mut j_0: size_t = 0;
        (*t).used_count = (*ot).used_count;
        i_0 = 0 as size_t;
        while i_0
            < (*ot).slot_count
                >> (if STBDS_BUCKET_LENGTH == 8 as ::core::ffi::c_int {
                    3 as ::core::ffi::c_int
                } else {
                    2 as ::core::ffi::c_int
                })
        {
            let mut ob: *mut stbds_hash_bucket = &mut *(*ot).storage.offset(i_0 as isize)
                as *mut stbds_hash_bucket;
            j_0 = 0 as size_t;
            while j_0 < STBDS_BUCKET_LENGTH as size_t {
                if (*ob).index[j_0 as usize] >= 0 as ptrdiff_t {
                    let mut hash: size_t = (*ob).hash[j_0 as usize];
                    let mut pos: size_t = stbds_probe_position(
                        hash,
                        (*t).slot_count,
                        (*t).slot_count_log2,
                    );
                    let mut step: size_t = STBDS_BUCKET_LENGTH as size_t;
                    's_177: loop {
                        let mut limit: size_t = 0;
                        let mut z: size_t = 0;
                        let mut bucket: *mut stbds_hash_bucket = 0
                            as *mut stbds_hash_bucket;
                        bucket = &mut *(*t)
                            .storage
                            .offset(
                                (pos
                                    >> (if STBDS_BUCKET_LENGTH == 8 as ::core::ffi::c_int {
                                        3 as ::core::ffi::c_int
                                    } else {
                                        2 as ::core::ffi::c_int
                                    })) as isize,
                            ) as *mut stbds_hash_bucket;
                        z = pos & STBDS_BUCKET_MASK as size_t;
                        while z < STBDS_BUCKET_LENGTH as size_t {
                            if (*bucket).hash[z as usize] == 0 as size_t {
                                (*bucket).hash[z as usize] = hash;
                                (*bucket).index[z as usize] = (*ob).index[j_0 as usize];
                                break 's_177;
                            } else {
                                z = z.wrapping_add(1);
                            }
                        }
                        limit = pos & STBDS_BUCKET_MASK as size_t;
                        z = 0 as size_t;
                        while z < limit {
                            if (*bucket).hash[z as usize] == 0 as size_t {
                                (*bucket).hash[z as usize] = hash;
                                (*bucket).index[z as usize] = (*ob).index[j_0 as usize];
                                break 's_177;
                            } else {
                                z = z.wrapping_add(1);
                            }
                        }
                        pos = pos.wrapping_add(step);
                        step = step.wrapping_add(STBDS_BUCKET_LENGTH as size_t);
                        pos &= (*t).slot_count.wrapping_sub(1 as size_t);
                    }
                }
                j_0 = j_0.wrapping_add(1);
            }
            i_0 = i_0.wrapping_add(1);
        }
    }
    return t;
}
#[no_mangle]
pub unsafe extern "C" fn stbds_hash_string(
    mut str: *mut ::core::ffi::c_char,
    mut seed: size_t,
) -> size_t {
    let mut hash: size_t = seed;
    while *str != 0 {
        let fresh7 = str;
        str = str.offset(1);
        hash = (hash << 9 as ::core::ffi::c_int
            | hash >> STBDS_SIZE_T_BITS.wrapping_sub(9 as usize))
            .wrapping_add(*fresh7 as ::core::ffi::c_uchar as size_t);
    }
    hash ^= seed;
    hash = (!hash).wrapping_add(hash << 18 as ::core::ffi::c_int);
    hash
        ^= hash
            ^ (hash >> 31 as ::core::ffi::c_int
                | hash << STBDS_SIZE_T_BITS.wrapping_sub(31 as usize));
    hash = hash.wrapping_mul(21 as size_t);
    hash
        ^= hash
            ^ (hash >> 11 as ::core::ffi::c_int
                | hash << STBDS_SIZE_T_BITS.wrapping_sub(11 as usize));
    hash = hash.wrapping_add(hash << 6 as ::core::ffi::c_int);
    hash
        ^= hash >> 22 as ::core::ffi::c_int
            | hash << STBDS_SIZE_T_BITS.wrapping_sub(22 as usize);
    return hash.wrapping_add(seed);
}
pub const STBDS_SIPHASH_C_ROUNDS: ::core::ffi::c_int = 2 as ::core::ffi::c_int;
pub const STBDS_SIPHASH_D_ROUNDS: ::core::ffi::c_int = 4 as ::core::ffi::c_int;
unsafe extern "C" fn stbds_siphash_bytes(
    mut p: *mut ::core::ffi::c_void,
    mut len: size_t,
    mut seed: size_t,
) -> size_t {
    let mut d: *mut ::core::ffi::c_uchar = p as *mut ::core::ffi::c_uchar;
    let mut i: size_t = 0;
    let mut j: size_t = 0;
    let mut v0: size_t = 0;
    let mut v1: size_t = 0;
    let mut v2: size_t = 0;
    let mut v3: size_t = 0;
    let mut data: size_t = 0;
    v0 = (((0x736f6d65 as ::core::ffi::c_int as size_t) << 16 as ::core::ffi::c_int)
        << 16 as ::core::ffi::c_int)
        .wrapping_add(0x70736575 as size_t) ^ seed;
    v1 = (((0x646f7261 as ::core::ffi::c_int as size_t) << 16 as ::core::ffi::c_int)
        << 16 as ::core::ffi::c_int)
        .wrapping_add(0x6e646f6d as size_t) ^ !seed;
    v2 = (((0x6c796765 as ::core::ffi::c_int as size_t) << 16 as ::core::ffi::c_int)
        << 16 as ::core::ffi::c_int)
        .wrapping_add(0x6e657261 as size_t) ^ seed;
    v3 = (((0x74656462 as ::core::ffi::c_int as size_t) << 16 as ::core::ffi::c_int)
        << 16 as ::core::ffi::c_int)
        .wrapping_add(0x79746573 as size_t) ^ !seed;
    v0 = (v0 as ::core::ffi::c_ulonglong
        ^ (0x706050403020100 as ::core::ffi::c_ulonglong
            ^ seed as ::core::ffi::c_ulonglong)) as size_t;
    v1 = (v1 as ::core::ffi::c_ulonglong
        ^ (0xf0e0d0c0b0a0908 as ::core::ffi::c_ulonglong
            ^ !seed as ::core::ffi::c_ulonglong)) as size_t;
    v2 = (v2 as ::core::ffi::c_ulonglong
        ^ (0x706050403020100 as ::core::ffi::c_ulonglong
            ^ seed as ::core::ffi::c_ulonglong)) as size_t;
    v3 = (v3 as ::core::ffi::c_ulonglong
        ^ (0xf0e0d0c0b0a0908 as ::core::ffi::c_ulonglong
            ^ !seed as ::core::ffi::c_ulonglong)) as size_t;
    i = 0 as size_t;
    while i.wrapping_add(::core::mem::size_of::<size_t>() as size_t) <= len {
        data = (*d.offset(0 as ::core::ffi::c_int as isize) as ::core::ffi::c_int
            | (*d.offset(1 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
                << 8 as ::core::ffi::c_int
            | (*d.offset(2 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
                << 16 as ::core::ffi::c_int
            | (*d.offset(3 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
                << 24 as ::core::ffi::c_int) as size_t;
        data
            |= (((*d.offset(4 as ::core::ffi::c_int as isize) as ::core::ffi::c_int
                | (*d.offset(5 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
                    << 8 as ::core::ffi::c_int
                | (*d.offset(6 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
                    << 16 as ::core::ffi::c_int
                | (*d.offset(7 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
                    << 24 as ::core::ffi::c_int) as size_t) << 16 as ::core::ffi::c_int)
                << 16 as ::core::ffi::c_int;
        v3 ^= data;
        j = 0 as size_t;
        while j < STBDS_SIPHASH_C_ROUNDS as size_t {
            v0 = v0.wrapping_add(v1);
            v1 = v1 << 13 as ::core::ffi::c_int
                | v1 >> STBDS_SIZE_T_BITS.wrapping_sub(13 as usize);
            v1 ^= v0;
            v0 = v0
                << (::core::mem::size_of::<size_t>() as usize)
                    .wrapping_mul(8 as usize)
                    .wrapping_div(2 as usize)
                | v0
                    >> STBDS_SIZE_T_BITS
                        .wrapping_sub(
                            (::core::mem::size_of::<size_t>() as usize)
                                .wrapping_mul(8 as usize)
                                .wrapping_div(2 as usize),
                        );
            v2 = v2.wrapping_add(v3);
            v3 = v3 << 16 as ::core::ffi::c_int
                | v3 >> STBDS_SIZE_T_BITS.wrapping_sub(16 as usize);
            v3 ^= v2;
            v2 = v2.wrapping_add(v1);
            v1 = v1 << 17 as ::core::ffi::c_int
                | v1 >> STBDS_SIZE_T_BITS.wrapping_sub(17 as usize);
            v1 ^= v2;
            v2 = v2
                << (::core::mem::size_of::<size_t>() as usize)
                    .wrapping_mul(8 as usize)
                    .wrapping_div(2 as usize)
                | v2
                    >> STBDS_SIZE_T_BITS
                        .wrapping_sub(
                            (::core::mem::size_of::<size_t>() as usize)
                                .wrapping_mul(8 as usize)
                                .wrapping_div(2 as usize),
                        );
            v0 = v0.wrapping_add(v3);
            v3 = v3 << 21 as ::core::ffi::c_int
                | v3 >> STBDS_SIZE_T_BITS.wrapping_sub(21 as usize);
            v3 ^= v0;
            j = j.wrapping_add(1);
        }
        v0 ^= data;
        i = (i as ::core::ffi::c_ulong)
            .wrapping_add(
                ::core::mem::size_of::<size_t>() as usize as ::core::ffi::c_ulong,
            ) as size_t as size_t;
        d = d.offset(::core::mem::size_of::<size_t>() as usize as isize);
    }
    data = len << STBDS_SIZE_T_BITS.wrapping_sub(8 as usize);
    let mut current_block_40: u64;
    match len.wrapping_sub(i) {
        7 => {
            data
                |= ((*d.offset(6 as ::core::ffi::c_int as isize) as size_t)
                    << 24 as ::core::ffi::c_int) << 24 as ::core::ffi::c_int;
            current_block_40 = 11072497749088541993;
        }
        6 => {
            current_block_40 = 11072497749088541993;
        }
        5 => {
            current_block_40 = 14557540497923032607;
        }
        4 => {
            current_block_40 = 2364461891993017838;
        }
        3 => {
            current_block_40 = 13010690532893077973;
        }
        2 => {
            current_block_40 = 12588939125543080051;
        }
        1 => {
            current_block_40 = 8113848136814073144;
        }
        0 | _ => {
            current_block_40 = 1538046216550696469;
        }
    }
    match current_block_40 {
        11072497749088541993 => {
            data
                |= ((*d.offset(5 as ::core::ffi::c_int as isize) as size_t)
                    << 20 as ::core::ffi::c_int) << 20 as ::core::ffi::c_int;
            current_block_40 = 14557540497923032607;
        }
        _ => {}
    }
    match current_block_40 {
        14557540497923032607 => {
            data
                |= ((*d.offset(4 as ::core::ffi::c_int as isize) as size_t)
                    << 16 as ::core::ffi::c_int) << 16 as ::core::ffi::c_int;
            current_block_40 = 2364461891993017838;
        }
        _ => {}
    }
    match current_block_40 {
        2364461891993017838 => {
            data
                |= ((*d.offset(3 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
                    << 24 as ::core::ffi::c_int) as size_t;
            current_block_40 = 13010690532893077973;
        }
        _ => {}
    }
    match current_block_40 {
        13010690532893077973 => {
            data
                |= ((*d.offset(2 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
                    << 16 as ::core::ffi::c_int) as size_t;
            current_block_40 = 12588939125543080051;
        }
        _ => {}
    }
    match current_block_40 {
        12588939125543080051 => {
            data
                |= ((*d.offset(1 as ::core::ffi::c_int as isize) as ::core::ffi::c_int)
                    << 8 as ::core::ffi::c_int) as size_t;
            current_block_40 = 8113848136814073144;
        }
        _ => {}
    }
    match current_block_40 {
        8113848136814073144 => {
            data |= *d.offset(0 as ::core::ffi::c_int as isize) as size_t;
        }
        _ => {}
    }
    v3 ^= data;
    j = 0 as size_t;
    while j < STBDS_SIPHASH_C_ROUNDS as size_t {
        v0 = v0.wrapping_add(v1);
        v1 = v1 << 13 as ::core::ffi::c_int
            | v1 >> STBDS_SIZE_T_BITS.wrapping_sub(13 as usize);
        v1 ^= v0;
        v0 = v0
            << (::core::mem::size_of::<size_t>() as usize)
                .wrapping_mul(8 as usize)
                .wrapping_div(2 as usize)
            | v0
                >> STBDS_SIZE_T_BITS
                    .wrapping_sub(
                        (::core::mem::size_of::<size_t>() as usize)
                            .wrapping_mul(8 as usize)
                            .wrapping_div(2 as usize),
                    );
        v2 = v2.wrapping_add(v3);
        v3 = v3 << 16 as ::core::ffi::c_int
            | v3 >> STBDS_SIZE_T_BITS.wrapping_sub(16 as usize);
        v3 ^= v2;
        v2 = v2.wrapping_add(v1);
        v1 = v1 << 17 as ::core::ffi::c_int
            | v1 >> STBDS_SIZE_T_BITS.wrapping_sub(17 as usize);
        v1 ^= v2;
        v2 = v2
            << (::core::mem::size_of::<size_t>() as usize)
                .wrapping_mul(8 as usize)
                .wrapping_div(2 as usize)
            | v2
                >> STBDS_SIZE_T_BITS
                    .wrapping_sub(
                        (::core::mem::size_of::<size_t>() as usize)
                            .wrapping_mul(8 as usize)
                            .wrapping_div(2 as usize),
                    );
        v0 = v0.wrapping_add(v3);
        v3 = v3 << 21 as ::core::ffi::c_int
            | v3 >> STBDS_SIZE_T_BITS.wrapping_sub(21 as usize);
        v3 ^= v0;
        j = j.wrapping_add(1);
    }
    v0 ^= data;
    v2 ^= 0xff as size_t;
    j = 0 as size_t;
    while j < STBDS_SIPHASH_D_ROUNDS as size_t {
        v0 = v0.wrapping_add(v1);
        v1 = v1 << 13 as ::core::ffi::c_int
            | v1 >> STBDS_SIZE_T_BITS.wrapping_sub(13 as usize);
        v1 ^= v0;
        v0 = v0
            << (::core::mem::size_of::<size_t>() as usize)
                .wrapping_mul(8 as usize)
                .wrapping_div(2 as usize)
            | v0
                >> STBDS_SIZE_T_BITS
                    .wrapping_sub(
                        (::core::mem::size_of::<size_t>() as usize)
                            .wrapping_mul(8 as usize)
                            .wrapping_div(2 as usize),
                    );
        v2 = v2.wrapping_add(v3);
        v3 = v3 << 16 as ::core::ffi::c_int
            | v3 >> STBDS_SIZE_T_BITS.wrapping_sub(16 as usize);
        v3 ^= v2;
        v2 = v2.wrapping_add(v1);
        v1 = v1 << 17 as ::core::ffi::c_int
            | v1 >> STBDS_SIZE_T_BITS.wrapping_sub(17 as usize);
        v1 ^= v2;
        v2 = v2
            << (::core::mem::size_of::<size_t>() as usize)
                .wrapping_mul(8 as usize)
                .wrapping_div(2 as usize)
            | v2
                >> STBDS_SIZE_T_BITS
                    .wrapping_sub(
                        (::core::mem::size_of::<size_t>() as usize)
                            .wrapping_mul(8 as usize)
                            .wrapping_div(2 as usize),
                    );
        v0 = v0.wrapping_add(v3);
        v3 = v3 << 21 as ::core::ffi::c_int
            | v3 >> STBDS_SIZE_T_BITS.wrapping_sub(21 as usize);
        v3 ^= v0;
        j = j.wrapping_add(1);
    }
    return v0 ^ v1 ^ v2 ^ v3;
}
#[no_mangle]
pub unsafe extern "C" fn stbds_hash_bytes(
    mut p: *mut ::core::ffi::c_void,
    mut len: size_t,
    mut seed: size_t,
) -> size_t {
    return stbds_siphash_bytes(p, len, seed);
}
unsafe extern "C" fn stbds_is_key_equal(
    mut a: *mut ::core::ffi::c_void,
    mut elemsize: size_t,
    mut key: *mut ::core::ffi::c_void,
    mut keysize: size_t,
    mut keyoffset: size_t,
    mut mode: ::core::ffi::c_int,
    mut i: size_t,
) -> ::core::ffi::c_int {
    if mode >= STBDS_HM_STRING {
        return (0 as ::core::ffi::c_int
            == strcmp(
                key as *mut ::core::ffi::c_char,
                *((a as *mut ::core::ffi::c_char)
                    .offset(elemsize.wrapping_mul(i) as isize)
                    .offset(keyoffset as isize) as *mut *mut ::core::ffi::c_char),
            )) as ::core::ffi::c_int
    } else {
        return (0 as ::core::ffi::c_int
            == memcmp(
                key,
                (a as *mut ::core::ffi::c_char)
                    .offset(elemsize.wrapping_mul(i) as isize)
                    .offset(keyoffset as isize) as *const ::core::ffi::c_void,
                keysize,
            )) as ::core::ffi::c_int
    };
}
#[no_mangle]
pub unsafe extern "C" fn stbds_hmfree_func(
    mut a: *mut ::core::ffi::c_void,
    mut elemsize: size_t,
) {
    if a.is_null() {
        return;
    }
    if !((*(a as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize)))
        .hash_table as *mut stbds_hash_index)
        .is_null()
    {
        if (*((*(a as *mut stbds_array_header)
            .offset(-(1 as ::core::ffi::c_int as isize)))
            .hash_table as *mut stbds_hash_index))
            .string
            .mode as ::core::ffi::c_int == STBDS_SH_STRDUP as ::core::ffi::c_int
        {
            let mut i: size_t = 0;
            i = 1 as size_t;
            while i
                < (*(a as *mut stbds_array_header)
                    .offset(-(1 as ::core::ffi::c_int as isize)))
                    .length
            {
                free(
                    *((a as *mut ::core::ffi::c_char)
                        .offset(elemsize.wrapping_mul(i) as isize)
                        as *mut *mut ::core::ffi::c_char) as *mut ::core::ffi::c_void,
                );
                i = i.wrapping_add(1);
            }
        }
        stbds_strreset(
            &mut (*((*(a as *mut stbds_array_header)
                .offset(-(1 as ::core::ffi::c_int as isize)))
                .hash_table as *mut stbds_hash_index))
                .string,
        );
    }
    free(
        (*(a as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize)))
            .hash_table,
    );
    free(
        (a as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize))
            as *mut ::core::ffi::c_void,
    );
}
unsafe extern "C" fn stbds_hm_find_slot(
    mut a: *mut ::core::ffi::c_void,
    mut elemsize: size_t,
    mut key: *mut ::core::ffi::c_void,
    mut keysize: size_t,
    mut keyoffset: size_t,
    mut mode: ::core::ffi::c_int,
) -> ptrdiff_t {
    let mut raw_a: *mut ::core::ffi::c_void = (a as *mut ::core::ffi::c_char)
        .offset(-(elemsize as isize)) as *mut ::core::ffi::c_void;
    let mut table: *mut stbds_hash_index = (*(raw_a as *mut stbds_array_header)
        .offset(-(1 as ::core::ffi::c_int as isize)))
        .hash_table as *mut stbds_hash_index;
    let mut hash: size_t = if mode >= STBDS_HM_STRING {
        stbds_hash_string(key as *mut ::core::ffi::c_char, (*table).seed)
    } else {
        stbds_hash_bytes(key, keysize, (*table).seed)
    };
    let mut step: size_t = STBDS_BUCKET_LENGTH as size_t;
    let mut limit: size_t = 0;
    let mut i: size_t = 0;
    let mut pos: size_t = 0;
    let mut bucket: *mut stbds_hash_bucket = 0 as *mut stbds_hash_bucket;
    if hash < 2 as size_t {
        hash = hash.wrapping_add(2 as size_t);
    }
    pos = stbds_probe_position(hash, (*table).slot_count, (*table).slot_count_log2);
    loop {
        bucket = &mut *(*table)
            .storage
            .offset(
                (pos
                    >> (if STBDS_BUCKET_LENGTH == 8 as ::core::ffi::c_int {
                        3 as ::core::ffi::c_int
                    } else {
                        2 as ::core::ffi::c_int
                    })) as isize,
            ) as *mut stbds_hash_bucket;
        i = pos & STBDS_BUCKET_MASK as size_t;
        while i < STBDS_BUCKET_LENGTH as size_t {
            if (*bucket).hash[i as usize] == hash {
                if stbds_is_key_equal(
                    a,
                    elemsize,
                    key,
                    keysize,
                    keyoffset,
                    mode,
                    (*bucket).index[i as usize] as size_t,
                ) != 0
                {
                    return (pos & !STBDS_BUCKET_MASK as size_t).wrapping_add(i)
                        as ptrdiff_t;
                }
            } else if (*bucket).hash[i as usize] == STBDS_HASH_EMPTY as size_t {
                return -(1 as ::core::ffi::c_int) as ptrdiff_t
            }
            i = i.wrapping_add(1);
        }
        limit = pos & STBDS_BUCKET_MASK as size_t;
        i = 0 as size_t;
        while i < limit {
            if (*bucket).hash[i as usize] == hash {
                if stbds_is_key_equal(
                    a,
                    elemsize,
                    key,
                    keysize,
                    keyoffset,
                    mode,
                    (*bucket).index[i as usize] as size_t,
                ) != 0
                {
                    return (pos & !STBDS_BUCKET_MASK as size_t).wrapping_add(i)
                        as ptrdiff_t;
                }
            } else if (*bucket).hash[i as usize] == STBDS_HASH_EMPTY as size_t {
                return -(1 as ::core::ffi::c_int) as ptrdiff_t
            }
            i = i.wrapping_add(1);
        }
        pos = pos.wrapping_add(step);
        step = step.wrapping_add(STBDS_BUCKET_LENGTH as size_t);
        pos &= (*table).slot_count.wrapping_sub(1 as size_t);
    };
}
#[no_mangle]
pub unsafe extern "C" fn stbds_hmget_key_ts(
    mut a: *mut ::core::ffi::c_void,
    mut elemsize: size_t,
    mut key: *mut ::core::ffi::c_void,
    mut keysize: size_t,
    mut temp: *mut ptrdiff_t,
    mut mode: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_void {
    let mut keyoffset: size_t = 0 as size_t;
    if a.is_null() {
        a = stbds_arrgrowf(
            0 as *mut ::core::ffi::c_void,
            elemsize,
            0 as size_t,
            1 as size_t,
        );
        let ref mut fresh6 = (*(a as *mut stbds_array_header)
            .offset(-(1 as ::core::ffi::c_int as isize)))
            .length;
        *fresh6 = (*fresh6).wrapping_add(1 as size_t);
        memset(a, 0 as ::core::ffi::c_int, elemsize);
        *temp = STBDS_INDEX_EMPTY as ptrdiff_t;
        return (a as *mut ::core::ffi::c_char).offset(elemsize as isize)
            as *mut ::core::ffi::c_void;
    } else {
        let mut table: *mut stbds_hash_index = 0 as *mut stbds_hash_index;
        let mut raw_a: *mut ::core::ffi::c_void = (a as *mut ::core::ffi::c_char)
            .offset(-(elemsize as isize)) as *mut ::core::ffi::c_void;
        table = (*(raw_a as *mut stbds_array_header)
            .offset(-(1 as ::core::ffi::c_int as isize)))
            .hash_table as *mut stbds_hash_index;
        if table.is_null() {
            *temp = -(1 as ::core::ffi::c_int) as ptrdiff_t;
        } else {
            let mut slot: ptrdiff_t = stbds_hm_find_slot(
                a,
                elemsize,
                key,
                keysize,
                keyoffset,
                mode,
            );
            if slot < 0 as ptrdiff_t {
                *temp = STBDS_INDEX_EMPTY as ptrdiff_t;
            } else {
                let mut b: *mut stbds_hash_bucket = &mut *(*table)
                    .storage
                    .offset(
                        (slot
                            >> (if STBDS_BUCKET_LENGTH == 8 as ::core::ffi::c_int {
                                3 as ::core::ffi::c_int
                            } else {
                                2 as ::core::ffi::c_int
                            })) as isize,
                    ) as *mut stbds_hash_bucket;
                *temp = (*b).index[(slot & STBDS_BUCKET_MASK as ptrdiff_t) as usize];
            }
        }
        return a;
    };
}
#[no_mangle]
pub unsafe extern "C" fn stbds_hmget_key(
    mut a: *mut ::core::ffi::c_void,
    mut elemsize: size_t,
    mut key: *mut ::core::ffi::c_void,
    mut keysize: size_t,
    mut mode: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_void {
    let mut temp: ptrdiff_t = 0;
    let mut p: *mut ::core::ffi::c_void = stbds_hmget_key_ts(
        a,
        elemsize,
        key,
        keysize,
        &mut temp,
        mode,
    );
    (*((p as *mut ::core::ffi::c_char).offset(-(elemsize as isize))
        as *mut stbds_array_header)
        .offset(-(1 as ::core::ffi::c_int as isize)))
        .temp = temp;
    return p;
}
#[no_mangle]
pub unsafe extern "C" fn stbds_hmput_default(
    mut a: *mut ::core::ffi::c_void,
    mut elemsize: size_t,
) -> *mut ::core::ffi::c_void {
    if a.is_null()
        || (*((a as *mut ::core::ffi::c_char).offset(-(elemsize as isize))
            as *mut stbds_array_header)
            .offset(-(1 as ::core::ffi::c_int as isize)))
            .length == 0 as size_t
    {
        a = stbds_arrgrowf(
            (if !a.is_null() {
                (a as *mut ::core::ffi::c_char).offset(-(elemsize as isize))
            } else {
                0 as *mut ::core::ffi::c_char
            }) as *mut ::core::ffi::c_void,
            elemsize,
            0 as size_t,
            1 as size_t,
        );
        let ref mut fresh19 = (*(a as *mut stbds_array_header)
            .offset(-(1 as ::core::ffi::c_int as isize)))
            .length;
        *fresh19 = (*fresh19).wrapping_add(1 as size_t);
        memset(a, 0 as ::core::ffi::c_int, elemsize);
        a = (a as *mut ::core::ffi::c_char).offset(elemsize as isize)
            as *mut ::core::ffi::c_void;
    }
    return a;
}
#[no_mangle]
pub unsafe extern "C" fn stbds_hmput_key(
    mut a: *mut ::core::ffi::c_void,
    mut elemsize: size_t,
    mut key: *mut ::core::ffi::c_void,
    mut keysize: size_t,
    mut mode: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_void {
    let mut keyoffset: size_t = 0 as size_t;
    let mut raw_a: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
    let mut table: *mut stbds_hash_index = 0 as *mut stbds_hash_index;
    if a.is_null() {
        a = stbds_arrgrowf(
            0 as *mut ::core::ffi::c_void,
            elemsize,
            0 as size_t,
            1 as size_t,
        );
        memset(a, 0 as ::core::ffi::c_int, elemsize);
        let ref mut fresh9 = (*(a as *mut stbds_array_header)
            .offset(-(1 as ::core::ffi::c_int as isize)))
            .length;
        *fresh9 = (*fresh9).wrapping_add(1 as size_t);
        a = (a as *mut ::core::ffi::c_char).offset(elemsize as isize)
            as *mut ::core::ffi::c_void;
    }
    raw_a = a;
    a = (a as *mut ::core::ffi::c_char).offset(-(elemsize as isize))
        as *mut ::core::ffi::c_void;
    table = (*(a as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize)))
        .hash_table as *mut stbds_hash_index;
    if table.is_null() || (*table).used_count >= (*table).used_count_threshold {
        let mut nt: *mut stbds_hash_index = 0 as *mut stbds_hash_index;
        let mut slot_count: size_t = 0;
        slot_count = if table.is_null() {
            STBDS_BUCKET_LENGTH as size_t
        } else {
            (*table).slot_count.wrapping_mul(2 as size_t)
        };
        nt = stbds_make_hash_index(slot_count, table);
        if !table.is_null() {
            free(table as *mut ::core::ffi::c_void);
        } else {
            (*nt).string.mode = (if mode >= STBDS_HM_STRING {
                STBDS_SH_DEFAULT as ::core::ffi::c_int
            } else {
                0 as ::core::ffi::c_int
            }) as ::core::ffi::c_uchar;
        }
        table = nt;
        let ref mut fresh10 = (*(a as *mut stbds_array_header)
            .offset(-(1 as ::core::ffi::c_int as isize)))
            .hash_table;
        *fresh10 = table as *mut ::core::ffi::c_void;
    }
    let mut hash: size_t = if mode >= STBDS_HM_STRING {
        stbds_hash_string(key as *mut ::core::ffi::c_char, (*table).seed)
    } else {
        stbds_hash_bytes(key, keysize, (*table).seed)
    };
    let mut step: size_t = STBDS_BUCKET_LENGTH as size_t;
    let mut pos: size_t = 0;
    let mut tombstone: ptrdiff_t = -(1 as ::core::ffi::c_int) as ptrdiff_t;
    let mut bucket: *mut stbds_hash_bucket = 0 as *mut stbds_hash_bucket;
    if hash < 2 as size_t {
        hash = hash.wrapping_add(2 as size_t);
    }
    pos = stbds_probe_position(hash, (*table).slot_count, (*table).slot_count_log2);
    's_101: loop {
        let mut limit: size_t = 0;
        let mut i: size_t = 0;
        bucket = &mut *(*table)
            .storage
            .offset(
                (pos
                    >> (if STBDS_BUCKET_LENGTH == 8 as ::core::ffi::c_int {
                        3 as ::core::ffi::c_int
                    } else {
                        2 as ::core::ffi::c_int
                    })) as isize,
            ) as *mut stbds_hash_bucket;
        i = pos & STBDS_BUCKET_MASK as size_t;
        while i < STBDS_BUCKET_LENGTH as size_t {
            if (*bucket).hash[i as usize] == hash {
                if stbds_is_key_equal(
                    raw_a,
                    elemsize,
                    key,
                    keysize,
                    keyoffset,
                    mode,
                    (*bucket).index[i as usize] as size_t,
                ) != 0
                {
                    (*(a as *mut stbds_array_header)
                        .offset(-(1 as ::core::ffi::c_int as isize)))
                        .temp = (*bucket).index[i as usize];
                    if mode >= STBDS_HM_STRING {
                        let ref mut fresh11 = *((*(a as *mut stbds_array_header)
                            .offset(-(1 as ::core::ffi::c_int as isize)))
                            .hash_table as *mut *mut ::core::ffi::c_char);
                        *fresh11 = *((raw_a as *mut ::core::ffi::c_char)
                            .offset(
                                elemsize.wrapping_mul((*bucket).index[i as usize] as size_t)
                                    as isize,
                            )
                            .offset(keyoffset as isize)
                            as *mut *mut ::core::ffi::c_char);
                    }
                    return (a as *mut ::core::ffi::c_char).offset(elemsize as isize)
                        as *mut ::core::ffi::c_void;
                }
            } else if (*bucket).hash[i as usize] == 0 as size_t {
                pos = (pos & !STBDS_BUCKET_MASK as size_t).wrapping_add(i);
                break 's_101;
            } else if tombstone < 0 as ptrdiff_t {
                if (*bucket).index[i as usize] == STBDS_INDEX_DELETED as ptrdiff_t {
                    tombstone = (pos & !STBDS_BUCKET_MASK as size_t).wrapping_add(i)
                        as ptrdiff_t;
                }
            }
            i = i.wrapping_add(1);
        }
        limit = pos & STBDS_BUCKET_MASK as size_t;
        i = 0 as size_t;
        while i < limit {
            if (*bucket).hash[i as usize] == hash {
                if stbds_is_key_equal(
                    raw_a,
                    elemsize,
                    key,
                    keysize,
                    keyoffset,
                    mode,
                    (*bucket).index[i as usize] as size_t,
                ) != 0
                {
                    (*(a as *mut stbds_array_header)
                        .offset(-(1 as ::core::ffi::c_int as isize)))
                        .temp = (*bucket).index[i as usize];
                    return (a as *mut ::core::ffi::c_char).offset(elemsize as isize)
                        as *mut ::core::ffi::c_void;
                }
            } else if (*bucket).hash[i as usize] == 0 as size_t {
                pos = (pos & !STBDS_BUCKET_MASK as size_t).wrapping_add(i);
                break 's_101;
            } else if tombstone < 0 as ptrdiff_t {
                if (*bucket).index[i as usize] == STBDS_INDEX_DELETED as ptrdiff_t {
                    tombstone = (pos & !STBDS_BUCKET_MASK as size_t).wrapping_add(i)
                        as ptrdiff_t;
                }
            }
            i = i.wrapping_add(1);
        }
        pos = pos.wrapping_add(step);
        step = step.wrapping_add(STBDS_BUCKET_LENGTH as size_t);
        pos &= (*table).slot_count.wrapping_sub(1 as size_t);
    }
    if tombstone >= 0 as ptrdiff_t {
        pos = tombstone as size_t;
        (*table).tombstone_count = (*table).tombstone_count.wrapping_sub(1);
    }
    (*table).used_count = (*table).used_count.wrapping_add(1);
    let mut i_0: ptrdiff_t = if !a.is_null() {
        (*(a as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize)))
            .length as ptrdiff_t
    } else {
        0 as ptrdiff_t
    };
    if (i_0 as size_t).wrapping_add(1 as size_t)
        > (if !a.is_null() {
            (*(a as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize)))
                .capacity
        } else {
            0 as size_t
        })
    {
        let ref mut fresh12 = *(&mut a as *mut *mut ::core::ffi::c_void);
        *fresh12 = stbds_arrgrowf(a, elemsize, 1 as size_t, 0 as size_t);
    }
    raw_a = (a as *mut ::core::ffi::c_char).offset(elemsize as isize)
        as *mut ::core::ffi::c_void;
    if !((i_0 as size_t).wrapping_add(1 as size_t)
        <= (if !a.is_null() {
            (*(a as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize)))
                .capacity
        } else {
            0 as size_t
        })) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 16],
                [::core::ffi::c_char; 16],
            >(*b"stbds_hmput_key\0")
                .as_ptr(),
            b"lib.c\0" as *const u8 as *const ::core::ffi::c_char,
            778 as ::core::ffi::c_int,
            b"(size_t) i+1 <= stbds_arrcap(a)\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    (*(a as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize)))
        .length = (i_0 + 1 as ptrdiff_t) as size_t;
    bucket = &mut *(*table)
        .storage
        .offset(
            (pos
                >> (if STBDS_BUCKET_LENGTH == 8 as ::core::ffi::c_int {
                    3 as ::core::ffi::c_int
                } else {
                    2 as ::core::ffi::c_int
                })) as isize,
        ) as *mut stbds_hash_bucket;
    (*bucket).hash[(pos & STBDS_BUCKET_MASK as size_t) as usize] = hash;
    (*bucket).index[(pos & STBDS_BUCKET_MASK as size_t) as usize] = i_0 - 1 as ptrdiff_t;
    (*(a as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize))).temp = i_0
        - 1 as ptrdiff_t;
    match (*table).string.mode as ::core::ffi::c_int {
        2 => {
            let ref mut fresh13 = *((a as *mut ::core::ffi::c_char)
                .offset(elemsize.wrapping_mul(i_0 as size_t) as isize)
                as *mut *mut ::core::ffi::c_char);
            *fresh13 = stbds_strdup(key as *mut ::core::ffi::c_char);
            let ref mut fresh14 = *((*(a as *mut stbds_array_header)
                .offset(-(1 as ::core::ffi::c_int as isize)))
                .hash_table as *mut *mut ::core::ffi::c_char);
            *fresh14 = *fresh13;
        }
        3 => {
            let ref mut fresh15 = *((a as *mut ::core::ffi::c_char)
                .offset(elemsize.wrapping_mul(i_0 as size_t) as isize)
                as *mut *mut ::core::ffi::c_char);
            *fresh15 = stbds_stralloc(
                &mut (*table).string,
                key as *mut ::core::ffi::c_char,
            );
            let ref mut fresh16 = *((*(a as *mut stbds_array_header)
                .offset(-(1 as ::core::ffi::c_int as isize)))
                .hash_table as *mut *mut ::core::ffi::c_char);
            *fresh16 = *fresh15;
        }
        1 => {
            let ref mut fresh17 = *((a as *mut ::core::ffi::c_char)
                .offset(elemsize.wrapping_mul(i_0 as size_t) as isize)
                as *mut *mut ::core::ffi::c_char);
            *fresh17 = key as *mut ::core::ffi::c_char;
            let ref mut fresh18 = *((*(a as *mut stbds_array_header)
                .offset(-(1 as ::core::ffi::c_int as isize)))
                .hash_table as *mut *mut ::core::ffi::c_char);
            *fresh18 = *fresh17;
        }
        _ => {
            memcpy(
                (a as *mut ::core::ffi::c_char)
                    .offset(elemsize.wrapping_mul(i_0 as size_t) as isize)
                    as *mut ::core::ffi::c_void,
                key,
                keysize,
            );
        }
    }
    return (a as *mut ::core::ffi::c_char).offset(elemsize as isize)
        as *mut ::core::ffi::c_void;
}
#[no_mangle]
pub unsafe extern "C" fn stbds_shmode_func(
    mut elemsize: size_t,
    mut mode: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_void {
    let mut a: *mut ::core::ffi::c_void = stbds_arrgrowf(
        0 as *mut ::core::ffi::c_void,
        elemsize,
        0 as size_t,
        1 as size_t,
    );
    let mut h: *mut stbds_hash_index = 0 as *mut stbds_hash_index;
    memset(a, 0 as ::core::ffi::c_int, elemsize);
    (*(a as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize)))
        .length = 1 as size_t;
    h = stbds_make_hash_index(STBDS_BUCKET_LENGTH as size_t, 0 as *mut stbds_hash_index);
    let ref mut fresh23 = (*(a as *mut stbds_array_header)
        .offset(-(1 as ::core::ffi::c_int as isize)))
        .hash_table;
    *fresh23 = h as *mut ::core::ffi::c_void;
    (*h).string.mode = mode as ::core::ffi::c_uchar;
    return (a as *mut ::core::ffi::c_char).offset(elemsize as isize)
        as *mut ::core::ffi::c_void;
}
#[no_mangle]
pub unsafe extern "C" fn stbds_hmdel_key(
    mut a: *mut ::core::ffi::c_void,
    mut elemsize: size_t,
    mut key: *mut ::core::ffi::c_void,
    mut keysize: size_t,
    mut keyoffset: size_t,
    mut mode: ::core::ffi::c_int,
) -> *mut ::core::ffi::c_void {
    if a.is_null() {
        return 0 as *mut ::core::ffi::c_void
    } else {
        let mut table: *mut stbds_hash_index = 0 as *mut stbds_hash_index;
        let mut raw_a: *mut ::core::ffi::c_void = (a as *mut ::core::ffi::c_char)
            .offset(-(elemsize as isize)) as *mut ::core::ffi::c_void;
        table = (*(raw_a as *mut stbds_array_header)
            .offset(-(1 as ::core::ffi::c_int as isize)))
            .hash_table as *mut stbds_hash_index;
        (*(raw_a as *mut stbds_array_header).offset(-(1 as ::core::ffi::c_int as isize)))
            .temp = 0 as ptrdiff_t;
        if table.is_null() {
            return a
        } else {
            let mut slot: ptrdiff_t = 0;
            slot = stbds_hm_find_slot(a, elemsize, key, keysize, keyoffset, mode);
            if slot < 0 as ptrdiff_t {
                return a
            } else {
                let mut b: *mut stbds_hash_bucket = &mut *(*table)
                    .storage
                    .offset(
                        (slot
                            >> (if STBDS_BUCKET_LENGTH == 8 as ::core::ffi::c_int {
                                3 as ::core::ffi::c_int
                            } else {
                                2 as ::core::ffi::c_int
                            })) as isize,
                    ) as *mut stbds_hash_bucket;
                let mut i: ::core::ffi::c_int = (slot & STBDS_BUCKET_MASK as ptrdiff_t)
                    as ::core::ffi::c_int;
                let mut old_index: ptrdiff_t = (*b).index[i as usize];
                let mut final_index: ptrdiff_t = (if !raw_a.is_null() {
                    (*(raw_a as *mut stbds_array_header)
                        .offset(-(1 as ::core::ffi::c_int as isize)))
                        .length as ptrdiff_t
                } else {
                    0 as ptrdiff_t
                }) - 1 as ptrdiff_t - 1 as ptrdiff_t;
                if !(slot < (*table).slot_count as ptrdiff_t) as ::core::ffi::c_int
                    as ::core::ffi::c_long != 0
                {
                    __assert_rtn(
                        ::core::mem::transmute::<
                            [u8; 16],
                            [::core::ffi::c_char; 16],
                        >(*b"stbds_hmdel_key\0")
                            .as_ptr(),
                        b"lib.c\0" as *const u8 as *const ::core::ffi::c_char,
                        828 as ::core::ffi::c_int,
                        b"slot < (ptrdiff_t) table->slot_count\0" as *const u8
                            as *const ::core::ffi::c_char,
                    );
                } else {};
                (*table).used_count = (*table).used_count.wrapping_sub(1);
                (*table).tombstone_count = (*table).tombstone_count.wrapping_add(1);
                (*(raw_a as *mut stbds_array_header)
                    .offset(-(1 as ::core::ffi::c_int as isize)))
                    .temp = 1 as ptrdiff_t;
                if !((*table).used_count >= 0 as size_t) as ::core::ffi::c_int
                    as ::core::ffi::c_long != 0
                {
                    __assert_rtn(
                        ::core::mem::transmute::<
                            [u8; 16],
                            [::core::ffi::c_char; 16],
                        >(*b"stbds_hmdel_key\0")
                            .as_ptr(),
                        b"lib.c\0" as *const u8 as *const ::core::ffi::c_char,
                        832 as ::core::ffi::c_int,
                        b"table->used_count >= 0\0" as *const u8
                            as *const ::core::ffi::c_char,
                    );
                } else {};
                (*b).hash[i as usize] = STBDS_HASH_DELETED as size_t;
                (*b).index[i as usize] = STBDS_INDEX_DELETED as ptrdiff_t;
                if mode == STBDS_HM_STRING
                    && (*table).string.mode as ::core::ffi::c_int
                        == STBDS_SH_STRDUP as ::core::ffi::c_int
                {
                    free(
                        *((a as *mut ::core::ffi::c_char)
                            .offset(elemsize.wrapping_mul(old_index as size_t) as isize)
                            as *mut *mut ::core::ffi::c_char) as *mut ::core::ffi::c_void,
                    );
                }
                if old_index != final_index {
                    memmove(
                        (a as *mut ::core::ffi::c_char)
                            .offset(elemsize.wrapping_mul(old_index as size_t) as isize)
                            as *mut ::core::ffi::c_void,
                        (a as *mut ::core::ffi::c_char)
                            .offset(
                                elemsize.wrapping_mul(final_index as size_t) as isize,
                            ) as *const ::core::ffi::c_void,
                        elemsize,
                    );
                    if mode == STBDS_HM_STRING {
                        slot = stbds_hm_find_slot(
                            a,
                            elemsize,
                            *((a as *mut ::core::ffi::c_char)
                                .offset(elemsize.wrapping_mul(old_index as size_t) as isize)
                                .offset(keyoffset as isize)
                                as *mut *mut ::core::ffi::c_char)
                                as *mut ::core::ffi::c_void,
                            keysize,
                            keyoffset,
                            mode,
                        );
                    } else {
                        slot = stbds_hm_find_slot(
                            a,
                            elemsize,
                            (a as *mut ::core::ffi::c_char)
                                .offset(elemsize.wrapping_mul(old_index as size_t) as isize)
                                .offset(keyoffset as isize) as *mut ::core::ffi::c_void,
                            keysize,
                            keyoffset,
                            mode,
                        );
                    }
                    if !(slot >= 0 as ptrdiff_t) as ::core::ffi::c_int
                        as ::core::ffi::c_long != 0
                    {
                        __assert_rtn(
                            ::core::mem::transmute::<
                                [u8; 16],
                                [::core::ffi::c_char; 16],
                            >(*b"stbds_hmdel_key\0")
                                .as_ptr(),
                            b"lib.c\0" as *const u8 as *const ::core::ffi::c_char,
                            846 as ::core::ffi::c_int,
                            b"slot >= 0\0" as *const u8 as *const ::core::ffi::c_char,
                        );
                    } else {};
                    b = &mut *(*table)
                        .storage
                        .offset(
                            (slot
                                >> (if STBDS_BUCKET_LENGTH == 8 as ::core::ffi::c_int {
                                    3 as ::core::ffi::c_int
                                } else {
                                    2 as ::core::ffi::c_int
                                })) as isize,
                        ) as *mut stbds_hash_bucket;
                    i = (slot & STBDS_BUCKET_MASK as ptrdiff_t) as ::core::ffi::c_int;
                    if !((*b).index[i as usize] == final_index) as ::core::ffi::c_int
                        as ::core::ffi::c_long != 0
                    {
                        __assert_rtn(
                            ::core::mem::transmute::<
                                [u8; 16],
                                [::core::ffi::c_char; 16],
                            >(*b"stbds_hmdel_key\0")
                                .as_ptr(),
                            b"lib.c\0" as *const u8 as *const ::core::ffi::c_char,
                            849 as ::core::ffi::c_int,
                            b"b->index[i] == final_index\0" as *const u8
                                as *const ::core::ffi::c_char,
                        );
                    } else {};
                    (*b).index[i as usize] = old_index;
                }
                let ref mut fresh20 = (*(raw_a as *mut stbds_array_header)
                    .offset(-(1 as ::core::ffi::c_int as isize)))
                    .length;
                *fresh20 = (*fresh20).wrapping_sub(1 as size_t);
                if (*table).used_count < (*table).used_count_shrink_threshold
                    && (*table).slot_count > STBDS_BUCKET_LENGTH as size_t
                {
                    let ref mut fresh21 = (*(raw_a as *mut stbds_array_header)
                        .offset(-(1 as ::core::ffi::c_int as isize)))
                        .hash_table;
                    *fresh21 = stbds_make_hash_index(
                        (*table).slot_count >> 1 as ::core::ffi::c_int,
                        table,
                    ) as *mut ::core::ffi::c_void;
                    free(table as *mut ::core::ffi::c_void);
                } else if (*table).tombstone_count > (*table).tombstone_count_threshold {
                    let ref mut fresh22 = (*(raw_a as *mut stbds_array_header)
                        .offset(-(1 as ::core::ffi::c_int as isize)))
                        .hash_table;
                    *fresh22 = stbds_make_hash_index((*table).slot_count, table)
                        as *mut ::core::ffi::c_void;
                    free(table as *mut ::core::ffi::c_void);
                }
                return a;
            }
        }
    };
}
unsafe extern "C" fn stbds_strdup(
    mut str: *mut ::core::ffi::c_char,
) -> *mut ::core::ffi::c_char {
    let mut len: size_t = strlen(str).wrapping_add(1 as size_t);
    let mut p: *mut ::core::ffi::c_char = realloc(0 as *mut ::core::ffi::c_void, len)
        as *mut ::core::ffi::c_char;
    memmove(p as *mut ::core::ffi::c_void, str as *const ::core::ffi::c_void, len);
    return p;
}
pub const STBDS_STRING_ARENA_BLOCKSIZE_MIN: ::core::ffi::c_uint = 512
    as ::core::ffi::c_uint;
pub const STBDS_STRING_ARENA_BLOCKSIZE_MAX: ::core::ffi::c_uint = (1
    as ::core::ffi::c_uint) << 20 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn stbds_stralloc(
    mut a: *mut stbds_string_arena,
    mut str: *mut ::core::ffi::c_char,
) -> *mut ::core::ffi::c_char {
    let mut p: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut len: size_t = strlen(str).wrapping_add(1 as size_t);
    if len > (*a).remaining {
        let mut blocksize: size_t = (*a).block as size_t;
        blocksize = (512 as ::core::ffi::c_uint as size_t)
            << (blocksize >> 1 as ::core::ffi::c_int);
        if blocksize < ((1 as ::core::ffi::c_uint) << 20 as ::core::ffi::c_int) as size_t
        {
            (*a).block = (*a).block.wrapping_add(1);
        }
        if len > blocksize {
            let mut sb: *mut stbds_string_block = realloc(
                0 as *mut ::core::ffi::c_void,
                (::core::mem::size_of::<stbds_string_block>() as size_t)
                    .wrapping_sub(8 as size_t)
                    .wrapping_add(len),
            ) as *mut stbds_string_block;
            memmove(
                (*sb).storage.as_mut_ptr() as *mut ::core::ffi::c_void,
                str as *const ::core::ffi::c_void,
                len,
            );
            if !(*a).storage.is_null() {
                (*sb).next = (*(*a).storage).next;
                (*(*a).storage).next = sb as *mut stbds_string_block;
            } else {
                (*sb).next = 0 as *mut stbds_string_block;
                (*a).storage = sb;
                (*a).remaining = 0 as size_t;
            }
            return (*sb).storage.as_mut_ptr();
        } else {
            let mut sb_0: *mut stbds_string_block = realloc(
                0 as *mut ::core::ffi::c_void,
                (::core::mem::size_of::<stbds_string_block>() as size_t)
                    .wrapping_sub(8 as size_t)
                    .wrapping_add(blocksize),
            ) as *mut stbds_string_block;
            (*sb_0).next = (*a).storage as *mut stbds_string_block;
            (*a).storage = sb_0;
            (*a).remaining = blocksize;
        }
    }
    if !(len <= (*a).remaining) as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 15],
                [::core::ffi::c_char; 15],
            >(*b"stbds_stralloc\0")
                .as_ptr(),
            b"lib.c\0" as *const u8 as *const ::core::ffi::c_char,
            913 as ::core::ffi::c_int,
            b"len <= a->remaining\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    p = (*(*a).storage)
        .storage
        .as_mut_ptr()
        .offset((*a).remaining as isize)
        .offset(-(len as isize));
    (*a).remaining = (*a).remaining.wrapping_sub(len);
    memmove(p as *mut ::core::ffi::c_void, str as *const ::core::ffi::c_void, len);
    return p;
}
#[no_mangle]
pub unsafe extern "C" fn stbds_strreset(mut a: *mut stbds_string_arena) {
    let mut x: *mut stbds_string_block = 0 as *mut stbds_string_block;
    let mut y: *mut stbds_string_block = 0 as *mut stbds_string_block;
    x = (*a).storage;
    while !x.is_null() {
        y = (*x).next as *mut stbds_string_block;
        free(x as *mut ::core::ffi::c_void);
        x = y;
    }
    memset(
        a as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<stbds_string_arena>() as size_t,
    );
}
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
static mut buffer: [::core::ffi::c_char; 256] = [0; 256];
#[no_mangle]
pub unsafe extern "C" fn strkey(mut n: ::core::ffi::c_int) -> *mut ::core::ffi::c_char {
    sprintf(
        buffer.as_mut_ptr(),
        b"test_%d\0" as *const u8 as *const ::core::ffi::c_char,
        n,
    );
    return buffer.as_mut_ptr();
}
#[no_mangle]
pub unsafe extern "C" fn intput(mut num: ::core::ffi::c_int) {
    let mut intmap: *mut C2RustUnnamed = 0 as *mut C2RustUnnamed;
    intmap = 0 as *mut C2RustUnnamed;
    let mut fresh0: [::core::ffi::c_int; 1] = [num];
    intmap = stbds_hmput_key(
        intmap as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<C2RustUnnamed>() as size_t,
        fresh0.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        0 as ::core::ffi::c_int,
    ) as *mut C2RustUnnamed;
    (*intmap
        .offset(
            (*(intmap.offset(-(1 as ::core::ffi::c_int as isize))
                as *mut stbds_array_header)
                .offset(-(1 as ::core::ffi::c_int as isize)))
                .temp as isize,
        ))
        .key = num;
    (*intmap
        .offset(
            (*(intmap.offset(-(1 as ::core::ffi::c_int as isize))
                as *mut stbds_array_header)
                .offset(-(1 as ::core::ffi::c_int as isize)))
                .temp as isize,
        ))
        .value = 7 as ::core::ffi::c_int;
    let mut fresh1: [::core::ffi::c_int; 1] = [11 as ::core::ffi::c_int];
    intmap = stbds_hmput_key(
        intmap as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<C2RustUnnamed>() as size_t,
        fresh1.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        0 as ::core::ffi::c_int,
    ) as *mut C2RustUnnamed;
    (*intmap
        .offset(
            (*(intmap.offset(-(1 as ::core::ffi::c_int as isize))
                as *mut stbds_array_header)
                .offset(-(1 as ::core::ffi::c_int as isize)))
                .temp as isize,
        ))
        .key = 11 as ::core::ffi::c_int;
    (*intmap
        .offset(
            (*(intmap.offset(-(1 as ::core::ffi::c_int as isize))
                as *mut stbds_array_header)
                .offset(-(1 as ::core::ffi::c_int as isize)))
                .temp as isize,
        ))
        .value = 3 as ::core::ffi::c_int;
    let mut fresh2: [::core::ffi::c_int; 1] = [9 as ::core::ffi::c_int];
    intmap = stbds_hmput_key(
        intmap as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<C2RustUnnamed>() as size_t,
        fresh2.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        0 as ::core::ffi::c_int,
    ) as *mut C2RustUnnamed;
    (*intmap
        .offset(
            (*(intmap.offset(-(1 as ::core::ffi::c_int as isize))
                as *mut stbds_array_header)
                .offset(-(1 as ::core::ffi::c_int as isize)))
                .temp as isize,
        ))
        .key = 9 as ::core::ffi::c_int;
    (*intmap
        .offset(
            (*(intmap.offset(-(1 as ::core::ffi::c_int as isize))
                as *mut stbds_array_header)
                .offset(-(1 as ::core::ffi::c_int as isize)))
                .temp as isize,
        ))
        .value = num;
    let mut fresh3: [::core::ffi::c_int; 1] = [9 as ::core::ffi::c_int];
    intmap = stbds_hmget_key(
        intmap as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<C2RustUnnamed>() as size_t,
        fresh3.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        0 as ::core::ffi::c_int,
    ) as *mut C2RustUnnamed;
    if !((*(&mut *intmap
        .offset(
            (*(intmap.offset(-(1 as ::core::ffi::c_int as isize))
                as *mut stbds_array_header)
                .offset(-(1 as ::core::ffi::c_int as isize)))
                .temp as isize,
        ) as *mut C2RustUnnamed))
        .value == num) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 7], [::core::ffi::c_char; 7]>(*b"intput\0")
                .as_ptr(),
            b"lib.c\0" as *const u8 as *const ::core::ffi::c_char,
            953 as ::core::ffi::c_int,
            b"hmget(intmap, 9) == num\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut fresh4: [::core::ffi::c_int; 1] = [11 as ::core::ffi::c_int];
    intmap = stbds_hmget_key(
        intmap as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<C2RustUnnamed>() as size_t,
        fresh4.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        0 as ::core::ffi::c_int,
    ) as *mut C2RustUnnamed;
    if !((*(&mut *intmap
        .offset(
            (*(intmap.offset(-(1 as ::core::ffi::c_int as isize))
                as *mut stbds_array_header)
                .offset(-(1 as ::core::ffi::c_int as isize)))
                .temp as isize,
        ) as *mut C2RustUnnamed))
        .value == 3 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 7], [::core::ffi::c_char; 7]>(*b"intput\0")
                .as_ptr(),
            b"lib.c\0" as *const u8 as *const ::core::ffi::c_char,
            954 as ::core::ffi::c_int,
            b"hmget(intmap, 11) == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut fresh5: [::core::ffi::c_int; 1] = [num];
    intmap = stbds_hmget_key(
        intmap as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<C2RustUnnamed>() as size_t,
        fresh5.as_mut_ptr() as *mut ::core::ffi::c_void,
        ::core::mem::size_of::<::core::ffi::c_int>() as size_t,
        0 as ::core::ffi::c_int,
    ) as *mut C2RustUnnamed;
    if !((*(&mut *intmap
        .offset(
            (*(intmap.offset(-(1 as ::core::ffi::c_int as isize))
                as *mut stbds_array_header)
                .offset(-(1 as ::core::ffi::c_int as isize)))
                .temp as isize,
        ) as *mut C2RustUnnamed))
        .value == 7 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<[u8; 7], [::core::ffi::c_char; 7]>(*b"intput\0")
                .as_ptr(),
            b"lib.c\0" as *const u8 as *const ::core::ffi::c_char,
            955 as ::core::ffi::c_int,
            b"hmget(intmap, num) == 7\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
}
