#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn UTIL_createLinePointers(
    mut buffer: *mut ::core::ffi::c_char,
    mut numLines: size_t,
    mut bufferSize: size_t,
) -> *mut *const ::core::ffi::c_char {
    let mut lineIndex: size_t = 0 as size_t;
    let mut pos: size_t = 0 as size_t;
    let bufferPtrs: *mut ::core::ffi::c_void = malloc(
        numLines
            .wrapping_mul(
                ::core::mem::size_of::<*mut *const ::core::ffi::c_char>() as size_t,
            ),
    ) as *mut ::core::ffi::c_void;
    let linePointers: *mut *const ::core::ffi::c_char = bufferPtrs
        as *mut *const ::core::ffi::c_char;
    if bufferPtrs.is_null() {
        return 0 as *mut *const ::core::ffi::c_char;
    }
    while lineIndex < numLines && pos < bufferSize {
        let mut len: size_t = 0 as size_t;
        let fresh0 = lineIndex;
        lineIndex = lineIndex.wrapping_add(1);
        let ref mut fresh1 = *linePointers.offset(fresh0 as isize);
        *fresh1 = buffer.offset(pos as isize);
        while pos.wrapping_add(len) < bufferSize
            && *buffer.offset(pos.wrapping_add(len) as isize) as ::core::ffi::c_int
                != '\0' as i32
        {
            len = len.wrapping_add(1);
        }
        pos = pos.wrapping_add(len);
        if pos < bufferSize {
            pos = pos.wrapping_add(1);
        }
    }
    if lineIndex != numLines {
        free(bufferPtrs);
        return 0 as *mut *const ::core::ffi::c_char;
    }
    return linePointers;
}
