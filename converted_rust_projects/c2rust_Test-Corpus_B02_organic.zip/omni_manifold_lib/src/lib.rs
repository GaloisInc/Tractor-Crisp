#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn sqrtf(_: ::core::ffi::c_float) -> ::core::ffi::c_float;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
}
pub type C2_TYPE = ::core::ffi::c_uint;
pub const C2_TYPE_POLY: C2_TYPE = 3;
pub const C2_TYPE_AABB: C2_TYPE = 2;
pub const C2_TYPE_CIRCLE: C2_TYPE = 1;
pub const C2_TYPE_CAPSULE: C2_TYPE = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct c2v {
    pub x: ::core::ffi::c_float,
    pub y: ::core::ffi::c_float,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct c2Manifold {
    pub count: ::core::ffi::c_int,
    pub depths: [::core::ffi::c_float; 2],
    pub contact_points: [c2v; 2],
    pub n: c2v,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct c2Capsule {
    pub a: c2v,
    pub b: c2v,
    pub r: ::core::ffi::c_float,
}
pub type size_t = __darwin_size_t;
pub type __darwin_size_t = usize;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct c2AABB {
    pub min: c2v,
    pub max: c2v,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct c2Circle {
    pub p: c2v,
    pub r: ::core::ffi::c_float,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct c2GJKCache {
    pub metric: ::core::ffi::c_float,
    pub count: ::core::ffi::c_int,
    pub iA: [::core::ffi::c_int; 3],
    pub iB: [::core::ffi::c_int; 3],
    pub div: ::core::ffi::c_float,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct c2x {
    pub p: c2v,
    pub r: c2r,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct c2r {
    pub c: ::core::ffi::c_float,
    pub s: ::core::ffi::c_float,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct c2Simplex {
    pub a: c2sv,
    pub b: c2sv,
    pub c: c2sv,
    pub d: c2sv,
    pub div: ::core::ffi::c_float,
    pub count: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct c2sv {
    pub sA: c2v,
    pub sB: c2v,
    pub p: c2v,
    pub u: ::core::ffi::c_float,
    pub iA: ::core::ffi::c_int,
    pub iB: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct c2Proxy {
    pub radius: ::core::ffi::c_float,
    pub count: ::core::ffi::c_int,
    pub verts: [c2v; 8],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct c2Poly {
    pub count: ::core::ffi::c_int,
    pub verts: [c2v; 8],
    pub norms: [c2v; 8],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct c2h {
    pub n: c2v,
    pub d: ::core::ffi::c_float,
}
#[no_mangle]
pub unsafe extern "C" fn c2V(
    mut x: ::core::ffi::c_float,
    mut y: ::core::ffi::c_float,
) -> c2v {
    let mut a: c2v = c2v { x: 0., y: 0. };
    a.x = x;
    a.y = y;
    return a;
}
#[no_mangle]
pub unsafe extern "C" fn c2Mulvs(mut a: c2v, mut b: ::core::ffi::c_float) -> c2v {
    a.x *= b;
    a.y *= b;
    return a;
}
#[no_mangle]
pub unsafe extern "C" fn c2Maxv(mut a: c2v, mut b: c2v) -> c2v {
    return c2V(if a.x > b.x { a.x } else { b.x }, if a.y > b.y { a.y } else { b.y });
}
#[no_mangle]
pub unsafe extern "C" fn c2Minv(mut a: c2v, mut b: c2v) -> c2v {
    return c2V(if a.x < b.x { a.x } else { b.x }, if a.y < b.y { a.y } else { b.y });
}
#[no_mangle]
pub unsafe extern "C" fn c2Clampv(mut a: c2v, mut lo: c2v, mut hi: c2v) -> c2v {
    return c2Maxv(lo, c2Minv(a, hi));
}
#[no_mangle]
pub unsafe extern "C" fn c2Sub(mut a: c2v, mut b: c2v) -> c2v {
    a.x -= b.x;
    a.y -= b.y;
    return a;
}
#[no_mangle]
pub unsafe extern "C" fn c2Dot(mut a: c2v, mut b: c2v) -> ::core::ffi::c_float {
    return a.x * b.x + a.y * b.y;
}
#[no_mangle]
pub unsafe extern "C" fn c2Dist(mut h: c2h, mut p: c2v) -> ::core::ffi::c_float {
    return c2Dot(h.n, p) - h.d;
}
#[no_mangle]
pub unsafe extern "C" fn c2PlaneAt(mut p: *const c2Poly, i: ::core::ffi::c_int) -> c2h {
    let mut h: c2h = c2h {
        n: c2v { x: 0., y: 0. },
        d: 0.,
    };
    h.n = (*p).norms[i as usize];
    h.d = c2Dot((*p).norms[i as usize], (*p).verts[i as usize]);
    return h;
}
#[no_mangle]
pub unsafe extern "C" fn c2RotIdentity() -> c2r {
    let mut r: c2r = c2r { c: 0., s: 0. };
    r.c = 1.0f32;
    r.s = 0 as ::core::ffi::c_int as ::core::ffi::c_float;
    return r;
}
#[no_mangle]
pub unsafe extern "C" fn c2xIdentity() -> c2x {
    let mut x: c2x = c2x {
        p: c2v { x: 0., y: 0. },
        r: c2r { c: 0., s: 0. },
    };
    x.p = c2V(
        0 as ::core::ffi::c_int as ::core::ffi::c_float,
        0 as ::core::ffi::c_int as ::core::ffi::c_float,
    );
    x.r = c2RotIdentity();
    return x;
}
#[no_mangle]
pub unsafe extern "C" fn c2BBVerts(mut out: *mut c2v, mut bb: *mut c2AABB) {
    *out.offset(0 as ::core::ffi::c_int as isize) = (*bb).min;
    *out.offset(1 as ::core::ffi::c_int as isize) = c2V((*bb).max.x, (*bb).min.y);
    *out.offset(2 as ::core::ffi::c_int as isize) = (*bb).max;
    *out.offset(3 as ::core::ffi::c_int as isize) = c2V((*bb).min.x, (*bb).max.y);
}
#[no_mangle]
pub unsafe extern "C" fn c2MakeProxy(
    mut shape: *const ::core::ffi::c_void,
    mut type_0: C2_TYPE,
    mut p: *mut c2Proxy,
) {
    match type_0 as ::core::ffi::c_uint {
        1 => {
            let mut c: *mut c2Circle = shape as *mut c2Circle;
            (*p).radius = (*c).r;
            (*p).count = 1 as ::core::ffi::c_int;
            (*p).verts[0 as ::core::ffi::c_int as usize] = (*c).p;
        }
        2 => {
            let mut bb: *mut c2AABB = shape as *mut c2AABB;
            (*p).radius = 0 as ::core::ffi::c_int as ::core::ffi::c_float;
            (*p).count = 4 as ::core::ffi::c_int;
            c2BBVerts((*p).verts.as_mut_ptr(), bb);
        }
        0 => {
            let mut c_0: *mut c2Capsule = shape as *mut c2Capsule;
            (*p).radius = (*c_0).r;
            (*p).count = 2 as ::core::ffi::c_int;
            (*p).verts[0 as ::core::ffi::c_int as usize] = (*c_0).a;
            (*p).verts[1 as ::core::ffi::c_int as usize] = (*c_0).b;
        }
        _ => {}
    };
}
#[no_mangle]
pub unsafe extern "C" fn c2Len(mut a: c2v) -> ::core::ffi::c_float {
    return sqrtf(c2Dot(a, a));
}
#[no_mangle]
pub unsafe extern "C" fn c2Det2(mut a: c2v, mut b: c2v) -> ::core::ffi::c_float {
    return a.x * b.y - a.y * b.x;
}
#[no_mangle]
pub unsafe extern "C" fn c2GJKSimplexMetric(
    mut s: *mut c2Simplex,
) -> ::core::ffi::c_float {
    match (*s).count {
        2 => return c2Len(c2Sub((*s).b.p, (*s).a.p)),
        3 => return c2Det2(c2Sub((*s).b.p, (*s).a.p), c2Sub((*s).c.p, (*s).a.p)),
        1 | _ => return 0 as ::core::ffi::c_int as ::core::ffi::c_float,
    };
}
#[no_mangle]
pub unsafe extern "C" fn c2Mulrv(mut a: c2r, mut b: c2v) -> c2v {
    return c2V(a.c * b.x - a.s * b.y, a.s * b.x + a.c * b.y);
}
#[no_mangle]
pub unsafe extern "C" fn c2MulrvT(mut a: c2r, mut b: c2v) -> c2v {
    return c2V(a.c * b.x + a.s * b.y, -a.s * b.x + a.c * b.y);
}
#[no_mangle]
pub unsafe extern "C" fn c2Add(mut a: c2v, mut b: c2v) -> c2v {
    a.x += b.x;
    a.y += b.y;
    return a;
}
#[no_mangle]
pub unsafe extern "C" fn c2Mulxv(mut a: c2x, mut b: c2v) -> c2v {
    return c2Add(c2Mulrv(a.r, b), a.p);
}
#[no_mangle]
pub unsafe extern "C" fn c2MulxvT(mut a: c2x, mut b: c2v) -> c2v {
    return c2MulrvT(a.r, c2Sub(b, a.p));
}
#[no_mangle]
pub unsafe extern "C" fn c2Intersect(
    mut a: c2v,
    mut b: c2v,
    mut da: ::core::ffi::c_float,
    mut db: ::core::ffi::c_float,
) -> c2v {
    return c2Add(a, c2Mulvs(c2Sub(b, a), da / (da - db)));
}
unsafe extern "C" fn c2Clip(mut seg: *mut c2v, mut h: c2h) -> ::core::ffi::c_int {
    let mut out: [c2v; 2] = [c2v { x: 0., y: 0. }; 2];
    let mut sp: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut d0: ::core::ffi::c_float = 0.;
    let mut d1: ::core::ffi::c_float = 0.;
    d0 = c2Dist(h, *seg.offset(0 as ::core::ffi::c_int as isize));
    if d0 < 0 as ::core::ffi::c_int as ::core::ffi::c_float {
        let fresh0 = sp;
        sp = sp + 1;
        out[fresh0 as usize] = *seg.offset(0 as ::core::ffi::c_int as isize);
    }
    d1 = c2Dist(h, *seg.offset(1 as ::core::ffi::c_int as isize));
    if d1 < 0 as ::core::ffi::c_int as ::core::ffi::c_float {
        let fresh1 = sp;
        sp = sp + 1;
        out[fresh1 as usize] = *seg.offset(1 as ::core::ffi::c_int as isize);
    }
    if d0 == 0 as ::core::ffi::c_int as ::core::ffi::c_float
        && d1 == 0 as ::core::ffi::c_int as ::core::ffi::c_float
    {
        let fresh2 = sp;
        sp = sp + 1;
        out[fresh2 as usize] = *seg.offset(0 as ::core::ffi::c_int as isize);
        let fresh3 = sp;
        sp = sp + 1;
        out[fresh3 as usize] = *seg.offset(1 as ::core::ffi::c_int as isize);
    } else if d0 * d1 <= 0 as ::core::ffi::c_int as ::core::ffi::c_float {
        let fresh4 = sp;
        sp = sp + 1;
        out[fresh4 as usize] = c2Intersect(
            *seg.offset(0 as ::core::ffi::c_int as isize),
            *seg.offset(1 as ::core::ffi::c_int as isize),
            d0,
            d1,
        );
    }
    *seg.offset(0 as ::core::ffi::c_int as isize) = out[0 as ::core::ffi::c_int
        as usize];
    *seg.offset(1 as ::core::ffi::c_int as isize) = out[1 as ::core::ffi::c_int
        as usize];
    return sp;
}
#[no_mangle]
pub unsafe extern "C" fn c2Div(mut a: c2v, mut b: ::core::ffi::c_float) -> c2v {
    return c2Mulvs(a, 1.0f32 / b);
}
#[no_mangle]
pub unsafe extern "C" fn c2Norm(mut a: c2v) -> c2v {
    return c2Div(a, c2Len(a));
}
#[no_mangle]
pub unsafe extern "C" fn c2Neg(mut a: c2v) -> c2v {
    return c2V(-a.x, -a.y);
}
#[no_mangle]
pub unsafe extern "C" fn c2CCW90(mut a: c2v) -> c2v {
    let mut b: c2v = c2v { x: 0., y: 0. };
    b.x = a.y;
    b.y = -a.x;
    return b;
}
unsafe extern "C" fn c2SidePlanes(
    mut seg: *mut c2v,
    mut ra: c2v,
    mut rb: c2v,
    mut h: *mut c2h,
) -> ::core::ffi::c_int {
    let mut in_0: c2v = c2Norm(c2Sub(rb, ra));
    let mut left: c2h = {
        let mut init = c2h {
            n: c2Neg(in_0),
            d: c2Dot(c2Neg(in_0), ra),
        };
        init
    };
    let mut right: c2h = {
        let mut init = c2h { n: in_0, d: c2Dot(in_0, rb) };
        init
    };
    if c2Clip(seg, left) < 2 as ::core::ffi::c_int {
        return 0 as ::core::ffi::c_int;
    }
    if c2Clip(seg, right) < 2 as ::core::ffi::c_int {
        return 0 as ::core::ffi::c_int;
    }
    if !h.is_null() {
        (*h).n = c2CCW90(in_0);
        (*h).d = c2Dot(c2CCW90(in_0), ra);
    }
    return 1 as ::core::ffi::c_int;
}
unsafe extern "C" fn c2SidePlanesFromPoly(
    mut seg: *mut c2v,
    mut x: c2x,
    mut p: *const c2Poly,
    mut e: ::core::ffi::c_int,
    mut h: *mut c2h,
) -> ::core::ffi::c_int {
    let mut ra: c2v = c2Mulxv(x, (*p).verts[e as usize]);
    let mut rb: c2v = c2Mulxv(
        x,
        (*p)
            .verts[(if e + 1 as ::core::ffi::c_int == (*p).count {
            0 as ::core::ffi::c_int
        } else {
            e + 1 as ::core::ffi::c_int
        }) as usize],
    );
    return c2SidePlanes(seg, ra, rb, h);
}
#[no_mangle]
pub unsafe extern "C" fn c22(mut s: *mut c2Simplex) {
    let mut a: c2v = (*s).a.p;
    let mut b: c2v = (*s).b.p;
    let mut u: ::core::ffi::c_float = c2Dot(b, c2Sub(b, a));
    let mut v: ::core::ffi::c_float = c2Dot(a, c2Sub(a, b));
    if v <= 0 as ::core::ffi::c_int as ::core::ffi::c_float {
        (*s).a.u = 1.0f32;
        (*s).div = 1.0f32;
        (*s).count = 1 as ::core::ffi::c_int;
    } else if u <= 0 as ::core::ffi::c_int as ::core::ffi::c_float {
        (*s).a = (*s).b;
        (*s).a.u = 1.0f32;
        (*s).div = 1.0f32;
        (*s).count = 1 as ::core::ffi::c_int;
    } else {
        (*s).a.u = u;
        (*s).b.u = v;
        (*s).div = u + v;
        (*s).count = 2 as ::core::ffi::c_int;
    };
}
#[no_mangle]
pub unsafe extern "C" fn c23(mut s: *mut c2Simplex) {
    let mut a: c2v = (*s).a.p;
    let mut b: c2v = (*s).b.p;
    let mut c: c2v = (*s).c.p;
    let mut uAB: ::core::ffi::c_float = c2Dot(b, c2Sub(b, a));
    let mut vAB: ::core::ffi::c_float = c2Dot(a, c2Sub(a, b));
    let mut uBC: ::core::ffi::c_float = c2Dot(c, c2Sub(c, b));
    let mut vBC: ::core::ffi::c_float = c2Dot(b, c2Sub(b, c));
    let mut uCA: ::core::ffi::c_float = c2Dot(a, c2Sub(a, c));
    let mut vCA: ::core::ffi::c_float = c2Dot(c, c2Sub(c, a));
    let mut area: ::core::ffi::c_float = c2Det2(c2Sub(b, a), c2Sub(c, a));
    let mut uABC: ::core::ffi::c_float = c2Det2(b, c) * area;
    let mut vABC: ::core::ffi::c_float = c2Det2(c, a) * area;
    let mut wABC: ::core::ffi::c_float = c2Det2(a, b) * area;
    if vAB <= 0 as ::core::ffi::c_int as ::core::ffi::c_float
        && uCA <= 0 as ::core::ffi::c_int as ::core::ffi::c_float
    {
        (*s).a.u = 1.0f32;
        (*s).div = 1.0f32;
        (*s).count = 1 as ::core::ffi::c_int;
    } else if uAB <= 0 as ::core::ffi::c_int as ::core::ffi::c_float
        && vBC <= 0 as ::core::ffi::c_int as ::core::ffi::c_float
    {
        (*s).a = (*s).b;
        (*s).a.u = 1.0f32;
        (*s).div = 1.0f32;
        (*s).count = 1 as ::core::ffi::c_int;
    } else if uBC <= 0 as ::core::ffi::c_int as ::core::ffi::c_float
        && vCA <= 0 as ::core::ffi::c_int as ::core::ffi::c_float
    {
        (*s).a = (*s).c;
        (*s).a.u = 1.0f32;
        (*s).div = 1.0f32;
        (*s).count = 1 as ::core::ffi::c_int;
    } else if uAB > 0 as ::core::ffi::c_int as ::core::ffi::c_float
        && vAB > 0 as ::core::ffi::c_int as ::core::ffi::c_float
        && wABC <= 0 as ::core::ffi::c_int as ::core::ffi::c_float
    {
        (*s).a.u = uAB;
        (*s).b.u = vAB;
        (*s).div = uAB + vAB;
        (*s).count = 2 as ::core::ffi::c_int;
    } else if uBC > 0 as ::core::ffi::c_int as ::core::ffi::c_float
        && vBC > 0 as ::core::ffi::c_int as ::core::ffi::c_float
        && uABC <= 0 as ::core::ffi::c_int as ::core::ffi::c_float
    {
        (*s).a = (*s).b;
        (*s).b = (*s).c;
        (*s).a.u = uBC;
        (*s).b.u = vBC;
        (*s).div = uBC + vBC;
        (*s).count = 2 as ::core::ffi::c_int;
    } else if uCA > 0 as ::core::ffi::c_int as ::core::ffi::c_float
        && vCA > 0 as ::core::ffi::c_int as ::core::ffi::c_float
        && vABC <= 0 as ::core::ffi::c_int as ::core::ffi::c_float
    {
        (*s).b = (*s).a;
        (*s).a = (*s).c;
        (*s).a.u = uCA;
        (*s).b.u = vCA;
        (*s).div = uCA + vCA;
        (*s).count = 2 as ::core::ffi::c_int;
    } else {
        (*s).a.u = uABC;
        (*s).b.u = vABC;
        (*s).c.u = wABC;
        (*s).div = uABC + vABC + wABC;
        (*s).count = 3 as ::core::ffi::c_int;
    };
}
#[no_mangle]
pub unsafe extern "C" fn c2Skew(mut a: c2v) -> c2v {
    let mut b: c2v = c2v { x: 0., y: 0. };
    b.x = -a.y;
    b.y = a.x;
    return b;
}
#[no_mangle]
pub unsafe extern "C" fn c2D(mut s: *mut c2Simplex) -> c2v {
    match (*s).count {
        1 => return c2Neg((*s).a.p),
        2 => {
            let mut ab: c2v = c2Sub((*s).b.p, (*s).a.p);
            if c2Det2(ab, c2Neg((*s).a.p))
                > 0 as ::core::ffi::c_int as ::core::ffi::c_float
            {
                return c2Skew(ab);
            }
            return c2CCW90(ab);
        }
        3 | _ => {
            return c2V(
                0 as ::core::ffi::c_int as ::core::ffi::c_float,
                0 as ::core::ffi::c_int as ::core::ffi::c_float,
            );
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn c2Support(
    mut verts: *const c2v,
    mut count: ::core::ffi::c_int,
    mut d: c2v,
) -> ::core::ffi::c_int {
    let mut imax: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut dmax: ::core::ffi::c_float = c2Dot(
        *verts.offset(0 as ::core::ffi::c_int as isize),
        d,
    );
    let mut i: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    while i < count {
        let mut dot: ::core::ffi::c_float = c2Dot(*verts.offset(i as isize), d);
        if dot > dmax {
            imax = i;
            dmax = dot;
        }
        i += 1;
    }
    return imax;
}
#[no_mangle]
pub unsafe extern "C" fn c2Witness(
    mut s: *mut c2Simplex,
    mut a: *mut c2v,
    mut b: *mut c2v,
) {
    let mut den: ::core::ffi::c_float = 1.0f32 / (*s).div;
    match (*s).count {
        1 => {
            *a = (*s).a.sA;
            *b = (*s).a.sB;
        }
        2 => {
            *a = c2Add(
                c2Mulvs((*s).a.sA, den * (*s).a.u),
                c2Mulvs((*s).b.sA, den * (*s).b.u),
            );
            *b = c2Add(
                c2Mulvs((*s).a.sB, den * (*s).a.u),
                c2Mulvs((*s).b.sB, den * (*s).b.u),
            );
        }
        3 => {
            *a = c2Add(
                c2Add(
                    c2Mulvs((*s).a.sA, den * (*s).a.u),
                    c2Mulvs((*s).b.sA, den * (*s).b.u),
                ),
                c2Mulvs((*s).c.sA, den * (*s).c.u),
            );
            *b = c2Add(
                c2Add(
                    c2Mulvs((*s).a.sB, den * (*s).a.u),
                    c2Mulvs((*s).b.sB, den * (*s).b.u),
                ),
                c2Mulvs((*s).c.sB, den * (*s).c.u),
            );
        }
        _ => {
            *a = c2V(
                0 as ::core::ffi::c_int as ::core::ffi::c_float,
                0 as ::core::ffi::c_int as ::core::ffi::c_float,
            );
            *b = c2V(
                0 as ::core::ffi::c_int as ::core::ffi::c_float,
                0 as ::core::ffi::c_int as ::core::ffi::c_float,
            );
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn c2L(mut s: *mut c2Simplex) -> c2v {
    let mut den: ::core::ffi::c_float = 1.0f32 / (*s).div;
    match (*s).count {
        1 => return (*s).a.p,
        2 => {
            return c2Add(
                c2Mulvs((*s).a.p, den * (*s).a.u),
                c2Mulvs((*s).b.p, den * (*s).b.u),
            );
        }
        _ => {
            return c2V(
                0 as ::core::ffi::c_int as ::core::ffi::c_float,
                0 as ::core::ffi::c_int as ::core::ffi::c_float,
            );
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn c2GJK(
    mut A: *const ::core::ffi::c_void,
    mut typeA: C2_TYPE,
    mut ax_ptr: *const c2x,
    mut B: *const ::core::ffi::c_void,
    mut typeB: C2_TYPE,
    mut bx_ptr: *const c2x,
    mut outA: *mut c2v,
    mut outB: *mut c2v,
    mut use_radius: ::core::ffi::c_int,
    mut iterations: *mut ::core::ffi::c_int,
    mut cache: *mut c2GJKCache,
) -> ::core::ffi::c_float {
    let mut ax: c2x = c2x {
        p: c2v { x: 0., y: 0. },
        r: c2r { c: 0., s: 0. },
    };
    let mut bx: c2x = c2x {
        p: c2v { x: 0., y: 0. },
        r: c2r { c: 0., s: 0. },
    };
    if ax_ptr.is_null() {
        ax = c2xIdentity();
    } else {
        ax = *ax_ptr;
    }
    if bx_ptr.is_null() {
        bx = c2xIdentity();
    } else {
        bx = *bx_ptr;
    }
    let mut pA: c2Proxy = c2Proxy {
        radius: 0.,
        count: 0,
        verts: [c2v { x: 0., y: 0. }; 8],
    };
    let mut pB: c2Proxy = c2Proxy {
        radius: 0.,
        count: 0,
        verts: [c2v { x: 0., y: 0. }; 8],
    };
    c2MakeProxy(A, typeA, &mut pA);
    c2MakeProxy(B, typeB, &mut pB);
    let mut s: c2Simplex = c2Simplex {
        a: c2sv {
            sA: c2v { x: 0., y: 0. },
            sB: c2v { x: 0., y: 0. },
            p: c2v { x: 0., y: 0. },
            u: 0.,
            iA: 0,
            iB: 0,
        },
        b: c2sv {
            sA: c2v { x: 0., y: 0. },
            sB: c2v { x: 0., y: 0. },
            p: c2v { x: 0., y: 0. },
            u: 0.,
            iA: 0,
            iB: 0,
        },
        c: c2sv {
            sA: c2v { x: 0., y: 0. },
            sB: c2v { x: 0., y: 0. },
            p: c2v { x: 0., y: 0. },
            u: 0.,
            iA: 0,
            iB: 0,
        },
        d: c2sv {
            sA: c2v { x: 0., y: 0. },
            sB: c2v { x: 0., y: 0. },
            p: c2v { x: 0., y: 0. },
            u: 0.,
            iA: 0,
            iB: 0,
        },
        div: 0.,
        count: 0,
    };
    let mut verts: *mut c2sv = &mut s.a;
    let mut cache_was_read: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    if !cache.is_null() {
        let mut cache_was_good: ::core::ffi::c_int = ((*cache).count != 0)
            as ::core::ffi::c_int;
        if cache_was_good != 0 {
            let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
            while i < (*cache).count {
                let mut iA: ::core::ffi::c_int = (*cache).iA[i as usize];
                let mut iB: ::core::ffi::c_int = (*cache).iB[i as usize];
                let mut sA: c2v = c2Mulxv(ax, pA.verts[iA as usize]);
                let mut sB: c2v = c2Mulxv(bx, pB.verts[iB as usize]);
                let mut v: *mut c2sv = verts.offset(i as isize);
                (*v).iA = iA;
                (*v).sA = sA;
                (*v).iB = iB;
                (*v).sB = sB;
                (*v).p = c2Sub((*v).sB, (*v).sA);
                (*v).u = 0 as ::core::ffi::c_int as ::core::ffi::c_float;
                i += 1;
            }
            s.count = (*cache).count;
            s.div = (*cache).div;
            let mut metric_old: ::core::ffi::c_float = (*cache).metric;
            let mut metric: ::core::ffi::c_float = c2GJKSimplexMetric(&mut s);
            let mut min_metric: ::core::ffi::c_float = if metric < metric_old {
                metric
            } else {
                metric_old
            };
            let mut max_metric: ::core::ffi::c_float = if metric > metric_old {
                metric
            } else {
                metric_old
            };
            if !(min_metric < max_metric * 2.0f32 && metric < -1.0e8f32) {
                cache_was_read = 1 as ::core::ffi::c_int;
            }
        }
    }
    if cache_was_read == 0 {
        s.a.iA = 0 as ::core::ffi::c_int;
        s.a.iB = 0 as ::core::ffi::c_int;
        s.a.sA = c2Mulxv(ax, pA.verts[0 as ::core::ffi::c_int as usize]);
        s.a.sB = c2Mulxv(bx, pB.verts[0 as ::core::ffi::c_int as usize]);
        s.a.p = c2Sub(s.a.sB, s.a.sA);
        s.a.u = 1.0f32;
        s.div = 1.0f32;
        s.count = 1 as ::core::ffi::c_int;
    }
    let mut saveA: [::core::ffi::c_int; 3] = [0; 3];
    let mut saveB: [::core::ffi::c_int; 3] = [0; 3];
    let mut save_count: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut d0: ::core::ffi::c_float = 3.40282346638528859811704183484516925e+38f32;
    let mut d1: ::core::ffi::c_float = 3.40282346638528859811704183484516925e+38f32;
    let mut iter: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut hit: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while iter < 20 as ::core::ffi::c_int {
        save_count = s.count;
        let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while i_0 < save_count {
            saveA[i_0 as usize] = (*verts.offset(i_0 as isize)).iA;
            saveB[i_0 as usize] = (*verts.offset(i_0 as isize)).iB;
            i_0 += 1;
        }
        match s.count {
            2 => {
                c22(&mut s);
            }
            3 => {
                c23(&mut s);
            }
            1 | _ => {}
        }
        if s.count == 3 as ::core::ffi::c_int {
            hit = 1 as ::core::ffi::c_int;
            break;
        } else {
            let mut p: c2v = c2L(&mut s);
            d1 = c2Dot(p, p);
            if d1 > d0 {
                break;
            }
            d0 = d1;
            let mut d: c2v = c2D(&mut s);
            if c2Dot(d, d)
                < 1.19209289550781250000000000000000000e-7f32
                    * 1.19209289550781250000000000000000000e-7f32
            {
                break;
            }
            let mut iA_0: ::core::ffi::c_int = c2Support(
                pA.verts.as_mut_ptr(),
                pA.count,
                c2MulrvT(ax.r, c2Neg(d)),
            );
            let mut sA_0: c2v = c2Mulxv(ax, pA.verts[iA_0 as usize]);
            let mut iB_0: ::core::ffi::c_int = c2Support(
                pB.verts.as_mut_ptr(),
                pB.count,
                c2MulrvT(bx.r, d),
            );
            let mut sB_0: c2v = c2Mulxv(bx, pB.verts[iB_0 as usize]);
            let mut v_0: *mut c2sv = verts.offset(s.count as isize);
            (*v_0).iA = iA_0;
            (*v_0).sA = sA_0;
            (*v_0).iB = iB_0;
            (*v_0).sB = sB_0;
            (*v_0).p = c2Sub((*v_0).sB, (*v_0).sA);
            let mut dup: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
            let mut i_1: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
            while i_1 < save_count {
                if iA_0 == saveA[i_1 as usize] && iB_0 == saveB[i_1 as usize] {
                    dup = 1 as ::core::ffi::c_int;
                    break;
                } else {
                    i_1 += 1;
                }
            }
            if dup != 0 {
                break;
            }
            s.count += 1;
            iter += 1;
        }
    }
    let mut a: c2v = c2v { x: 0., y: 0. };
    let mut b: c2v = c2v { x: 0., y: 0. };
    c2Witness(&mut s, &mut a, &mut b);
    let mut dist: ::core::ffi::c_float = c2Len(c2Sub(a, b));
    if hit != 0 {
        a = b;
        dist = 0 as ::core::ffi::c_int as ::core::ffi::c_float;
    } else if use_radius != 0 {
        let mut rA: ::core::ffi::c_float = pA.radius;
        let mut rB: ::core::ffi::c_float = pB.radius;
        if dist > rA + rB && dist > 1.19209289550781250000000000000000000e-7f32 {
            dist -= rA + rB;
            let mut n: c2v = c2Norm(c2Sub(b, a));
            a = c2Add(a, c2Mulvs(n, rA));
            b = c2Sub(b, c2Mulvs(n, rB));
            if a.x == b.x && a.y == b.y {
                dist = 0 as ::core::ffi::c_int as ::core::ffi::c_float;
            }
        } else {
            let mut p_0: c2v = c2Mulvs(c2Add(a, b), 0.5f32);
            a = p_0;
            b = p_0;
            dist = 0 as ::core::ffi::c_int as ::core::ffi::c_float;
        }
    }
    if !cache.is_null() {
        (*cache).metric = c2GJKSimplexMetric(&mut s);
        (*cache).count = s.count;
        let mut i_2: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while i_2 < s.count {
            let mut v_1: *mut c2sv = verts.offset(i_2 as isize);
            (*cache).iA[i_2 as usize] = (*v_1).iA;
            (*cache).iB[i_2 as usize] = (*v_1).iB;
            i_2 += 1;
        }
        (*cache).div = s.div;
    }
    if !outA.is_null() {
        *outA = a;
    }
    if !outB.is_null() {
        *outB = b;
    }
    if !iterations.is_null() {
        *iterations = iter;
    }
    return dist;
}
#[no_mangle]
pub unsafe extern "C" fn c2Absv(mut a: c2v) -> c2v {
    return c2V(
        if a.x < 0 as ::core::ffi::c_int as ::core::ffi::c_float { -a.x } else { a.x },
        if a.y < 0 as ::core::ffi::c_int as ::core::ffi::c_float { -a.y } else { a.y },
    );
}
#[no_mangle]
pub unsafe extern "C" fn c2CircletoCircleManifold(
    mut A: c2Circle,
    mut B: c2Circle,
    mut m: *mut c2Manifold,
) {
    (*m).count = 0 as ::core::ffi::c_int;
    let mut d: c2v = c2Sub(B.p, A.p);
    let mut d2: ::core::ffi::c_float = c2Dot(d, d);
    let mut r: ::core::ffi::c_float = A.r + B.r;
    if d2 < r * r {
        let mut l: ::core::ffi::c_float = sqrtf(d2);
        let mut n: c2v = if l != 0 as ::core::ffi::c_int as ::core::ffi::c_float {
            c2Mulvs(d, 1.0f32 / l)
        } else {
            c2V(0 as ::core::ffi::c_int as ::core::ffi::c_float, 1.0f32)
        };
        (*m).count = 1 as ::core::ffi::c_int;
        (*m).depths[0 as ::core::ffi::c_int as usize] = r - l;
        (*m).contact_points[0 as ::core::ffi::c_int as usize] = c2Sub(
            B.p,
            c2Mulvs(n, B.r),
        );
        (*m).n = n;
    }
}
#[no_mangle]
pub unsafe extern "C" fn c2CircletoAABBManifold(
    mut A: c2Circle,
    mut B: c2AABB,
    mut m: *mut c2Manifold,
) {
    (*m).count = 0 as ::core::ffi::c_int;
    let mut L: c2v = c2Clampv(A.p, B.min, B.max);
    let mut ab: c2v = c2Sub(L, A.p);
    let mut d2: ::core::ffi::c_float = c2Dot(ab, ab);
    let mut r2: ::core::ffi::c_float = A.r * A.r;
    if d2 < r2 {
        if d2 != 0 as ::core::ffi::c_int as ::core::ffi::c_float {
            let mut d: ::core::ffi::c_float = sqrtf(d2);
            let mut n: c2v = c2Norm(ab);
            (*m).count = 1 as ::core::ffi::c_int;
            (*m).depths[0 as ::core::ffi::c_int as usize] = A.r - d;
            (*m).contact_points[0 as ::core::ffi::c_int as usize] = c2Add(
                A.p,
                c2Mulvs(n, d),
            );
            (*m).n = n;
        } else {
            let mut mid: c2v = c2Mulvs(c2Add(B.min, B.max), 0.5f32);
            let mut e: c2v = c2Mulvs(c2Sub(B.max, B.min), 0.5f32);
            let mut d_0: c2v = c2Sub(A.p, mid);
            let mut abs_d: c2v = c2Absv(d_0);
            let mut x_overlap: ::core::ffi::c_float = e.x - abs_d.x;
            let mut y_overlap: ::core::ffi::c_float = e.y - abs_d.y;
            let mut depth: ::core::ffi::c_float = 0.;
            let mut n_0: c2v = c2v { x: 0., y: 0. };
            if x_overlap < y_overlap {
                depth = x_overlap;
                n_0 = c2V(1.0f32, 0 as ::core::ffi::c_int as ::core::ffi::c_float);
                n_0 = c2Mulvs(
                    n_0,
                    if d_0.x < 0 as ::core::ffi::c_int as ::core::ffi::c_float {
                        1.0f32
                    } else {
                        -1.0f32
                    },
                );
            } else {
                depth = y_overlap;
                n_0 = c2V(0 as ::core::ffi::c_int as ::core::ffi::c_float, 1.0f32);
                n_0 = c2Mulvs(
                    n_0,
                    if d_0.y < 0 as ::core::ffi::c_int as ::core::ffi::c_float {
                        1.0f32
                    } else {
                        -1.0f32
                    },
                );
            }
            (*m).count = 1 as ::core::ffi::c_int;
            (*m).depths[0 as ::core::ffi::c_int as usize] = A.r + depth;
            (*m).contact_points[0 as ::core::ffi::c_int as usize] = c2Sub(
                A.p,
                c2Mulvs(n_0, depth),
            );
            (*m).n = n_0;
        }
    }
}
#[no_mangle]
pub unsafe extern "C" fn c2CircletoCapsuleManifold(
    mut A: c2Circle,
    mut B: c2Capsule,
    mut m: *mut c2Manifold,
) {
    (*m).count = 0 as ::core::ffi::c_int;
    let mut a: c2v = c2v { x: 0., y: 0. };
    let mut b: c2v = c2v { x: 0., y: 0. };
    let mut r: ::core::ffi::c_float = A.r + B.r;
    let mut d: ::core::ffi::c_float = c2GJK(
        &mut A as *mut c2Circle as *const ::core::ffi::c_void,
        C2_TYPE_CIRCLE,
        0 as *const c2x,
        &mut B as *mut c2Capsule as *const ::core::ffi::c_void,
        C2_TYPE_CAPSULE,
        0 as *const c2x,
        &mut a,
        &mut b,
        0 as ::core::ffi::c_int,
        0 as *mut ::core::ffi::c_int,
        0 as *mut c2GJKCache,
    );
    if d < r {
        let mut n: c2v = c2v { x: 0., y: 0. };
        if d == 0 as ::core::ffi::c_int as ::core::ffi::c_float {
            n = c2Norm(c2Skew(c2Sub(B.b, B.a)));
        } else {
            n = c2Norm(c2Sub(b, a));
        }
        (*m).count = 1 as ::core::ffi::c_int;
        (*m).depths[0 as ::core::ffi::c_int as usize] = r - d;
        (*m).contact_points[0 as ::core::ffi::c_int as usize] = c2Sub(
            b,
            c2Mulvs(n, B.r),
        );
        (*m).n = n;
    }
}
#[no_mangle]
pub unsafe extern "C" fn c2AABBtoAABBManifold(
    mut A: c2AABB,
    mut B: c2AABB,
    mut m: *mut c2Manifold,
) {
    (*m).count = 0 as ::core::ffi::c_int;
    let mut mid_a: c2v = c2Mulvs(c2Add(A.min, A.max), 0.5f32);
    let mut mid_b: c2v = c2Mulvs(c2Add(B.min, B.max), 0.5f32);
    let mut eA: c2v = c2Absv(c2Mulvs(c2Sub(A.max, A.min), 0.5f32));
    let mut eB: c2v = c2Absv(c2Mulvs(c2Sub(B.max, B.min), 0.5f32));
    let mut d: c2v = c2Sub(mid_b, mid_a);
    let mut dx: ::core::ffi::c_float = eA.x + eB.x
        - (if d.x < 0 as ::core::ffi::c_int as ::core::ffi::c_float {
            -d.x
        } else {
            d.x
        });
    if dx < 0 as ::core::ffi::c_int as ::core::ffi::c_float {
        return;
    }
    let mut dy: ::core::ffi::c_float = eA.y + eB.y
        - (if d.y < 0 as ::core::ffi::c_int as ::core::ffi::c_float {
            -d.y
        } else {
            d.y
        });
    if dy < 0 as ::core::ffi::c_int as ::core::ffi::c_float {
        return;
    }
    let mut n: c2v = c2v { x: 0., y: 0. };
    let mut depth: ::core::ffi::c_float = 0.;
    let mut p: c2v = c2v { x: 0., y: 0. };
    if dx < dy {
        depth = dx;
        if d.x < 0 as ::core::ffi::c_int as ::core::ffi::c_float {
            n = c2V(-1.0f32, 0 as ::core::ffi::c_int as ::core::ffi::c_float);
            p = c2Sub(mid_a, c2V(eA.x, 0 as ::core::ffi::c_int as ::core::ffi::c_float));
        } else {
            n = c2V(1.0f32, 0 as ::core::ffi::c_int as ::core::ffi::c_float);
            p = c2Add(mid_a, c2V(eA.x, 0 as ::core::ffi::c_int as ::core::ffi::c_float));
        }
    } else {
        depth = dy;
        if d.y < 0 as ::core::ffi::c_int as ::core::ffi::c_float {
            n = c2V(0 as ::core::ffi::c_int as ::core::ffi::c_float, -1.0f32);
            p = c2Sub(mid_a, c2V(0 as ::core::ffi::c_int as ::core::ffi::c_float, eA.y));
        } else {
            n = c2V(0 as ::core::ffi::c_int as ::core::ffi::c_float, 1.0f32);
            p = c2Add(mid_a, c2V(0 as ::core::ffi::c_int as ::core::ffi::c_float, eA.y));
        }
    }
    (*m).count = 1 as ::core::ffi::c_int;
    (*m).contact_points[0 as ::core::ffi::c_int as usize] = p;
    (*m).depths[0 as ::core::ffi::c_int as usize] = depth;
    (*m).n = n;
}
unsafe extern "C" fn c2KeepDeep(mut seg: *mut c2v, mut h: c2h, mut m: *mut c2Manifold) {
    let mut cp: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < 2 as ::core::ffi::c_int {
        let mut p: c2v = *seg.offset(i as isize);
        let mut d: ::core::ffi::c_float = c2Dist(h, p);
        if d <= 0 as ::core::ffi::c_int as ::core::ffi::c_float {
            (*m).contact_points[cp as usize] = p;
            (*m).depths[cp as usize] = -d;
            cp += 1;
        }
        i += 1;
    }
    (*m).count = cp;
    (*m).n = h.n;
}
unsafe extern "C" fn c2Incident(
    mut incident: *mut c2v,
    mut ip: *const c2Poly,
    mut ix: c2x,
    mut rn_in_incident_space: c2v,
) {
    let mut index: ::core::ffi::c_int = !(0 as ::core::ffi::c_int);
    let mut min_dot: ::core::ffi::c_float = 3.40282346638528859811704183484516925e+38f32;
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*ip).count {
        let mut dot: ::core::ffi::c_float = c2Dot(
            rn_in_incident_space,
            (*ip).norms[i as usize],
        );
        if dot < min_dot {
            min_dot = dot;
            index = i;
        }
        i += 1;
    }
    *incident.offset(0 as ::core::ffi::c_int as isize) = c2Mulxv(
        ix,
        (*ip).verts[index as usize],
    );
    *incident.offset(1 as ::core::ffi::c_int as isize) = c2Mulxv(
        ix,
        (*ip)
            .verts[(if index + 1 as ::core::ffi::c_int == (*ip).count {
            0 as ::core::ffi::c_int
        } else {
            index + 1 as ::core::ffi::c_int
        }) as usize],
    );
}
#[no_mangle]
pub unsafe extern "C" fn c2CapsuletoPolyManifold(
    mut A: c2Capsule,
    mut B: *const c2Poly,
    mut bx_ptr: *const c2x,
    mut m: *mut c2Manifold,
) {
    (*m).count = 0 as ::core::ffi::c_int;
    let mut a: c2v = c2v { x: 0., y: 0. };
    let mut b: c2v = c2v { x: 0., y: 0. };
    let mut d: ::core::ffi::c_float = c2GJK(
        &mut A as *mut c2Capsule as *const ::core::ffi::c_void,
        C2_TYPE_CAPSULE,
        0 as *const c2x,
        B as *const ::core::ffi::c_void,
        C2_TYPE_POLY,
        bx_ptr,
        &mut a,
        &mut b,
        0 as ::core::ffi::c_int,
        0 as *mut ::core::ffi::c_int,
        0 as *mut c2GJKCache,
    );
    if d < 1.0e-6f32 {
        let mut bx: c2x = if !bx_ptr.is_null() { *bx_ptr } else { c2xIdentity() };
        let mut A_in_B: c2Capsule = c2Capsule {
            a: c2v { x: 0., y: 0. },
            b: c2v { x: 0., y: 0. },
            r: 0.,
        };
        A_in_B.a = c2MulxvT(bx, A.a);
        A_in_B.b = c2MulxvT(bx, A.b);
        let mut ab: c2v = c2Norm(c2Sub(A_in_B.a, A_in_B.b));
        let mut ab_h0: c2h = c2h {
            n: c2v { x: 0., y: 0. },
            d: 0.,
        };
        ab_h0.n = c2CCW90(ab);
        ab_h0.d = c2Dot(A_in_B.a, ab_h0.n);
        let mut v0: ::core::ffi::c_int = c2Support(
            (*B).verts.as_ptr(),
            (*B).count,
            c2Neg(ab_h0.n),
        );
        let mut s0: ::core::ffi::c_float = c2Dist(ab_h0, (*B).verts[v0 as usize]);
        let mut ab_h1: c2h = c2h {
            n: c2v { x: 0., y: 0. },
            d: 0.,
        };
        ab_h1.n = c2Skew(ab);
        ab_h1.d = c2Dot(A_in_B.a, ab_h1.n);
        let mut v1: ::core::ffi::c_int = c2Support(
            (*B).verts.as_ptr(),
            (*B).count,
            c2Neg(ab_h1.n),
        );
        let mut s1: ::core::ffi::c_float = c2Dist(ab_h1, (*B).verts[v1 as usize]);
        let mut index: ::core::ffi::c_int = !(0 as ::core::ffi::c_int);
        let mut sep: ::core::ffi::c_float = -3.40282346638528859811704183484516925e+38f32;
        let mut code: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while i < (*B).count {
            let mut h: c2h = c2PlaneAt(B, i);
            let mut da: ::core::ffi::c_float = c2Dot(A_in_B.a, c2Neg(h.n));
            let mut db: ::core::ffi::c_float = c2Dot(A_in_B.b, c2Neg(h.n));
            let mut d_0: ::core::ffi::c_float = 0.;
            if da > db {
                d_0 = c2Dist(h, A_in_B.a);
            } else {
                d_0 = c2Dist(h, A_in_B.b);
            }
            if d_0 > sep {
                sep = d_0;
                index = i;
            }
            i += 1;
        }
        if s0 > sep {
            sep = s0;
            index = v0;
            code = 1 as ::core::ffi::c_int;
        }
        if s1 > sep {
            sep = s1;
            index = v1;
            code = 2 as ::core::ffi::c_int;
        }
        match code {
            0 => {
                let mut seg: [c2v; 2] = [A.a, A.b];
                let mut h_0: c2h = c2h {
                    n: c2v { x: 0., y: 0. },
                    d: 0.,
                };
                if c2SidePlanesFromPoly(seg.as_mut_ptr(), bx, B, index, &mut h_0) == 0 {
                    return;
                }
                c2KeepDeep(seg.as_mut_ptr(), h_0, m);
                (*m).n = c2Neg((*m).n);
            }
            1 => {
                let mut incident: [c2v; 2] = [c2v { x: 0., y: 0. }; 2];
                c2Incident(incident.as_mut_ptr(), B, bx, ab_h0.n);
                let mut h_1: c2h = c2h {
                    n: c2v { x: 0., y: 0. },
                    d: 0.,
                };
                if c2SidePlanes(incident.as_mut_ptr(), A_in_B.b, A_in_B.a, &mut h_1) == 0
                {
                    return;
                }
                c2KeepDeep(incident.as_mut_ptr(), h_1, m);
            }
            2 => {
                let mut incident_0: [c2v; 2] = [c2v { x: 0., y: 0. }; 2];
                c2Incident(incident_0.as_mut_ptr(), B, bx, ab_h1.n);
                let mut h_2: c2h = c2h {
                    n: c2v { x: 0., y: 0. },
                    d: 0.,
                };
                if c2SidePlanes(incident_0.as_mut_ptr(), A_in_B.a, A_in_B.b, &mut h_2)
                    == 0
                {
                    return;
                }
                c2KeepDeep(incident_0.as_mut_ptr(), h_2, m);
            }
            _ => return,
        }
        let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while i_0 < (*m).count {
            (*m).depths[i_0 as usize] += A.r;
            i_0 += 1;
        }
    } else if d < A.r {
        (*m).count = 1 as ::core::ffi::c_int;
        (*m).n = c2Norm(c2Sub(b, a));
        (*m).contact_points[0 as ::core::ffi::c_int as usize] = c2Add(
            a,
            c2Mulvs((*m).n, A.r),
        );
        (*m).depths[0 as ::core::ffi::c_int as usize] = A.r - d;
    }
}
#[no_mangle]
pub unsafe extern "C" fn c2Norms(
    mut verts: *mut c2v,
    mut norms: *mut c2v,
    mut count: ::core::ffi::c_int,
) {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < count {
        let mut a: ::core::ffi::c_int = i;
        let mut b: ::core::ffi::c_int = if (i + 1 as ::core::ffi::c_int) < count {
            i + 1 as ::core::ffi::c_int
        } else {
            0 as ::core::ffi::c_int
        };
        let mut e: c2v = c2Sub(*verts.offset(b as isize), *verts.offset(a as isize));
        *norms.offset(i as isize) = c2Norm(c2CCW90(e));
        i += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn c2AABBtoCapsuleManifold(
    mut A: c2AABB,
    mut B: c2Capsule,
    mut m: *mut c2Manifold,
) {
    (*m).count = 0 as ::core::ffi::c_int;
    let mut p: c2Poly = c2Poly {
        count: 0,
        verts: [c2v { x: 0., y: 0. }; 8],
        norms: [c2v { x: 0., y: 0. }; 8],
    };
    c2BBVerts(p.verts.as_mut_ptr(), &mut A);
    p.count = 4 as ::core::ffi::c_int;
    c2Norms(p.verts.as_mut_ptr(), p.norms.as_mut_ptr(), 4 as ::core::ffi::c_int);
    c2CapsuletoPolyManifold(B, &mut p, 0 as *const c2x, m);
    (*m).n = c2Neg((*m).n);
}
#[no_mangle]
pub unsafe extern "C" fn c2CapsuletoCapsuleManifold(
    mut A: c2Capsule,
    mut B: c2Capsule,
    mut m: *mut c2Manifold,
) {
    (*m).count = 0 as ::core::ffi::c_int;
    let mut a: c2v = c2v { x: 0., y: 0. };
    let mut b: c2v = c2v { x: 0., y: 0. };
    let mut r: ::core::ffi::c_float = A.r + B.r;
    let mut d: ::core::ffi::c_float = c2GJK(
        &mut A as *mut c2Capsule as *const ::core::ffi::c_void,
        C2_TYPE_CAPSULE,
        0 as *const c2x,
        &mut B as *mut c2Capsule as *const ::core::ffi::c_void,
        C2_TYPE_CAPSULE,
        0 as *const c2x,
        &mut a,
        &mut b,
        0 as ::core::ffi::c_int,
        0 as *mut ::core::ffi::c_int,
        0 as *mut c2GJKCache,
    );
    if d < r {
        let mut n: c2v = c2v { x: 0., y: 0. };
        if d == 0 as ::core::ffi::c_int as ::core::ffi::c_float {
            n = c2Norm(c2Skew(c2Sub(A.b, A.a)));
        } else {
            n = c2Norm(c2Sub(b, a));
        }
        (*m).count = 1 as ::core::ffi::c_int;
        (*m).depths[0 as ::core::ffi::c_int as usize] = r - d;
        (*m).contact_points[0 as ::core::ffi::c_int as usize] = c2Sub(
            b,
            c2Mulvs(n, B.r),
        );
        (*m).n = n;
    }
}
#[no_mangle]
pub unsafe extern "C" fn c2Collide(
    mut A: *const ::core::ffi::c_void,
    mut typeA: C2_TYPE,
    mut B: *const ::core::ffi::c_void,
    mut typeB: C2_TYPE,
    mut m: *mut c2Manifold,
) {
    (*m).count = 0 as ::core::ffi::c_int;
    match typeA as ::core::ffi::c_uint {
        1 => {
            match typeB as ::core::ffi::c_uint {
                1 => {
                    c2CircletoCircleManifold(
                        *(A as *mut c2Circle),
                        *(B as *mut c2Circle),
                        m,
                    );
                }
                2 => {
                    c2CircletoAABBManifold(
                        *(A as *mut c2Circle),
                        *(B as *mut c2AABB),
                        m,
                    );
                }
                0 => {
                    c2CircletoCapsuleManifold(
                        *(A as *mut c2Circle),
                        *(B as *mut c2Capsule),
                        m,
                    );
                }
                _ => {}
            }
        }
        2 => {
            match typeB as ::core::ffi::c_uint {
                1 => {
                    c2CircletoAABBManifold(
                        *(B as *mut c2Circle),
                        *(A as *mut c2AABB),
                        m,
                    );
                    (*m).n = c2Neg((*m).n);
                }
                2 => {
                    c2AABBtoAABBManifold(*(A as *mut c2AABB), *(B as *mut c2AABB), m);
                }
                0 => {
                    c2AABBtoCapsuleManifold(
                        *(A as *mut c2AABB),
                        *(B as *mut c2Capsule),
                        m,
                    );
                }
                _ => {}
            }
        }
        0 => {
            match typeB as ::core::ffi::c_uint {
                1 => {
                    c2CircletoCapsuleManifold(
                        *(B as *mut c2Circle),
                        *(A as *mut c2Capsule),
                        m,
                    );
                    (*m).n = c2Neg((*m).n);
                }
                2 => {
                    c2AABBtoCapsuleManifold(
                        *(B as *mut c2AABB),
                        *(A as *mut c2Capsule),
                        m,
                    );
                    (*m).n = c2Neg((*m).n);
                }
                0 => {
                    c2CapsuletoCapsuleManifold(
                        *(A as *mut c2Capsule),
                        *(B as *mut c2Capsule),
                        m,
                    );
                }
                _ => {}
            }
        }
        _ => {}
    };
}
#[no_mangle]
pub unsafe extern "C" fn ptr_from_parts(
    mut typ: C2_TYPE,
    mut a: ::core::ffi::c_float,
    mut b: ::core::ffi::c_float,
    mut c: ::core::ffi::c_float,
    mut d: ::core::ffi::c_float,
    mut e: ::core::ffi::c_float,
) -> *mut ::core::ffi::c_void {
    let mut circle: *mut c2Circle = 0 as *mut c2Circle;
    let mut aabb: *mut c2AABB = 0 as *mut c2AABB;
    let mut capsule: *mut c2Capsule = 0 as *mut c2Capsule;
    match typ as ::core::ffi::c_uint {
        1 => {
            circle = malloc(::core::mem::size_of::<c2Circle>() as size_t)
                as *mut c2Circle;
            (*circle).p = c2V(a, b);
            (*circle).r = c;
            return circle as *mut ::core::ffi::c_void;
        }
        2 => {
            aabb = malloc(::core::mem::size_of::<c2AABB>() as size_t) as *mut c2AABB;
            (*aabb).min = c2V(a, b);
            (*aabb).max = c2V(c, d);
            return aabb as *mut ::core::ffi::c_void;
        }
        0 => {
            capsule = malloc(::core::mem::size_of::<c2Capsule>() as size_t)
                as *mut c2Capsule;
            (*capsule).a = c2V(a, b);
            (*capsule).b = c2V(c, d);
            (*capsule).r = e;
            return capsule as *mut ::core::ffi::c_void;
        }
        _ => {}
    }
    panic!("Reached end of non-void function without returning");
}
#[no_mangle]
pub unsafe extern "C" fn omni_manifold(
    mut m: *mut c2Manifold,
    mut type_a: C2_TYPE,
    mut a1: ::core::ffi::c_float,
    mut a2: ::core::ffi::c_float,
    mut a3: ::core::ffi::c_float,
    mut a4: ::core::ffi::c_float,
    mut a5: ::core::ffi::c_float,
    mut type_b: C2_TYPE,
    mut b1: ::core::ffi::c_float,
    mut b2: ::core::ffi::c_float,
    mut b3: ::core::ffi::c_float,
    mut b4: ::core::ffi::c_float,
    mut b5: ::core::ffi::c_float,
) {
    let mut A: *mut ::core::ffi::c_void = ptr_from_parts(type_a, a1, a2, a3, a4, a5);
    let mut B: *mut ::core::ffi::c_void = ptr_from_parts(type_b, b1, b2, b3, b4, b5);
    c2Collide(A, type_a, B, type_b, m);
}
