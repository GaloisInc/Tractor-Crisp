#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type re_guts;
    pub type __sFILEX;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strstr(
        __big: *const ::core::ffi::c_char,
        __little: *const ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
    fn strdup(__s1: *const ::core::ffi::c_char) -> *mut ::core::ffi::c_char;
    fn regcomp(
        _: *mut regex_t,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn regexec(
        _: *const regex_t,
        _: *const ::core::ffi::c_char,
        _: size_t,
        __pmatch: *mut regmatch_t,
        _: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn regfree(_: *mut regex_t);
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn snprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct os_data {
    pub os_name: *mut ::core::ffi::c_char,
    pub os_version: *mut ::core::ffi::c_char,
    pub os_major: *mut ::core::ffi::c_char,
    pub os_minor: *mut ::core::ffi::c_char,
    pub os_codename: *mut ::core::ffi::c_char,
    pub os_platform: *mut ::core::ffi::c_char,
    pub os_build: *mut ::core::ffi::c_char,
    pub os_uname: *mut ::core::ffi::c_char,
    pub os_arch: *mut ::core::ffi::c_char,
}
pub type size_t = __darwin_size_t;
pub type __darwin_size_t = usize;
pub type regoff_t = __darwin_off_t;
pub type __darwin_off_t = __int64_t;
pub type __int64_t = i64;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct regmatch_t {
    pub rm_so: regoff_t,
    pub rm_eo: regoff_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct regex_t {
    pub re_magic: ::core::ffi::c_int,
    pub re_nsub: size_t,
    pub re_endp: *const ::core::ffi::c_char,
    pub re_g: *mut re_guts,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const REG_EXTENDED: ::core::ffi::c_int = 0o1 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn get_os_arch(
    mut os_header: *mut ::core::ffi::c_char,
) -> *mut ::core::ffi::c_char {
    let mut ARCHS: [*const ::core::ffi::c_char; 13] = [
        b"x86_64\0" as *const u8 as *const ::core::ffi::c_char,
        b"i386\0" as *const u8 as *const ::core::ffi::c_char,
        b"i686\0" as *const u8 as *const ::core::ffi::c_char,
        b"sparc\0" as *const u8 as *const ::core::ffi::c_char,
        b"amd64\0" as *const u8 as *const ::core::ffi::c_char,
        b"i86pc\0" as *const u8 as *const ::core::ffi::c_char,
        b"ia64\0" as *const u8 as *const ::core::ffi::c_char,
        b"AIX\0" as *const u8 as *const ::core::ffi::c_char,
        b"armv6\0" as *const u8 as *const ::core::ffi::c_char,
        b"armv7\0" as *const u8 as *const ::core::ffi::c_char,
        b"aarch64\0" as *const u8 as *const ::core::ffi::c_char,
        b"arm64\0" as *const u8 as *const ::core::ffi::c_char,
        0 as *const ::core::ffi::c_char,
    ];
    let mut os_arch: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut i: ::core::ffi::c_int = 0;
    i = 0 as ::core::ffi::c_int;
    while !ARCHS[i as usize].is_null() {
        if !strstr(os_header, ARCHS[i as usize]).is_null() {
            os_arch = strdup(ARCHS[i as usize]);
            break;
        } else {
            i += 1;
        }
    }
    return os_arch;
}
#[no_mangle]
pub unsafe extern "C" fn w_regexec(
    mut pattern: *const ::core::ffi::c_char,
    mut string: *const ::core::ffi::c_char,
    mut nmatch: size_t,
    mut pmatch: *mut regmatch_t,
) -> ::core::ffi::c_int {
    let mut regex: regex_t = regex_t {
        re_magic: 0,
        re_nsub: 0,
        re_endp: 0 as *const ::core::ffi::c_char,
        re_g: 0 as *mut re_guts,
    };
    let mut result: ::core::ffi::c_int = 0;
    if !(!pattern.is_null() && !string.is_null()) {
        return 0 as ::core::ffi::c_int;
    }
    if regcomp(&mut regex, pattern, REG_EXTENDED) != 0 {
        fprintf(
            __stderrp,
            b"Couldn't compile regular expression '%s'\n\0" as *const u8
                as *const ::core::ffi::c_char,
            pattern,
        );
        return 0 as ::core::ffi::c_int;
    }
    result = regexec(
        &mut regex,
        string,
        nmatch,
        pmatch as *mut regmatch_t,
        0 as ::core::ffi::c_int,
    );
    regfree(&mut regex);
    return (result == 0) as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn parse_uname_string(
    mut uname: *mut ::core::ffi::c_char,
    mut osd: *mut os_data,
) {
    let mut str_tmp: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut match_0: [regmatch_t; 2] = [
        {
            let mut init = regmatch_t {
                rm_so: 0 as regoff_t,
                rm_eo: 0,
            };
            init
        },
        regmatch_t { rm_so: 0, rm_eo: 0 },
    ];
    let mut match_size: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    if osd.is_null() {
        return;
    }
    str_tmp = strstr(uname, b" [Ver: \0" as *const u8 as *const ::core::ffi::c_char);
    if !str_tmp.is_null() {
        *str_tmp = '\0' as i32 as ::core::ffi::c_char;
        str_tmp = str_tmp.offset(7 as ::core::ffi::c_int as isize);
        (*osd).os_name = strdup(uname);
        *str_tmp
            .offset(strlen(str_tmp) as isize)
            .offset(-(1 as ::core::ffi::c_int as isize)) = '\0' as i32
            as ::core::ffi::c_char;
        if w_regexec(
            b"^([0-9]+)\\.*\0" as *const u8 as *const ::core::ffi::c_char,
            str_tmp,
            2 as size_t,
            match_0.as_mut_ptr(),
        ) != 0
        {
            match_size = (match_0[1 as ::core::ffi::c_int as usize].rm_eo
                - match_0[1 as ::core::ffi::c_int as usize].rm_so) as ::core::ffi::c_int;
            (*osd).os_major = malloc((match_size + 1 as ::core::ffi::c_int) as size_t)
                as *mut ::core::ffi::c_char;
            snprintf(
                (*osd).os_major,
                (match_size + 1 as ::core::ffi::c_int) as size_t,
                b"%.*s\0" as *const u8 as *const ::core::ffi::c_char,
                match_size,
                str_tmp.offset(match_0[1 as ::core::ffi::c_int as usize].rm_so as isize),
            );
        }
        if w_regexec(
            b"^[0-9]+\\.([0-9]+)\\.*\0" as *const u8 as *const ::core::ffi::c_char,
            str_tmp,
            2 as size_t,
            match_0.as_mut_ptr(),
        ) != 0
        {
            match_size = (match_0[1 as ::core::ffi::c_int as usize].rm_eo
                - match_0[1 as ::core::ffi::c_int as usize].rm_so) as ::core::ffi::c_int;
            (*osd).os_minor = malloc((match_size + 1 as ::core::ffi::c_int) as size_t)
                as *mut ::core::ffi::c_char;
            snprintf(
                (*osd).os_minor,
                (match_size + 1 as ::core::ffi::c_int) as size_t,
                b"%.*s\0" as *const u8 as *const ::core::ffi::c_char,
                match_size,
                str_tmp.offset(match_0[1 as ::core::ffi::c_int as usize].rm_so as isize),
            );
        }
        if w_regexec(
            b"^[0-9]+\\.[0-9]+\\.([0-9]+(\\.[0-9]+)*)\\.*\0" as *const u8
                as *const ::core::ffi::c_char,
            str_tmp,
            2 as size_t,
            match_0.as_mut_ptr(),
        ) != 0
        {
            match_size = (match_0[1 as ::core::ffi::c_int as usize].rm_eo
                - match_0[1 as ::core::ffi::c_int as usize].rm_so) as ::core::ffi::c_int;
            (*osd).os_build = malloc((match_size + 1 as ::core::ffi::c_int) as size_t)
                as *mut ::core::ffi::c_char;
            snprintf(
                (*osd).os_build,
                (match_size + 1 as ::core::ffi::c_int) as size_t,
                b"%.*s\0" as *const u8 as *const ::core::ffi::c_char,
                match_size,
                str_tmp.offset(match_0[1 as ::core::ffi::c_int as usize].rm_so as isize),
            );
        }
        (*osd).os_version = strdup(str_tmp);
        (*osd).os_platform = strdup(
            b"windows\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {
        str_tmp = strstr(uname, b" [\0" as *const u8 as *const ::core::ffi::c_char);
        if !str_tmp.is_null() {
            *str_tmp = '\0' as i32 as ::core::ffi::c_char;
            str_tmp = str_tmp.offset(2 as ::core::ffi::c_int as isize);
            (*osd).os_name = strdup(str_tmp);
            str_tmp = strstr(
                (*osd).os_name,
                b": \0" as *const u8 as *const ::core::ffi::c_char,
            );
            if !str_tmp.is_null() {
                *str_tmp = '\0' as i32 as ::core::ffi::c_char;
                str_tmp = str_tmp.offset(2 as ::core::ffi::c_int as isize);
                (*osd).os_version = strdup(str_tmp);
                *(*osd)
                    .os_version
                    .offset(strlen((*osd).os_version) as isize)
                    .offset(-(1 as ::core::ffi::c_int as isize)) = '\0' as i32
                    as ::core::ffi::c_char;
                str_tmp = strstr(
                    (*osd).os_version,
                    b" (\0" as *const u8 as *const ::core::ffi::c_char,
                );
                if !str_tmp.is_null() {
                    *str_tmp = '\0' as i32 as ::core::ffi::c_char;
                    str_tmp = str_tmp.offset(2 as ::core::ffi::c_int as isize);
                    (*osd).os_codename = strdup(str_tmp);
                    *(*osd)
                        .os_codename
                        .offset(strlen((*osd).os_codename) as isize)
                        .offset(-(1 as ::core::ffi::c_int as isize)) = '\0' as i32
                        as ::core::ffi::c_char;
                }
                if w_regexec(
                    b"^([0-9]+)\\.*\0" as *const u8 as *const ::core::ffi::c_char,
                    (*osd).os_version,
                    2 as size_t,
                    match_0.as_mut_ptr(),
                ) != 0
                {
                    match_size = (match_0[1 as ::core::ffi::c_int as usize].rm_eo
                        - match_0[1 as ::core::ffi::c_int as usize].rm_so)
                        as ::core::ffi::c_int;
                    (*osd).os_major = malloc(
                        (match_size + 1 as ::core::ffi::c_int) as size_t,
                    ) as *mut ::core::ffi::c_char;
                    snprintf(
                        (*osd).os_major,
                        (match_size + 1 as ::core::ffi::c_int) as size_t,
                        b"%.*s\0" as *const u8 as *const ::core::ffi::c_char,
                        match_size,
                        (*osd)
                            .os_version
                            .offset(
                                match_0[1 as ::core::ffi::c_int as usize].rm_so as isize,
                            ),
                    );
                }
                if w_regexec(
                    b"^[0-9]+\\.([0-9]+)\\.*\0" as *const u8
                        as *const ::core::ffi::c_char,
                    (*osd).os_version,
                    2 as size_t,
                    match_0.as_mut_ptr(),
                ) != 0
                {
                    match_size = (match_0[1 as ::core::ffi::c_int as usize].rm_eo
                        - match_0[1 as ::core::ffi::c_int as usize].rm_so)
                        as ::core::ffi::c_int;
                    (*osd).os_minor = malloc(
                        (match_size + 1 as ::core::ffi::c_int) as size_t,
                    ) as *mut ::core::ffi::c_char;
                    snprintf(
                        (*osd).os_minor,
                        (match_size + 1 as ::core::ffi::c_int) as size_t,
                        b"%.*s\0" as *const u8 as *const ::core::ffi::c_char,
                        match_size,
                        (*osd)
                            .os_version
                            .offset(
                                match_0[1 as ::core::ffi::c_int as usize].rm_so as isize,
                            ),
                    );
                }
            } else {
                *(*osd)
                    .os_name
                    .offset(strlen((*osd).os_name) as isize)
                    .offset(-(1 as ::core::ffi::c_int as isize)) = '\0' as i32
                    as ::core::ffi::c_char;
            }
            str_tmp = strstr(
                (*osd).os_name,
                b"|\0" as *const u8 as *const ::core::ffi::c_char,
            );
            if !str_tmp.is_null() {
                *str_tmp = '\0' as i32 as ::core::ffi::c_char;
                str_tmp = str_tmp.offset(1);
                (*osd).os_platform = strdup(str_tmp);
            }
        }
        str_tmp = get_os_arch(uname);
        if !str_tmp.is_null() {
            (*osd).os_arch = strdup(str_tmp);
            free(str_tmp as *mut ::core::ffi::c_void);
        }
    };
}
