#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn calloc(__count: size_t, __size: size_t) -> *mut ::core::ffi::c_void;
    fn exit(_: ::core::ffi::c_int) -> !;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strerror(__errnum: ::core::ffi::c_int) -> *mut ::core::ffi::c_char;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strrchr(
        __s: *const ::core::ffi::c_char,
        __c: ::core::ffi::c_int,
    ) -> *mut ::core::ffi::c_char;
    fn __error() -> *mut ::core::ffi::c_int;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn extractFilename(
    mut path: *const ::core::ffi::c_char,
    mut separator: ::core::ffi::c_char,
) -> *const ::core::ffi::c_char {
    let mut search: *const ::core::ffi::c_char = strrchr(
        path,
        separator as ::core::ffi::c_int,
    );
    if search.is_null() {
        return path;
    }
    return search.offset(1 as ::core::ffi::c_int as isize);
}
#[no_mangle]
pub unsafe extern "C" fn FIO_createFilename_fromOutDir(
    mut path: *const ::core::ffi::c_char,
    mut outDirName: *const ::core::ffi::c_char,
    suffixLen: size_t,
) -> *mut ::core::ffi::c_char {
    let mut filenameStart: *const ::core::ffi::c_char = 0 as *const ::core::ffi::c_char;
    let mut separator: ::core::ffi::c_char = 0;
    let mut result: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    separator = '/' as i32 as ::core::ffi::c_char;
    filenameStart = extractFilename(path, separator);
    result = calloc(
        1 as size_t,
        strlen(outDirName)
            .wrapping_add(1 as size_t)
            .wrapping_add(strlen(filenameStart))
            .wrapping_add(suffixLen)
            .wrapping_add(1 as size_t),
    ) as *mut ::core::ffi::c_char;
    if result.is_null() {
        fprintf(
            __stderrp,
            b"zstd: FIO_createFilename_fromOutDir: %s\0" as *const u8
                as *const ::core::ffi::c_char,
            strerror(*__error()),
        );
        exit(30 as ::core::ffi::c_int);
    }
    memcpy(
        result as *mut ::core::ffi::c_void,
        outDirName as *const ::core::ffi::c_void,
        strlen(outDirName),
    );
    if *outDirName.offset(strlen(outDirName).wrapping_sub(1 as size_t) as isize)
        as ::core::ffi::c_int == separator as ::core::ffi::c_int
    {
        memcpy(
            result.offset(strlen(outDirName) as isize) as *mut ::core::ffi::c_void,
            filenameStart as *const ::core::ffi::c_void,
            strlen(filenameStart),
        );
    } else {
        memcpy(
            result.offset(strlen(outDirName) as isize) as *mut ::core::ffi::c_void,
            &mut separator as *mut ::core::ffi::c_char as *const ::core::ffi::c_void,
            1 as size_t,
        );
        memcpy(
            result
                .offset(strlen(outDirName) as isize)
                .offset(1 as ::core::ffi::c_int as isize) as *mut ::core::ffi::c_void,
            filenameStart as *const ::core::ffi::c_void,
            strlen(filenameStart),
        );
    }
    return result;
}
