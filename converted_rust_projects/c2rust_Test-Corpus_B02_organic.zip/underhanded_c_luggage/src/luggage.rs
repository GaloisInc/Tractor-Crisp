#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn scanf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn calloc(__count: size_t, __size: size_t) -> *mut ::core::ffi::c_void;
    fn exit(_: ::core::ffi::c_int) -> !;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strcpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct RoutingDirective {
    pub time_stamp: ::core::ffi::c_uint,
    pub luggage_id: [::core::ffi::c_char; 9],
    pub flight_id: [::core::ffi::c_char; 7],
    pub departure: [::core::ffi::c_char; 4],
    pub arrival: [::core::ffi::c_char; 4],
    pub comments: [::core::ffi::c_char; 81],
    pub next_directive: *mut RoutingDirective,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const EOF: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
#[no_mangle]
pub unsafe extern "C" fn addRoutingDirectiveToList(
    mut previous_directive: *mut RoutingDirective,
    mut new_directive: *mut RoutingDirective,
) {
    let mut next_directive: *mut RoutingDirective = (*previous_directive).next_directive
        as *mut RoutingDirective;
    if next_directive.is_null()
        || (*next_directive).time_stamp > (*new_directive).time_stamp
    {
        (*new_directive).next_directive = next_directive as *mut RoutingDirective;
        (*previous_directive).next_directive = new_directive as *mut RoutingDirective;
    } else {
        addRoutingDirectiveToList(next_directive, new_directive);
    };
}
#[no_mangle]
pub unsafe extern "C" fn supersedes(
    mut directive: *mut RoutingDirective,
    mut luggage_id: *mut ::core::ffi::c_char,
    mut departure: *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    if directive.is_null() {
        return 0 as ::core::ffi::c_int;
    }
    if strcmp((*directive).luggage_id.as_mut_ptr(), luggage_id)
        != 0 as ::core::ffi::c_int
    {
        return supersedes(
            (*directive).next_directive as *mut RoutingDirective,
            luggage_id,
            departure,
        );
    }
    if strcmp((*directive).departure.as_mut_ptr(), departure) == 0 as ::core::ffi::c_int
    {
        return 1 as ::core::ffi::c_int;
    }
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn superseded(
    mut directive: *mut RoutingDirective,
) -> ::core::ffi::c_int {
    return supersedes(
        (*directive).next_directive as *mut RoutingDirective,
        (*directive).luggage_id.as_mut_ptr(),
        (*directive).departure.as_mut_ptr(),
    );
}
#[no_mangle]
pub unsafe extern "C" fn matches(
    mut expected: *mut ::core::ffi::c_char,
    mut actual: *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    return (*expected.offset(0 as ::core::ffi::c_int as isize) as ::core::ffi::c_int
        == '-' as i32 || strcmp(expected, actual) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn printMatchingDirectives(
    mut first_directive: *mut RoutingDirective,
    mut expected_luggage_id: *mut ::core::ffi::c_char,
    mut expected_flight_id: *mut ::core::ffi::c_char,
    mut expected_departure: *mut ::core::ffi::c_char,
    mut expected_arrival: *mut ::core::ffi::c_char,
) {
    let mut directive: *mut RoutingDirective = 0 as *mut RoutingDirective;
    directive = first_directive;
    while !directive.is_null() {
        if superseded(directive) == 0
            && matches(expected_luggage_id, (*directive).luggage_id.as_mut_ptr()) != 0
            && matches(expected_flight_id, (*directive).flight_id.as_mut_ptr()) != 0
            && matches(expected_departure, (*directive).departure.as_mut_ptr()) != 0
            && matches(expected_arrival, (*directive).arrival.as_mut_ptr()) != 0
        {
            printf(
                b"%010u %s %s %s %s %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                (*directive).time_stamp,
                (*directive).luggage_id.as_mut_ptr(),
                (*directive).flight_id.as_mut_ptr(),
                (*directive).departure.as_mut_ptr(),
                (*directive).arrival.as_mut_ptr(),
                (*directive).comments.as_mut_ptr(),
            );
        }
        directive = (*directive).next_directive as *mut RoutingDirective;
    }
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    if argc != 5 as ::core::ffi::c_int {
        fprintf(
            __stderrp,
            b"Command line error: 4 arguments expected\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        exit(1 as ::core::ffi::c_int);
    }
    let mut directive_list_head: RoutingDirective = RoutingDirective {
        time_stamp: 0,
        luggage_id: [0; 9],
        flight_id: [0; 7],
        departure: [0; 4],
        arrival: [0; 4],
        comments: [0; 81],
        next_directive: 0 as *mut RoutingDirective,
    };
    directive_list_head.time_stamp = 0 as ::core::ffi::c_uint;
    directive_list_head.next_directive = 0 as *mut RoutingDirective;
    let mut time_stamp: ::core::ffi::c_uint = 0;
    let mut luggage_id: [::core::ffi::c_char; 9] = [0; 9];
    let mut flight_id: [::core::ffi::c_char; 7] = [0; 7];
    let mut departure: [::core::ffi::c_char; 4] = [0; 4];
    let mut arrival: [::core::ffi::c_char; 4] = [0; 4];
    let mut comments: [::core::ffi::c_char; 81] = [0; 81];
    comments[0 as ::core::ffi::c_int as usize] = 0 as ::core::ffi::c_char;
    while !(scanf(
        b"%d \0" as *const u8 as *const ::core::ffi::c_char,
        &mut time_stamp as *mut ::core::ffi::c_uint,
    ) == EOF)
    {
        if scanf(
            b"%8[A-Z0-9] %6[A-Z0-9] \0" as *const u8 as *const ::core::ffi::c_char,
            luggage_id.as_mut_ptr(),
            flight_id.as_mut_ptr(),
        ) == EOF
        {
            break;
        }
        if scanf(
            b"%3[A-Z] %3[A-Z]\0" as *const u8 as *const ::core::ffi::c_char,
            departure.as_mut_ptr(),
            arrival.as_mut_ptr(),
        ) == EOF
        {
            break;
        }
        if scanf(
            b"%80[^\n]\0" as *const u8 as *const ::core::ffi::c_char,
            comments.as_mut_ptr(),
        ) == EOF
        {
            break;
        }
        let mut new_directive: *mut RoutingDirective = calloc(
            1 as size_t,
            ::core::mem::size_of::<RoutingDirective>() as size_t,
        ) as *mut RoutingDirective;
        (*new_directive).time_stamp = time_stamp;
        strcpy((*new_directive).luggage_id.as_mut_ptr(), luggage_id.as_mut_ptr());
        strcpy((*new_directive).flight_id.as_mut_ptr(), flight_id.as_mut_ptr());
        strcpy((*new_directive).departure.as_mut_ptr(), departure.as_mut_ptr());
        strcpy((*new_directive).arrival.as_mut_ptr(), arrival.as_mut_ptr());
        strcpy((*new_directive).comments.as_mut_ptr(), comments.as_mut_ptr());
        (*new_directive).next_directive = 0 as *mut RoutingDirective;
        addRoutingDirectiveToList(&mut directive_list_head, new_directive);
    }
    printMatchingDirectives(
        directive_list_head.next_directive as *mut RoutingDirective,
        *argv.offset(1 as ::core::ffi::c_int as isize),
        *argv.offset(2 as ::core::ffi::c_int as isize),
        *argv.offset(3 as ::core::ffi::c_int as isize),
        *argv.offset(4 as ::core::ffi::c_int as isize),
    );
    exit(0 as ::core::ffi::c_int);
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
