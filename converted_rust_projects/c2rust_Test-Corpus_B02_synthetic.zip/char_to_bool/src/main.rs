#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stdinp: *mut FILE;
    static mut __stderrp: *mut FILE;
    fn fgets(
        _: *mut ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *mut FILE,
    ) -> *mut ::core::ffi::c_char;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn atoi(_: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn process_decisions(
        decision_string: *mut ::core::ffi::c_char,
        length: size_t,
        operation: ::core::ffi::c_int,
        param: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const MAX_INPUT_SIZE: ::core::ffi::c_int = 1024 as ::core::ffi::c_int;
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut input_buffer: [::core::ffi::c_char; 1024] = [0; 1024];
    let mut operation: ::core::ffi::c_int = 0;
    let mut param: ::core::ffi::c_int = 0;
    let mut result: ::core::ffi::c_int = 0;
    if fgets(input_buffer.as_mut_ptr(), MAX_INPUT_SIZE, __stdinp).is_null() {
        fprintf(
            __stderrp,
            b"Error reading operation\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    operation = atoi(input_buffer.as_mut_ptr());
    if fgets(input_buffer.as_mut_ptr(), MAX_INPUT_SIZE, __stdinp).is_null() {
        fprintf(
            __stderrp,
            b"Error reading parameter\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    param = atoi(input_buffer.as_mut_ptr());
    if fgets(input_buffer.as_mut_ptr(), MAX_INPUT_SIZE, __stdinp).is_null() {
        fprintf(
            __stderrp,
            b"Error reading decision string\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    let mut len: size_t = strlen(input_buffer.as_mut_ptr());
    if len > 0 as size_t
        && input_buffer[len.wrapping_sub(1 as size_t) as usize] as ::core::ffi::c_int
            == '\n' as i32
    {
        input_buffer[len.wrapping_sub(1 as size_t) as usize] = '\0' as i32
            as ::core::ffi::c_char;
        len = len.wrapping_sub(1);
    }
    result = process_decisions(input_buffer.as_mut_ptr(), len, operation, param);
    printf(b"%d\n\0" as *const u8 as *const ::core::ffi::c_char, result);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
