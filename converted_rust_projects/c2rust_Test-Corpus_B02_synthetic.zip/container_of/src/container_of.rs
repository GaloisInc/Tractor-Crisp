#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn atoi(_: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct test {
    pub a: ::core::ffi::c_int,
    pub b: ::core::ffi::c_int,
}
#[no_mangle]
pub unsafe extern "C" fn find_container_of_a(
    mut i: *mut ::core::ffi::c_int,
) -> *mut test {
    return ({
        (i as *mut ::core::ffi::c_char)
            .offset(
                -(&mut (*(0 as *mut test)).a as *mut ::core::ffi::c_int as size_t
                    as isize),
            ) as *mut test
    });
}
#[no_mangle]
pub unsafe extern "C" fn find_container_of_b(
    mut i: *mut ::core::ffi::c_int,
) -> *mut test {
    return ({
        (i as *mut ::core::ffi::c_char)
            .offset(
                -(&mut (*(0 as *mut test)).b as *mut ::core::ffi::c_int as size_t
                    as isize),
            ) as *mut test
    });
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut a: ::core::ffi::c_int = atoi(*argv.offset(1 as ::core::ffi::c_int as isize));
    let mut b: ::core::ffi::c_int = atoi(*argv.offset(2 as ::core::ffi::c_int as isize));
    let mut t: test = test { a: 0, b: 0 };
    memset(
        &mut t as *mut test as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<test>() as size_t,
    );
    t.a = a;
    t.b = b;
    printf(
        b"%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*find_container_of_a(&mut t.a)).a + (*find_container_of_b(&mut t.b)).b,
    );
    return 0;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
