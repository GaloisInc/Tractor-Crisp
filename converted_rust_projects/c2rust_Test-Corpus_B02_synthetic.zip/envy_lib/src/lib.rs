#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn snprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn atoi(_: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
    fn getenv(_: *const ::core::ffi::c_char) -> *mut ::core::ffi::c_char;
    fn memcpy(
        __dst: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strchr(
        __s: *const ::core::ffi::c_char,
        __c: ::core::ffi::c_int,
    ) -> *mut ::core::ffi::c_char;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone, BitfieldStruct)]
#[repr(C)]
pub struct ConfigFlags {
    #[bitfield(name = "verbose", ty = "::core::ffi::c_uint", bits = "0..=0")]
    #[bitfield(name = "debug", ty = "::core::ffi::c_uint", bits = "1..=1")]
    #[bitfield(name = "optimize", ty = "::core::ffi::c_uint", bits = "2..=2")]
    #[bitfield(name = "cache_enabled", ty = "::core::ffi::c_uint", bits = "3..=3")]
    #[bitfield(name = "log_level", ty = "::core::ffi::c_uint", bits = "4..=6")]
    #[bitfield(name = "reserved", ty = "::core::ffi::c_uint", bits = "7..=7")]
    pub verbose_debug_optimize_cache_enabled_log_level_reserved: [u8; 1],
    #[bitfield(padding)]
    pub c2rust_padding: [u8; 3],
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct ProcessState {
    pub flags: ConfigFlags,
    pub base_value: ::core::ffi::c_int,
    pub multiplier: ::core::ffi::c_int,
    pub operation: ::core::ffi::c_char,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const BUFFER_SIZE: ::core::ffi::c_int = 256 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn parse_env_numeric(
    mut env_name: *const ::core::ffi::c_char,
    mut default_val: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut env_value: *mut ::core::ffi::c_char = getenv(env_name);
    if env_value.is_null() {
        return default_val;
    }
    let mut invalid_char: *mut ::core::ffi::c_char = strchr(env_value, ',' as i32);
    if !invalid_char.is_null() {
        fprintf(
            __stderrp,
            b"Warning: Invalid character in %s\n\0" as *const u8
                as *const ::core::ffi::c_char,
            env_name,
        );
        return default_val;
    }
    invalid_char = strchr(env_value, ';' as i32);
    if !invalid_char.is_null() {
        fprintf(
            __stderrp,
            b"Warning: Semicolon found in %s\n\0" as *const u8
                as *const ::core::ffi::c_char,
            env_name,
        );
        return default_val;
    }
    return atoi(env_value);
}
#[no_mangle]
pub unsafe extern "C" fn init_config_from_env(mut flags: *mut ConfigFlags) {
    let mut verbose_env: *mut ::core::ffi::c_char = getenv(
        b"PROG_VERBOSE\0" as *const u8 as *const ::core::ffi::c_char,
    );
    let mut debug_env: *mut ::core::ffi::c_char = getenv(
        b"PROG_DEBUG\0" as *const u8 as *const ::core::ffi::c_char,
    );
    let mut optimize_env: *mut ::core::ffi::c_char = getenv(
        b"PROG_OPTIMIZE\0" as *const u8 as *const ::core::ffi::c_char,
    );
    (*flags)
        .set_verbose(
            (if !verbose_env.is_null() && !strchr(verbose_env, '1' as i32).is_null() {
                1 as ::core::ffi::c_int
            } else {
                0 as ::core::ffi::c_int
            }) as ::core::ffi::c_uint as ::core::ffi::c_uint,
        );
    (*flags)
        .set_debug(
            (if !debug_env.is_null() && !strchr(debug_env, '1' as i32).is_null() {
                1 as ::core::ffi::c_int
            } else {
                0 as ::core::ffi::c_int
            }) as ::core::ffi::c_uint as ::core::ffi::c_uint,
        );
    (*flags)
        .set_optimize(
            (if !optimize_env.is_null() {
                1 as ::core::ffi::c_int
            } else {
                0 as ::core::ffi::c_int
            }) as ::core::ffi::c_uint as ::core::ffi::c_uint,
        );
    (*flags).set_cache_enabled(1 as ::core::ffi::c_uint as ::core::ffi::c_uint);
    (*flags).set_log_level(0o3 as ::core::ffi::c_uint as ::core::ffi::c_uint);
    (*flags).set_reserved(0 as ::core::ffi::c_uint as ::core::ffi::c_uint);
}
#[no_mangle]
pub unsafe extern "C" fn perform_operation(
    mut val1: ::core::ffi::c_int,
    mut val2: ::core::ffi::c_int,
    mut flags: *mut ConfigFlags,
) -> ::core::ffi::c_int {
    let mut result: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut operation_mode: ::core::ffi::c_int = 0o755 as ::core::ffi::c_int;
    if (*flags).optimize() != 0 {
        result = val1 + val2;
    } else {
        result = val1 * (*flags).log_level() as ::core::ffi::c_int
            + val2 / 2 as ::core::ffi::c_int;
    }
    if (*flags).debug() != 0 {
        printf(
            b"Debug: operation_mode = %o (octal)\n\0" as *const u8
                as *const ::core::ffi::c_char,
            operation_mode,
        );
        printf(
            b"Debug: result before adjustment = %d\n\0" as *const u8
                as *const ::core::ffi::c_char,
            result,
        );
    }
    return result;
}
#[no_mangle]
pub unsafe extern "C" fn apply_bit_operations(
    mut value: ::core::ffi::c_int,
    mut flags: *mut ConfigFlags,
) -> ::core::ffi::c_int {
    let mut adjusted: ::core::ffi::c_int = value;
    if (*flags).verbose() != 0 {
        adjusted = adjusted << 1 as ::core::ffi::c_int;
    }
    if (*flags).cache_enabled() != 0 {
        adjusted = adjusted | 0xf as ::core::ffi::c_int;
    }
    return adjusted;
}
#[no_mangle]
pub unsafe extern "C" fn envy(
    mut param1: ::core::ffi::c_int,
    mut param2: ::core::ffi::c_int,
    mut param3: ::core::ffi::c_int,
    mut param4: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut state: ProcessState = ProcessState {
        flags: ConfigFlags {
            verbose_debug_optimize_cache_enabled_log_level_reserved: [0; 1],
            c2rust_padding: [0; 3],
        },
        base_value: 0,
        multiplier: 0,
        operation: 0,
    };
    let mut state_backup: ProcessState = ProcessState {
        flags: ConfigFlags {
            verbose_debug_optimize_cache_enabled_log_level_reserved: [0; 1],
            c2rust_padding: [0; 3],
        },
        base_value: 0,
        multiplier: 0,
        operation: 0,
    };
    let mut buffer: [::core::ffi::c_char; 256] = [0; 256];
    let mut result: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    init_config_from_env(&mut state.flags);
    let mut base_offset: ::core::ffi::c_int = parse_env_numeric(
        b"PROG_BASE_OFFSET\0" as *const u8 as *const ::core::ffi::c_char,
        0o100 as ::core::ffi::c_int,
    );
    let mut multiplier: ::core::ffi::c_int = parse_env_numeric(
        b"PROG_MULTIPLIER\0" as *const u8 as *const ::core::ffi::c_char,
        0o12 as ::core::ffi::c_int,
    );
    if state.flags.verbose() != 0 {
        printf(b"Verbose mode enabled\n\0" as *const u8 as *const ::core::ffi::c_char);
        printf(
            b"Base offset: %d (from octal 0100)\n\0" as *const u8
                as *const ::core::ffi::c_char,
            base_offset,
        );
        printf(
            b"Multiplier: %d (from octal 012)\n\0" as *const u8
                as *const ::core::ffi::c_char,
            multiplier,
        );
    }
    state.base_value = param1;
    state.multiplier = multiplier;
    state.operation = '+' as i32 as ::core::ffi::c_char;
    memcpy(
        &mut state_backup as *mut ProcessState as *mut ::core::ffi::c_void,
        &mut state as *mut ProcessState as *const ::core::ffi::c_void,
        ::core::mem::size_of::<ProcessState>() as size_t,
    );
    if state.flags.debug() != 0 {
        printf(
            b"Debug: Created state backup using memcpy\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        printf(
            b"Debug: Backup base_value = %d\n\0" as *const u8
                as *const ::core::ffi::c_char,
            state_backup.base_value,
        );
    }
    result = perform_operation(param1, param2, &mut state.flags);
    if param3 != 0 as ::core::ffi::c_int {
        result += param3 * state.multiplier;
    }
    if param4 != 0 as ::core::ffi::c_int {
        result += param4 >> 2 as ::core::ffi::c_int;
    }
    result = apply_bit_operations(result, &mut state.flags);
    result += base_offset;
    snprintf(
        buffer.as_mut_ptr(),
        BUFFER_SIZE as size_t,
        b"Result:%d:Complete\0" as *const u8 as *const ::core::ffi::c_char,
        result,
    );
    let mut colon_pos: *mut ::core::ffi::c_char = strchr(
        buffer.as_mut_ptr(),
        ':' as i32,
    );
    if !colon_pos.is_null() {
        if state.flags.verbose() != 0 {
            printf(
                b"Found colon at position: %ld\n\0" as *const u8
                    as *const ::core::ffi::c_char,
                colon_pos.offset_from(buffer.as_mut_ptr()) as ::core::ffi::c_long,
            );
        }
        let mut second_colon: *mut ::core::ffi::c_char = strchr(
            colon_pos.offset(1 as ::core::ffi::c_int as isize),
            ':' as i32,
        );
        if !second_colon.is_null() && state.flags.debug() as ::core::ffi::c_int != 0 {
            printf(
                b"Debug: Result string format validated\n\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        }
    }
    if result < 0 as ::core::ffi::c_int {
        memcpy(
            &mut state as *mut ProcessState as *mut ::core::ffi::c_void,
            &mut state_backup as *mut ProcessState as *const ::core::ffi::c_void,
            ::core::mem::size_of::<ProcessState>() as size_t,
        );
        result = state.base_value;
        if state.flags.verbose() != 0 {
            printf(
                b"Restored state from backup\n\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        }
    }
    if state.flags.verbose() != 0 {
        printf(
            b"Final result: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
            result,
        );
        printf(
            b"Configuration - Debug: %d, Optimize: %d, Log Level: %d\n\0" as *const u8
                as *const ::core::ffi::c_char,
            state.flags.debug() as ::core::ffi::c_int,
            state.flags.optimize() as ::core::ffi::c_int,
            state.flags.log_level() as ::core::ffi::c_int,
        );
    }
    return result;
}
