#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct DataPoint {
    pub value: ::core::ffi::c_int,
    pub coefficient: ::core::ffi::c_double,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const INT_MAX: ::core::ffi::c_int = 2147483647 as ::core::ffi::c_int;
pub const INT_MIN: ::core::ffi::c_int = -(2147483647 as ::core::ffi::c_int)
    - 1 as ::core::ffi::c_int;
#[inline(always)]
unsafe extern "C" fn __inline_isinff(
    mut __x: ::core::ffi::c_float,
) -> ::core::ffi::c_int {
    return (__x.abs() == ::core::f32::INFINITY) as ::core::ffi::c_int;
}
#[inline(always)]
unsafe extern "C" fn __inline_isinfd(
    mut __x: ::core::ffi::c_double,
) -> ::core::ffi::c_int {
    return (__x.abs() == ::core::f64::INFINITY) as ::core::ffi::c_int;
}
#[inline(always)]
unsafe extern "C" fn __inline_isinfl(mut __x: ::f128::f128) -> ::core::ffi::c_int {
    return (__x.abs() == ::core::f64::INFINITY) as ::core::ffi::c_int;
}
#[inline(always)]
unsafe extern "C" fn __inline_isnanf(
    mut __x: ::core::ffi::c_float,
) -> ::core::ffi::c_int {
    return (__x != __x) as ::core::ffi::c_int;
}
#[inline(always)]
unsafe extern "C" fn __inline_isnand(
    mut __x: ::core::ffi::c_double,
) -> ::core::ffi::c_int {
    return (__x != __x) as ::core::ffi::c_int;
}
#[inline(always)]
unsafe extern "C" fn __inline_isnanl(mut __x: ::f128::f128) -> ::core::ffi::c_int {
    return (__x != __x) as ::core::ffi::c_int;
}
pub const OCTAL_MASK_1: ::core::ffi::c_int = 0o777 as ::core::ffi::c_int;
pub const OCTAL_MASK_2: ::core::ffi::c_int = 0o100 as ::core::ffi::c_int;
pub const OCTAL_FLAG: ::core::ffi::c_int = 0o200 as ::core::ffi::c_int;
pub const OCTAL_BASE: ::core::ffi::c_int = 0o10 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn safe_double_to_int(
    mut d: ::core::ffi::c_double,
) -> ::core::ffi::c_int {
    if if ::core::mem::size_of::<::core::ffi::c_double>() as usize
        == ::core::mem::size_of::<::core::ffi::c_float>() as usize
    {
        __inline_isnanf(d as ::core::ffi::c_float)
    } else if ::core::mem::size_of::<::core::ffi::c_double>() as usize
        == ::core::mem::size_of::<::core::ffi::c_double>() as usize
    {
        __inline_isnand(d)
    } else {
        __inline_isnanl(::f128::f128::new(d))
    } != 0
    {
        return 0 as ::core::ffi::c_int;
    }
    if if ::core::mem::size_of::<::core::ffi::c_double>() as usize
        == ::core::mem::size_of::<::core::ffi::c_float>() as usize
    {
        __inline_isinff(d as ::core::ffi::c_float)
    } else if ::core::mem::size_of::<::core::ffi::c_double>() as usize
        == ::core::mem::size_of::<::core::ffi::c_double>() as usize
    {
        __inline_isinfd(d)
    } else {
        __inline_isinfl(::f128::f128::new(d))
    } != 0
    {
        return if d > 0 as ::core::ffi::c_int as ::core::ffi::c_double {
            INT_MAX
        } else {
            INT_MIN
        };
    }
    if d >= INT_MAX as ::core::ffi::c_double {
        return INT_MAX;
    }
    if d <= INT_MIN as ::core::ffi::c_double {
        return INT_MIN;
    }
    return d as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn process_array_reverse(
    mut end: *mut ::core::ffi::c_int,
    mut count: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut sum: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut ptr: *mut ::core::ffi::c_int = end;
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < count {
        sum += *ptr;
        ptr = ptr.offset(-1);
        i += 1;
    }
    return sum;
}
#[no_mangle]
pub unsafe extern "C" fn switch_fallthrough_calculator(
    mut value: ::core::ffi::c_int,
    mut operation: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut result: ::core::ffi::c_int = value;
    let mut current_block_5: u64;
    match operation {
        0 => {
            result *= OCTAL_BASE;
            current_block_5 = 12249165840742987277;
        }
        1 => {
            current_block_5 = 12249165840742987277;
        }
        2 => {
            current_block_5 = 17344246177823515599;
        }
        3 => {
            result *= 3 as ::core::ffi::c_int;
            current_block_5 = 16113995389245979936;
        }
        4 => {
            current_block_5 = 16113995389245979936;
        }
        _ => {
            result = 0 as ::core::ffi::c_int;
            current_block_5 = 14523784380283086299;
        }
    }
    match current_block_5 {
        12249165840742987277 => {
            result += OCTAL_FLAG;
            current_block_5 = 17344246177823515599;
        }
        16113995389245979936 => {
            result += OCTAL_MASK_2;
            current_block_5 = 14523784380283086299;
        }
        _ => {}
    }
    match current_block_5 {
        17344246177823515599 => {
            result &= OCTAL_MASK_1;
        }
        _ => {}
    }
    return result;
}
#[no_mangle]
pub unsafe extern "C" fn allocate_and_compute(
    mut size: ::core::ffi::c_int,
    mut multiplier: ::core::ffi::c_double,
) -> ::core::ffi::c_int {
    let mut points: *mut DataPoint = malloc(
        (size as size_t).wrapping_mul(::core::mem::size_of::<DataPoint>() as size_t),
    ) as *mut DataPoint;
    if points.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < size {
        (*points.offset(i as isize)).value = i * OCTAL_BASE;
        (*points.offset(i as isize)).coefficient = i as ::core::ffi::c_double
            * multiplier;
        i += 1;
    }
    let mut sum: ::core::ffi::c_double = 0.0f64;
    let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_0 < size {
        sum
            += (*points.offset(i_0 as isize)).value as ::core::ffi::c_double
                * (*points.offset(i_0 as isize)).coefficient;
        i_0 += 1;
    }
    let mut result: ::core::ffi::c_int = safe_double_to_int(sum);
    free(points as *mut ::core::ffi::c_void);
    return result;
}
#[no_mangle]
pub unsafe extern "C" fn foreach_sum(
    mut array: *mut ::core::ffi::c_int,
    mut count: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut total: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut element: ::core::ffi::c_int = 0;
    let mut keep: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    let mut idx: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut size: ::core::ffi::c_int = count;
    while keep != 0 && idx < size {
        element = *array.offset(idx as isize);
        while keep != 0 {
            total += element;
            keep = (keep == 0) as ::core::ffi::c_int;
        }
        keep = (keep == 0) as ::core::ffi::c_int;
        idx += 1;
    }
    return total;
}
#[no_mangle]
pub unsafe extern "C" fn fallcalc(
    mut param1: ::core::ffi::c_int,
    mut param2: ::core::ffi::c_int,
    mut param3: ::core::ffi::c_int,
    mut param4: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut result: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut base_value: ::core::ffi::c_int = param1 * OCTAL_MASK_2 + param2;
    let mut array_size: ::core::ffi::c_int = 5 as ::core::ffi::c_int;
    let mut data_array: *mut ::core::ffi::c_int = malloc(
        (array_size as size_t)
            .wrapping_mul(::core::mem::size_of::<::core::ffi::c_int>() as size_t),
    ) as *mut ::core::ffi::c_int;
    if data_array.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < array_size {
        *data_array.offset(i as isize) = (i + 1 as ::core::ffi::c_int) * OCTAL_BASE
            + param1;
        i += 1;
    }
    let mut foreach_result: ::core::ffi::c_int = foreach_sum(data_array, array_size);
    let mut last_element: *mut ::core::ffi::c_int = data_array
        .offset(array_size as isize)
        .offset(-(1 as ::core::ffi::c_int as isize));
    let mut reverse_sum: ::core::ffi::c_int = process_array_reverse(
        last_element,
        array_size,
    );
    let mut switch_result: ::core::ffi::c_int = switch_fallthrough_calculator(
        param2,
        param3 % 5 as ::core::ffi::c_int,
    );
    let mut floating_calc: ::core::ffi::c_double = param1 as ::core::ffi::c_double
        * 3.7f64 + param2 as ::core::ffi::c_double * 2.3f64
        - param3 as ::core::ffi::c_double * 0.5f64;
    let mut converted: ::core::ffi::c_int = safe_double_to_int(floating_calc);
    let mut alloc_result: ::core::ffi::c_int = allocate_and_compute(
        param4 % 10 as ::core::ffi::c_int + 1 as ::core::ffi::c_int,
        1.5f64,
    );
    result = base_value + foreach_result + reverse_sum + switch_result + converted
        + alloc_result;
    if param3 > OCTAL_FLAG {
        result |= OCTAL_FLAG;
    }
    free(data_array as *mut ::core::ffi::c_void);
    result &= OCTAL_MASK_1;
    return result;
}
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
