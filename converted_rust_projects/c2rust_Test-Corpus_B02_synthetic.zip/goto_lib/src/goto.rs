#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn ferror(_: *mut FILE) -> ::core::ffi::c_int;
    fn fgets(
        _: *mut ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *mut FILE,
    ) -> *mut ::core::ffi::c_char;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
}
pub type __int64_t = i64;
pub type __darwin_off_t = __int64_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn forward_goto_example(
    mut x: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    if x < 0 as ::core::ffi::c_int {
        fprintf(
            __stderrp,
            b"Error: negative input\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return -(1 as ::core::ffi::c_int);
    } else {
        printf(b"Processing: %d\n\0" as *const u8 as *const ::core::ffi::c_char, x);
        return x * 2 as ::core::ffi::c_int;
    };
}
#[no_mangle]
pub unsafe extern "C" fn open_with_cleanup(
    mut filename: *const ::core::ffi::c_char,
) -> *mut FILE {
    let mut buffer: [::core::ffi::c_char; 100] = [0; 100];
    let mut fp: *mut FILE = fopen(
        filename,
        b"r\0" as *const u8 as *const ::core::ffi::c_char,
    ) as *mut FILE;
    if !fp.is_null() {
        buffer = [0; 100];
        while !fgets(
                buffer.as_mut_ptr(),
                ::core::mem::size_of::<[::core::ffi::c_char; 100]>()
                    as ::core::ffi::c_int,
                fp,
            )
            .is_null()
        {
            printf(
                b"%s\0" as *const u8 as *const ::core::ffi::c_char,
                buffer.as_mut_ptr(),
            );
        }
        if !(ferror(fp) != 0) {
            return fp;
        }
    }
    fprintf(
        __stderrp,
        b"Error: opening or processing file %s\n\0" as *const u8
            as *const ::core::ffi::c_char,
        filename,
    );
    if !fp.is_null() {
        fclose(fp);
    }
    return 0 as *mut FILE;
}
#[no_mangle]
pub unsafe extern "C" fn driver(
    mut num: ::core::ffi::c_int,
    mut filename: *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut res: ::core::ffi::c_int = forward_goto_example(num);
    if res == -(1 as ::core::ffi::c_int) {
        return -(1 as ::core::ffi::c_int)
    } else {
        printf(b"Goto output: %d\n\0" as *const u8 as *const ::core::ffi::c_char, res);
    }
    let mut out: *mut FILE = open_with_cleanup(filename);
    if out.is_null() {
        return -(2 as ::core::ffi::c_int)
    } else {
        fclose(out);
    }
    return 0 as ::core::ffi::c_int;
}
