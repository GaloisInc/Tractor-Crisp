#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn __assert_rtn(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *const ::core::ffi::c_char,
    ) -> !;
    fn hashmap_create() -> *mut hashmap_t;
    fn hashmap_destroy(map: *mut hashmap_t);
    fn hashmap_put(
        map: *mut hashmap_t,
        key: tree_id_t,
        value: *mut ::core::ffi::c_void,
    ) -> ::core::ffi::c_int;
    fn hashmap_get(map: *mut hashmap_t, key: tree_id_t) -> *mut ::core::ffi::c_void;
    fn hashmap_remove(map: *mut hashmap_t, key: tree_id_t) -> *mut ::core::ffi::c_void;
    fn hashmap_contains(map: *mut hashmap_t, key: tree_id_t) -> ::core::ffi::c_int;
    fn hashmap_size(map: *mut hashmap_t) -> size_t;
    fn tree_create() -> *mut tree_t;
    fn tree_delete(tree: *mut tree_t);
    fn tree_add_node(
        tree: *mut tree_t,
        id: tree_id_t,
        parent_id: tree_id_t,
        data: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn tree_remove_node(tree: *mut tree_t, id: tree_id_t) -> ::core::ffi::c_int;
    fn tree_get_node(tree: *mut tree_t, id: tree_id_t) -> *mut tree_node_t;
    fn tree_contains(tree: *mut tree_t, id: tree_id_t) -> ::core::ffi::c_int;
    fn tree_size(tree: *mut tree_t) -> size_t;
    fn tree_print(tree: *mut tree_t);
    fn tree_get_depth(tree: *mut tree_t, id: tree_id_t) -> ::core::ffi::c_int;
    fn tree_get_height(tree: *mut tree_t, id: tree_id_t) -> ::core::ffi::c_int;
    fn tree_count_descendants(tree: *mut tree_t, id: tree_id_t) -> ::core::ffi::c_int;
    fn tree_find_path(
        tree: *mut tree_t,
        id: tree_id_t,
        path: *mut tree_id_t,
        max_length: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type uint64_t = u64;
pub type tree_id_t = uint64_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct hashmap_entry {
    pub key: tree_id_t,
    pub value: *mut ::core::ffi::c_void,
    pub occupied: ::core::ffi::c_int,
    pub deleted: ::core::ffi::c_int,
}
pub type hashmap_entry_t = hashmap_entry;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct hashmap_t {
    pub entries: *mut hashmap_entry_t,
    pub capacity: size_t,
    pub size: size_t,
    pub deleted_count: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tree_node {
    pub id: tree_id_t,
    pub parent_id: tree_id_t,
    pub child_ids: [tree_id_t; 32],
    pub child_count: ::core::ffi::c_int,
    pub data: [::core::ffi::c_char; 256],
}
pub type tree_node_t = tree_node;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tree_t {
    pub node_map: *mut hashmap_t,
    pub root_id: tree_id_t,
    pub has_root: ::core::ffi::c_int,
    pub node_count: size_t,
}
pub const MAX_CHILDREN: ::core::ffi::c_int = 32 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn test_hashmap_basic() {
    printf(
        b"\n=== Testing Hashmap Basic Operations ===\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut map: *mut hashmap_t = hashmap_create();
    if map.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            18 as ::core::ffi::c_int,
            b"map != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(hashmap_size(map) == 0 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            19 as ::core::ffi::c_int,
            b"hashmap_size(map) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut val1: ::core::ffi::c_int = 42 as ::core::ffi::c_int;
    let mut val2: ::core::ffi::c_int = 100 as ::core::ffi::c_int;
    let mut val3: ::core::ffi::c_int = 200 as ::core::ffi::c_int;
    if !(hashmap_put(
        map,
        1 as tree_id_t,
        &mut val1 as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            23 as ::core::ffi::c_int,
            b"hashmap_put(map, 1, &val1) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(hashmap_put(
        map,
        2 as tree_id_t,
        &mut val2 as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            24 as ::core::ffi::c_int,
            b"hashmap_put(map, 2, &val2) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(hashmap_put(
        map,
        3 as tree_id_t,
        &mut val3 as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            25 as ::core::ffi::c_int,
            b"hashmap_put(map, 3, &val3) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(hashmap_size(map) == 3 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            26 as ::core::ffi::c_int,
            b"hashmap_size(map) == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(*(hashmap_get(map, 1 as tree_id_t) as *mut ::core::ffi::c_int)
        == 42 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            28 as ::core::ffi::c_int,
            b"*(int *)hashmap_get(map, 1) == 42\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(*(hashmap_get(map, 2 as tree_id_t) as *mut ::core::ffi::c_int)
        == 100 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            29 as ::core::ffi::c_int,
            b"*(int *)hashmap_get(map, 2) == 100\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(*(hashmap_get(map, 3 as tree_id_t) as *mut ::core::ffi::c_int)
        == 200 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            30 as ::core::ffi::c_int,
            b"*(int *)hashmap_get(map, 3) == 200\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut val4: ::core::ffi::c_int = 500 as ::core::ffi::c_int;
    if !(hashmap_put(
        map,
        1 as tree_id_t,
        &mut val4 as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            34 as ::core::ffi::c_int,
            b"hashmap_put(map, 1, &val4) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(hashmap_size(map) == 3 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            35 as ::core::ffi::c_int,
            b"hashmap_size(map) == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(*(hashmap_get(map, 1 as tree_id_t) as *mut ::core::ffi::c_int)
        == 500 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            36 as ::core::ffi::c_int,
            b"*(int *)hashmap_get(map, 1) == 500\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut removed: *mut ::core::ffi::c_void = hashmap_remove(map, 2 as tree_id_t);
    if !(removed == &mut val2 as *mut ::core::ffi::c_int as *mut ::core::ffi::c_void)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            40 as ::core::ffi::c_int,
            b"removed == &val2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(hashmap_size(map) == 2 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            41 as ::core::ffi::c_int,
            b"hashmap_size(map) == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !hashmap_get(map, 2 as tree_id_t).is_null() as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            42 as ::core::ffi::c_int,
            b"hashmap_get(map, 2) == NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(hashmap_contains(map, 1 as tree_id_t) == 1 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            45 as ::core::ffi::c_int,
            b"hashmap_contains(map, 1) == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(hashmap_contains(map, 2 as tree_id_t) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            46 as ::core::ffi::c_int,
            b"hashmap_contains(map, 2) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(hashmap_contains(map, 3 as tree_id_t) == 1 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_hashmap_basic\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            47 as ::core::ffi::c_int,
            b"hashmap_contains(map, 3) == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    hashmap_destroy(map);
    printf(
        b"\xE2\x9C\x93 PASS: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        ::core::mem::transmute::<
            [u8; 19],
            [::core::ffi::c_char; 19],
        >(*b"test_hashmap_basic\0")
            .as_ptr(),
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_hashmap_collisions() {
    printf(
        b"\n=== Testing Hashmap Collisions ===\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut map: *mut hashmap_t = hashmap_create();
    let mut values: [::core::ffi::c_int; 100] = [0; 100];
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < 100 as ::core::ffi::c_int {
        values[i as usize] = i * 10 as ::core::ffi::c_int;
        if !(hashmap_put(
            map,
            i as tree_id_t,
            &mut *values.as_mut_ptr().offset(i as isize) as *mut ::core::ffi::c_int
                as *mut ::core::ffi::c_void,
        ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 24],
                    [::core::ffi::c_char; 24],
                >(*b"test_hashmap_collisions\0")
                    .as_ptr(),
                b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
                62 as ::core::ffi::c_int,
                b"hashmap_put(map, i, &values[i]) == 0\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        } else {};
        i += 1;
    }
    if !(hashmap_size(map) == 100 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 24],
                [::core::ffi::c_char; 24],
            >(*b"test_hashmap_collisions\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            65 as ::core::ffi::c_int,
            b"hashmap_size(map) == 100\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_0 < 100 as ::core::ffi::c_int {
        let mut val: *mut ::core::ffi::c_int = hashmap_get(map, i_0 as tree_id_t)
            as *mut ::core::ffi::c_int;
        if val.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 24],
                    [::core::ffi::c_char; 24],
                >(*b"test_hashmap_collisions\0")
                    .as_ptr(),
                b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
                70 as ::core::ffi::c_int,
                b"val != NULL\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        if !(*val == i_0 * 10 as ::core::ffi::c_int) as ::core::ffi::c_int
            as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 24],
                    [::core::ffi::c_char; 24],
                >(*b"test_hashmap_collisions\0")
                    .as_ptr(),
                b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
                71 as ::core::ffi::c_int,
                b"*val == i * 10\0" as *const u8 as *const ::core::ffi::c_char,
            );
        } else {};
        i_0 += 1;
    }
    hashmap_destroy(map);
    printf(
        b"\xE2\x9C\x93 PASS: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        ::core::mem::transmute::<
            [u8; 24],
            [::core::ffi::c_char; 24],
        >(*b"test_hashmap_collisions\0")
            .as_ptr(),
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_tree_creation() {
    printf(
        b"\n=== Testing Tree Creation ===\n\0" as *const u8 as *const ::core::ffi::c_char,
    );
    let mut tree: *mut tree_t = tree_create();
    if tree.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_tree_creation\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            82 as ::core::ffi::c_int,
            b"tree != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_size(tree) == 0 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_tree_creation\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            83 as ::core::ffi::c_int,
            b"tree_size(tree) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tree).has_root == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_tree_creation\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            84 as ::core::ffi::c_int,
            b"tree->has_root == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    tree_delete(tree);
    printf(
        b"\xE2\x9C\x93 PASS: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        ::core::mem::transmute::<
            [u8; 19],
            [::core::ffi::c_char; 19],
        >(*b"test_tree_creation\0")
            .as_ptr(),
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_tree_add_root() {
    printf(
        b"\n=== Testing Tree Add Root ===\n\0" as *const u8 as *const ::core::ffi::c_char,
    );
    let mut tree: *mut tree_t = tree_create();
    if !(tree_add_node(
        tree,
        1 as tree_id_t,
        0 as tree_id_t,
        b"root\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_tree_add_root\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            96 as ::core::ffi::c_int,
            b"tree_add_node(tree, 1, 0, \"root\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_size(tree) == 1 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_tree_add_root\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            97 as ::core::ffi::c_int,
            b"tree_size(tree) == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tree).has_root == 1 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_tree_add_root\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            98 as ::core::ffi::c_int,
            b"tree->has_root == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tree).root_id == 1 as tree_id_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_tree_add_root\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            99 as ::core::ffi::c_int,
            b"tree->root_id == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut root: *mut tree_node_t = tree_get_node(tree, 1 as tree_id_t);
    if root.is_null() as ::core::ffi::c_int as ::core::ffi::c_long != 0 {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_tree_add_root\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            102 as ::core::ffi::c_int,
            b"root != NULL\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*root).id == 1 as tree_id_t) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_tree_add_root\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            103 as ::core::ffi::c_int,
            b"root->id == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(strcmp(
        (*root).data.as_mut_ptr(),
        b"root\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_tree_add_root\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            104 as ::core::ffi::c_int,
            b"strcmp(root->data, \"root\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*root).child_count == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 19],
                [::core::ffi::c_char; 19],
            >(*b"test_tree_add_root\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            105 as ::core::ffi::c_int,
            b"root->child_count == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    tree_delete(tree);
    printf(
        b"\xE2\x9C\x93 PASS: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        ::core::mem::transmute::<
            [u8; 19],
            [::core::ffi::c_char; 19],
        >(*b"test_tree_add_root\0")
            .as_ptr(),
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_tree_add_children() {
    printf(
        b"\n=== Testing Tree Add Children ===\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut tree: *mut tree_t = tree_create();
    if !(tree_add_node(
        tree,
        1 as tree_id_t,
        0 as tree_id_t,
        b"root\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_tree_add_children\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            117 as ::core::ffi::c_int,
            b"tree_add_node(tree, 1, 0, \"root\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        2 as tree_id_t,
        1 as tree_id_t,
        b"child1\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_tree_add_children\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            118 as ::core::ffi::c_int,
            b"tree_add_node(tree, 2, 1, \"child1\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        3 as tree_id_t,
        1 as tree_id_t,
        b"child2\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_tree_add_children\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            119 as ::core::ffi::c_int,
            b"tree_add_node(tree, 3, 1, \"child2\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        4 as tree_id_t,
        1 as tree_id_t,
        b"child3\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_tree_add_children\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            120 as ::core::ffi::c_int,
            b"tree_add_node(tree, 4, 1, \"child3\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_size(tree) == 4 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_tree_add_children\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            122 as ::core::ffi::c_int,
            b"tree_size(tree) == 4\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut root: *mut tree_node_t = tree_get_node(tree, 1 as tree_id_t);
    if !((*root).child_count == 3 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_tree_add_children\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            125 as ::core::ffi::c_int,
            b"root->child_count == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*root).child_ids[0 as ::core::ffi::c_int as usize] == 2 as tree_id_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_tree_add_children\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            126 as ::core::ffi::c_int,
            b"root->child_ids[0] == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*root).child_ids[1 as ::core::ffi::c_int as usize] == 3 as tree_id_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_tree_add_children\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            127 as ::core::ffi::c_int,
            b"root->child_ids[1] == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*root).child_ids[2 as ::core::ffi::c_int as usize] == 4 as tree_id_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_tree_add_children\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            128 as ::core::ffi::c_int,
            b"root->child_ids[2] == 4\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    tree_delete(tree);
    printf(
        b"\xE2\x9C\x93 PASS: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        ::core::mem::transmute::<
            [u8; 23],
            [::core::ffi::c_char; 23],
        >(*b"test_tree_add_children\0")
            .as_ptr(),
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_tree_deep_hierarchy() {
    printf(
        b"\n=== Testing Tree Deep Hierarchy ===\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut tree: *mut tree_t = tree_create();
    if !(tree_add_node(
        tree,
        1 as tree_id_t,
        0 as tree_id_t,
        b"level0\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_deep_hierarchy\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            140 as ::core::ffi::c_int,
            b"tree_add_node(tree, 1, 0, \"level0\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        2 as tree_id_t,
        1 as tree_id_t,
        b"level1\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_deep_hierarchy\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            141 as ::core::ffi::c_int,
            b"tree_add_node(tree, 2, 1, \"level1\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        3 as tree_id_t,
        2 as tree_id_t,
        b"level2\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_deep_hierarchy\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            142 as ::core::ffi::c_int,
            b"tree_add_node(tree, 3, 2, \"level2\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        4 as tree_id_t,
        3 as tree_id_t,
        b"level3\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_deep_hierarchy\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            143 as ::core::ffi::c_int,
            b"tree_add_node(tree, 4, 3, \"level3\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        5 as tree_id_t,
        4 as tree_id_t,
        b"level4\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_deep_hierarchy\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            144 as ::core::ffi::c_int,
            b"tree_add_node(tree, 5, 4, \"level4\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_size(tree) == 5 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_deep_hierarchy\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            146 as ::core::ffi::c_int,
            b"tree_size(tree) == 5\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_get_depth(tree, 1 as tree_id_t) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_deep_hierarchy\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            148 as ::core::ffi::c_int,
            b"tree_get_depth(tree, 1) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_get_depth(tree, 2 as tree_id_t) == 1 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_deep_hierarchy\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            149 as ::core::ffi::c_int,
            b"tree_get_depth(tree, 2) == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_get_depth(tree, 3 as tree_id_t) == 2 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_deep_hierarchy\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            150 as ::core::ffi::c_int,
            b"tree_get_depth(tree, 3) == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_get_depth(tree, 4 as tree_id_t) == 3 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_deep_hierarchy\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            151 as ::core::ffi::c_int,
            b"tree_get_depth(tree, 4) == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_get_depth(tree, 5 as tree_id_t) == 4 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_deep_hierarchy\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            152 as ::core::ffi::c_int,
            b"tree_get_depth(tree, 5) == 4\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_get_height(tree, 1 as tree_id_t) == 4 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_deep_hierarchy\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            154 as ::core::ffi::c_int,
            b"tree_get_height(tree, 1) == 4\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_get_height(tree, 2 as tree_id_t) == 3 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_deep_hierarchy\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            155 as ::core::ffi::c_int,
            b"tree_get_height(tree, 2) == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_get_height(tree, 5 as tree_id_t) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_deep_hierarchy\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            156 as ::core::ffi::c_int,
            b"tree_get_height(tree, 5) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    tree_delete(tree);
    printf(
        b"\xE2\x9C\x93 PASS: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        ::core::mem::transmute::<
            [u8; 25],
            [::core::ffi::c_char; 25],
        >(*b"test_tree_deep_hierarchy\0")
            .as_ptr(),
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_tree_remove_leaf() {
    printf(
        b"\n=== Testing Tree Remove Leaf ===\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut tree: *mut tree_t = tree_create();
    if !(tree_add_node(
        tree,
        1 as tree_id_t,
        0 as tree_id_t,
        b"root\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_tree_remove_leaf\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            167 as ::core::ffi::c_int,
            b"tree_add_node(tree, 1, 0, \"root\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        2 as tree_id_t,
        1 as tree_id_t,
        b"child1\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_tree_remove_leaf\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            168 as ::core::ffi::c_int,
            b"tree_add_node(tree, 2, 1, \"child1\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        3 as tree_id_t,
        1 as tree_id_t,
        b"child2\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_tree_remove_leaf\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            169 as ::core::ffi::c_int,
            b"tree_add_node(tree, 3, 1, \"child2\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_size(tree) == 3 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_tree_remove_leaf\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            171 as ::core::ffi::c_int,
            b"tree_size(tree) == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_remove_node(tree, 3 as tree_id_t) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_tree_remove_leaf\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            174 as ::core::ffi::c_int,
            b"tree_remove_node(tree, 3) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_size(tree) == 2 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_tree_remove_leaf\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            175 as ::core::ffi::c_int,
            b"tree_size(tree) == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_contains(tree, 3 as tree_id_t) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_tree_remove_leaf\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            176 as ::core::ffi::c_int,
            b"tree_contains(tree, 3) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    let mut root: *mut tree_node_t = tree_get_node(tree, 1 as tree_id_t);
    if !((*root).child_count == 1 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_tree_remove_leaf\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            179 as ::core::ffi::c_int,
            b"root->child_count == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*root).child_ids[0 as ::core::ffi::c_int as usize] == 2 as tree_id_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_tree_remove_leaf\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            180 as ::core::ffi::c_int,
            b"root->child_ids[0] == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    tree_delete(tree);
    printf(
        b"\xE2\x9C\x93 PASS: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        ::core::mem::transmute::<
            [u8; 22],
            [::core::ffi::c_char; 22],
        >(*b"test_tree_remove_leaf\0")
            .as_ptr(),
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_tree_remove_subtree() {
    printf(
        b"\n=== Testing Tree Remove Subtree ===\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut tree: *mut tree_t = tree_create();
    if !(tree_add_node(
        tree,
        1 as tree_id_t,
        0 as tree_id_t,
        b"root\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_remove_subtree\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            192 as ::core::ffi::c_int,
            b"tree_add_node(tree, 1, 0, \"root\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        2 as tree_id_t,
        1 as tree_id_t,
        b"child1\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_remove_subtree\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            193 as ::core::ffi::c_int,
            b"tree_add_node(tree, 2, 1, \"child1\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        3 as tree_id_t,
        2 as tree_id_t,
        b"grandchild1\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_remove_subtree\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            194 as ::core::ffi::c_int,
            b"tree_add_node(tree, 3, 2, \"grandchild1\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        4 as tree_id_t,
        2 as tree_id_t,
        b"grandchild2\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_remove_subtree\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            195 as ::core::ffi::c_int,
            b"tree_add_node(tree, 4, 2, \"grandchild2\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        5 as tree_id_t,
        1 as tree_id_t,
        b"child2\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_remove_subtree\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            196 as ::core::ffi::c_int,
            b"tree_add_node(tree, 5, 1, \"child2\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_size(tree) == 5 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_remove_subtree\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            198 as ::core::ffi::c_int,
            b"tree_size(tree) == 5\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_remove_node(tree, 2 as tree_id_t) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_remove_subtree\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            201 as ::core::ffi::c_int,
            b"tree_remove_node(tree, 2) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_size(tree) == 2 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_remove_subtree\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            202 as ::core::ffi::c_int,
            b"tree_size(tree) == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_contains(tree, 2 as tree_id_t) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_remove_subtree\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            203 as ::core::ffi::c_int,
            b"tree_contains(tree, 2) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_contains(tree, 3 as tree_id_t) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_remove_subtree\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            204 as ::core::ffi::c_int,
            b"tree_contains(tree, 3) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_contains(tree, 4 as tree_id_t) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_remove_subtree\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            205 as ::core::ffi::c_int,
            b"tree_contains(tree, 4) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_contains(tree, 1 as tree_id_t) == 1 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_remove_subtree\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            206 as ::core::ffi::c_int,
            b"tree_contains(tree, 1) == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_contains(tree, 5 as tree_id_t) == 1 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 25],
                [::core::ffi::c_char; 25],
            >(*b"test_tree_remove_subtree\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            207 as ::core::ffi::c_int,
            b"tree_contains(tree, 5) == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    tree_delete(tree);
    printf(
        b"\xE2\x9C\x93 PASS: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        ::core::mem::transmute::<
            [u8; 25],
            [::core::ffi::c_char; 25],
        >(*b"test_tree_remove_subtree\0")
            .as_ptr(),
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_tree_remove_root() {
    printf(
        b"\n=== Testing Tree Remove Root ===\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut tree: *mut tree_t = tree_create();
    if !(tree_add_node(
        tree,
        1 as tree_id_t,
        0 as tree_id_t,
        b"root\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_tree_remove_root\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            218 as ::core::ffi::c_int,
            b"tree_add_node(tree, 1, 0, \"root\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        2 as tree_id_t,
        1 as tree_id_t,
        b"child1\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_tree_remove_root\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            219 as ::core::ffi::c_int,
            b"tree_add_node(tree, 2, 1, \"child1\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        3 as tree_id_t,
        1 as tree_id_t,
        b"child2\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_tree_remove_root\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            220 as ::core::ffi::c_int,
            b"tree_add_node(tree, 3, 1, \"child2\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_size(tree) == 3 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_tree_remove_root\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            222 as ::core::ffi::c_int,
            b"tree_size(tree) == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_remove_node(tree, 1 as tree_id_t) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_tree_remove_root\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            225 as ::core::ffi::c_int,
            b"tree_remove_node(tree, 1) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_size(tree) == 0 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_tree_remove_root\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            226 as ::core::ffi::c_int,
            b"tree_size(tree) == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !((*tree).has_root == 0 as ::core::ffi::c_int) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 22],
                [::core::ffi::c_char; 22],
            >(*b"test_tree_remove_root\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            227 as ::core::ffi::c_int,
            b"tree->has_root == 0\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    tree_delete(tree);
    printf(
        b"\xE2\x9C\x93 PASS: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        ::core::mem::transmute::<
            [u8; 22],
            [::core::ffi::c_char; 22],
        >(*b"test_tree_remove_root\0")
            .as_ptr(),
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_tree_count_descendants() {
    printf(
        b"\n=== Testing Tree Count Descendants ===\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut tree: *mut tree_t = tree_create();
    if !(tree_add_node(
        tree,
        1 as tree_id_t,
        0 as tree_id_t,
        b"root\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_count_descendants\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            246 as ::core::ffi::c_int,
            b"tree_add_node(tree, 1, 0, \"root\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        2 as tree_id_t,
        1 as tree_id_t,
        b"child1\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_count_descendants\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            247 as ::core::ffi::c_int,
            b"tree_add_node(tree, 2, 1, \"child1\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        3 as tree_id_t,
        2 as tree_id_t,
        b"grandchild1\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_count_descendants\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            248 as ::core::ffi::c_int,
            b"tree_add_node(tree, 3, 2, \"grandchild1\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        4 as tree_id_t,
        2 as tree_id_t,
        b"grandchild2\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_count_descendants\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            249 as ::core::ffi::c_int,
            b"tree_add_node(tree, 4, 2, \"grandchild2\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        5 as tree_id_t,
        1 as tree_id_t,
        b"child2\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_count_descendants\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            250 as ::core::ffi::c_int,
            b"tree_add_node(tree, 5, 1, \"child2\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_count_descendants(tree, 1 as tree_id_t) == 4 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_count_descendants\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            252 as ::core::ffi::c_int,
            b"tree_count_descendants(tree, 1) == 4\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_count_descendants(tree, 2 as tree_id_t) == 2 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_count_descendants\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            253 as ::core::ffi::c_int,
            b"tree_count_descendants(tree, 2) == 2\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_count_descendants(tree, 3 as tree_id_t) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_count_descendants\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            254 as ::core::ffi::c_int,
            b"tree_count_descendants(tree, 3) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_count_descendants(tree, 5 as tree_id_t) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_count_descendants\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            255 as ::core::ffi::c_int,
            b"tree_count_descendants(tree, 5) == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    tree_delete(tree);
    printf(
        b"\xE2\x9C\x93 PASS: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        ::core::mem::transmute::<
            [u8; 28],
            [::core::ffi::c_char; 28],
        >(*b"test_tree_count_descendants\0")
            .as_ptr(),
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_tree_find_path() {
    printf(
        b"\n=== Testing Tree Find Path ===\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut tree: *mut tree_t = tree_create();
    if !(tree_add_node(
        tree,
        1 as tree_id_t,
        0 as tree_id_t,
        b"root\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_tree_find_path\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            266 as ::core::ffi::c_int,
            b"tree_add_node(tree, 1, 0, \"root\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        2 as tree_id_t,
        1 as tree_id_t,
        b"child\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_tree_find_path\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            267 as ::core::ffi::c_int,
            b"tree_add_node(tree, 2, 1, \"child\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        3 as tree_id_t,
        2 as tree_id_t,
        b"grandchild\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_tree_find_path\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            268 as ::core::ffi::c_int,
            b"tree_add_node(tree, 3, 2, \"grandchild\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut path: [tree_id_t; 10] = [0; 10];
    let mut length: ::core::ffi::c_int = 0;
    length = tree_find_path(
        tree,
        3 as tree_id_t,
        path.as_mut_ptr(),
        10 as ::core::ffi::c_int,
    );
    if !(length == 3 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_tree_find_path\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            274 as ::core::ffi::c_int,
            b"length == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(path[0 as ::core::ffi::c_int as usize] == 1 as tree_id_t) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_tree_find_path\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            275 as ::core::ffi::c_int,
            b"path[0] == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(path[1 as ::core::ffi::c_int as usize] == 2 as tree_id_t) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_tree_find_path\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            276 as ::core::ffi::c_int,
            b"path[1] == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(path[2 as ::core::ffi::c_int as usize] == 3 as tree_id_t) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_tree_find_path\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            277 as ::core::ffi::c_int,
            b"path[2] == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    length = tree_find_path(
        tree,
        1 as tree_id_t,
        path.as_mut_ptr(),
        10 as ::core::ffi::c_int,
    );
    if !(length == 1 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_tree_find_path\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            280 as ::core::ffi::c_int,
            b"length == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(path[0 as ::core::ffi::c_int as usize] == 1 as tree_id_t) as ::core::ffi::c_int
        as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 20],
                [::core::ffi::c_char; 20],
            >(*b"test_tree_find_path\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            281 as ::core::ffi::c_int,
            b"path[0] == 1\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    tree_delete(tree);
    printf(
        b"\xE2\x9C\x93 PASS: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        ::core::mem::transmute::<
            [u8; 20],
            [::core::ffi::c_char; 20],
        >(*b"test_tree_find_path\0")
            .as_ptr(),
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_tree_duplicate_id() {
    printf(
        b"\n=== Testing Tree Duplicate ID ===\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut tree: *mut tree_t = tree_create();
    if !(tree_add_node(
        tree,
        1 as tree_id_t,
        0 as tree_id_t,
        b"root\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_tree_duplicate_id\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            292 as ::core::ffi::c_int,
            b"tree_add_node(tree, 1, 0, \"root\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        2 as tree_id_t,
        1 as tree_id_t,
        b"child\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_tree_duplicate_id\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            293 as ::core::ffi::c_int,
            b"tree_add_node(tree, 2, 1, \"child\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        2 as tree_id_t,
        1 as tree_id_t,
        b"duplicate\0" as *const u8 as *const ::core::ffi::c_char,
    ) != 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_tree_duplicate_id\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            296 as ::core::ffi::c_int,
            b"tree_add_node(tree, 2, 1, \"duplicate\") != 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_size(tree) == 2 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_tree_duplicate_id\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            297 as ::core::ffi::c_int,
            b"tree_size(tree) == 2\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    tree_delete(tree);
    printf(
        b"\xE2\x9C\x93 PASS: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        ::core::mem::transmute::<
            [u8; 23],
            [::core::ffi::c_char; 23],
        >(*b"test_tree_duplicate_id\0")
            .as_ptr(),
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_tree_max_children() {
    printf(
        b"\n=== Testing Tree Max Children ===\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut tree: *mut tree_t = tree_create();
    if !(tree_add_node(
        tree,
        1 as tree_id_t,
        0 as tree_id_t,
        b"root\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_tree_max_children\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            308 as ::core::ffi::c_int,
            b"tree_add_node(tree, 1, 0, \"root\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < MAX_CHILDREN {
        if !(tree_add_node(
            tree,
            (i + 2 as ::core::ffi::c_int) as tree_id_t,
            1 as tree_id_t,
            b"child\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
        {
            __assert_rtn(
                ::core::mem::transmute::<
                    [u8; 23],
                    [::core::ffi::c_char; 23],
                >(*b"test_tree_max_children\0")
                    .as_ptr(),
                b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
                312 as ::core::ffi::c_int,
                b"tree_add_node(tree, i + 2, 1, \"child\") == 0\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
        } else {};
        i += 1;
    }
    if !(tree_add_node(
        tree,
        (32 as ::core::ffi::c_int + 2 as ::core::ffi::c_int) as tree_id_t,
        1 as tree_id_t,
        b"overflow\0" as *const u8 as *const ::core::ffi::c_char,
    ) != 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_tree_max_children\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            316 as ::core::ffi::c_int,
            b"tree_add_node(tree, MAX_CHILDREN + 2, 1, \"overflow\") != 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_size(tree)
        == (32 as ::core::ffi::c_int + 1 as ::core::ffi::c_int) as size_t)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 23],
                [::core::ffi::c_char; 23],
            >(*b"test_tree_max_children\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            317 as ::core::ffi::c_int,
            b"tree_size(tree) == MAX_CHILDREN + 1\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    tree_delete(tree);
    printf(
        b"\xE2\x9C\x93 PASS: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        ::core::mem::transmute::<
            [u8; 23],
            [::core::ffi::c_char; 23],
        >(*b"test_tree_max_children\0")
            .as_ptr(),
    );
}
#[no_mangle]
pub unsafe extern "C" fn test_tree_complex_structure() {
    printf(
        b"\n=== Testing Tree Complex Structure ===\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    let mut tree: *mut tree_t = tree_create();
    if !(tree_add_node(
        tree,
        1 as tree_id_t,
        0 as tree_id_t,
        b"root\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_complex_structure\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            338 as ::core::ffi::c_int,
            b"tree_add_node(tree, 1, 0, \"root\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        2 as tree_id_t,
        1 as tree_id_t,
        b"child1\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_complex_structure\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            339 as ::core::ffi::c_int,
            b"tree_add_node(tree, 2, 1, \"child1\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        3 as tree_id_t,
        1 as tree_id_t,
        b"child2\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_complex_structure\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            340 as ::core::ffi::c_int,
            b"tree_add_node(tree, 3, 1, \"child2\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        4 as tree_id_t,
        1 as tree_id_t,
        b"child3\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_complex_structure\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            341 as ::core::ffi::c_int,
            b"tree_add_node(tree, 4, 1, \"child3\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        5 as tree_id_t,
        2 as tree_id_t,
        b"gc1\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_complex_structure\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            342 as ::core::ffi::c_int,
            b"tree_add_node(tree, 5, 2, \"gc1\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        6 as tree_id_t,
        2 as tree_id_t,
        b"gc2\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_complex_structure\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            343 as ::core::ffi::c_int,
            b"tree_add_node(tree, 6, 2, \"gc2\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        7 as tree_id_t,
        3 as tree_id_t,
        b"gc3\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_complex_structure\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            344 as ::core::ffi::c_int,
            b"tree_add_node(tree, 7, 3, \"gc3\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        8 as tree_id_t,
        4 as tree_id_t,
        b"gc4\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_complex_structure\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            345 as ::core::ffi::c_int,
            b"tree_add_node(tree, 8, 4, \"gc4\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        9 as tree_id_t,
        4 as tree_id_t,
        b"gc5\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_complex_structure\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            346 as ::core::ffi::c_int,
            b"tree_add_node(tree, 9, 4, \"gc5\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_add_node(
        tree,
        10 as tree_id_t,
        7 as tree_id_t,
        b"ggc1\0" as *const u8 as *const ::core::ffi::c_char,
    ) == 0 as ::core::ffi::c_int) as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_complex_structure\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            347 as ::core::ffi::c_int,
            b"tree_add_node(tree, 10, 7, \"ggc1\") == 0\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_size(tree) == 10 as size_t) as ::core::ffi::c_int as ::core::ffi::c_long
        != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_complex_structure\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            349 as ::core::ffi::c_int,
            b"tree_size(tree) == 10\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_get_height(tree, 1 as tree_id_t) == 3 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_complex_structure\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            350 as ::core::ffi::c_int,
            b"tree_get_height(tree, 1) == 3\0" as *const u8 as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_count_descendants(tree, 1 as tree_id_t) == 9 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_complex_structure\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            351 as ::core::ffi::c_int,
            b"tree_count_descendants(tree, 1) == 9\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_count_descendants(tree, 2 as tree_id_t) == 2 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_complex_structure\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            352 as ::core::ffi::c_int,
            b"tree_count_descendants(tree, 2) == 2\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    if !(tree_count_descendants(tree, 7 as tree_id_t) == 1 as ::core::ffi::c_int)
        as ::core::ffi::c_int as ::core::ffi::c_long != 0
    {
        __assert_rtn(
            ::core::mem::transmute::<
                [u8; 28],
                [::core::ffi::c_char; 28],
            >(*b"test_tree_complex_structure\0")
                .as_ptr(),
            b"main.c\0" as *const u8 as *const ::core::ffi::c_char,
            353 as ::core::ffi::c_int,
            b"tree_count_descendants(tree, 7) == 1\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {};
    tree_print(tree);
    tree_delete(tree);
    printf(
        b"\xE2\x9C\x93 PASS: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        ::core::mem::transmute::<
            [u8; 28],
            [::core::ffi::c_char; 28],
        >(*b"test_tree_complex_structure\0")
            .as_ptr(),
    );
}
unsafe fn main_0() -> ::core::ffi::c_int {
    printf(
        b"\xE2\x95\x94\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x97\n\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    printf(
        b"\xE2\x95\x91  TREE WITH HASHMAP ID MAPPING TESTS   \xE2\x95\x91\n\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    printf(
        b"\xE2\x95\x9A\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x9D\n\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    test_hashmap_basic();
    test_hashmap_collisions();
    test_tree_creation();
    test_tree_add_root();
    test_tree_add_children();
    test_tree_deep_hierarchy();
    test_tree_complex_structure();
    test_tree_remove_leaf();
    test_tree_remove_subtree();
    test_tree_remove_root();
    test_tree_count_descendants();
    test_tree_find_path();
    test_tree_duplicate_id();
    test_tree_max_children();
    printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(
        b"========================================\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    printf(
        b"  All tests passed successfully!\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    printf(
        b"========================================\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
