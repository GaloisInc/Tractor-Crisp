#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
extern "C" {
    fn strchr(
        __s: *const ::core::ffi::c_char,
        __c: ::core::ffi::c_int,
    ) -> *mut ::core::ffi::c_char;
    fn strncpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> *mut ::core::ffi::c_char;
}
pub type __darwin_size_t = usize;
pub type size_t = __darwin_size_t;
pub type Operation = ::core::ffi::c_uint;
pub const OP_MODULO: Operation = 5;
pub const OP_DIVIDE: Operation = 4;
pub const OP_SUBTRACT: Operation = 3;
pub const OP_MULTIPLY: Operation = 2;
pub const OP_ADD: Operation = 1;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct TreeNode {
    pub id: ::core::ffi::c_int,
    pub value: ::core::ffi::c_int,
    pub parent_id: ::core::ffi::c_int,
    pub left_child_id: ::core::ffi::c_int,
    pub right_child_id: ::core::ffi::c_int,
    pub label: [::core::ffi::c_char; 32],
}
pub type OperationFunc = Option<
    unsafe extern "C" fn(
        ::core::ffi::c_int,
        ::core::ffi::c_int,
        ::core::ffi::c_int,
        ::core::ffi::c_int,
    ) -> ::core::ffi::c_int,
>;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const MAX_NODES: ::core::ffi::c_int = 50 as ::core::ffi::c_int;
#[no_mangle]
pub static mut node_table: [TreeNode; 50] = [TreeNode {
    id: 0,
    value: 0,
    parent_id: 0,
    left_child_id: 0,
    right_child_id: 0,
    label: [0; 32],
}; 50];
#[no_mangle]
pub static mut node_count: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn add_op(
    mut a: ::core::ffi::c_int,
    mut b: ::core::ffi::c_int,
    mut unused1: ::core::ffi::c_int,
    mut unused2: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    return a + b;
}
#[no_mangle]
pub unsafe extern "C" fn multiply_op(
    mut a: ::core::ffi::c_int,
    mut b: ::core::ffi::c_int,
    mut unused1: ::core::ffi::c_int,
    mut unused2: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    return a * b;
}
#[no_mangle]
pub unsafe extern "C" fn subtract_op(
    mut a: ::core::ffi::c_int,
    mut b: ::core::ffi::c_int,
    mut unused1: ::core::ffi::c_int,
    mut unused2: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    return a - b;
}
#[no_mangle]
pub unsafe extern "C" fn divide_op(
    mut a: ::core::ffi::c_int,
    mut b: ::core::ffi::c_int,
    mut unused1: ::core::ffi::c_int,
    mut unused2: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    if b == 0 as ::core::ffi::c_int {
        return 0 as ::core::ffi::c_int;
    }
    return a / b;
}
#[no_mangle]
pub unsafe extern "C" fn modulo_op(
    mut a: ::core::ffi::c_int,
    mut b: ::core::ffi::c_int,
    mut unused1: ::core::ffi::c_int,
    mut unused2: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    if b == 0 as ::core::ffi::c_int {
        return 0 as ::core::ffi::c_int;
    }
    return a % b;
}
#[no_mangle]
pub unsafe extern "C" fn find_node_by_id(mut id: ::core::ffi::c_int) -> *mut TreeNode {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < node_count {
        if node_table[i as usize].id == id {
            return &mut *node_table.as_mut_ptr().offset(i as isize) as *mut TreeNode;
        }
        i += 1;
    }
    return 0 as *mut TreeNode;
}
#[no_mangle]
pub unsafe extern "C" fn add_tree_node(
    mut id: ::core::ffi::c_int,
    mut value: ::core::ffi::c_int,
    mut parent_id: ::core::ffi::c_int,
    mut label: *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    if node_count >= MAX_NODES {
        return -(1 as ::core::ffi::c_int);
    }
    let mut node: *mut TreeNode = &mut *node_table
        .as_mut_ptr()
        .offset(node_count as isize) as *mut TreeNode;
    (*node).id = id;
    (*node).value = value;
    (*node).parent_id = parent_id;
    (*node).left_child_id = -(1 as ::core::ffi::c_int);
    (*node).right_child_id = -(1 as ::core::ffi::c_int);
    strncpy((*node).label.as_mut_ptr(), label, 31 as size_t);
    (*node).label[31 as ::core::ffi::c_int as usize] = '\0' as i32
        as ::core::ffi::c_char;
    if parent_id != -(1 as ::core::ffi::c_int) {
        let mut parent: *mut TreeNode = find_node_by_id(parent_id);
        if parent.is_null() || (*parent).id != parent_id {
            return -(1 as ::core::ffi::c_int);
        }
        if (*parent).left_child_id == -(1 as ::core::ffi::c_int) {
            (*parent).left_child_id = id;
        } else if (*parent).right_child_id == -(1 as ::core::ffi::c_int) {
            (*parent).right_child_id = id;
        }
    }
    node_count += 1;
    return node_count - 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn calculate_tree_sum(
    mut node_id: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    let mut node: *mut TreeNode = find_node_by_id(node_id);
    if node.is_null() || (*node).id != node_id {
        return 0 as ::core::ffi::c_int;
    }
    let mut sum: ::core::ffi::c_int = (*node).value;
    if (*node).left_child_id != -(1 as ::core::ffi::c_int) {
        sum += calculate_tree_sum((*node).left_child_id);
    }
    if (*node).right_child_id != -(1 as ::core::ffi::c_int) {
        sum += calculate_tree_sum((*node).right_child_id);
    }
    return sum;
}
#[no_mangle]
pub unsafe extern "C" fn parse_operation(
    mut op_str: *const ::core::ffi::c_char,
) -> Operation {
    if op_str.is_null() || !strchr(op_str, '+' as i32).is_null() {
        return OP_ADD;
    }
    if !strchr(op_str, '*' as i32).is_null() {
        return OP_MULTIPLY;
    }
    if !strchr(op_str, '-' as i32).is_null() {
        return OP_SUBTRACT;
    }
    if !strchr(op_str, '/' as i32).is_null() {
        return OP_DIVIDE;
    }
    if !strchr(op_str, '%' as i32).is_null() {
        return OP_MODULO;
    }
    return OP_ADD;
}
#[no_mangle]
pub unsafe extern "C" fn get_operation_func(mut op: Operation) -> OperationFunc {
    match op as ::core::ffi::c_int {
        1 => {
            return Some(
                add_op
                    as unsafe extern "C" fn(
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                    ) -> ::core::ffi::c_int,
            );
        }
        2 => {
            return Some(
                multiply_op
                    as unsafe extern "C" fn(
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                    ) -> ::core::ffi::c_int,
            );
        }
        3 => {
            return Some(
                subtract_op
                    as unsafe extern "C" fn(
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                    ) -> ::core::ffi::c_int,
            );
        }
        4 => {
            return Some(
                divide_op
                    as unsafe extern "C" fn(
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                    ) -> ::core::ffi::c_int,
            );
        }
        5 => {
            return Some(
                modulo_op
                    as unsafe extern "C" fn(
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                    ) -> ::core::ffi::c_int,
            );
        }
        _ => {
            return Some(
                add_op
                    as unsafe extern "C" fn(
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                        ::core::ffi::c_int,
                    ) -> ::core::ffi::c_int,
            );
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn inreftree(
    mut param1: ::core::ffi::c_int,
    mut param2: ::core::ffi::c_int,
    mut param3: ::core::ffi::c_int,
    mut param4: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    node_count = 0 as ::core::ffi::c_int;
    add_tree_node(
        1 as ::core::ffi::c_int,
        param1,
        -(1 as ::core::ffi::c_int),
        b"root\0" as *const u8 as *const ::core::ffi::c_char,
    );
    add_tree_node(
        2 as ::core::ffi::c_int,
        param2,
        1 as ::core::ffi::c_int,
        b"left\0" as *const u8 as *const ::core::ffi::c_char,
    );
    add_tree_node(
        3 as ::core::ffi::c_int,
        param3,
        1 as ::core::ffi::c_int,
        b"right\0" as *const u8 as *const ::core::ffi::c_char,
    );
    add_tree_node(
        4 as ::core::ffi::c_int,
        param4,
        2 as ::core::ffi::c_int,
        b"left-left\0" as *const u8 as *const ::core::ffi::c_char,
    );
    let mut target_id: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < node_count {
        if !strchr(
                (*node_table.as_mut_ptr().offset(i as isize)).label.as_mut_ptr(),
                'l' as i32,
            )
            .is_null()
        {
            target_id = node_table[i as usize].id;
            break;
        } else {
            i += 1;
        }
    }
    let mut target: *mut TreeNode = find_node_by_id(target_id);
    if target.is_null() || (*target).value == 0 as ::core::ffi::c_int {
        target_id = 1 as ::core::ffi::c_int;
    }
    let mut tree_sum: ::core::ffi::c_int = calculate_tree_sum(1 as ::core::ffi::c_int);
    let mut op_string: *const ::core::ffi::c_char = b"+*-%\0" as *const u8
        as *const ::core::ffi::c_char;
    let mut op_char: [::core::ffi::c_char; 2] = [
        *op_string.offset((tree_sum % 4 as ::core::ffi::c_int) as isize),
        '\0' as i32 as ::core::ffi::c_char,
    ];
    let mut op: Operation = parse_operation(op_char.as_mut_ptr());
    let mut op_value: ::core::ffi::c_int = op as ::core::ffi::c_int;
    let mut func: OperationFunc = get_operation_func(op);
    let mut result: ::core::ffi::c_int = func
        .expect(
            "non-null function pointer",
        )(tree_sum, target_id, 0 as ::core::ffi::c_int, 0 as ::core::ffi::c_int);
    return result;
}
