#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn perror(_: *const ::core::ffi::c_char);
    fn snprintf(
        __str: *mut ::core::ffi::c_char,
        __size: size_t,
        __format: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn atoi(_: *const ::core::ffi::c_char) -> ::core::ffi::c_int;
    fn strcat(
        __s1: *mut ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
    fn strtok_r(
        __str: *mut ::core::ffi::c_char,
        __sep: *const ::core::ffi::c_char,
        __lasts: *mut *mut ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
    fn strdup(__s1: *const ::core::ffi::c_char) -> *mut ::core::ffi::c_char;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct matrix_t {
    pub matrix: *mut *mut ::core::ffi::c_int,
    pub width: ::core::ffi::c_int,
    pub height: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
#[no_mangle]
pub unsafe extern "C" fn allocate_matrix(
    mut width: ::core::ffi::c_int,
    mut height: ::core::ffi::c_int,
) -> *mut matrix_t {
    let mut mat: *mut matrix_t = malloc(::core::mem::size_of::<matrix_t>() as size_t)
        as *mut matrix_t;
    if mat.is_null() {
        perror(
            b"Failed to allocate memory for matrix struct\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 0 as *mut matrix_t;
    }
    (*mat).width = width;
    (*mat).height = height;
    (*mat).matrix = malloc(
        (height as size_t)
            .wrapping_mul(::core::mem::size_of::<*mut ::core::ffi::c_int>() as size_t),
    ) as *mut *mut ::core::ffi::c_int;
    if (*mat).matrix.is_null() {
        perror(
            b"Failed to allocate memory for matrix rows\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        free(mat as *mut ::core::ffi::c_void);
        return 0 as *mut matrix_t;
    }
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < height {
        let ref mut fresh0 = *(*mat).matrix.offset(i as isize);
        *fresh0 = malloc(
            (width as size_t)
                .wrapping_mul(::core::mem::size_of::<::core::ffi::c_int>() as size_t),
        ) as *mut ::core::ffi::c_int;
        if (*(*mat).matrix.offset(i as isize)).is_null() {
            perror(
                b"Failed to allocate memory for matrix columns\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
            let mut j: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
            while j <= i {
                free(*(*mat).matrix.offset(j as isize) as *mut ::core::ffi::c_void);
                j += 1;
            }
            free((*mat).matrix as *mut ::core::ffi::c_void);
            free(mat as *mut ::core::ffi::c_void);
            return 0 as *mut matrix_t;
        }
        i += 1;
    }
    return mat;
}
#[no_mangle]
pub unsafe extern "C" fn free_matrix(mut mat: *mut matrix_t) {
    if mat.is_null() {
        return;
    }
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*mat).height {
        free(*(*mat).matrix.offset(i as isize) as *mut ::core::ffi::c_void);
        i += 1;
    }
    free((*mat).matrix as *mut ::core::ffi::c_void);
    free(mat as *mut ::core::ffi::c_void);
}
#[no_mangle]
pub unsafe extern "C" fn initialize_matrix_from_string(
    mut input: *const ::core::ffi::c_char,
    mut width: ::core::ffi::c_int,
    mut height: ::core::ffi::c_int,
) -> *mut matrix_t {
    let mut mat: *mut matrix_t = allocate_matrix(width, height);
    let mut input_copy: *mut ::core::ffi::c_char = strdup(input);
    if input_copy.is_null() {
        perror(
            b"Failed to duplicate input string\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        free_matrix(mat);
        return 0 as *mut matrix_t;
    }
    let mut saveptr_row: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
    let mut row_token: *mut ::core::ffi::c_char = strtok_r(
        input_copy,
        b"\n\0" as *const u8 as *const ::core::ffi::c_char,
        &mut saveptr_row,
    );
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < height {
        if row_token.is_null() {
            fprintf(
                __stderrp,
                b"Insufficient rows in input string.\n\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
            free(input_copy as *mut ::core::ffi::c_void);
            free_matrix(mat);
            return 0 as *mut matrix_t;
        }
        let mut saveptr_col: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
        let mut col_token: *mut ::core::ffi::c_char = strtok_r(
            row_token,
            b" \0" as *const u8 as *const ::core::ffi::c_char,
            &mut saveptr_col,
        );
        let mut j: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while j < width {
            if col_token.is_null() {
                fprintf(
                    __stderrp,
                    b"Insufficient columns in row %d.\n\0" as *const u8
                        as *const ::core::ffi::c_char,
                    i + 1 as ::core::ffi::c_int,
                );
                free(input_copy as *mut ::core::ffi::c_void);
                free_matrix(mat);
                return 0 as *mut matrix_t;
            }
            *(*(*mat).matrix.offset(i as isize)).offset(j as isize) = atoi(col_token);
            col_token = strtok_r(
                0 as *mut ::core::ffi::c_char,
                b" \0" as *const u8 as *const ::core::ffi::c_char,
                &mut saveptr_col,
            );
            j += 1;
        }
        row_token = strtok_r(
            0 as *mut ::core::ffi::c_char,
            b"\n\0" as *const u8 as *const ::core::ffi::c_char,
            &mut saveptr_row,
        );
        i += 1;
    }
    free(input_copy as *mut ::core::ffi::c_void);
    return mat;
}
#[no_mangle]
pub unsafe extern "C" fn multiply_matrices(
    mut mat_a: *mut matrix_t,
    mut mat_b: *mut matrix_t,
) -> *mut matrix_t {
    if (*mat_a).width != (*mat_b).height {
        fprintf(
            __stderrp,
            b"Matrix dimensions do not allow multiplication.\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 0 as *mut matrix_t;
    }
    let mut result: *mut matrix_t = allocate_matrix((*mat_b).width, (*mat_a).height);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*mat_a).height {
        let mut j: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while j < (*mat_b).width {
            *(*(*result).matrix.offset(i as isize)).offset(j as isize) = 0
                as ::core::ffi::c_int;
            let mut k: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
            while k < (*mat_a).width {
                *(*(*result).matrix.offset(i as isize)).offset(j as isize)
                    += *(*(*mat_a).matrix.offset(i as isize)).offset(k as isize)
                        * *(*(*mat_b).matrix.offset(k as isize)).offset(j as isize);
                k += 1;
            }
            j += 1;
        }
        i += 1;
    }
    return result;
}
#[no_mangle]
pub unsafe extern "C" fn matrix_to_string(
    mut mat: *mut matrix_t,
) -> *mut ::core::ffi::c_char {
    if mat.is_null() {
        fprintf(
            __stderrp,
            b"Error: Matrix is NULL.\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 0 as *mut ::core::ffi::c_char;
    }
    let mut buffer_size: ::core::ffi::c_int = (*mat).height
        * ((*mat).width * 10 as ::core::ffi::c_int + (*mat).width) + (*mat).height
        + 1 as ::core::ffi::c_int;
    let mut result: *mut ::core::ffi::c_char = malloc(buffer_size as size_t)
        as *mut ::core::ffi::c_char;
    if result.is_null() {
        perror(
            b"Failed to allocate memory for matrix string\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 0 as *mut ::core::ffi::c_char;
    }
    *result.offset(0 as ::core::ffi::c_int as isize) = '\0' as i32
        as ::core::ffi::c_char;
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*mat).height {
        let mut j: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while j < (*mat).width {
            let mut buffer: [::core::ffi::c_char; 12] = [0; 12];
            snprintf(
                buffer.as_mut_ptr(),
                ::core::mem::size_of::<[::core::ffi::c_char; 12]>() as size_t,
                b"%d\0" as *const u8 as *const ::core::ffi::c_char,
                *(*(*mat).matrix.offset(i as isize)).offset(j as isize),
            );
            strcat(result, buffer.as_mut_ptr());
            if j < (*mat).width - 1 as ::core::ffi::c_int {
                strcat(result, b" \0" as *const u8 as *const ::core::ffi::c_char);
            }
            j += 1;
        }
        strcat(result, b"\n\0" as *const u8 as *const ::core::ffi::c_char);
        i += 1;
    }
    return result;
}
