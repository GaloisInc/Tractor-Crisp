#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn __error() -> *mut ::core::ffi::c_int;
    fn strerror(__errnum: ::core::ffi::c_int) -> *mut ::core::ffi::c_char;
}
pub type __int64_t = i64;
pub type __darwin_off_t = __int64_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const EINVAL: ::core::ffi::c_int = 22 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn write_to_file(
    mut filename: *const ::core::ffi::c_char,
    mut content: *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    if content.is_null() {
        fprintf(
            __stderrp,
            b"Error: Content is NULL.\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return EINVAL;
    }
    let mut file: *mut FILE = fopen(
        filename,
        b"w\0" as *const u8 as *const ::core::ffi::c_char,
    ) as *mut FILE;
    if file.is_null() {
        fprintf(
            __stderrp,
            b"Error opening file '%s': %s\n\0" as *const u8
                as *const ::core::ffi::c_char,
            filename,
            strerror(*__error()),
        );
        return *__error();
    }
    if fprintf(file, b"%s\0" as *const u8 as *const ::core::ffi::c_char, content)
        < 0 as ::core::ffi::c_int
    {
        fprintf(
            __stderrp,
            b"Error writing to file '%s': %s\n\0" as *const u8
                as *const ::core::ffi::c_char,
            filename,
            strerror(*__error()),
        );
        fclose(file);
        return *__error();
    }
    if fclose(file) != 0 as ::core::ffi::c_int {
        fprintf(
            __stderrp,
            b"Error closing file '%s': %s\n\0" as *const u8
                as *const ::core::ffi::c_char,
            filename,
            strerror(*__error()),
        );
        return *__error();
    }
    return 0 as ::core::ffi::c_int;
}
