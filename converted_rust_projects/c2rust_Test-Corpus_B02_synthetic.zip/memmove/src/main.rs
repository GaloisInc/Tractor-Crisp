#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn scanf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn process_buffer(
        buffer: *mut uint8_t,
        length: size_t,
        flags: uint32_t,
        param1: ::core::ffi::c_int,
        param2: ::core::ffi::c_int,
    ) -> size_t;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type uint8_t = u8;
pub type uint32_t = u32;
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut flags: uint32_t = 0;
    let mut param1: ::core::ffi::c_int = 0;
    let mut param2: ::core::ffi::c_int = 0;
    let mut length: size_t = 0;
    let mut buffer: [uint8_t; 256] = [0; 256];
    if scanf(
        b"%u\0" as *const u8 as *const ::core::ffi::c_char,
        &mut flags as *mut uint32_t,
    ) != 1 as ::core::ffi::c_int
    {
        fprintf(
            __stderrp,
            b"Error reading flags\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    if scanf(
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut param1 as *mut ::core::ffi::c_int,
    ) != 1 as ::core::ffi::c_int
    {
        fprintf(
            __stderrp,
            b"Error reading param1\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    if scanf(
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut param2 as *mut ::core::ffi::c_int,
    ) != 1 as ::core::ffi::c_int
    {
        fprintf(
            __stderrp,
            b"Error reading param2\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    if scanf(
        b"%zu\0" as *const u8 as *const ::core::ffi::c_char,
        &mut length as *mut size_t,
    ) != 1 as ::core::ffi::c_int
    {
        fprintf(
            __stderrp,
            b"Error reading length\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    if length > 256 as size_t {
        fprintf(
            __stderrp,
            b"Error: length %zu exceeds maximum 256\n\0" as *const u8
                as *const ::core::ffi::c_char,
            length,
        );
        return 1 as ::core::ffi::c_int;
    }
    let mut i: size_t = 0 as size_t;
    while i < length {
        let mut byte: ::core::ffi::c_uint = 0;
        if scanf(
            b"%u\0" as *const u8 as *const ::core::ffi::c_char,
            &mut byte as *mut ::core::ffi::c_uint,
        ) != 1 as ::core::ffi::c_int
        {
            fprintf(
                __stderrp,
                b"Error reading byte %zu\n\0" as *const u8 as *const ::core::ffi::c_char,
                i,
            );
            return 1 as ::core::ffi::c_int;
        }
        buffer[i as usize] = byte as uint8_t;
        i = i.wrapping_add(1);
    }
    let mut new_length: size_t = process_buffer(
        buffer.as_mut_ptr(),
        length,
        flags,
        param1,
        param2,
    );
    printf(b"%zu\0" as *const u8 as *const ::core::ffi::c_char, new_length);
    let mut i_0: size_t = 0 as size_t;
    while i_0 < new_length {
        printf(
            b" %u\0" as *const u8 as *const ::core::ffi::c_char,
            buffer[i_0 as usize] as ::core::ffi::c_int,
        );
        i_0 = i_0.wrapping_add(1);
    }
    printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
