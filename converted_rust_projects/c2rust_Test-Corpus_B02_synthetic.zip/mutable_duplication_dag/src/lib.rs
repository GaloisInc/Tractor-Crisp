#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strncpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> *mut ::core::ffi::c_char;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct node_t {
    pub city_name: [::core::ffi::c_char; 64],
    pub ref_count: ::core::ffi::c_int,
    pub edges: [edge_t; 10],
    pub edge_count: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct edge_t {
    pub destination: *mut node_t,
    pub distance: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct graph_t {
    pub nodes: [*mut node_t; 100],
    pub node_count: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct dijkstra_node_t {
    pub node: *mut node_t,
    pub distance: ::core::ffi::c_int,
    pub previous: *mut node_t,
    pub visited: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const INT_MAX: ::core::ffi::c_int = 2147483647 as ::core::ffi::c_int;
pub const MAX_CITY_NAME: ::core::ffi::c_int = 64 as ::core::ffi::c_int;
pub const MAX_EDGES: ::core::ffi::c_int = 10 as ::core::ffi::c_int;
pub const MAX_NODES: ::core::ffi::c_int = 100 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn create_graph() -> *mut graph_t {
    let mut graph: *mut graph_t = malloc(::core::mem::size_of::<graph_t>() as size_t)
        as *mut graph_t;
    if graph.is_null() {
        fprintf(
            __stderrp,
            b"Error: Failed to allocate graph\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 0 as *mut graph_t;
    }
    (*graph).node_count = 0 as ::core::ffi::c_int;
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < MAX_NODES {
        (*graph).nodes[i as usize] = 0 as *mut node_t;
        i += 1;
    }
    return graph;
}
#[no_mangle]
pub unsafe extern "C" fn add_node(
    mut graph: *mut graph_t,
    mut city_name: *const ::core::ffi::c_char,
) -> *mut node_t {
    if graph.is_null() || city_name.is_null() {
        fprintf(
            __stderrp,
            b"Error: NULL parameter in add_node\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 0 as *mut node_t;
    }
    if (*graph).node_count >= MAX_NODES {
        fprintf(
            __stderrp,
            b"Error: Graph is full (max %d nodes)\n\0" as *const u8
                as *const ::core::ffi::c_char,
            MAX_NODES,
        );
        return 0 as *mut node_t;
    }
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*graph).node_count {
        if strcmp(
            (**(*graph).nodes.as_mut_ptr().offset(i as isize)).city_name.as_mut_ptr(),
            city_name,
        ) == 0 as ::core::ffi::c_int
        {
            fprintf(
                __stderrp,
                b"Error: Node '%s' already exists\n\0" as *const u8
                    as *const ::core::ffi::c_char,
                city_name,
            );
            return 0 as *mut node_t;
        }
        i += 1;
    }
    let mut node: *mut node_t = malloc(::core::mem::size_of::<node_t>() as size_t)
        as *mut node_t;
    if node.is_null() {
        fprintf(
            __stderrp,
            b"Error: Failed to allocate node\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 0 as *mut node_t;
    }
    strncpy(
        (*node).city_name.as_mut_ptr(),
        city_name,
        (MAX_CITY_NAME - 1 as ::core::ffi::c_int) as size_t,
    );
    (*node).city_name[(MAX_CITY_NAME - 1 as ::core::ffi::c_int) as usize] = '\0' as i32
        as ::core::ffi::c_char;
    (*node).ref_count = 1 as ::core::ffi::c_int;
    (*node).edge_count = 0 as ::core::ffi::c_int;
    let fresh0 = (*graph).node_count;
    (*graph).node_count = (*graph).node_count + 1;
    (*graph).nodes[fresh0 as usize] = node;
    return node;
}
#[no_mangle]
pub unsafe extern "C" fn add_edge(
    mut from: *mut node_t,
    mut to: *mut node_t,
    mut distance: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    if from.is_null() || to.is_null() {
        fprintf(
            __stderrp,
            b"Error: NULL node in add_edge\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return -(1 as ::core::ffi::c_int);
    }
    if (*from).edge_count >= MAX_EDGES {
        fprintf(
            __stderrp,
            b"Error: Node '%s' has maximum edges\n\0" as *const u8
                as *const ::core::ffi::c_char,
            (*from).city_name.as_mut_ptr(),
        );
        return -(1 as ::core::ffi::c_int);
    }
    if distance < 0 as ::core::ffi::c_int {
        fprintf(
            __stderrp,
            b"Error: Negative distance not allowed\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return -(1 as ::core::ffi::c_int);
    }
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*from).edge_count {
        if (*from).edges[i as usize].destination == to {
            fprintf(
                __stderrp,
                b"Error: Edge already exists\n\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
            return -(1 as ::core::ffi::c_int);
        }
        i += 1;
    }
    (*from).edges[(*from).edge_count as usize].destination = to;
    (*from).edges[(*from).edge_count as usize].distance = distance;
    (*from).edge_count += 1;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn delete_node(mut node: *mut node_t) {
    if node.is_null() {
        return;
    }
    (*node).ref_count -= 1;
    if (*node).ref_count == 0 as ::core::ffi::c_int {
        free(node as *mut ::core::ffi::c_void);
    }
}
unsafe extern "C" fn increment_refs_recursive(
    mut node: *mut node_t,
    mut visited: *mut *mut node_t,
    mut visited_count: *mut ::core::ffi::c_int,
) {
    if node.is_null() {
        return;
    }
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < *visited_count {
        if *visited.offset(i as isize) == node {
            return;
        }
        i += 1;
    }
    if *visited_count < MAX_NODES {
        let fresh1 = *visited_count;
        *visited_count = *visited_count + 1;
        let ref mut fresh2 = *visited.offset(fresh1 as isize);
        *fresh2 = node;
    }
    (*node).ref_count += 1;
    let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_0 < (*node).edge_count {
        increment_refs_recursive(
            (*node).edges[i_0 as usize].destination,
            visited,
            visited_count,
        );
        i_0 += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn shallow_copy(mut start: *mut node_t) -> *mut node_t {
    if start.is_null() {
        fprintf(
            __stderrp,
            b"Error: NULL node in shallow_copy\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 0 as *mut node_t;
    }
    let mut visited: [*mut node_t; 100] = [0 as *mut node_t; 100];
    let mut visited_count: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    increment_refs_recursive(start, visited.as_mut_ptr(), &mut visited_count);
    return start;
}
#[no_mangle]
pub unsafe extern "C" fn find_shortest_path(
    mut start: *mut node_t,
    mut end: *mut node_t,
    mut path_length: *mut ::core::ffi::c_int,
) -> *mut *mut node_t {
    if start.is_null() || end.is_null() || path_length.is_null() {
        fprintf(
            __stderrp,
            b"Error: NULL parameter in find_shortest_path\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 0 as *mut *mut node_t;
    }
    let mut state: [dijkstra_node_t; 100] = [dijkstra_node_t {
        node: 0 as *mut node_t,
        distance: 0,
        previous: 0 as *mut node_t,
        visited: 0,
    }; 100];
    let mut state_count: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    state[state_count as usize].node = start;
    state[state_count as usize].distance = 0 as ::core::ffi::c_int;
    state[state_count as usize].previous = 0 as *mut node_t;
    state[state_count as usize].visited = 0 as ::core::ffi::c_int;
    state_count += 1;
    let mut current: *mut node_t = start;
    while !current.is_null() {
        let mut current_idx: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
        let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while i < state_count {
            if state[i as usize].node == current {
                current_idx = i;
                break;
            } else {
                i += 1;
            }
        }
        if current_idx == -(1 as ::core::ffi::c_int) {
            break;
        }
        state[current_idx as usize].visited = 1 as ::core::ffi::c_int;
        if current == end {
            break;
        }
        let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while i_0 < (*current).edge_count {
            let mut neighbor: *mut node_t = (*current).edges[i_0 as usize].destination;
            let mut new_distance: ::core::ffi::c_int = state[current_idx as usize]
                .distance + (*current).edges[i_0 as usize].distance;
            let mut neighbor_idx: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
            let mut j: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
            while j < state_count {
                if state[j as usize].node == neighbor {
                    neighbor_idx = j;
                    break;
                } else {
                    j += 1;
                }
            }
            if neighbor_idx == -(1 as ::core::ffi::c_int) && state_count < MAX_NODES {
                neighbor_idx = state_count;
                state[state_count as usize].node = neighbor;
                state[state_count as usize].distance = INT_MAX;
                state[state_count as usize].previous = 0 as *mut node_t;
                state[state_count as usize].visited = 0 as ::core::ffi::c_int;
                state_count += 1;
            }
            if neighbor_idx != -(1 as ::core::ffi::c_int)
                && new_distance < state[neighbor_idx as usize].distance
            {
                state[neighbor_idx as usize].distance = new_distance;
                state[neighbor_idx as usize].previous = current;
            }
            i_0 += 1;
        }
        let mut min_distance: ::core::ffi::c_int = INT_MAX;
        current = 0 as *mut node_t;
        let mut i_1: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while i_1 < state_count {
            if state[i_1 as usize].visited == 0
                && state[i_1 as usize].distance < min_distance
            {
                min_distance = state[i_1 as usize].distance;
                current = state[i_1 as usize].node;
            }
            i_1 += 1;
        }
    }
    let mut end_idx: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
    let mut i_2: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_2 < state_count {
        if state[i_2 as usize].node == end {
            end_idx = i_2;
            break;
        } else {
            i_2 += 1;
        }
    }
    if end_idx == -(1 as ::core::ffi::c_int)
        || state[end_idx as usize].distance == INT_MAX
    {
        fprintf(
            __stderrp,
            b"No path found\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        *path_length = 0 as ::core::ffi::c_int;
        return 0 as *mut *mut node_t;
    }
    let mut path: [*mut node_t; 100] = [0 as *mut node_t; 100];
    let mut count: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut current_node: *mut node_t = end;
    while !current_node.is_null() {
        let fresh3 = count;
        count = count + 1;
        path[fresh3 as usize] = current_node;
        let mut current_state_idx: ::core::ffi::c_int = -(1 as ::core::ffi::c_int);
        let mut i_3: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while i_3 < state_count {
            if state[i_3 as usize].node == current_node {
                current_state_idx = i_3;
                break;
            } else {
                i_3 += 1;
            }
        }
        if current_state_idx == -(1 as ::core::ffi::c_int) {
            break;
        }
        current_node = state[current_state_idx as usize].previous;
    }
    let mut result: *mut *mut node_t = malloc(
        (::core::mem::size_of::<*mut node_t>() as size_t).wrapping_mul(count as size_t),
    ) as *mut *mut node_t;
    if result.is_null() {
        fprintf(
            __stderrp,
            b"Error: Failed to allocate path\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        *path_length = 0 as ::core::ffi::c_int;
        return 0 as *mut *mut node_t;
    }
    let mut i_4: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_4 < count {
        let ref mut fresh4 = *result.offset(i_4 as isize);
        *fresh4 = path[(count - 1 as ::core::ffi::c_int - i_4) as usize];
        i_4 += 1;
    }
    *path_length = count;
    return result;
}
#[no_mangle]
pub unsafe extern "C" fn get_node_by_name(
    mut graph: *mut graph_t,
    mut city_name: *const ::core::ffi::c_char,
) -> *mut node_t {
    if graph.is_null() || city_name.is_null() {
        return 0 as *mut node_t;
    }
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*graph).node_count {
        if strcmp(
            (**(*graph).nodes.as_mut_ptr().offset(i as isize)).city_name.as_mut_ptr(),
            city_name,
        ) == 0 as ::core::ffi::c_int
        {
            return (*graph).nodes[i as usize];
        }
        i += 1;
    }
    return 0 as *mut node_t;
}
#[no_mangle]
pub unsafe extern "C" fn print_node(mut node: *mut node_t) {
    if node.is_null() {
        printf(b"NULL node\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    printf(
        b"City: %s (ref_count: %d)\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*node).city_name.as_mut_ptr(),
        (*node).ref_count,
    );
    printf(b"  Edges:\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*node).edge_count {
        printf(
            b"    -> %s (distance: %d)\n\0" as *const u8 as *const ::core::ffi::c_char,
            (*(*(*node).edges.as_mut_ptr().offset(i as isize)).destination)
                .city_name
                .as_mut_ptr(),
            (*node).edges[i as usize].distance,
        );
        i += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn print_graph(mut graph: *mut graph_t) {
    if graph.is_null() {
        printf(b"NULL graph\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    printf(
        b"Graph with %d nodes:\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*graph).node_count,
    );
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*graph).node_count {
        print_node((*graph).nodes[i as usize]);
        i += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn free_graph(mut graph: *mut graph_t) {
    if graph.is_null() {
        return;
    }
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*graph).node_count {
        delete_node((*graph).nodes[i as usize]);
        i += 1;
    }
    free(graph as *mut ::core::ffi::c_void);
}
