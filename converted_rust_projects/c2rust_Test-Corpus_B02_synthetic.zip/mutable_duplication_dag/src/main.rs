#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stdinp: *mut FILE;
    static mut __stderrp: *mut FILE;
    fn fgets(
        _: *mut ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *mut FILE,
    ) -> *mut ::core::ffi::c_char;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn sscanf(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn free(_: *mut ::core::ffi::c_void);
    fn strcspn(
        __s: *const ::core::ffi::c_char,
        __charset: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_ulong;
    fn create_graph() -> *mut graph_t;
    fn add_node(
        graph: *mut graph_t,
        city_name: *const ::core::ffi::c_char,
    ) -> *mut node_t;
    fn add_edge(
        from: *mut node_t,
        to: *mut node_t,
        distance: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn delete_node(node: *mut node_t);
    fn shallow_copy(start: *mut node_t) -> *mut node_t;
    fn find_shortest_path(
        start: *mut node_t,
        end: *mut node_t,
        path_length: *mut ::core::ffi::c_int,
    ) -> *mut *mut node_t;
    fn free_graph(graph: *mut graph_t);
    fn get_node_by_name(
        graph: *mut graph_t,
        city_name: *const ::core::ffi::c_char,
    ) -> *mut node_t;
    fn print_node(node: *mut node_t);
    fn print_graph(graph: *mut graph_t);
}
pub type __int64_t = i64;
pub type __darwin_off_t = __int64_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct node_t {
    pub city_name: [::core::ffi::c_char; 64],
    pub ref_count: ::core::ffi::c_int,
    pub edges: [edge_t; 10],
    pub edge_count: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct edge_t {
    pub destination: *mut node_t,
    pub distance: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct graph_t {
    pub nodes: [*mut node_t; 100],
    pub node_count: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const MAX_INPUT: ::core::ffi::c_int = 256 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn print_menu() {
    printf(
        b"\n=== DAG City Route Manager ===\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    printf(b"1. Add city (node)\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"2. Add route (edge)\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"3. Show all cities\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"4. Show city details\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"5. Find shortest path\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(
        b"6. Make shallow copy of subsection\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    printf(b"7. Delete node\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"8. Exit\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"Choice: \0" as *const u8 as *const ::core::ffi::c_char);
}
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut graph: *mut graph_t = create_graph();
    if graph.is_null() {
        fprintf(
            __stderrp,
            b"Failed to create graph\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    let mut input: [::core::ffi::c_char; 256] = [0; 256];
    let mut choice: ::core::ffi::c_int = 0;
    printf(
        b"City Route Management System\n\0" as *const u8 as *const ::core::ffi::c_char,
    );
    printf(
        b"Commands are read from stdin\n\0" as *const u8 as *const ::core::ffi::c_char,
    );
    loop {
        print_menu();
        if fgets(input.as_mut_ptr(), MAX_INPUT, __stdinp).is_null() {
            break;
        }
        if sscanf(
            input.as_mut_ptr(),
            b"%d\0" as *const u8 as *const ::core::ffi::c_char,
            &mut choice as *mut ::core::ffi::c_int,
        ) != 1 as ::core::ffi::c_int
        {
            printf(b"Invalid input\n\0" as *const u8 as *const ::core::ffi::c_char);
        } else {
            match choice {
                1 => {
                    printf(
                        b"Enter city name: \0" as *const u8 as *const ::core::ffi::c_char,
                    );
                    if !fgets(input.as_mut_ptr(), MAX_INPUT, __stdinp).is_null() {
                        input[strcspn(
                            input.as_mut_ptr(),
                            b"\n\0" as *const u8 as *const ::core::ffi::c_char,
                        ) as usize] = 0 as ::core::ffi::c_char;
                        let mut node: *mut node_t = add_node(graph, input.as_mut_ptr());
                        if !node.is_null() {
                            printf(
                                b"Added city: %s\n\0" as *const u8
                                    as *const ::core::ffi::c_char,
                                input.as_mut_ptr(),
                            );
                        } else {
                            printf(
                                b"Failed to add city\n\0" as *const u8
                                    as *const ::core::ffi::c_char,
                            );
                        }
                    }
                }
                2 => {
                    let mut from_city: [::core::ffi::c_char; 256] = [0; 256];
                    let mut to_city: [::core::ffi::c_char; 256] = [0; 256];
                    let mut distance: ::core::ffi::c_int = 0;
                    printf(
                        b"Enter from city: \0" as *const u8 as *const ::core::ffi::c_char,
                    );
                    if !fgets(from_city.as_mut_ptr(), MAX_INPUT, __stdinp).is_null() {
                        from_city[strcspn(
                            from_city.as_mut_ptr(),
                            b"\n\0" as *const u8 as *const ::core::ffi::c_char,
                        ) as usize] = 0 as ::core::ffi::c_char;
                        printf(
                            b"Enter to city: \0" as *const u8
                                as *const ::core::ffi::c_char,
                        );
                        if !fgets(to_city.as_mut_ptr(), MAX_INPUT, __stdinp).is_null() {
                            to_city[strcspn(
                                to_city.as_mut_ptr(),
                                b"\n\0" as *const u8 as *const ::core::ffi::c_char,
                            ) as usize] = 0 as ::core::ffi::c_char;
                            printf(
                                b"Enter distance: \0" as *const u8
                                    as *const ::core::ffi::c_char,
                            );
                            if !fgets(input.as_mut_ptr(), MAX_INPUT, __stdinp).is_null()
                            {
                                if sscanf(
                                    input.as_mut_ptr(),
                                    b"%d\0" as *const u8 as *const ::core::ffi::c_char,
                                    &mut distance as *mut ::core::ffi::c_int,
                                ) != 1 as ::core::ffi::c_int
                                {
                                    printf(
                                        b"Invalid distance\n\0" as *const u8
                                            as *const ::core::ffi::c_char,
                                    );
                                } else {
                                    let mut from: *mut node_t = get_node_by_name(
                                        graph,
                                        from_city.as_mut_ptr(),
                                    );
                                    let mut to: *mut node_t = get_node_by_name(
                                        graph,
                                        to_city.as_mut_ptr(),
                                    );
                                    if from.is_null() {
                                        printf(
                                            b"City '%s' not found\n\0" as *const u8
                                                as *const ::core::ffi::c_char,
                                            from_city.as_mut_ptr(),
                                        );
                                    } else if to.is_null() {
                                        printf(
                                            b"City '%s' not found\n\0" as *const u8
                                                as *const ::core::ffi::c_char,
                                            to_city.as_mut_ptr(),
                                        );
                                    } else if add_edge(from, to, distance)
                                        == 0 as ::core::ffi::c_int
                                    {
                                        printf(
                                            b"Added route: %s -> %s (distance: %d)\n\0" as *const u8
                                                as *const ::core::ffi::c_char,
                                            from_city.as_mut_ptr(),
                                            to_city.as_mut_ptr(),
                                            distance,
                                        );
                                    } else {
                                        printf(
                                            b"Failed to add route\n\0" as *const u8
                                                as *const ::core::ffi::c_char,
                                        );
                                    }
                                }
                            }
                        }
                    }
                }
                3 => {
                    print_graph(graph);
                }
                4 => {
                    printf(
                        b"Enter city name: \0" as *const u8 as *const ::core::ffi::c_char,
                    );
                    if !fgets(input.as_mut_ptr(), MAX_INPUT, __stdinp).is_null() {
                        input[strcspn(
                            input.as_mut_ptr(),
                            b"\n\0" as *const u8 as *const ::core::ffi::c_char,
                        ) as usize] = 0 as ::core::ffi::c_char;
                        let mut node_0: *mut node_t = get_node_by_name(
                            graph,
                            input.as_mut_ptr(),
                        );
                        if !node_0.is_null() {
                            print_node(node_0);
                        } else {
                            printf(
                                b"City '%s' not found\n\0" as *const u8
                                    as *const ::core::ffi::c_char,
                                input.as_mut_ptr(),
                            );
                        }
                    }
                }
                5 => {
                    let mut start_city: [::core::ffi::c_char; 256] = [0; 256];
                    let mut end_city: [::core::ffi::c_char; 256] = [0; 256];
                    printf(
                        b"Enter start city: \0" as *const u8
                            as *const ::core::ffi::c_char,
                    );
                    if !fgets(start_city.as_mut_ptr(), MAX_INPUT, __stdinp).is_null() {
                        start_city[strcspn(
                            start_city.as_mut_ptr(),
                            b"\n\0" as *const u8 as *const ::core::ffi::c_char,
                        ) as usize] = 0 as ::core::ffi::c_char;
                        printf(
                            b"Enter end city: \0" as *const u8
                                as *const ::core::ffi::c_char,
                        );
                        if !fgets(end_city.as_mut_ptr(), MAX_INPUT, __stdinp).is_null() {
                            end_city[strcspn(
                                end_city.as_mut_ptr(),
                                b"\n\0" as *const u8 as *const ::core::ffi::c_char,
                            ) as usize] = 0 as ::core::ffi::c_char;
                            let mut start: *mut node_t = get_node_by_name(
                                graph,
                                start_city.as_mut_ptr(),
                            );
                            let mut end: *mut node_t = get_node_by_name(
                                graph,
                                end_city.as_mut_ptr(),
                            );
                            if start.is_null() {
                                printf(
                                    b"City '%s' not found\n\0" as *const u8
                                        as *const ::core::ffi::c_char,
                                    start_city.as_mut_ptr(),
                                );
                            } else if end.is_null() {
                                printf(
                                    b"City '%s' not found\n\0" as *const u8
                                        as *const ::core::ffi::c_char,
                                    end_city.as_mut_ptr(),
                                );
                            } else {
                                let mut path_length: ::core::ffi::c_int = 0;
                                let mut path: *mut *mut node_t = find_shortest_path(
                                    start,
                                    end,
                                    &mut path_length,
                                );
                                if !path.is_null() {
                                    printf(
                                        b"Shortest path from %s to %s:\n\0" as *const u8
                                            as *const ::core::ffi::c_char,
                                        start_city.as_mut_ptr(),
                                        end_city.as_mut_ptr(),
                                    );
                                    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                                    while i < path_length {
                                        printf(
                                            b"  %d. %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                                            i + 1 as ::core::ffi::c_int,
                                            (**path.offset(i as isize)).city_name.as_mut_ptr(),
                                        );
                                        i += 1;
                                    }
                                    free(path as *mut ::core::ffi::c_void);
                                } else {
                                    printf(
                                        b"No path found\n\0" as *const u8
                                            as *const ::core::ffi::c_char,
                                    );
                                }
                            }
                        }
                    }
                }
                6 => {
                    printf(
                        b"Enter start city for shallow copy: \0" as *const u8
                            as *const ::core::ffi::c_char,
                    );
                    if !fgets(input.as_mut_ptr(), MAX_INPUT, __stdinp).is_null() {
                        input[strcspn(
                            input.as_mut_ptr(),
                            b"\n\0" as *const u8 as *const ::core::ffi::c_char,
                        ) as usize] = 0 as ::core::ffi::c_char;
                        let mut node_1: *mut node_t = get_node_by_name(
                            graph,
                            input.as_mut_ptr(),
                        );
                        if node_1.is_null() {
                            printf(
                                b"City '%s' not found\n\0" as *const u8
                                    as *const ::core::ffi::c_char,
                                input.as_mut_ptr(),
                            );
                        } else {
                            let mut copy: *mut node_t = shallow_copy(node_1);
                            if !copy.is_null() {
                                printf(
                                    b"Created shallow copy starting from %s\n\0" as *const u8
                                        as *const ::core::ffi::c_char,
                                    input.as_mut_ptr(),
                                );
                                printf(
                                    b"Reference counts incremented for all reachable nodes\n\0"
                                        as *const u8 as *const ::core::ffi::c_char,
                                );
                                print_node(copy);
                            } else {
                                printf(
                                    b"Failed to create shallow copy\n\0" as *const u8
                                        as *const ::core::ffi::c_char,
                                );
                            }
                        }
                    }
                }
                7 => {
                    printf(
                        b"Enter city name to delete: \0" as *const u8
                            as *const ::core::ffi::c_char,
                    );
                    if !fgets(input.as_mut_ptr(), MAX_INPUT, __stdinp).is_null() {
                        input[strcspn(
                            input.as_mut_ptr(),
                            b"\n\0" as *const u8 as *const ::core::ffi::c_char,
                        ) as usize] = 0 as ::core::ffi::c_char;
                        let mut node_2: *mut node_t = get_node_by_name(
                            graph,
                            input.as_mut_ptr(),
                        );
                        if node_2.is_null() {
                            printf(
                                b"City '%s' not found\n\0" as *const u8
                                    as *const ::core::ffi::c_char,
                                input.as_mut_ptr(),
                            );
                        } else {
                            printf(
                                b"Current ref count: %d\n\0" as *const u8
                                    as *const ::core::ffi::c_char,
                                (*node_2).ref_count,
                            );
                            delete_node(node_2);
                            printf(
                                b"Decremented reference count for %s\n\0" as *const u8
                                    as *const ::core::ffi::c_char,
                                input.as_mut_ptr(),
                            );
                            printf(
                                b"Note: Node will be freed when ref count reaches 0\n\0"
                                    as *const u8 as *const ::core::ffi::c_char,
                            );
                        }
                    }
                }
                8 => {
                    printf(
                        b"Freeing graph and exiting...\n\0" as *const u8
                            as *const ::core::ffi::c_char,
                    );
                    free_graph(graph);
                    return 0 as ::core::ffi::c_int;
                }
                _ => {
                    printf(
                        b"Invalid choice\n\0" as *const u8 as *const ::core::ffi::c_char,
                    );
                }
            }
        }
    }
    free_graph(graph);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
