#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stdinp: *mut FILE;
    fn fgets(
        _: *mut ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *mut FILE,
    ) -> *mut ::core::ffi::c_char;
    fn getchar() -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn scanf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn sscanf(
        _: *const ::core::ffi::c_char,
        _: *const ::core::ffi::c_char,
        ...
    ) -> ::core::ffi::c_int;
    fn strcspn(
        __s: *const ::core::ffi::c_char,
        __charset: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_ulong;
    fn shape_manager_init();
    fn shape_manager_cleanup();
    fn shape_get(type_0: shape_type_t) -> *mut shape_t;
    fn shape_print(shape: *const shape_t);
    fn shape_equals(s1: *const shape_t, s2: *const shape_t) -> ::core::ffi::c_int;
    fn shape_type_name(type_0: shape_type_t) -> *const ::core::ffi::c_char;
    fn scene_create(name: *const ::core::ffi::c_char) -> *mut scene_t;
    fn scene_destroy(scene: *mut scene_t);
    fn scene_add_shape(scene: *mut scene_t, shape: *mut shape_t) -> ::core::ffi::c_int;
    fn scene_remove_shape(
        scene: *mut scene_t,
        index: ::core::ffi::c_int,
    ) -> ::core::ffi::c_int;
    fn scene_print(scene: *const scene_t);
    fn scene_equals(s1: *const scene_t, s2: *const scene_t) -> ::core::ffi::c_int;
    fn scene_save(
        scene: *const scene_t,
        filename: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn scene_load(filename: *const ::core::ffi::c_char) -> *mut scene_t;
    fn scene_list_shapes(scene: *const scene_t);
}
pub type __int64_t = i64;
pub type __darwin_off_t = __int64_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type shape_type_t = ::core::ffi::c_uint;
pub const SHAPE_COUNT: shape_type_t = 10;
pub const SHAPE_RAINBOW: shape_type_t = 9;
pub const SHAPE_HEART: shape_type_t = 8;
pub const SHAPE_STAR: shape_type_t = 7;
pub const SHAPE_CAR: shape_type_t = 6;
pub const SHAPE_FLOWER: shape_type_t = 5;
pub const SHAPE_CLOUD: shape_type_t = 4;
pub const SHAPE_SUN: shape_type_t = 3;
pub const SHAPE_HOUSE: shape_type_t = 2;
pub const SHAPE_TRACTOR: shape_type_t = 1;
pub const SHAPE_TREE: shape_type_t = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct shape_t {
    pub type_0: shape_type_t,
    pub name: [::core::ffi::c_char; 32],
    pub art: [[::core::ffi::c_char; 80]; 30],
    pub width: ::core::ffi::c_int,
    pub height: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct scene_t {
    pub name: [::core::ffi::c_char; 64],
    pub shapes: [*mut shape_t; 50],
    pub shape_count: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const MAX_SCENE_NAME: ::core::ffi::c_int = 64 as ::core::ffi::c_int;
pub const MAX_SCENES: ::core::ffi::c_int = 10 as ::core::ffi::c_int;
static mut scenes: [*mut scene_t; 10] = [
    0 as *const scene_t as *mut scene_t,
    0 as *const scene_t as *mut scene_t,
    0 as *const scene_t as *mut scene_t,
    0 as *const scene_t as *mut scene_t,
    0 as *const scene_t as *mut scene_t,
    0 as *const scene_t as *mut scene_t,
    0 as *const scene_t as *mut scene_t,
    0 as *const scene_t as *mut scene_t,
    0 as *const scene_t as *mut scene_t,
    0 as *const scene_t as *mut scene_t,
];
static mut scene_count: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn print_menu() {
    printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(
        b"=========================================\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    printf(
        b"  ASCII ART DRAWING APPLICATION\n\0" as *const u8 as *const ::core::ffi::c_char,
    );
    printf(
        b"=========================================\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    printf(
        b"1. View all available shapes\n\0" as *const u8 as *const ::core::ffi::c_char,
    );
    printf(b"2. Create new scene\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"3. Add shape to scene\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"4. Remove shape from scene\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"5. View scene\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"6. List all scenes\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"7. Save scene\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"8. Load scene\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"9. Compare two shapes\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"10. Compare two scenes\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"11. Delete scene\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(b"12. Exit\n\0" as *const u8 as *const ::core::ffi::c_char);
    printf(
        b"=========================================\n\0" as *const u8
            as *const ::core::ffi::c_char,
    );
    printf(b"Choice: \0" as *const u8 as *const ::core::ffi::c_char);
}
#[no_mangle]
pub unsafe extern "C" fn view_all_shapes() {
    printf(b"\n=== Available Shapes ===\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < SHAPE_COUNT as ::core::ffi::c_int {
        printf(
            b"\n%d. \0" as *const u8 as *const ::core::ffi::c_char,
            i + 1 as ::core::ffi::c_int,
        );
        shape_print(shape_get(i as shape_type_t));
        i += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn create_new_scene() {
    if scene_count >= MAX_SCENES {
        printf(
            b"Error: Maximum scenes reached\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return;
    }
    let mut name: [::core::ffi::c_char; 64] = [0; 64];
    printf(b"Enter scene name: \0" as *const u8 as *const ::core::ffi::c_char);
    if fgets(name.as_mut_ptr(), MAX_SCENE_NAME, __stdinp).is_null() {
        return;
    }
    name[strcspn(name.as_mut_ptr(), b"\n\0" as *const u8 as *const ::core::ffi::c_char)
        as usize] = 0 as ::core::ffi::c_char;
    scenes[scene_count as usize] = scene_create(name.as_mut_ptr());
    if !scenes[scene_count as usize].is_null() {
        printf(
            b"Scene '%s' created (index %d)\n\0" as *const u8
                as *const ::core::ffi::c_char,
            name.as_mut_ptr(),
            scene_count,
        );
        scene_count += 1;
    } else {
        printf(b"Error creating scene\n\0" as *const u8 as *const ::core::ffi::c_char);
    };
}
#[no_mangle]
pub unsafe extern "C" fn add_shape_to_scene() {
    if scene_count == 0 as ::core::ffi::c_int {
        printf(
            b"No scenes available. Create a scene first.\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return;
    }
    printf(
        b"Select scene (0-%d): \0" as *const u8 as *const ::core::ffi::c_char,
        scene_count - 1 as ::core::ffi::c_int,
    );
    let mut scene_idx: ::core::ffi::c_int = 0;
    if scanf(
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut scene_idx as *mut ::core::ffi::c_int,
    ) != 1 as ::core::ffi::c_int
    {
        printf(b"Invalid input\n\0" as *const u8 as *const ::core::ffi::c_char);
        while getchar() != '\n' as i32 {}
        return;
    }
    while getchar() != '\n' as i32 {}
    if scene_idx < 0 as ::core::ffi::c_int || scene_idx >= scene_count {
        printf(b"Invalid scene index\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    printf(b"\nSelect shape to add:\n\0" as *const u8 as *const ::core::ffi::c_char);
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < SHAPE_COUNT as ::core::ffi::c_int {
        printf(
            b"%d. %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            i,
            shape_type_name(i as shape_type_t),
        );
        i += 1;
    }
    printf(b"Choice: \0" as *const u8 as *const ::core::ffi::c_char);
    let mut shape_type: ::core::ffi::c_int = 0;
    if scanf(
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut shape_type as *mut ::core::ffi::c_int,
    ) != 1 as ::core::ffi::c_int
    {
        printf(b"Invalid input\n\0" as *const u8 as *const ::core::ffi::c_char);
        while getchar() != '\n' as i32 {}
        return;
    }
    while getchar() != '\n' as i32 {}
    if shape_type < 0 as ::core::ffi::c_int
        || shape_type >= SHAPE_COUNT as ::core::ffi::c_int
    {
        printf(b"Invalid shape type\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    let mut shape: *mut shape_t = shape_get(shape_type as shape_type_t);
    if scene_add_shape(scenes[scene_idx as usize], shape) == 0 as ::core::ffi::c_int {
        printf(
            b"Shape '%s' added to scene (reusing singleton at %p)\n\0" as *const u8
                as *const ::core::ffi::c_char,
            (*shape).name.as_mut_ptr(),
            shape as *mut ::core::ffi::c_void,
        );
    } else {
        printf(b"Error adding shape\n\0" as *const u8 as *const ::core::ffi::c_char);
    };
}
#[no_mangle]
pub unsafe extern "C" fn remove_shape_from_scene() {
    if scene_count == 0 as ::core::ffi::c_int {
        printf(b"No scenes available\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    printf(
        b"Select scene (0-%d): \0" as *const u8 as *const ::core::ffi::c_char,
        scene_count - 1 as ::core::ffi::c_int,
    );
    let mut scene_idx: ::core::ffi::c_int = 0;
    if scanf(
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut scene_idx as *mut ::core::ffi::c_int,
    ) != 1 as ::core::ffi::c_int
    {
        printf(b"Invalid input\n\0" as *const u8 as *const ::core::ffi::c_char);
        while getchar() != '\n' as i32 {}
        return;
    }
    while getchar() != '\n' as i32 {}
    if scene_idx < 0 as ::core::ffi::c_int || scene_idx >= scene_count {
        printf(b"Invalid scene index\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    scene_list_shapes(scenes[scene_idx as usize]);
    if (*scenes[scene_idx as usize]).shape_count == 0 as ::core::ffi::c_int {
        printf(b"Scene is empty\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    printf(
        b"Select shape to remove (1-%d): \0" as *const u8 as *const ::core::ffi::c_char,
        (*scenes[scene_idx as usize]).shape_count,
    );
    let mut shape_idx: ::core::ffi::c_int = 0;
    if scanf(
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut shape_idx as *mut ::core::ffi::c_int,
    ) != 1 as ::core::ffi::c_int
    {
        printf(b"Invalid input\n\0" as *const u8 as *const ::core::ffi::c_char);
        while getchar() != '\n' as i32 {}
        return;
    }
    while getchar() != '\n' as i32 {}
    if scene_remove_shape(
        scenes[scene_idx as usize],
        shape_idx - 1 as ::core::ffi::c_int,
    ) == 0 as ::core::ffi::c_int
    {
        printf(b"Shape removed\n\0" as *const u8 as *const ::core::ffi::c_char);
    } else {
        printf(b"Error removing shape\n\0" as *const u8 as *const ::core::ffi::c_char);
    };
}
#[no_mangle]
pub unsafe extern "C" fn view_scene() {
    if scene_count == 0 as ::core::ffi::c_int {
        printf(b"No scenes available\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    printf(
        b"Select scene (0-%d): \0" as *const u8 as *const ::core::ffi::c_char,
        scene_count - 1 as ::core::ffi::c_int,
    );
    let mut scene_idx: ::core::ffi::c_int = 0;
    if scanf(
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut scene_idx as *mut ::core::ffi::c_int,
    ) != 1 as ::core::ffi::c_int
    {
        printf(b"Invalid input\n\0" as *const u8 as *const ::core::ffi::c_char);
        while getchar() != '\n' as i32 {}
        return;
    }
    while getchar() != '\n' as i32 {}
    if scene_idx < 0 as ::core::ffi::c_int || scene_idx >= scene_count {
        printf(b"Invalid scene index\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    scene_print(scenes[scene_idx as usize]);
}
#[no_mangle]
pub unsafe extern "C" fn list_all_scenes() {
    printf(b"\n=== All Scenes ===\n\0" as *const u8 as *const ::core::ffi::c_char);
    if scene_count == 0 as ::core::ffi::c_int {
        printf(b"No scenes created yet\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < scene_count {
        printf(
            b"%d. %s (%d shapes)\n\0" as *const u8 as *const ::core::ffi::c_char,
            i,
            (**scenes.as_mut_ptr().offset(i as isize)).name.as_mut_ptr(),
            (*scenes[i as usize]).shape_count,
        );
        i += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn save_scene_to_file() {
    if scene_count == 0 as ::core::ffi::c_int {
        printf(b"No scenes available\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    printf(
        b"Select scene (0-%d): \0" as *const u8 as *const ::core::ffi::c_char,
        scene_count - 1 as ::core::ffi::c_int,
    );
    let mut scene_idx: ::core::ffi::c_int = 0;
    if scanf(
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut scene_idx as *mut ::core::ffi::c_int,
    ) != 1 as ::core::ffi::c_int
    {
        printf(b"Invalid input\n\0" as *const u8 as *const ::core::ffi::c_char);
        while getchar() != '\n' as i32 {}
        return;
    }
    while getchar() != '\n' as i32 {}
    if scene_idx < 0 as ::core::ffi::c_int || scene_idx >= scene_count {
        printf(b"Invalid scene index\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    let mut filename: [::core::ffi::c_char; 256] = [0; 256];
    printf(b"Enter filename: \0" as *const u8 as *const ::core::ffi::c_char);
    if fgets(
            filename.as_mut_ptr(),
            ::core::mem::size_of::<[::core::ffi::c_char; 256]>() as ::core::ffi::c_int,
            __stdinp,
        )
        .is_null()
    {
        return;
    }
    filename[strcspn(
        filename.as_mut_ptr(),
        b"\n\0" as *const u8 as *const ::core::ffi::c_char,
    ) as usize] = 0 as ::core::ffi::c_char;
    scene_save(scenes[scene_idx as usize], filename.as_mut_ptr());
}
#[no_mangle]
pub unsafe extern "C" fn load_scene_from_file() {
    if scene_count >= MAX_SCENES {
        printf(
            b"Error: Maximum scenes reached\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return;
    }
    let mut filename: [::core::ffi::c_char; 256] = [0; 256];
    printf(b"Enter filename: \0" as *const u8 as *const ::core::ffi::c_char);
    if fgets(
            filename.as_mut_ptr(),
            ::core::mem::size_of::<[::core::ffi::c_char; 256]>() as ::core::ffi::c_int,
            __stdinp,
        )
        .is_null()
    {
        return;
    }
    filename[strcspn(
        filename.as_mut_ptr(),
        b"\n\0" as *const u8 as *const ::core::ffi::c_char,
    ) as usize] = 0 as ::core::ffi::c_char;
    let mut scene: *mut scene_t = scene_load(filename.as_mut_ptr());
    if !scene.is_null() {
        let fresh0 = scene_count;
        scene_count = scene_count + 1;
        scenes[fresh0 as usize] = scene;
        printf(
            b"Scene loaded (index %d)\n\0" as *const u8 as *const ::core::ffi::c_char,
            scene_count - 1 as ::core::ffi::c_int,
        );
    }
}
#[no_mangle]
pub unsafe extern "C" fn compare_shapes() {
    printf(
        b"\nSelect first shape (0-%d):\n\0" as *const u8 as *const ::core::ffi::c_char,
        SHAPE_COUNT as ::core::ffi::c_int - 1 as ::core::ffi::c_int,
    );
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < SHAPE_COUNT as ::core::ffi::c_int {
        printf(
            b"%d. %s\n\0" as *const u8 as *const ::core::ffi::c_char,
            i,
            shape_type_name(i as shape_type_t),
        );
        i += 1;
    }
    printf(b"Choice: \0" as *const u8 as *const ::core::ffi::c_char);
    let mut type1: ::core::ffi::c_int = 0;
    if scanf(
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut type1 as *mut ::core::ffi::c_int,
    ) != 1 as ::core::ffi::c_int
    {
        printf(b"Invalid input\n\0" as *const u8 as *const ::core::ffi::c_char);
        while getchar() != '\n' as i32 {}
        return;
    }
    while getchar() != '\n' as i32 {}
    printf(
        b"\nSelect second shape (0-%d): \0" as *const u8 as *const ::core::ffi::c_char,
        SHAPE_COUNT as ::core::ffi::c_int - 1 as ::core::ffi::c_int,
    );
    let mut type2: ::core::ffi::c_int = 0;
    if scanf(
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut type2 as *mut ::core::ffi::c_int,
    ) != 1 as ::core::ffi::c_int
    {
        printf(b"Invalid input\n\0" as *const u8 as *const ::core::ffi::c_char);
        while getchar() != '\n' as i32 {}
        return;
    }
    while getchar() != '\n' as i32 {}
    if type1 < 0 as ::core::ffi::c_int || type1 >= SHAPE_COUNT as ::core::ffi::c_int
        || type2 < 0 as ::core::ffi::c_int || type2 >= SHAPE_COUNT as ::core::ffi::c_int
    {
        printf(b"Invalid shape type\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    let mut s1: *mut shape_t = shape_get(type1 as shape_type_t);
    let mut s2: *mut shape_t = shape_get(type2 as shape_type_t);
    printf(
        b"\nShape 1: %s (ptr: %p)\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*s1).name.as_mut_ptr(),
        s1 as *mut ::core::ffi::c_void,
    );
    printf(
        b"Shape 2: %s (ptr: %p)\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*s2).name.as_mut_ptr(),
        s2 as *mut ::core::ffi::c_void,
    );
    printf(
        b"Comparison of pointers: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
        (s1 == s2) as ::core::ffi::c_int,
    );
    if shape_equals(s1, s2) != 0 {
        printf(
            b"Result: Shapes are EQUAL (same instance)\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {
        printf(
            b"Result: Shapes are NOT EQUAL (different instances)\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
}
#[no_mangle]
pub unsafe extern "C" fn compare_scenes() {
    if scene_count < 2 as ::core::ffi::c_int {
        printf(
            b"Need at least 2 scenes to compare\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return;
    }
    printf(
        b"Select first scene (0-%d): \0" as *const u8 as *const ::core::ffi::c_char,
        scene_count - 1 as ::core::ffi::c_int,
    );
    let mut idx1: ::core::ffi::c_int = 0;
    if scanf(
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut idx1 as *mut ::core::ffi::c_int,
    ) != 1 as ::core::ffi::c_int
    {
        printf(b"Invalid input\n\0" as *const u8 as *const ::core::ffi::c_char);
        while getchar() != '\n' as i32 {}
        return;
    }
    while getchar() != '\n' as i32 {}
    printf(
        b"Select second scene (0-%d): \0" as *const u8 as *const ::core::ffi::c_char,
        scene_count - 1 as ::core::ffi::c_int,
    );
    let mut idx2: ::core::ffi::c_int = 0;
    if scanf(
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut idx2 as *mut ::core::ffi::c_int,
    ) != 1 as ::core::ffi::c_int
    {
        printf(b"Invalid input\n\0" as *const u8 as *const ::core::ffi::c_char);
        while getchar() != '\n' as i32 {}
        return;
    }
    while getchar() != '\n' as i32 {}
    if idx1 < 0 as ::core::ffi::c_int || idx1 >= scene_count
        || idx2 < 0 as ::core::ffi::c_int || idx2 >= scene_count
    {
        printf(b"Invalid scene index\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    let mut sc1: *mut scene_t = scenes[idx1 as usize];
    let mut sc2: *mut scene_t = scenes[idx2 as usize];
    printf(
        b"\nScene 1: %s (%d shapes)\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*sc1).name.as_mut_ptr(),
        (*sc1).shape_count,
    );
    scene_list_shapes(sc1);
    printf(
        b"\nScene 2: %s (%d shapes)\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*sc2).name.as_mut_ptr(),
        (*sc2).shape_count,
    );
    scene_list_shapes(sc2);
    if scene_equals(sc1, sc2) != 0 {
        printf(
            b"\nResult: Scenes are EQUAL (1:1 correspondence)\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    } else {
        printf(
            b"\nResult: Scenes are NOT EQUAL\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
    };
}
#[no_mangle]
pub unsafe extern "C" fn delete_scene() {
    if scene_count == 0 as ::core::ffi::c_int {
        printf(b"No scenes available\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    printf(
        b"Select scene to delete (0-%d): \0" as *const u8 as *const ::core::ffi::c_char,
        scene_count - 1 as ::core::ffi::c_int,
    );
    let mut scene_idx: ::core::ffi::c_int = 0;
    if scanf(
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut scene_idx as *mut ::core::ffi::c_int,
    ) != 1 as ::core::ffi::c_int
    {
        printf(b"Invalid input\n\0" as *const u8 as *const ::core::ffi::c_char);
        while getchar() != '\n' as i32 {}
        return;
    }
    while getchar() != '\n' as i32 {}
    if scene_idx < 0 as ::core::ffi::c_int || scene_idx >= scene_count {
        printf(b"Invalid scene index\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    scene_destroy(scenes[scene_idx as usize]);
    let mut i: ::core::ffi::c_int = scene_idx;
    while i < scene_count - 1 as ::core::ffi::c_int {
        scenes[i as usize] = scenes[(i + 1 as ::core::ffi::c_int) as usize];
        i += 1;
    }
    scene_count -= 1;
    printf(b"Scene deleted\n\0" as *const u8 as *const ::core::ffi::c_char);
}
unsafe fn main_0() -> ::core::ffi::c_int {
    printf(
        b"\xE2\x95\x94\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x97\n\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    printf(
        b"\xE2\x95\x91  ASCII ART DRAWING APPLICATION        \xE2\x95\x91\n\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    printf(
        b"\xE2\x95\x91  Child-Friendly Shape Editor           \xE2\x95\x91\n\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    printf(
        b"\xE2\x95\x9A\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x90\xE2\x95\x9D\n\0"
            as *const u8 as *const ::core::ffi::c_char,
    );
    shape_manager_init();
    let mut input: [::core::ffi::c_char; 256] = [0; 256];
    let mut choice: ::core::ffi::c_int = 0;
    loop {
        print_menu();
        if fgets(
                input.as_mut_ptr(),
                ::core::mem::size_of::<[::core::ffi::c_char; 256]>()
                    as ::core::ffi::c_int,
                __stdinp,
            )
            .is_null()
        {
            break;
        }
        if sscanf(
            input.as_mut_ptr(),
            b"%d\0" as *const u8 as *const ::core::ffi::c_char,
            &mut choice as *mut ::core::ffi::c_int,
        ) != 1 as ::core::ffi::c_int
        {
            printf(b"Invalid input\n\0" as *const u8 as *const ::core::ffi::c_char);
        } else {
            match choice {
                1 => {
                    view_all_shapes();
                }
                2 => {
                    create_new_scene();
                }
                3 => {
                    add_shape_to_scene();
                }
                4 => {
                    remove_shape_from_scene();
                }
                5 => {
                    view_scene();
                }
                6 => {
                    list_all_scenes();
                }
                7 => {
                    save_scene_to_file();
                }
                8 => {
                    load_scene_from_file();
                }
                9 => {
                    compare_shapes();
                }
                10 => {
                    compare_scenes();
                }
                11 => {
                    delete_scene();
                }
                12 => {
                    printf(
                        b"\nCleaning up and exiting...\n\0" as *const u8
                            as *const ::core::ffi::c_char,
                    );
                    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
                    while i < scene_count {
                        scene_destroy(scenes[i as usize]);
                        i += 1;
                    }
                    shape_manager_cleanup();
                    printf(b"Goodbye!\n\0" as *const u8 as *const ::core::ffi::c_char);
                    return 0 as ::core::ffi::c_int;
                }
                _ => {
                    printf(
                        b"Invalid choice\n\0" as *const u8 as *const ::core::ffi::c_char,
                    );
                }
            }
        }
    }
    let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_0 < scene_count {
        scene_destroy(scenes[i_0 as usize]);
        i_0 += 1;
    }
    shape_manager_cleanup();
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
