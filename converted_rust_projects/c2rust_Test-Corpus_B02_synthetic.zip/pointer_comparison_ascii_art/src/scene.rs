#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    fn shape_get(type_0: shape_type_t) -> *mut shape_t;
    fn shape_print(shape: *const shape_t);
    fn shape_equals(s1: *const shape_t, s2: *const shape_t) -> ::core::ffi::c_int;
    static mut __stderrp: *mut FILE;
    fn fclose(_: *mut FILE) -> ::core::ffi::c_int;
    fn fgets(
        _: *mut ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *mut FILE,
    ) -> *mut ::core::ffi::c_char;
    fn fopen(
        __filename: *const ::core::ffi::c_char,
        __mode: *const ::core::ffi::c_char,
    ) -> *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn fscanf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn strcpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
    fn strcspn(
        __s: *const ::core::ffi::c_char,
        __charset: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_ulong;
    fn strncpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> *mut ::core::ffi::c_char;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type shape_type_t = ::core::ffi::c_uint;
pub const SHAPE_COUNT: shape_type_t = 10;
pub const SHAPE_RAINBOW: shape_type_t = 9;
pub const SHAPE_HEART: shape_type_t = 8;
pub const SHAPE_STAR: shape_type_t = 7;
pub const SHAPE_CAR: shape_type_t = 6;
pub const SHAPE_FLOWER: shape_type_t = 5;
pub const SHAPE_CLOUD: shape_type_t = 4;
pub const SHAPE_SUN: shape_type_t = 3;
pub const SHAPE_HOUSE: shape_type_t = 2;
pub const SHAPE_TRACTOR: shape_type_t = 1;
pub const SHAPE_TREE: shape_type_t = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct shape_t {
    pub type_0: shape_type_t,
    pub name: [::core::ffi::c_char; 32],
    pub art: [[::core::ffi::c_char; 80]; 30],
    pub width: ::core::ffi::c_int,
    pub height: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct scene_t {
    pub name: [::core::ffi::c_char; 64],
    pub shapes: [*mut shape_t; 50],
    pub shape_count: ::core::ffi::c_int,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const MAX_SHAPES_IN_SCENE: ::core::ffi::c_int = 50 as ::core::ffi::c_int;
pub const MAX_SCENE_NAME: ::core::ffi::c_int = 64 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn scene_create(
    mut name: *const ::core::ffi::c_char,
) -> *mut scene_t {
    let mut scene: *mut scene_t = malloc(::core::mem::size_of::<scene_t>() as size_t)
        as *mut scene_t;
    if scene.is_null() {
        return 0 as *mut scene_t;
    }
    if !name.is_null() {
        strncpy(
            (*scene).name.as_mut_ptr(),
            name,
            (MAX_SCENE_NAME - 1 as ::core::ffi::c_int) as size_t,
        );
        (*scene).name[(MAX_SCENE_NAME - 1 as ::core::ffi::c_int) as usize] = '\0' as i32
            as ::core::ffi::c_char;
    } else {
        strcpy(
            (*scene).name.as_mut_ptr(),
            b"Untitled Scene\0" as *const u8 as *const ::core::ffi::c_char,
        );
    }
    (*scene).shape_count = 0 as ::core::ffi::c_int;
    return scene;
}
#[no_mangle]
pub unsafe extern "C" fn scene_destroy(mut scene: *mut scene_t) {
    if !scene.is_null() {
        free(scene as *mut ::core::ffi::c_void);
    }
}
#[no_mangle]
pub unsafe extern "C" fn scene_add_shape(
    mut scene: *mut scene_t,
    mut shape: *mut shape_t,
) -> ::core::ffi::c_int {
    if scene.is_null() || shape.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    if (*scene).shape_count >= MAX_SHAPES_IN_SCENE {
        fprintf(
            __stderrp,
            b"Error: Scene is full\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return -(1 as ::core::ffi::c_int);
    }
    let fresh0 = (*scene).shape_count;
    (*scene).shape_count = (*scene).shape_count + 1;
    (*scene).shapes[fresh0 as usize] = shape;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn scene_remove_shape(
    mut scene: *mut scene_t,
    mut index: ::core::ffi::c_int,
) -> ::core::ffi::c_int {
    if scene.is_null() || index < 0 as ::core::ffi::c_int
        || index >= (*scene).shape_count
    {
        return -(1 as ::core::ffi::c_int);
    }
    let mut i: ::core::ffi::c_int = index;
    while i < (*scene).shape_count - 1 as ::core::ffi::c_int {
        (*scene).shapes[i as usize] = (*scene)
            .shapes[(i + 1 as ::core::ffi::c_int) as usize];
        i += 1;
    }
    (*scene).shape_count -= 1;
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn scene_print(mut scene: *const scene_t) {
    if scene.is_null() {
        printf(b"(null scene)\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    printf(
        b"\n=== Scene: %s ===\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*scene).name.as_ptr(),
    );
    printf(
        b"Contains %d shape(s)\n\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*scene).shape_count,
    );
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*scene).shape_count {
        printf(
            b"Shape #%d:\n\0" as *const u8 as *const ::core::ffi::c_char,
            i + 1 as ::core::ffi::c_int,
        );
        shape_print((*scene).shapes[i as usize]);
        printf(b"\n\0" as *const u8 as *const ::core::ffi::c_char);
        i += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn scene_equals(
    mut s1: *const scene_t,
    mut s2: *const scene_t,
) -> ::core::ffi::c_int {
    if s1.is_null() || s2.is_null() {
        return 0 as ::core::ffi::c_int;
    }
    if (*s1).shape_count != (*s2).shape_count {
        return 0 as ::core::ffi::c_int;
    }
    let mut matched: [::core::ffi::c_int; 50] = [0 as ::core::ffi::c_int; 50];
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*s1).shape_count {
        let mut found: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        let mut j: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while j < (*s2).shape_count {
            if matched[j as usize] == 0
                && shape_equals((*s1).shapes[i as usize], (*s2).shapes[j as usize]) != 0
            {
                matched[j as usize] = 1 as ::core::ffi::c_int;
                found = 1 as ::core::ffi::c_int;
                break;
            } else {
                j += 1;
            }
        }
        if found == 0 {
            return 0 as ::core::ffi::c_int;
        }
        i += 1;
    }
    return 1 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn scene_save(
    mut scene: *const scene_t,
    mut filename: *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    if scene.is_null() || filename.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    let mut file: *mut FILE = fopen(
        filename,
        b"w\0" as *const u8 as *const ::core::ffi::c_char,
    ) as *mut FILE;
    if file.is_null() {
        fprintf(
            __stderrp,
            b"Error: Could not open file '%s' for writing\n\0" as *const u8
                as *const ::core::ffi::c_char,
            filename,
        );
        return -(1 as ::core::ffi::c_int);
    }
    fprintf(
        file,
        b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*scene).name.as_ptr(),
    );
    fprintf(
        file,
        b"%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*scene).shape_count,
    );
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*scene).shape_count {
        fprintf(
            file,
            b"%d\n\0" as *const u8 as *const ::core::ffi::c_char,
            (*(*scene).shapes[i as usize]).type_0 as ::core::ffi::c_uint,
        );
        i += 1;
    }
    fclose(file);
    printf(
        b"Scene saved to '%s'\n\0" as *const u8 as *const ::core::ffi::c_char,
        filename,
    );
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn scene_load(
    mut filename: *const ::core::ffi::c_char,
) -> *mut scene_t {
    if filename.is_null() {
        return 0 as *mut scene_t;
    }
    let mut file: *mut FILE = fopen(
        filename,
        b"r\0" as *const u8 as *const ::core::ffi::c_char,
    ) as *mut FILE;
    if file.is_null() {
        fprintf(
            __stderrp,
            b"Error: Could not open file '%s' for reading\n\0" as *const u8
                as *const ::core::ffi::c_char,
            filename,
        );
        return 0 as *mut scene_t;
    }
    let mut name: [::core::ffi::c_char; 64] = [0; 64];
    if fgets(name.as_mut_ptr(), MAX_SCENE_NAME, file).is_null() {
        fclose(file);
        return 0 as *mut scene_t;
    }
    name[strcspn(name.as_mut_ptr(), b"\n\0" as *const u8 as *const ::core::ffi::c_char)
        as usize] = 0 as ::core::ffi::c_char;
    let mut scene: *mut scene_t = scene_create(name.as_mut_ptr());
    if scene.is_null() {
        fclose(file);
        return 0 as *mut scene_t;
    }
    let mut shape_count: ::core::ffi::c_int = 0;
    if fscanf(
        file,
        b"%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        &mut shape_count as *mut ::core::ffi::c_int,
    ) != 1 as ::core::ffi::c_int
    {
        scene_destroy(scene);
        fclose(file);
        return 0 as *mut scene_t;
    }
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < shape_count {
        let mut type_0: ::core::ffi::c_int = 0;
        if fscanf(
            file,
            b"%d\n\0" as *const u8 as *const ::core::ffi::c_char,
            &mut type_0 as *mut ::core::ffi::c_int,
        ) != 1 as ::core::ffi::c_int
        {
            scene_destroy(scene);
            fclose(file);
            return 0 as *mut scene_t;
        }
        let mut shape: *mut shape_t = shape_get(type_0 as shape_type_t);
        if !shape.is_null() {
            scene_add_shape(scene, shape);
        }
        i += 1;
    }
    fclose(file);
    printf(
        b"Scene loaded from '%s'\n\0" as *const u8 as *const ::core::ffi::c_char,
        filename,
    );
    return scene;
}
#[no_mangle]
pub unsafe extern "C" fn scene_list_shapes(mut scene: *const scene_t) {
    if scene.is_null() {
        printf(b"(null scene)\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    printf(
        b"\nScene: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*scene).name.as_ptr(),
    );
    printf(
        b"Shapes (%d):\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*scene).shape_count,
    );
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*scene).shape_count {
        printf(
            b"  %d. %s (ptr: %p)\n\0" as *const u8 as *const ::core::ffi::c_char,
            i + 1 as ::core::ffi::c_int,
            (**(*scene).shapes.as_ptr().offset(i as isize)).name.as_mut_ptr(),
            (*scene).shapes[i as usize] as *mut ::core::ffi::c_void,
        );
        i += 1;
    }
}
