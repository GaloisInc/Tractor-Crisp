#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn strcpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn exit(_: ::core::ffi::c_int) -> !;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type shape_type_t = ::core::ffi::c_uint;
pub const SHAPE_COUNT: shape_type_t = 10;
pub const SHAPE_RAINBOW: shape_type_t = 9;
pub const SHAPE_HEART: shape_type_t = 8;
pub const SHAPE_STAR: shape_type_t = 7;
pub const SHAPE_CAR: shape_type_t = 6;
pub const SHAPE_FLOWER: shape_type_t = 5;
pub const SHAPE_CLOUD: shape_type_t = 4;
pub const SHAPE_SUN: shape_type_t = 3;
pub const SHAPE_HOUSE: shape_type_t = 2;
pub const SHAPE_TRACTOR: shape_type_t = 1;
pub const SHAPE_TREE: shape_type_t = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct shape_t {
    pub type_0: shape_type_t,
    pub name: [::core::ffi::c_char; 32],
    pub art: [[::core::ffi::c_char; 80]; 30],
    pub width: ::core::ffi::c_int,
    pub height: ::core::ffi::c_int,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
static mut shapes: [*mut shape_t; 10] = [
    0 as *const shape_t as *mut shape_t,
    0 as *const shape_t as *mut shape_t,
    0 as *const shape_t as *mut shape_t,
    0 as *const shape_t as *mut shape_t,
    0 as *const shape_t as *mut shape_t,
    0 as *const shape_t as *mut shape_t,
    0 as *const shape_t as *mut shape_t,
    0 as *const shape_t as *mut shape_t,
    0 as *const shape_t as *mut shape_t,
    0 as *const shape_t as *mut shape_t,
];
unsafe extern "C" fn init_tree(mut shape: *mut shape_t) {
    (*shape).type_0 = SHAPE_TREE;
    strcpy(
        (*shape).name.as_mut_ptr(),
        b"Tree\0" as *const u8 as *const ::core::ffi::c_char,
    );
    (*shape).height = 7 as ::core::ffi::c_int;
    (*shape).width = 11 as ::core::ffi::c_int;
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(0 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"    /\\    \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(1 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"   /  \\   \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(2 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"  /____\\  \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(3 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"  /    \\  \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(4 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b" /______\\ \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(5 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"    ||    \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(6 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"    ||    \0" as *const u8 as *const ::core::ffi::c_char,
    );
}
unsafe extern "C" fn init_tractor(mut shape: *mut shape_t) {
    (*shape).type_0 = SHAPE_TRACTOR;
    strcpy(
        (*shape).name.as_mut_ptr(),
        b"Tractor\0" as *const u8 as *const ::core::ffi::c_char,
    );
    (*shape).height = 6 as ::core::ffi::c_int;
    (*shape).width = 20 as ::core::ffi::c_int;
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(0 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"      ________     \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(1 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"     |        |___ \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(2 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"     |  []  []|   |\0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(3 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"  ___|________|___|\0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(4 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b" /  o        o   \\\0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(5 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"|___|        |___| \0" as *const u8 as *const ::core::ffi::c_char,
    );
}
unsafe extern "C" fn init_house(mut shape: *mut shape_t) {
    (*shape).type_0 = SHAPE_HOUSE;
    strcpy(
        (*shape).name.as_mut_ptr(),
        b"House\0" as *const u8 as *const ::core::ffi::c_char,
    );
    (*shape).height = 7 as ::core::ffi::c_int;
    (*shape).width = 13 as ::core::ffi::c_int;
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(0 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"     /\\     \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(1 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"    /  \\    \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(2 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"   /____\\   \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(3 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"   |    |   \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(4 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"   | [] |   \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(5 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"   |    |   \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(6 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"   |____|   \0" as *const u8 as *const ::core::ffi::c_char,
    );
}
unsafe extern "C" fn init_sun(mut shape: *mut shape_t) {
    (*shape).type_0 = SHAPE_SUN;
    strcpy(
        (*shape).name.as_mut_ptr(),
        b"Sun\0" as *const u8 as *const ::core::ffi::c_char,
    );
    (*shape).height = 7 as ::core::ffi::c_int;
    (*shape).width = 11 as ::core::ffi::c_int;
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(0 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"  \\  |  / \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(1 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"   \\ | /  \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(2 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"--- (@) ---\0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(3 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"   / | \\  \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(4 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"  /  |  \\ \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(5 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"          \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(6 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"          \0" as *const u8 as *const ::core::ffi::c_char,
    );
}
unsafe extern "C" fn init_cloud(mut shape: *mut shape_t) {
    (*shape).type_0 = SHAPE_CLOUD;
    strcpy(
        (*shape).name.as_mut_ptr(),
        b"Cloud\0" as *const u8 as *const ::core::ffi::c_char,
    );
    (*shape).height = 4 as ::core::ffi::c_int;
    (*shape).width = 16 as ::core::ffi::c_int;
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(0 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"   _____       \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(1 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"  /     \\_    \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(2 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b" /  ___  _\\  \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(3 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"(__/   \\_)   \0" as *const u8 as *const ::core::ffi::c_char,
    );
}
unsafe extern "C" fn init_flower(mut shape: *mut shape_t) {
    (*shape).type_0 = SHAPE_FLOWER;
    strcpy(
        (*shape).name.as_mut_ptr(),
        b"Flower\0" as *const u8 as *const ::core::ffi::c_char,
    );
    (*shape).height = 7 as ::core::ffi::c_int;
    (*shape).width = 9 as ::core::ffi::c_int;
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(0 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"  \\|/  \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(1 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b" -(@)- \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(2 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"  /|\\  \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(3 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"   |   \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(4 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"   |   \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(5 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"  / \\  \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(6 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b" /   \\ \0" as *const u8 as *const ::core::ffi::c_char,
    );
}
unsafe extern "C" fn init_car(mut shape: *mut shape_t) {
    (*shape).type_0 = SHAPE_CAR;
    strcpy(
        (*shape).name.as_mut_ptr(),
        b"Car\0" as *const u8 as *const ::core::ffi::c_char,
    );
    (*shape).height = 4 as ::core::ffi::c_int;
    (*shape).width = 16 as ::core::ffi::c_int;
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(0 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"  ____       \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(1 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b" /|_||_\\____ \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(2 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"( o     o  ) \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(3 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b" -----------  \0" as *const u8 as *const ::core::ffi::c_char,
    );
}
unsafe extern "C" fn init_star(mut shape: *mut shape_t) {
    (*shape).type_0 = SHAPE_STAR;
    strcpy(
        (*shape).name.as_mut_ptr(),
        b"Star\0" as *const u8 as *const ::core::ffi::c_char,
    );
    (*shape).height = 5 as ::core::ffi::c_int;
    (*shape).width = 9 as ::core::ffi::c_int;
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(0 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"    *    \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(1 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"   ***   \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(2 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"  *****  \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(3 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b" ******* \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(4 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"*********\0" as *const u8 as *const ::core::ffi::c_char,
    );
}
unsafe extern "C" fn init_heart(mut shape: *mut shape_t) {
    (*shape).type_0 = SHAPE_HEART;
    strcpy(
        (*shape).name.as_mut_ptr(),
        b"Heart\0" as *const u8 as *const ::core::ffi::c_char,
    );
    (*shape).height = 6 as ::core::ffi::c_int;
    (*shape).width = 11 as ::core::ffi::c_int;
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(0 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b" *** ***  \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(1 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"*********  \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(2 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"*********  \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(3 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b" ******* \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(4 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"  *****  \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(5 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"   ***   \0" as *const u8 as *const ::core::ffi::c_char,
    );
}
unsafe extern "C" fn init_rainbow(mut shape: *mut shape_t) {
    (*shape).type_0 = SHAPE_RAINBOW;
    strcpy(
        (*shape).name.as_mut_ptr(),
        b"Rainbow\0" as *const u8 as *const ::core::ffi::c_char,
    );
    (*shape).height = 5 as ::core::ffi::c_int;
    (*shape).width = 21 as ::core::ffi::c_int;
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(0 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"      _______      \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(1 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"    /         \\    \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(2 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"   /           \\   \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(3 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b"  /             \\  \0" as *const u8 as *const ::core::ffi::c_char,
    );
    strcpy(
        (*(*shape).art.as_mut_ptr().offset(4 as ::core::ffi::c_int as isize))
            .as_mut_ptr(),
        b" /               \\ \0" as *const u8 as *const ::core::ffi::c_char,
    );
}
#[no_mangle]
pub unsafe extern "C" fn shape_manager_init() {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < SHAPE_COUNT as ::core::ffi::c_int {
        shapes[i as usize] = malloc(::core::mem::size_of::<shape_t>() as size_t)
            as *mut shape_t;
        if shapes[i as usize].is_null() {
            fprintf(
                __stderrp,
                b"Error: Failed to allocate shape\n\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
            exit(1 as ::core::ffi::c_int);
        }
        i += 1;
    }
    init_tree(shapes[SHAPE_TREE as ::core::ffi::c_int as usize]);
    init_tractor(shapes[SHAPE_TRACTOR as ::core::ffi::c_int as usize]);
    init_house(shapes[SHAPE_HOUSE as ::core::ffi::c_int as usize]);
    init_sun(shapes[SHAPE_SUN as ::core::ffi::c_int as usize]);
    init_cloud(shapes[SHAPE_CLOUD as ::core::ffi::c_int as usize]);
    init_flower(shapes[SHAPE_FLOWER as ::core::ffi::c_int as usize]);
    init_car(shapes[SHAPE_CAR as ::core::ffi::c_int as usize]);
    init_star(shapes[SHAPE_STAR as ::core::ffi::c_int as usize]);
    init_heart(shapes[SHAPE_HEART as ::core::ffi::c_int as usize]);
    init_rainbow(shapes[SHAPE_RAINBOW as ::core::ffi::c_int as usize]);
}
#[no_mangle]
pub unsafe extern "C" fn shape_manager_cleanup() {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < SHAPE_COUNT as ::core::ffi::c_int {
        free(shapes[i as usize] as *mut ::core::ffi::c_void);
        shapes[i as usize] = 0 as *mut shape_t;
        i += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn shape_get(mut type_0: shape_type_t) -> *mut shape_t {
    if (type_0 as ::core::ffi::c_uint) < 0 as ::core::ffi::c_uint
        || type_0 as ::core::ffi::c_uint
            >= SHAPE_COUNT as ::core::ffi::c_int as ::core::ffi::c_uint
    {
        return 0 as *mut shape_t;
    }
    return shapes[type_0 as usize];
}
#[no_mangle]
pub unsafe extern "C" fn shape_print(mut shape: *const shape_t) {
    if shape.is_null() {
        printf(b"(null shape)\n\0" as *const u8 as *const ::core::ffi::c_char);
        return;
    }
    printf(
        b"%s:\n\0" as *const u8 as *const ::core::ffi::c_char,
        (*shape).name.as_ptr(),
    );
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < (*shape).height {
        printf(
            b"%s\n\0" as *const u8 as *const ::core::ffi::c_char,
            (*(*shape).art.as_ptr().offset(i as isize)).as_ptr(),
        );
        i += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn shape_equals(
    mut s1: *const shape_t,
    mut s2: *const shape_t,
) -> ::core::ffi::c_int {
    return if s1 == s2 { 1 as ::core::ffi::c_int } else { 0 as ::core::ffi::c_int };
}
#[no_mangle]
pub unsafe extern "C" fn shape_type_name(
    mut type_0: shape_type_t,
) -> *const ::core::ffi::c_char {
    match type_0 as ::core::ffi::c_uint {
        0 => return b"Tree\0" as *const u8 as *const ::core::ffi::c_char,
        1 => return b"Tractor\0" as *const u8 as *const ::core::ffi::c_char,
        2 => return b"House\0" as *const u8 as *const ::core::ffi::c_char,
        3 => return b"Sun\0" as *const u8 as *const ::core::ffi::c_char,
        4 => return b"Cloud\0" as *const u8 as *const ::core::ffi::c_char,
        5 => return b"Flower\0" as *const u8 as *const ::core::ffi::c_char,
        6 => return b"Car\0" as *const u8 as *const ::core::ffi::c_char,
        7 => return b"Star\0" as *const u8 as *const ::core::ffi::c_char,
        8 => return b"Heart\0" as *const u8 as *const ::core::ffi::c_char,
        9 => return b"Rainbow\0" as *const u8 as *const ::core::ffi::c_char,
        _ => return b"Unknown\0" as *const u8 as *const ::core::ffi::c_char,
    };
}
