#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn memset(
        __b: *mut ::core::ffi::c_void,
        __c: ::core::ffi::c_int,
        __len: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strcpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
    fn strncpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> *mut ::core::ffi::c_char;
    fn strstr(
        __big: *const ::core::ffi::c_char,
        __little: *const ::core::ffi::c_char,
    ) -> *mut ::core::ffi::c_char;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type token_type_t = ::core::ffi::c_uint;
pub const TOKEN_ERROR: token_type_t = 11;
pub const TOKEN_COMMENT: token_type_t = 10;
pub const TOKEN_STRING: token_type_t = 9;
pub const TOKEN_OPERATOR: token_type_t = 8;
pub const TOKEN_KEYWORD: token_type_t = 7;
pub const TOKEN_IDENTIFIER: token_type_t = 6;
pub const TOKEN_NEWLINE: token_type_t = 5;
pub const TOKEN_WHITESPACE: token_type_t = 4;
pub const TOKEN_PUNCTUATION: token_type_t = 3;
pub const TOKEN_NUMBER: token_type_t = 2;
pub const TOKEN_WORD: token_type_t = 1;
pub const TOKEN_EOF: token_type_t = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct token_t {
    pub type_0: token_type_t,
    pub value: [::core::ffi::c_char; 256],
    pub length: size_t,
    pub line: ::core::ffi::c_int,
    pub column: ::core::ffi::c_int,
}
pub type tokenizer_next_fn = Option<unsafe extern "C" fn() -> token_t>;
pub type tokenizer_peek_fn = Option<unsafe extern "C" fn() -> token_t>;
pub type tokenizer_reset_fn = Option<unsafe extern "C" fn() -> ()>;
pub type tokenizer_load_fn = Option<
    unsafe extern "C" fn(*const ::core::ffi::c_char) -> ::core::ffi::c_int,
>;
pub type tokenizer_get_stats_fn = Option<
    unsafe extern "C" fn(*mut size_t, *mut size_t, *mut size_t) -> (),
>;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tokenizer_ops_t {
    pub next_token: tokenizer_next_fn,
    pub peek_token: tokenizer_peek_fn,
    pub reset: tokenizer_reset_fn,
    pub load_text: tokenizer_load_fn,
    pub get_stats: tokenizer_get_stats_fn,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct analysis_result_t {
    pub word_count: size_t,
    pub number_count: size_t,
    pub keyword_count: size_t,
    pub operator_count: size_t,
    pub comment_count: size_t,
    pub string_count: size_t,
    pub line_count: size_t,
    pub char_count: size_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const MAX_TOKEN_LENGTH: ::core::ffi::c_int = 256 as ::core::ffi::c_int;
static mut tokenizer_ops: tokenizer_ops_t = tokenizer_ops_t {
    next_token: None,
    peek_token: None,
    reset: None,
    load_text: None,
    get_stats: None,
};
static mut initialized: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
static mut token_type_counts: [::core::ffi::c_int; 20] = [0; 20];
static mut common_words: [[::core::ffi::c_char; 256]; 100] = [[0; 256]; 100];
static mut common_word_counts: [::core::ffi::c_int; 100] = [0; 100];
static mut num_common_words: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn analyzer_init(mut ops: tokenizer_ops_t) {
    tokenizer_ops = ops;
    initialized = 1 as ::core::ffi::c_int;
    memset(
        token_type_counts.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<[::core::ffi::c_int; 20]>() as size_t,
    );
    memset(
        common_word_counts.as_mut_ptr() as *mut ::core::ffi::c_void,
        0 as ::core::ffi::c_int,
        ::core::mem::size_of::<[::core::ffi::c_int; 100]>() as size_t,
    );
    num_common_words = 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn track_word(mut word: *const ::core::ffi::c_char) {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < num_common_words {
        if strcmp((*common_words.as_mut_ptr().offset(i as isize)).as_mut_ptr(), word)
            == 0 as ::core::ffi::c_int
        {
            common_word_counts[i as usize] += 1;
            return;
        }
        i += 1;
    }
    if num_common_words < 100 as ::core::ffi::c_int {
        strncpy(
            (*common_words.as_mut_ptr().offset(num_common_words as isize)).as_mut_ptr(),
            word,
            (MAX_TOKEN_LENGTH - 1 as ::core::ffi::c_int) as size_t,
        );
        common_words[num_common_words
            as usize][(MAX_TOKEN_LENGTH - 1 as ::core::ffi::c_int) as usize] = '\0'
            as i32 as ::core::ffi::c_char;
        common_word_counts[num_common_words as usize] = 1 as ::core::ffi::c_int;
        num_common_words += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn analyze_text(
    mut text: *const ::core::ffi::c_char,
) -> analysis_result_t {
    let mut result: analysis_result_t = {
        let mut init = analysis_result_t {
            word_count: 0 as size_t,
            number_count: 0,
            keyword_count: 0,
            operator_count: 0,
            comment_count: 0,
            string_count: 0,
            line_count: 0,
            char_count: 0,
        };
        init
    };
    if initialized == 0 {
        fprintf(
            __stderrp,
            b"Error: Analyzer not initialized\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return result;
    }
    if tokenizer_ops.load_text.expect("non-null function pointer")(text)
        != 0 as ::core::ffi::c_int
    {
        fprintf(
            __stderrp,
            b"Error: Failed to load text\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return result;
    }
    let mut token: token_t = token_t {
        type_0: TOKEN_EOF,
        value: [0; 256],
        length: 0,
        line: 0,
        column: 0,
    };
    loop {
        token = tokenizer_ops.next_token.expect("non-null function pointer")();
        if !(token.type_0 as ::core::ffi::c_uint
            != TOKEN_EOF as ::core::ffi::c_int as ::core::ffi::c_uint)
        {
            break;
        }
        token_type_counts[token.type_0 as usize] += 1;
        match token.type_0 as ::core::ffi::c_uint {
            1 | 6 => {
                result.word_count = result.word_count.wrapping_add(1);
                track_word(token.value.as_mut_ptr());
            }
            2 => {
                result.number_count = result.number_count.wrapping_add(1);
            }
            7 => {
                result.keyword_count = result.keyword_count.wrapping_add(1);
            }
            8 => {
                result.operator_count = result.operator_count.wrapping_add(1);
            }
            10 => {
                result.comment_count = result.comment_count.wrapping_add(1);
            }
            9 => {
                result.string_count = result.string_count.wrapping_add(1);
            }
            5 => {
                result.line_count = result.line_count.wrapping_add(1);
            }
            _ => {}
        }
    }
    let mut lines: size_t = 0;
    let mut tokens: size_t = 0;
    let mut chars: size_t = 0;
    tokenizer_ops
        .get_stats
        .expect("non-null function pointer")(&mut lines, &mut tokens, &mut chars);
    result.line_count = lines;
    result.char_count = chars;
    return result;
}
#[no_mangle]
pub unsafe extern "C" fn print_token_distribution() {
    printf(
        b"\n=== Token Distribution ===\n\0" as *const u8 as *const ::core::ffi::c_char,
    );
    let mut token_names: [*const ::core::ffi::c_char; 12] = [
        b"EOF\0" as *const u8 as *const ::core::ffi::c_char,
        b"WORD\0" as *const u8 as *const ::core::ffi::c_char,
        b"NUMBER\0" as *const u8 as *const ::core::ffi::c_char,
        b"PUNCTUATION\0" as *const u8 as *const ::core::ffi::c_char,
        b"WHITESPACE\0" as *const u8 as *const ::core::ffi::c_char,
        b"NEWLINE\0" as *const u8 as *const ::core::ffi::c_char,
        b"IDENTIFIER\0" as *const u8 as *const ::core::ffi::c_char,
        b"KEYWORD\0" as *const u8 as *const ::core::ffi::c_char,
        b"OPERATOR\0" as *const u8 as *const ::core::ffi::c_char,
        b"STRING\0" as *const u8 as *const ::core::ffi::c_char,
        b"COMMENT\0" as *const u8 as *const ::core::ffi::c_char,
        b"ERROR\0" as *const u8 as *const ::core::ffi::c_char,
    ];
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < 12 as ::core::ffi::c_int {
        if token_type_counts[i as usize] > 0 as ::core::ffi::c_int {
            printf(
                b"%s: %d\n\0" as *const u8 as *const ::core::ffi::c_char,
                token_names[i as usize],
                token_type_counts[i as usize],
            );
        }
        i += 1;
    }
    printf(
        b"\n=== Most Common Words ===\n\0" as *const u8 as *const ::core::ffi::c_char,
    );
    let mut i_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_0 < num_common_words - 1 as ::core::ffi::c_int {
        let mut j: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
        while j < num_common_words - i_0 - 1 as ::core::ffi::c_int {
            if common_word_counts[j as usize]
                < common_word_counts[(j + 1 as ::core::ffi::c_int) as usize]
            {
                let mut temp_count: ::core::ffi::c_int = common_word_counts[j as usize];
                common_word_counts[j as usize] = common_word_counts[(j
                    + 1 as ::core::ffi::c_int) as usize];
                common_word_counts[(j + 1 as ::core::ffi::c_int) as usize] = temp_count;
                let mut temp_word: [::core::ffi::c_char; 256] = [0; 256];
                strcpy(
                    temp_word.as_mut_ptr(),
                    (*common_words.as_mut_ptr().offset(j as isize)).as_mut_ptr(),
                );
                strcpy(
                    (*common_words.as_mut_ptr().offset(j as isize)).as_mut_ptr(),
                    (*common_words
                        .as_mut_ptr()
                        .offset((j + 1 as ::core::ffi::c_int) as isize))
                        .as_mut_ptr(),
                );
                strcpy(
                    (*common_words
                        .as_mut_ptr()
                        .offset((j + 1 as ::core::ffi::c_int) as isize))
                        .as_mut_ptr(),
                    temp_word.as_mut_ptr(),
                );
            }
            j += 1;
        }
        i_0 += 1;
    }
    let mut limit: ::core::ffi::c_int = if num_common_words < 10 as ::core::ffi::c_int {
        num_common_words
    } else {
        10 as ::core::ffi::c_int
    };
    let mut i_1: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i_1 < limit {
        printf(
            b"%d. %s: %d times\n\0" as *const u8 as *const ::core::ffi::c_char,
            i_1 + 1 as ::core::ffi::c_int,
            (*common_words.as_mut_ptr().offset(i_1 as isize)).as_mut_ptr(),
            common_word_counts[i_1 as usize],
        );
        i_1 += 1;
    }
}
#[no_mangle]
pub unsafe extern "C" fn calculate_complexity_score() -> ::core::ffi::c_int {
    let mut score: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    score
        += token_type_counts[TOKEN_KEYWORD as ::core::ffi::c_int as usize]
            * 2 as ::core::ffi::c_int;
    score += token_type_counts[TOKEN_OPERATOR as ::core::ffi::c_int as usize];
    score
        += token_type_counts[TOKEN_PUNCTUATION as ::core::ffi::c_int as usize]
            / 10 as ::core::ffi::c_int;
    score -= token_type_counts[TOKEN_COMMENT as ::core::ffi::c_int as usize];
    if score < 0 as ::core::ffi::c_int {
        score = 0 as ::core::ffi::c_int;
    }
    return score;
}
#[no_mangle]
pub unsafe extern "C" fn find_patterns(mut pattern: *const ::core::ffi::c_char) {
    if initialized == 0 || pattern.is_null() {
        return;
    }
    printf(
        b"\n=== Searching for pattern: '%s' ===\n\0" as *const u8
            as *const ::core::ffi::c_char,
        pattern,
    );
    tokenizer_ops.reset.expect("non-null function pointer")();
    let mut count: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut token: token_t = token_t {
        type_0: TOKEN_EOF,
        value: [0; 256],
        length: 0,
        line: 0,
        column: 0,
    };
    loop {
        token = tokenizer_ops.next_token.expect("non-null function pointer")();
        if !(token.type_0 as ::core::ffi::c_uint
            != TOKEN_EOF as ::core::ffi::c_int as ::core::ffi::c_uint)
        {
            break;
        }
        if !strstr(token.value.as_mut_ptr(), pattern).is_null() {
            printf(
                b"Line %d, Column %d: %s\n\0" as *const u8 as *const ::core::ffi::c_char,
                token.line,
                token.column,
                token.value.as_mut_ptr(),
            );
            count += 1;
        }
    }
    printf(
        b"Found %d occurrences\n\0" as *const u8 as *const ::core::ffi::c_char,
        count,
    );
}
