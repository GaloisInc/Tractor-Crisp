#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types, linkage)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn strchr(
        __s: *const ::core::ffi::c_char,
        __c: ::core::ffi::c_int,
    ) -> *mut ::core::ffi::c_char;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strncpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> *mut ::core::ffi::c_char;
    static mut _DefaultRuneLocale: _RuneLocale;
    fn __maskrune(_: __darwin_ct_rune_t, _: ::core::ffi::c_ulong) -> ::core::ffi::c_int;
}
pub type __uint32_t = u32;
pub type __int64_t = i64;
pub type __darwin_ct_rune_t = ::core::ffi::c_int;
pub type __darwin_size_t = usize;
pub type __darwin_wchar_t = ::libc::wchar_t;
pub type __darwin_rune_t = __darwin_wchar_t;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type token_type_t = ::core::ffi::c_uint;
pub const TOKEN_ERROR: token_type_t = 11;
pub const TOKEN_COMMENT: token_type_t = 10;
pub const TOKEN_STRING: token_type_t = 9;
pub const TOKEN_OPERATOR: token_type_t = 8;
pub const TOKEN_KEYWORD: token_type_t = 7;
pub const TOKEN_IDENTIFIER: token_type_t = 6;
pub const TOKEN_NEWLINE: token_type_t = 5;
pub const TOKEN_WHITESPACE: token_type_t = 4;
pub const TOKEN_PUNCTUATION: token_type_t = 3;
pub const TOKEN_NUMBER: token_type_t = 2;
pub const TOKEN_WORD: token_type_t = 1;
pub const TOKEN_EOF: token_type_t = 0;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct token_t {
    pub type_0: token_type_t,
    pub value: [::core::ffi::c_char; 256],
    pub length: size_t,
    pub line: ::core::ffi::c_int,
    pub column: ::core::ffi::c_int,
}
pub type tokenizer_next_fn = Option<unsafe extern "C" fn() -> token_t>;
pub type tokenizer_peek_fn = Option<unsafe extern "C" fn() -> token_t>;
pub type tokenizer_reset_fn = Option<unsafe extern "C" fn() -> ()>;
pub type tokenizer_load_fn = Option<
    unsafe extern "C" fn(*const ::core::ffi::c_char) -> ::core::ffi::c_int,
>;
pub type tokenizer_get_stats_fn = Option<
    unsafe extern "C" fn(*mut size_t, *mut size_t, *mut size_t) -> (),
>;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct tokenizer_ops_t {
    pub next_token: tokenizer_next_fn,
    pub peek_token: tokenizer_peek_fn,
    pub reset: tokenizer_reset_fn,
    pub load_text: tokenizer_load_fn,
    pub get_stats: tokenizer_get_stats_fn,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneLocale {
    pub __magic: [::core::ffi::c_char; 8],
    pub __encoding: [::core::ffi::c_char; 32],
    pub __sgetrune: Option<
        unsafe extern "C" fn(
            *const ::core::ffi::c_char,
            __darwin_size_t,
            *mut *const ::core::ffi::c_char,
        ) -> __darwin_rune_t,
    >,
    pub __sputrune: Option<
        unsafe extern "C" fn(
            __darwin_rune_t,
            *mut ::core::ffi::c_char,
            __darwin_size_t,
            *mut *mut ::core::ffi::c_char,
        ) -> ::core::ffi::c_int,
    >,
    pub __invalid_rune: __darwin_rune_t,
    pub __runetype: [__uint32_t; 256],
    pub __maplower: [__darwin_rune_t; 256],
    pub __mapupper: [__darwin_rune_t; 256],
    pub __runetype_ext: _RuneRange,
    pub __maplower_ext: _RuneRange,
    pub __mapupper_ext: _RuneRange,
    pub __variable: *mut ::core::ffi::c_void,
    pub __variable_len: ::core::ffi::c_int,
    pub __ncharclasses: ::core::ffi::c_int,
    pub __charclasses: *mut _RuneCharClass,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneCharClass {
    pub __name: [::core::ffi::c_char; 14],
    pub __mask: __uint32_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneRange {
    pub __nranges: ::core::ffi::c_int,
    pub __ranges: *mut _RuneEntry,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct _RuneEntry {
    pub __min: __darwin_rune_t,
    pub __max: __darwin_rune_t,
    pub __map: __darwin_rune_t,
    pub __types: *mut __uint32_t,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const MAX_TOKEN_LENGTH: ::core::ffi::c_int = 256 as ::core::ffi::c_int;
pub const MAX_BUFFER_SIZE: ::core::ffi::c_int = 8192 as ::core::ffi::c_int;
pub const _CACHED_RUNES: ::core::ffi::c_int = (1 as ::core::ffi::c_int)
    << 8 as ::core::ffi::c_int;
pub const _CTYPE_A: ::core::ffi::c_long = 0x100 as ::core::ffi::c_long;
pub const _CTYPE_D: ::core::ffi::c_long = 0x400 as ::core::ffi::c_long;
pub const _CTYPE_S: ::core::ffi::c_long = 0x4000 as ::core::ffi::c_long;
#[inline]
unsafe extern "C" fn isascii(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return (_c & !(0x7f as ::core::ffi::c_int) == 0 as ::core::ffi::c_int)
        as ::core::ffi::c_int;
}
#[inline]
unsafe extern "C" fn __istype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> ::core::ffi::c_int {
    return if isascii(_c as ::core::ffi::c_int) != 0 {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    } else {
        (__maskrune(_c, _f) != 0) as ::core::ffi::c_int
    };
}
#[inline]
unsafe extern "C" fn __isctype(
    mut _c: __darwin_ct_rune_t,
    mut _f: ::core::ffi::c_ulong,
) -> __darwin_ct_rune_t {
    return if _c < 0 as ::core::ffi::c_int || _c >= _CACHED_RUNES {
        0 as __darwin_ct_rune_t
    } else {
        (_DefaultRuneLocale.__runetype[_c as usize] as ::core::ffi::c_ulong & _f != 0)
            as ::core::ffi::c_int
    };
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isalnum(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(
        _c as __darwin_ct_rune_t,
        (_CTYPE_A | _CTYPE_D) as ::core::ffi::c_ulong,
    );
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isalpha(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_A as ::core::ffi::c_ulong);
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isdigit(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __isctype(_c as __darwin_ct_rune_t, _CTYPE_D as ::core::ffi::c_ulong)
        as ::core::ffi::c_int;
}
#[no_mangle]
#[inline]
#[linkage = "external"]
pub unsafe extern "C" fn isspace(mut _c: ::core::ffi::c_int) -> ::core::ffi::c_int {
    return __istype(_c as __darwin_ct_rune_t, _CTYPE_S as ::core::ffi::c_ulong);
}
static mut input_buffer: [::core::ffi::c_char; 8192] = [0; 8192];
static mut buffer_length: size_t = 0 as size_t;
static mut current_position: size_t = 0 as size_t;
static mut current_line: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
static mut current_column: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
static mut total_tokens_processed: size_t = 0 as size_t;
static mut total_lines_processed: size_t = 0 as size_t;
static mut total_chars_processed: size_t = 0 as size_t;
static mut lookahead_token: token_t = token_t {
    type_0: TOKEN_EOF,
    value: [0; 256],
    length: 0,
    line: 0,
    column: 0,
};
static mut lookahead_valid: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
static mut keywords: [*const ::core::ffi::c_char; 31] = [
    b"if\0" as *const u8 as *const ::core::ffi::c_char,
    b"else\0" as *const u8 as *const ::core::ffi::c_char,
    b"while\0" as *const u8 as *const ::core::ffi::c_char,
    b"for\0" as *const u8 as *const ::core::ffi::c_char,
    b"return\0" as *const u8 as *const ::core::ffi::c_char,
    b"int\0" as *const u8 as *const ::core::ffi::c_char,
    b"char\0" as *const u8 as *const ::core::ffi::c_char,
    b"float\0" as *const u8 as *const ::core::ffi::c_char,
    b"double\0" as *const u8 as *const ::core::ffi::c_char,
    b"void\0" as *const u8 as *const ::core::ffi::c_char,
    b"struct\0" as *const u8 as *const ::core::ffi::c_char,
    b"typedef\0" as *const u8 as *const ::core::ffi::c_char,
    b"const\0" as *const u8 as *const ::core::ffi::c_char,
    b"static\0" as *const u8 as *const ::core::ffi::c_char,
    b"extern\0" as *const u8 as *const ::core::ffi::c_char,
    b"auto\0" as *const u8 as *const ::core::ffi::c_char,
    b"register\0" as *const u8 as *const ::core::ffi::c_char,
    b"sizeof\0" as *const u8 as *const ::core::ffi::c_char,
    b"break\0" as *const u8 as *const ::core::ffi::c_char,
    b"continue\0" as *const u8 as *const ::core::ffi::c_char,
    b"switch\0" as *const u8 as *const ::core::ffi::c_char,
    b"case\0" as *const u8 as *const ::core::ffi::c_char,
    b"default\0" as *const u8 as *const ::core::ffi::c_char,
    b"do\0" as *const u8 as *const ::core::ffi::c_char,
    b"goto\0" as *const u8 as *const ::core::ffi::c_char,
    b"enum\0" as *const u8 as *const ::core::ffi::c_char,
    b"union\0" as *const u8 as *const ::core::ffi::c_char,
    b"signed\0" as *const u8 as *const ::core::ffi::c_char,
    b"unsigned\0" as *const u8 as *const ::core::ffi::c_char,
    b"long\0" as *const u8 as *const ::core::ffi::c_char,
    b"short\0" as *const u8 as *const ::core::ffi::c_char,
];
static mut num_keywords: ::core::ffi::c_int = 0;
unsafe extern "C" fn is_keyword(
    mut str: *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut i: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while i < num_keywords {
        if strcmp(str, keywords[i as usize]) == 0 as ::core::ffi::c_int {
            return 1 as ::core::ffi::c_int;
        }
        i += 1;
    }
    return 0 as ::core::ffi::c_int;
}
unsafe extern "C" fn peek_char() -> ::core::ffi::c_char {
    if current_position >= buffer_length {
        return '\0' as i32 as ::core::ffi::c_char;
    }
    return input_buffer[current_position as usize];
}
unsafe extern "C" fn advance_char() -> ::core::ffi::c_char {
    if current_position >= buffer_length {
        return '\0' as i32 as ::core::ffi::c_char;
    }
    let fresh0 = current_position;
    current_position = current_position.wrapping_add(1);
    let mut c: ::core::ffi::c_char = input_buffer[fresh0 as usize];
    total_chars_processed = total_chars_processed.wrapping_add(1);
    if c as ::core::ffi::c_int == '\n' as i32 {
        current_line += 1;
        current_column = 1 as ::core::ffi::c_int;
        total_lines_processed = total_lines_processed.wrapping_add(1);
    } else {
        current_column += 1;
    }
    return c;
}
unsafe extern "C" fn skip_whitespace() {
    while peek_char() as ::core::ffi::c_int != '\0' as i32
        && isspace(peek_char() as ::core::ffi::c_int) != 0
        && peek_char() as ::core::ffi::c_int != '\n' as i32
    {
        advance_char();
    }
}
unsafe extern "C" fn create_token(
    mut type_0: token_type_t,
    mut value: *const ::core::ffi::c_char,
    mut length: size_t,
) -> token_t {
    let mut token: token_t = token_t {
        type_0: TOKEN_EOF,
        value: [0; 256],
        length: 0,
        line: 0,
        column: 0,
    };
    token.type_0 = type_0;
    token.length = if length < MAX_TOKEN_LENGTH as size_t {
        length
    } else {
        (MAX_TOKEN_LENGTH - 1 as ::core::ffi::c_int) as size_t
    };
    strncpy(token.value.as_mut_ptr(), value, token.length);
    token.value[token.length as usize] = '\0' as i32 as ::core::ffi::c_char;
    token.line = current_line;
    token.column = (current_column as size_t).wrapping_sub(token.length)
        as ::core::ffi::c_int;
    total_tokens_processed = total_tokens_processed.wrapping_add(1);
    return token;
}
unsafe extern "C" fn scan_word() -> token_t {
    let mut buffer: [::core::ffi::c_char; 256] = [0; 256];
    let mut length: size_t = 0 as size_t;
    while peek_char() as ::core::ffi::c_int != '\0' as i32
        && (isalnum(peek_char() as ::core::ffi::c_int) != 0
            || peek_char() as ::core::ffi::c_int == '_' as i32)
        && length < (MAX_TOKEN_LENGTH - 1 as ::core::ffi::c_int) as size_t
    {
        let fresh16 = length;
        length = length.wrapping_add(1);
        buffer[fresh16 as usize] = advance_char();
    }
    buffer[length as usize] = '\0' as i32 as ::core::ffi::c_char;
    if is_keyword(buffer.as_mut_ptr()) != 0 {
        return create_token(TOKEN_KEYWORD, buffer.as_mut_ptr(), length);
    }
    return create_token(TOKEN_IDENTIFIER, buffer.as_mut_ptr(), length);
}
unsafe extern "C" fn scan_number() -> token_t {
    let mut buffer: [::core::ffi::c_char; 256] = [0; 256];
    let mut length: size_t = 0 as size_t;
    let mut has_decimal: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    while peek_char() as ::core::ffi::c_int != '\0' as i32
        && (isdigit(peek_char() as ::core::ffi::c_int) != 0
            || peek_char() as ::core::ffi::c_int == '.' as i32)
        && length < (MAX_TOKEN_LENGTH - 1 as ::core::ffi::c_int) as size_t
    {
        if peek_char() as ::core::ffi::c_int == '.' as i32 {
            if has_decimal != 0 {
                break;
            }
            has_decimal = 1 as ::core::ffi::c_int;
        }
        let fresh15 = length;
        length = length.wrapping_add(1);
        buffer[fresh15 as usize] = advance_char();
    }
    buffer[length as usize] = '\0' as i32 as ::core::ffi::c_char;
    return create_token(TOKEN_NUMBER, buffer.as_mut_ptr(), length);
}
unsafe extern "C" fn scan_string() -> token_t {
    let mut buffer: [::core::ffi::c_char; 256] = [0; 256];
    let mut length: size_t = 0 as size_t;
    let mut quote: ::core::ffi::c_char = advance_char();
    let fresh10 = length;
    length = length.wrapping_add(1);
    buffer[fresh10 as usize] = quote;
    while peek_char() as ::core::ffi::c_int != '\0' as i32
        && peek_char() as ::core::ffi::c_int != quote as ::core::ffi::c_int
        && peek_char() as ::core::ffi::c_int != '\n' as i32
        && length < (MAX_TOKEN_LENGTH - 2 as ::core::ffi::c_int) as size_t
    {
        if peek_char() as ::core::ffi::c_int == '\\' as i32 {
            let fresh11 = length;
            length = length.wrapping_add(1);
            buffer[fresh11 as usize] = advance_char();
            if peek_char() as ::core::ffi::c_int != '\0' as i32 {
                let fresh12 = length;
                length = length.wrapping_add(1);
                buffer[fresh12 as usize] = advance_char();
            }
        } else {
            let fresh13 = length;
            length = length.wrapping_add(1);
            buffer[fresh13 as usize] = advance_char();
        }
    }
    if peek_char() as ::core::ffi::c_int == quote as ::core::ffi::c_int {
        let fresh14 = length;
        length = length.wrapping_add(1);
        buffer[fresh14 as usize] = advance_char();
    }
    buffer[length as usize] = '\0' as i32 as ::core::ffi::c_char;
    return create_token(TOKEN_STRING, buffer.as_mut_ptr(), length);
}
unsafe extern "C" fn scan_comment() -> token_t {
    let mut buffer: [::core::ffi::c_char; 256] = [0; 256];
    let mut length: size_t = 0 as size_t;
    let fresh3 = length;
    length = length.wrapping_add(1);
    buffer[fresh3 as usize] = advance_char();
    if peek_char() as ::core::ffi::c_int == '/' as i32 {
        let fresh4 = length;
        length = length.wrapping_add(1);
        buffer[fresh4 as usize] = advance_char();
        while peek_char() as ::core::ffi::c_int != '\0' as i32
            && peek_char() as ::core::ffi::c_int != '\n' as i32
            && length < (MAX_TOKEN_LENGTH - 1 as ::core::ffi::c_int) as size_t
        {
            let fresh5 = length;
            length = length.wrapping_add(1);
            buffer[fresh5 as usize] = advance_char();
        }
    } else if peek_char() as ::core::ffi::c_int == '*' as i32 {
        let fresh6 = length;
        length = length.wrapping_add(1);
        buffer[fresh6 as usize] = advance_char();
        while peek_char() as ::core::ffi::c_int != '\0' as i32
            && length < (MAX_TOKEN_LENGTH - 2 as ::core::ffi::c_int) as size_t
        {
            if peek_char() as ::core::ffi::c_int == '*' as i32 {
                let fresh7 = length;
                length = length.wrapping_add(1);
                buffer[fresh7 as usize] = advance_char();
                if !(peek_char() as ::core::ffi::c_int == '/' as i32) {
                    continue;
                }
                let fresh8 = length;
                length = length.wrapping_add(1);
                buffer[fresh8 as usize] = advance_char();
                break;
            } else {
                let fresh9 = length;
                length = length.wrapping_add(1);
                buffer[fresh9 as usize] = advance_char();
            }
        }
    }
    buffer[length as usize] = '\0' as i32 as ::core::ffi::c_char;
    return create_token(TOKEN_COMMENT, buffer.as_mut_ptr(), length);
}
unsafe extern "C" fn scan_operator() -> token_t {
    let mut buffer: [::core::ffi::c_char; 256] = [0; 256];
    let mut length: size_t = 0 as size_t;
    let mut c: ::core::ffi::c_char = peek_char();
    let fresh1 = length;
    length = length.wrapping_add(1);
    buffer[fresh1 as usize] = advance_char();
    let mut next: ::core::ffi::c_char = peek_char();
    if c as ::core::ffi::c_int == '=' as i32 && next as ::core::ffi::c_int == '=' as i32
        || c as ::core::ffi::c_int == '!' as i32
            && next as ::core::ffi::c_int == '=' as i32
        || c as ::core::ffi::c_int == '<' as i32
            && next as ::core::ffi::c_int == '=' as i32
        || c as ::core::ffi::c_int == '>' as i32
            && next as ::core::ffi::c_int == '=' as i32
        || c as ::core::ffi::c_int == '&' as i32
            && next as ::core::ffi::c_int == '&' as i32
        || c as ::core::ffi::c_int == '|' as i32
            && next as ::core::ffi::c_int == '|' as i32
        || c as ::core::ffi::c_int == '+' as i32
            && next as ::core::ffi::c_int == '+' as i32
        || c as ::core::ffi::c_int == '-' as i32
            && next as ::core::ffi::c_int == '-' as i32
        || c as ::core::ffi::c_int == '-' as i32
            && next as ::core::ffi::c_int == '>' as i32
        || c as ::core::ffi::c_int == '<' as i32
            && next as ::core::ffi::c_int == '<' as i32
        || c as ::core::ffi::c_int == '>' as i32
            && next as ::core::ffi::c_int == '>' as i32
    {
        let fresh2 = length;
        length = length.wrapping_add(1);
        buffer[fresh2 as usize] = advance_char();
    }
    buffer[length as usize] = '\0' as i32 as ::core::ffi::c_char;
    return create_token(TOKEN_OPERATOR, buffer.as_mut_ptr(), length);
}
#[no_mangle]
pub unsafe extern "C" fn tokenizer_next_token() -> token_t {
    if lookahead_valid != 0 {
        lookahead_valid = 0 as ::core::ffi::c_int;
        return lookahead_token;
    }
    skip_whitespace();
    if current_position >= buffer_length {
        return create_token(
            TOKEN_EOF,
            b"\0" as *const u8 as *const ::core::ffi::c_char,
            0 as size_t,
        );
    }
    let mut c: ::core::ffi::c_char = peek_char();
    if c as ::core::ffi::c_int == '\n' as i32 {
        let mut newline: [::core::ffi::c_char; 2] = [
            advance_char(),
            '\0' as i32 as ::core::ffi::c_char,
        ];
        return create_token(TOKEN_NEWLINE, newline.as_mut_ptr(), 1 as size_t);
    }
    if isalpha(c as ::core::ffi::c_int) != 0 || c as ::core::ffi::c_int == '_' as i32 {
        return scan_word();
    }
    if isdigit(c as ::core::ffi::c_int) != 0 {
        return scan_number();
    }
    if c as ::core::ffi::c_int == '"' as i32 || c as ::core::ffi::c_int == '\'' as i32 {
        return scan_string();
    }
    if c as ::core::ffi::c_int == '/' as i32
        && (peek_char() as ::core::ffi::c_int == '/' as i32
            || peek_char() as ::core::ffi::c_int == '*' as i32)
    {
        return scan_comment();
    }
    if !strchr(
            b"+-*/%=<>!&|^~?:\0" as *const u8 as *const ::core::ffi::c_char,
            c as ::core::ffi::c_int,
        )
        .is_null()
    {
        return scan_operator();
    }
    if !strchr(
            b"(){}[];,.\0" as *const u8 as *const ::core::ffi::c_char,
            c as ::core::ffi::c_int,
        )
        .is_null()
    {
        let mut punct: [::core::ffi::c_char; 2] = [
            advance_char(),
            '\0' as i32 as ::core::ffi::c_char,
        ];
        return create_token(TOKEN_PUNCTUATION, punct.as_mut_ptr(), 1 as size_t);
    }
    let mut unknown: [::core::ffi::c_char; 2] = [
        advance_char(),
        '\0' as i32 as ::core::ffi::c_char,
    ];
    return create_token(TOKEN_ERROR, unknown.as_mut_ptr(), 1 as size_t);
}
#[no_mangle]
pub unsafe extern "C" fn tokenizer_peek_token() -> token_t {
    if lookahead_valid == 0 {
        lookahead_token = tokenizer_next_token();
        lookahead_valid = 1 as ::core::ffi::c_int;
    }
    return lookahead_token;
}
#[no_mangle]
pub unsafe extern "C" fn tokenizer_reset() {
    current_position = 0 as size_t;
    current_line = 1 as ::core::ffi::c_int;
    current_column = 1 as ::core::ffi::c_int;
    lookahead_valid = 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn tokenizer_load_text(
    mut text: *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    if text.is_null() {
        return -(1 as ::core::ffi::c_int);
    }
    let mut length: size_t = strlen(text);
    if length >= MAX_BUFFER_SIZE as size_t {
        fprintf(
            __stderrp,
            b"Error: Input text too large\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return -(1 as ::core::ffi::c_int);
    }
    strncpy(
        input_buffer.as_mut_ptr(),
        text,
        (MAX_BUFFER_SIZE - 1 as ::core::ffi::c_int) as size_t,
    );
    input_buffer[(MAX_BUFFER_SIZE - 1 as ::core::ffi::c_int) as usize] = '\0' as i32
        as ::core::ffi::c_char;
    buffer_length = length;
    tokenizer_reset();
    return 0 as ::core::ffi::c_int;
}
#[no_mangle]
pub unsafe extern "C" fn tokenizer_get_stats(
    mut lines: *mut size_t,
    mut tokens: *mut size_t,
    mut chars: *mut size_t,
) {
    if !lines.is_null() {
        *lines = total_lines_processed;
    }
    if !tokens.is_null() {
        *tokens = total_tokens_processed;
    }
    if !chars.is_null() {
        *chars = total_chars_processed;
    }
}
#[no_mangle]
pub unsafe extern "C" fn get_tokenizer_ops() -> tokenizer_ops_t {
    let mut ops: tokenizer_ops_t = tokenizer_ops_t {
        next_token: None,
        peek_token: None,
        reset: None,
        load_text: None,
        get_stats: None,
    };
    ops.next_token = Some(tokenizer_next_token as unsafe extern "C" fn() -> token_t)
        as tokenizer_next_fn;
    ops.peek_token = Some(tokenizer_peek_token as unsafe extern "C" fn() -> token_t)
        as tokenizer_peek_fn;
    ops.reset = Some(tokenizer_reset as unsafe extern "C" fn() -> ())
        as tokenizer_reset_fn;
    ops.load_text = Some(
        tokenizer_load_text
            as unsafe extern "C" fn(*const ::core::ffi::c_char) -> ::core::ffi::c_int,
    ) as tokenizer_load_fn;
    ops.get_stats = Some(
        tokenizer_get_stats
            as unsafe extern "C" fn(*mut size_t, *mut size_t, *mut size_t) -> (),
    ) as tokenizer_get_stats_fn;
    return ops;
}
unsafe extern "C" fn run_static_initializers() {
    num_keywords = (::core::mem::size_of::<[*const ::core::ffi::c_char; 31]>() as usize)
        .wrapping_div(::core::mem::size_of::<*const ::core::ffi::c_char>() as usize)
        as ::core::ffi::c_int;
}
#[used]
#[cfg_attr(target_os = "linux", link_section = ".init_array")]
#[cfg_attr(target_os = "windows", link_section = ".CRT$XIB")]
#[cfg_attr(target_os = "macos", link_section = "__DATA,__mod_init_func")]
static INIT_ARRAY: [unsafe extern "C" fn(); 1] = [run_static_initializers];
