#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn scanf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn process_strings(
        input: *mut ::core::ffi::c_char,
        input_len: size_t,
        reference: *const ::core::ffi::c_char,
        ref_len: size_t,
        operation: ::core::ffi::c_int,
        flags: uint32_t,
    ) -> ::core::ffi::c_int;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
pub type uint32_t = u32;
pub const MAX_BUFFER_SIZE: ::core::ffi::c_int = 1024 as ::core::ffi::c_int;
unsafe fn main_0() -> ::core::ffi::c_int {
    let mut operation: ::core::ffi::c_int = 0;
    let mut flags: uint32_t = 0;
    let mut input_len: size_t = 0;
    let mut ref_len: size_t = 0;
    let mut input_buffer: [::core::ffi::c_char; 1024] = [0; 1024];
    let mut ref_buffer: [::core::ffi::c_char; 1024] = [0; 1024];
    if scanf(
        b"%d\0" as *const u8 as *const ::core::ffi::c_char,
        &mut operation as *mut ::core::ffi::c_int,
    ) != 1 as ::core::ffi::c_int
    {
        fprintf(
            __stderrp,
            b"Error reading operation\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    if scanf(
        b"%u\0" as *const u8 as *const ::core::ffi::c_char,
        &mut flags as *mut uint32_t,
    ) != 1 as ::core::ffi::c_int
    {
        fprintf(
            __stderrp,
            b"Error reading flags\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    if scanf(
        b"%zu\0" as *const u8 as *const ::core::ffi::c_char,
        &mut input_len as *mut size_t,
    ) != 1 as ::core::ffi::c_int
    {
        fprintf(
            __stderrp,
            b"Error reading input length\n\0" as *const u8 as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    if input_len > MAX_BUFFER_SIZE as size_t {
        fprintf(
            __stderrp,
            b"Error: input length %zu exceeds maximum %d\n\0" as *const u8
                as *const ::core::ffi::c_char,
            input_len,
            MAX_BUFFER_SIZE,
        );
        return 1 as ::core::ffi::c_int;
    }
    let mut i: size_t = 0 as size_t;
    while i < input_len {
        let mut byte: ::core::ffi::c_uint = 0;
        if scanf(
            b"%u\0" as *const u8 as *const ::core::ffi::c_char,
            &mut byte as *mut ::core::ffi::c_uint,
        ) != 1 as ::core::ffi::c_int
        {
            fprintf(
                __stderrp,
                b"Error reading input byte %zu\n\0" as *const u8
                    as *const ::core::ffi::c_char,
                i,
            );
            return 1 as ::core::ffi::c_int;
        }
        input_buffer[i as usize] = byte as ::core::ffi::c_char;
        i = i.wrapping_add(1);
    }
    if scanf(
        b"%zu\0" as *const u8 as *const ::core::ffi::c_char,
        &mut ref_len as *mut size_t,
    ) != 1 as ::core::ffi::c_int
    {
        fprintf(
            __stderrp,
            b"Error reading reference length\n\0" as *const u8
                as *const ::core::ffi::c_char,
        );
        return 1 as ::core::ffi::c_int;
    }
    if ref_len > MAX_BUFFER_SIZE as size_t {
        fprintf(
            __stderrp,
            b"Error: reference length %zu exceeds maximum %d\n\0" as *const u8
                as *const ::core::ffi::c_char,
            ref_len,
            MAX_BUFFER_SIZE,
        );
        return 1 as ::core::ffi::c_int;
    }
    let mut i_0: size_t = 0 as size_t;
    while i_0 < ref_len {
        let mut byte_0: ::core::ffi::c_uint = 0;
        if scanf(
            b"%u\0" as *const u8 as *const ::core::ffi::c_char,
            &mut byte_0 as *mut ::core::ffi::c_uint,
        ) != 1 as ::core::ffi::c_int
        {
            fprintf(
                __stderrp,
                b"Error reading reference byte %zu\n\0" as *const u8
                    as *const ::core::ffi::c_char,
                i_0,
            );
            return 1 as ::core::ffi::c_int;
        }
        ref_buffer[i_0 as usize] = byte_0 as ::core::ffi::c_char;
        i_0 = i_0.wrapping_add(1);
    }
    let mut result: ::core::ffi::c_int = process_strings(
        input_buffer.as_mut_ptr(),
        input_len,
        ref_buffer.as_mut_ptr(),
        ref_len,
        operation,
        flags,
    );
    printf(b"%d\n\0" as *const u8 as *const ::core::ffi::c_char, result);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    unsafe { ::std::process::exit(main_0() as i32) }
}
