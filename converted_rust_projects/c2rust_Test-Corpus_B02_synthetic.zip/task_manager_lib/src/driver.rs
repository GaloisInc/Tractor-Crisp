#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stderrp: *mut FILE;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn malloc(__size: size_t) -> *mut ::core::ffi::c_void;
    fn free(_: *mut ::core::ffi::c_void);
    fn create_task_manager() -> *mut TaskManager;
    fn add_task(
        manager: *mut TaskManager,
        description: *const ::core::ffi::c_char,
        priority: ::core::ffi::c_int,
    );
    fn print_tasks(manager: *const TaskManager);
    fn destroy_task_manager(manager: *mut TaskManager);
    fn initialize_logger() -> ::core::ffi::c_int;
    fn finalize_logger();
    fn strchr(
        __s: *const ::core::ffi::c_char,
        __c: ::core::ffi::c_int,
    ) -> *mut ::core::ffi::c_char;
    fn strlen(__s: *const ::core::ffi::c_char) -> size_t;
    fn strncpy(
        __dst: *mut ::core::ffi::c_char,
        __src: *const ::core::ffi::c_char,
        __n: size_t,
    ) -> *mut ::core::ffi::c_char;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct Task {
    pub description: [::core::ffi::c_char; 256],
    pub priority: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct TaskManager {
    pub tasks: *mut Task,
    pub max_tasks: ::core::ffi::c_int,
    pub task_count: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const EXIT_FAILURE: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn driver(
    mut tasks: *const ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut res: ::core::ffi::c_int = initialize_logger();
    if res != 0 as ::core::ffi::c_int {
        return EXIT_FAILURE;
    }
    let mut manager: *mut TaskManager = create_task_manager();
    if manager.is_null() {
        return EXIT_FAILURE;
    }
    let mut start: *const ::core::ffi::c_char = tasks;
    let mut priority: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    while *start as ::core::ffi::c_int != '\0' as i32 {
        let mut end: *const ::core::ffi::c_char = strchr(start, '\n' as i32);
        if end.is_null() {
            end = start.offset(strlen(start) as isize);
        }
        let mut length: size_t = end.offset_from(start) as ::core::ffi::c_long as size_t;
        let mut task: *mut ::core::ffi::c_char = malloc(length.wrapping_add(1 as size_t))
            as *mut ::core::ffi::c_char;
        if task.is_null() {
            fprintf(
                __stderrp,
                b"Error: Failed to allocate memory for task.\n\0" as *const u8
                    as *const ::core::ffi::c_char,
            );
            destroy_task_manager(manager);
            finalize_logger();
            return EXIT_FAILURE;
        }
        strncpy(task, start, length);
        *task.offset(length as isize) = '\0' as i32 as ::core::ffi::c_char;
        let fresh0 = priority;
        priority = priority + 1;
        add_task(manager, task, fresh0);
        free(task as *mut ::core::ffi::c_void);
        start = if *end as ::core::ffi::c_int == '\n' as i32 {
            end.offset(1 as ::core::ffi::c_int as isize)
        } else {
            end
        };
    }
    print_tasks(manager);
    destroy_task_manager(manager);
    finalize_logger();
    return 0 as ::core::ffi::c_int;
}
