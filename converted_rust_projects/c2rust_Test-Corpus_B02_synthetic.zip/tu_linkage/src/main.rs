#![allow(
    dead_code,
    non_camel_case_types,
    non_snake_case,
    non_upper_case_globals,
    unused_assignments,
    unused_mut
)]
#![feature(extern_types)]
extern "C" {
    pub type __sFILEX;
    static mut __stdinp: *mut FILE;
    static mut __stdoutp: *mut FILE;
    static mut __stderrp: *mut FILE;
    fn fgets(
        _: *mut ::core::ffi::c_char,
        _: ::core::ffi::c_int,
        _: *mut FILE,
    ) -> *mut ::core::ffi::c_char;
    fn fprintf(_: *mut FILE, _: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn printf(_: *const ::core::ffi::c_char, ...) -> ::core::ffi::c_int;
    fn strtol(
        __str: *const ::core::ffi::c_char,
        __endptr: *mut *mut ::core::ffi::c_char,
        __base: ::core::ffi::c_int,
    ) -> ::core::ffi::c_long;
    fn strcmp(
        __s1: *const ::core::ffi::c_char,
        __s2: *const ::core::ffi::c_char,
    ) -> ::core::ffi::c_int;
    fn iv_init(v: *mut IntVec);
    fn iv_free(v: *mut IntVec);
    fn iv_push(v: *mut IntVec, x: ::core::ffi::c_int) -> bool;
    fn vm_init(vm: *mut VM);
    fn vm_free(vm: *mut VM);
    fn vm_print(fp: *mut FILE, label: *const ::core::ffi::c_char, vm: *const VM);
    fn run_engine(
        impl_id: ::core::ffi::c_int,
        code: *const ::core::ffi::c_int,
        n: size_t,
        vm: *mut VM,
    ) -> ::core::ffi::c_int;
}
pub type __int64_t = i64;
pub type __darwin_size_t = usize;
pub type __darwin_off_t = __int64_t;
pub type size_t = __darwin_size_t;
pub type fpos_t = __darwin_off_t;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sbuf {
    pub _base: *mut ::core::ffi::c_uchar,
    pub _size: ::core::ffi::c_int,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct __sFILE {
    pub _p: *mut ::core::ffi::c_uchar,
    pub _r: ::core::ffi::c_int,
    pub _w: ::core::ffi::c_int,
    pub _flags: ::core::ffi::c_short,
    pub _file: ::core::ffi::c_short,
    pub _bf: __sbuf,
    pub _lbfsize: ::core::ffi::c_int,
    pub _cookie: *mut ::core::ffi::c_void,
    pub _close: Option<
        unsafe extern "C" fn(*mut ::core::ffi::c_void) -> ::core::ffi::c_int,
    >,
    pub _read: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *mut ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _seek: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            fpos_t,
            ::core::ffi::c_int,
        ) -> fpos_t,
    >,
    pub _write: Option<
        unsafe extern "C" fn(
            *mut ::core::ffi::c_void,
            *const ::core::ffi::c_char,
            ::core::ffi::c_int,
        ) -> ::core::ffi::c_int,
    >,
    pub _ub: __sbuf,
    pub _extra: *mut __sFILEX,
    pub _ur: ::core::ffi::c_int,
    pub _ubuf: [::core::ffi::c_uchar; 3],
    pub _nbuf: [::core::ffi::c_uchar; 1],
    pub _lb: __sbuf,
    pub _blksize: ::core::ffi::c_int,
    pub _offset: fpos_t,
}
pub type FILE = __sFILE;
#[derive(Copy, Clone)]
#[repr(C)]
pub struct IntVec {
    pub data: *mut ::core::ffi::c_int,
    pub len: size_t,
    pub cap: size_t,
}
#[derive(Copy, Clone)]
#[repr(C)]
pub struct VM {
    pub stack: IntVec,
    pub trace: IntVec,
    pub steps: ::core::ffi::c_int,
}
pub const __DARWIN_NULL: *mut ::core::ffi::c_void = 0 as *mut ::core::ffi::c_void;
pub const NULL: *mut ::core::ffi::c_void = __DARWIN_NULL;
pub const true_0: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
pub const false_0: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
unsafe extern "C" fn usage(mut p: *const ::core::ffi::c_char) {
    fprintf(
        __stderrp,
        b"Usage: %s [--stdin] [bytecodes...]\nBytecodes are integers forming a small VM program.\n\0"
            as *const u8 as *const ::core::ffi::c_char,
        p,
    );
}
unsafe extern "C" fn read_stdin(mut v: *mut IntVec) -> size_t {
    let mut buf: [::core::ffi::c_char; 4096] = [0; 4096];
    let mut count: size_t = 0 as size_t;
    while !fgets(
            buf.as_mut_ptr(),
            ::core::mem::size_of::<[::core::ffi::c_char; 4096]>() as ::core::ffi::c_int,
            __stdinp,
        )
        .is_null()
    {
        let mut p: *mut ::core::ffi::c_char = buf.as_mut_ptr();
        while *p != 0 {
            let mut q: *mut ::core::ffi::c_char = p;
            while *q as ::core::ffi::c_int != 0 && *q as ::core::ffi::c_int != ' ' as i32
                && *q as ::core::ffi::c_int != '\t' as i32
                && *q as ::core::ffi::c_int != '\n' as i32
                && *q as ::core::ffi::c_int != '\r' as i32
            {
                q = q.offset(1);
            }
            let mut save: ::core::ffi::c_char = *q;
            *q = '\0' as i32 as ::core::ffi::c_char;
            if *p != 0 {
                let mut e: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
                let mut t: ::core::ffi::c_long = strtol(
                    p,
                    &mut e,
                    10 as ::core::ffi::c_int,
                );
                if !e.is_null() && *e as ::core::ffi::c_int == '\0' as i32 {
                    iv_push(v, t as ::core::ffi::c_int);
                    count = count.wrapping_add(1);
                }
            }
            *q = save;
            p = if *q as ::core::ffi::c_int != 0 {
                q.offset(1 as ::core::ffi::c_int as isize)
            } else {
                q
            };
        }
    }
    return count;
}
unsafe fn main_0(
    mut argc: ::core::ffi::c_int,
    mut argv: *mut *mut ::core::ffi::c_char,
) -> ::core::ffi::c_int {
    let mut use_stdin: bool = false_0 != 0;
    let mut code: IntVec = IntVec {
        data: 0 as *mut ::core::ffi::c_int,
        len: 0,
        cap: 0,
    };
    iv_init(&mut code);
    let mut i: ::core::ffi::c_int = 1 as ::core::ffi::c_int;
    while i < argc {
        if strcmp(
            *argv.offset(i as isize),
            b"--help\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0
        {
            usage(*argv.offset(0 as ::core::ffi::c_int as isize));
            iv_free(&mut code);
            return 0 as ::core::ffi::c_int;
        } else if strcmp(
            *argv.offset(i as isize),
            b"--stdin\0" as *const u8 as *const ::core::ffi::c_char,
        ) == 0
        {
            use_stdin = true_0 != 0;
        } else {
            let mut e: *mut ::core::ffi::c_char = 0 as *mut ::core::ffi::c_char;
            let mut t: ::core::ffi::c_long = strtol(
                *argv.offset(i as isize),
                &mut e,
                10 as ::core::ffi::c_int,
            );
            if !e.is_null() && *e as ::core::ffi::c_int == '\0' as i32 {
                iv_push(&mut code, t as ::core::ffi::c_int);
            } else {
                fprintf(
                    __stderrp,
                    b"skip '%s'\n\0" as *const u8 as *const ::core::ffi::c_char,
                    *argv.offset(i as isize),
                );
            }
        }
        i += 1;
    }
    if use_stdin {
        read_stdin(&mut code);
    }
    if code.len == 0 as size_t {
        fprintf(__stderrp, b"no program\n\0" as *const u8 as *const ::core::ffi::c_char);
        iv_free(&mut code);
        return 2 as ::core::ffi::c_int;
    }
    let mut vmA: VM = VM {
        stack: IntVec {
            data: 0 as *mut ::core::ffi::c_int,
            len: 0,
            cap: 0,
        },
        trace: IntVec {
            data: 0 as *mut ::core::ffi::c_int,
            len: 0,
            cap: 0,
        },
        steps: 0,
    };
    let mut vmB: VM = VM {
        stack: IntVec {
            data: 0 as *mut ::core::ffi::c_int,
            len: 0,
            cap: 0,
        },
        trace: IntVec {
            data: 0 as *mut ::core::ffi::c_int,
            len: 0,
            cap: 0,
        },
        steps: 0,
    };
    let mut vmE: VM = VM {
        stack: IntVec {
            data: 0 as *mut ::core::ffi::c_int,
            len: 0,
            cap: 0,
        },
        trace: IntVec {
            data: 0 as *mut ::core::ffi::c_int,
            len: 0,
            cap: 0,
        },
        steps: 0,
    };
    vm_init(&mut vmA);
    vm_init(&mut vmB);
    vm_init(&mut vmE);
    let mut rcA: ::core::ffi::c_int = run_engine(
        0 as ::core::ffi::c_int,
        code.data,
        code.len,
        &mut vmA,
    );
    let mut rcB: ::core::ffi::c_int = run_engine(
        1 as ::core::ffi::c_int,
        code.data,
        code.len,
        &mut vmB,
    );
    let mut rcE: ::core::ffi::c_int = run_engine(
        2 as ::core::ffi::c_int,
        code.data,
        code.len,
        &mut vmE,
    );
    printf(
        b"RC:A=%d B=%d EXT=%d\n\0" as *const u8 as *const ::core::ffi::c_char,
        rcA,
        rcB,
        rcE,
    );
    vm_print(__stdoutp, b"A:\0" as *const u8 as *const ::core::ffi::c_char, &mut vmA);
    vm_print(__stdoutp, b"B:\0" as *const u8 as *const ::core::ffi::c_char, &mut vmB);
    vm_print(__stdoutp, b"EXT:\0" as *const u8 as *const ::core::ffi::c_char, &mut vmE);
    vm_free(&mut vmA);
    vm_free(&mut vmB);
    vm_free(&mut vmE);
    iv_free(&mut code);
    return 0 as ::core::ffi::c_int;
}
pub fn main() {
    let mut args: Vec<*mut ::core::ffi::c_char> = Vec::new();
    for arg in ::std::env::args() {
        args.push(
            ::std::ffi::CString::new(arg)
                .expect("Failed to convert argument into CString.")
                .into_raw(),
        );
    }
    args.push(::core::ptr::null_mut());
    unsafe {
        ::std::process::exit(
            main_0(
                (args.len() - 1) as ::core::ffi::c_int,
                args.as_mut_ptr() as *mut *mut ::core::ffi::c_char,
            ) as i32,
        )
    }
}
